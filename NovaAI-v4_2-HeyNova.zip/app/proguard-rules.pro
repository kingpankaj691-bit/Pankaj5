# org.json is part of Android; keep our own JSON-facing models and the libraries that use reflection or JNI.
-keep class org.json.** { *; }
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }
-keep class org.vosk.** { *; }
-keepclassmembers class * extends com.sun.jna.** { public *; }
-dontwarn java.awt.**
-dontwarn javax.annotation.**
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
# WebView JS bridge classes (none are exposed to generated sites)
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
# Compose and Room generated code needs no extra rules; services in the manifest are kept automatically.
-keep class com.nova.ai.agent.ShareToNovaActivity { *; }
