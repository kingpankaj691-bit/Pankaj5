package com.nova.ai.brain

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Needs a phone or emulator: real SQLite persistence across reopen, migrations, Android Keystore vault. */
@RunWith(AndroidJUnit4::class)
class BrainInstrumentedTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val name = "nova_brain_test.db"

    private fun <T> withStore(block: (SqlBrainStore) -> T): T { val s = SqlBrainStore(ctx, name); try { return block(s) } finally { s.close() } }

    @Before fun clean() { ctx.deleteDatabase(name) }
    @After fun after() { ctx.deleteDatabase(name) }

    @Test fun memorySurvivesClosingAndReopeningTheDatabase() {
        withStore { s -> MemoryService(s).save(Candidate(BrainCategory.PREFERENCE, "ui", "dark liquid glass UI pasand hai"), "test"); s.putState("lang.cur", "hinglish") }
        withStore { s ->
            assertEquals(1, s.items().size); assertEquals("hinglish", s.getState("lang.cur")); assertTrue(s.integrityOk())
        }
    }

    @Test fun upgradeFromVersionOneKeepsDataAndAddsVersionTable() {
        // build a version-1 database by hand, then let the helper upgrade it
        val db = ctx.openOrCreateDatabase(name, Context.MODE_PRIVATE, null)
        SqlBrainStore.MIGRATIONS[0].forEach { db.execSQL(it) }
        db.execSQL("INSERT INTO items(category,title,content,created,updated,last_used,source,hash) VALUES('NOTE','t','old note',1,1,1,'x','h')")
        db.version = 1; db.close()
        withStore { s ->
            assertEquals(1, s.items().size)
            val it = s.items().first(); s.saveItem(it.copy(content = "new note"))
            assertEquals(listOf(1 to "old note"), s.versions(it.id))
        }
    }

    @Test fun transactionRollsBackOnFailure() {
        withStore { s ->
            try { s.tx { s.putState("a", "1"); throw IllegalStateException("boom") } } catch (e: IllegalStateException) { }
            assertEquals(null, s.getState("a"))
        }
    }

    @Test fun keystoreVaultRoundTrip() {
        withStore { s ->
            val v = SecureVault(s, { KeystoreKeys.vaultKey() })
            val id = v.add("Test", VaultKind.NOTE, "secret text")
            assertEquals("secret text", v.reveal(id))
            assertTrue(s.vault().single().cipher.size > 20)
        }
    }

    @Test fun backupRestoreOnRealDatabase() {
        withStore { s ->
            MemoryService(s).save(Candidate(BrainCategory.TASK, "t", "voice engine complete karna hai", status = Status.PENDING), "test")
            val json = BackupManager.export(s, System.currentTimeMillis(), "t")
            s.wipeAll(); assertEquals(0, s.items().size)
            BackupManager.restore(s, json, false); assertEquals(1, s.items().size)
        }
    }
}
