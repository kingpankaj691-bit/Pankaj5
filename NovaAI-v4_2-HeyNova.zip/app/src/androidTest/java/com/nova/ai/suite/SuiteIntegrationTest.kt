package com.nova.ai.suite

import android.content.Context
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** Runs on a device/emulator (./gradlew connectedDirectDebugAndroidTest). Uses real Android classes and Nova's private storage. */
@RunWith(AndroidJUnit4::class)
class SuiteIntegrationTest {
    private lateinit var ctx: Context

    @Before fun setUp() { ctx = InstrumentationRegistry.getInstrumentation().targetContext }
    @After fun tearDown() {
        AssetManager.list(ctx).filter { it.name.startsWith("itest_") }.forEach { AssetManager.delete(ctx, it) }
        SecurityWatch.clear(ctx); Workflows.History.clear(ctx); LogAnalyzer.clearHistory(ctx)
    }

    @Test fun assetImportPreviewCopyExportDelete() {
        val src = File(ctx.cacheDir, "itest_note.txt").apply { writeText("hello nova") }
        val item = AssetManager.importUri(ctx, Uri.fromFile(src))
        assertNotNull(item); assertEquals("snippet", item!!.type)
        assertEquals("hello nova", AssetManager.previewText(ctx, item))
        assertTrue(AssetManager.copy(ctx, item).startsWith("Text copied"))
        val out = File(ctx.cacheDir, "itest_export.txt")
        assertTrue(AssetManager.exportTo(ctx, item, Uri.fromFile(out))); assertEquals("hello nova", out.readText())
        assertTrue(AssetManager.recent(ctx, 3).any { it.id == item.id })
        assertTrue(AssetManager.delete(ctx, item)); assertFalse(AssetManager.list(ctx).any { it.id == item.id })
    }

    @Test fun snippetSaveAndDuplicateNames() {
        val a = AssetManager.saveSnippet(ctx, "itest_a", "one"); val b = AssetManager.saveSnippet(ctx, "itest_a", "two")
        assertNotNull(a); assertNotNull(b); assertTrue(a!!.id != b!!.id)
    }

    @Test fun securityActivityLogAndRetention() {
        Features.set(ctx, Features.WATCH, true)
        SecurityWatch.log(ctx, "test", "hello")
        assertEquals("hello", SecurityWatch.events(ctx).first().text)
        Retention.setDays(ctx, 0); SecurityWatch.clear(ctx); assertTrue(SecurityWatch.events(ctx).isEmpty())
        Features.set(ctx, Features.WATCH, false); SecurityWatch.log(ctx, "test", "ignored"); assertTrue(SecurityWatch.events(ctx).isEmpty())
        Features.set(ctx, Features.WATCH, true)
        Retention.setDays(ctx, 30)
    }

    @Test fun snapshotListsAllSevenAccessItems() { assertEquals(7, SecurityWatch.snapshot(ctx).size) }

    @Test fun workflowAndErrorHistoryRoundTrip() {
        Workflows.History.add(ctx, "t", "ok"); assertEquals("t", Workflows.History.list(ctx).first().second)
        LogAnalyzer.remember(ctx, "summary"); assertEquals("summary", LogAnalyzer.history(ctx).first().second)
    }

    @Test fun systemInfoIsReadable() {
        assertTrue(SystemControls.batteryInfo(ctx).startsWith("Battery"))
        assertTrue(SystemControls.networkInfo(ctx).isNotBlank())
    }

    @Test fun audioFocusAcquireReleaseIsSafe() {
        AudioDucker.setEnabled(ctx, true); AudioDucker.acquire(ctx); AudioDucker.release(ctx); assertFalse(AudioDucker.active)
    }

    @Test fun deviceInventoryAndProtection() {
        assertTrue(DeviceMgmt.inventory(ctx).isNotEmpty())
        assertFalse(DeviceMgmt.canRestrict(ctx, ctx.packageName)); assertFalse(DeviceMgmt.canRestrict(ctx, "com.android.settings"))
    }

    @Test fun featureSwitchesGateEntryPoints() {
        Features.set(ctx, Features.VISION, false)
        assertTrue(LiveOcr.start(ctx, null).contains("turned off")); assertFalse(LiveOcr.running)
        Features.set(ctx, Features.VISION, true)
        Features.set(ctx, Features.TERMUX, false)
        val (p, _) = TermuxBridge.prepare("git status"); assertTrue(TermuxBridge.run(ctx, p!!)!!.contains("turned off"))
        Features.set(ctx, Features.TERMUX, true)
    }

    @Test fun perfProfileAnswers() { assertTrue(PerfProfile.ocrBaseMs(ctx) >= 2500L) }

    @Test fun voiceLevelReactsToLoudPcm() {
        val loud = ByteArray(1600) { i -> if (i % 2 == 0) 0x00 else 0x40 }      // 16-bit samples around +16384
        Thread.sleep(100); VoiceLevel.feed(loud, loud.size); assertTrue(VoiceLevel.level.value > 0.5f)
        Thread.sleep(100); VoiceLevel.feed(ByteArray(1600), 1600); assertEquals(0f, VoiceLevel.level.value, 0.001f)
    }
}
