package com.nova.ai.control;

/** Runs inside the Shizuku "shell" process. Every command is re-validated by ShellPolicy there before it runs. */
interface IShellService {
    /** Reserved id: Shizuku calls this when the service is being torn down. */
    void destroy() = 16777114;

    /** Returns "exitCode\u0001stdout\u0001stderr". */
    String exec(String command, int timeoutMs) = 1;
}
