package com.nova.ai.control

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import com.nova.ai.files.Access
import com.nova.ai.files.FileAccess
import com.nova.ai.files.FileAccessPolicy
import com.nova.ai.files.FileNeed
import kotlinx.coroutines.delay

class ApkInfo(val pkg: String, val label: String, val versionName: String, val versionCode: Long)
class ApkFile(val name: String, val uri: Uri, val path: String?, val modified: Long)

/**
 * Installs and uninstalls apps ONLY through Android's own system screens. Nothing here can approve those screens:
 * the user always confirms in Android. After handing over, it WAITS and checks the real package state, so "uninstalled" /
 * "installed" is only reported when the phone says so. Protected apps are refused by [AppGuard] before any screen opens.
 */
object AppInstaller {
    private const val APK_MIME = "application/vnd.android.package-archive"

    fun isInstalled(ctx: Context, pkg: String): Boolean = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun versionCodeOf(ctx: Context, pkg: String): Long = try {
        val i = ctx.packageManager.getPackageInfo(pkg, 0)
        if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()
    } catch (e: Exception) { -1L }

    /** System apps and updated system apps. Android only lets the user disable or update these. */
    fun isSystem(ctx: Context, pkg: String): Boolean = try {
        val f = ctx.packageManager.getApplicationInfo(pkg, 0).flags
        (f and ApplicationInfo.FLAG_SYSTEM) != 0 || (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
    } catch (e: Exception) { false }

    /** Android 8+: the user must allow Nova as an install source. This is a real runtime state, not an assumption. */
    fun canInstallUnknown(ctx: Context): Boolean = Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    fun canUninstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 28 || ctx.checkSelfPermission("android.permission.REQUEST_DELETE_PACKAGES") == PackageManager.PERMISSION_GRANTED

    fun openUnknownSourcesSettings(ctx: Context): Boolean = try {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** Opens Android's uninstall confirmation. Returns an error text, or null when the screen was opened. */
    fun openUninstallScreen(ctx: Context, pkg: String): String? = try {
        ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); null
    } catch (e: Exception) { e.message ?: "Android would not open its uninstall screen" }

    /** Every installed app (including system apps, so they can be refused with the right reason). */
    fun installedApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        return try {
            pm.getInstalledApplications(0).map { pm.getApplicationLabel(it).toString() to it.packageName }
        } catch (e: Exception) { emptyList() }
    }

    suspend fun uninstall(ctx: Context, label: String, pkg: String, h: Boolean, confirm: suspend (String) -> Boolean): OpResult {
        fun t(hi: String, en: String) = if (h) hi else en
        if (!isInstalled(ctx, pkg)) return OpResult(TaskStatus.VERIFIED, t("$label is phone me pehle se nahi hai.", "$label is not installed."), "package check")
        when (val v = AppGuard.forUninstall(pkg, label, ctx.packageName, isSystem(ctx, pkg))) {
            is AppVerdict.Refused -> return OpResult(TaskStatus.DENIED, v.reason, "guard")
            AppVerdict.Allowed -> Unit
        }
        if (!canUninstall(ctx)) return OpResult(TaskStatus.FAILED, t("Is build me uninstall ki permission nahi hai.", "This build doesn't hold the uninstall permission."), "permission check")
        if (!confirm(t(
                "$label ($pkg) uninstall karun? Android apni confirmation screen dikhayega, aur app ka data is phone se hat jayega.",
                "Uninstall $label ($pkg)? Android will show its own confirmation, and the app's data on this phone will be deleted."))
        ) return OpResult(TaskStatus.CANCELLED, t("Theek hai, cancel kar diya.", "Okay, cancelled."))
        openUninstallScreen(ctx, pkg)?.let { return OpResult(TaskStatus.FAILED, t("Android ki uninstall screen nahi khul payi: $it", "Android's uninstall screen didn't open: $it"), "system uninstall screen") }
        var i = 0
        while (i < 90) {                       // up to 45 s for the user to confirm in Android
            delay(500); i++
            if (!isInstalled(ctx, pkg)) return OpResult(TaskStatus.VERIFIED, t("$label uninstall ho gaya (check kiya: ab phone me nahi hai).", "$label is uninstalled (checked: it is no longer on the phone)."), "system uninstall screen")
        }
        return OpResult(TaskStatus.NEEDS_USER, t(
            "Maine Android ki uninstall screen khol di, par $label abhi bhi installed hai. Wahan confirm karo (ya cancel ho gaya).",
            "I opened Android's uninstall screen, but $label is still installed. Confirm it there (or it was cancelled)."), "system uninstall screen")
    }

    /** Reads package name, label and version from an APK file. Null when the file is not a readable APK. */
    @Suppress("DEPRECATION")
    fun readApk(ctx: Context, path: String): ApkInfo? = try {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(path, 0)
        val ai = info?.applicationInfo
        if (info == null || ai == null) null else {
            ai.sourceDir = path; ai.publicSourceDir = path
            ApkInfo(info.packageName, pm.getApplicationLabel(ai).toString(), info.versionName ?: "", if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong())
        }
    } catch (e: Exception) { null }

    /** APK files MediaStore shows, newest first. Needs "All files access" for non-media files; otherwise a precise reason. */
    fun findApks(ctx: Context): Pair<List<ApkFile>, String?> {
        val acc = FileAccessPolicy.decide(FileAccess.state(ctx, 0), FileNeed.DOCUMENTS)
        if (acc is Access.Denied) return emptyList<ApkFile>() to acc.reason
        val out = ArrayList<ApkFile>()
        try {
            val uri = MediaStore.Files.getContentUri("external")
            @Suppress("DEPRECATION") val cols = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.DATE_MODIFIED)
            ctx.contentResolver.query(uri, cols, "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?", arrayOf("%.apk"), "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { c ->
                while (c.moveToNext() && out.size < 50) {
                    val id = c.getLong(0)
                    out.add(ApkFile(c.getString(1) ?: continue, android.content.ContentUris.withAppendedId(uri, id), c.getString(2), c.getLong(3)))
                }
            }
        } catch (e: Exception) { return emptyList<ApkFile>() to "Android wouldn't let me list files (${e.javaClass.simpleName})." }
        return out to null
    }

    /**
     * Hands an APK to Android's installer after checking: Nova may install (unknown-sources), the package isn't Nova or a protected app,
     * and asking the user first. Then waits for the package to appear with the new version.
     */
    suspend fun installApk(ctx: Context, uri: Uri, path: String?, name: String, h: Boolean, confirm: suspend (String) -> Boolean): OpResult {
        fun t(hi: String, en: String) = if (h) hi else en
        val info = path?.let { readApk(ctx, it) }
        if (info != null) when (val v = AppGuard.forInstall(info.pkg, info.label, ctx.packageName)) {
            is AppVerdict.Refused -> return OpResult(TaskStatus.DENIED, v.reason, "guard")
            AppVerdict.Allowed -> Unit
        }
        if (!canInstallUnknown(ctx)) {
            openUnknownSourcesSettings(ctx)
            return OpResult(TaskStatus.NEEDS_USER, t(
                "Android ne Nova ko apps install karne ki ijazat nahi di. Maine wo page khol diya: \"Allow from this source\" on karo, phir dobara bolo.",
                "Android hasn't allowed Nova to install apps. I opened that page: turn on \"Allow from this source\" for Nova AI, then ask again."), "install permission")
        }
        val before = info?.let { versionCodeOf(ctx, it.pkg) } ?: -1L
        if (info != null && before >= info.versionCode) return OpResult(TaskStatus.VERIFIED, t("${info.label} ka yahi ya naya version pehle se installed hai.", "${info.label} is already installed at this version or newer."), "package check")
        val what = info?.let { "${it.label} ${it.versionName} (${it.pkg})" } ?: name
        if (!confirm(t("$what, file $name se install karun? Android apni installer screen dikhayega aur tumse poochega.", "Install $what from $name? Android will show its own installer screen and ask you to confirm."))) return OpResult(TaskStatus.CANCELLED, t("Theek hai, cancel kar diya.", "Okay, cancelled."))
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, APK_MIME).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { return OpResult(TaskStatus.FAILED, t("Android ka installer nahi khul paya: ${e.message}", "Android's installer didn't open: ${e.message}"), "system installer") }
        if (info == null) return OpResult(TaskStatus.UNVERIFIED, t(
            "Android ka installer $name ke liye khul gaya. APK ki details padh nahi payi, isliye result check nahi kar sakti.",
            "Android's installer is open for $name. I couldn't read the APK's details, so I can't check the result."), "system installer")
        var i = 0
        while (i < 240) {                      // up to 2 minutes for the user to confirm in Android
            delay(500); i++
            if (versionCodeOf(ctx, info.pkg) >= info.versionCode) return OpResult(TaskStatus.VERIFIED, t("${info.label} install ho gaya (check kiya).", "${info.label} is installed (checked)."), "system installer")
        }
        return OpResult(TaskStatus.NEEDS_USER, t("Installer khula hai par ${info.label} abhi installed nahi hua. Wahan confirm karo (ya cancel ho gaya).", "The installer is open but ${info.label} isn't installed yet. Confirm it there (or it was cancelled)."), "system installer")
    }
}
