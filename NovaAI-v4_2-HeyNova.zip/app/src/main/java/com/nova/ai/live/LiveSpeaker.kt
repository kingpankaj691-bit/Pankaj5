package com.nova.ai.live

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

/**
 * Speaker for the model's 24 kHz mono PCM16 voice.
 *
 * - [play] only queues (never blocks), so the WebSocket thread keeps reading and an "interrupted" message is seen at once.
 * - A dedicated writer thread feeds the AudioTrack in 20 ms slices; the track has ~1 s of buffer and a small pre-buffer before
 *   it starts, which is raised automatically after an underrun.
 * - [flush] (barge-in) drops everything that is queued and everything the track has not played yet.
 * - [pendingMs] / [levelNow] describe what is really still to be heard, so "Nova finished speaking" and the orb follow the
 *   output audio itself, not the moment the chunks arrived.
 */
class LiveSpeaker {
    private class Slice(val bytes: ByteArray, val rms: Float, val gen: Int)

    private val queue = LinkedBlockingQueue<Slice>()
    private val lock = Any()
    @Volatile private var track: AudioTrack? = null
    @Volatile private var thread: Thread? = null
    @Volatile private var alive = false
    @Volatile private var volume = 1f
    @Volatile private var gen = 0
    private val queuedBytes = AtomicLong(0)
    private var framesWritten = 0L          // frames handed to the track since the last flush
    private var headBase = 0L               // track head position right after the last flush
    private var playing = false
    private var preBufferBytes = PREBUFFER_BYTES
    private var lastUnderruns = 0
    /** (cumulative end frame, rms) of the slices already in the track, oldest first. */
    private val levels = java.util.ArrayDeque<Pair<Long, Float>>()

    companion object {
        const val RATE = 24000
        private const val SLICE_BYTES = RATE / 50 * 2            // 20 ms
        private const val PREBUFFER_BYTES = RATE * 2 * 80 / 1000 // 80 ms
        private const val MAX_PREBUFFER_BYTES = RATE * 2 * 300 / 1000

        /** Little-endian PCM16 loudness 0..1. */
        fun rms(b: ByteArray, len: Int = b.size): Float {
            val n = len / 2
            if (n == 0) return 0f
            var sum = 0.0
            for (i in 0 until n) {
                val s = ((b[2 * i + 1].toInt() shl 8) or (b[2 * i].toInt() and 0xFF)).toShort().toInt()
                sum += s.toDouble() * s
            }
            return (sqrt(sum / n) / 32768.0).toFloat().coerceIn(0f, 1f)
        }

        /** Splits PCM into 20 ms slices (pure; unit-tested). The last slice may be shorter. */
        fun slices(pcm: ByteArray): List<ByteArray> {
            if (pcm.isEmpty()) return emptyList()
            val out = ArrayList<ByteArray>(pcm.size / SLICE_BYTES + 1)
            var o = 0
            while (o < pcm.size) {
                val e = minOf(pcm.size, o + SLICE_BYTES)
                out.add(pcm.copyOfRange(o, if ((e - o) % 2 == 1) e - 1 else e).takeIf { it.isNotEmpty() } ?: break)
                o = e
            }
            return out
        }
    }

    /** Queues one chunk (returns at once) and returns its loudness. Safe to call from the WebSocket thread. */
    fun play(pcm: ByteArray): Float {
        if (pcm.isEmpty()) return 0f
        startThread()
        val g = gen
        for (s in slices(pcm)) {
            queuedBytes.addAndGet(s.size.toLong())
            queue.offer(Slice(s, rms(s), g))
        }
        return rms(pcm)
    }

    private fun startThread() {
        if (alive) return
        synchronized(lock) {
            if (alive) return
            alive = true
            val t = Thread({ writerLoop() }, "nova-live-speaker")
            t.isDaemon = true
            thread = t
            t.start()
        }
    }

    private fun writerLoop() {
        while (alive) {
            val slice = try {
                // While the track is still waiting for its pre-buffer, wait at most 40 ms for more data, then start anyway.
                queue.poll(if (!playing && framesWritten > 0) 40L else 200L, TimeUnit.MILLISECONDS)
            } catch (e: InterruptedException) { return }
            if (slice == null) {
                if (!playing && framesWritten > 0) startPlayback()
                continue
            }
            if (queuedBytes.addAndGet(-slice.bytes.size.toLong()) < 0) queuedBytes.set(0)
            if (slice.gen != gen) continue                       // flushed while queued
            val t = ensureTrack() ?: continue
            try {
                var off = 0
                while (off < slice.bytes.size && alive && slice.gen == gen) {
                    val n = t.write(slice.bytes, off, slice.bytes.size - off)
                    if (n <= 0) break
                    off += n
                }
                if (slice.gen == gen) synchronized(lock) {
                    framesWritten += off / 2
                    levels.addLast((headBase + framesWritten) to slice.rms)
                    if (!playing && framesWritten * 2 >= preBufferBytes) startPlayback()
                }
            } catch (e: Exception) { }
            watchUnderruns(t)
        }
    }

    private fun startPlayback() {
        val t = track ?: return
        synchronized(lock) {
            try { t.play(); playing = true } catch (e: Exception) { }
        }
    }

    /** After an underrun the pre-buffer grows (up to 300 ms) so the next turn starts smoother. */
    private fun watchUnderruns(t: AudioTrack) {
        if (Build.VERSION.SDK_INT < 24) return
        val u = try { t.underrunCount } catch (e: Exception) { return }
        if (u > lastUnderruns) {
            lastUnderruns = u
            preBufferBytes = minOf(MAX_PREBUFFER_BYTES, preBufferBytes + RATE * 2 * 60 / 1000)
        }
    }

    @Synchronized
    private fun ensureTrack(): AudioTrack? {
        track?.let { return it }
        return try {
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(maxOf(min * 2, RATE * 2))       // about 1 s: bursts from the server never block the writer for long
                .build()
            t.setVolume(volume)
            synchronized(lock) { headBase = playedFramesOf(t); framesWritten = 0; playing = false; levels.clear() }
            track = t
            t
        } catch (e: Exception) { null }
    }

    private fun playedFramesOf(t: AudioTrack): Long = try { t.playbackHeadPosition.toLong() and 0xFFFFFFFFL } catch (e: Exception) { 0L }

    /** Milliseconds of audio still to be heard (queued + inside the track). 0 when everything has been played. */
    fun pendingMs(): Long {
        val t = track
        val inTrack = synchronized(lock) {
            if (t == null) 0L else {
                val played = playedFramesOf(t)
                if (played < headBase) headBase = played                  // some phones reset the head position on flush
                maxOf(0L, framesWritten - (played - headBase))
            }
        }
        return (queuedBytes.get() / 2 + inTrack) * 1000L / RATE
    }

    /** Loudness 0..1 of the audio that is coming out of the speaker right now. */
    fun levelNow(): Float {
        val t = track ?: return 0f
        synchronized(lock) {
            val played = playedFramesOf(t)
            if (played < headBase) { levels.clear(); headBase = played; return 0f }
            while (levels.size > 1 && levels.first().first <= played) levels.removeFirst()
            val head = levels.firstOrNull() ?: return 0f
            if (head.first <= played && queue.isEmpty()) { levels.clear(); return 0f }
            return head.second
        }
    }

    /** Barge-in: forget everything queued and everything the track has not played yet. */
    fun flush() {
        gen++
        queue.clear(); queuedBytes.set(0)
        val t = track ?: return
        synchronized(lock) {
            try { t.pause(); t.flush() } catch (e: Exception) { }
            headBase = playedFramesOf(t); framesWritten = 0; playing = false; levels.clear()
        }
    }

    fun setVolume(v: Float) { volume = v.coerceIn(0f, 1f); track?.setVolume(volume) }

    fun underruns(): Int = if (Build.VERSION.SDK_INT >= 24) try { track?.underrunCount ?: 0 } catch (e: Exception) { 0 } else 0

    fun release() {
        alive = false
        gen++
        queue.clear(); queuedBytes.set(0)
        thread?.interrupt(); thread = null
        val t = synchronized(this) { val x = track; track = null; x }
        synchronized(lock) { framesWritten = 0; headBase = 0; playing = false; levels.clear(); lastUnderruns = 0; preBufferBytes = PREBUFFER_BYTES }
        if (t != null) { try { t.pause() } catch (e: Exception) { }; try { t.flush() } catch (e: Exception) { }; try { t.release() } catch (e: Exception) { } }
    }
}
