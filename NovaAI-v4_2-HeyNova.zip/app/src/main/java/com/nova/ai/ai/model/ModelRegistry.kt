package com.nova.ai.ai.model

import android.content.Context
import com.nova.ai.ai.ModelCatalog
import com.nova.ai.ai.net.GeminiError
import com.nova.ai.ai.net.GeminiErrorKind
import com.nova.ai.ai.net.GeminiRestClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Every Gemini model the user's key can see, discovered from Google's own model-list endpoint (nothing is hardcoded),
 * with each model's supported methods turned into [ModelCapabilities]. The last good list is cached on the phone, so
 * model selection, routing and the notification still work offline. New Google models appear after a refresh.
 */
class ModelRegistry(ctx: Context, private val client: GeminiRestClient = GeminiRestClient.shared) {
    private val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _models = MutableStateFlow<List<GeminiModel>>(emptyList())
    val models: StateFlow<List<GeminiModel>> get() = _models
    val refreshing = MutableStateFlow(false)
    val lastError = MutableStateFlow("")
    val lastUpdated = MutableStateFlow(0L)

    companion object {
        private const val PREFS = "nova_models"
        private const val KEY_LIST = "list_json"
        private const val KEY_TIME = "list_time"
        const val STALE_AFTER_MS = 12L * 60 * 60 * 1000
    }

    init {
        try {
            val raw = sp.getString(KEY_LIST, null)
            if (!raw.isNullOrBlank()) {
                _models.value = ModelListParser.parsePage(raw).models.sortedWith(ModelSort.comparator)
                lastUpdated.value = sp.getLong(KEY_TIME, 0L)
            }
        } catch (e: Exception) { /* a damaged cache is simply ignored; the next refresh replaces it */ }
    }

    fun find(id: String): GeminiModel? {
        val clean = id.removePrefix("models/")
        return _models.value.firstOrNull { it.id == clean }
    }

    fun isLoaded(): Boolean = _models.value.isNotEmpty()

    fun isStale(now: Long = System.currentTimeMillis()): Boolean = !isLoaded() || now - lastUpdated.value > STALE_AFTER_MS

    /**
     * Fetches the list from Google. On failure the cached list is kept and [lastError] says why
     * (invalid key, no internet, ...). Returns true when a fresh list was stored.
     */
    suspend fun refresh(apiKey: String): Boolean {
        if (apiKey.isBlank()) { lastError.value = GeminiError(GeminiErrorKind.NO_KEY).userMessage(); return false }
        if (!refreshing.compareAndSet(false, true)) return false
        try {
            return when (val r = client.listModels(apiKey)) {
                is GeminiRestClient.ListResult.Ok -> {
                    if (r.models.isEmpty()) { lastError.value = "Google returned an empty model list."; false }
                    else {
                        val sorted = r.models.sortedWith(ModelSort.comparator)
                        _models.value = sorted
                        val now = System.currentTimeMillis()
                        lastUpdated.value = now
                        lastError.value = ""
                        sp.edit().putString(KEY_LIST, ModelListParser.toJson(sorted)).putLong(KEY_TIME, now).apply()
                        true
                    }
                }
                is GeminiRestClient.ListResult.Fail -> { lastError.value = r.error.userMessage(); false }
            }
        } finally {
            refreshing.value = false
        }
    }

    /** The built-in offline lists (ModelCatalog), shown only until the first successful refresh. They are NOT verified against Google. */
    fun offlineSeed(): List<GeminiModel> =
        (ModelCatalog.chat + ModelCatalog.live + ModelCatalog.tts)
            .distinctBy { it.id }
            .map { GeminiModel(id = it.id, displayName = it.label, verified = false) }
}
