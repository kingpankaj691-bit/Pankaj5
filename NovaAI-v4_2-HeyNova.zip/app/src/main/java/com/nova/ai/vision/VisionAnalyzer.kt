package com.nova.ai.vision

import android.util.Base64
import com.nova.ai.ai.GeminiHttp
import com.nova.ai.screen.ActionValidator
import com.nova.ai.security.Prefs
import org.json.JSONArray
import org.json.JSONObject

data class Located(val label: String, val x: Int, val y: Int, val confidence: Float)

/** Sends one screenshot to Gemini for understanding. Used only after the user asked a visual question. */
class VisionAnalyzer(private val prefs: Prefs) {

    fun blocked(frame: ScreenFrame): String? = when {
        prefs.localOnly -> "Local-only mode is on, so I won't send the screen anywhere."
        !prefs.visionOn -> "Screen vision is switched off in Privacy & Security."
        prefs.apiKey.isBlank() -> "Screen vision needs a Gemini API key."
        ActionValidator.packageBlocked(frame.pkg) -> "I don't look at payment, banking or password apps."
        else -> null
    }

    private fun imagePart(frame: ScreenFrame) = JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(frame.jpeg(), Base64.NO_WRAP)))

    suspend fun describe(frame: ScreenFrame, question: String, languageHint: String): String {
        blocked(frame)?.let { return it }
        val system = "You describe an Android phone screenshot for a voice assistant. Say only what is visible. Do not guess hidden content or read out passwords, OTPs or card numbers. " +
            "Short, plain text, no markdown. $languageHint"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", question)).put(imagePart(frame)))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", prefs.maxTokens.coerceAtLeast(500)))
        val out = GeminiHttp.post(prefs, body)
        val j = out.json ?: return "⚠ " + (out.error ?: "Vision failed.")
        return GeminiHttp.textOf(j).ifBlank { "I couldn't understand this screenshot." }
    }

    /** Asks Gemini where a visual element is. Returns null when it can't find it with reasonable confidence. */
    suspend fun locate(frame: ScreenFrame, query: String): Pair<Located?, String?> {
        blocked(frame)?.let { return null to it }
        val prompt = "Find this UI element in the screenshot: \"$query\". Reply with JSON only: " +
            "{\"found\":true|false,\"label\":\"short description\",\"box\":[ymin,xmin,ymax,xmax],\"confidence\":0.0-1.0} " +
            "where box uses a 0-1000 scale relative to the image. If several equally good matches exist or you are unsure, set found=false."
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)).put(imagePart(frame)))))
            .put("generationConfig", JSONObject().put("temperature", 0.0).put("maxOutputTokens", 300).put("responseMimeType", "application/json"))
        val out = GeminiHttp.post(prefs, body)
        val j = out.json ?: return null to ("⚠ " + (out.error ?: "Vision failed."))
        return try {
            val raw = GeminiHttp.textOf(j).replace("```json", "").replace("```", "").trim()
            val o = JSONObject(raw)
            if (!o.optBoolean("found", false)) return null to null
            val b = o.getJSONArray("box")
            val ymin = b.getDouble(0); val xmin = b.getDouble(1); val ymax = b.getDouble(2); val xmax = b.getDouble(3)
            val conf = o.optDouble("confidence", 0.0).toFloat()
            val x = (((xmin + xmax) / 2.0) / 1000.0 * frame.screenWidth).toInt().coerceIn(0, frame.screenWidth - 1)
            val y = (((ymin + ymax) / 2.0) / 1000.0 * frame.screenHeight).toInt().coerceIn(0, frame.screenHeight - 1)
            if (conf < 0.55f) null to null else Located(o.optString("label", query), x, y, conf) to null
        } catch (e: Exception) { null to null }
    }
}
