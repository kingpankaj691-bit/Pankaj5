package com.nova.ai.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.nova.ai.core.PermissionManager

data class PermItem(val name: String, val why: String, val perms: List<String>, val required: Boolean = false, val anyOf: Boolean = false) {
    private fun ok(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    /** [anyOf]: one granted permission is enough (e.g. approximate location). Otherwise every one is needed. */
    fun granted(ctx: Context) = if (anyOf) perms.any { ok(ctx, it) } else perms.all { ok(ctx, it) }
}

object NovaPermissions {
    fun all(): List<PermItem> {
        val l = mutableListOf<PermItem>()
        l.add(PermItem("Microphone", "Push-to-talk and Background Voice (continuous listening while you have it switched on).", listOf(Manifest.permission.RECORD_AUDIO), true))
        if (Build.VERSION.SDK_INT >= 33)
            l.add(PermItem("Notifications", "Shows the \"microphone is on\" notification that must stay visible while Background Voice runs.", listOf(Manifest.permission.POST_NOTIFICATIONS), true))
        l.add(PermItem("Phone", "Place calls and read call state.", listOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)))
        l.add(PermItem("Answer calls", "Lets you say \"uthao\" or \"kaat do\" while the phone rings (only when you enable it in Jarvis settings).", listOf(Manifest.permission.ANSWER_PHONE_CALLS)))
        l.add(PermItem("Send SMS", "Emergency SOS: sends your location to your emergency contacts (only after you say help me and don't cancel).", listOf(Manifest.permission.SEND_SMS)))
        l.add(PermItem("Contacts", "Resolve names like \"call Mom\".", listOf(Manifest.permission.READ_CONTACTS)))
        l.add(PermItem("Call logs", "Answer questions about recent calls.", listOf(Manifest.permission.READ_CALL_LOG)))
        l.add(PermItem("SMS", "Read messages when you ask.", listOf(Manifest.permission.READ_SMS)))
        l.add(PermItem("Calendar", "Tell you about upcoming events.", listOf(Manifest.permission.READ_CALENDAR)))
        l.add(PermItem("Camera", "Camera features.", listOf(Manifest.permission.CAMERA)))
        l.add(PermItem("Location", "Location-aware answers (optional).", listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), anyOf = true))
        if (Build.VERSION.SDK_INT >= 31)
            l.add(PermItem("Nearby devices", "Bluetooth status, scanning and connecting.", listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)))
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(PermItem("Photos and videos", "Find and open your media.", listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)))
            l.add(PermItem("Music and audio", "Find and open your audio files.", listOf(Manifest.permission.READ_MEDIA_AUDIO)))
        } else {
            l.add(PermItem("Photos, videos and audio", "Find and open your media.", listOf(Manifest.permission.READ_EXTERNAL_STORAGE)))
        }
        return l
    }
}

class AndroidPermissionManager(private val ctx: Context) : PermissionManager {
    override fun novaPermissions(): List<PermItem> = NovaPermissions.all()
    override fun isGranted(p: PermItem): Boolean = p.granted(ctx)
}
