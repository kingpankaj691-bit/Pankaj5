package com.nova.ai.scanner

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.pm.PackageInfoCompat
import com.nova.ai.core.AppManager

/** Only sees apps that Android's package-visibility rules expose to Nova (launchable apps + declared queries). */
class AndroidAppManager(private val ctx: Context) : AppManager {
    private val pm = ctx.packageManager

    @Suppress("DEPRECATION")
    override fun inventory(): List<AppInfo> {
        val out = mutableListOf<AppInfo>()
        for (pi in pm.getInstalledPackages(0)) {
            try {
                val ai = pi.applicationInfo ?: continue
                val pkg = pi.packageName
                val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val label = pm.getApplicationLabel(ai).toString()
                out.add(AppInfo(
                    label, pkg, pi.versionName ?: "?", PackageInfoCompat.getLongVersionCode(pi),
                    pi.firstInstallTime, pi.lastUpdateTime, installer(pkg),
                    pm.getLaunchIntentForPackage(pkg) != null, categorize(label, pkg, ai, system)
                ))
            } catch (e: Exception) { }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun installer(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    private fun categorize(label: String, pkg: String, ai: ApplicationInfo, system: Boolean): String {
        val s = (pkg + " " + label).lowercase()
        fun any(vararg k: String) = k.any { s.contains(it) }
        if (ai.category == ApplicationInfo.CATEGORY_GAME) return "Games"
        if (any("termux", "github", "studio", "androidide", "jetbrains", "vscode", "developer")) return "Development"
        if (ai.category == ApplicationInfo.CATEGORY_SOCIAL || any("whatsapp", "telegram", "instagram", "facebook", "snapchat", "twitter", "reddit", "linkedin", "discord")) return "Social"
        if (any("dialer", "messag", "mms", "gmail", ".mail", "contacts", "signal", "skype", "meet", "zoom")) return "Communication"
        if (ai.category == ApplicationInfo.CATEGORY_AUDIO || ai.category == ApplicationInfo.CATEGORY_VIDEO || ai.category == ApplicationInfo.CATEGORY_IMAGE ||
            any("youtube", "spotify", "netflix", "music", "video", "player", "photos", "gallery", "camera")) return "Media"
        if (any("game", "pubg", "minecraft", "roblox", "clash")) return "Games"
        if (any("classroom", "duolingo", "edu", "learn", "course", "khan", "byju", "unacademy")) return "Education"
        if (ai.category == ApplicationInfo.CATEGORY_PRODUCTIVITY || any("docs", "sheets", "slides", "office", "notes", "keep", "calendar", "drive", "onenote", "notion")) return "Productivity"
        if (any("calculator", "clock", "files", "filemanager", "settings", "flashlight", "torch", "scanner", "compass", "weather")) return "Tools"
        return if (system) "System" else "Other"
    }

    override fun launch(pkg: String): Boolean = try {
        val i = pm.getLaunchIntentForPackage(pkg)
        if (i == null) false else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true }
    } catch (e: Exception) { false }

    /** "supported" = Android reports a handler. A launch can still be rejected; callers must check the result. */
    override fun capabilityMap(): List<Capability> {
        fun can(i: Intent) = try { pm.resolveActivity(i, 0) != null } catch (e: Exception) { false }
        val labels = inventory().map { it.name.lowercase() }
        return listOf(
            Capability("YouTube", "Launch app", labels.any { it.contains("youtube") }),
            Capability("Browser", "Open URL", can(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")))),
            Capability("Camera", "Launch camera", can(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))),
            Capability("Gallery", "Open media", can(Intent(Intent.ACTION_VIEW).setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*"))),
            Capability("Files", "Open file picker", can(Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE))),
            Capability("Maps", "Open maps", can(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))),
            Capability("Play Store", "Open store", can(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=")))),
            Capability("Dialer", "Open dialer", can(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))),
            Capability("Settings", "Open settings", can(Intent(Settings.ACTION_SETTINGS)))
        )
    }
}
