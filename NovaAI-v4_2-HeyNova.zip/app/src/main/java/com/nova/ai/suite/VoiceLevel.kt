package com.nova.ai.suite

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.sqrt

/** Microphone loudness 0..1, computed from the audio Nova is already recording (no second microphone session). Updated ~12 times a second. */
object VoiceLevel {
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level
    private var last = 0L

    /** [buf] holds 16-bit little-endian mono PCM. Looks at every 4th sample to stay cheap. */
    fun feed(buf: ByteArray, n: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - last < 80) return
        last = now
        var sum = 0.0; var c = 0; var i = 0
        while (i + 1 < n) {
            val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s; c++; i += 8
        }
        val rms = if (c == 0) 0.0 else sqrt(sum / c)
        _level.value = (rms / 6000.0).coerceIn(0.0, 1.0).toFloat()
    }

    fun reset() { _level.value = 0f }
}

/** Online/offline for the orb's connection dot. One default-network callback, registered only while the orb is shown. */
object NetState {
    @Volatile var online = true
        private set
    private var cb: ConnectivityManager.NetworkCallback? = null

    fun start(ctx: Context, onChange: () -> Unit) {
        if (cb != null) return
        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        online = cm.activeNetwork != null
        val c = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { online = true; onChange() }
            override fun onLost(network: Network) { online = false; onChange() }
        }
        try { cm.registerDefaultNetworkCallback(c); cb = c } catch (e: Exception) { }
    }

    fun stop(ctx: Context) {
        val c = cb ?: return
        try { (ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(c) } catch (e: Exception) { }
        cb = null
    }
}
