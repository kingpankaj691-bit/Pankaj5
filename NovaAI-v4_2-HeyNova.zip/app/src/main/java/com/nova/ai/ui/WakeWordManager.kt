package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.jarvis.Deva
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.jarvis.WakePhrases

/**
 * "Add My Own Wake Words": every phrase (built-in or yours) can be switched on or off, one can be the default, yours can be edited
 * and deleted, and built-in ones can be customized (a copy you can edit replaces them). Every change is saved to JarvisPrefs at once
 * and [onChanged] makes the running wake engine rebuild its recognizers (see WakeVocab / WakeGateEngine), so a saved phrase is
 * a phrase the engine listens for, not just text. [plan] says which phrases the installed offline models can really recognize.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WakeWordManager(jp: JarvisPrefs, name: String, plan: WakePhrases.Plan?, onChanged: () -> Unit) {
    val g = LocalGlass.current
    var ids by remember { mutableStateOf(WakePhrases.parseIds(jp.wakePhraseIds)) }
    var custom by remember { mutableStateOf(jp.customPhrases) }
    var defId by remember { mutableStateOf(jp.defaultPhraseId) }
    var selected by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }       // null = adding; "c:text" = editing yours; "copy:id" = customizing a built-in
    var input by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val catalog = remember(name, custom) { WakePhrases.catalog(name, custom) { Deva.variants(it) } }
    val def = if (catalog.any { it.id == defId }) defId else "hey_nova"

    fun isOn(p: WakePhrases.Phrase) = p.id == def || (if (p.custom) p.on else p.id in ids)
    fun saveIds(v: List<String>) { ids = v; jp.wakePhraseIds = WakePhrases.joinIds(v); onChanged() }
    fun saveCustom(v: String) { custom = v; jp.customPhrases = v; onChanged() }
    fun saveDefault(id: String) { defId = id; jp.defaultPhraseId = id; onChanged() }

    GText("Add My Own Wake Words", size = 13.sp)
    GText("Each phrase is recognized on this phone by the offline English or Hindi model. Tap a phrase for more options. Changes apply by themselves in a moment (the microphone is re-opened once).", size = 12.sp, color = g.subtext)

    catalog.forEach { ph ->
        val on = isOn(ph)
        val status = when {
            !on -> "off"
            plan == null -> "checking…"
            plan.unavailable[ph.id] != null -> "not available: " + plan.unavailable[ph.id] + (if (ph.custom) ". Try another spelling, or type it in Devanagari." else "")
            else -> "ready (" + WakePhrases.modelLabel(plan.modelFor(ph.id) ?: WakePhrases.EN) + " model)"
        }
        GlassListItem(ph.label + (if (ph.id == def) "  ·  default" else ""), status, onClick = { selected = if (selected == ph.id) "" else ph.id }, trailing = {
            GlassSwitch(on) { v ->
                if (ph.id == def && !v) note = "The default phrase stays on. Choose another default first."
                else { note = ""; if (ph.custom) saveCustom(WakePhrases.setCustomEnabled(custom, ph.id, v)) else saveIds(if (v) ids + ph.id else ids - ph.id) }
            }
        })
        if (selected == ph.id) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ph.id != def) GlassChip("Set as default", false, {
                    if (ph.custom) custom = WakePhrases.setCustomEnabled(custom, ph.id, true).also { jp.customPhrases = it } else if (ph.id !in ids) { ids = ids + ph.id; jp.wakePhraseIds = WakePhrases.joinIds(ids) }
                    saveDefault(ph.id)
                })
                GlassChip(if (ph.custom) "Edit" else "Customize", false, { editing = if (ph.custom) ph.id else "copy:" + ph.id; input = ph.forms.first().text; err = ""; note = "" })
                if (ph.custom) GlassChip("Delete", false, {
                    saveCustom(WakePhrases.removeCustom(custom, ph.id))
                    if (def == ph.id) saveDefault("hey_nova")
                    selected = ""
                })
            }
        }
    }
    if (note.isNotBlank()) GText(note, size = 12.sp, color = g.accent)

    GText(if (editing == null) "Add a phrase (Hindi, English or Hinglish, at least two words), e.g. \"meri jaan\", \"jaan suno\", \"nova listen\":" else "Edit phrase:", size = 12.sp, color = g.subtext)
    GlassTextField(input, { input = it; err = "" }, Modifier.fillMaxWidth(), placeholder = "Your wake phrase")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton(if (editing == null) "Add phrase" else "Save phrase", {
            val e = editing
            val except = if (e != null && e.startsWith("copy:")) e.removePrefix("copy:") else e
            val problem = WakePhrases.checkCustom(catalog, input, except)
            if (problem != null) err = problem
            else {
                val newId = "c:" + WakePhrases.norm(input)
                when {
                    e == null -> saveCustom(WakePhrases.addCustom(custom, input))
                    e.startsWith("copy:") -> {                       // customize a built-in: your copy replaces it
                        val old = e.removePrefix("copy:")
                        saveCustom(WakePhrases.addCustom(custom, input))
                        saveIds(ids - old)
                        if (def == old) saveDefault(newId)
                    }
                    else -> {
                        saveCustom(WakePhrases.editCustom(custom, e, input))
                        if (def == e) saveDefault(newId)
                    }
                }
                editing = null; input = ""; err = ""; selected = ""
            }
        }, enabled = input.isNotBlank())
        if (editing != null) GlassButton("Cancel", { editing = null; input = ""; err = "" })
    }
    if (err.isNotBlank()) GText(err, size = 12.sp, color = g.accent)
    GText("Protection against false activation: phrases need two or more distinctive words, duplicates and everyday-word phrases are refused, and the recognizer only wakes Nova for a clear, confident match of the whole phrase.", size = 12.sp, color = g.subtext)
}
