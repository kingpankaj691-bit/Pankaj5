package com.nova.ai.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class Prefs(ctx: Context) {
    private val plain: SharedPreferences = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)
    private val secure: SharedPreferences? = try {
        EncryptedSharedPreferences.create(
            ctx, "nova_secure",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) { null }
    private var memoryOnlyKey = ""

    // API key is only ever stored encrypted (or kept in RAM if encryption is unavailable).
    var apiKey: String
        get() = secure?.getString("api_key", "") ?: memoryOnlyKey
        set(v) { if (secure != null) secure.edit().putString("api_key", v).apply() else memoryOnlyKey = v }

    var model: String
        get() = com.nova.ai.ai.ModelCatalog.clean(plain.getString("model", null), com.nova.ai.ai.ModelCatalog.DEFAULT_CHAT)
        set(v) = plain.edit().putString("model", com.nova.ai.ai.ModelCatalog.clean(v, com.nova.ai.ai.ModelCatalog.DEFAULT_CHAT)).apply()
    /** The model the user marked as default ("Use default" in Settings → Gemini). Blank = none chosen. Never applied silently. */
    var defaultModel: String
        get() = if ((plain.getString("default_model", "") ?: "").isBlank()) "" else com.nova.ai.ai.ModelCatalog.clean(plain.getString("default_model", ""), "")
        set(v) = plain.edit().putString("default_model", if (v.isBlank()) "" else com.nova.ai.ai.ModelCatalog.clean(v, "")).apply()
    var temperature: Float
        get() = plain.getFloat("temp", 0.8f)
        set(v) = plain.edit().putFloat("temp", v).apply()
    var aiEnabled: Boolean
        get() = plain.getBoolean("ai_on", true)
        set(v) = plain.edit().putBoolean("ai_on", v).apply()
    // ── AI provider selection (Gemini or OpenAI) ──
    var aiProvider: String
        get() = plain.getString("ai_provider", PROVIDER_GEMINI) ?: PROVIDER_GEMINI
        set(v) = plain.edit().putString("ai_provider", v).apply()
    var geminiEnabled: Boolean
        get() = plain.getBoolean("gemini_on", true)
        set(v) = plain.edit().putBoolean("gemini_on", v).apply()
    var openAiEnabled: Boolean
        get() = plain.getBoolean("openai_on", true)
        set(v) = plain.edit().putBoolean("openai_on", v).apply()
    var openAiModel: String
        get() = plain.getString("openai_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        set(v) = plain.edit().putString("openai_model", v.trim()).apply()
    /** Stored encrypted like the Gemini key; never in source or plain prefs. */
    var openAiKey: String
        get() = secret("openai_key")
        set(v) = setSecret("openai_key", v)
    /** True when the selected provider has a key saved. */
    fun hasActiveKey(): Boolean = if (aiProvider == PROVIDER_OPENAI) openAiKey.isNotBlank() else apiKey.isNotBlank()

    companion object {
        const val PROVIDER_GEMINI = "gemini"
        const val PROVIDER_OPENAI = "openai"
    }

    // ── Part 2: device alerts, night mode, editing mode ──
    var batteryAlerts: Boolean
        get() = plain.getBoolean("bat_alerts", false)
        set(v) = plain.edit().putBoolean("bat_alerts", v).apply()
    var batteryLowPct: Int
        get() = plain.getInt("bat_low", 20)
        set(v) = plain.edit().putInt("bat_low", v.coerceIn(10, 50)).apply()
    var batteryCritPct: Int
        get() = plain.getInt("bat_crit", 10)
        set(v) = plain.edit().putInt("bat_crit", v.coerceIn(3, 20)).apply()
    var batteryFullAlert: Boolean
        get() = plain.getBoolean("bat_full", true)
        set(v) = plain.edit().putBoolean("bat_full", v).apply()
    var tempAlerts: Boolean
        get() = plain.getBoolean("temp_alerts", false)
        set(v) = plain.edit().putBoolean("temp_alerts", v).apply()
    var tempWarnC: Int
        get() = plain.getInt("temp_warn", 40)
        set(v) = plain.edit().putInt("temp_warn", v.coerceIn(35, 50)).apply()
    var tempCritC: Int
        get() = plain.getInt("temp_crit", 45)
        set(v) = plain.edit().putInt("temp_crit", v.coerceIn(40, 55)).apply()
    /** Bitmask of alerts already fired, so each one fires once per crossing. */
    var alertState: Int
        get() = plain.getInt("alert_state", 0)
        set(v) = plain.edit().putInt("alert_state", v).apply()
    var nightScheduleOn: Boolean
        get() = plain.getBoolean("night_sched", false)
        set(v) = plain.edit().putBoolean("night_sched", v).apply()
    var nightActive: Boolean
        get() = plain.getBoolean("night_active", false)
        set(v) = plain.edit().putBoolean("night_active", v).apply()
    var nightStart: String
        get() = plain.getString("night_start", "22:00") ?: "22:00"
        set(v) = plain.edit().putString("night_start", v).apply()
    var nightEnd: String
        get() = plain.getString("night_end", "06:00") ?: "06:00"
        set(v) = plain.edit().putString("night_end", v).apply()
    var nightPrevVolume: Float
        get() = plain.getFloat("night_prev_vol", 1f)
        set(v) = plain.edit().putFloat("night_prev_vol", v).apply()
    var nightPrevTheme: String
        get() = plain.getString("night_prev_theme", "dark") ?: "dark"
        set(v) = plain.edit().putString("night_prev_theme", v).apply()
    var editingActive: Boolean
        get() = plain.getBoolean("edit_active", false)
        set(v) = plain.edit().putBoolean("edit_active", v).apply()
    var editingPrevProactive: Boolean
        get() = plain.getBoolean("edit_prev_pro", true)
        set(v) = plain.edit().putBoolean("edit_prev_pro", v).apply()
    /** Package of the editing app Nova may open (blank = none). */
    var editingApp: String
        get() = plain.getString("edit_app", "") ?: ""
        set(v) = plain.edit().putString("edit_app", v).apply()
    var editingTemplate: String
        get() = plain.getString("edit_tpl", "Title:\nDescription:\nTags:\nTimestamps:\nLinks:") ?: ""
        set(v) = plain.edit().putString("edit_tpl", v).apply()
    var editingDays: String
        get() = plain.getString("edit_days", "") ?: ""
        set(v) = plain.edit().putString("edit_days", v).apply()
    var editingTime: String
        get() = plain.getString("edit_time", "18:00") ?: "18:00"
        set(v) = plain.edit().putString("edit_time", v).apply()
    var editingRoutineId: Long
        get() = plain.getLong("edit_rid", 0L)
        set(v) = plain.edit().putLong("edit_rid", v).apply()

    // ── Part 3: Security Mode (motion / pick-up alert) ──
    /** True while the user wants Security Mode armed. Cleared on reboot, so nothing re-arms silently. */
    var securityModeOn: Boolean
        get() = plain.getBoolean("secmode_on", false)
        set(v) = plain.edit().putBoolean("secmode_on", v).apply()
    /** "low", "medium" or "high". */
    var secSensitivity: String
        get() = plain.getString("sec_sens", "medium") ?: "medium"
        set(v) = plain.edit().putString("sec_sens", v).apply()
    var secUseGyro: Boolean
        get() = plain.getBoolean("sec_gyro", true)
        set(v) = plain.edit().putBoolean("sec_gyro", v).apply()
    var secArmDelaySec: Int
        get() = plain.getInt("sec_arm_delay", 10)
        set(v) = plain.edit().putInt("sec_arm_delay", v.coerceIn(5, 30)).apply()
    var secCooldownSec: Int
        get() = plain.getInt("sec_cooldown", 30)
        set(v) = plain.edit().putInt("sec_cooldown", v.coerceIn(10, 120)).apply()
    var secAlarmSec: Int
        get() = plain.getInt("sec_alarm_len", 20)
        set(v) = plain.edit().putInt("sec_alarm_len", v.coerceIn(5, 60)).apply()
    var secWarning: String
        get() = plain.getString("sec_warning", "Warning! Keep the phone down.") ?: "Warning! Keep the phone down."
        set(v) = plain.edit().putString("sec_warning", v.take(120)).apply()
    var secAlarmSound: Boolean
        get() = plain.getBoolean("sec_sound", true)
        set(v) = plain.edit().putBoolean("sec_sound", v).apply()
    var secSpeak: Boolean
        get() = plain.getBoolean("sec_speak", true)
        set(v) = plain.edit().putBoolean("sec_speak", v).apply()
    /** Turning Security Mode off from Nova's screen needs fingerprint or screen lock. */
    var secDisarmBio: Boolean
        get() = plain.getBoolean("sec_disarm_bio", true)
        set(v) = plain.edit().putBoolean("sec_disarm_bio", v).apply()
    /** Sound the alarm after 3 failed fingerprint/screen-lock attempts inside Nova within 5 minutes. */
    var secFailAlarm: Boolean
        get() = plain.getBoolean("sec_fail_alarm", false)
        set(v) = plain.edit().putBoolean("sec_fail_alarm", v).apply()
    /** JSON list of local security events (max 50). Stays on this phone. */
    var securityEvents: String
        get() = plain.getString("sec_events", "[]") ?: "[]"
        set(v) = plain.edit().putString("sec_events", v).apply()

    // ── Part 4 ──
    /** Let the AI propose a device action as JSON. Nova validates it and runs it through the normal confirm/lock path. */
    var structuredActions: Boolean
        get() = plain.getBoolean("structured_actions", false)
        set(v) = plain.edit().putBoolean("structured_actions", v).apply()
    /** HTTPS address of the update metadata JSON you host (blank = updates off). */
    var updateUrl: String
        get() = plain.getString("update_url", "") ?: ""
        set(v) = plain.edit().putString("update_url", v).apply()

    var personality: String
        get() = plain.getString("persona", "Normal") ?: "Normal"
        set(v) = plain.edit().putString("persona", v).apply()
    var customPersonality: String
        get() = plain.getString("persona_custom", "") ?: ""
        set(v) = plain.edit().putString("persona_custom", v).apply()
    var memoryEnabled: Boolean
        get() = plain.getBoolean("mem_on", true)
        set(v) = plain.edit().putBoolean("mem_on", v).apply()
    var language: String
        get() = plain.getString("lang", "auto") ?: "auto"
        set(v) = plain.edit().putString("lang", v).apply()
    var speed: Float
        get() = plain.getFloat("speed", 1.0f)
        set(v) = plain.edit().putFloat("speed", v).apply()
    var pitch: Float
        get() = plain.getFloat("pitch", 1.1f)
        set(v) = plain.edit().putFloat("pitch", v).apply()
    var speakReplies: Boolean
        get() = plain.getBoolean("speak", true)
        set(v) = plain.edit().putBoolean("speak", v).apply()

    var themeMode: String
        get() = plain.getString("theme", "dark") ?: "dark"
        set(v) = plain.edit().putString("theme", v).apply()
    var accent: Int
        get() = plain.getInt("accent", 0xFF4FC3F7.toInt())
        set(v) = plain.edit().putInt("accent", v).apply()
    var blurLevel: Int
        get() = plain.getInt("blur", 1)
        set(v) = plain.edit().putInt("blur", v).apply()
    var transparency: Int
        get() = plain.getInt("transp", 1)
        set(v) = plain.edit().putInt("transp", v).apply()
    var reducedMotion: Boolean
        get() = plain.getBoolean("reduced", false)
        set(v) = plain.edit().putBoolean("reduced", v).apply()
    var devMode: Boolean
        get() = plain.getBoolean("dev_mode", false)
        set(v) = plain.edit().putBoolean("dev_mode", v).apply()
    var codeFormatting: Boolean
        get() = plain.getBoolean("dev_fmt", true)
        set(v) = plain.edit().putBoolean("dev_fmt", v).apply()
    var autoExplain: Boolean
        get() = plain.getBoolean("dev_explain", true)
        set(v) = plain.edit().putBoolean("dev_explain", v).apply()
    var debugMode: Boolean
        get() = plain.getBoolean("dev_debug", false)
        set(v) = plain.edit().putBoolean("dev_debug", v).apply()
    var devModel: String
        get() = if ((plain.getString("dev_model", "") ?: "").isBlank()) "" else com.nova.ai.ai.ModelCatalog.clean(plain.getString("dev_model", ""), "")
        set(v) = plain.edit().putString("dev_model", if (v.isBlank()) "" else com.nova.ai.ai.ModelCatalog.clean(v, "")).apply()

    var systemPromptExtra: String
        get() = plain.getString("sys_extra", "") ?: ""
        set(v) = plain.edit().putString("sys_extra", v).apply()
    var contextTurns: Int
        get() = plain.getInt("ctx_turns", 12)
        set(v) = plain.edit().putInt("ctx_turns", v).apply()
    var moodOverride: String
        get() = plain.getString("mood_override", "Auto") ?: "Auto"
        set(v) = plain.edit().putString("mood_override", v).apply()
    var ttsVolume: Float
        get() = plain.getFloat("tts_vol", 1f)
        set(v) = plain.edit().putFloat("tts_vol", v).apply()
    var ttsVoice: String
        get() = plain.getString("tts_voice", "") ?: ""
        set(v) = plain.edit().putString("tts_voice", v).apply()
    var confirmLevel: String
        get() = plain.getString("confirm", "sensitive") ?: "sensitive"
        set(v) = plain.edit().putString("confirm", v).apply()
    var proactive: Boolean
        get() = plain.getBoolean("proactive", true)
        set(v) = plain.edit().putBoolean("proactive", v).apply()
    var avatarStyle: String
        get() = plain.getString("avatar", "avatar") ?: "avatar"
        set(v) = plain.edit().putString("avatar", v).apply()
    var material: Int
        get() = plain.getInt("material", 0)
        set(v) = plain.edit().putInt("material", v).apply()
    var notifAllowed: Set<String>
        get() = HashSet(plain.getStringSet("notif_allowed", emptySet()) ?: emptySet())
        set(v) = plain.edit().putStringSet("notif_allowed", HashSet(v)).apply()

    var bgEnabled: Boolean
        get() = plain.getBoolean("bg_enabled", false)
        set(v) = plain.edit().putBoolean("bg_enabled", v).apply()
    var lastBootInit: Long
        get() = plain.getLong("last_boot_init", 0L)
        set(v) = plain.edit().putLong("last_boot_init", v).apply()
    var wakeEnabled: Boolean
        get() = plain.getBoolean("wake_enabled", true)
        set(v) = plain.edit().putBoolean("wake_enabled", v).apply()
    var memoryExpiryDays: Int
        get() = plain.getInt("mem_expiry_days", 180)
        set(v) = plain.edit().putInt("mem_expiry_days", v).apply()
    var saveChats: Boolean
        get() = plain.getBoolean("save_chats", true)
        set(v) = plain.edit().putBoolean("save_chats", v).apply()
    var smartCompression: Boolean
        get() = plain.getBoolean("smart_compress", true)
        set(v) = plain.edit().putBoolean("smart_compress", v).apply()
    var ownerMode: Boolean
        get() = plain.getBoolean("owner_mode", false)
        set(v) = plain.edit().putBoolean("owner_mode", v).apply()
    var voiceLockOn: Boolean
        get() = plain.getBoolean("voice_lock", false)
        set(v) = plain.edit().putBoolean("voice_lock", v).apply()
    /** confirm | voice_or_bio | biometric */
    var protectMode: String
        get() = plain.getString("protect_mode", "confirm") ?: "confirm"
        set(v) = plain.edit().putString("protect_mode", v).apply()
    var lockBasic: Boolean
        get() = plain.getBoolean("lock_basic", true)
        set(v) = plain.edit().putBoolean("lock_basic", v).apply()
    var lockFlashlight: Boolean
        get() = plain.getBoolean("lock_flash", true)
        set(v) = plain.edit().putBoolean("lock_flash", v).apply()
    var lockTimer: Boolean
        get() = plain.getBoolean("lock_timer", true)
        set(v) = plain.edit().putBoolean("lock_timer", v).apply()
    var lockStatus: Boolean
        get() = plain.getBoolean("lock_status", true)
        set(v) = plain.edit().putBoolean("lock_status", v).apply()
    var lockRequireUnlock: Boolean
        get() = plain.getBoolean("lock_unlock", true)
        set(v) = plain.edit().putBoolean("lock_unlock", v).apply()

    var peopleAi: Boolean
        get() = plain.getBoolean("people_ai", true)
        set(v) = plain.edit().putBoolean("people_ai", v).apply()
    var peopleLearn: Boolean
        get() = plain.getBoolean("people_learn", true)
        set(v) = plain.edit().putBoolean("people_learn", v).apply()

    // ── v1.6 ──
    var maxTokens: Int
        get() = plain.getInt("max_tokens", 1024)
        set(v) = plain.edit().putInt("max_tokens", v.coerceIn(64, 8192)).apply()
    /** Local-only mode: nothing leaves the phone, Gemini and web search are never called. */
    var localOnly: Boolean
        get() = plain.getBoolean("local_only", false)
        set(v) = plain.edit().putBoolean("local_only", v).apply()
    var webSearchOn: Boolean
        get() = plain.getBoolean("web_on", true)
        set(v) = plain.edit().putBoolean("web_on", v).apply()
    /** Allow screen text / screenshots to be sent to Gemini when the user asks a screen question. */
    var visionOn: Boolean
        get() = plain.getBoolean("vision_on", true)
        set(v) = plain.edit().putBoolean("vision_on", v).apply()
    /** Master switch for sending a photo/video frame to Gemini. OFF by default; even when ON, every upload still needs a per-use confirmation. */
    var photosToGemini: Boolean
        get() = plain.getBoolean("photos_to_gemini", false)
        set(v) = plain.edit().putBoolean("photos_to_gemini", v).apply()
    /** Master switch for sending extracted DOCUMENT TEXT to Gemini from the File Manager. OFF by default; even when ON, every send needs its own confirmation showing the exact text. */
    var fileAnalysisToGemini: Boolean
        get() = plain.getBoolean("file_analysis_to_gemini", false)
        set(v) = plain.edit().putBoolean("file_analysis_to_gemini", v).apply()
    /** SAF folders the user granted (persisted tree URIs). */
    var storageTrees: Set<String>
        get() = plain.getStringSet("storage_trees", emptySet()) ?: emptySet()
        set(v) = plain.edit().putStringSet("storage_trees", v).apply()
    /** BCP-47 tag used when language == "manual" (for speech recognition, Gemini reply language and TTS). */
    var manualTag: String
        get() = plain.getString("lang_tag", "en-IN") ?: "en-IN"
        set(v) = plain.edit().putString("lang_tag", v).apply()
    var autoLangDetect: Boolean
        get() = plain.getBoolean("lang_auto_detect", true)
        set(v) = plain.edit().putBoolean("lang_auto_detect", v).apply()
    var screenActionsOn: Boolean
        get() = plain.getBoolean("screen_actions", true)
        set(v) = plain.edit().putBoolean("screen_actions", v).apply()
    /** Package name of the browser NOVA should use for browser tasks ("" = system default browser). */
    var browserPackage: String
        get() = plain.getString("browser_package", "") ?: ""
        set(v) = plain.edit().putString("browser_package", v).apply()
    var companionStyle: String
        get() = plain.getString("companion_style", "caring") ?: "caring"
        set(v) = plain.edit().putString("companion_style", v).apply()
    var routinesLog: String
        get() = plain.getString("routine_log", "") ?: ""
        set(v) = plain.edit().putString("routine_log", v.takeLast(4000)).apply()

    // ── modules ──
    var homeCity: String
        get() = plain.getString("home_city", "") ?: ""
        set(v) = plain.edit().putString("home_city", v.trim()).apply()
    var hookHome: String
        get() = plain.getString("hook_home", "") ?: ""
        set(v) = plain.edit().putString("hook_home", v.trim()).apply()
    var hookPc: String
        get() = plain.getString("hook_pc", "") ?: ""
        set(v) = plain.edit().putString("hook_pc", v.trim()).apply()
    var hookDevices: String
        get() = plain.getString("hook_dev", "") ?: ""
        set(v) = plain.edit().putString("hook_dev", v.trim()).apply()
    private var memoryOnlyHook = ""
    private var memoryOnlySecrets = HashMap<String, String>()
    /** Smart-home secrets (Tuya cloud secret, Home Assistant token): encrypted like the API key. */
    fun secret(name: String): String = secure?.getString("sec_$name", "") ?: memoryOnlySecrets[name].orEmpty()
    fun setSecret(name: String, v: String) { if (secure != null) secure.edit().putString("sec_$name", v.trim()).apply() else memoryOnlySecrets[name] = v.trim() }

    var hookToken: String
        get() = secure?.getString("hook_token", "") ?: memoryOnlyHook
        set(v) { if (secure != null) secure.edit().putString("hook_token", v.trim()).apply() else memoryOnlyHook = v.trim() }

    fun clearAll() {
        plain.edit().clear().apply()
        secure?.edit()?.clear()?.apply()
        memoryOnlyKey = ""
    }
}
