package com.nova.ai.brain

import android.content.Context
import android.net.Uri
import com.nova.ai.language.LanguageDetector
import com.nova.ai.live.LiveTools
import com.nova.ai.memory.MemCategory
import com.nova.ai.memory.MemoryDb
import com.nova.ai.security.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Outcome(val reply: String? = null, val notice: String? = null)
data class BrainStatus(
    val enabled: Boolean, val autoSave: Boolean, val counts: Map<BrainCategory, Int>, val topics: Int, val projects: Int, val files: Int, val reminders: Int,
    val vault: Int, val storageBytes: Long, val lastWrite: Long, val lastSnapshot: Long, val integrityOk: Boolean, val turns: Int, val lastError: String
)

private sealed class Pend {
    data class Save(val c: Candidate, val topicId: Long) : Pend()
    data class Choose(val act: String, val ids: List<Long>, val arg: String = "") : Pend()
    data class UpdateText(val id: Long) : Pend()
    data class Delete(val ids: List<Long>) : Pend()
    object Wipe : Pend()
}

/**
 * The memory engine's front door. One instance per app. It owns the database, the topic lock, the language lock, retrieval,
 * projects, reminders, the vault and backups, and is what chat, background voice, Live voice and the dashboard talk to.
 * Memory is independent of the selected Gemini model; each request gets a freshly built, size-limited context.
 */
class Brain private constructor(ctx: Context) {
    companion object {
        @Volatile private var inst: Brain? = null
        fun get(ctx: Context): Brain = inst ?: synchronized(this) { inst ?: Brain(ctx.applicationContext).also { inst = it } }

        const val LIVE_TOOL_HINT = "Memory tools: save_memory(text) saves something the user asked you to remember (for personal or sensitive information ask the user first, and never save passwords, PINs, OTPs, card numbers or keys), " +
            "recall_memory(query) looks up what the user told you before, get_pending_tasks() lists unfinished tasks. Use recall_memory instead of guessing what the user said earlier."

        fun declarations(): JSONArray = JSONArray()
            .put(LiveTools.decl("save_memory", "Save something the user asked you to remember.", listOf("text" to "The fact, preference, task or note, in the user's words"), listOf("text")))
            .put(LiveTools.decl("recall_memory", "Look up what the user previously told you.", listOf("query" to "What to look for"), listOf("query")))
            .put(LiveTools.decl("get_pending_tasks", "List the user's unfinished tasks.", emptyList(), emptyList()))
    }

    private val app: Context = ctx.applicationContext
    private val prefs = Prefs(app)
    @Volatile private var lastError = ""
    private var recoveredNote = ""

    @Volatile var store: BrainStore = openStore(); private set
    lateinit var memory: MemoryService; private set
    lateinit var topics: TopicEngine; private set
    lateinit var lang: LanguageStabilizer; private set
    lateinit var profile: ProfileService; private set
    lateinit var vault: SecureVault; private set
    private lateinit var builder: ContextBuilder

    private var pend: Pend? = null
    private var lastRef = 0L                 // the memory the conversation last talked about ("is information ko delete karo")
    @Volatile private var recapFlag = false
    private val suggestions = ArrayList<Pend.Save>()

    init { wire(); try { importLegacyOnce() } catch (e: Exception) { }; restorePending() }

    private fun wire() {
        memory = MemoryService(store); topics = TopicEngine(store); lang = LanguageStabilizer(store); profile = ProfileService(store)
        vault = SecureVault(store, { KeystoreKeys.vaultKey() })
        builder = ContextBuilder(store, topics, lang, profile)
    }

    // ───────── storage, recovery ─────────
    private fun openStore(): BrainStore {
        var s = SqlBrainStore(app)
        val ok = try { s.writableDatabase; s.integrityOk() } catch (e: Exception) { false }
        if (ok) return s
        try { s.close() } catch (e: Exception) { }
        val f = app.getDatabasePath(SqlBrainStore.DB_NAME)
        val stamp = System.currentTimeMillis()
        for (suffix in listOf("", "-wal", "-shm")) { val x = File(f.path + suffix); if (x.exists()) x.renameTo(File(f.path + suffix + ".corrupt-$stamp")) }
        s = SqlBrainStore(app)
        val restored = try { restoreLatestSnapshot(s) } catch (e: Exception) { false }
        recoveredNote = if (restored) "The memory database was damaged and was restored from the latest automatic snapshot." else "The memory database was damaged and could not be restored. The damaged file was kept aside."
        lastError = recoveredNote
        return s
    }

    private inline fun <T> safe(default: T, block: () -> T): T = try { block() } catch (e: Exception) { lastError = "Storage problem: " + (e.message ?: e.javaClass.simpleName); default }

    private fun now() = System.currentTimeMillis()
    private fun cfg(k: String, d: String) = store.getState("cfg.$k")?.takeIf { it.isNotEmpty() } ?: d
    private fun setCfg(k: String, v: String) = store.putState("cfg.$k", v)

    val enabled: Boolean get() = prefs.memoryEnabled
    var autoSave: Boolean get() = cfg("autosave", "1") == "1"; set(v) = setCfg("autosave", if (v) "1" else "0")
    var showNotices: Boolean get() = cfg("notices", "1") == "1"; set(v) = setCfg("notices", if (v) "1" else "0")
    var confirmSensitive: Boolean get() = cfg("confirm", "1") == "1"; set(v) = setCfg("confirm", if (v) "1" else "0")
    var autoReminder: Boolean get() = cfg("autoreminder", "0") == "1"; set(v) = setCfg("autoreminder", if (v) "1" else "0")
    var reminderHour: Int get() = cfg("reminderhour", "9").toIntOrNull()?.coerceIn(0, 23) ?: 9; set(v) = setCfg("reminderhour", v.coerceIn(0, 23).toString())
    fun setEnabled(v: Boolean) { prefs.memoryEnabled = v }

    private fun english() = lang.state()?.lang == LanguageStabilizer.ENGLISH
    private fun t(hi: String, en: String) = if (english()) en else hi
    private val dateFmt get() = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault())
    private fun markWrite() { store.putState("cfg.lastWrite", now().toString()) }

    private fun importLegacyOnce() {
        if (cfg("legacy", "") == "1") return
        val old = MemoryDb.get(app).memories()
        for (e in old) {
            val cat = when (e.category) {
                MemCategory.USER_PREFERENCE, MemCategory.DEVICE_PREFERENCE, MemCategory.PERSONALITY_PREFERENCE -> BrainCategory.PREFERENCE
                MemCategory.IMPORTANT_FACT -> BrainCategory.PERSONAL
                MemCategory.LONG_TERM_GOAL -> BrainCategory.FUTURE_PLAN
                MemCategory.ROUTINE -> BrainCategory.CUSTOM
                MemCategory.COMMAND_PREFERENCE -> BrainCategory.INSTRUCTION
                else -> continue
            }
            if (MemoryExtractor.isBlocked(e.content)) continue
            memory.save(Candidate(cat, Txt.clip(e.content, 60), e.content, importance = e.importance, explicit = e.userConfirmed), "legacy")
        }
        setCfg("legacy", "1")
    }

    // ───────── per-message entry point ─────────
    /**
     * Call for every user message before anything else. Returns a [Outcome.reply] when the message was a memory command
     * (then nothing else should answer it). Otherwise it updates language, topic and memory and may return a [Outcome.notice].
     */
    @Synchronized
    fun process(text: String, online: Boolean = true, source: String = "chat"): Outcome {
        if (!enabled) return Outcome()
        val t0 = text.trim()
        if (t0.isEmpty()) return Outcome()
        return safe(Outcome()) {
            val n = now()
            resolvePending(t0)?.let { logUser(t0, n); return@safe Outcome(reply = it) }
            val intent = BrainIntents.parse(t0)
            if (intent != null) {
                val r = execute(intent, t0, online)
                if (r != null) { logUser(t0, n); return@safe Outcome(reply = r) }
            }
            Outcome(notice = onUserTurn(t0, source))
        }
    }

    private fun logUser(text: String, n: Long) {
        val last = store.turns(1).firstOrNull()
        if (last != null && last.fromUser && last.text == text && n - last.ts < 4000) return   // duplicate after a reconnect
        store.addTurn(Turn(topicId = topics.activeId(), fromUser = true, text = text, ts = n, lang = lang.state()?.lang.orEmpty()))
        store.putState("ckpt.lastUser", text); store.putState("ckpt.ts", n.toString())
    }

    /** Language, topic, checkpoint, extraction. Returns a short notice for the user when something was saved or needs a yes. */
    private fun onUserTurn(text: String, source: String): String? {
        val n = now()
        val resolvedLang = lang.observe(text, n, prefs.language, prefs.manualTag)
        val dec = topics.onUserTurn(text, n)
        store.putState("ckpt.uncertain", if (dec is TopicDecision.Uncertain) "1" else "0")
        logUser(text, n)
        trackCommand(text)
        val directive = MemoryExtractor.directive(text)
        if (directive == Directive.DONT_SAVE) return null
        val explicit = directive == Directive.REMEMBER
        var cands = MemoryExtractor.extract(text, n, explicit = explicit)
        if (explicit && cands.isEmpty()) store.turns(4).filter { it.fromUser && it.text != text }.lastOrNull()?.let { cands = MemoryExtractor.extract(it.text, n, explicit = true) }
        if (cands.isEmpty()) return null
        val notices = ArrayList<String>()
        for (c in cands) {
            if (c.sensitivity == Sensitivity.BLOCK) { if (explicit) notices.add(t("Ye password / PIN / OTP / card jaisa lag raha hai, isliye main ise normal memory mein save nahi karungi. Secure Vault use karo.", "That looks like a password, PIN, OTP, card or key, so I won't save it in normal memory. Please use the Secure Vault.")); continue }
            if (!explicit && (!autoSave || c.category !in MemoryExtractor.autoSavable)) continue
            val ask = !explicit && ((c.sensitivity == Sensitivity.ASK && confirmSensitive) || c.category == BrainCategory.PERSONAL && confirmSensitive)
            if (ask) {
                val p = Pend.Save(c, topics.activeId())
                if (source == "voice") { if (suggestions.size < 20) suggestions.add(p) }
                else { setPend(p); notices.add(t("Ye important lag raha hai: \"${Txt.clip(c.content, 90)}\". Save kar loon? (haan / nahi)", "This looks important: \"${Txt.clip(c.content, 90)}\". Save it? (yes / no)")) }
                continue
            }
            saveCandidate(c, source)?.let { if (showNotices || explicit) notices.add(it) }
        }
        return notices.joinToString("\n").ifBlank { null }
    }

    private fun refProject(text: String): String {
        val ref = Regex("(?i)\\b(is|iss|us|uss|wahi|this|that|same)\\s+(project|app|application)\\b").containsMatchIn(text)
        val top = topics.active()
        if (top != null && top.project.isNotBlank()) return top.project
        return if (ref) store.projects().firstOrNull { it.status == Status.ONGOING }?.name.orEmpty() else ""
    }

    private fun saveCandidate(c: Candidate, source: String): String? {
        val topicId = topics.activeId()
        val proj = if (c.category == BrainCategory.TASK || c.category == BrainCategory.DECISION || c.category == BrainCategory.IMPORTANT_CONVERSATION) refProject(c.content) else ""
        val res = memory.save(c, source, topicId, proj)
        markWrite()
        return when (res) {
            is SaveResult.Saved -> {
                profile.observe(c)
                if (c.category == BrainCategory.PROJECT) topics.attachProject(c.title, now())
                if (c.category == BrainCategory.INSTRUCTION) topics.addInstruction(c.content, now())
                lastRef = res.item.id
                if (autoReminder && res.item.dueAt > now() && (c.category == BrainCategory.TASK || c.category == BrainCategory.REMINDER)) createReminder(res.item.title, res.item.dueAt, 0, res.item.id)
                if (c.category == BrainCategory.REMINDER && res.item.dueAt > now()) createReminder(res.item.title, res.item.dueAt, 0, res.item.id)
                t("💾 Yaad rakh liya (${c.category.label}): ${Txt.clip(res.item.title, 70)}", "💾 Saved (${c.category.label}): ${Txt.clip(res.item.title, 70)}")
            }
            is SaveResult.Updated -> { lastRef = res.item.id; t("💾 Purani yaad update kar di: ${Txt.clip(res.item.title, 70)}", "💾 Updated an earlier memory: ${Txt.clip(res.item.title, 70)}") }
            is SaveResult.Duplicate -> { lastRef = res.item.id; if (c.explicit) t("Ye mujhe pehle se yaad hai.", "I already remember that.") else null }
            SaveResult.Blocked -> null
        }
    }

    /** Called with every assistant reply (chat, voice). Keeps the topic's open questions and the checkpoint current. */
    @Synchronized
    fun onAssistantTurn(text: String) {
        if (!enabled) return
        val t0 = text.trim()
        if (t0.isEmpty()) return
        safe(Unit) {
            val n = now()
            val last = store.turns(1).firstOrNull()
            if (last != null && !last.fromUser && last.text == t0 && n - last.ts < 8000) return@safe       // repeated after a reconnect
            store.addTurn(Turn(topicId = topics.activeId(), fromUser = false, text = t0, ts = n, lang = lang.state()?.lang.orEmpty()))
            store.putState("ckpt.lastAI", Txt.clip(t0, 400)); store.putState("ckpt.ts", n.toString())
            topics.onAssistantTurn(t0, n)
        }
    }

    /** Background-voice / Live transcripts: same bookkeeping, never prompts (items that need a yes wait in the dashboard). */
    @Synchronized
    fun observeVoiceUser(text: String) { if (enabled && text.isNotBlank()) safe(Unit) { onUserTurn(text.trim(), "voice") } }

    // ───────── what the AI receives ─────────
    @Synchronized
    fun contextFor(userText: String, modelId: String, inputTokenLimit: Int = 0): String {
        if (!enabled) return ""
        return safe("") {
            val recap = recapFlag; recapFlag = false
            builder.build(userText, ContextBuilder.budgetFor(modelId, inputTokenLimit), 0, store.getState("ckpt.uncertain") == "1", recap).text
        }
    }

    /** Language instruction for chat prompts. A fixed language in Settings is kept; "auto" uses the conversation's locked language. */
    @Synchronized
    fun languageInstruction(prefLanguage: String, manualTag: String, lastText: String): String {
        if (!enabled) return LanguageDetector.instruction(prefLanguage, manualTag, lastText)
        return safe(LanguageDetector.instruction(prefLanguage, manualTag, lastText)) {
            if (prefLanguage == "auto") lang.policy() else LanguageDetector.instruction(prefLanguage, manualTag, lastText) + " " + lang.policy()
        }
    }

    /** For the Live system instruction: the locked language (null = use the existing wording), plus context to restore after a reconnect. */
    @Synchronized fun livePolicy(): String? = if (enabled && prefs.language == "auto") safe<String?>(null) { lang.policy() } else null

    @Synchronized
    fun liveContext(modelId: String = "live"): String {
        if (!enabled) return ""
        return safe("") {
            val seed = (topics.active()?.title.orEmpty() + " " + (store.getState("ckpt.lastUser") ?: "")).trim()
            builder.build(seed, ContextBuilder.budgetFor(modelId, 0, true), 6, false, false).text + "\n\n" + LIVE_TOOL_HINT
        }
    }

    /** Last few messages when the conversation was active in the last 30 minutes, so a new connection continues instead of greeting again. */
    @Synchronized
    fun recapIfRecent(): String? = safe<String?>(null) {
        if (!enabled) return@safe null
        val ts = store.getState("ckpt.ts")?.toLongOrNull() ?: return@safe null
        if (now() - ts > 30 * 60_000L) return@safe null
        val turns = store.turns(6)
        if (turns.isEmpty()) null else turns.joinToString("\n") { (if (it.fromUser) "User: " else "You: ") + Txt.clip(it.text, 160) } +
            (store.getState("ckpt.lastAI")?.let { "\n(Your last reply is above; do not repeat it.)" } ?: "")
    }

    // ───────── pending questions (confirm / choose) ─────────
    private fun setPend(p: Pend?) { pend = p; store.putState("pend", p?.let { pendJson(it) } ?: "") }

    private fun pendJson(p: Pend): String = when (p) {
        is Pend.Save -> JSONObject().put("k", "save").put("cat", p.c.category.name).put("title", p.c.title).put("content", p.c.content).put("project", p.c.project)
            .put("status", p.c.status).put("due", p.c.dueAt).put("imp", p.c.importance.toDouble()).put("topic", p.topicId).toString()
        is Pend.Choose -> JSONObject().put("k", "choose").put("act", p.act).put("ids", JSONArray(p.ids)).put("arg", p.arg).toString()
        is Pend.UpdateText -> JSONObject().put("k", "upd").put("id", p.id).toString()
        is Pend.Delete -> JSONObject().put("k", "del").put("ids", JSONArray(p.ids)).toString()
        Pend.Wipe -> JSONObject().put("k", "wipe").toString()
    }

    private fun restorePending() {
        val s = store.getState("pend").orEmpty()
        if (s.isEmpty()) return
        pend = try {
            val o = JSONObject(s)
            fun ids(): List<Long> = o.getJSONArray("ids").let { a -> (0 until a.length()).map { a.getLong(it) } }
            when (o.getString("k")) {
                "save" -> Pend.Save(Candidate(BrainCategory.parse(o.getString("cat")), o.getString("title"), o.getString("content"), o.optString("project"), o.optString("status"), o.optLong("due"), o.optDouble("imp", 0.6).toFloat(), Sensitivity.ASK), o.optLong("topic"))
                "choose" -> Pend.Choose(o.getString("act"), ids(), o.optString("arg"))
                "upd" -> Pend.UpdateText(o.getLong("id"))
                "del" -> Pend.Delete(ids())
                "wipe" -> Pend.Wipe
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun describe(id: Long): String = memory.item(id)?.let { Txt.clip(it.content, 90) } ?: "?"

    private fun resolvePending(text: String): String? {
        val p = pend ?: return null
        val yes = BrainIntents.isYes(text); val no = BrainIntents.isNo(text)
        when (p) {
            is Pend.Save -> {
                setPend(null)
                if (yes) { val r = saveCandidate(p.c.copy(explicit = true), "chat"); return r ?: t("Theek hai.", "Okay.") }
                if (no) return t("Theek hai, save nahi kiya.", "Okay, I did not save it.")
            }
            is Pend.Wipe -> {
                setPend(null)
                if (yes) { wipeMemory(); return t("Ho gaya. Saari memory delete kar di (Secure Vault ko haath nahi lagaya).", "Done. All memory is deleted (the Secure Vault was not touched).") }
                if (no) return t("Theek hai, kuch delete nahi kiya.", "Okay, nothing was deleted.")
            }
            is Pend.Delete -> {
                setPend(null)
                if (yes) { p.ids.forEach { memory.delete(it); cancelRemindersFor(it) }; markWrite(); return t("Delete kar diya.", "Deleted.") }
                if (no) return t("Theek hai, rehne diya.", "Okay, I kept it.")
            }
            is Pend.UpdateText -> {
                setPend(null)
                if (no) return t("Theek hai, update nahi kiya.", "Okay, not updated.")
                if (MemoryExtractor.isBlocked(text)) return t("Ye private jaankari jaisa lag raha hai, isliye save nahi kiya.", "That looks private, so I did not save it.")
                memory.update(p.id, text)?.let { markWrite(); lastRef = it.id; return t("Update kar diya.", "Updated.") }
                return null
            }
            is Pend.Choose -> {
                val opts = p.ids.map { describe(it) }
                val i = BrainIntents.choiceIndex(text, opts)
                setPend(null)
                if (i < 0) return null
                return applyChoice(p.act, p.ids[i], p.arg)
            }
        }
        return null
    }

    private fun applyChoice(act: String, id: Long, arg: String): String {
        val it = memory.item(id) ?: return t("Wo memory ab nahi mili.", "I can't find that memory any more.")
        lastRef = id
        return when (act) {
            "recall" -> t("Tumne bataya tha: ${it.content}", "You told me: ${it.content}")
            "delete" -> { setPend(Pend.Delete(listOf(id))); t("\"${Txt.clip(it.content, 90)}\" delete kar doon? (haan / nahi)", "Delete \"${Txt.clip(it.content, 90)}\"? (yes / no)") }
            "update" -> if (arg.isNotBlank()) { memory.update(id, arg); markWrite(); t("Update kar diya.", "Updated.") } else { setPend(Pend.UpdateText(id)); t("Naya kya likhun?", "What should it say now?") }
            "done" -> { memory.setStatus(id, Status.DONE); markWrite(); t("Theek hai, task ko done mark kar diya.", "Okay, marked the task as done.") }
            "remind" -> remindFor(it)
            else -> it.content
        }
    }

    // ───────── commands ─────────
    private fun options(ids: List<Long>) = ids.mapIndexed { i, id -> "${i + 1}) ${describe(id)}" }.joinToString("  ")

    private fun pick(hint: String, cats: Set<BrainCategory> = emptySet(), act: String, arg: String = ""): Pair<BrainItem?, String?> {
        val tokens = Txt.tokens(hint)
        if (tokens.isEmpty()) {
            val r = memory.item(lastRef)
            return if (r != null) r to null else null to t("Kaun si memory? Thoda batao.", "Which memory do you mean? Tell me a bit more.")
        }
        val hits = memory.find(hint, cats, 4)
        if (hits.isEmpty()) return null to t("Mujhe aisi koi memory nahi mili.", "I could not find such a memory.")
        val amb = Retrieval.ambiguous(hits)
        if (amb != null) { setPend(Pend.Choose(act, amb.map { it.item.id }, arg)); return null to t("Kaun si wali? ${options(amb.map { it.item.id })}", "Which one? ${options(amb.map { it.item.id })}") }
        return hits[0].item to null
    }

    private fun execute(intent: BrainIntent, text: String, online: Boolean): String? = when (intent) {
        is BrainIntent.Remember -> {
            val src = intent.content.ifBlank { store.turns(4).filter { it.fromUser && it.text.trim() != text.trim() }.lastOrNull()?.text.orEmpty() }
            if (src.isBlank()) t("Kya yaad rakhun? Bata do.", "What should I remember?")
            else {
                var cands = MemoryExtractor.extract(src, now(), explicit = true)
                if (cands.isEmpty()) cands = listOf(Candidate(BrainCategory.CUSTOM, Txt.clip(src, 60), src, importance = 0.8f, explicit = true))
                if (cands.first().sensitivity == Sensitivity.BLOCK) t("Ye password / PIN / OTP / card jaisa lag raha hai, isliye main ise normal memory mein save nahi karungi. Secure Vault (Memory Dashboard) mein save karo.", "That looks like a password, PIN, OTP, card or key, so I won't save it in normal memory. Please use the Secure Vault in the Memory Dashboard.")
                else cands.mapNotNull { saveCandidate(it.copy(explicit = true), "chat") }.joinToString("\n").ifBlank { t("Theek hai.", "Okay.") }
            }
        }
        BrainIntent.DontSave -> { store.putState("ckpt.ts", now().toString()); t("Theek hai, ye baat save nahi karungi.", "Okay, I won't save this.") }
        BrainIntent.WhatDoYouRemember -> whatIRemember()
        is BrainIntent.Recall -> recallAnswer(intent, text)
        is BrainIntent.Update -> {
            val (hit, ask) = pick(intent.hint, emptySet(), "update", intent.newText)
            when {
                ask != null -> ask
                hit == null -> null
                intent.newText.isBlank() -> { setPend(Pend.UpdateText(hit.id)); t("Abhi ye saved hai: \"${Txt.clip(hit.content, 90)}\". Naya kya likhun?", "Currently saved: \"${Txt.clip(hit.content, 90)}\". What should it say now?") }
                MemoryExtractor.isBlocked(intent.newText) -> t("Ye private jaankari jaisa lag raha hai, isliye save nahi kiya.", "That looks private, so I did not save it.")
                else -> { memory.update(hit.id, intent.newText); markWrite(); lastRef = hit.id; t("Update kar diya.", "Updated.") }
            }
        }
        is BrainIntent.Delete -> {
            val (hit, ask) = pick(intent.hint, emptySet(), "delete")
            when { ask != null -> ask; hit == null -> null; else -> { lastRef = hit.id; setPend(Pend.Delete(listOf(hit.id))); t("\"${Txt.clip(hit.content, 90)}\" delete kar doon? (haan / nahi)", "Delete \"${Txt.clip(hit.content, 90)}\"? (yes / no)") } }
        }
        is BrainIntent.MarkDone -> {
            val hits = memory.find(intent.hint, setOf(BrainCategory.TASK), 3).filter { it.item.status != Status.DONE }
            when {
                hits.isEmpty() -> null
                Retrieval.ambiguous(hits) != null -> { val a = Retrieval.ambiguous(hits)!!; setPend(Pend.Choose("done", a.map { it.item.id })); t("Kaun sa task? ${options(a.map { it.item.id })}", "Which task? ${options(a.map { it.item.id })}") }
                else -> { memory.setStatus(hits[0].item.id, Status.DONE); markWrite(); t("Theek hai, \"${Txt.clip(hits[0].item.title, 60)}\" ko done mark kar diya.", "Okay, marked \"${Txt.clip(hits[0].item.title, 60)}\" as done.") }
            }
        }
        BrainIntent.PendingList -> pendingAnswer()
        BrainIntent.ProjectMemory -> projectsAnswer()
        is BrainIntent.FindFile -> fileAnswer(intent)
        BrainIntent.Recap -> {
            val top = topics.active()
            if (top == null) t("Abhi mere paas koi topic saved nahi hai.", "I don't have a saved topic yet.")
            else if (online && prefs.hasActiveKey() && !prefs.localOnly) { recapFlag = true; null }
            else topics.recap(top, english())
        }
        is BrainIntent.ResumeTopic -> resumeAnswer(intent.query, text)
        is BrainIntent.RemindTask -> {
            val task = memory.item(lastRef)?.takeIf { x -> x.category == BrainCategory.TASK } ?: memory.pendingTasks().firstOrNull()
            if (task == null) t("Kis task ka reminder lagaun? Abhi koi pending task saved nahi hai.", "Which task? I have no pending task saved.") else { lastRef = task.id; remindFor(task) }
        }
        BrainIntent.PauseSaving -> { autoSave = false; t("Theek hai, ab main apne aap kuch save nahi karungi. \"Ise yaad rakhna\" bologe to save karungi.", "Okay, automatic saving is paused. I will still save things when you ask.") }
        BrainIntent.ResumeSaving -> { autoSave = true; t("Automatic memory saving chalu kar di.", "Automatic memory saving is on again.") }
        BrainIntent.WipeAll -> { setPend(Pend.Wipe); t("Saari memory delete kar doon? Ye wapas nahi aayegi. (haan / nahi)", "Delete ALL memory? This cannot be undone. (yes / no)") }
    }

    private fun whatIRemember(): String {
        val counts = memory.countsByCategory()
        if (counts.isEmpty()) return t("Abhi mere paas kuch saved nahi hai.", "I have nothing saved yet.")
        val total = counts.values.sum()
        val top = memory.all().filter { it.category != BrainCategory.FREQUENT_COMMAND }.sortedWith(compareByDescending<BrainItem> { it.pinned }.thenByDescending { it.updatedAt }).take(5)
        return t("Mere paas $total cheezein saved hain: ", "I have $total things saved: ") + counts.entries.sortedByDescending { it.value }.take(6).joinToString(", ") { "${it.key.label} ${it.value}" } + ". " +
            t("Haal hi ki: ", "Most recent: ") + top.joinToString("; ") { Txt.clip(it.content, 70) } + t(". Poori list Memory Dashboard mein hai.", ". The full list is in the Memory Dashboard.")
    }

    private fun recallAnswer(i: BrainIntent.Recall, text: String): String? {
        val range = DateResolver.pastRange(text, now())
        val q = text.replace(Regex("(?i)\\b(maine|humne|mene|tumhe|tumse|aapko|apne|bataya|tha|thi|the|kya|ke baare mein|baare|what|did|i|tell|you|about|my|mera|meri|mere|nova)\\b"), " ").trim()
        val hits = Retrieval.search(memory.all(), RetrievalQuery(q.ifBlank { text }, from = range?.first ?: 0L, to = range?.second ?: Long.MAX_VALUE), now(), 5)
        if (hits.isEmpty()) return if (i.explicitTold) t("Mujhe is baare mein kuch saved nahi mila.", "I don't have anything saved about that.") else null
        store.touch(hits.map { it.item.id }, now()); lastRef = hits[0].item.id
        val single = Regex("(?i)(naam|name|kaun\\s*sa|konsa|which|kab|when|kahan|where|kitna|how many)").containsMatchIn(text)
        if (single) Retrieval.ambiguous(hits)?.let { a -> setPend(Pend.Choose("recall", a.map { it.item.id })); return t("Mere paas kai match hain. Kaun sa? ${options(a.map { it.item.id })}", "I have several matches. Which one? ${options(a.map { it.item.id })}") }
        return if (single || hits.size == 1) t("Tumne bataya tha: ${hits[0].item.content}", "You told me: ${hits[0].item.content}")
        else t("Tumne ye bataya tha: ", "You told me: ") + hits.take(4).mapIndexed { n, h -> "${n + 1}) ${Txt.clip(h.item.content, 110)}" }.joinToString("  ")
    }

    private fun pendingAnswer(): String {
        val tasks = memory.pendingTasks().take(6)
        val top = topics.active()
        val asked = top?.unanswered?.lines()?.firstOrNull { it.startsWith("A:") }?.removePrefix("A:")
        if (tasks.isEmpty() && asked == null) return t("Mere paas koi pending task saved nahi hai.", "I have no pending task saved.")
        val sb = StringBuilder()
        if (tasks.isNotEmpty()) {
            sb.append(t("Pending kaam: ", "Pending tasks: ")).append(tasks.mapIndexed { n, x -> "${n + 1}) ${Txt.clip(x.content, 80)}" + (if (x.dueAt > 0) " (${dateFmt.format(Date(x.dueAt))})" else "") + (if (x.project.isNotBlank()) " [${x.project}]" else "") }.joinToString("  "))
            lastRef = tasks[0].id
        }
        if (asked != null) sb.append(" ").append(t("Maine tumse poocha tha: ", "I asked you: ")).append(asked)
        sb.append(t(" Kisi ko continue karna hai?", " Want to continue with one?"))
        return sb.toString().trim()
    }

    private fun projectsAnswer(): String {
        val ps = store.projects()
        if (ps.isEmpty()) return t("Abhi koi project saved nahi hai. \"Main ... project par kaam kar raha hoon\" bolo ya Dashboard mein folder add karo.", "No project is saved yet. Say \"I'm working on ... project\" or add a folder in the dashboard.")
        return t("Tumhare projects: ", "Your projects: ") + ps.take(6).joinToString("; ") { p ->
            val open = memory.pendingTasks(p.name).size
            p.name + " (" + p.status.lowercase() + (if (p.version.isNotBlank()) ", v${p.version}" else "") + (if (open > 0) ", $open pending" else "") + ")"
        }
    }

    private fun fileAnswer(i: BrainIntent.FindFile): String? {
        val projects = store.projects()
        if (i.open) {
            val p = projects.firstOrNull { pr -> Txt.tokenSet(pr.name).let { it.isNotEmpty() && it.all { w -> w in Txt.tokenSet(i.query) } } } ?: return null
            val files = store.files(p.id)
            val open = memory.pendingTasks(p.name).size
            return t("Project ${p.name}: status ${p.status.lowercase()}", "Project ${p.name}: status ${p.status.lowercase()}") + (if (p.version.isNotBlank()) ", latest known version ${p.version}" else "") +
                (if (files.isNotEmpty()) ". Structure: ${ProjectFiles.structure(files)}" else t(". Is project ka folder abhi index nahi hua.", ". This project's folder is not indexed yet.")) +
                (if (open > 0) t(". $open kaam pending hain.", ". $open items are pending.") else "") + t(" Files Memory Dashboard ke Projects tab mein khol sakte ho.", " You can open its files from the Projects tab in the dashboard.")
        }
        val q = i.query.replace(Regex("(?i)\\b(kahan|hai|hain|where|is|are|the|my|mera|meri|mere|ka|ki|ke|locate|dhoondo|dhundo|find|search|file|files|code|folder|document)\\b"), " ").trim().ifBlank { i.query }
        val hits = ProjectFiles.search(store.files(), q, 5)
        if (hits.isEmpty()) return if (store.projects().any { it.rootUri.isNotBlank() }) t("Mujhe index ki hui files mein aisi koi file nahi mili.", "I could not find such a file in the indexed folders.") else t("Abhi koi folder index nahi hua. Memory Dashboard > Projects mein folder add karo.", "No folder is indexed yet. Add one in Memory Dashboard > Projects.")
        val nameOf = { pid: Long -> projects.firstOrNull { it.id == pid }?.name.orEmpty() }
        return t("Mujhe ye mila: ", "I found: ") + hits.mapIndexed { n, h -> "${n + 1}) ${h.first.relPath} (${nameOf(h.first.projectId)})" }.joinToString("  ")
    }

    private fun resumeAnswer(query: String, text: String): String? {
        val range = DateResolver.pastRange(text, now())
        val wantsPending = Regex("(?i)(adhura|pending|baaki|unfinished)").containsMatchIn(text)
        val q = query.replace(Regex("(?i)\\b(hum|purani|puraani|wali|baat|continue|karte|hain|karo|kar|kal|pichhli|pichli|mujhe|woh|wo|yaad|dilao|dila|jisme|jo|kaam|adhura|chhoda|tha|use|old|previous|resume|let's|lets|nova)\\b"), " ").trim()
        if (wantsPending) {
            val tasks = memory.pendingTasks()
            if (tasks.isEmpty() && topics.active() == null) return t("Mere paas koi adhura kaam saved nahi hai.", "I have no unfinished work saved.")
            tasks.firstOrNull()?.let { lastRef = it.id }
            return pendingAnswer()
        }
        val cur = topics.active()
        var found = topics.find(q, range).filter { it.id != cur?.id }
        if (found.isEmpty() && q.isBlank()) found = topics.history().filter { it.id != cur?.id }
        if (found.isEmpty()) return if (cur != null && q.isBlank()) topics.recap(cur, english()) else t("Mujhe is naam ki koi purani baat saved nahi mili.", "I could not find an earlier conversation like that.")
        if (found.size > 1 && q.isNotBlank() && Txt.tokens(q).size >= 1 && found.take(2).let { it[0].title != it[1].title } && range == null) {
            val scoreA = found[0]; val scoreB = found[1]
            if (Txt.jaccard(Txt.tokenSet(scoreA.title + " " + scoreA.keywords), Txt.tokenSet(q)) == Txt.jaccard(Txt.tokenSet(scoreB.title + " " + scoreB.keywords), Txt.tokenSet(q))) {
                return t("Kai purani baatein mili: ", "I found several earlier conversations: ") + found.take(3).mapIndexed { n, tp -> "${n + 1}) ${tp.title}" }.joinToString("  ") + t(". Kaun si continue karein? (topic ka naam bolo)", ". Which one should we continue? (say its name)")
            }
        }
        val chosen = found[0]
        val back = topics.resume(chosen.id, now()) ?: return null
        return t("Theek hai, wapas wahin. ", "Okay, back to it. ") + topics.recap(back, english())
    }

    private fun remindFor(item: BrainItem): String {
        val at = if (item.dueAt > now()) item.dueAt else java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, 1); set(java.util.Calendar.HOUR_OF_DAY, reminderHour); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0) }.timeInMillis
        createReminder(Txt.clip(item.title, 80), at, 0, item.id)
        return t("Reminder laga diya: ${dateFmt.format(Date(at))}.", "Reminder set for ${dateFmt.format(Date(at))}.")
    }

    // ───────── reminders ─────────
    fun createReminder(title: String, at: Long, repeatMs: Long, itemId: Long = 0): ReminderRec? = safe<ReminderRec?>(null) {
        val r = ReminderRec(0, itemId, title, at, repeatMs)
        val saved = r.copy(id = store.saveReminder(r)); ReminderScheduler.schedule(app, saved); markWrite(); saved
    }
    fun updateReminder(r: ReminderRec) { safe(Unit) { store.saveReminder(r); ReminderScheduler.schedule(app, r); if (!r.enabled) ReminderScheduler.cancel(app, r.id) } }
    fun deleteReminder(id: Long) { safe(Unit) { ReminderScheduler.cancel(app, id); store.deleteReminder(id) } }
    private fun cancelRemindersFor(itemId: Long) { store.reminders().filter { it.itemId == itemId }.forEach { ReminderScheduler.cancel(app, it.id) } }
    fun rescheduleReminders() { safe(Unit) { ReminderScheduler.rescheduleAll(app, store) } }

    /** Called by the alarm. Returns the reminder to show, or null when it was switched off or deleted meanwhile. */
    fun fireReminder(id: Long): ReminderRec? = safe<ReminderRec?>(null) {
        val r = store.reminders().firstOrNull { it.id == id } ?: return@safe null
        if (!r.enabled) return@safe null
        val n = now()
        if (r.repeatMs > 0) { val next = r.copy(lastFired = n, fireAt = ReminderScheduler.nextRepeat(r, n)); store.saveReminder(next); ReminderScheduler.schedule(app, next) }
        else store.saveReminder(r.copy(lastFired = n, enabled = false))
        r
    }

    // ───────── tools for Live voice ─────────
    @Synchronized
    fun executeTool(name: String, args: JSONObject): JSONObject? = safe<JSONObject?>(JSONObject().put("result", "memory_error")) {
        if (!enabled) return@safe JSONObject().put("result", "memory_is_off")
        when (name) {
            "save_memory" -> {
                val text = args.optString("text")
                val cands = MemoryExtractor.extract(text, now(), explicit = true)
                when {
                    text.isBlank() -> JSONObject().put("result", "nothing_to_save")
                    MemoryExtractor.isBlocked(text) -> JSONObject().put("result", "refused: looks like a password, PIN, OTP, card or key. Tell the user to use the Secure Vault in the app.")
                    else -> { val c = (cands.firstOrNull() ?: Candidate(BrainCategory.CUSTOM, Txt.clip(text, 60), text, importance = 0.8f, explicit = true)).copy(explicit = true)
                        saveCandidate(c, "voice"); JSONObject().put("result", "saved") }
                }
            }
            "recall_memory" -> {
                val hits = Retrieval.search(memory.all(), RetrievalQuery(args.optString("query")), now(), 5)
                if (hits.isEmpty()) JSONObject().put("result", "nothing_saved_about_that")
                else { store.touch(hits.map { it.item.id }, now()); JSONObject().put("result", hits.joinToString(" | ") { "[" + it.item.category.label + "] " + Txt.clip(it.item.content, 200) }) }
            }
            "get_pending_tasks" -> JSONObject().put("result", memory.pendingTasks().take(8).joinToString(" | ") { Txt.clip(it.content, 100) }.ifBlank { "no_pending_tasks" })
            else -> null
        }
    }

    // ───────── frequent commands ─────────
    private fun trackCommand(text: String) {
        val l = text.trim().lowercase().replace(Regex("(?i)^nova[ ,]*"), "")
        if (!Regex("^(open|call|play|kholo|chalao|bajao|start|stop|turn|set|scan|show|dikhao|band karo)\\b").containsMatchIn(l) || l.split(' ').size > 6) return
        val key = "cmd." + Txt.hash(l)
        val cur = store.getState(key)?.substringBefore('|')?.toIntOrNull() ?: 0
        val n = cur + 1
        store.putState(key, "$n|$l")
        if (n == 3 || n == 6 || n == 12) {
            val content = "Often uses the command: \"$l\" ($n times)"
            val ex = memory.all().firstOrNull { it.category == BrainCategory.FREQUENT_COMMAND && it.title.equals(l, true) }
            if (ex == null) memory.save(Candidate(BrainCategory.FREQUENT_COMMAND, l, content, importance = 0.4f), "chat")
            else { memory.update(ex.id, content); memory.item(ex.id)?.let { store.saveItem(it.copy(title = l)) } }
        }
    }

    // ───────── dashboard API ─────────
    fun pendingSuggestions(): List<Candidate> = suggestions.map { it.c }
    fun approveSuggestion(index: Int): String? { if (index !in suggestions.indices) return null; val s = suggestions.removeAt(index); return saveCandidate(s.c.copy(explicit = true), "voice") }
    fun rejectSuggestion(index: Int) { if (index in suggestions.indices) suggestions.removeAt(index) }

    fun addNote(text: String, category: BrainCategory = BrainCategory.NOTE): String {
        if (MemoryExtractor.isBlocked(text)) return "That looks like a password, PIN, OTP, card or key. Please use the Secure Vault."
        return when (memory.save(Candidate(category, Txt.clip(text.trim(), 60), text.trim(), importance = 0.8f, explicit = true), "dashboard", topics.activeId())) {
            is SaveResult.Saved -> { markWrite(); "Saved." }
            is SaveResult.Updated -> { markWrite(); "Updated an earlier memory." }
            is SaveResult.Duplicate -> "Already saved."
            SaveResult.Blocked -> "Not saved."
        }
    }

    fun deleteItem(id: Long) { safe(Unit) { cancelRemindersFor(id); memory.delete(id); markWrite() } }
    fun clearCategory(c: BrainCategory) { safe(Unit) { store.items().filter { it.category == c }.forEach { cancelRemindersFor(it.id) }; memory.clearCategory(c); markWrite() } }

    /** Deletes memories, topics, conversation log, projects, files, reminders and settings state. The Secure Vault is not touched. */
    fun wipeMemory() { safe(Unit) { store.reminders().forEach { ReminderScheduler.cancel(app, it.id) }; store.wipeAll(); setPend(null); lastRef = 0; suggestions.clear(); markWrite() } }

    fun status(): BrainStatus = safe(BrainStatus(enabled, true, emptyMap(), 0, 0, 0, 0, 0, 0, 0, 0, false, 0, lastError)) {
        BrainStatus(enabled, autoSave, memory.countsByCategory(), store.topics().size, store.projects().size, store.files().size, store.reminders().size, store.vault().size,
            store.sizeBytes() + snapshotDir().listFiles().orEmpty().sumOf { it.length() }, store.getState("cfg.lastWrite")?.toLongOrNull() ?: 0L,
            store.getState("cfg.lastSnap")?.toLongOrNull() ?: 0L, store.integrityOk(), store.turns(3000).size, lastError)
    }

    // ───────── projects and files ─────────
    fun addProjectFolder(treeUri: Uri, name: String): ProjectRec? = safe<ProjectRec?>(null) {
        val existing = store.projects().firstOrNull { it.name.equals(name, true) }
        val p = (existing ?: memory.ensureProject(name, Status.ONGOING)).copy(rootUri = treeUri.toString(), updatedAt = now())
        store.saveProject(p); markWrite(); p
    }
    /** Heavy: call from a background thread. */
    fun reindex(projectId: Long): IndexReport {
        val p = store.projects().firstOrNull { it.id == projectId } ?: return IndexReport(0, 0, 0, 0, false, "Project not found")
        if (p.rootUri.isBlank()) return IndexReport(0, 0, 0, 0, false, "No folder is linked to this project")
        return FileIndexer.index(app, store, p).also { markWrite() }
    }
    fun readFile(rec: FileRec, max: Int = 4000): String? = FileIndexer.readText(app, store, rec, max)
    fun setProjectStatus(id: Long, status: String) { safe(Unit) { store.projects().firstOrNull { it.id == id }?.let { store.saveProject(it.copy(status = status, updatedAt = now())) } } }
    fun deleteProject(id: Long) { safe(Unit) { store.deleteProject(id) } }

    // ───────── backup ─────────
    /** [vaultPass] non-null = include the vault, protected by that passphrase. Without a passphrase the backup is plain JSON without the vault. */
    fun exportBytes(pass: CharArray?, includeVault: Boolean): ByteArray {
        val plainVault = if (includeVault && pass != null) vault.exportPlain() else null
        val json = BackupManager.export(store, now(), "NOVA", plainVault)
        return if (pass != null) BackupManager.seal(json, pass) else json.toByteArray(Charsets.UTF_8)
    }
    fun verifyBytes(bytes: ByteArray, pass: CharArray?): VerifyResult {
        return try {
            BackupManager.verify(if (VaultCrypto.isSealed(bytes)) BackupManager.open(bytes, pass ?: return VerifyResult(false, "This backup is encrypted. Enter its passphrase.")) else String(bytes, Charsets.UTF_8))
        } catch (e: Exception) { VerifyResult(false, "Wrong passphrase or damaged file.") }
    }
    fun importBytes(bytes: ByteArray, pass: CharArray?, replace: Boolean): RestoreResult {
        val json = if (VaultCrypto.isSealed(bytes)) BackupManager.open(bytes, pass ?: throw IllegalArgumentException("Passphrase needed")) else String(bytes, Charsets.UTF_8)
        autoSnapshot()
        val r = BackupManager.restore(store, json, replace) { vault.importPlain(it) }
        markWrite(); rescheduleReminders(); return r
    }

    private fun snapshotDir() = File(app.filesDir, "brain_snap").also { it.mkdirs() }

    /** Encrypted local safety copy (Android Keystore key), used to recover from a damaged database. Keeps the newest three. */
    fun autoSnapshot() { safe(Unit) {
        val json = BackupManager.export(store, now(), "NOVA-snapshot", null)
        File(snapshotDir(), "snap_${now()}.bin").writeBytes(VaultCrypto.encrypt(KeystoreKeys.snapshotKey(), json.toByteArray(Charsets.UTF_8)))
        snapshotDir().listFiles().orEmpty().sortedByDescending { it.name }.drop(3).forEach { it.delete() }
        store.putState("cfg.lastSnap", now().toString())
    } }

    private fun restoreLatestSnapshot(target: BrainStore): Boolean {
        for (f in snapshotDir().listFiles().orEmpty().sortedByDescending { it.name }) {
            try {
                val json = String(VaultCrypto.decrypt(KeystoreKeys.snapshotKey(), f.readBytes()), Charsets.UTF_8)
                if (BackupManager.verify(json).ok) { BackupManager.restore(target, json, true); return true }
            } catch (e: Exception) { }
        }
        return false
    }

    /** Cheap upkeep at app start: integrity check, daily snapshot, reminders back on the clock. */
    fun maintenance() { safe(Unit) {
        if (!store.integrityOk()) lastError = "Database integrity check failed"
        val last = store.getState("cfg.lastSnap")?.toLongOrNull() ?: 0L
        if (enabled && now() - last > 24 * 3600_000L && store.items().isNotEmpty()) autoSnapshot()
        rescheduleReminders()
    } }

    fun recoveryNote(): String = recoveredNote
}
