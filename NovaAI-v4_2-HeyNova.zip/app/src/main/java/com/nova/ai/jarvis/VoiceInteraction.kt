package com.nova.ai.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import com.nova.ai.ui.MainActivity

/**
 * Lets you pick Nova as the phone's default digital assistant (Settings > Apps > Default apps > Digital assistant app).
 * Then the assist gesture (power-button long press / corner swipe) opens Nova and starts listening.
 */
class NovaVoiceInteractionService : VoiceInteractionService()

class NovaVoiceSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = NovaVoiceSession(this)
}

class NovaVoiceSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            startAssistantActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("listen", true))
        } catch (e: Exception) { }
        finish()
    }
}

/** Required by Android's assistant declaration. It is not offered to other apps and always reports that it can't recognize speech. */
class NovaStubRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) { try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { } }
    override fun onCancel(listener: RecognitionService.Callback?) { }
    override fun onStopListening(listener: RecognitionService.Callback?) { }
}
