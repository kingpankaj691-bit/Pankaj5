package com.nova.ai.brain

import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** AES-256-GCM helpers. The same code works with an Android Keystore key (vault, snapshots) and with a passphrase-derived key (backups). */
object VaultCrypto {
    private val rnd = SecureRandom()
    private val MAGIC = "NOVABK1".toByteArray(Charsets.US_ASCII)
    private const val ITER = 150_000
    private val AAD = "nova-brain-v1".toByteArray(Charsets.US_ASCII)

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    /** Result layout: 12 byte IV followed by ciphertext and the 16 byte authentication tag. */
    fun encrypt(key: SecretKey, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        c.updateAAD(AAD)
        val ct = c.doFinal(plain)
        return c.iv + ct
    }

    /** Throws [GeneralSecurityException] when the data was changed or the key is wrong. */
    fun decrypt(key: SecretKey, blob: ByteArray): ByteArray {
        if (blob.size < 12 + 16) throw GeneralSecurityException("Data too short")
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
        c.updateAAD(AAD)
        return c.doFinal(blob, 12, blob.size - 12)
    }

    fun deriveKey(pass: CharArray, salt: ByteArray, iterations: Int = ITER): SecretKey {
        val spec = PBEKeySpec(pass, salt, iterations, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(raw, "AES")
    }

    /** Encrypted backup file: magic, salt, then IV + ciphertext. */
    fun seal(pass: CharArray, plain: ByteArray): ByteArray {
        val salt = randomBytes(16)
        return MAGIC + salt + encrypt(deriveKey(pass, salt), plain)
    }

    fun isSealed(blob: ByteArray): Boolean = blob.size > MAGIC.size + 16 + 28 && blob.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    fun open(pass: CharArray, blob: ByteArray): ByteArray {
        if (!isSealed(blob)) throw GeneralSecurityException("Not a NOVA backup")
        val salt = blob.copyOfRange(MAGIC.size, MAGIC.size + 16)
        return decrypt(deriveKey(pass, salt), blob.copyOfRange(MAGIC.size + 16, blob.size))
    }
}

data class VaultInfo(val id: Long, val label: String, val kind: VaultKind, val createdAt: Long, val updatedAt: Long)
data class VaultPlain(val label: String, val kind: VaultKind, val secret: String)

/**
 * The optional Secure Personal Vault. Secrets are encrypted with a key that lives in the Android Keystore and are stored only as
 * ciphertext. Nothing here is ever given to the AI model, written to a log or shown in a notification. The screen asks for
 * fingerprint / screen lock before it calls [reveal].
 */
class SecureVault(
    private val store: BrainStore,
    private val keyProvider: () -> SecretKey,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        private val secretish = Regex("[A-Za-z0-9_\\-]{24,}|\\d{9,}|(?i)\\b(password|passcode|otp|cvv)\\s*[:=]\\s*\\S+")
        fun labelLooksSecret(label: String): Boolean = secretish.containsMatchIn(label)
    }

    fun list(): List<VaultInfo> = store.vault().map { VaultInfo(it.id, it.label, it.kind, it.createdAt, it.updatedAt) }
    fun count(): Int = store.vault().size

    fun add(label: String, kind: VaultKind, secret: String): Long {
        require(label.isNotBlank()) { "Give the record a name." }
        require(!labelLooksSecret(label)) { "The name must not contain the secret itself. Put the secret in the hidden text field." }
        val now = clock()
        return store.saveVault(VaultRec(0, label.trim().take(60), kind, VaultCrypto.encrypt(keyProvider(), secret.toByteArray(Charsets.UTF_8)), now, now))
    }

    fun reveal(id: Long): String {
        val rec = store.vault().firstOrNull { it.id == id } ?: throw NoSuchElementException("Record not found")
        return String(VaultCrypto.decrypt(keyProvider(), rec.cipher), Charsets.UTF_8)
    }

    fun update(id: Long, secret: String) {
        val rec = store.vault().firstOrNull { it.id == id } ?: return
        store.saveVault(VaultRec(rec.id, rec.label, rec.kind, VaultCrypto.encrypt(keyProvider(), secret.toByteArray(Charsets.UTF_8)), rec.createdAt, clock()))
    }

    fun delete(id: Long) = store.deleteVault(id)
    fun deleteAll() = store.vault().forEach { store.deleteVault(it.id) }

    /** Decrypted copy for a user-requested, passphrase-protected backup. Only call after the user authenticated. */
    fun exportPlain(): List<VaultPlain> = store.vault().map { VaultPlain(it.label, it.kind, String(VaultCrypto.decrypt(keyProvider(), it.cipher), Charsets.UTF_8)) }

    fun importPlain(items: List<VaultPlain>): Int {
        var n = 0
        val existing = store.vault().map { it.label to it.kind }.toSet()
        for (p in items) if ((p.label to p.kind) !in existing) { add(p.label, p.kind, p.secret); n++ }
        return n
    }
}
