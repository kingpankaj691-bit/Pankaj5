package com.nova.ai.suite

import com.nova.ai.NovaApp
import com.nova.ai.security.Prefs
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.nova.ai.automation.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

data class GhRun(val id: Long, val name: String, val status: String, val conclusion: String, val branch: String, val url: String, val createdAt: String)
data class GhResult<T>(val value: T?, val error: String?)
data class GhArtifact(val id: Long, val name: String, val sizeBytes: Long, val expired: Boolean)
data class ApkFile(val file: File, val sha256: String, val sizeBytes: Long)

/**
 * GitHub Actions through the official REST API. The personal access token (fine-grained: Actions read/write on one repository) is
 * stored only in EncryptedSharedPreferences, sent only in the Authorization header to api.github.com, and never shown or logged.
 * There is no polling in the background: status is read when you ask or while the Developer screen is open.
 */
class GitHubActions(private val prefs: Prefs) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val json = "application/json".toMediaType()

    var token: String
        get() = prefs.secret("github_token")
        set(v) { prefs.setSecret("github_token", v) }
    private val settings = NovaApp.instance.getSharedPreferences("nova_prefs", 0)
    var repo: String
        get() = settings.getString("gh_repo", "") ?: ""
        set(v) { settings.edit().putString("gh_repo", v.trim()).apply() }
    var workflow: String
        get() = settings.getString("gh_workflow", "") ?: ""
        set(v) { settings.edit().putString("gh_workflow", v.trim()).apply() }
    var branch: String
        get() = settings.getString("gh_branch", "main") ?: "main"
        set(v) { settings.edit().putString("gh_branch", v.trim().ifBlank { "main" }).apply() }

    fun configured() = token.isNotBlank() && validRepo(repo)
    fun validRepo(r: String) = Regex("""^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$""").matches(r)

    private fun req(path: String) = Request.Builder().url("https://api.github.com$path")
        .header("Authorization", "Bearer $token").header("Accept", "application/vnd.github+json").header("X-GitHub-Api-Version", "2022-11-28")

    private fun <T> call(r: Request, parse: (okhttp3.Response) -> T): GhResult<T> = try {
        http.newCall(r).execute().use { resp ->
            when {
                resp.code == 401 -> GhResult(null, "GitHub rejected the token (401). Create a new fine-grained token with Actions access.")
                resp.code == 403 -> GhResult(null, "GitHub says forbidden (403): token lacks Actions permission or rate limit hit.")
                resp.code == 404 -> GhResult(null, "Not found (404): check repository and workflow name, and that the token can see the repository.")
                resp.code == 422 -> GhResult(null, "GitHub refused (422): the branch or workflow doesn't exist or the workflow has no workflow_dispatch trigger.")
                !resp.isSuccessful -> GhResult(null, "GitHub error ${resp.code}.")
                else -> GhResult(parse(resp), null)
            }
        }
    } catch (e: java.io.IOException) { GhResult(null, "No connection to GitHub.") } catch (e: Exception) { GhResult(null, "Problem: ${e.message ?: e.javaClass.simpleName}") }

    /** Starts the configured workflow on the configured branch. Call only after the user confirmed. */
    fun trigger(): GhResult<Boolean> {
        if (!configured() || workflow.isBlank()) return GhResult(null, "Set token, repository (owner/name) and workflow file first.")
        if (!Features.enabled(NovaApp.instance, Features.GITHUB)) return GhResult(null, Features.off("GitHub Actions"))
        val body = JSONObject().put("ref", branch).toString().toRequestBody(json)
        val started = System.currentTimeMillis()
        val r = call(req("/repos/$repo/actions/workflows/${workflow}/dispatches").post(body).build()) { true }
        if (r.error == null) GhBuildWorker.schedule(NovaApp.instance, started)
        return r
    }

    fun runs(limit: Int = 5): GhResult<List<GhRun>> {
        if (!configured()) return GhResult(null, "Set token and repository first.")
        return call(req("/repos/$repo/actions/runs?per_page=$limit").build()) { resp ->
            val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("workflow_runs")
            (0 until (arr?.length() ?: 0)).map { i ->
                val o = arr!!.getJSONObject(i)
                GhRun(o.optLong("id"), o.optString("name"), o.optString("status"), o.optString("conclusion"), o.optString("head_branch"), o.optString("html_url"), o.optString("created_at"))
            }
        }
    }

    /** First failed job/step names of a run, for a short explanation. */
    fun failedSteps(runId: Long): GhResult<List<String>> =
        call(req("/repos/$repo/actions/runs/$runId/jobs").build()) { resp ->
            val jobs = JSONObject(resp.body?.string().orEmpty()).optJSONArray("jobs")
            val out = ArrayList<String>()
            for (i in 0 until (jobs?.length() ?: 0)) {
                val j = jobs!!.getJSONObject(i); val steps = j.optJSONArray("steps") ?: continue
                for (s in 0 until steps.length()) { val st = steps.getJSONObject(s); if (st.optString("conclusion") == "failure") out.add(j.optString("name") + " › " + st.optString("name")) }
            }
            out
        }

    /** Downloads the run's log archive and returns the tail of the failing text (up to ~12 KB). Redacted before use. */
    fun logTail(runId: Long): GhResult<String> =
        call(req("/repos/$repo/actions/runs/$runId/logs").build()) { resp ->
            val bytes = resp.body?.bytes() ?: ByteArray(0)
            val sb = StringBuilder()
            ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                var e = z.nextEntry
                while (e != null && sb.length < 400_000) { if (!e.isDirectory) sb.append(z.bufferedReader().readText()).append('\n'); e = z.nextEntry }
            }
            LogAnalyzer.clean(sb.toString()).takeLast(12000)
        }

    /** Names of artifacts (e.g. the APK) of a finished run. The download itself needs your GitHub login, so Nova gives the run page link. */
    fun artifacts(runId: Long): GhResult<List<String>> =
        call(req("/repos/$repo/actions/runs/$runId/artifacts").build()) { resp ->
            val a = JSONObject(resp.body?.string().orEmpty()).optJSONArray("artifacts")
            (0 until (a?.length() ?: 0)).map { i -> a!!.getJSONObject(i).let { it.optString("name") + " (" + it.optLong("size_in_bytes") / 1024 / 1024 + " MB)" } }
        }


    /** Repositories this token can see (newest activity first), for a picker instead of typing owner/name. */
    fun myRepos(limit: Int = 50): GhResult<List<String>> {
        if (token.isBlank()) return GhResult(null, "Save a token first.")
        return call(req("/user/repos?per_page=$limit&sort=updated").build()) { resp ->
            val a = org.json.JSONArray(resp.body?.string().orEmpty())
            (0 until a.length()).map { a.getJSONObject(it).optString("full_name") }.filter { it.isNotBlank() }
        }
    }

    /** Workflow files of the selected repository: (display name, file name such as build.yml). */
    fun workflows(): GhResult<List<Pair<String, String>>> {
        if (!configured()) return GhResult(null, "Set token and repository first.")
        return call(req("/repos/$repo/actions/workflows").build()) { resp ->
            val a = JSONObject(resp.body?.string().orEmpty()).optJSONArray("workflows")
            (0 until (a?.length() ?: 0)).map { a!!.getJSONObject(it).let { o -> o.optString("name") to o.optString("path").substringAfterLast('/') } }
        }
    }

    fun artifactList(runId: Long): GhResult<List<GhArtifact>> =
        call(req("/repos/$repo/actions/runs/$runId/artifacts").build()) { resp ->
            val a = JSONObject(resp.body?.string().orEmpty()).optJSONArray("artifacts")
            (0 until (a?.length() ?: 0)).map { i -> a!!.getJSONObject(i).let { GhArtifact(it.optLong("id"), it.optString("name"), it.optLong("size_in_bytes"), it.optBoolean("expired")) } }
        }

    /**
     * Downloads an artifact with your token, checks it is a valid zip that really contains an .apk, extracts it into Nova's private
     * storage and returns its SHA-256 so you can compare it. Android's own installer then asks you to confirm the install.
     */
    fun downloadApk(ctx: Context, art: GhArtifact): GhResult<ApkFile> {
        if (art.expired) return GhResult(null, "That artifact has expired on GitHub (re-run the workflow).")
        if (art.sizeBytes > 300L * 1024 * 1024) return GhResult(null, "Artifact is larger than 300 MB; download it on GitHub instead.")
        return call(req("/repos/$repo/actions/artifacts/${art.id}/zip").build()) { resp ->
            val dir = File(ctx.filesDir, "apk").also { it.mkdirs() }
            val zip = File(dir, "artifact_${art.id}.zip")
            resp.body!!.byteStream().use { i -> zip.outputStream().use { o -> i.copyTo(o) } }
            val apkEntry: File = ZipFile(zip).use { z ->
                val e = z.entries().asSequence().firstOrNull { !it.isDirectory && it.name.endsWith(".apk", true) } ?: throw IllegalStateException("The artifact has no .apk file inside")
                val out = File(dir, File(e.name).name)
                z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                out
            }
            zip.delete()
            val md = MessageDigest.getInstance("SHA-256")
            apkEntry.inputStream().use { i -> val b = ByteArray(65536); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
            ApkFile(apkEntry, md.digest().joinToString("") { "%02x".format(it) }, apkEntry.length())
        }
    }

    fun installIntent(ctx: Context, apk: File): Intent =
        Intent(Intent.ACTION_VIEW).setDataAndType(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk), "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    fun describe(r: GhRun) = "${r.name.ifBlank { "run" }} on ${r.branch}: " + when {
        r.status != "completed" -> "running (${r.status})"
        r.conclusion == "success" -> "succeeded ✓"
        else -> "finished: ${r.conclusion}"
    }
}

/**
 * After you start a workflow, checks once a minute (max 25 times, then stops) whether the run finished and posts one notification:
 * "APK ready" or "Build failed". No polling happens when you haven't started a run.
 */
class GhBuildWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    companion object {
        fun schedule(ctx: Context, since: Long, tries: Int = 0) {
            val data = Data.Builder().putLong("since", since).putInt("tries", tries).build()
            WorkManager.getInstance(ctx).enqueueUniqueWork("nova_gh_build", androidx.work.ExistingWorkPolicy.REPLACE,
                OneTimeWorkRequestBuilder<GhBuildWorker>().setInitialDelay(60, java.util.concurrent.TimeUnit.SECONDS).setInputData(data).build())
        }
    }

    override suspend fun doWork(): Result {
        val app = applicationContext
        val since = inputData.getLong("since", 0L); val tries = inputData.getInt("tries", 0)
        val gh = GitHubActions(Prefs(app))
        if (!gh.configured()) return Result.success()
        val runs = withContext(Dispatchers.IO) { gh.runs(5) }.value
        val run = runs?.firstOrNull { r -> try { java.time.Instant.parse(r.createdAt).toEpochMilli() >= since - 90_000 } catch (e: Exception) { false } }
        if (run != null && run.status == "completed") {
            if (run.conclusion == "success") Notifier.post(app, 6200, "Build finished ✓", "Your APK is ready. Open Nova > More > Developer Integrations > GitHub Actions to download and verify it.")
            else Notifier.post(app, 6200, "Build failed", "The workflow ended with: ${run.conclusion}. Open Developer Integrations to read the log.")
            return Result.success()
        }
        if (tries < 25) schedule(app, since, tries + 1)
        return Result.success()
    }
}
