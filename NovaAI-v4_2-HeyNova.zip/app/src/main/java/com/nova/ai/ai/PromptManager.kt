package com.nova.ai.ai

/** Builds the extra prompt text that lets the LLM PLAN actions. The LLM only proposes; Nova's code decides and executes. */
object PromptManager {
    fun actionPlanning(): String = buildString {
        append("You may ask Nova to perform a device action. To do so, reply with ONLY one JSON object after the [emo:x] tag and nothing else, ")
        append("for example {\"action\":\"GET_BATTERY_STATUS\"}. Allowed actions: ")
        append(NovaAction.values().joinToString(", ") { it.name + if (it.takesArg) "(arg)" else "" })
        append(". Actions that take an argument use {\"action\":\"OPEN_APP\",\"arg\":\"youtube\"}. ")
        append("If no action is needed, answer normally in plain text. Never invent action names. ")
        append("You cannot run code, change protected settings or bypass Android permissions; Nova checks every action first.")
    }
}
