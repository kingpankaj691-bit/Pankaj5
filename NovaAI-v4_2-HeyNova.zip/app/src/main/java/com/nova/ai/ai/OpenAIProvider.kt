package com.nova.ai.ai

import com.nova.ai.core.AIProvider
import com.nova.ai.security.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * OpenAI Chat Completions over HTTPS (OkHttp). The key lives in encrypted prefs ([Prefs.openAiKey]) and is only ever sent
 * to api.openai.com. Nothing here touches Android privileged APIs: it only turns a conversation into text.
 */
class OpenAIProvider(private val prefs: Prefs) : AIProvider {

    companion object {
        const val ENDPOINT = "https://api.openai.com/v1/chat/completions"
        const val DEFAULT_MODEL = "gpt-4o-mini"
        private val JSON = "application/json; charset=utf-8".toMediaType()
        /** o-series and gpt-5 reasoning models only accept the default temperature. */
        private val FIXED_TEMPERATURE = Regex("^(o\\d|gpt-5).*", RegexOption.IGNORE_CASE)
        private val client: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
        }
    }

    override suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String?): AiResult {
        if (prefs.localOnly) return AiResult.Err("Local-only mode is on. OpenAI is not used.")
        val key = prefs.openAiKey
        if (key.isBlank()) return AiResult.Err("No OpenAI API key set. Add one in Settings.")
        val m = (model ?: prefs.openAiModel).trim().ifBlank { DEFAULT_MODEL }
        return try {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            history.forEach { (isUser, text) ->
                msgs.put(JSONObject().put("role", if (isUser) "user" else "assistant").put("content", text))
            }
            val body = JSONObject().put("model", m).put("messages", msgs).put("max_completion_tokens", prefs.maxTokens)
            if (!FIXED_TEMPERATURE.matches(m)) body.put("temperature", prefs.temperature.toDouble())
            val req = Request.Builder().url(ENDPOINT)
                .header("Authorization", "Bearer $key")
                .post(body.toString().toRequestBody(JSON)).build()
            client.newCall(req).await().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val text = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("message")?.optString("content").orEmpty().trim()
                    if (text.isEmpty()) AiResult.Err("OpenAI returned an empty answer.") else AiResult.Ok(text)
                } else {
                    val detail = try { JSONObject(raw).getJSONObject("error").optString("message") } catch (e: Exception) { "" }
                    AiResult.Err(when (resp.code) {
                        401 -> "OpenAI rejected the API key. Check the key."
                        403 -> "OpenAI says this key or region is not allowed. $detail"
                        404 -> "Model '$m' not found for this key. Change the OpenAI model in Settings."
                        429 -> "OpenAI quota or rate limit reached. Try again later. $detail".trim()
                        in 500..599 -> "OpenAI server error (${resp.code}). Try again."
                        else -> "OpenAI error ${resp.code}: $detail"
                    })
                }
            }
        } catch (e: UnknownHostException) {
            AiResult.Err("No internet connection. Local commands still work.")
        } catch (e: SocketTimeoutException) {
            AiResult.Err("OpenAI timed out. Check your connection.")
        } catch (e: IOException) {
            AiResult.Err("Network error: ${e.message}")
        } catch (e: org.json.JSONException) {
            AiResult.Err("OpenAI sent an answer Nova could not read.")
        }
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { c ->
        c.invokeOnCancellation { try { cancel() } catch (_: Throwable) { } }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (c.isActive) c.resumeWithException(e) }
            override fun onResponse(call: Call, response: Response) { if (c.isActive) c.resume(response) else response.close() }
        })
    }
}
