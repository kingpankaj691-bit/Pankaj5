package com.nova.ai.automation

import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nova.ai.device.DeviceChangeDetector
import com.nova.ai.jarvis.CarMode
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.memory.MemoryDb
import com.nova.ai.voice.NovaVoiceForegroundService
import com.nova.ai.voice.VoicePermissionManager
import java.io.File

/**
 * Runs after Android has booted. It restores/validates local state and posts "NOVA initialized".
 * It does NOT start the microphone: Android blocks microphone foreground services from boot receivers,
 * so Background Voice resumes only when the user taps "Resume listening" in the notification.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        Thread {
            try {
                val app = ctx.applicationContext
                val sp = app.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)
                sp.edit().putLong("last_boot_init", System.currentTimeMillis()).apply()
                val db = MemoryDb.get(app)
                db.purge(System.currentTimeMillis(), sp.getInt("mem_expiry_days", 180))
                val memories = db.countMemories()
                val hasProfile = File(app.filesDir, "device_profile.json").exists()
                AutomationEngine(app, db).rescheduleAll()
                if (sp.getBoolean("secmode_on", false)) {
                    // Security Mode never re-arms silently after a restart: tell the user and let them choose.
                    sp.edit().putBoolean("secmode_on", false).apply()
                    Notifier.post(app, 6103, "Security Mode was turned off", "The phone restarted. Open Nova to turn Security Mode on again.")
                }
                Maintenance.schedule(app)
                try { com.nova.ai.brain.Brain.get(app).rescheduleReminders() } catch (e: Exception) { }
                try { com.nova.ai.suite.SecurityWatch.log(app, "boot", "Phone restarted; Nova checked its permissions"); com.nova.ai.suite.SecurityWatch.check(app) } catch (e: Exception) { }
                val changes = DeviceChangeDetector(app).detect()
                val actions = mutableListOf<Pair<String, PendingIntent>>()
                if (sp.getBoolean("bg_enabled", false) && VoicePermissionManager.canStart(app)) {
                    actions.add("Resume listening" to PendingIntent.getForegroundService(app, 7,
                        Intent(app, NovaVoiceForegroundService::class.java).setAction(NovaVoiceForegroundService.ACTION_START), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                }
                val text = "$memories memories and your settings restored" + (if (hasProfile) ", device profile restored" else "") +
                    (if (changes.isNotEmpty()) ". ${changes.size} change(s) detected: open NOVA to rescan." else ".")
                Notifier.post(app, 4001, "NOVA initialized", text, Notifier.openApp(app), actions)
            } finally { pending.finish() }
        }.start()
    }
}

/** Fires "when my headphones connect" routines. Android may not deliver this on every device. */
class BluetoothTriggerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED && intent.action != BluetoothDevice.ACTION_ACL_DISCONNECTED) return
        val name = try {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)?.name ?: ""
        } catch (e: Exception) { "" }
        // Car mode follows your car's Bluetooth (set the name in Jarvis settings).
        val car = JarvisPrefs(ctx).carBtName
        if (car.isNotBlank() && name.contains(car, true)) {
            if (intent.action == BluetoothDevice.ACTION_ACL_CONNECTED) CarMode.enable(ctx, fromBluetooth = true) else CarMode.disable(ctx)
        }
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
        val db = MemoryDb.get(ctx)
        val now = System.currentTimeMillis()
        db.routines().filter { it.enabled && it.trigger == "BT_CONNECTED" && (it.trigValue.isBlank() || name.contains(it.trigValue, true)) && now - it.lastFired > 60000 }
            .forEach { fireRoutine(ctx, it); db.markFired(it.id, now) }
    }
}
