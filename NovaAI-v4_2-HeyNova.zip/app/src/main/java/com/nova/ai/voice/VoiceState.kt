package com.nova.ai.voice

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/** What the Background Voice pipeline is doing right now. */
enum class VoiceStatus {
    /** Service is not running. */
    Off,
    /** Service is starting and the microphone is being opened. */
    Starting,
    /** AudioRecord is open and PCM is flowing. Microphone is ON. */
    Listening,
    /** The user pressed Pause. Microphone is released. */
    Paused,
    /** Android or another app took the microphone (call, other recorder). Microphone is released or silenced. */
    Interrupted
}

/** Process-wide, read-only-for-the-UI view of Background Voice. The service is the only writer. */
object VoiceState {
    /** True while the foreground service is alive (also while paused). */
    val running = MutableStateFlow(false)
    /** True after the user pressed Pause (service stays alive, microphone released). */
    val paused = MutableStateFlow(false)
    val status = MutableStateFlow(VoiceStatus.Off)
    /** Human readable line about the microphone ("Microphone: built-in", "Phone call in progress"...). */
    val detail = MutableStateFlow("")
    /** Last speech-recognition / Gemini / network problem. Empty when healthy. */
    val problem = MutableStateFlow("")
    /** Last recognized text (kept in RAM only, never written to disk by this subsystem). */
    val heard = MutableStateFlow("")
    /** Which voice pipeline is active for the selected Gemini model ("Native Gemini Live · model" or "Speech-to-Text → model → Text-to-Speech"). */
    val voiceMode = MutableStateFlow("")
    /** True while Nova's own TTS is talking; captured audio is dropped so Nova does not hear itself. */
    val speaking = MutableStateFlow(false)

    /** True while the offline wake word is in charge: anything that reaches the command stage was said after the name. */
    @Volatile var wakeGated = false
    /** What Nova said last (lower case), so the recognizer can ignore her own voice. */
    @Volatile var lastSpoken: String = ""
    /** Every TTS player registers here so "interrupt" can silence all of them. */
    val speechStoppers = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()
    fun interruptSpeech() { speechStoppers.forEach { try { it() } catch (e: Exception) { } } }

    private const val PREFS = "nova_prefs"
    private const val KEY = "bg_enabled"

    /** Same key as Prefs.bgEnabled. Read directly so the service does not need encrypted prefs just for a flag. */
    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply()
    }

    /** Called when the service is gone. [detail] is kept so the UI can still show why it stopped. */
    fun reset() {
        running.value = false
        paused.value = false
        status.value = VoiceStatus.Off
        problem.value = ""
        heard.value = ""
        speaking.value = false
        voiceMode.value = ""
    }
}

/**
 * Recognized commands go here. When the app UI is alive its ViewModel collects them and runs them through the full
 * CommandRouter (screen control, people, web search...). With no collector, the service answers on its own.
 */
object VoiceBus {
    val commands = MutableSharedFlow<String>(extraBufferCapacity = 8)
    fun uiIsListening(): Boolean = commands.subscriptionCount.value > 0
}
