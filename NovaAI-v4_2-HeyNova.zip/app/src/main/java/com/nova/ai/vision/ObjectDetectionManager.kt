package com.nova.ai.vision

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

/**
 * On-device scene understanding. The image labeler names what is in view, and the object detector counts separate objects.
 * These are estimates from a small general model, so Nova words them as "looks like", never as certain facts.
 */
class ObjectDetectionManager {
    private val labeler: ImageLabeler = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build())
    private val detector: ObjectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder().setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE).enableMultipleObjects().build()
    )

    fun describe(input: InputImage, done: (String) -> Unit) {
        var labels: List<String>? = null
        var objects: Int? = null
        fun finish() {
            val l = labels ?: return
            val o = objects ?: return
            done(sentence(l, o))
        }
        labeler.process(input).addOnSuccessListener { r -> labels = r.sortedByDescending { it.confidence }.map { it.text.lowercase() }.distinct().take(4); finish() }
            .addOnFailureListener { labels = emptyList(); finish() }
        detector.process(input).addOnSuccessListener { objects = it.size; finish() }.addOnFailureListener { objects = 0; finish() }
    }

    private fun sentence(labels: List<String>, objects: Int): String {
        if (labels.isEmpty() && objects == 0) return "Camera ke saamne kuch clear pehchaan nahi paaya. Roshni badhaiye ya cheez paas laaiye."
        val sb = StringBuilder()
        if (labels.isNotEmpty()) {
            sb.append("Camera ke saamne ek ").append(labels[0]).append(" jaisa object dikh raha hai.")
            if (labels.size > 1) sb.append(" Aur shayad: ").append(labels.drop(1).joinToString(", ")).append(".")
        }
        if (objects > 1) sb.append(" Mujhe lagbhag ").append(objects).append(" alag cheezein dikh rahi hain.")
        sb.append(" (Ye phone par chalne wale chhote model ka andaaza hai.)")
        return sb.toString()
    }

    fun close() { try { labeler.close(); detector.close() } catch (e: Exception) { } }
}
