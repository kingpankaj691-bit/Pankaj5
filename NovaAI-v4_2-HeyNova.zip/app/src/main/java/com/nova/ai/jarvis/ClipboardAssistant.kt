package com.nova.ai.jarvis

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.nova.ai.modules.GeminiTask
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Watches for "something was copied" while Background Voice runs.
 * Android 10+ does not let a background app read the clipboard, so Nova only learns THAT something was copied. She then opens a
 * small see-through card (allowed because of the "display over other apps" permission); only that card, being on screen, reads
 * the text. Long text gets Summarize / Translate buttons, short text closes the card at once. Password-manager copies are skipped.
 */
class ClipboardWatcher(private val ctx: Context) {
    private val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    private val main = Handler(Looper.getMainLooper())
    private var last = 0L
    private val listener = ClipboardManager.OnPrimaryClipChangedListener {
        val now = System.currentTimeMillis()
        if (now - last < 2500) return@OnPrimaryClipChangedListener
        last = now
        val d = try { cm.primaryClipDescription } catch (e: Exception) { null } ?: return@OnPrimaryClipChangedListener
        if (!d.hasMimeType("text/*")) return@OnPrimaryClipChangedListener
        if (d.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return@OnPrimaryClipChangedListener
        if (!Settings.canDrawOverlays(ctx)) return@OnPrimaryClipChangedListener
        main.postDelayed({
            try { ctx.startActivity(Intent(ctx, ClipboardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)) } catch (e: Exception) { }
        }, 300)
    }
    private var on = false

    fun start() { if (on) return; on = true; try { cm.addPrimaryClipChangedListener(listener) } catch (e: Exception) { on = false } }
    fun stop() { if (!on) return; on = false; try { cm.removePrimaryClipChangedListener(listener) } catch (e: Exception) { } }
}

class ClipboardActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var read = false
    private lateinit var card: LinearLayout
    private lateinit var result: TextView
    private var text = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#66000000"))
        root.setOnClickListener { finish() }
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 40, 48, 40)
            background = GradientDrawable().apply { setColor(Color.parseColor("#F2202428")); cornerRadius = 48f }
            visibility = View.GONE
            isClickable = true
        }
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(32, 0, 32, 96) })
        setContentView(root)
    }

    /** Only a window that has focus may read the clipboard. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || read) return
        read = true
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        text = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty() } catch (e: Exception) { "" }
        if (text.length < JarvisPrefs(this).clipMinChars) { finish(); return }
        show()
    }

    private fun tv(s: String, size: Float, color: String = "#FFFFFF") = TextView(this).apply { this.text = s; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, 8, 0, 8) }
    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply { this.text = label; isAllCaps = false; setOnClickListener { onClick() } }

    private fun show() {
        card.visibility = View.VISIBLE
        card.addView(tv("Lamba text copy hua (${text.length} akshar). Kya karun?", 16f))
        card.addView(tv(text.take(140).replace("\n", " ") + "…", 13f, "#B0BEC5"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("Summarize") { run("Summarize this text in the same language as the text, in at most 4 short sentences. No bullets.") })
        row.addView(btn("→ English") { run("Translate this text into English. Output only the translation.") })
        row.addView(btn("→ Hindi") { run("Translate this text into Hindi (Devanagari). Output only the translation.") })
        card.addView(row)
        result = tv("", 14f)
        card.addView(ScrollView(this).apply { addView(result); layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 600) })
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(btn("Read aloud") { if (result.text.isNotBlank()) Announcer.speak(this, result.text.toString()) })
        row2.addView(btn("Close") { finish() })
        card.addView(row2)
    }

    private fun run(instruction: String) {
        val prefs = Prefs(this)
        if (prefs.localOnly) { result.text = "Local-only mode is on, so nothing is sent to Gemini."; return }
        result.text = "Working…"
        scope.launch { result.text = GeminiTask(prefs).run(instruction, text.take(30000), maxTokens = 900) }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
