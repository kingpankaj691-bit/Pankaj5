package com.nova.ai.forge

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

enum class ForgePhase { IDLE, BUILDING, DONE, FAILED, CANCELLED }
data class ForgeMetrics(val chars: Int = 0, val sections: Int = 0, val elapsedSec: Int = 0, val tokensPerSec: Int = 0)
data class ForgeUiState(
    val phase: ForgePhase = ForgePhase.IDLE,
    val prompt: String = "",
    val isEdit: Boolean = false,
    val stage: ForgeStage = ForgeStage.PLANNING,
    val progress: Float = 0f,
    val metrics: ForgeMetrics = ForgeMetrics(),
    val sections: List<String> = emptyList(),
    val log: List<String> = emptyList(),
    val logSeq: Int = 0,
    val buildId: Int = 0,
    val file: File? = null,
    val error: String? = null
)

sealed class ForgeStart(val message: String) {
    object Started : ForgeStart("Opening the Forge. Building your website now.")
    object MissingKey : ForgeStart("I need a Gemini API key first. Add it in Settings.")
    object Offline : ForgeStart("You're offline. Connect to the internet and try again.")
    object Busy : ForgeStart("I'm already building a website. Wait for it to finish or cancel it.")
    object NothingToEdit : ForgeStart("There is no website to edit yet. Ask me to build one first.")
}

/** Process-wide website builder. Runs in its own scope, so it keeps going while the user leaves the screen. */
object ForgeController {
    const val EXTRA_OPEN_FORGE = "open_forge"
    private const val CHANNEL = "nova_forge"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(ForgeUiState())
    val state: StateFlow<ForgeUiState> = _state
    val pendingOpen = MutableStateFlow(false)
    @Volatile var screenVisible = false

    private val htmlLock = Any()
    private val html = StringBuilder()
    private var job: Job? = null
    private var lastPrompt = ""
    private var lastEdit: String? = null
    private var seq = 0

    fun requestOpen() { pendingOpen.value = true }
    fun consumeOpen(): Boolean { val v = pendingOpen.value; pendingOpen.value = false; return v }
    fun partialHtml(): String = synchronized(htmlLock) { html.toString() }

    private fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return true
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun check(ctx: Context): ForgeStart? {
        if (_state.value.phase == ForgePhase.BUILDING) return ForgeStart.Busy
        if (Prefs(ctx).apiKey.isBlank()) return ForgeStart.MissingKey
        if (!online(ctx)) return ForgeStart.Offline
        return null
    }

    fun start(ctx: Context, prompt: String): ForgeStart {
        val app = ctx.applicationContext
        check(app)?.let { return it }
        lastPrompt = prompt; lastEdit = null
        launchBuild(app, prompt, false, ForgeSystemPrompt.forNewSite(prompt))
        return ForgeStart.Started
    }

    fun edit(ctx: Context, change: String): ForgeStart {
        val app = ctx.applicationContext
        val current = synchronized(htmlLock) { html.toString() }
        if (current.isBlank() || _state.value.phase == ForgePhase.IDLE && _state.value.file == null) return ForgeStart.NothingToEdit
        check(app)?.let { return it }
        lastEdit = change
        launchBuild(app, change, true, ForgeSystemPrompt.forEdit(current, change))
        return ForgeStart.Started
    }

    fun retry(ctx: Context): ForgeStart = if (lastEdit != null) edit(ctx, lastEdit!!) else if (lastPrompt.isNotBlank()) start(ctx, lastPrompt) else ForgeStart.NothingToEdit

    fun cancel() {
        job?.cancel()
        if (_state.value.phase == ForgePhase.BUILDING) _state.value = _state.value.copy(phase = ForgePhase.CANCELLED)
    }

    fun reset() { job?.cancel(); synchronized(htmlLock) { html.setLength(0) }; _state.value = ForgeUiState(buildId = _state.value.buildId) }

    fun openSaved(file: File) {
        val text = try { file.readText() } catch (e: Exception) { return }
        synchronized(htmlLock) { html.setLength(0); html.append(text) }
        _state.value = ForgeUiState(phase = ForgePhase.DONE, prompt = file.nameWithoutExtension, stage = ForgeStage.FINISHING, progress = 1f,
            metrics = ForgeMetrics(chars = text.length, sections = ForgeStageDetector.sections(text).size), sections = ForgeStageDetector.sections(text),
            buildId = _state.value.buildId + 1, file = file)
    }

    fun saved(ctx: Context): List<File> =
        File(ctx.applicationContext.filesDir, "Websites").listFiles { f -> f.name.endsWith(".html") }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun delete(file: File) {
        try { file.delete() } catch (e: Exception) { }
        if (_state.value.file == file) reset()
    }

    private fun log(msg: String) {
        val s = _state.value
        _state.value = s.copy(log = (s.log + msg).takeLast(40), logSeq = s.logSeq + 1)
    }

    private fun launchBuild(app: Context, label: String, isEdit: Boolean, user: String) {
        job?.cancel()
        synchronized(htmlLock) { if (!isEdit) html.setLength(0) }
        val id = _state.value.buildId + 1
        _state.value = ForgeUiState(phase = ForgePhase.BUILDING, prompt = label, isEdit = isEdit, buildId = id, log = listOf(if (isEdit) "Applying your change" else "Starting the build"))
        job = scope.launch {
            try { run(app, user, isEdit) } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { fail("Something went wrong while building. Please try again.") }
        }
    }

    private fun fail(msg: String) { _state.value = _state.value.copy(phase = ForgePhase.FAILED, error = msg) }

    private suspend fun run(app: Context, user: String, isEdit: Boolean) {
        val prefs = Prefs(app)
        val client = WebsiteForgeClient(prefs.apiKey, prefs.model)
        val started = SystemClock.elapsedRealtime()
        var lastEmit = 0L
        var lastStage = ForgeStage.PLANNING
        var lastSections = 0
        var lastKb = 0
        val buf = StringBuilder()

        fun emit(force: Boolean) {
            val now = SystemClock.elapsedRealtime()
            if (!force && now - lastEmit < 120) return
            lastEmit = now
            val text = buf.toString()
            val stage = ForgeStageDetector.detect(text)
            val secs = ForgeStageDetector.sections(text)
            val el = ((now - started) / 1000).toInt()
            if (stage != lastStage) { lastStage = stage; log(stage.label) }
            while (lastSections < secs.size) { log("Laying out ${secs[lastSections]}"); lastSections++ }
            val kb = text.length / 10_000
            if (kb > lastKb) { lastKb = kb; log("${kb * 10} KB written") }
            val tps = if (el > 0) (text.length / 4) / el else 0
            _state.value = _state.value.copy(stage = stage, progress = ForgeStageDetector.progress(stage, text.length), sections = secs,
                metrics = ForgeMetrics(text.length, secs.size, el, tps))
            synchronized(htmlLock) { html.setLength(0); html.append(text) }
        }

        suspend fun attempt(userMsg: String): WebsiteForgeClient.Result {
            buf.setLength(0)
            return client.stream(ForgeSystemPrompt.SYSTEM, userMsg) { buf.append(it); emit(false) }
        }

        var res = attempt(user)
        if (res.error == "OVERLOADED") { log("Gemini is busy, retrying"); delay(4000); res = attempt(user) }
        if (res.error != null && res.text.isBlank()) { fail(if (res.error == "OVERLOADED") ForgeErrors.friendly(503, "") else res.error!!); return }
        if (res.finishReason != null && res.finishReason != "STOP") Log.w("Forge", "finishReason=${res.finishReason}")

        var out = ForgeHtml.stripFences(res.text)
        val incomplete = { s: String -> s.length < 1500 || !s.contains("</html>", true) }
        if (incomplete(out)) {
            log("Retrying for a complete page")
            res = attempt(user + ForgeSystemPrompt.RETRY_HINT)
            out = ForgeHtml.stripFences(res.text)
        }
        if (!ForgeHtml.looksLikeHtml(out)) { fail("Gemini didn't return a web page. Try describing it differently."); return }
        if (!out.contains("</html>", true)) {
            if (out.length >= 14_000) out = ForgeHtml.repairTruncated(out) else { fail("Gemini stopped before finishing. Please try again."); return }
        }
        val finalHtml = ForgeHtml.withSafetyNet(out)
        buf.setLength(0); buf.append(finalHtml); emit(true)
        val dir = File(app.filesDir, "Websites").apply { mkdirs() }
        val file = File(dir, "website_${System.currentTimeMillis()}.html")
        file.writeText(finalHtml)
        val secs = ForgeStageDetector.sections(finalHtml)
        _state.value = _state.value.copy(phase = ForgePhase.DONE, stage = ForgeStage.FINISHING, progress = 1f, file = file, sections = secs,
            metrics = _state.value.metrics.copy(chars = finalHtml.length, sections = secs.size))
        log("Done")
        if (!screenVisible) notifyReady(app)
    }

    private fun notifyReady(app: Context) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Website Forge", NotificationManager.IMPORTANCE_DEFAULT))
            val i = Intent(app, com.nova.ai.ui.MainActivity::class.java).putExtra(EXTRA_OPEN_FORGE, true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(app, 91, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(91, NotificationCompat.Builder(app, CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Your website is ready").setContentText("Tap to open it.").setAutoCancel(true).setContentIntent(pi).build())
        } catch (e: SecurityException) { }
    }
}
