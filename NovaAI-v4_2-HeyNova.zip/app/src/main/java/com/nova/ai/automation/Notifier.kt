package com.nova.ai.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.nova.ai.ui.MainActivity

/** All reminder/automation/boot notifications go through here. Nothing acts silently: the user taps to proceed. */
object Notifier {
    const val CH = "nova_info"

    fun ensureChannel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "NOVA reminders and status", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun openApp(ctx: Context, extraListen: Boolean = false): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (extraListen) i.putExtra("listen", true)
        return PendingIntent.getActivity(ctx, if (extraListen) 1 else 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun launchPackage(ctx: Context, pkg: String): PendingIntent? {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return null
        return PendingIntent.getActivity(ctx, pkg.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(ctx: Context, id: Int, title: String, text: String, tap: PendingIntent? = openApp(ctx), actions: List<Pair<String, PendingIntent>> = emptyList()) {
        try {
            ensureChannel(ctx)
            if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(title).setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            if (tap != null) b.setContentIntent(tap)
            actions.forEach { b.addAction(0, it.first, it.second) }
            NotificationManagerCompat.from(ctx).notify(id, b.build())
        } catch (e: SecurityException) { }
    }
}
