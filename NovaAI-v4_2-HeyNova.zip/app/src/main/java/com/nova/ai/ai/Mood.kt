package com.nova.ai.ai

import androidx.compose.ui.graphics.Color

/** Conversational tone inferred from text only. Never a diagnosis; it only shapes how Nova talks. */
enum class Mood { Happy, Sad, Angry, Frustrated, Excited, Confused, Tired, Calm, Serious, Playful, Neutral }

enum class Emotion(
    val label: String, val rate: Float, val pitch: Float,
    val smile: Float, val browTilt: Float, val browRaise: Float, val lid: Float, val cheek: Float,
    val tint: Color, val hint: String
) {
    Normal("Normal", 1f, 1f, 0.25f, 0f, 0f, 1f, 0f, Color(0xFF4FC3F7), "Natural, warm and balanced."),
    Happy("Happy", 1.05f, 1.06f, 0.8f, 0f, 0.02f, 1f, 0.5f, Color(0xFFFFD54F), "Upbeat and warm, slightly more energetic."),
    Playful("Playful", 1.05f, 1.05f, 0.55f, 0f, 0f, 1f, 0.4f, Color(0xFFFF8AD8), "Light teasing and humor. Keep it kind."),
    Attitude("Attitude", 0.95f, 0.97f, 0.15f, 0.3f, 0f, 0.85f, 0f, Color(0xFFB388FF), "Confident and a little sassy with short witty lines. Never rude."),
    Nakhra("Nakhra", 0.92f, 1.04f, -0.05f, 0.15f, 0.02f, 0.9f, 0.3f, Color(0xFFFF80AB), "Playful nakhra: mock-complaining, short teasing replies, warm underneath. Soften as soon as the user apologizes."),
    MockAngry("Mock angry", 0.95f, 0.98f, -0.3f, 0.6f, -0.01f, 0.8f, 0.1f, Color(0xFFFF8A65), "Lightly mock-annoyed and clearly playful. Never insulting, threatening, humiliating or guilt-tripping. Reconcile quickly."),
    Disappointed("Disappointed", 0.9f, 0.95f, -0.35f, -0.5f, 0.02f, 0.7f, 0f, Color(0xFF90A4AE), "Mildly disappointed but kind. Short sentences. No guilt-tripping."),
    Calm("Calm", 0.92f, 0.97f, 0.2f, 0f, 0f, 0.78f, 0f, Color(0xFF80DEEA), "Calm, short, reassuring and supportive. Simple words."),
    Professional("Professional", 1f, 0.97f, 0.1f, 0f, 0f, 1f, 0f, Color(0xFF90CAF9), "Clear, precise and professional. No slang."),
    Serious("Serious", 0.97f, 0.95f, 0f, 0.1f, 0f, 1f, 0f, Color(0xFF9FA8DA), "Serious and focused. No jokes."),
    Excited("Excited", 1.1f, 1.1f, 1f, 0f, 0.04f, 1f, 0.5f, Color(0xFFFFB74D), "Energetic and enthusiastic with short exclamations.");

    val tag: String get() = if (this == MockAngry) "mock_angry" else name.lowercase()

    companion object {
        fun fromTag(s: String): Emotion? = values().firstOrNull { it.tag == s.trim().lowercase() }
        val tagList: String get() = values().joinToString(",") { it.tag }
    }
}

object MoodEngine {
    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    fun detect(text: String, prev: String? = null): Mood {
        val t = text.lowercase()
        val m = when {
            has(t, "gussa aa", "angry", "hate this", "bakwas", "irritat", "pissed", "furious") -> Mood.Angry
            has(t, "not working", "nahi chal", "kaam nahi", "kyu nahi", "kyun nahi", "still not", "useless", "fed up", "pareshan", "stuck") || t.count { it == '!' } >= 3 -> Mood.Frustrated
            has(t, "i am sad", "i'm sad", "dukhi", "udaas", "lonely", "feeling low") -> Mood.Sad
            has(t, "tired", "thak", "sleepy", "neend", "exhausted") -> Mood.Tired
            has(t, "confused", "samajh nahi", "don't understand", "dont understand", "kya matlab", "what do you mean") -> Mood.Confused
            has(t, "wow", "yay", "amazing", "awesome", "mast", "let's go", "lets go", "chalo", "superb", "😍", "🔥") -> Mood.Excited
            has(t, "haha", "lol", "😂", "🤣", "😜", "joke", "mazak", "tease", "hehe", "naraz", "attitude", "nakhra") -> Mood.Playful
            has(t, "thanks", "thank you", "shukriya", "dhanyavaad", "love it", "great job", "khush", "😊", "😄") -> Mood.Happy
            has(t, "urgent", "important", "serious", "zaroori", "zaruri", "deadline") -> Mood.Serious
            else -> Mood.Neutral
        }
        if (m == Mood.Neutral && prev != null) {
            val p = detect(prev, null)
            if (p in setOf(Mood.Angry, Mood.Frustrated, Mood.Sad, Mood.Tired, Mood.Confused)) return p
        }
        return m
    }

    fun derive(p: Personality, mood: Mood, override: String, text: String, developer: Boolean): Emotion {
        if (developer) return Emotion.Professional
        when (override.lowercase()) {
            "calm" -> return Emotion.Calm
            "happy" -> return Emotion.Happy
            "funny", "playful" -> return Emotion.Playful
            "serious" -> return Emotion.Serious
            "professional" -> return Emotion.Professional
        }
        val t = text.lowercase()
        if (p == Personality.GFMode) {
            if (has(t, "sorry", "maaf", "manao", "manaunga", "manaungi")) return Emotion.Happy
            if (has(t, "attitude", "nakhra")) return Emotion.Nakhra
            if (has(t, "naraz", "gussa ho", "gussa kar", "jealous", "jalan")) return Emotion.MockAngry
        }
        if (mood in setOf(Mood.Angry, Mood.Frustrated, Mood.Sad, Mood.Tired, Mood.Confused)) return Emotion.Calm
        return when (mood) {
            Mood.Happy -> Emotion.Happy
            Mood.Excited -> Emotion.Excited
            Mood.Playful -> Emotion.Playful
            Mood.Serious -> Emotion.Serious
            Mood.Calm -> Emotion.Calm
            else -> p.defaultEmotion
        }
    }

    fun moodNote(m: Mood): String = when (m) {
        Mood.Angry, Mood.Frustrated -> "The user seems frustrated. Be calm, short and supportive; fix things step by step."
        Mood.Sad -> "The user seems low. Be gentle and warm. Do not diagnose or comment on mental health."
        Mood.Tired -> "The user seems tired. Keep it concise."
        Mood.Confused -> "The user seems confused. Explain simply, step by step."
        Mood.Excited -> "The user is excited. Match the energy briefly."
        Mood.Playful -> "The user is joking. You may respond playfully."
        Mood.Serious -> "The user is serious. Be calm and professional."
        else -> ""
    }
}
