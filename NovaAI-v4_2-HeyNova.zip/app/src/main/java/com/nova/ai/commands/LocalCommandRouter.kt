package com.nova.ai.commands

import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.Personality
import com.nova.ai.core.CommandExecutor
import com.nova.ai.core.MemoryManager
import com.nova.ai.device.DeviceController
import com.nova.ai.memory.MemoryDb
import com.nova.ai.notifications.NovaNotificationListener
import com.nova.ai.people.PeopleCommands
import com.nova.ai.people.PeopleMemoryManager
import com.nova.ai.plugins.PluginRegistry
import com.nova.ai.security.Prefs
import com.nova.ai.voice.VoiceManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Cat { DEVICE_SCAN, LOCAL_DEVICE_COMMAND, APP_COMMAND, VOICE_COMMAND, SCREEN_COMMAND, AI_QUERY, DEVELOPER_COMMAND, SETTINGS_COMMAND, GENERAL_QUERY }
enum class Level { Info, Action, Sensitive }

/**
 * exec runs the command and returns what Nova should say (blank = say nothing); it is deferred so confirmation/auth can happen first.
 * tag is used by the lock-screen policy; sensitiveInfo marks commands that reveal private data.
 */
data class CmdResult(
    val handled: Boolean, val cat: Cat = Cat.AI_QUERY, val prompt: String = "",
    val level: Level = Level.Info, val exec: () -> String = { "" },
    val tag: String = "", val sensitiveInfo: Boolean = false
)

/** A question Nova asks when a name or relation matches more than one saved person. */
class Clarification(val title: String, val options: List<Pair<String, () -> String>>) { var onCancel: (() -> Unit)? = null }

class RouterHooks(
    val talkNormally: () -> Unit, val setAiContext: (String) -> Unit,
    val startScan: () -> Unit, val showScan: () -> Unit, val scanReport: () -> String?, val deleteScan: () -> Unit,
    val wifiConnect: () -> Unit, val btConnected: () -> Unit, val btScan: () -> Unit,
    val reminder: (String) -> (() -> String)?, val lastUserMessage: () -> String?,
    val changesReport: () -> String, val switchPersonality: (Personality) -> Unit,
    val clarify: (Clarification) -> Unit, val confirm: (String, () -> String) -> Unit
)

/** Runs everything that doesn't need an AI. It is always tried first, online or offline. */
class LocalCommandRouter(
    private val device: DeviceController,
    private val memory: MemoryManager,
    private val db: MemoryDb,
    private val prefs: Prefs,
    private val voice: VoiceManager,
    private val plugins: PluginRegistry,
    private val people: PeopleMemoryManager,
    private val hooks: RouterHooks
) : CommandExecutor {
    private val peopleCmds = PeopleCommands(people, device, prefs, memory, hooks)
    private val modeCmds = ModeCommands(device, memory, prefs, db)
    private val secVisionCmds = SecurityVisionCommands(prefs)
    private val devCmds = DeveloperCommands()
    private val suiteCmds = com.nova.ai.suite.SuiteCommands()
    private val controlCmds = com.nova.ai.control.ControlCommands()
    private val mediaCmds = com.nova.ai.media.MediaCommands()
    private val fileCmds = com.nova.ai.files.FileCommands()
    private val a11yHelp = "Screen control is off. Open Settings, then Screen Assistant, and enable Nova AI."
    private fun vary(vararg s: String) = s.random()

    private fun cmd(cat: Cat, level: Level = Level.Info, prompt: String = "", tag: String = "", sensitiveInfo: Boolean = false, run: () -> String) =
        CmdResult(true, cat, prompt, level, run, tag, sensitiveInfo)

    override fun route(raw: String): CmdResult {
        val low = raw.lowercase().trim()
        val t = low.removePrefix("hey nova").removePrefix("nova").trim(' ', ',', '.', '!', '?')
        fun has(vararg w: String) = w.any { t.contains(it) }

        // ── VOICE ──
        if (t == "stop" || has("stop talking", "stop speaking", "chup ho", "chup karo", "ruko"))
            return cmd(Cat.VOICE_COMMAND, tag = "basic") { voice.stopSpeaking(); "" }
        if (t == "continue" || t == "resume" || has("continue speaking", "resume speaking", "aage bolo"))
            return cmd(Cat.VOICE_COMMAND, tag = "basic") { if (voice.resume()) "" else "There's nothing to continue." }
        if (t == "repeat" || has("repeat that", "say that again", "dobara bolo"))
            return cmd(Cat.VOICE_COMMAND, tag = "basic") { voice.repeat(); "" }
        if (has("speak slower", "talk slower", "slow down", "dheere bolo"))
            return cmd(Cat.VOICE_COMMAND, tag = "basic") { prefs.speed = (prefs.speed - 0.2f).coerceAtLeast(0.5f); vary("Okay, slower.", "Sure.") }
        if (has("speak faster", "talk faster", "tez bolo"))
            return cmd(Cat.VOICE_COMMAND, tag = "basic") { prefs.speed = (prefs.speed + 0.2f).coerceAtMost(2f); vary("Okay, faster.", "Sure.") }

        // ── SETTINGS: modes ──
        if (has("talk normally", "normal mode", "normal baat"))
            return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { hooks.talkNormally(); "Okay, back to normal." }
        Regex("(?:switch to|go to|enable|activate|start) (.+?) mode").find(t)?.let { m ->
            val want = m.groupValues[1].trim()
            val p = Personality.values().firstOrNull { it.label.lowercase().startsWith(want) || it.name.lowercase().startsWith(want.replace(" ", "")) }
            val gate = when (p) { Personality.Study -> "study_mode"; Personality.Gaming -> "gaming_mode"; else -> "" }
            if (p != null && (gate.isEmpty() || plugins.isEnabled(gate)))
                return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { hooks.switchPersonality(p); "Switched to ${p.label}." }
        }

        // ── DEVICE ALERTS, NIGHT / EDITING MODE, WEEKLY ROUTINES ──
        modeCmds.route(raw, t)?.let { return it }
        secVisionCmds.route(raw, t)?.let { return it }
        devCmds.route(raw, t)?.let { return it }
        suiteCmds.route(raw, t)?.let { return it }
        controlCmds.route(raw, t)?.let { return it }
        mediaCmds.route(raw, t)?.let { return it }
        fileCmds.route(raw, t)?.let { return it }

        // ── PEOPLE & RELATIONSHIPS ──
        peopleCmds.route(raw, t)?.let { return it }

        // ── MEMORY ──
        if (has("what do you remember", "my memories", "kya yaad hai"))
            return cmd(Cat.SETTINGS_COMMAND, sensitiveInfo = true) { memory.summaryText() }
        if (has("forget everything", "delete all memories", "clear memory", "clear my memory"))
            return cmd(Cat.SETTINGS_COMMAND, Level.Sensitive, "Delete all memories?") { memory.clear(); "Done. Memory is empty." }
        if (t == "forget that" || t == "forget this" || t == "forget it")
            return cmd(Cat.SETTINGS_COMMAND, Level.Action, "Forget what I just saved?") { memory.forgetLast() }
        if (t == "remember this" || t == "remember that" || t.startsWith("remember "))
            return cmd(Cat.SETTINGS_COMMAND) {
                val fact = t.removePrefix("remember").removePrefix(" that").removePrefix(" this").trim(' ', ':', ',')
                memory.remember(fact.ifBlank { null }, hooks.lastUserMessage())
            }

        // ── NOTES ──
        if (plugins.isEnabled("notes")) {
            Regex("^(?:add a note|add note|take a note|note that|note)[: ]+(.+)$").find(t)?.let { m ->
                val body = m.groupValues[1]
                return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { db.addNote(body); vary("Noted.", "Saved.", "Got it.") }
            }
            if (has("show notes", "my notes", "read notes"))
                return cmd(Cat.SETTINGS_COMMAND, sensitiveInfo = true) {
                    val n = db.notes().take(5); if (n.isEmpty()) "You have no notes." else n.joinToString(". ") { it.second }
                }
            if (has("delete notes", "clear notes"))
                return cmd(Cat.SETTINGS_COMMAND, Level.Sensitive, "Delete all notes?") { db.clearNotes(); "Notes deleted." }
        }

        // ── REMINDERS ──
        if ((has("remind me") || Regex("when (my )?(wired |bluetooth )?(headphones|earphones|earbuds|headset) (connect|plug)").containsMatchIn(t)) && plugins.isEnabled("reminders")) hooks.reminder(raw)?.let { fn ->
            return cmd(Cat.SETTINGS_COMMAND, tag = "timer") { fn() }
        }

        // ── TIMER / ALARM (system clock app) ──
        Regex("timer (?:for )?(\\d+)\\s*(second|sec|minute|min|hour|hr)s?").find(t)?.let { m ->
            val n = m.groupValues[1].toInt()
            val secs = when (m.groupValues[2]) { "second", "sec" -> n; "minute", "min" -> n * 60; else -> n * 3600 }
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Start a timer?", tag = "timer") {
                val r = device.setTimer(secs, "NOVA timer"); if (r == "Timer set.") "Timer set for $n ${m.groupValues[2]}${if (n > 1) "s" else ""}." else r
            }
        }
        Regex("alarm (?:for|at) (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(t)?.let { m ->
            var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifBlank { "0" }.toInt()
            if (m.groupValues[3] == "pm" && h < 12) h += 12
            if (m.groupValues[3] == "am" && h == 12) h = 0
            if (h in 0..23 && min in 0..59)
                return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Set an alarm?", tag = "timer") { device.setAlarm(h, min) }
        }

        // ── CALCULATOR (offline) ──
        Calc.fromText(t)?.let { r -> return cmd(Cat.GENERAL_QUERY, tag = "basic") { r } }

        // ── DEVICE: volume ──
        if (has("volume")) {
            val n = Regex("\\d+").find(t)?.value?.toIntOrNull()
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Change the volume?", tag = "basic") {
                val cur = device.volumePct()
                val target = when {
                    n != null -> n / 100f
                    has("mute") -> 0f
                    has("max", "full") -> 1f
                    has("up", "increase", "badha", "zyada") -> cur + 0.15f
                    has("down", "decrease", "kam", "lower") -> cur - 0.15f
                    else -> cur
                }.coerceIn(0f, 1f)
                device.setVolumePct(target)
                "Volume is at ${(target * 100).toInt()}%."
            }
        }

        // ── GENERAL INFORMATION ──
        if ((has("battery") && has("what", "kitni", "kitna", "level", "percent", "status", "how much", "check")) || t == "battery")
            return cmd(Cat.GENERAL_QUERY, tag = "status") { val p = device.batteryPct(); if (p >= 0) "Battery is at $p%." else "I can't read the battery right now." }
        if (has("what time", "time kya", "kitne baje", "current time"))
            return cmd(Cat.GENERAL_QUERY, tag = "basic") { "It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "." }
        if (has("today's date", "todays date", "aaj ki date", "what day", "what's the date"))
            return cmd(Cat.GENERAL_QUERY, tag = "basic") { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) + "." }
        if (has("device info", "how much ram", "storage left", "how much storage"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") { device.deviceInfo() }
        if (has("what changed", "anything changed", "kya badla"))
            return cmd(Cat.DEVICE_SCAN, tag = "status") { hooks.changesReport() }
        if (has("notification")) {
            if (has("summar")) { hooks.setAiContext("Recent notifications from allowed apps:\n" + NovaNotificationListener.summaryText()); return CmdResult(false, Cat.AI_QUERY) }
            if (has("read", "what", "check", "show"))
                return cmd(Cat.GENERAL_QUERY, sensitiveInfo = true) { NovaNotificationListener.summaryText() }
        }

        // ── DEVICE SCAN ──
        if (has("scan my phone", "scan phone", "scan my device", "scan the phone", "phone scan", "device scan", "scan device", "scan my mobile"))
            return cmd(Cat.DEVICE_SCAN, tag = "status") { hooks.startScan(); "Starting the scan. It takes a few seconds." }
        if (has("what did you find", "scan result", "scan report", "kya mila"))
            return cmd(Cat.DEVICE_SCAN, tag = "status") { hooks.scanReport() ?: "I haven't scanned your phone yet. Say, Nova, scan my phone." }
        if (has("show scan", "open scan", "show the report"))
            return cmd(Cat.DEVICE_SCAN, tag = "status") { hooks.showScan(); "Here's the device report." }
        if (has("delete scan", "clear scan"))
            return cmd(Cat.DEVICE_SCAN, Level.Sensitive, "Delete the scan data?") { hooks.deleteScan(); "Scan data deleted." }

        // ── WI-FI / BLUETOOTH ──
        if (has("wifi status", "wi-fi status", "show wifi", "show wi-fi"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") { device.wifiStatusText() }
        if (has("connect to this wifi", "connect to wifi", "connect to this wi-fi", "connect to a wifi", "connect to wi-fi"))
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Connect to a Wi-Fi network?") { hooks.wifiConnect(); "Enter the network name and password. Android will ask you to confirm." }
        if (has("connected bluetooth", "bluetooth devices", "bluetooth connected"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") { hooks.btConnected(); "Checking Bluetooth devices…" }
        if (has("turn bluetooth on", "bluetooth on", "bluetooth chalu", "enable bluetooth"))
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Turn Bluetooth on?") { device.requestBluetoothOn() }

        // ── DEVELOPER ──
        if (has("code", "kotlin", "python", "javascript", "java ", "debug", "error log", "stack trace", "function ", "gradle", "html", "css", "explain this error"))
            return CmdResult(false, Cat.DEVELOPER_COMMAND)

        // ── FLASHLIGHT ──
        if (has("flashlight", "torch", "flash light")) {
            val off = has(" off", "band", "bujha", "बंद")
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, if (off) "Turn the flashlight off?" else "Turn the flashlight on?", tag = "flashlight") {
                val r = device.torch(!off); if (r.startsWith("Flashlight")) vary("Done.", r) else r
            }
        }

        // ── SCREEN ──
        if (has("on my screen", "on the screen", "whats on screen", "what's on screen", "screen par kya", "screen kya dikha", "is page ka summary", "summary of this page", "error find karo", "find the error"))
            return cmd(Cat.SCREEN_COMMAND, sensitiveInfo = true) {
                val s = NovaAccessibilityService.instance
                if (s == null) a11yHelp else { val fg = NovaAccessibilityService.activePackage(); hooks.setAiContext(com.nova.ai.suite.AppContext.hint(fg).let { if (it.isBlank()) "" else it + "\n" } + "Foreground app: " + fg + "\nCurrent screen text: " + s.readScreen()); "I can see the current screen. What would you like me to do with it?" }
            }
        if (has("read screen", "read the screen", "read my screen"))
            return cmd(Cat.SCREEN_COMMAND, sensitiveInfo = true) { NovaAccessibilityService.instance?.readScreen() ?: a11yHelp }
        if (t == "go back" || t == "back")
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Go back?") { if (NovaAccessibilityService.instance?.back() == true) "Going back." else a11yHelp }
        if (t == "go home" || t == "home")
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Go to the home screen?") { if (NovaAccessibilityService.instance?.home() == true) "Going home." else a11yHelp }
        if (has("scroll down")) return cmd(Cat.SCREEN_COMMAND) { if (NovaAccessibilityService.instance?.scroll(true) == true) "Scrolling down." else a11yHelp }
        if (has("scroll up")) return cmd(Cat.SCREEN_COMMAND) { if (NovaAccessibilityService.instance?.scroll(false) == true) "Scrolling up." else a11yHelp }
        if (t.startsWith("click ") || t.startsWith("tap ")) {
            val label = t.substringAfter(' ').trim()
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Tap \"$label\"?") {
                val s = NovaAccessibilityService.instance
                when { s == null -> a11yHelp; s.clickText(label) -> "Tapped $label."; else -> "I couldn't find $label on the screen." }
            }
        }
        if (t.startsWith("type ")) {
            val txt = raw.substring(raw.lowercase().indexOf("type ") + 5).trim()
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Type that into the selected field?") {
                val s = NovaAccessibilityService.instance
                if (s == null) a11yHelp else (s.typeTextChecked(txt)?.let { it } ?: "Typed it.")
            }
        }

        // ── PHONE ──
        if (t.startsWith("call ") || t.startsWith("dial ")) {
            val who = t.substringAfter(' ').trim()
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Sensitive, "Should I call $who?") {
                val digits = who.filter { it.isDigit() || it == '+' }
                if (digits.length >= 5) device.openDialer(digits)
                else {
                    val num = device.findNumber(who)
                    if (num != null) device.openDialer(num) else "I couldn't find $who (Contacts permission may be off). " + device.openDialer(null)
                }
            }
        }
        Regex("^(?:open contact|contact kholo|contact open karo)\\s+(.+)$|^(.+?)\\s+(?:ka contact|ka contact kholo)$").find(t)?.let { m ->
            val who = (m.groupValues[1].ifBlank { m.groupValues[2] }).trim()
            if (who.isNotBlank()) return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Open contact $who?") { device.openContact(who) }
        }
        if (has("nearby bluetooth", "bluetooth scan", "scan bluetooth", "bluetooth devices nearby", "bluetooth dhoondo"))
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Scan for nearby Bluetooth devices?", tag = "status") { hooks.btScan(); "Scanning for nearby devices for about 12 seconds…" }
        if (has("open contacts"))
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Open contacts?") { device.openUrl("content://com.android.contacts/contacts", "contacts") }

        // ── SETTINGS PAGES ──
        if (has("settings") || has("wifi", "wi-fi", "bluetooth", "brightness", "mobile data")) {
            val key = when {
                has("wifi", "wi-fi") -> "wifi"
                has("bluetooth") -> "bluetooth"
                has("display", "brightness") -> "display"
                has("battery") -> "battery"
                has("mobile", "network") -> "mobile"
                has("sound") -> "sound"
                else -> "settings"
            }
            val (action, name) = DeviceController.SETTINGS.getValue(key)
            val prefix = when {
                has("brightness") -> "Android doesn't let apps change brightness silently. "
                has("turn") -> "Android doesn't let apps toggle this silently. "
                else -> ""
            }
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, "Open $name?") { prefix + device.openSettings(action, name) }
        }

        // ── APPS ──
        if (t.startsWith("open ") || t.startsWith("launch ") || t.startsWith("start ")) {
            val what = t.substringAfter(' ').trim()
            return cmd(Cat.APP_COMMAND, Level.Action, "Open $what?") {
                when {
                    what.contains("youtube") -> device.openApp("youtube").let { if (it.startsWith("Opening")) "Opening YouTube." else device.openUrl("https://www.youtube.com", "YouTube") }
                    what.contains("map") -> device.openUrl("geo:0,0?q=", "Maps")
                    what.contains("browser") || what.contains("chrome") -> device.openUrl("https://www.google.com", "the browser")
                    what.contains("camera") -> device.openCamera()
                    what.contains("gallery") || what.contains("photos") -> device.openGallery()
                    what.contains("files") -> device.openFiles()
                    what.contains("play store") -> device.openUrl("market://search?q=", "Play Store")
                    else -> device.openApp(what)
                }
            }
        }
        return CmdResult(false, Cat.AI_QUERY)
    }
}
