package com.nova.ai.commands

import com.nova.ai.NovaApp
import com.nova.ai.developer.DiagnosticsManager

/** Part 4 commands: ask for a script, check for updates, last crash. Nothing here runs code or installs anything by itself. */
class DeveloperCommands {
    private val ctx get() = NovaApp.instance
    private val scriptRe = Regex("(script|code|program|function|app)\\s+(bana|banao|likh|likho|generate|write|create)|(write|create|generate|make)\\s+(me\\s+)?(a|an)\\s+(\\w+\\s+)?(script|program|function)|(bana|banao|likh|likho)\\s+(do|de)\\s+.*(script|code|program)")

    private fun cmd(cat: Cat, level: Level = Level.Info, tag: String = "", run: () -> String) = CmdResult(true, cat, "", level, run, tag)

    fun route(raw: String, t: String): CmdResult? {
        fun has(vararg w: String) = w.any { t.contains(it) }
        if (has("check for update", "check updates", "update check", "check for updates", "nova update"))
            return cmd(Cat.SETTINGS_COMMAND, tag = "basic") {
                val nav = UiBridge.navigate ?: return@cmd "Open Nova > More > Developer Tools to check for updates."
                nav(UiBridge.TAB_DEV_TOOLS); "Developer Tools khol rahi hoon. Update wahan se check kijiye."
            }
        if (has("last crash", "crash log", "diagnostics", "run diagnostics", "koi crash"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") { DiagnosticsManager.summary(ctx) }
        if (scriptRe.containsMatchIn(t))
            return cmd(Cat.DEVELOPER_COMMAND, tag = "basic") {
                val send = UiBridge.sendDev ?: return@cmd "Open Nova's Developer tab and ask there. I only write the code; you review and run it yourself."
                send(raw); "Developer tab mein code bana rahi hoon. Main code sirf dikhati hoon, chalati nahi."
            }
        return null
    }
}
