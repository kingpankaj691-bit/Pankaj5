package com.nova.ai.screen

/** Hides codes and card numbers before anything read from a chat is shown or spoken. Pure Kotlin (unit-tested). */
object SensitiveText {
    private val keywordCode = Regex("(?i)\\b(code|otp|pin|passcode|password|cvv)\\b[^\\n\\d]{0,20}(?:\\d{3}[- ]\\d{3,5}|\\d{4,8})")
    private val dashedCode = Regex("\\b\\d{3}-\\d{3}\\b")
    private val cardLike = Regex("\\b(?:\\d[ -]?){13,19}\\b")
    private val warn = Regex("(?i)\\b(password|passcode|otp|cvv|pin)\\b|\\b(?:\\d[ -]?){13,19}\\b")

    fun redact(s: String): String = s
        .replace(keywordCode) { it.groupValues[1] + " [hidden]" }
        .replace(dashedCode, "[hidden]")
        .replace(cardLike, "[hidden]")

    /** True when a message the user wants to SEND looks like it carries a password, OTP, PIN or card number. */
    fun looksSensitive(s: String): Boolean = warn.containsMatchIn(s)
}

enum class SendOutcome { CONFIRMED, UNCONFIRMED, NOT_SENT }
data class ContactRow(val name: String, val cand: Cand, val score: Int)
data class ChatEntry(val name: String, val preview: String, val unread: String)

/**
 * Where things are in WhatsApp (and WhatsApp Business) and what they mean. Matching uses view ids first and labels as
 * a fallback; it is a heuristic on accessibility data, so confirm on a real phone. Android-free so it is unit-tested.
 */
object WhatsAppUi {
    val packages = setOf("com.whatsapp", "com.whatsapp.w4b")
    fun isWhatsApp(pkg: String) = pkg in packages

    fun norm(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** Registration / verification screens: NOVA never reads or enters codes or phone numbers there. */
    fun isOnboarding(texts: List<String>): Boolean {
        val t = texts.joinToString(" | ").lowercase()
        return Regex("(verify your phone number|enter the 6-digit code|enter your phone number|agree and continue|welcome to whatsapp|verifying your number|6-digit code)").containsMatchIn(t)
    }

    fun looksLikeNumber(s: String): Boolean = Regex("^\\+?[\\d][\\d\\s-]{6,16}$").matches(s.trim())

    private val voiceLike = Regex("(?i)\\b(voice|mic|microphone|lens|camera|speak)\\b")

    fun searchField(cands: List<Cand>): Cand? =
        cands.firstOrNull { it.editable && it.enabled && (it.idName.contains("search_input") || it.all.contains("search")) }

    fun searchEntry(cands: List<Cand>): Cand? =
        cands.filter { it.clickable && it.enabled && !it.editable && !voiceLike.containsMatchIn(it.all) &&
            (it.desc.trim().equals("search", true) || it.text.trim().equals("search", true) || it.idName.contains("menuitem_search")) }
            .minByOrNull { it.top }

    private val nameIds = listOf("conversations_row_contact_name", "contactpicker_row_name", "contact_name", "conversation_contact_name")
    private val noise = Regex("(?i)^(search|chats|status|calls|communities|updates|more options|new chat|archived|camera|settings)$")

    /** Chats / contacts that match [name], best first. */
    fun contactRows(cands: List<Cand>, name: String): List<ContactRow> {
        val q = norm(name)
        if (q.isBlank()) return emptyList()
        val qw = q.split(' ')
        val byId = cands.filter { c -> !c.editable && c.text.isNotBlank() && nameIds.any { c.idName.contains(it) } && !c.idName.startsWith("conversation_contact_name") }
        val pool = if (byId.isNotEmpty()) byId else cands.filter { !it.editable && it.text.isNotBlank() && it.text.length <= 40 && !noise.matches(it.text.trim()) }
        return pool.map { c ->
            val n = norm(c.text); val nw = n.split(' ')
            val score = when {
                n == q -> 100
                qw.all { it in nw } -> 80 - (nw.size - qw.size).coerceAtLeast(0) * 3
                n.startsWith(q) -> 70
                n.contains(q) -> 50
                else -> 0
            }
            ContactRow(c.text.trim(), c, score)
        }.filter { it.score > 0 }.sortedWith(compareByDescending<ContactRow> { it.score }.thenBy { it.cand.top })
    }

    /** Matches that are about equally good AND different people: the user must choose. One exact match is never ambiguous. */
    fun closeMatches(rows: List<ContactRow>): List<ContactRow> {
        if (rows.isEmpty()) return rows
        val top = rows[0].score
        val close = rows.filter { top - it.score <= 10 }.distinctBy { norm(it.name) }
        if (top == 100 && close.count { it.score == 100 } == 1) return listOf(close.first { it.score == 100 })
        return close
    }

    /** Name shown in the open chat's toolbar, or null when no chat is open. */
    fun openChatTitle(cands: List<Cand>): String? =
        cands.firstOrNull { it.idName.contains("conversation_contact_name") && it.text.isNotBlank() }?.text?.trim()

    fun sameContact(title: String, wanted: String): Boolean {
        val t = norm(title); val w = norm(wanted)
        if (t.isBlank() || w.isBlank()) return false
        return t == w || w.split(' ').all { it in t.split(' ') } || t.contains(w)
    }

    fun messageField(cands: List<Cand>): Cand? =
        cands.firstOrNull { it.editable && it.enabled && (it.idName == "entry" || it.all.contains("type a message") || it.hint.lowercase().contains("message")) }

    fun sendButton(cands: List<Cand>): Cand? =
        cands.firstOrNull { it.clickable && it.enabled && !it.editable && !voiceLike.containsMatchIn(it.all) && (it.desc.trim().equals("send", true) || it.idName == "send") }

    /** Text of message bubbles in the open chat, top to bottom. */
    fun messageTexts(cands: List<Cand>): List<String> =
        cands.filter { it.idName.contains("message_text") && it.text.isNotBlank() }.sortedBy { it.top }.map { it.text }

    fun chatListEntries(cands: List<Cand>): List<ChatEntry> {
        val names = cands.filter { it.idName.contains("conversations_row_contact_name") && it.text.isNotBlank() }.sortedBy { it.top }
        return names.map { n ->
            fun near(id: String) = cands.filter { it.idName.contains(id) && it.top >= n.top - 10 && it.top <= n.top + 260 }.minByOrNull { kotlin.math.abs(it.top - n.top) }
            ChatEntry(n.text.trim(), near("single_msg_tv")?.text.orEmpty().trim(), near("conversations_row_message_count")?.text.orEmpty().trim())
        }
    }

    /** Was the message really sent? The box must be empty AND the text must now appear in the chat. */
    fun sendOutcome(fieldEmpty: Boolean, bubbleSeen: Boolean): SendOutcome = when {
        fieldEmpty && bubbleSeen -> SendOutcome.CONFIRMED
        fieldEmpty -> SendOutcome.UNCONFIRMED
        else -> SendOutcome.NOT_SENT
    }
}
