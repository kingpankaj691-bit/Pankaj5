package com.nova.ai.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val TAU = (2.0 * PI).toFloat()

/** One shared looping 0..1 clock. Static (0) when Reduced Motion is on. Only runs while composed. */
@Composable
fun rememberPhase(durationMs: Int): State<Float> {
    val g = LocalGlass.current
    return if (g.reduced) remember { mutableStateOf(0f) }
    else rememberInfiniteTransition(label = "phase").animateFloat(
        0f, 1f, infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
}

@Composable
fun statusColor(status: String): Color {
    val g = LocalGlass.current
    return when (status) {
        "Listening" -> Color(0xFF69F0AE)
        "Thinking", "Processing" -> g.accent2
        "Screen Control" -> Color(0xFFFFD54F)
        "Speaking" -> g.accent
        "Offline", "Error" -> Color(0xFFFF8A80)
        else -> g.accent.a(0.85f)
    }
}

@Composable
fun NovaOrb(status: String, modifier: Modifier = Modifier.size(230.dp), level: () -> Float = { 0f }) {
    val g = LocalGlass.current
    val phase = rememberPhase(2400)
    val accent = if (status == "Offline" || status == "Error") Color(0xFF78909C) else g.accent
    val accent2 = if (status == "Offline") Color(0xFF546E7A) else g.accent2
    Canvas(
        modifier
            .graphicsLayer { translationY = sin(phase.value * TAU) * 8.dp.toPx() }
            .semantics { contentDescription = "Nova is $status" }
    ) {
        val p = phase.value
        val c = center
        val r = size.minDimension * 0.30f
        val pulse = when (status) {
            "Listening" -> 1f + 0.04f * sin(p * TAU * 2f) + 0.12f * level()
            "Speaking" -> 1f + 0.04f * sin(p * TAU * 4f)
            else -> 1f + 0.02f * sin(p * TAU)
        }
        drawCircle(Brush.radialGradient(listOf(accent.a(0.45f), Color.Transparent), c, r * 2.1f), r * 2.1f, c)
        if (status == "Listening") {
            for (i in 0..2) {
                val q = (p * 2f + i / 3f) % 1f
                drawCircle(accent.a((1f - q) * 0.55f), r * (1.1f + q * 0.9f), c, style = Stroke(2.dp.toPx()))
            }
        }
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.a(0.92f), accent.a(0.90f), accent2.a(0.80f), Color(0xFF05070F).a(0.92f)),
                c + Offset(-r * 0.35f, -r * 0.40f), r * 1.7f
            ), r * pulse, c
        )
        drawCircle(
            Brush.linearGradient(listOf(Color.White.a(0.85f), Color.Transparent, accent.a(0.6f))),
            r * pulse, c, style = Stroke(1.5.dp.toPx())
        )
        drawOval(
            Brush.radialGradient(listOf(Color.White.a(0.45f), Color.Transparent), c + Offset(-r * 0.38f, -r * 0.55f), r * 0.55f),
            topLeft = c + Offset(-r * 0.80f, -r * 0.90f), size = Size(r * 0.85f, r * 0.45f)
        )
        if (status == "Screen Control") {
            val rr = r * 1.45f
            for (i in 0..3) {
                drawArc(Color(0xFFFFD54F).a(0.9f), startAngle = i * 90f + 10f + p * 90f, sweepAngle = 50f, useCenter = false,
                    topLeft = c - Offset(rr, rr), size = Size(rr * 2f, rr * 2f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            }
        }
        if (status == "Thinking" || status == "Processing") {
            rotate(p * 360f * (if (status == "Processing") 2f else 1f), c) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, Color.White.a(0.9f)), c),
                    startAngle = 0f, sweepAngle = 270f, useCenter = false,
                    topLeft = c - Offset(r * 1.25f, r * 1.25f), size = Size(r * 2.5f, r * 2.5f),
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        if (status == "Speaking") {
            for (i in 0..4) {
                val h = r * (0.20f + 0.55f * abs(sin(TAU * (p * 4f + i * 0.15f))))
                drawRoundRect(
                    Color.White.a(0.9f),
                    topLeft = Offset(c.x + (i - 2) * r * 0.28f - r * 0.06f, c.y - h / 2f),
                    size = Size(r * 0.12f, h), cornerRadius = CornerRadius(r * 0.06f)
                )
            }
        }
    }
}

@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val color = statusColor(status)
    val active = status == "Listening" || status == "Thinking" || status == "Speaking"
    val phase = rememberPhase(1400)
    GlassCard(modifier, shape = RoundedCornerShape(50), glow = active) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Canvas(Modifier.size(18.dp)) {
                val q = phase.value
                if (active) drawCircle(color.a((1f - q) * 0.6f), size.minDimension / 2f * (0.5f + q * 0.5f), center)
                drawCircle(color, size.minDimension * 0.22f, center)
            }
            GText(status, size = 14.sp, weight = FontWeight.Medium, color = g.text)
        }
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit, diameter: Dp = 84.dp) {
    val g = LocalGlass.current
    val phase = rememberPhase(1800)
    val burst = remember { Animatable(0f) }
    var taps by remember { mutableIntStateOf(0) }
    LaunchedEffect(taps) {
        if (taps > 0 && !g.reduced) { burst.snapTo(0f); burst.animateTo(1f, tween(650)) }
    }
    Box(Modifier.size(diameter + 44.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(diameter + 44.dp)) {
            val base = diameter.toPx() / 2f
            if (listening) for (i in 0..1) {
                val q = (phase.value * 1f + i * 0.5f) % 1f
                drawCircle(g.accent.a((1f - q) * 0.45f), base * (1f + q * 0.5f), center, style = Stroke(2.dp.toPx()))
            }
            if (burst.value in 0.001f..0.999f) drawCircle(g.accent.a((1f - burst.value) * 0.5f), base * (1f + burst.value * 0.55f), center, style = Stroke(3.dp.toPx()))
        }
        GlassCard(
            Modifier.size(diameter).pressable({ taps++; onClick() }).semantics { contentDescription = if (listening) "Listening. Tap to restart" else "Speak to Nova" },
            shape = CircleShape, glow = true, tint = g.accent.a(if (listening) 0.28f else 0.14f)
        ) { Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) { GText("🎤", size = 32.sp) } }
    }
}
