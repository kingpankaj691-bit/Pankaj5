package com.nova.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nova.ai.ai.Emotion
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val TAU2 = (2.0 * PI).toFloat()

/**
 * Original stylized vector avatar (not photorealistic, not based on any real person).
 * Blinks, drifts its gaze, changes brows/mouth/cheeks per Emotion, and animates the mouth while speaking.
 */
@Composable
fun NovaAvatar(status: String, emotion: Emotion, modifier: Modifier = Modifier.size(260.dp), level: () -> Float = { 0f }) {
    val g = LocalGlass.current
    val p = rememberPhase(4800)
    val sp = rememberPhase(650)
    val accent = g.accent
    val ring = statusColor(status)
    val hairDark = Color(0xFF1B1F3B)
    Canvas(
        modifier.graphicsLayer { translationY = sin(p.value * TAU2) * 5.dp.toPx() }
            .semantics { contentDescription = "Nova avatar, $status, ${emotion.label}" }
    ) {
        val u = size.minDimension / 2f
        val c = center
        val ph = p.value
        clipRect {
            drawCircle(Brush.radialGradient(listOf(emotion.tint.a(0.30f), Color.Transparent), c, u * 1.3f), u * 1.3f, c)

            // status ring
            val active = status == "Listening" || status == "Thinking" || status == "Speaking"
            if (status == "Thinking") {
                rotate(ph * 360f, c) {
                    drawArc(Brush.sweepGradient(listOf(Color.Transparent, ring.a(0.9f)), c), 0f, 260f, false,
                        c - Offset(u * 0.86f, u * 0.86f), Size(u * 1.72f, u * 1.72f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
            } else if (active) {
                val q = if (status == "Listening") (ph * 2f) % 1f else 0.5f + 0.5f * sin(sp.value * TAU2)
                drawCircle(ring.a(0.5f * (1f - q * 0.6f)), u * (0.80f + 0.08f * q + 0.10f * level()), c, style = Stroke(2.dp.toPx()))
            }

            // back hair + shoulders + neck
            val hair = Path().apply {
                moveTo(c.x - 0.60f * u, c.y + 0.20f * u)
                cubicTo(c.x - 0.78f * u, c.y - 1.0f * u, c.x + 0.78f * u, c.y - 1.0f * u, c.x + 0.60f * u, c.y + 0.20f * u)
                lineTo(c.x + 0.72f * u, c.y + 1.0f * u); lineTo(c.x - 0.72f * u, c.y + 1.0f * u); close()
            }
            drawPath(hair, Brush.verticalGradient(listOf(hairDark, Color(0xFF3A2F6B)), c.y - u, c.y + u))
            drawOval(Brush.verticalGradient(listOf(Color(0xFF2A3050), Color(0xFF12162B)), c.y + 0.7f * u, c.y + 1.3f * u),
                Offset(c.x - 0.80f * u, c.y + 0.72f * u), Size(1.6f * u, 0.6f * u))
            drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFC9D2E8), Color(0xFF8F9BB8)), c.y + 0.4f * u, c.y + 0.8f * u),
                Offset(c.x - 0.11f * u, c.y + 0.40f * u), Size(0.22f * u, 0.40f * u), CornerRadius(0.06f * u))

            // face
            val faceTL = Offset(c.x - 0.40f * u, c.y - 0.62f * u)
            val faceSize = Size(0.80f * u, 1.12f * u)
            drawOval(Brush.verticalGradient(listOf(Color(0xFFF1F4FB), Color(0xFFC3CCE2)), c.y - 0.62f * u, c.y + 0.5f * u), faceTL, faceSize)
            drawOval(accent.a(0.10f), faceTL, faceSize)

            // cheeks
            if (emotion.cheek > 0f) for (side in intArrayOf(-1, 1)) {
                val cc = Offset(c.x + side * 0.26f * u, c.y + 0.14f * u)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFF8AAE).a(0.35f * emotion.cheek), Color.Transparent), cc, 0.12f * u), 0.12f * u, cc)
            }

            // eyes, brows
            val bt = (ph - 0.93f) / 0.04f
            val blink = if (bt in 0f..1f) abs(1f - 2f * bt) else 1f
            val open = emotion.lid * blink
            val thinking = status == "Thinking"
            for (side in intArrayOf(-1, 1)) {
                val ex = c.x + side * 0.18f * u
                val ey = c.y - 0.02f * u
                drawOval(Color(0xFF14172B), Offset(ex - 0.085f * u, ey - 0.05f * u * open), Size(0.17f * u, 0.10f * u * open))
                if (open > 0.25f) {
                    val gx = sin(ph * TAU2) * 0.012f * u - (if (thinking) 0.02f * u else 0f)
                    val gy = if (thinking) -0.015f * u else 0f
                    val ic = Offset(ex + gx, ey + gy)
                    drawCircle(Brush.radialGradient(listOf(Color.White, accent, accent.a(0.2f)), ic, 0.05f * u), 0.042f * u * minOf(1f, open * 1.4f), ic)
                }
                val tilt = emotion.browTilt * 0.06f * u
                val y0 = c.y - 0.15f * u - emotion.browRaise * u
                var outerY = y0 - tilt * 0.5f
                if (emotion == Emotion.Playful && side > 0) outerY -= 0.03f * u
                drawLine(hairDark, Offset(c.x + side * 0.07f * u, y0 + tilt), Offset(c.x + side * 0.27f * u, outerY), 3.dp.toPx(), StrokeCap.Round)
            }

            // mouth
            val my = c.y + 0.27f * u
            val w = 0.11f * u
            val curve = emotion.smile * 0.06f * u
            val speaking = status == "Speaking"
            val mouthOpen = if (speaking) 0.05f * u * (0.25f + 0.75f * abs(sin(sp.value * TAU2))) else 0f
            if (mouthOpen > 0f) drawOval(Color(0xFF3B1530).a(0.85f), Offset(c.x - w * 0.7f, my + curve - mouthOpen * 0.2f), Size(w * 1.4f, mouthOpen))
            val lip = Path().apply { moveTo(c.x - w, my); quadraticBezierTo(c.x, my + curve * 2f, c.x + w, my) }
            drawPath(lip, Color(0xFFD1587E).a(0.9f), style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))

            // fringe + rim light
            val fringe = Path().apply {
                moveTo(c.x - 0.44f * u, c.y - 0.15f * u)
                quadraticBezierTo(c.x - 0.20f * u, c.y - 0.75f * u, c.x + 0.10f * u, c.y - 0.62f * u)
                quadraticBezierTo(c.x + 0.35f * u, c.y - 0.50f * u, c.x + 0.44f * u, c.y - 0.12f * u)
                quadraticBezierTo(c.x + 0.20f * u, c.y - 0.45f * u, c.x - 0.05f * u, c.y - 0.38f * u)
                quadraticBezierTo(c.x - 0.30f * u, c.y - 0.30f * u, c.x - 0.44f * u, c.y - 0.15f * u)
                close()
            }
            drawPath(fringe, Brush.verticalGradient(listOf(Color(0xFF2B2F55), hairDark), c.y - 0.75f * u, c.y - 0.1f * u))
            drawOval(Brush.linearGradient(listOf(Color.White.a(0.8f), Color.Transparent, accent.a(0.5f))), faceTL, faceSize, style = Stroke(1.5.dp.toPx()))
        }
    }
}
