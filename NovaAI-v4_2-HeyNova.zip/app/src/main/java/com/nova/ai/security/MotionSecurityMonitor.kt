package com.nova.ai.security

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * Motion / pick-up detection from the official accelerometer (and optionally gyroscope).
 *
 *  1. Arming delay: sensors settle and the resting position is recorded, so you can put the phone down.
 *  2. A "hit" is a moment when movement beats the sensitivity threshold. Single bumps do not count.
 *  3. Three hits inside 1.5 s open a 2 s confirmation window.
 *  4. The alarm fires only if, inside that window, the phone's tilt changed from its resting position (picked up) or the movement
 *     kept going. Otherwise it was a false alarm and the monitor quietly resets.
 *  5. After an alarm there is a cooldown. No permission is needed for these sensors, and nothing is recorded.
 */
class MotionSecurityMonitor(ctx: Context, private val prefs: Prefs, private val onTriggered: (String) -> Unit) : SensorEventListener {

    companion object {
        private const val MIN_HITS = 3
        private const val HIT_WINDOW_MS = 1500L
        private const val CONFIRM_MS = 2000L
    }

    private val sm = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val g = FloatArray(3)
    private val base = FloatArray(3)
    private var gInit = false
    private var baseSet = false
    private var armedAt = 0L
    private var cooldownUntil = 0L
    private var confirmUntil = 0L
    private val hits = ArrayDeque<Long>()
    @Volatile private var gyroMag = 0f
    private var thrLinear = 1.2f
    private var thrTiltDeg = 20.0
    private var thrGyro = 0.5f
    private var useGyro = true
    private var armDelayMs = 10_000L
    private var cooldownMs = 30_000L
    @Volatile var armed = false
        private set

    fun isAvailable() = acc != null

    fun start(): Boolean {
        if (acc == null) return false
        when (prefs.secSensitivity) {
            "low" -> { thrLinear = 2.5f; thrTiltDeg = 35.0; thrGyro = 1.0f }
            "high" -> { thrLinear = 0.6f; thrTiltDeg = 10.0; thrGyro = 0.25f }
            else -> { thrLinear = 1.2f; thrTiltDeg = 20.0; thrGyro = 0.5f }
        }
        useGyro = prefs.secUseGyro && gyro != null
        armDelayMs = prefs.secArmDelaySec * 1000L
        cooldownMs = prefs.secCooldownSec * 1000L
        gInit = false; baseSet = false; confirmUntil = 0L; cooldownUntil = 0L; hits.clear()
        armedAt = SystemClock.elapsedRealtime()
        sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI)
        if (useGyro) sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_UI)
        armed = true
        return true
    }

    /** Always unregisters both listeners. */
    fun stop() {
        try { sm.unregisterListener(this) } catch (e: Exception) { }
        armed = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> gyroMag = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
            Sensor.TYPE_ACCELEROMETER -> onAcc(e.values, SystemClock.elapsedRealtime())
        }
    }

    private fun onAcc(v: FloatArray, now: Long) {
        if (!gInit) { for (i in 0..2) g[i] = v[i]; gInit = true; return }
        for (i in 0..2) g[i] = 0.9f * g[i] + 0.1f * v[i]
        val dx = v[0] - g[0]; val dy = v[1] - g[1]; val dz = v[2] - g[2]
        val linear = sqrt(dx * dx + dy * dy + dz * dz)

        if (now - armedAt < armDelayMs) return              // still arming
        if (!baseSet) { val n = norm(g); for (i in 0..2) base[i] = g[i] / n; baseSet = true }
        if (now < cooldownUntil) { hits.clear(); confirmUntil = 0L; return }

        if (linear > thrLinear || (useGyro && gyroMag > thrGyro)) hits.addLast(now)
        while (hits.isNotEmpty() && now - hits.first() > HIT_WINDOW_MS) hits.removeFirst()
        if (confirmUntil == 0L && hits.size >= MIN_HITS) confirmUntil = now + CONFIRM_MS
        if (confirmUntil != 0L) {
            val tilt = tiltDegrees()
            when {
                tilt > thrTiltDeg -> fire("The phone was picked up (tilted ${tilt.toInt()}°).", now)
                hits.size >= MIN_HITS * 3 -> fire("The phone kept moving.", now)
                now > confirmUntil -> { confirmUntil = 0L; hits.clear() }      // false alarm, e.g. a table bump
            }
        }
    }

    private fun fire(reason: String, now: Long) {
        cooldownUntil = now + cooldownMs
        confirmUntil = 0L
        hits.clear()
        onTriggered(reason)
    }

    private fun norm(a: FloatArray) = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).coerceAtLeast(0.0001f)

    private fun tiltDegrees(): Double {
        val n = norm(g)
        val dot = ((g[0] / n) * base[0] + (g[1] / n) * base[1] + (g[2] / n) * base[2]).toDouble().coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(dot))
    }
}
