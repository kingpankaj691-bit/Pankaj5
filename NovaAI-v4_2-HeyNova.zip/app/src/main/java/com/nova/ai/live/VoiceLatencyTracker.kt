package com.nova.ai.live

import kotlinx.coroutines.flow.MutableStateFlow

/** Per-turn timestamps (ms) and derived deltas, for the debugger. Marks must arrive in order; an out-of-order mark is ignored. */
class VoiceLatencyTracker(private val clock: () -> Long = { System.currentTimeMillis() }) {
    enum class Mark { USER_SPEECH_END, FIRST_MODEL_AUDIO, TURN_COMPLETE }

    val reconnectCount = MutableStateFlow(0)
    private val marks = LongArray(Mark.values().size) { -1L }

    @Synchronized fun startTurn() { marks.fill(-1L) }

    @Synchronized
    fun mark(m: Mark, at: Long = clock()) {
        val i = m.ordinal
        if (marks[i] >= 0) return
        for (j in i + 1 until marks.size) if (marks[j] >= 0) return      // a later mark is already there
        val prev = (0 until i).map { marks[it] }.filter { it >= 0 }.maxOrNull()
        if (prev != null && at < prev) return
        marks[i] = at
    }

    @Synchronized fun firstAudioLatencyMs(): Long? = delta(Mark.USER_SPEECH_END, Mark.FIRST_MODEL_AUDIO)
    @Synchronized fun turnDurationMs(): Long? = delta(Mark.FIRST_MODEL_AUDIO, Mark.TURN_COMPLETE)

    private fun delta(a: Mark, b: Mark): Long? {
        val x = marks[a.ordinal]; val y = marks[b.ordinal]
        return if (x >= 0 && y >= 0) y - x else null
    }

    fun onReconnect() { reconnectCount.value = reconnectCount.value + 1 }
    fun resetReconnects() { reconnectCount.value = 0 }
}
