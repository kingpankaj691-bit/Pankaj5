package com.nova.ai.voice

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.Emotion
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.ai.NovaPersonalityEngine
import com.nova.ai.ai.OfflineProvider
import com.nova.ai.ai.Personality
import com.nova.ai.commands.Level
import com.nova.ai.commands.LocalCommandRouter
import com.nova.ai.commands.RouterHooks
import com.nova.ai.core.AIProvider
import com.nova.ai.jarvis.CarMode
import com.nova.ai.jarvis.GeminiAgent
import com.nova.ai.jarvis.Interpreter
import com.nova.ai.jarvis.JarvisCall
import com.nova.ai.jarvis.JarvisCommands
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.core.CommandExecutor
import com.nova.ai.device.DeviceController
import com.nova.ai.language.LanguageDetector
import com.nova.ai.memory.MemoryDb
import com.nova.ai.memory.MemoryEngine
import com.nova.ai.people.PeopleMemoryManager
import com.nova.ai.plugins.PluginRegistry
import com.nova.ai.security.LockPolicy
import com.nova.ai.security.Prefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Answers voice commands when the app UI is not alive (screen off, activity closed) so Background Voice keeps working:
 * CommandRouter -> GeminiProvider / OfflineProvider -> TTS.
 *
 * Limits: it has no chat window, so anything that needs on-screen confirmation, a choice, screen vision or a scan
 * is answered with "open Nova". Sensitive actions are never run from here without confirmation.
 */
class HeadlessAssistant(private val app: Application, private val prefs: Prefs) {
    private val voice = VoiceManager(app, prefs).also { it.onSpeaking = { s -> VoiceState.speaking.value = s } }
    private val device = DeviceController(app)
    private val db = MemoryDb.get(app)
    private val memory = MemoryEngine(app, prefs, db)
    private val people = PeopleMemoryManager(app, prefs, memory)
    private val brain = com.nova.ai.brain.Brain.get(app)
    private val plugins = PluginRegistry(app)
    private val gemini: AIProvider = SwitchingProvider(prefs)
    private val offline: AIProvider = OfflineProvider()
    private val personaEngine = NovaPersonalityEngine()
    private val mutex = Mutex()
    private val jp = JarvisPrefs(app)
    private val agent: AIProvider = GeminiAgent(app, prefs) { cmd -> agentPhone(cmd) }
    private val history = ArrayList<Pair<Boolean, String>>()
    private var silent = false
    private val captured = StringBuilder()

    private val router: CommandExecutor = LocalCommandRouter(
        device, memory, db, prefs, voice, plugins, people,
        RouterHooks(
            talkNormally = { }, setAiContext = { }, startScan = { }, showScan = { }, scanReport = { null }, deleteScan = { },
            wifiConnect = { }, btConnected = { }, btScan = { }, reminder = { null }, lastUserMessage = { null },
            changesReport = { "" }, switchPersonality = { }, clarify = { }, confirm = { _, _ -> }
        )
    )

    suspend fun handle(raw: String) = mutex.withLock { process(raw.trim()) }

    /** For Tasker: runs the command like a spoken one but does not talk; returns what Nova would have said. */
    suspend fun handleSilently(raw: String): String = mutex.withLock {
        silent = true; captured.clear()
        try { process(raw.trim()) } finally { silent = false }
        captured.toString().trim()
    }

    private suspend fun process(t: String) {
        if (t.isEmpty()) { say(if (NovaSession.hindiHint || prefs.language == "hindi" || prefs.language == "hinglish") "Haan, boliye?" else "Yes?"); return }
        val jc = JarvisCommands.parse(t)
        if (Interpreter.active && jc != JarvisCall.InterpreterOff) { say(Interpreter.translate(prefs, t)); return }
        if (jc != null) {
            when {
                jc.needsScreen -> say("Open Nova to do that.")
                jc.sensitive -> say("Please open Nova to confirm that.")
                else -> say(JarvisCommands.run(app, prefs, jc))
            }
            return
        }
        val locked = LockPolicy.isLocked(app)
        if (!locked) {
            val bo = try { brain.process(t, isOnline(), "voice") } catch (e: Exception) { com.nova.ai.brain.Outcome() }
            if (!brain.enabled) memory.observe(t)
            if (bo.reply != null) { say(bo.reply); return }
        }
        val r = router.route(t)
        if (r.handled) {
            val blocked = LockPolicy.check(r, prefs)
            if (blocked != null) { say(blocked); return }
            val needsConfirm = r.level == Level.Sensitive || r.sensitiveInfo || (prefs.confirmLevel == "always" && r.level != Level.Info)
            if (needsConfirm) { say("Please open Nova to confirm that."); return }
            val out = r.exec()
            if (out.isNotBlank()) say(out)
            return
        }
        if (locked && !prefs.lockBasic) { say("Unlock your phone first."); return }
        ask(t, locked)
    }

    private suspend fun ask(t: String, locked: Boolean) {
        if (!prefs.aiEnabled) { say("AI is disabled in Settings. Local commands still work."); return }
        val provider = if (isOnline() && !prefs.localOnly) (if (jp.agent) agent else gemini) else offline
        history.add(true to t)
        while (history.size > 8) history.removeAt(0)
        while (history.isNotEmpty() && !history.first().first) history.removeAt(0)
        val system = systemPrompt(t, locked)
        when (val res = provider.chat(history.toList(), system, prefs.model)) {
            is AiResult.Ok -> {
                val text = res.text.replace(Regex("\\[emo:[^\\]]*]\\s*"), "").trim()
                history.add(false to text)
                say(text)
            }
            is AiResult.Err -> say(if (res.msg == OfflineProvider.NEEDS_INTERNET) res.msg else "Sorry. ${res.msg}")
        }
    }

    private fun systemPrompt(lastUser: String, locked: Boolean): String {
        val persona = personaEngine.prompt(Personality.fromName(prefs.personality), prefs.customPersonality)
        val lang = if (locked) LanguageDetector.instruction(prefs.language, prefs.manualTag, lastUser) else brain.languageInstruction(prefs.language, prefs.manualTag, lastUser)
        val mem = if (locked) "" else if (brain.enabled) brain.contextFor(lastUser, prefs.model) else memory.promptContext()
        return listOf(
            "You are NOVA, a voice assistant on an Android phone. Replies are read aloud, so avoid markdown symbols and emoji. " +
                "Answer simple requests in one short sentence; give detail only when asked. Never claim you performed a phone action unless told it was done.",
            "Personality: $persona", lang, mem, prefs.systemPromptExtra, if (jp.carMode) CarMode.PROMPT else "",
            if (jp.wakeName != "nova") "The user calls you ${jp.wakeName.replaceFirstChar { it.uppercase() }}. Treat that as your name." else ""
        ).filter { it.isNotBlank() }.joinToString("\n")
    }

    /** Used by the Gemini agent: runs a plain-words command through the router, but never anything that needs confirmation. */
    private fun agentPhone(cmd: String): String {
        val r = router.route(cmd)
        if (!r.handled) return "I couldn't map that to a phone command."
        if (r.level == Level.Sensitive || r.sensitiveInfo || LockPolicy.check(r, prefs) != null) return "That needs the user's confirmation. Tell them to say it directly."
        return r.exec().ifBlank { "Done." }
    }

    private suspend fun say(text: String) {
        try { brain.onAssistantTurn(text) } catch (e: Exception) { }
        if (silent) { captured.append(text).append(' '); return }
        var waited = 0
        while (!voice.ttsAvailable() && waited < 2500) { delay(100); waited += 100 }   // first use: TTS engine is still starting
        voice.speak(text, Emotion.Normal)
    }

    private fun isOnline(): Boolean = try {
        val cm = app.getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork)
        c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) { true }

    fun close() {
        voice.shutdown()
        VoiceState.speaking.value = false
    }
}
