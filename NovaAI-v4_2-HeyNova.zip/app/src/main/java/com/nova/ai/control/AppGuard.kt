package com.nova.ai.control

import com.nova.ai.screen.ActionValidator
import com.nova.ai.screen.AppNameMatcher

sealed class AppVerdict {
    object Allowed : AppVerdict()
    data class Refused(val reason: String) : AppVerdict()
}

/**
 * What Nova will never start an install / uninstall for. Android's own confirmation screen is ALWAYS shown (Nova can't
 * and doesn't bypass it); these rules additionally stop Nova from even opening it for system, security and protected apps
 * and for Nova itself. Pure Kotlin (unit-tested).
 */
object AppGuard {
    fun forUninstall(pkg: String, label: String, ownPackage: String, isSystem: Boolean): AppVerdict = when {
        pkg == ownPackage -> AppVerdict.Refused("I won't uninstall myself. If you really want to remove Nova AI, do it in Android Settings > Apps.")
        isSystem -> AppVerdict.Refused("$label is a system app, so I won't uninstall it. Android only lets you update or disable it in Settings > Apps.")
        ShellPolicy.isProtectedPackage(pkg) -> AppVerdict.Refused("$label is a protected system or security app (or a tool Nova depends on), so I won't uninstall it.")
        ActionValidator.packageBlocked(pkg) -> AppVerdict.Refused("$label looks like a payment, banking or password app. I won't touch it; uninstall it yourself in Settings > Apps.")
        else -> AppVerdict.Allowed
    }

    /** Installing never happens silently either; this only refuses packages Nova must not install or replace. */
    fun forInstall(pkg: String, label: String, ownPackage: String): AppVerdict = when {
        pkg == ownPackage -> AppVerdict.Refused("That APK is Nova AI itself. I won't replace myself.")
        ShellPolicy.isProtectedPackage(pkg) -> AppVerdict.Refused("$label would replace a protected system or security app, so I won't start that install.")
        else -> AppVerdict.Allowed
    }
}

/** Finds the one installed app a spoken name means. Never guesses between several apps. */
object AppPick {
    sealed class Pick {
        data class Found(val label: String, val pkg: String) : Pick()
        object NotFound : Pick()
        data class Ambiguous(val names: List<String>) : Pick()
    }

    /** [apps] = (label, package). */
    fun pick(apps: List<Pair<String, String>>, query: String): Pick {
        val q = AppNameMatcher.norm(query)
        if (q.isBlank()) return Pick.NotFound
        val distinct = apps.filter { it.first.isNotBlank() }.distinctBy { it.second }
        distinct.firstOrNull { it.second.equals(query.trim(), ignoreCase = true) }?.let { return Pick.Found(it.first, it.second) }
        val exact = distinct.filter { AppNameMatcher.norm(it.first) == q }
        if (exact.size == 1) return Pick.Found(exact[0].first, exact[0].second)
        if (exact.size > 1) return Pick.Ambiguous(exact.map { "${it.first} (${it.second})" }.take(5))
        AppNameMatcher.exactPackageFor(query)?.let { p -> distinct.firstOrNull { it.second == p }?.let { return Pick.Found(it.first, it.second) } }
        val part = distinct.filter { AppNameMatcher.norm(it.first).contains(q) }
        return when {
            part.isEmpty() -> Pick.NotFound
            part.size == 1 -> Pick.Found(part[0].first, part[0].second)
            else -> Pick.Ambiguous(part.map { it.first }.take(5))
        }
    }
}

/** Picks an APK file by name from a list of (name, id). */
object ApkPick {
    /** Matches, best first. A blank query returns everything in the given (newest-first) order. */
    fun match(names: List<String>, query: String): List<String> {
        val q = AppNameMatcher.norm(query)
        val apks = names.filter { it.lowercase().endsWith(".apk") }
        if (q.isBlank()) return apks
        return apks.filter { AppNameMatcher.norm(it).contains(q) }
    }
}
