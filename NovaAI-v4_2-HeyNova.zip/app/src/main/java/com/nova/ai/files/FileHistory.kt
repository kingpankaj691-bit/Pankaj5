package com.nova.ai.files

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class FileOp(val label: String) {
    OPEN("Open"), COPY("Copy"), MOVE("Move"), RENAME("Rename"), MKDIR("New folder"), DELETE("Delete"), ZIP("Compress"), UNZIP("Extract"),
    SHARE("Share"), ORGANIZE("Organize"), ANALYZE("Analyze"), PERMISSION("Permission")
}
enum class FileStatus { OK, FAILED, CANCELLED, DENIED }

data class FileOpRecord(val id: Long, val time: Long, val op: FileOp, val name: String, val target: String, val status: FileStatus, val note: String)

/** Ring buffer, pure logic. */
class FileOpLog(private val cap: Int = 200) {
    private val items = ArrayList<FileOpRecord>()
    @Synchronized fun add(r: FileOpRecord) { items.add(0, r); while (items.size > cap) items.removeAt(items.size - 1) }
    @Synchronized fun all(): List<FileOpRecord> = items.toList()
    @Synchronized fun clear() = items.clear()
    @Synchronized fun load(l: List<FileOpRecord>) { items.clear(); items.addAll(l.take(cap)) }
}

object FileOpCodec {
    fun encode(list: List<FileOpRecord>): String {
        val a = JSONArray()
        list.forEach { r -> a.put(JSONObject().put("i", r.id).put("t", r.time).put("o", r.op.name).put("n", r.name.take(120)).put("g", r.target.take(200)).put("s", r.status.name).put("x", r.note.take(160))) }
        return a.toString()
    }
    fun decode(json: String): List<FileOpRecord> = try {
        val a = JSONArray(json)
        (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            val op = FileOp.values().firstOrNull { it.name == o.optString("o") } ?: return@mapNotNull null
            val st = FileStatus.values().firstOrNull { it.name == o.optString("s") } ?: FileStatus.FAILED
            FileOpRecord(o.optLong("i"), o.optLong("t"), op, o.optString("n"), o.optString("g"), st, o.optString("x"))
        }
    } catch (e: Exception) { emptyList() }
}

/**
 * "What did Nova do with my files": every open, copy, move, delete and so on. Stored only in Nova's private app folder, never uploaded,
 * holds file names and folders (never file contents), and the user can clear it at any time.
 */
object FileHistory {
    private val log = FileOpLog()
    @Volatile private var loaded = false
    private var seq = 0L

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "file_history.json")

    @Synchronized private fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        try { file(ctx).takeIf { it.exists() }?.let { f -> val l = FileOpCodec.decode(f.readText()); log.load(l); seq = l.maxOfOrNull { it.id } ?: 0L } } catch (e: Exception) { }
    }

    fun record(ctx: Context, op: FileOp, name: String, target: String, status: FileStatus, note: String) {
        ensure(ctx)
        synchronized(this) {
            seq++
            log.add(FileOpRecord(seq, System.currentTimeMillis(), op, name, target, status, note))
            try { file(ctx).writeText(FileOpCodec.encode(log.all())) } catch (e: Exception) { }
        }
    }

    fun all(ctx: Context): List<FileOpRecord> { ensure(ctx); return log.all() }

    fun clear(ctx: Context) { ensure(ctx); log.clear(); try { file(ctx).delete() } catch (e: Exception) { } }
}
