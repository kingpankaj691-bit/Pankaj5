package com.nova.ai.files

/** An offline, extractive summary: counts, top keywords and the most representative sentences. Nothing leaves the phone and nothing is invented. */
object LocalSummary {
    private val stop = ("the and for that with this from have are was were will would there their about which into your you not but all can has had its our out who how what when where why " +
        "hai hain tha thi the ka ki ke ko se mein me par aur ya to bhi kar karo kiya yeh ye woh wo is us uska iske apne mera meri mere").split(' ').toSet()

    fun keywords(text: String, n: Int = 8): List<String> =
        Regex("[\\p{L}][\\p{L}\\p{N}'-]{3,}").findAll(text.lowercase()).map { it.value }.filter { it !in stop }
            .groupingBy { it }.eachCount().entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).take(n).map { it.key }

    fun sentences(text: String): List<String> =
        text.replace('\n', ' ').split(Regex("(?<=[.!?।])\\s+")).map { it.trim() }.filter { it.length in 25..400 }

    fun of(text: String, maxSentences: Int = 3): String {
        val t = text.trim()
        if (t.isEmpty()) return "There's no text to summarize."
        val words = Regex("[\\p{L}\\p{N}]+").findAll(t).count(); val lines = t.lines().count { it.isNotBlank() }
        val kw = keywords(t); val kwSet = kw.toSet()
        val sents = sentences(t)
        val picked = sents.withIndex().map { (i, s) ->
            val ws = Regex("[\\p{L}][\\p{L}'-]{3,}").findAll(s.lowercase()).map { it.value }.toList()
            val score = if (ws.isEmpty()) 0.0 else ws.count { it in kwSet }.toDouble() / ws.size
            Triple(i, s, score)
        }.sortedByDescending { it.third }.take(maxSentences).sortedBy { it.first }
        return buildString {
            append("About $words words in $lines lines.")
            if (kw.isNotEmpty()) append("\nMain words: ${kw.joinToString(", ")}.")
            if (picked.isNotEmpty()) { append("\nKey sentences:"); picked.forEach { append("\n• ").append(it.second) } }
            else append("\n(No full sentences to pick from. Open the preview to read it.)")
        }
    }
}
