package com.nova.ai.control

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class TaskStatus { VERIFIED, UNVERIFIED, FAILED, NEEDS_USER, DENIED, UNSUPPORTED, CANCELLED, RUNNING }

data class TaskRecord(
    val id: Long, val time: Long, val title: String, val method: String, val status: TaskStatus,
    val message: String, val before: String = "", val after: String = "", val attempts: Int = 1
)

/** Ring buffer of recent control tasks: pure logic, no Android types. [TaskHistory] persists it. */
class TaskLog(private val cap: Int = 100) {
    private val items = ArrayList<TaskRecord>()
    @Synchronized fun add(r: TaskRecord) { items.add(0, r); while (items.size > cap) items.removeAt(items.size - 1) }
    @Synchronized fun update(r: TaskRecord) { val i = items.indexOfFirst { it.id == r.id }; if (i >= 0) items[i] = r else add(r) }
    @Synchronized fun all(): List<TaskRecord> = items.toList()
    @Synchronized fun failed(): List<TaskRecord> = items.filter { it.status == TaskStatus.FAILED || it.status == TaskStatus.DENIED || it.status == TaskStatus.UNSUPPORTED }
    @Synchronized fun running(): List<TaskRecord> = items.filter { it.status == TaskStatus.RUNNING }
    @Synchronized fun clear() = items.clear()
    @Synchronized fun load(l: List<TaskRecord>) { items.clear(); items.addAll(l.take(cap)) }
}

/** Execution log + task history shown in Advanced System Control. Stored in app-private files only; no personal screen content is logged. */
object TaskHistory {
    val log = TaskLog()
    @Volatile private var ctx: Context? = null
    private fun file() = ctx?.let { File(it.filesDir, "control_history.json") }

    fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        try {
            val f = file()?.takeIf { it.exists() } ?: return
            val a = JSONArray(f.readText())
            log.load((0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val st = TaskStatus.values().firstOrNull { it.name == o.optString("s") } ?: TaskStatus.FAILED
                // anything still "running" from a previous process died with it
                TaskRecord(o.getLong("i"), o.getLong("t"), o.getString("n"), o.optString("m"), if (st == TaskStatus.RUNNING) TaskStatus.CANCELLED else st,
                    o.optString("x"), o.optString("b"), o.optString("a"), o.optInt("k", 1))
            })
        } catch (e: Exception) { }
    }

    fun save() {
        try {
            val a = JSONArray()
            log.all().take(60).forEach { r ->
                a.put(JSONObject().put("i", r.id).put("t", r.time).put("n", r.title).put("m", r.method).put("s", r.status.name)
                    .put("x", r.message.take(200)).put("b", r.before.take(60)).put("a", r.after.take(60)).put("k", r.attempts))
            }
            file()?.writeText(a.toString())
        } catch (e: Exception) { }
    }
    fun clear() { log.clear(); try { file()?.delete() } catch (e: Exception) { } }
}
