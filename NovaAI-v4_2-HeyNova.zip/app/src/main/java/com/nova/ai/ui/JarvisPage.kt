package com.nova.ai.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.jarvis.Briefing
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.jarvis.FileSearch
import com.nova.ai.jarvis.LocationReminders
import com.nova.ai.jarvis.SmartHome
import com.nova.ai.jarvis.TaskerBridge
import com.nova.ai.jarvis.VoskModelManager
import kotlinx.coroutines.launch

/** Settings > Jarvis Pack. Changes to listening options apply the next time Background Voice is started. */
@Composable
internal fun JarvisPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val jp = remember { JarvisPrefs(ctx) }
    val scope = rememberCoroutineScope()
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    fun ask(vararg p: String) = permLauncher.launch(arrayOf(*p))

    var stt by remember { mutableStateOf(jp.sttMode) }
    var liveModel by remember { mutableStateOf(jp.liveModel) }
    var interrupt by remember { mutableStateOf(jp.interrupt) }
    var offLang by remember { mutableStateOf(jp.offlineLang) }
    var neural by remember { mutableStateOf(jp.neuralTts) }
    var ttsModel by remember { mutableStateOf(jp.ttsModel) }
    var ttsVoice by remember { mutableStateOf(jp.ttsVoiceName) }
    var orb by remember { mutableStateOf(jp.orb) }
    var callAnn by remember { mutableStateOf(jp.callAnnounce) }
    var callVoice by remember { mutableStateOf(jp.callVoiceControl) }
    var brief by remember { mutableStateOf(if (jp.briefingMinute >= 0) "%02d:%02d".format(jp.briefingMinute / 60, jp.briefingMinute % 60) else "") }
    var proactive by remember { mutableStateOf(jp.proactive) }
    var loc by remember { mutableStateOf(jp.locationReminders) }
    var placeName by remember { mutableStateOf("") }
    var placeMsg by remember { mutableStateOf("") }
    var car by remember { mutableStateOf(jp.carMode) }
    var carBt by remember { mutableStateOf(jp.carBtName) }
    var agent by remember { mutableStateOf(jp.agent) }
    var wakeName by remember { mutableStateOf(jp.wakeName) }
    var wakeGate by remember { mutableStateOf(jp.wakeGate) }
    var sos by remember { mutableStateOf(jp.sosContacts) }
    var sosCall by remember { mutableStateOf(jp.sosCall) }
    var taskerIn by remember { mutableStateOf(jp.taskerIn) }
    var taskerToken by remember { mutableStateOf(jp.taskerToken) }
    var taskerEv by remember { mutableStateOf(jp.taskerEvents) }
    var clip by remember { mutableStateOf(jp.clipboard) }
    var clipMin by remember { mutableStateOf(jp.clipMinChars.toString()) }
    var devs by remember { mutableStateOf(SmartHome.parse(jp.devicesJson)) }
    var dName by remember { mutableStateOf("") }
    var dAlias by remember { mutableStateOf("") }
    var dKind by remember { mutableStateOf("light") }
    var dType by remember { mutableStateOf("tasmota") }
    var dHost by remember { mutableStateOf("") }
    var dExtra by remember { mutableStateOf("") }
    var dConfirm by remember { mutableStateOf(false) }
    var tuyaRegion by remember { mutableStateOf(jp.tuyaRegion) }
    var tuyaId by remember { mutableStateOf(jp.tuyaClientId) }
    var tuyaSecret by remember { mutableStateOf("") }
    var haUrl by remember { mutableStateOf(jp.haUrl) }
    var haToken by remember { mutableStateOf("") }
    val allFiles = remember(tick, refresh) { FileSearch.hasAccess(ctx) }
    var briefText by remember { mutableStateOf("") }
    var offMsg by remember { mutableStateOf("") }
    val voskStatus by VoskModelManager.status.collectAsState()
    val overlayOk = remember(tick, refresh) { Settings.canDrawOverlays(ctx) }
    val installed = remember(tick, refresh, voskStatus, offLang) { VoskModelManager.isInstalled(ctx, offLang) }
    val places = remember(tick, refresh, placeMsg) { jp.places() }
    val rems = remember(tick, refresh, placeMsg) { jp.reminders() }

    NovaFloatingVoiceSettings(vm)
    LiveVoiceSettings()
    GlassSettingSection("Speech recognition (Background Voice)") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "Auto", "live" to "Live (Gemini)", "clips" to "5-sec clips", "offline" to "Offline", "duplex" to "Two-way voice").forEach { (id, label) ->
                GlassButton(label, { stt = id; jp.sttMode = id }, primary = stt == id)
            }
        }
        GText("Auto: real-time Gemini Live, and the offline recognizer takes over when Live is down (if downloaded). Live sends your voice to Google's Gemini; Offline stays on the phone but is less accurate, especially for Hindi.", size = 12.sp, color = g.subtext)
        GText("Live speech-to-text model (recognition only). Answers always come from the model chosen in Settings → Gemini → Model. A conversational Live model cannot be used here: it needs audio output and fails with error 1007.", size = 12.sp, color = g.subtext)
        ModelPicker(liveModel, remember { com.nova.ai.ai.model.ModelManager.transcriptionEntries(ctx) }, { jp.liveModel = it; liveModel = jp.liveModel })
        ToggleRow("Let me interrupt Nova (experimental)", "Keeps listening while Nova talks. Works best with earphones; on the speaker she may hear herself.", interrupt) { interrupt = it; jp.interrupt = it }
    }
    GlassSettingSection("Offline recognizer") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VoskModelManager.specs.forEach { sp -> GlassButton(sp.label, { offLang = sp.id; jp.offlineLang = sp.id }, primary = offLang == sp.id) }
        }
        val sp = VoskModelManager.spec(offLang)
        GlassListItem(sp.label + " model", if (installed) "Installed" else "Not installed (about ${sp.sizeMb} MB download)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Download", { scope.launch { offMsg = VoskModelManager.download(ctx, offLang) ?: "Done."; refresh++ } }, enabled = !installed, primary = true)
            GlassButton("Delete", { VoskModelManager.delete(ctx, offLang); refresh++ }, enabled = installed)
        }
        if (voskStatus.isNotBlank()) GText(voskStatus, size = 12.sp, color = g.accent)
        if (offMsg.isNotBlank()) GText(offMsg, size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Natural voice") {
        ToggleRow("Gemini voice", "Speaks with a natural Gemini voice. Falls back to Android's voice if it fails. Uses your Gemini quota.", neural) { neural = it; jp.neuralTts = it }
        GText("Voice model", size = 12.sp, color = g.subtext)
        ModelPicker(ttsModel, com.nova.ai.ai.ModelCatalog.tts, { jp.ttsModel = it; ttsModel = jp.ttsModel })
        GlassTextField(ttsVoice, { ttsVoice = it; jp.ttsVoiceName = it }, Modifier.fillMaxWidth(), placeholder = "Voice (for example Kore, Puck, Charon)")
    }
    GlassSettingSection("Floating orb and default assistant") {
        ToggleRow("Floating orb", "A small orb over other apps while Background Voice runs. Tap to talk, long-press to pause.", orb) { orb = it; jp.orb = it }
        if (orb && !overlayOk) GlassButton("Allow display over other apps", { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth())
        GlassButton("Choose Nova as the digital assistant", { try { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, Modifier.fillMaxWidth())
        GText("After choosing Nova there, the assist gesture (power-button long press or corner swipe) opens Nova and starts listening.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Calls") {
        ToggleRow("Announce who is calling", "Nova says the caller's name while the phone rings (Background Voice must be on).", callAnn) { callAnn = it; jp.callAnnounce = it }
        ToggleRow("Answer or reject by voice", "Say \"uthao\" or \"kaat do\" while it rings. Nova never touches a call on her own.", callVoice) { callVoice = it; jp.callVoiceControl = it }
        GlassButton("Allow phone and contacts access", { ask(Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS) }, Modifier.fillMaxWidth())
    }
    GlassSettingSection("Morning briefing and suggestions") {
        GlassTextField(brief, { v ->
            brief = v
            jp.briefingMinute = Regex("^(\\d{1,2}):(\\d{2})$").find(v.trim())?.let { m -> m.groupValues[1].toInt().coerceIn(0, 23) * 60 + m.groupValues[2].toInt().coerceIn(0, 59) } ?: -1
        }, Modifier.fillMaxWidth(), placeholder = "Spoken briefing time, 24h, e.g. 07:30 (empty = off)")
        GlassButton("Run briefing now", { scope.launch { briefText = "Working…"; briefText = Briefing.build(ctx, vm.prefs); vm.voice.speak(briefText, vm.emotion) } }, Modifier.fillMaxWidth())
        if (briefText.isNotBlank()) GText(briefText, size = 13.sp)
        ToggleRow("Proactive suggestions", "Event starting soon, low battery. Each is said once. Needs Background Voice on.", proactive) { proactive = it; jp.proactive = it }
        GlassButton("Allow calendar access", { ask(Manifest.permission.READ_CALENDAR) }, Modifier.fillMaxWidth())
        GText("The briefing is spoken only while Background Voice is running at that time. You can also just say \"good morning\".", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Location reminders") {
        ToggleRow("Remind me when I arrive", "Say \"yaad dilana ghar pahunchu to doodh lena\". Needs Location and Background Voice on.", loc) { loc = it; jp.locationReminders = it }
        GlassButton("Allow location", { ask(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION) }, Modifier.fillMaxWidth())
        GlassTextField(placeName, { placeName = it }, Modifier.fillMaxWidth(), placeholder = "Name this place (home, office...)")
        GlassButton("Save my current location as this place", { if (placeName.isNotBlank()) placeMsg = LocationReminders(ctx).savePlaceHere(placeName) }, Modifier.fillMaxWidth(), enabled = placeName.isNotBlank())
        if (placeMsg.isNotBlank()) GText(placeMsg, size = 12.sp, color = g.accent)
        places.forEach { GlassListItem(it.name, "Saved place") }
        rems.forEach { GlassListItem(it.place + ": " + it.what, "Waiting") }
    }
    GlassSettingSection("Car mode") {
        ToggleRow("Car mode", "Very short spoken answers, messages read aloud, call announcements on.", car) { car = it; jp.carMode = it }
        GlassTextField(carBt, { carBt = it; jp.carBtName = it }, Modifier.fillMaxWidth(), placeholder = "Your car's Bluetooth name (turns car mode on by itself)")
    }
    GlassSettingSection("Agent mode (Gemini picks the tools)") {
        ToggleRow("Agent mode", "Gemini decides which phone tool to use for open-ended requests. Anything needing confirmation is never run this way.", agent) { agent = it; jp.agent = it }
    }
    GlassSettingSection("Your wake name") {
        GlassTextField(wakeName, { wakeName = it; jp.wakeName = it }, Modifier.fillMaxWidth(), placeholder = "Name you call me (for example jarvis, max, nova)")
        ToggleRow("Offline wake word", "Nothing is sent to Gemini until the offline recognizer hears this name. Needs the offline model; uncommon names may be missed.", wakeGate) { wakeGate = it; jp.wakeGate = it }
        GText("Without the offline wake word, Nova answers only sentences that contain this name (when \"Only answer when I say Nova\" is on in Background). Restart Background Voice after changing it.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Smart home (lights and plugs)") {
        devs.forEach { d -> GlassListItem(d.name + " (" + d.kind + ", " + d.type + ")", d.aliases.ifBlank { d.host }, onClick = { devs = devs.filter { it.id != d.id }; SmartHome.save(ctx, devs) }) }
        if (devs.isNotEmpty()) GText("Tap a device to remove it.", size = 12.sp, color = g.subtext)
        GlassTextField(dName, { dName = it }, Modifier.fillMaxWidth(), placeholder = "Name (e.g. Bedroom light)")
        GlassTextField(dAlias, { dAlias = it }, Modifier.fillMaxWidth(), placeholder = "Words you say, comma separated (kamra, kamre, bedroom)")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("light", "plug").forEach { k -> GlassButton(k, { dKind = k }, primary = dKind == k) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmartHome.types.forEach { t -> GlassButton(t, { dType = t }, primary = dType == t) }
        }
        GlassTextField(dHost, { dHost = it }, Modifier.fillMaxWidth(), placeholder = when (dType) { "ha" -> "Home Assistant entity id (light.bedroom)"; "tuya" -> "Tuya device id"; "webhook" -> "(not used)"; else -> "IP address (192.168.1.50)" })
        GlassTextField(dExtra, { dExtra = it }, Modifier.fillMaxWidth(), placeholder = "Optional: relay/channel number, or Tuya switch code")
        ToggleRow("Ask me to confirm", "Use for heaters, geysers and other things you don't want switched by a misheard word.", dConfirm) { dConfirm = it }
        GlassButton("Add device", {
            if (dName.isNotBlank()) {
                devs = devs + SmartHome.Dev(System.currentTimeMillis().toString(), dName.trim(), dAlias.trim(), dKind, dType, dHost.trim(), dExtra.trim(), dConfirm)
                SmartHome.save(ctx, devs); dName = ""; dAlias = ""; dHost = ""; dExtra = ""
            }
        }, Modifier.fillMaxWidth(), primary = true, enabled = dName.isNotBlank())
        GText("tasmota, shelly1, shelly2, wled and kasa work directly on your Wi-Fi. For Tuya: use the Tuya cloud below, or add the devices to Home Assistant (type ha). Plain http on your home network is allowed for this.", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("in" to "India", "us" to "US", "eu" to "Europe", "cn" to "China").forEach { (id, label) -> GlassButton("Tuya $label", { tuyaRegion = id; jp.tuyaRegion = id }, primary = tuyaRegion == id) }
        }
        GlassTextField(tuyaId, { tuyaId = it; jp.tuyaClientId = it }, Modifier.fillMaxWidth(), placeholder = "Tuya Access ID")
        GlassTextField(tuyaSecret, { tuyaSecret = it; vm.prefs.setSecret("tuya_secret", it) }, Modifier.fillMaxWidth(), placeholder = "Tuya Access Secret (stored encrypted)")
        GlassTextField(haUrl, { haUrl = it; jp.haUrl = it }, Modifier.fillMaxWidth(), placeholder = "Home Assistant URL (http://192.168.1.10:8123)")
        GlassTextField(haToken, { haToken = it; vm.prefs.setSecret("ha_token", it) }, Modifier.fillMaxWidth(), placeholder = "Home Assistant long-lived token (stored encrypted)")
    }
    GlassSettingSection("Emergency SOS") {
        GlassTextField(sos, { sos = it; jp.sosContacts = it }, Modifier.fillMaxWidth(), placeholder = "One per line: Name:+911234567890", singleLine = false, minLines = 3)
        ToggleRow("Also call the first contact", "Nova calls the first number after sending the SMS. She never calls the police by herself.", sosCall) { sosCall = it; jp.sosCall = it }
        GlassButton("Allow SMS, calling and location", { ask(Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION) }, Modifier.fillMaxWidth())
        GText("Say \"help me Nova\". Nova waits 10 seconds (say \"cancel\" or tap Cancel in the notification), then sends your location by SMS, calls, and updates the location every 5 minutes until you cancel. This can message real people: set it up carefully and do not test with real emergency numbers.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Tasker and automation apps") {
        ToggleRow("Let Tasker control Nova", "Off by default. Other apps must send the token below, so strangers' apps can't control your phone.", taskerIn) { taskerIn = it; jp.taskerIn = it; if (it && jp.taskerToken.isBlank()) { taskerToken = TaskerBridge.newToken(); jp.taskerToken = taskerToken } }
        GlassTextField(taskerToken, { taskerToken = it; jp.taskerToken = it }, Modifier.fillMaxWidth(), placeholder = "Token")
        GlassButton("Generate new token", { taskerToken = TaskerBridge.newToken(); jp.taskerToken = taskerToken }, Modifier.fillMaxWidth())
        ToggleRow("Send events to Tasker", "Heard commands, SOS. Use Profile > Event > Intent Received.", taskerEv) { taskerEv = it; jp.taskerEvents = it }
        GText("Tasker action Send Intent: Action com.nova.ai.action.COMMAND, Cat None, Target Broadcast Receiver, Extras  command:open youtube  token:<token>  reply_package:net.dinglisch.android.tasker. The answer comes back as com.nova.ai.action.RESULT (extras command, result). Say \"tasker chalao <task>\" to run a Tasker task (turn on Allow External Access in Tasker).", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Clipboard assistant") {
        ToggleRow("Offer help for long copied text", "When you copy a long text Nova shows Summarize / Translate. Needs Background Voice on and Display over other apps.", clip) { clip = it; jp.clipboard = it }
        GlassTextField(clipMin, { clipMin = it; it.toIntOrNull()?.let { n -> jp.clipMinChars = n.coerceIn(50, 5000) } }, Modifier.fillMaxWidth(), placeholder = "Minimum length in characters (300)")
        if (!overlayOk) GlassButton("Allow display over other apps", { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth())
        GText("Android stops background apps from reading the clipboard, so Nova opens a small card that reads it only while it is on screen. Each copy can flash the card for a moment; copies from password managers are skipped.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Phone files and offline music") {
        GlassListItem("All files access", if (allFiles) "Allowed" else "Needed to search PDFs and documents")
        if (!allFiles) GlassButton("Allow all files access", { try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { ask(Manifest.permission.READ_EXTERNAL_STORAGE) } }, Modifier.fillMaxWidth())
        GText("Say \"mere phone se kal wali PDF dhundho\", then \"pehli wali kholo\". For music: \"offline gaane play karo\" or \"phone ke gaane Arijit bajao\" (needs the Music and audio permission).", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Try saying") {
        GlassListItem("Briefing", "\"good morning\", \"morning briefing\"")
        GlassListItem("Messages", "\"messages padho\", \"Rahul ko reply karo ki main aa raha hoon\"")
        GlassListItem("Calls", "\"uthao\" / \"kaat do\" while it rings")
        GlassListItem("Places", "\"ye mera ghar hai\", \"remind me to buy milk when I reach home\"")
        GlassListItem("Interpreter", "\"interpreter mode on Hindi English\", \"interpreter band karo\"")
        GlassListItem("Modes", "\"car mode on\", \"agent mode on\"")
        GlassListItem("Camera and files", "\"camera se dekho ye kya hai\", \"pdf padho\"")
        GlassListItem("Volume", "\"volume badhao\", \"mute\"")
        GlassListItem("Smart home", "\"kamre ki light off karo\", \"sab lights band karo\", \"bedroom light 40 percent\"")
        GlassListItem("Emergency", "\"help me Nova\" (then \"cancel\" to stop)")
        GlassListItem("Files", "\"mere phone se kal wali PDF dhundho\", \"offline gaane play karo\"")
    }
}
