package com.nova.ai.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream

/**
 * Prepares a photo (or ONE frame of a video) for Gemini. Called only after the user has pressed Analyze and confirmed.
 * Re-encoding to JPEG drops EXIF metadata (including GPS location). Only the pixels, downscaled, are sent.
 */
object PhotoPrivacy {
    const val MAX_PHOTOS = 4

    fun prepareJpeg(ctx: Context, uri: Uri, isVideo: Boolean, maxSide: Int = 1280): ByteArray? = try {
        val bmp: Bitmap? = if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                r.getFrameAtTime(d * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)      // middle frame, microseconds
            } finally { r.release() }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1; while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        }
        bmp?.let { b ->
            val s = minOf(1f, maxSide.toFloat() / maxOf(b.width, b.height))
            val scaled = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true) else b
            ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
        }
    } catch (e: Exception) { null }
}

/** Something the user selected or authorized: a MediaStore item or a Photo Picker result. */
data class PhotoRef(val uri: Uri, val name: String, val isVideo: Boolean)

/** Local record of every upload so the user can see exactly what was sent and when. Stores counts and times only, never images or file names. */
object UploadLedger {
    private fun file(ctx: Context) = java.io.File(ctx.filesDir, "photo_upload_log.json")
    fun list(ctx: Context): List<Triple<Long, Int, Boolean>> = try {
        val a = org.json.JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Triple(o.getLong("t"), o.getInt("n"), o.optBoolean("v")) } }
    } catch (e: Exception) { emptyList() }
    fun add(ctx: Context, count: Int, video: Boolean) {
        try {
            val cur = list(ctx).toMutableList(); cur.add(0, Triple(System.currentTimeMillis(), count, video))
            val a = org.json.JSONArray(); cur.take(40).forEach { a.put(org.json.JSONObject().put("t", it.first).put("n", it.second).put("v", it.third)) }
            file(ctx).writeText(a.toString())
        } catch (e: Exception) { }
    }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }
}
