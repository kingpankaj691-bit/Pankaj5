package com.nova.ai.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.nova.ai.notifications.NovaNotificationListener

/** Handles Android's screen-capture approval dialog for Screen Vision. */
@Composable
fun RegisterVisionLauncher(vm: NovaViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val d = res.data
        if (res.resultCode == Activity.RESULT_OK && d != null) vm.startVision(res.resultCode, d)
        else vm.note("Screen capture wasn't approved, so Screen Vision stays off.")
    }
    LaunchedEffect(vm.captureRequest) {
        if (vm.captureRequest) {
            vm.captureRequest = false
            try { launcher.launch(vm.visionConsentIntent()) } catch (e: Exception) { vm.note("This phone can't start screen capture.") }
        }
    }
}

@Composable
internal fun SubPage(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            GText(title, size = 22.sp, weight = FontWeight.SemiBold)
        }
        content()
    }
}

/** More hub: every main screen that does not fit the bottom bar. Tab numbers: 5 scan, 6 command center, 7 people, 9-14 below. */
@Composable
fun MoreHubScreen(vm: NovaViewModel, open: (Int) -> Unit) {
    val items = listOf(
        Triple("⚙", "Settings", 4), Triple("🎛", "Control", 2), Triple("💻", "Developer", 3),
        Triple("🎙", "Voice", 9), Triple("🖥", "Screen Assistant", 10), Triple("🔔", "Notifications", 11),
        Triple("📷", "Camera Vision", 16), Triple("🛠", "Developer Tools", 17), Triple("🔐", "Permissions", 12), Triple("🛡", "Privacy & Security", 13), Triple("🧭", "Command Center", 6),
        Triple("🩺", "Voice Debugger", 18), Triple("🔒", "Privacy Dashboard", 19), Triple("🧰", "Developer Integrations", 20), Triple("🎛️", "Control Center", 21), Triple("🗂️", "Asset Manager", 22), Triple("📱", "Device Management", 23), Triple("🛡️", "Security Activity", 24), Triple("🛰", "Device Intelligence", 5), Triple("👥", "People & Memory", 7), Triple("🧠", "Memory Dashboard", 25), Triple("✦", "About", 14)
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GText("More", size = 24.sp, weight = FontWeight.SemiBold)
        items.forEach { (g, t, tab) ->
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Box(Modifier.padding(horizontal = 16.dp)) { GlassListItem(t, glyph = g, onClick = { open(tab) }, trailing = { GText("›", size = 22.sp) }) }
            }
        }
    }
}

@Composable
fun VoiceScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val mic = rememberMicAction(vm)
    SubPage("Voice", onBack) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val c3 = androidx.compose.ui.platform.LocalContext.current
            if (com.nova.ai.live.LivePrefs.fx3d(c3)) {
                val st by com.nova.ai.live.LiveSession.state.collectAsState(); val amp by com.nova.ai.live.LiveSession.amplitude.collectAsState()
                val act by com.nova.ai.live.LiveSession.isActive.collectAsState()
                com.nova.ai.fx.NovaOrb3D(if (act) st else com.nova.ai.live.LiveOrbState.IDLE, 220.dp, if (act) amp else vm.voice.level)
            } else NovaOrb(vm.status, Modifier.size(200.dp), level = { vm.voice.level })
        }
        GText(
            when (vm.status) {
                "Listening" -> "Listening — Android's microphone indicator is on"
                "Thinking" -> "Thinking…"; "Speaking" -> "Speaking"; "Error" -> "Something went wrong"
                "Screen Control" -> "Controlling the screen"; else -> if (vm.online) "Ready" else "Offline — local commands only"
            }, size = 14.sp, color = LocalGlass.current.subtext
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("🎙 Talk", mic, primary = true)
            GlassButton("Stop", { vm.voice.stopSpeaking() })
            GlassButton("Resume", { vm.voice.resume() })
            GlassButton("Repeat", { vm.voice.repeat() })
        }
        GText("NOVA listens only after you tap Talk, or while the visible background-assistant notification is on. With Background Voice on, say \"Nova\" followed by your command.", size = 12.sp, color = LocalGlass.current.subtext)
        VoicePage(vm)
        BackgroundPage(vm)
        LanguagePage(vm)
    }
}

@Composable
fun ScreenAssistantScreen(vm: NovaViewModel, onBack: () -> Unit) = SubPage("Screen Assistant", onBack) { ScreenPage(vm) }

@Composable
fun NotificationsScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val lis = tick >= 0 && NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    SubPage("Notifications", onBack) {
        if (lis) {
            var shown by remember { mutableStateOf("") }
            GlassSettingSection("Ask NOVA") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Read", { shown = NovaNotificationListener.summaryText() })
                    GlassButton("Summarize", { vm.send("summarize my notifications"); onBack() }, primary = true)
                }
                if (shown.isNotBlank()) GText(shown, size = 13.sp)
            }
        } else GText("Notification access is off, so NOVA reads nothing. Enable it below if you want summaries.", size = 12.sp, color = LocalGlass.current.subtext)
        NotificationsPage(vm)
    }
}

@Composable
fun PermissionsScreen(onBack: () -> Unit) = SubPage("Permissions", onBack) { PermissionsPage() }

@Composable
fun PrivacyScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var export by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) msg = try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(export.toByteArray()) }; "Exported to the file you chose." } catch (e: Exception) { "Export failed." }
        export = ""
    }
    SubPage("Privacy & Security", onBack) {
        PrivacyPage(vm)
        SecurityPage(vm)
        GlassSettingSection("Your data") {
            GlassButton("Export my NOVA data", { export = vm.exportAllJson(); saver.launch("nova-data.json") })
            if (msg.isNotBlank()) GText(msg, size = 12.sp, color = LocalGlass.current.accent)
            GText("Export contains memories, notes, people and non-secret settings. Never your API key. \"Clear local data\" above deletes everything NOVA stores.", size = 12.sp, color = LocalGlass.current.subtext)
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) = SubPage("About NOVA", onBack) { AboutPage() }
