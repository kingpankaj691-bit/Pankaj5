package com.nova.ai.ui

import android.app.Activity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.viewModels
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : FragmentActivity() {
    private val vm: NovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        com.nova.ai.license.AccessKeyManager.refreshInfo(applicationContext)
        setContent { NovaRoot() }
    }

    override fun onResume() {
        super.onResume()
        val app = applicationContext
        Thread {
            try {
                com.nova.ai.license.AccessKeyManager.liveCheck(app)
                // a running session whose key became blocked is stopped
                if (!com.nova.ai.license.AccessKeyManager.isActive(app) && com.nova.ai.voice.VoiceState.running.value)
                    app.startService(Intent(app, com.nova.ai.voice.NovaVoiceForegroundService::class.java).setAction(com.nova.ai.voice.NovaVoiceForegroundService.ACTION_STOP))
            } catch (e: Exception) { }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** The notification "Talk" button opens the app and starts push-to-talk. */
    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("listen", false) == true) vm.autoListen = true
        if (i?.getBooleanExtra(com.nova.ai.forge.ForgeController.EXTRA_OPEN_FORGE, false) == true) com.nova.ai.forge.ForgeController.requestOpen()
        if (i?.getBooleanExtra("disarm", false) == true) {
            val app = applicationContext
            vm.auth = AuthRequest("Turn off Security Mode") { com.nova.ai.security.SecurityModeManager.disarm(app, vm.prefs) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NovaRoot() {
    val vm: NovaViewModel = viewModel()
    val dark = when (vm.themeMode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val theme = remember(dark, vm.accent, vm.blurLevel, vm.transparency, vm.reduced, vm.material) {
        GlassTheme(dark, vm.accent, vm.blurLevel, vm.transparency, vm.reduced, vm.material)
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalGlass provides theme) {
        GlassBackground(vm.emotion.tint) {
            var tab by rememberSaveable { mutableIntStateOf(0) }
            val imeUp = WindowInsets.isImeVisible
            LaunchedEffect(vm.navigateTo) { vm.navigateTo?.let { tab = it; vm.navigateTo = null } }
            BackHandler(enabled = tab != 0) { tab = if (tab in 2..3 || tab in 9..14 || tab in 16..18 || tab == 25) 8 else 0 }
            RegisterVisionLauncher(vm)
            val micAction = rememberMicAction(vm, toggle = false)
            LaunchedEffect(vm.autoListen) { if (vm.autoListen) { vm.autoListen = false; micAction() } }
            Box(Modifier.fillMaxSize().imePadding()) {
                Box(
                    Modifier.fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                        .padding(bottom = if (imeUp) 0.dp else 96.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    AnimatedContent(
                        targetState = tab,
                        modifier = Modifier.widthIn(max = 760.dp).fillMaxSize(),
                        transitionSpec = {
                            if (theme.reduced) fadeIn(snap()) togetherWith fadeOut(snap())
                            else (fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) + scaleIn(initialScale = 0.96f, animationSpec = spring(stiffness = Spring.StiffnessMediumLow))) togetherWith fadeOut(spring(stiffness = Spring.StiffnessMedium))
                        },
                        label = "tabs"
                    ) { t ->
                        when (t) {
                            0 -> HomeScreen(vm) { tab = it }
                            1 -> ChatPane(vm, dev = false)
                            2 -> ControlScreen(vm)
                            3 -> DeveloperScreen(vm)
                            4 -> SettingsScreen(vm)
                            6 -> CommandCenterScreen(vm) { tab = 0 }
                            7 -> PeopleScreen(vm) { tab = 0 }
                            8 -> MoreHubScreen(vm) { tab = it }
                            9 -> VoiceScreen(vm) { tab = 8 }
                            10 -> ScreenAssistantScreen(vm) { tab = 8 }
                            11 -> NotificationsScreen(vm) { tab = 8 }
                            12 -> PermissionsScreen { tab = 8 }
                            13 -> PrivacyScreen(vm) { tab = 8 }
                            14 -> AboutScreen { tab = 8 }
                            15 -> ToolsScreen(vm) { tab = 0 }
                            16 -> VisionScreen(vm) { tab = 8 }
                            17 -> DevToolsScreen(vm) { tab = 8 }
                            18 -> VoiceDebugScreen { tab = 8 }
                            19 -> PrivacyDashboardScreen { tab = 8 }
                            20 -> DevIntegrationsScreen { tab = 8 }
                            21 -> ControlCenterScreen({ tab = it }) { tab = 8 }
                            22 -> AssetScreen { tab = 8 }
                            23 -> DeviceMgmtScreen { tab = 8 }
                            24 -> SecurityActivityScreen { tab = 8 }
                            25 -> BrainScreen(vm) { tab = 8 }
                            else -> DeviceScanScreen(vm) { tab = 0 }
                        }
                    }
                }
                AnimatedVisibility(
                    visible = !imeUp, modifier = Modifier.align(Alignment.BottomCenter),
                    enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
                ) {
                    // Home | Tools (tab 15) | History (the chat, tab 1) | More (tab 8: Control, Developer, Settings and everything else)
                    GlassNavigationBar(
                        listOf("🏠" to "Home", "🧰" to "Tools", "🕘" to "History", "☰" to "More"),
                        when (tab) { 0 -> 0; 15 -> 1; 1 -> 2; else -> 3 }, { tab = when (it) { 0 -> 0; 1 -> 15; 2 -> 1; else -> 8 } },
                        Modifier.navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 12.dp)
                    )
                }
                val fxCtx = androidx.compose.ui.platform.LocalContext.current
                val fx = remember { com.nova.ai.live.LivePrefs.fx3d(fxCtx) }
                var splash by remember { mutableStateOf(!com.nova.ai.fx.SplashSession.played) }
                if (fx) com.nova.ai.fx.ListeningEdgeGlow()
                if (splash) NovaLogoSplash { splash = false }
                val forge by com.nova.ai.forge.ForgeController.state.collectAsState()
                val openReq by com.nova.ai.forge.ForgeController.pendingOpen.collectAsState()
                var forgeOpen by remember { mutableStateOf(false) }
                LaunchedEffect(forge.phase, openReq) {
                    if (forge.phase == com.nova.ai.forge.ForgePhase.BUILDING || openReq) { forgeOpen = true; com.nova.ai.forge.ForgeController.consumeOpen() }
                    if (forge.phase == com.nova.ai.forge.ForgePhase.IDLE) forgeOpen = false
                }
                if (forgeOpen && forge.phase != com.nova.ai.forge.ForgePhase.IDLE) com.nova.ai.forge.ForgeOverlay { forgeOpen = false }
                if (vm.wifiSheet) WifiConnectSheet(vm) { vm.wifiSheet = false }
                vm.auth?.let { a -> AuthDialog(vm, a) }
                vm.clarify?.let { c -> ClarifyDialog(vm, c) }
                vm.pending?.let { p ->
                    GlassDialog({ vm.confirmPending(false) }, "Confirm", "Yes", { vm.confirmPending(true) }) { GText(p.prompt) }
                }
            }
        }
    }
}

@Composable
fun AuthDialog(vm: NovaViewModel, a: AuthRequest) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val act = ctx as? FragmentActivity
    val g = LocalGlass.current
    val bio = act != null && com.nova.ai.security.SecurityGate.canBiometric(ctx)
    var msg by remember { mutableStateOf("") }
    GlassDialog({ vm.completeAuth(false) }, "Verify it's you") {
        GText(a.prompt)
        if (bio && act != null) GlassButton("Use fingerprint / screen lock", { com.nova.ai.security.SecurityGate.prompt(act, a.prompt) { ok -> vm.completeAuth(ok) } }, Modifier.fillMaxWidth(), primary = true)
        if (vm.prefs.protectMode == "voice_or_bio" && vm.prefs.voiceLockOn && vm.voiceLock.hasProfile())
            GlassButton("Verify my voice (weak check)", { msg = "Listening for 3 seconds…"; vm.verifyVoice { ok, m -> msg = m; if (ok) vm.completeAuth(true) } }, Modifier.fillMaxWidth())
        if (!bio) {
            GText("No fingerprint or screen lock is set up, so Android can't verify you. Set one in Android settings for real protection.", size = 12.sp, color = g.subtext)
            GlassButton("Confirm anyway", { vm.completeAuth(true) }, Modifier.fillMaxWidth())
        }
        if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)
    }
}

@Composable
fun ClarifyDialog(vm: NovaViewModel, c: com.nova.ai.commands.Clarification) {
    GlassDialog({ vm.chooseClarify(-1) }, c.title) {
        c.options.forEachIndexed { i, o -> GlassButton(o.first, { vm.chooseClarify(i) }, Modifier.fillMaxWidth(), primary = i == 0) }
    }
}
