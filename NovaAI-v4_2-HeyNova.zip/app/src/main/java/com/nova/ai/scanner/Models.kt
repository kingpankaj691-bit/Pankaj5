package com.nova.ai.scanner

import org.json.JSONArray
import org.json.JSONObject

data class ScanItem(val label: String, val value: String, val status: String? = null, val detail: String? = null)

data class ScanSection(
    val id: String, val title: String, val headline: String,
    val fraction: Float?, val items: List<ScanItem>
)

data class AppInfo(
    val name: String, val pkg: String, val version: String, val code: Long,
    val installed: Long, val updated: Long, val installer: String?, val launchable: Boolean, val category: String
)

data class Capability(val app: String, val action: String, val supported: Boolean)

data class DeviceProfile(val time: Long, val sections: List<ScanSection>, val apps: List<AppInfo>) {
    fun section(id: String): ScanSection? = sections.firstOrNull { it.id == id }

    /** Short, minimal summary. This is the only thing ever used as AI context (never the full profile). */
    fun summary(): String {
        val ids = listOf("processor", "battery", "storage", "memory", "network", "wifi", "bluetooth", "sensors", "cameras", "speech", "apps", "permissions", "nova")
        return ids.mapNotNull { section(it) }.joinToString("; ") { it.title + ": " + it.headline }
    }

    fun report(): String {
        val cats = apps.groupingBy { it.category }.eachCount().entries.sortedByDescending { it.value }
            .joinToString(", ") { "${it.key} ${it.value}" }
        val restricted = sections.flatMap { s -> s.items.filter { it.status == "Restricted" }.map { it.label } }
        return "Here's what I found. " + summary() + "." +
            (if (cats.isNotBlank()) " Apps by category: $cats." else "") +
            (if (restricted.isNotEmpty()) " Restricted without a permission: ${restricted.take(6).joinToString()}." else "")
    }

    /** Minimal context for AI questions. App names are included only when asked. */
    fun aiContext(includeApps: Boolean): String =
        "Device summary from the user's on-device scan: " + summary() +
            (if (includeApps) ". Visible apps: " + apps.take(60).joinToString { it.name } else "")

    fun toJson(): String = JSONObject()
        .put("time", time)
        .put("sections", JSONArray(sections.map { s ->
            JSONObject().put("id", s.id).put("title", s.title).put("headline", s.headline)
                .put("fraction", s.fraction?.toDouble() ?: -1.0)
                .put("items", JSONArray(s.items.map { i ->
                    JSONObject().put("l", i.label).put("v", i.value).put("s", i.status ?: "").put("d", i.detail ?: "")
                }))
        }))
        .put("apps", JSONArray(apps.map { a ->
            JSONObject().put("n", a.name).put("p", a.pkg).put("v", a.version).put("c", a.code)
                .put("i", a.installed).put("u", a.updated).put("src", a.installer ?: "")
                .put("l", a.launchable).put("cat", a.category)
        })).toString()

    companion object {
        fun fromJson(s: String): DeviceProfile? = try {
            val o = JSONObject(s)
            val secs = o.getJSONArray("sections")
            val sections = (0 until secs.length()).map { i ->
                val j = secs.getJSONObject(i)
                val its = j.getJSONArray("items")
                ScanSection(j.getString("id"), j.getString("title"), j.getString("headline"),
                    j.getDouble("fraction").let { if (it < 0) null else it.toFloat() },
                    (0 until its.length()).map { k ->
                        val x = its.getJSONObject(k)
                        ScanItem(x.getString("l"), x.getString("v"), x.optString("s").ifBlank { null }, x.optString("d").ifBlank { null })
                    })
            }
            val ap = o.getJSONArray("apps")
            val apps = (0 until ap.length()).map { i ->
                val a = ap.getJSONObject(i)
                AppInfo(a.getString("n"), a.getString("p"), a.getString("v"), a.getLong("c"), a.getLong("i"), a.getLong("u"),
                    a.optString("src").ifBlank { null }, a.getBoolean("l"), a.getString("cat"))
            }
            DeviceProfile(o.getLong("time"), sections, apps)
        } catch (e: Exception) { null }
    }
}
