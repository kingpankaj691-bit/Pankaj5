package com.nova.ai.screen

import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.NovaAction
import com.nova.ai.ai.NovaIntent
import com.nova.ai.security.Prefs

sealed class Verdict {
    object Allowed : Verdict()
    data class NeedsConfirm(val reason: String) : Verdict()
    data class Denied(val reason: String) : Verdict()
}

/**
 * Safety checks for every screen action. NOVA never acts in payment/banking/password-manager apps,
 * never types into password / PIN / OTP fields, and asks before anything that spends money, deletes, installs or sends.
 */
object ActionValidator {
    /** Apps where NOVA refuses to act on the screen at all. */
    private val blockedPackages = setOf(
        "com.google.android.apps.nbu.paisa.user", "com.phonepe.app", "net.one97.paytm", "in.org.npci.upiapp",
        "com.google.android.apps.walletnfcrel", "com.paypal.android.p2pmobile", "com.samsung.android.spay",
        "com.bitwarden.mobile", "com.x8bit.bitwarden", "com.lastpass.lpandroid", "com.onepassword.android",
        "com.agilebits.onepassword", "com.android.settings.intelligence", "com.google.android.packageinstaller",
        "com.android.packageinstaller"
    )
    private val blockedHints = listOf("bank", "banking", "wallet", "passwords", "authenticator")
    /** "upi" only counts as a whole dot/underscore-separated word, so it can't match inside unrelated package names. */
    private val upiWord = Regex("(^|[._])upi([._]|$)")
    private val risky = Regex(
        "\\b(pay|payment|send money|transfer|buy|purchase|order now|place order|checkout|subscribe now|delete|remove|uninstall|erase|" +
            "factory reset|reset|format|install|allow|grant|permit|turn off|disable|sign out|log out|logout|send|post|publish|confirm|submit|" +
            "accept|agree|decline|block|report|unfollow|clear data|clear all)\\b", RegexOption.IGNORE_CASE
    )

    private val secretLike = Regex("(password|passcode|\\bpin\\b|\\botp\\b|\\bcvv\\b|card number|\\b\\d{12,19}\\b)", RegexOption.IGNORE_CASE)

    /** Field labels / ids that mean "credential": NOVA never types into these (a postal "PIN code" is fine). */
    private val secretField = Regex(
        "(password|passcode|passphrase|\\bpin\\b(?!\\s*-?\\s*code)|\\botp\\b|one[- ]?time|verification code|security code|\\bcvv\\b|\\bcvc\\b|card number|\\bmpin\\b)",
        RegexOption.IGNORE_CASE
    )

    /**
     * Checks an action the LLM asked for. Returns null when it may go ahead, otherwise the reason it was refused.
     * The LLM never runs anything itself; this is the gate between its plan and the CommandExecutor.
     */
    fun forIntent(intent: NovaIntent): String? {
        val a = intent.action
        val arg = intent.arg
        if (arg.any { it.isISOControl() }) return "That request had characters Nova won't act on."
        if (a.takesArg && arg.isBlank() && a != NovaAction.OPEN_SETTINGS) return "I need to know what to use for that action."
        if (a == NovaAction.REMEMBER && secretLike.containsMatchIn(arg)) return "I don't store passwords, PINs, OTPs or card numbers."
        return null
    }

    fun isRisky(text: String): Boolean = risky.containsMatchIn(text)

    fun isSecretField(label: String): Boolean = secretField.containsMatchIn(label)

    fun packageBlocked(pkg: String): Boolean {
        if (pkg.isBlank()) return false
        val l = pkg.lowercase()
        return pkg in blockedPackages || l in blockedPackages || blockedHints.any { l.contains(it) } || upiWord.containsMatchIn(l)
    }

    /** Pure core of [base]: easy to unit-test without Android. */
    fun baseFor(connected: Boolean, screenActionsOn: Boolean, foreground: String): Verdict {
        if (!connected)
            return Verdict.Denied("Screen control isn't connected. Open Screen Assistant and turn the NOVA AI accessibility service on (if it already shows ON, switch it off and on once).")
        if (!screenActionsOn) return Verdict.Denied("Screen actions are switched off in Screen Assistant.")
        if (packageBlocked(foreground)) return Verdict.Denied("I don't act inside payment, banking or password apps. Please do this one yourself.")
        return Verdict.Allowed
    }

    fun base(prefs: Prefs): Verdict =
        baseFor(NovaAccessibilityService.instance != null, prefs.screenActionsOn, NovaAccessibilityService.activePackage())

    /** Check a tap/long-press on a labelled control. */
    fun forElement(prefs: Prefs, e: UiElement?, intent: String = ""): Verdict {
        val b = base(prefs)
        if (b !is Verdict.Allowed) return b
        if (e == null) return Verdict.Allowed
        if (e.password) return Verdict.Denied("That is a password field, so I won't touch it.")
        val text = (e.label + " " + intent)
        if (risky.containsMatchIn(text)) return Verdict.NeedsConfirm("\"${e.label.take(40)}\" looks like a sensitive action")
        return Verdict.Allowed
    }

    /**
     * Check opening a piece of CONTENT (a search result, a video, a chat row). Its title is not an instruction, so a
     * video called "How to buy bitcoin" is not treated as a purchase button. Password fields and blocked apps still stop it.
     */
    fun forContent(prefs: Prefs, e: UiElement?): Verdict {
        val b = base(prefs)
        if (b !is Verdict.Allowed) return b
        if (e?.password == true) return Verdict.Denied("That is a password field, so I won't touch it.")
        return Verdict.Allowed
    }

    /** Typing: never into password / PIN / OTP / card fields, whatever the field is called. */
    fun forTyping(prefs: Prefs, target: UiElement?, text: String? = null): Verdict {
        val b = base(prefs)
        if (b !is Verdict.Allowed) return b
        if (target?.password == true) return Verdict.Denied("I won't type into password fields.")
        if (target != null && isSecretField(target.label + " " + target.hint + " " + target.desc + " " + target.viewId))
            return Verdict.Denied("That looks like a password, PIN or OTP field, so I won't type into it. Please enter it yourself.")
        return Verdict.Allowed
    }

    /** Coordinate gestures have no label, so a long press / drag by raw coordinates always asks. */
    fun forGesture(prefs: Prefs, needsConfirm: Boolean = false): Verdict {
        val b = base(prefs)
        if (b !is Verdict.Allowed) return b
        return if (needsConfirm) Verdict.NeedsConfirm("This gesture has no label I can check") else Verdict.Allowed
    }
}
