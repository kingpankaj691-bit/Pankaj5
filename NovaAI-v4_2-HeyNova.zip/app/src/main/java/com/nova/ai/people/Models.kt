package com.nova.ai.people

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

/** One person the USER has explicitly introduced. Nothing here is ever guessed or learned from audio or camera. */
@Entity(tableName = "persons")
data class PersonEntity(
    @PrimaryKey(autoGenerate = true) val personId: Long = 0,
    val name: String,
    val nickname: String = "",
    val preferredAddress: String = "",
    val relType: String,
    val relLabel: String,
    val category: String,
    val userConfirmed: Boolean = true,
    val createdAt: Long,
    val lastInteraction: Long,
    val confidence: String = "HIGH",
    val source: String = "",
    val reason: String = "",
    /** "" (auto), friendly, formal, casual, funny, respectful, short, detailed */
    val style: String = "",
    val aiContextAllowed: Boolean = true,
    val lastContext: String = "",
    /** Tone of the USER's recent messages about this person. It is NOT the person's real mood. */
    val lastTone: String = "",
    val contextUpdatedAt: Long = 0,
    /** Only text the user explicitly provided. */
    val notes: String = ""
)

@Entity(
    tableName = "aliases",
    foreignKeys = [ForeignKey(entity = PersonEntity::class, parentColumns = ["personId"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("personId"), Index(value = ["personId", "alias"], unique = true)]
)
data class AliasEntity(@PrimaryKey(autoGenerate = true) val aliasId: Long = 0, val personId: Long, val alias: String)

@Entity(
    tableName = "person_memories",
    foreignKeys = [ForeignKey(entity = PersonEntity::class, parentColumns = ["personId"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("personId")]
)
data class PersonMemoryEntity(
    @PrimaryKey(autoGenerate = true) val memoryId: Long = 0,
    val personId: Long,
    /** RELATION | FACT | CONTEXT | NOTE */
    val kind: String,
    val content: String,
    val confidence: String,
    val source: String,
    val importance: Float,
    val createdAt: Long,
    val lastUsedAt: Long,
    val expiresAt: Long,
    val userConfirmed: Boolean,
    val reason: String
)

@Entity(tableName = "blocked_patterns")
data class BlockedEntity(@PrimaryKey val hash: String, val label: String)

data class PersonWithData(
    @Embedded val person: PersonEntity,
    @Relation(parentColumn = "personId", entityColumn = "personId") val aliases: List<AliasEntity>,
    @Relation(parentColumn = "personId", entityColumn = "personId") val memories: List<PersonMemoryEntity>
)

enum class RelationshipType(val key: String, val label: String, val category: String, val words: List<String>) {
    MUMMY("mummy", "Mummy", "Family", listOf("mummy", "mommy", "mom", "maa", "mother", "ammi", "mata")),
    PAPA("papa", "Papa", "Family", listOf("papa", "dad", "daddy", "father", "pita", "abbu", "pitaji")),
    BHAI("bhai", "Bhai", "Family", listOf("bhai", "brother", "bhaiya")),
    BEHEN("behen", "Behen", "Family", listOf("behen", "bahan", "sister", "didi")),
    DADA("dada", "Dada", "Family", listOf("dada", "grandfather")),
    DADI("dadi", "Dadi", "Family", listOf("dadi", "grandmother")),
    NANA("nana", "Nana", "Family", listOf("nana")),
    NANI("nani", "Nani", "Family", listOf("nani")),
    CHACHA("chacha", "Chacha", "Family", listOf("chacha", "uncle")),
    MAMA("mama", "Mama", "Family", listOf("mama")),
    BUA("bua", "Bua", "Family", listOf("bua", "aunt")),
    COUSIN("cousin", "Cousin", "Family", listOf("cousin")),
    BEST_FRIEND("best_friend", "Best friend", "Friends", listOf("best friend", "bestie")),
    DOST("dost", "Dost", "Friends", listOf("dost", "friend", "yaar", "buddy")),
    TEACHER("teacher", "Teacher", "Work/School", listOf("teacher", "tutor")),
    COLLEAGUE("colleague", "Colleague", "Work/School", listOf("colleague", "coworker")),
    OTHER("other", "Other", "Other", emptyList());

    companion object {
        fun byKey(k: String) = values().firstOrNull { it.key == k } ?: OTHER
        fun find(word: String): RelationshipType? {
            val w = word.lowercase().trim()
            return values().firstOrNull { rt -> rt.words.any { it == w } }
        }
        fun alternation(): String = values().flatMap { it.words }.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        fun matches(personRel: String, rt: RelationshipType) = personRel == rt.key || (rt == DOST && personRel == BEST_FRIEND.key)
        fun sameGroup(a: String, b: String) = a == b || (setOf(a, b) == setOf(DOST.key, BEST_FRIEND.key))
    }
}

sealed class Resolution {
    object None : Resolution()
    class One(val p: PersonWithData) : Resolution()
    class Many(val list: List<PersonWithData>, val query: String) : Resolution()
}

sealed class IntroOutcome {
    class Created(val p: PersonWithData) : IntroOutcome()
    class Updated(val p: PersonWithData, val note: String) : IntroOutcome()
    class Duplicate(val p: PersonWithData) : IntroOutcome()
    class NeedsMerge(val existing: PersonWithData, val name: String, val rt: RelationshipType, val label: String?) : IntroOutcome()
}

fun normName(s: String): String = s.lowercase().replace(Regex("[^\\p{L}0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
fun capName(s: String): String = s.trim().split(" ").filter { it.isNotBlank() }.joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
