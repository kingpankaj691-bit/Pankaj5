package com.nova.ai.files

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipFile

/** Text Nova pulled out of a file on the phone. [method] says how, so the answer is honest about OCR or partial reads. */
data class DocText(val ok: Boolean, val text: String, val note: String = "", val truncated: Boolean = false, val method: String = "")

/**
 * Reads documents on the phone, no network, pure JVM (tested against generated fixtures).
 * Supported here: TXT/MD/LOG/code, CSV/JSON/XML, HTML, DOCX, ODT, XLSX, PPTX, ZIP listings. PDF (on-device OCR) and APK info need Android and live in FileReader.
 * Old binary .doc/.xls/.ppt are NOT supported and the result says so instead of showing garbage.
 */
object DocReader {
    const val MAX_CHARS = 30_000            // also the most that can ever be sent to Gemini
    const val PREVIEW_CHARS = 1_500
    private const val MAX_BYTES = 8L * 1024 * 1024
    private const val MAX_XML = 20L * 1024 * 1024

    fun readable(name: String): Boolean = when (FileTypes.extOf(name)) {
        "txt", "md", "log", "ini", "cfg", "conf", "properties", "csv", "tsv", "json", "xml", "html", "htm", "xhtml",
        "docx", "odt", "xlsx", "pptx", "zip", "jar" -> true
        else -> FileTypes.kindOf(name) == FileKind.CODE
    }

    fun read(file: File, maxChars: Int = MAX_CHARS): DocText {
        if (!file.isFile) return DocText(false, "", "That file isn't available.")
        val kind = FileTypes.kindOf(file.name); val ext = FileTypes.extOf(file.name)
        return try {
            when {
                ext == "docx" -> finish(docxText(file), "DOCX text", maxChars)
                ext == "odt" -> finish(odtText(file), "ODT text", maxChars)
                ext == "xlsx" -> finish(xlsxText(file), "XLSX first sheet", maxChars)
                ext == "pptx" -> finish(pptxText(file), "PPTX slide text", maxChars)
                ext == "zip" || ext == "jar" -> finish(zipListing(file), "ZIP listing (names only)", maxChars)
                ext == "doc" || ext == "dot" -> DocText(false, "", "Old binary .doc files can't be read on the phone. Save it as .docx or PDF and try again.")
                ext == "xls" || ext == "ppt" -> DocText(false, "", "Old binary .$ext files can't be read on the phone. Save it as .${ext}x or PDF and try again.")
                ext == "rtf" || ext == "ods" || ext == "odp" -> DocText(false, "", "Nova can't read .$ext yet.")
                kind == FileKind.WEB -> plain(file, maxChars, html = true)
                kind == FileKind.TEXT || kind == FileKind.CODE || kind == FileKind.DATA -> plain(file, maxChars, html = false)
                else -> DocText(false, "", "Nova can't read ${kind.label.lowercase()} files as text.")
            }
        } catch (e: Exception) { DocText(false, "", "I couldn't read that file: ${e.message?.take(80)}") }
    }

    private fun finish(text: String, method: String, max: Int): DocText {
        val t = tidy(text)
        if (t.isBlank()) return DocText(false, "", "I found no text in it.", false, method)
        return if (t.length > max) DocText(true, t.take(max), "Only the first $max characters were read.", true, method) else DocText(true, t, "", false, method)
    }

    private fun plain(f: File, max: Int, html: Boolean): DocText {
        val bytes = ByteArrayOutputStream()
        f.inputStream().use { i -> val buf = ByteArray(32 * 1024); var total = 0L; var n: Int
            while (i.read(buf).also { n = it } > 0 && total < MAX_BYTES) { bytes.write(buf, 0, n); total += n } }
        val s = String(bytes.toByteArray(), Charsets.UTF_8)
        val sample = s.take(4000)
        if (sample.isNotEmpty() && sample.count { it.isISOControl() && it != '\n' && it != '\r' && it != '\t' || it == '\uFFFD' } * 20 > sample.length)
            return DocText(false, "", "This doesn't look like a text file (it seems to be binary).")
        val r = finish(if (html) stripHtml(s) else s, if (html) "HTML text" else "Plain text", max)
        return if (f.length() > MAX_BYTES && r.ok) r.copy(truncated = true, note = "Only the start of this large file was read.") else r
    }

    fun tidy(s: String): String = s.replace("\r\n", "\n").replace('\r', '\n').replace(Regex("[ \\t]+\\n"), "\n").replace(Regex("\\n{3,}"), "\n\n").trim()

    fun unescape(s: String): String = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
        .replace(Regex("&#(\\d+);")) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it.coerceIn(32, 0x10FFFF))) } ?: "" }
        .replace(Regex("&#x([0-9a-fA-F]+);")) { m -> m.groupValues[1].toIntOrNull(16)?.let { String(Character.toChars(it.coerceIn(32, 0x10FFFF))) } ?: "" }
        .replace("&amp;", "&")

    fun stripHtml(html: String): String {
        var s = html.replace(Regex("(?is)<(script|style|head)[^>]*>.*?</\\1>"), " ")
        s = s.replace(Regex("(?i)<br\\s*/?>|</(p|div|li|tr|h[1-6])>"), "\n").replace(Regex("<[^>]+>"), " ")
        return unescape(s).replace(Regex("[ \\t]{2,}"), " ")
    }

    private fun entry(z: ZipFile, name: String): String? {
        val e = z.getEntry(name) ?: return null
        if (e.size > MAX_XML) throw IllegalStateException("part of the document is too large")
        return z.getInputStream(e).use { String(it.readNBytesCapped(MAX_XML), Charsets.UTF_8) }
    }

    private fun java.io.InputStream.readNBytesCapped(cap: Long): ByteArray {
        val out = ByteArrayOutputStream(); val buf = ByteArray(32 * 1024); var total = 0L; var n: Int
        while (read(buf).also { n = it } > 0) { total += n; if (total > cap) throw IllegalStateException("part of the document is too large"); out.write(buf, 0, n) }
        return out.toByteArray()
    }

    fun docxText(f: File): String = ZipFile(f).use { z ->
        val xml = entry(z, "word/document.xml") ?: return@use ""
        val sb = StringBuilder()
        Regex("<w:t(?:\\s[^>]*)?>([\\s\\S]*?)</w:t>|</w:p>|<w:tab\\s*/>|<w:br\\s*/>").findAll(xml).forEach { m ->
            if (m.groups[1] != null) sb.append(unescape(m.groupValues[1]))
            else if (m.value.startsWith("<w:tab")) sb.append('\t')
            else sb.append('\n')
        }
        sb.toString()
    }

    fun odtText(f: File): String = ZipFile(f).use { z ->
        val xml = entry(z, "content.xml") ?: return@use ""
        unescape(xml.replace(Regex("</text:(p|h)>"), "\n").replace(Regex("<text:tab\\s*/>"), "\t").replace(Regex("<[^>]+>"), ""))
    }

    fun pptxText(f: File): String = ZipFile(f).use { z ->
        val names = z.entries().asSequence().map { it.name }.filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0 }.toList()
        val sb = StringBuilder()
        names.forEachIndexed { i, n ->
            sb.append("--- Slide ${i + 1} ---\n")
            val xml = entry(z, n).orEmpty()
            Regex("<a:t>([\\s\\S]*?)</a:t>|</a:p>").findAll(xml).forEach { m -> if (m.groups[1] != null) sb.append(unescape(m.groupValues[1])) else sb.append('\n') }
            sb.append('\n')
        }
        sb.toString()
    }

    fun colIndex(ref: String): Int {
        var n = 0; for (c in ref) { if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1) else break }; return (n - 1).coerceAtLeast(0)
    }

    fun xlsxText(f: File, maxRows: Int = 400): String = ZipFile(f).use { z ->
        val shared = ArrayList<String>()
        entry(z, "xl/sharedStrings.xml")?.let { xml ->
            Regex("<si>([\\s\\S]*?)</si>").findAll(xml).forEach { si -> shared.add(unescape(Regex("<t[^>]*>([\\s\\S]*?)</t>").findAll(si.groupValues[1]).joinToString("") { it.groupValues[1] })) }
        }
        val sheetName = z.entries().asSequence().map { it.name }.filter { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0 }.firstOrNull() ?: return@use ""
        val xml = entry(z, sheetName).orEmpty()
        val sb = StringBuilder(); var rows = 0
        for (row in Regex("<row\\b[^>]*>([\\s\\S]*?)</row>").findAll(xml)) {
            if (rows++ >= maxRows) { sb.append("… (more rows not read)\n"); break }
            val cells = ArrayList<String>()
            for (c in Regex("<c\\b([^>]*?)(?:/>|>([\\s\\S]*?)</c>)").findAll(row.groupValues[1])) {
                val attrs = c.groupValues[1]; val body = c.groupValues[2]
                val idx = colIndex(Regex("r=\"([A-Z]+)\\d*\"").find(attrs)?.groupValues?.get(1).orEmpty())
                val type = Regex("t=\"(\\w+)\"").find(attrs)?.groupValues?.get(1)
                val v = Regex("<v>([\\s\\S]*?)</v>").find(body)?.groupValues?.get(1)
                val text = when (type) {
                    "s" -> shared.getOrNull(v?.toIntOrNull() ?: -1).orEmpty()
                    "inlineStr" -> unescape(Regex("<t[^>]*>([\\s\\S]*?)</t>").findAll(body).joinToString("") { it.groupValues[1] })
                    else -> unescape(v.orEmpty())
                }
                while (cells.size <= idx) cells.add("")
                cells[idx] = text
            }
            sb.append(cells.joinToString(" | ").trimEnd(' ', '|')).append('\n')
        }
        sb.toString()
    }

    fun zipListing(f: File, maxEntries: Int = 200): String = ZipFile(f).use { z ->
        val all = z.entries().asSequence().toList()
        val sb = StringBuilder("${all.count { !it.isDirectory }} files, ${all.count { it.isDirectory }} folders\n")
        all.take(maxEntries).forEach { sb.append(if (it.isDirectory) "📁 " else "• ").append(it.name).append(if (it.isDirectory) "" else "  (${FileFormat.size(it.size.coerceAtLeast(0))})").append('\n') }
        if (all.size > maxEntries) sb.append("… and ${all.size - maxEntries} more\n")
        sb.toString()
    }
}
