package com.nova.ai.suite

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** One command waiting for the user's approval. Nothing runs until [TermuxBridge.run] is called with it. */
data class PendingCommand(val id: Long, val command: String, val workDir: String, val reason: String)

data class TermuxResult(val commandId: Long, val exitCode: Int, val stdout: String, val stderr: String, val error: String)

/**
 * Talks to Termux through its documented RUN_COMMAND intent. Requirements (Android/Termux, not Nova): Termux installed, Nova granted
 * "Run commands in Termux environment" permission, and `allow-external-apps = true` in ~/.termux/termux.properties.
 * Every command is shown first and only runs after the user approves it; destructive patterns are refused even if approved.
 */
object TermuxBridge {
    const val PACKAGE = "com.termux"
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val SERVICE = "com.termux.app.RunCommandService"
    private const val ACTION = "com.termux.RUN_COMMAND"
    const val RESULT_ACTION = "com.nova.ai.action.TERMUX_RESULT"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"

    private val _last = MutableStateFlow<TermuxResult?>(null)
    val last: StateFlow<TermuxResult?> = _last
    private var nextId = 1L
    private val blocked = listOf(
        Regex("""rm\s+-[a-z]*r[a-z]*f?\s+(/|~|${'$'}HOME|\*)(\s|$)"""), Regex("""mkfs"""), Regex("""dd\s+if=.*of=/dev/"""),
        Regex(""":\(\)\s*\{"""), Regex("""chmod\s+-R\s+777\s+/"""), Regex("""curl[^|]*\|\s*(ba)?sh"""), Regex("""wget[^|]*\|\s*(ba)?sh""")
    )

    fun installed(ctx: Context): Boolean = try { ctx.packageManager.getPackageInfo(PACKAGE, 0); true } catch (e: PackageManager.NameNotFoundException) { false }
    fun permissionGranted(ctx: Context): Boolean = ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** Returns null when the command is acceptable, otherwise the reason it is refused. */
    fun refusal(command: String): String? {
        val c = command.trim()
        if (c.isEmpty()) return "Empty command."
        if (c.length > 2000) return "Command too long to review."
        blocked.firstOrNull { it.containsMatchIn(c) }?.let { return "This looks destructive or downloads and runs unknown code, so Nova won't send it to Termux." }
        return null
    }

    /** Presets so common developer jobs don't need free-form shell. */
    fun gitStatus(dir: String) = "git -C '${q(dir)}' status --short --branch"
    fun gitDiffStat(dir: String) = "git -C '${q(dir)}' diff --stat"
    fun gitLog(dir: String) = "git -C '${q(dir)}' log --oneline -n 10"
    fun gradleAssembleDebug(dir: String) = "cd '${q(dir)}' && ./gradlew assembleDebug --console=plain"
    fun gitCommit(dir: String, message: String) = "git -C '${q(dir)}' add -A && git -C '${q(dir)}' commit -m '${q(message)}'"
    fun gitPush(dir: String) = "git -C '${q(dir)}' push"
    private fun q(s: String) = s.replace("'", "'\\''")

    fun prepare(command: String, workDir: String = HOME, reason: String = ""): Pair<PendingCommand?, String?> {
        val why = refusal(command)
        if (why != null) return null to why
        return PendingCommand(nextId++, command.trim(), workDir.ifBlank { HOME }, reason) to null
    }

    /** Sends an approved command. Returns an error text or null on success. */
    fun run(ctx: Context, cmd: PendingCommand): String? {
        if (!Features.enabled(ctx, Features.TERMUX)) return Features.off("Termux integration")
        if (!installed(ctx)) return "Termux isn't installed."
        if (!permissionGranted(ctx)) return "Termux permission is missing: Android Settings > Apps > Nova AI > Permissions > Additional permissions > Run commands in Termux environment."
        refusal(cmd.command)?.let { return it }
        return try {
            val result = Intent(RESULT_ACTION).setClass(ctx, TermuxResultReceiver::class.java).putExtra("cmd_id", cmd.id)
            val flags = PendingIntent.FLAG_ONE_SHOT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(ctx, cmd.id.toInt(), result, flags)
            val i = Intent(ACTION).setComponent(ComponentName(PACKAGE, SERVICE))
                .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
                .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", cmd.command))
                .putExtra("com.termux.RUN_COMMAND_WORKDIR", cmd.workDir)
                .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                .putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            null
        } catch (e: SecurityException) {
            "Termux refused: set allow-external-apps = true in ~/.termux/termux.properties and restart Termux."
        } catch (e: Exception) { "Couldn't reach Termux: ${e.message}" }
    }

    internal fun deliver(r: TermuxResult) { _last.value = r }
}

class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val b = intent.getBundleExtra("result")
        val r = TermuxResult(
            commandId = intent.getLongExtra("cmd_id", 0L),
            exitCode = b?.getInt("exitCode", -1) ?: -1,
            stdout = (b?.getString("stdout") ?: "").take(20000),
            stderr = (b?.getString("stderr") ?: "").take(20000),
            error = b?.getString("errmsg") ?: ""
        )
        TermuxBridge.deliver(r)
    }
}
