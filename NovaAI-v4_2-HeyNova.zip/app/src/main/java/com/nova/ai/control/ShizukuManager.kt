package com.nova.ai.control

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_INSTALLED, NOT_RUNNING, UNSUPPORTED_VERSION, NEEDS_PERMISSION, PERMISSION_DENIED, READY }

data class ShizukuSnapshot(
    val installed: Boolean = false, val running: Boolean = false, val granted: Boolean = false,
    val permanentlyDenied: Boolean = false, val serverVersion: Int = -1, val serverUid: Int = -1,
    val serviceBound: Boolean = false, val status: ShizukuStatus = ShizukuStatus.NOT_INSTALLED, val detail: String = ""
) {
    /** "adb" (shell uid 2000), "root" (uid 0) or "unknown". Root is only ever what the user chose in Shizuku; Nova never needs it. */
    val mode: String get() = when (serverUid) { 2000 -> "adb (shell)"; 0 -> "root"; -1 -> "unknown"; else -> "uid $serverUid" }
}

class ShellResult(val ok: Boolean, val exitCode: Int, val out: String, val err: String, val blocked: Boolean = false) {
    override fun toString() = if (ok) out.trim() else (err.ifBlank { out }).trim()
}

/**
 * Owns the Shizuku connection: install/running/permission detection, permission request, binder lifecycle,
 * user-service binding with one automatic reconnect, and command execution through [ShellPolicy].
 * It never claims access it does not have: [exec] fails with a clear message unless status is READY and the service is bound.
 */
object ShizukuManager {
    const val PACKAGE = "moe.shizuku.privileged.api"
    private const val REQ_CODE = 7421

    private val _state = MutableStateFlow(ShizukuSnapshot())
    val state: StateFlow<ShizukuSnapshot> = _state

    @Volatile private var ctx: Context? = null
    @Volatile private var service: IShellService? = null
    @Volatile private var binding: CompletableDeferred<Boolean>? = null
    @Volatile private var permResult: CompletableDeferred<Boolean>? = null
    @Volatile private var inited = false
    private val bindLock = Mutex()      // two commands at once must not both rebind (the second would orphan the first's wait)

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(ctx!!.packageName, ShellUserService::class.java.name))
            .processNameSuffix("shell").daemon(false).version(2)   // bump when ShellUserService / ShellPolicy change so an old shell process is replaced
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            binding?.complete(service != null); refresh()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null; refresh() }
    }

    fun init(context: Context) {
        if (inited) { refresh(); return }
        ctx = context.applicationContext
        inited = true
        try {
            Shizuku.addBinderReceivedListenerSticky { refresh() }
            Shizuku.addBinderDeadListener { service = null; refresh() }
            Shizuku.addRequestPermissionResultListener { code, result ->
                if (code == REQ_CODE) { permResult?.complete(result == PackageManager.PERMISSION_GRANTED); refresh() }
            }
        } catch (e: Throwable) { /* Shizuku classes unavailable: state stays NOT_RUNNING/NOT_INSTALLED, nothing is faked */ }
        refresh()
    }

    private fun installed(c: Context) = try { c.packageManager.getPackageInfo(PACKAGE, 0); true } catch (e: Exception) { false }

    /** Re-reads everything from the system. Cheap; safe to call from the UI whenever it resumes. */
    fun refresh(): ShizukuSnapshot {
        val c = ctx ?: return _state.value
        val inst = installed(c)
        var running = false; var granted = false; var perm = false; var ver = -1; var uid = -1; var pre = false
        try {
            running = Shizuku.pingBinder()
            if (running) {
                pre = Shizuku.isPreV11()
                ver = Shizuku.getVersion(); uid = Shizuku.getUid()
                if (!pre) {
                    granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    perm = !granted && Shizuku.shouldShowRequestPermissionRationale()   // true after the user pressed "Deny forever"? see note in requestPermission
                }
            }
        } catch (e: Throwable) { running = false }
        val status = when {
            !inst && !running -> ShizukuStatus.NOT_INSTALLED
            !running -> ShizukuStatus.NOT_RUNNING
            pre || ver in 0..10 -> ShizukuStatus.UNSUPPORTED_VERSION
            granted -> ShizukuStatus.READY
            perm -> ShizukuStatus.PERMISSION_DENIED
            else -> ShizukuStatus.NEEDS_PERMISSION
        }
        val detail = when (status) {
            ShizukuStatus.NOT_INSTALLED -> "Shizuku app is not installed. Install it from its official page, start it, then come back."
            ShizukuStatus.NOT_RUNNING -> "Shizuku is installed but not running. Open Shizuku and start it (wireless debugging, adb, or root)."
            ShizukuStatus.UNSUPPORTED_VERSION -> "This Shizuku version is too old (needs v11+). Update the Shizuku app."
            ShizukuStatus.NEEDS_PERMISSION -> "Shizuku is running. Nova has not been given access yet."
            ShizukuStatus.PERMISSION_DENIED -> "Access was denied. Open Shizuku → Authorized apps and allow Nova AI."
            ShizukuStatus.READY -> if (service != null) "Connected." else "Permission granted; shell service not connected yet."
        }
        val s = ShizukuSnapshot(inst, running, granted, perm, ver, uid, running && service?.asBinder()?.pingBinder() == true, status, detail)
        _state.value = s
        return s
    }

    /** Shows Shizuku's own permission dialog. Returns true only if Shizuku reports the permission as granted afterwards. */
    suspend fun requestPermission(): Boolean {
        val s = refresh()
        if (s.status == ShizukuStatus.READY) return true
        if (s.status != ShizukuStatus.NEEDS_PERMISSION && s.status != ShizukuStatus.PERMISSION_DENIED) return false
        val d = CompletableDeferred<Boolean>(); permResult = d
        return try {
            Shizuku.requestPermission(REQ_CODE)
            withTimeoutOrNull(60_000) { d.await() } ?: false
        } catch (e: Throwable) { false } finally { permResult = null; refresh() }
    }

    private suspend fun ensureService(): Boolean {
        if (service?.asBinder()?.pingBinder() == true) return true
        return bindLock.withLock {
            if (service?.asBinder()?.pingBinder() == true) return@withLock true
            service = null
            if (refresh().status != ShizukuStatus.READY) return@withLock false
            val d = CompletableDeferred<Boolean>(); binding = d
            try {
                withContext(Dispatchers.Main) { Shizuku.bindUserService(args, conn) }
                withTimeoutOrNull(8_000) { d.await() } ?: false
            } catch (e: Throwable) { false } finally { binding = null; refresh() }
        }
    }

    /** Drops and re-opens the shell service. Used by the "Reconnect" button and by automatic error recovery. */
    suspend fun reconnect(): Boolean {
        try { withContext(Dispatchers.Main) { Shizuku.unbindUserService(args, conn, true) } } catch (e: Throwable) { }
        service = null
        refresh()
        return ensureService()
    }

    /** Runs one allow-listed command. Never throws; failures are explained in the result. */
    suspend fun exec(command: String, timeoutMs: Int = 8_000): ShellResult {
        when (val d = ShellPolicy.validate(command)) {
            is ShellPolicy.Decision.Deny -> return ShellResult(false, 126, "", d.reason, blocked = true)
            is ShellPolicy.Decision.Allow -> Unit
        }
        val st = refresh().status
        if (st != ShizukuStatus.READY) return ShellResult(false, 125, "", "Shizuku is not ready (${st.name.lowercase().replace('_', ' ')}).")
        repeat(2) { attempt ->
            if (!ensureService()) return@repeat
            val svc = service ?: return@repeat
            try {
                val raw = withContext(Dispatchers.IO) { svc.exec(command, timeoutMs) }
                val parts = raw.split('\u0001')
                val code = parts.getOrNull(0)?.toIntOrNull() ?: 1
                return ShellResult(code == 0, code, parts.getOrElse(1) { "" }, parts.getOrElse(2) { "" })
            } catch (e: Throwable) {            // binder died mid-call: reset once and retry
                service = null
                if (attempt == 1) return ShellResult(false, 1, "", "Shizuku connection was lost: ${e.message}")
            }
        }
        return ShellResult(false, 1, "", "Could not connect to the Shizuku shell service.")
    }

    suspend fun testConnection(): ShellResult = exec("getprop ro.build.version.sdk")

    /** Runs a real command through the whole chain (policy → Shizuku → shell) and checks the ANSWER, not just that nothing crashed. */
    suspend fun selfTest(): ShizukuSelfTest.Result = ShizukuSelfTest.evaluate(testConnection(), Build.VERSION.SDK_INT)

    fun sdk() = Build.VERSION.SDK_INT
}
