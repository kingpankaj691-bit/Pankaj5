package com.nova.ai.device

import android.bluetooth.BluetoothManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONArray
import org.json.JSONObject

class Change(val area: String, val text: String)

/** Cheap change detection (package list, Android build, Bluetooth, network type, storage in 5% steps). No heavy scan. */
class DeviceChangeDetector(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)
    private val pm = ctx.packageManager

    @Suppress("DEPRECATION")
    private fun current(): JSONObject {
        val pk = JSONObject()
        pm.getInstalledPackages(0).forEach { pk.put(it.packageName, PackageInfoCompat.getLongVersionCode(it)) }
        val st = StatFs(Environment.getDataDirectory().path)
        val used = 1.0 - st.availableBlocksLong.toDouble() / st.blockCountLong
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            else -> "Other"
        }
        val bt = try { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true } catch (e: Exception) { false }
        return JSONObject().put("sdk", Build.VERSION.SDK_INT).put("build", Build.ID).put("pkgs", pk)
            .put("bt", bt).put("net", net).put("storage", (used * 20).toInt())
    }

    private fun label(pkg: String) = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

    @Synchronized
    fun detect(): List<Change> {
        val now = current()
        val oldStr = sp.getString("snapshot", null)
        sp.edit().putString("snapshot", now.toString()).apply()
        if (oldStr == null) return emptyList()
        val old = try { JSONObject(oldStr) } catch (e: Exception) { return emptyList() }
        val out = mutableListOf<Change>()
        val a = old.optJSONObject("pkgs") ?: JSONObject()
        val b = now.getJSONObject("pkgs")
        val added = b.keys().asSequence().filter { !a.has(it) }.toList()
        val removed = a.keys().asSequence().filter { !b.has(it) }.toList()
        val updated = b.keys().asSequence().count { a.has(it) && a.optLong(it) != b.optLong(it) }
        if (added.isNotEmpty()) out.add(Change("apps", "Installed: " + added.take(4).joinToString { label(it) } + if (added.size > 4) " and ${added.size - 4} more" else ""))
        if (removed.isNotEmpty()) out.add(Change("apps", "Removed: " + removed.take(4).joinToString() + if (removed.size > 4) " and ${removed.size - 4} more" else ""))
        if (updated > 0) out.add(Change("apps", "$updated app(s) updated"))
        if (old.optInt("sdk") != now.optInt("sdk") || old.optString("build") != now.optString("build")) out.add(Change("android", "Android system was updated"))
        if (old.optBoolean("bt") != now.optBoolean("bt")) out.add(Change("bluetooth", "Bluetooth turned " + if (now.optBoolean("bt")) "on" else "off"))
        if (old.optString("net") != now.optString("net")) out.add(Change("network", "Network changed: ${old.optString("net")} → ${now.optString("net")}"))
        val ds = now.optInt("storage") - old.optInt("storage")
        if (ds != 0) out.add(Change("storage", "Storage use ${if (ds > 0) "grew" else "shrank"} by about ${Math.abs(ds) * 5}%"))
        if (out.isNotEmpty()) appendLog(out)
        return out
    }

    private fun appendLog(cs: List<Change>) {
        val arr = try { JSONArray(sp.getString("change_log", "[]")) } catch (e: Exception) { JSONArray() }
        cs.forEach { arr.put(JSONObject().put("t", System.currentTimeMillis()).put("text", it.text)) }
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 30) until arr.length()) trimmed.put(arr.get(i))
        sp.edit().putString("change_log", trimmed.toString()).apply()
    }

    fun log(): List<Pair<Long, String>> {
        val arr = try { JSONArray(sp.getString("change_log", "[]")) } catch (e: Exception) { return emptyList() }
        return (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.getLong("t") to o.getString("text") } }.reversed()
    }

    fun clearLog() { sp.edit().remove("change_log").apply() }
}
