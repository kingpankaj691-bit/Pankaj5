package com.nova.ai.control

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import com.nova.ai.NovaApp
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.device.DeviceController
import com.nova.ai.suite.SystemControls
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class OpResult(val status: TaskStatus, val message: String, val method: String = "", val before: String = "", val after: String = "", val attempts: Int = 1) {
    val ok get() = status == TaskStatus.VERIFIED
}

/**
 * Unified device-control engine: understand → check current state → pick the best AVAILABLE method
 * (Android API → Shizuku → official Settings screen) → run → READ THE STATE BACK → retry → report honestly.
 * An operation is only called VERIFIED when the state was read back and matches. Otherwise it is UNVERIFIED / FAILED /
 * NEEDS_USER / UNSUPPORTED, and the message says which.
 */
object ControlEngine {
    private class M(val name: String, val usable: Boolean, val why: String, val act: suspend () -> String?)
    private class Spec(
        val title: String, val methods: List<M>, val read: suspend () -> String?, val verify: (String?) -> Boolean,
        val settleMs: Long = 600, val fallback: (() -> String)? = null, val done: (String?) -> String = { "Done." }
    )

    private val ctx: Context get() = NovaApp.instance
    private fun t(h: Boolean, hi: String, en: String) = if (h) hi else en
    private var nextId = 1L

    private val device by lazy { DeviceController(ctx) }

    suspend fun run(op: ControlOp, hinglish: Boolean = false, confirm: suspend (String) -> Boolean = { false }): OpResult {
        TaskHistory.init(ctx); ShizukuManager.init(ctx)
        val id = System.currentTimeMillis() * 1000 + (nextId++ % 1000)
        val title = describe(op)
        TaskHistory.log.add(TaskRecord(id, System.currentTimeMillis(), title, "", TaskStatus.RUNNING, "Working…"))
        val r = try { dispatch(op, hinglish, confirm) } catch (e: kotlinx.coroutines.CancellationException) {
            TaskHistory.log.update(TaskRecord(id, System.currentTimeMillis(), title, "", TaskStatus.CANCELLED, "Cancelled")); TaskHistory.save(); throw e
        } catch (e: Exception) { OpResult(TaskStatus.FAILED, t(hinglish, "Kuch gadbad ho gayi: ${e.message}", "Something went wrong: ${e.message}")) }
        TaskHistory.log.update(TaskRecord(id, System.currentTimeMillis(), title, r.method, r.status, r.message, r.before, r.after, r.attempts))
        TaskHistory.save()
        return r
    }

    fun describe(op: ControlOp) = when (op) {
        is ControlOp.Brightness -> "Brightness " + (op.pct?.let { "→ $it%" } ?: op.delta?.let { if (it > 0) "up" else "down" })
        is ControlOp.Volume -> "Volume " + (op.pct?.let { "→ $it%" } ?: op.delta?.let { if (it > 0) "up" else "down" })
        is ControlOp.Torch -> "Flashlight " + if (op.on) "on" else "off"
        is ControlOp.Wifi -> "Wi-Fi " + if (op.on) "on" else "off"
        is ControlOp.Bluetooth -> "Bluetooth " + if (op.on) "on" else "off"
        is ControlOp.Dnd -> "Do Not Disturb " + if (op.on) "on" else "off"
        is ControlOp.AutoRotate -> "Auto-rotate " + if (op.on) "on" else "off"
        is ControlOp.ScreenTimeout -> "Screen timeout ${op.seconds}s"
        is ControlOp.ForceStop -> "Force-stop ${op.query}"
        is ControlOp.Key -> "Key ${op.name}"
        is ControlOp.Uninstall -> "Uninstall ${op.query}"
        is ControlOp.InstallApk -> "Install APK ${op.query}".trim()
        ControlOp.Battery -> "Battery info"; ControlOp.Storage -> "Storage info"; ControlOp.DeviceInfo -> "Device info"
        ControlOp.ShizukuStatusOp -> "Shizuku status"; ControlOp.ControlStatus -> "Control status"
    }

    private suspend fun dispatch(op: ControlOp, h: Boolean, confirm: suspend (String) -> Boolean): OpResult = when (op) {
        is ControlOp.Brightness -> brightness(op, h)
        is ControlOp.Volume -> volume(op, h)
        is ControlOp.Torch -> torch(op.on, h)
        is ControlOp.Wifi -> wifi(op.on, h)
        is ControlOp.Bluetooth -> bluetooth(op.on, h)
        is ControlOp.Dnd -> dnd(op.on, h)
        is ControlOp.AutoRotate -> writeSetting("Auto-rotate", Settings.System.ACCELEROMETER_ROTATION, "accelerometer_rotation", if (op.on) 1 else 0, h,
            t(h, "Auto-rotate ${if (op.on) "on" else "off"} ho gaya.", "Auto-rotate is ${if (op.on) "on" else "off"}."))
        is ControlOp.ScreenTimeout -> writeSetting("Screen timeout", Settings.System.SCREEN_OFF_TIMEOUT, "screen_off_timeout", op.seconds * 1000, h,
            t(h, "Screen timeout ${op.seconds} second kar diya.", "Screen timeout is now ${op.seconds} seconds."))
        is ControlOp.ForceStop -> forceStop(op.query, h, confirm)
        is ControlOp.Key -> key(op.name, h)
        is ControlOp.Uninstall -> uninstall(op.query, h, confirm)
        is ControlOp.InstallApk -> installApk(op.query, h, confirm)
        ControlOp.Battery -> OpResult(TaskStatus.VERIFIED, SystemControls.batteryInfo(ctx), "Android API")
        ControlOp.Storage -> OpResult(TaskStatus.VERIFIED, storage(), "Android API")
        ControlOp.DeviceInfo -> OpResult(TaskStatus.VERIFIED, device.deviceInfo(), "Android API")
        ControlOp.ShizukuStatusOp -> OpResult(TaskStatus.VERIFIED, ShizukuManager.refresh().let { "Shizuku: ${it.status.name.lowercase().replace('_', ' ')}. ${it.detail}" }, "Shizuku")
        ControlOp.ControlStatus -> OpResult(TaskStatus.VERIFIED, Capabilities.summary(ctx), "Capabilities")
    }

    // ───────── generic verified runner ─────────
    private suspend fun execute(s: Spec, h: Boolean): OpResult {
        val before = try { s.read() } catch (e: Exception) { null }
        if (before != null && s.verify(before)) return OpResult(TaskStatus.VERIFIED, t(h, "Pehle se hi aisa hai.", "It was already like that."), "state check", before ?: "", before ?: "")
        var attempts = 0; var lastErr = ""; var dispatched = false; var usedMethod = ""
        val usable = s.methods.filter { it.usable }
        for (m in usable) {
            for (i in 1..2) {
                attempts++
                val err = try { m.act() } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { e.message ?: "error" }
                if (err != null) { lastErr = "${m.name}: $err"; if (i == 1) delay(300); continue }
                dispatched = true; usedMethod = m.name
                var waited = 0L; var after: String? = null
                while (true) {
                    after = try { s.read() } catch (e: Exception) { null }
                    if (after != null && s.verify(after)) return OpResult(TaskStatus.VERIFIED, s.done(after), m.name, before ?: "", after, attempts)
                    if (waited >= s.settleMs) break
                    delay(300); waited += 300
                }
                lastErr = if (after == null) "" else "${m.name} accepted the command but the state did not change (now: $after)"
                if (after == null) return OpResult(TaskStatus.UNVERIFIED, t(h, "Command bhej diya (${m.name} se), par result confirm nahi kar paaya.", "I sent the command via ${m.name}, but I can't read the state back to confirm it."), m.name, before ?: "", "", attempts)
            }
        }
        if (dispatched) return OpResult(TaskStatus.FAILED, t(h, "Koshish ki (${usedMethod}), par badlaav dikha nahi. $lastErr", "I tried via $usedMethod but it didn't take effect. $lastErr"), usedMethod, before ?: "", "", attempts)
        val why = s.methods.filter { !it.usable }.joinToString(" ") { "${it.name}: ${it.why}" }
        if (lastErr.isNotBlank()) return OpResult(TaskStatus.FAILED, lastErr, "", before ?: "", "", attempts)
        val fb = s.fallback?.invoke()
        return if (fb != null) OpResult(TaskStatus.NEEDS_USER, fb, "Settings screen", before ?: "")
        else OpResult(TaskStatus.UNSUPPORTED, t(h, "Ye abhi nahi ho sakta. $why", "I can't do that right now. $why"), "", before ?: "")
    }

    // ───────── helpers ─────────
    private fun canWrite() = Settings.System.canWrite(ctx)
    private val shizukuReady get() = ShizukuManager.state.value.status == ShizukuStatus.READY || ShizukuManager.refresh().status == ShizukuStatus.READY
    private suspend fun sh(cmd: String): String? = ShizukuManager.exec(cmd).let { if (it.ok) null else it.toString().ifBlank { "failed" } }
    private fun openWriteSettings(): String = try {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        "Is change ke liye “Modify system settings” allow karna padega. Maine wo page khol diya; Nova AI on karke dobara bolo."
    } catch (e: Exception) { "Settings > Apps > Nova AI > Modify system settings allow karo, phir dobara bolo." }
    private fun sysInt(name: String): String? = try { Settings.System.getInt(ctx.contentResolver, name).toString() } catch (e: Exception) { null }

    private suspend fun writeSetting(title: String, key: String, shellKey: String, value: Int, h: Boolean, ok: String): OpResult =
        execute(Spec(title, listOf(
            M("Settings API", canWrite(), "needs 'Modify system settings'") { try { if (Settings.System.putInt(ctx.contentResolver, key, value)) null else "refused" } catch (e: Exception) { e.message } },
            M("Shizuku", shizukuReady, "Shizuku not ready") { sh("settings put system $shellKey $value") }
        ), { sysInt(key) }, { it == value.toString() }, fallback = { openWriteSettings() }, done = { ok }), h)

    // ───────── operations ─────────
    private suspend fun brightness(op: ControlOp.Brightness, h: Boolean): OpResult {
        val cur = sysInt(Settings.System.SCREEN_BRIGHTNESS)?.toIntOrNull() ?: return OpResult(TaskStatus.FAILED, t(h, "Brightness padh nahi paaya.", "I can't read the current brightness."))
        val curPct = (cur * 100 + 127) / 255
        val target = (op.pct ?: (curPct + (op.delta ?: 0))).coerceIn(1, 100)
        if (op.pct == null && target == curPct) return OpResult(TaskStatus.VERIFIED, t(h, "Brightness pehle se $curPct% hai, isse aur ${if ((op.delta ?: 0) < 0) "kam" else "zyada"} nahi ho sakti.", "Brightness is already at its limit ($curPct%)."), "state check", "$curPct%", "$curPct%")
        val v = (target * 255 / 100).coerceIn(1, 255)
        val auto = sysInt(Settings.System.SCREEN_BRIGHTNESS_MODE) == "1"
        val r = execute(Spec("Brightness", listOf(
            M("Settings API", canWrite(), "needs 'Modify system settings'") { try { if (Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)) null else "refused" } catch (e: Exception) { e.message } },
            M("Shizuku", shizukuReady, "Shizuku not ready") { sh("settings put system screen_brightness $v") }
        ), { sysInt(Settings.System.SCREEN_BRIGHTNESS) }, { x -> x?.toIntOrNull()?.let { kotlin.math.abs(it - v) <= 3 } == true },
            fallback = { openWriteSettings() }, done = { x -> t(h, "Brightness $curPct% se ${((x?.toIntOrNull() ?: v) * 100 + 127) / 255}% kar di.", "Brightness changed from $curPct% to ${((x?.toIntOrNull() ?: v) * 100 + 127) / 255}%.") }), h)
        return if (r.ok && auto) OpResult(r.status, r.message + t(h, " (Adaptive brightness on hai, isliye Android ise khud badal sakta hai.)", " (Adaptive brightness is on, so Android may adjust it again.)"), r.method, r.before, r.after, r.attempts) else r
    }

    private suspend fun volume(op: ControlOp.Volume, h: Boolean): OpResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val targetPct = op.pct ?: ((cur * 100 / max) + (op.delta ?: 0))
        val idx = (targetPct.coerceIn(0, 100) * max / 100.0).let { Math.round(it).toInt() }.coerceIn(0, max)
        return execute(Spec("Volume", listOf(
            M("AudioManager", true, "") { try { am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0); null } catch (e: SecurityException) { "blocked by Do Not Disturb policy" } }
        ), { am.getStreamVolume(AudioManager.STREAM_MUSIC).toString() }, { it == idx.toString() },
            done = { t(h, "Volume ${idx * 100 / max}% par hai.", "Volume is at ${idx * 100 / max}%.") }), h)
    }

    private suspend fun torchState(): Boolean? = withTimeoutOrNull(800) {
        suspendCancellableCoroutine<Boolean> { c ->
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { cm.unregisterTorchCallback(this); if (c.isActive) c.resume(enabled) }
            }
            cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
            c.invokeOnCancellation { try { cm.unregisterTorchCallback(cb) } catch (e: Exception) { } }
        }
    }

    private suspend fun torch(on: Boolean, h: Boolean): OpResult = execute(Spec("Flashlight", listOf(
        M("Camera API", true, "") { val r = device.torch(on); if (r.startsWith("Flashlight")) null else r }
    ), { torchState()?.toString() }, { it == on.toString() }, done = { t(h, "Flashlight ${if (on) "on" else "off"} hai.", "Flashlight is ${if (on) "on" else "off"}.") }), h)

    private suspend fun wifi(on: Boolean, h: Boolean): OpResult {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return execute(Spec("Wi-Fi", listOf(
            M("Shizuku", shizukuReady, "Shizuku not ready; Android 10+ doesn't let apps switch Wi-Fi") { sh("svc wifi ${if (on) "enable" else "disable"}") }
        ), { wm.isWifiEnabled.toString() }, { it == on.toString() }, settleMs = 4000,
            fallback = {
                try {
                    val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
                    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    t(h, "Android apps ko Wi-Fi seedha badalne nahi deta. Maine Wi-Fi panel khol diya hai, wahan se ${if (on) "on" else "off"} kar do. (Shizuku se ye automatic ho jaata hai.)", "Android doesn't let apps switch Wi-Fi directly. I opened the Wi-Fi panel; please turn it ${if (on) "on" else "off"} there. (Shizuku makes this automatic.)")
                } catch (e: Exception) { t(h, "Wi-Fi panel nahi khul paaya.", "I couldn't open the Wi-Fi panel.") }
            }, done = { t(h, "Wi-Fi ${if (on) "on" else "off"} ho gaya.", "Wi-Fi is ${if (on) "on" else "off"}.") }), h)
    }

    private fun btState(): String? {
        if (Build.VERSION.SDK_INT >= 31 && ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return null
        return try { ((ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true).toString() } catch (e: Exception) { null }
    }

    private suspend fun bluetooth(on: Boolean, h: Boolean): OpResult = execute(Spec("Bluetooth", listOf(
        M("Shizuku", shizukuReady, "Shizuku not ready") { sh("svc bluetooth ${if (on) "enable" else "disable"}") }
    ), { btState() }, { it == on.toString() }, settleMs = 3000,
        fallback = { if (on) device.requestBluetoothOn() else { SystemControls.openBluetooth(ctx) + " " + t(h, "Android apps ko Bluetooth band karne nahi deta; wahan se band kar do.", "Android won't let apps turn Bluetooth off; please switch it off there.") } },
        done = { t(h, "Bluetooth ${if (on) "on" else "off"} ho gaya.", "Bluetooth is ${if (on) "on" else "off"}.") }), h)

    private suspend fun dnd(on: Boolean, h: Boolean): OpResult {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return execute(Spec("Do Not Disturb", listOf(
            M("Notification policy access", nm.isNotificationPolicyAccessGranted, "needs Do Not Disturb access") {
                nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL); null },
            M("Shizuku", shizukuReady, "Shizuku not ready") { sh("cmd notification set_dnd ${if (on) "priority" else "off"}") }
        ), { SystemControls.dndOn(ctx).toString() }, { it == on.toString() }, fallback = { SystemControls.setDnd(ctx, on) },
            done = { t(h, "Do Not Disturb ${if (on) "on" else "off"} hai.", "Do Not Disturb is ${if (on) "on" else "off"}.") }), h)
    }

    private fun storage(): String {
        val s = StatFs(Environment.getDataDirectory().path)
        fun gb(b: Long) = String.format("%.1f GB", b / 1073741824.0)
        return "Storage: ${gb(s.availableBytes)} free of ${gb(s.totalBytes)}."
    }

    private suspend fun forceStop(query: String, h: Boolean, confirm: suspend (String) -> Boolean): OpResult {
        val q = query.lowercase().trim()
        val matches = device.listApps().filter { it.first.lowercase() == q }.ifEmpty { device.listApps().filter { it.first.lowercase().contains(q) } }
        if (matches.isEmpty()) return OpResult(TaskStatus.FAILED, t(h, "“$query” naam ka koi app nahi mila.", "I couldn't find an app called “$query”."))
        if (matches.size > 1 && matches.none { it.first.lowercase() == q }) return OpResult(TaskStatus.FAILED, t(h, "Kai apps match hue: ${matches.take(4).joinToString { it.first }}. Poora naam batao.", "Several apps match: ${matches.take(4).joinToString { it.first }}. Say the full name."))
        val (label, pkg) = matches.first()
        if (ShellPolicy.isProtectedPackage(pkg)) return OpResult(TaskStatus.DENIED, t(h, "$label ek system ya security app hai, ise main band nahi karta.", "$label is a system or security app; I won't stop it."))
        if (!shizukuReady) {
            return try {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                OpResult(TaskStatus.NEEDS_USER, t(h, "Android apps ko doosre app ko force-stop nahi karne deta. $label ka App info khol diya, wahan “Force stop” dabao. (Shizuku se ye ho sakta hai.)", "Android doesn't let apps force-stop other apps. I opened $label's App info; tap “Force stop” there. (Shizuku can do this.)"), "Settings screen")
            } catch (e: Exception) { OpResult(TaskStatus.UNSUPPORTED, t(h, "$label ka App info nahi khul paaya.", "Couldn't open App info for $label.")) }
        }
        if (!confirm(t(h, "$label ko force-stop kar doon? Usme unsaved kaam ja sakta hai.", "Force-stop $label? Unsaved work in it may be lost."))) return OpResult(TaskStatus.CANCELLED, t(h, "Theek hai, cancel kar diya.", "Okay, cancelled."))
        val err = sh("am force-stop $pkg")
        return if (err == null) OpResult(TaskStatus.UNVERIFIED, t(h, "$label ke liye force-stop command chal gaya (Shizuku). Android doosre app ki running state padhne nahi deta, isliye main confirm nahi kar sakta.", "The force-stop command for $label ran via Shizuku. Android doesn't let me read another app's running state, so I can't confirm it."), "Shizuku")
        else OpResult(TaskStatus.FAILED, t(h, "Force-stop fail hua: $err", "Force-stop failed: $err"), "Shizuku")
    }

    private suspend fun uninstall(query: String, h: Boolean, confirm: suspend (String) -> Boolean): OpResult =
        when (val p = com.nova.ai.control.AppPick.pick(AppInstaller.installedApps(ctx), query)) {
            AppPick.Pick.NotFound -> OpResult(TaskStatus.FAILED, t(h, "“$query” naam ka koi app nahi mila.", "I couldn't find an app called “$query”."))
            is AppPick.Pick.Ambiguous -> OpResult(TaskStatus.FAILED, t(h, "Kai apps match hue: ${p.names.joinToString()}. Poora naam batao.", "Several apps match: ${p.names.joinToString()}. Say the full name."))
            is AppPick.Pick.Found -> AppInstaller.uninstall(ctx, p.label, p.pkg, h, confirm)
        }

    private suspend fun installApk(query: String, h: Boolean, confirm: suspend (String) -> Boolean): OpResult {
        val (apks, problem) = AppInstaller.findApks(ctx)
        if (problem != null) return OpResult(TaskStatus.NEEDS_USER, t(h, "APK files dhundh nahi sakti. $problem", "I can't look for APK files. $problem"))
        val names = ApkPick.match(apks.map { it.name }, query)
        if (names.isEmpty()) return OpResult(TaskStatus.FAILED, if (query.isBlank()) t(h, "Phone me koi APK file nahi mili.", "I didn't find any APK file on this phone.") else t(h, "“$query” naam ki APK nahi mili.", "I couldn't find an APK matching “$query”."))
        if (query.isNotBlank() && names.size > 1 && names.map { it.lowercase() }.distinct().size > 1)
            return OpResult(TaskStatus.FAILED, t(h, "Kai APK match hui: ${names.take(4).joinToString()}. Poora naam batao.", "Several APKs match: ${names.take(4).joinToString()}. Say the full name."))
        val f = apks.first { it.name == names.first() }
        return AppInstaller.installApk(ctx, f.uri, f.path, f.name, h, confirm)
    }

    private val keyMap = mapOf("back" to "KEYCODE_BACK", "home" to "KEYCODE_HOME", "recents" to "KEYCODE_APP_SWITCH", "play_pause" to "KEYCODE_MEDIA_PLAY_PAUSE", "next" to "KEYCODE_MEDIA_NEXT", "previous" to "KEYCODE_MEDIA_PREVIOUS")

    private suspend fun key(name: String, h: Boolean): OpResult {
        val code = keyMap[name.lowercase()] ?: return OpResult(TaskStatus.UNSUPPORTED, "Unknown key: $name")
        val a11y = NovaAccessibilityService.instance
        if (a11y != null && name.lowercase() == "back") if (a11y.back()) return OpResult(TaskStatus.UNVERIFIED, t(h, "Back dabaya (Accessibility). Screen badli ya nahi, ye alag se dekhna padega.", "Pressed Back via Accessibility. I haven't checked the screen changed."), "Accessibility")
        if (a11y != null && name.lowercase() == "home") if (a11y.home()) return OpResult(TaskStatus.UNVERIFIED, t(h, "Home dabaya (Accessibility).", "Pressed Home via Accessibility."), "Accessibility")
        if (!shizukuReady) return OpResult(TaskStatus.UNSUPPORTED, t(h, "Iske liye Accessibility ya Shizuku on hona chahiye.", "That needs Accessibility or Shizuku to be on."))
        val err = sh("input keyevent $code")
        return if (err == null) OpResult(TaskStatus.UNVERIFIED, t(h, "$name key bheji (Shizuku).", "Sent the $name key via Shizuku."), "Shizuku") else OpResult(TaskStatus.FAILED, err, "Shizuku")
    }
}
