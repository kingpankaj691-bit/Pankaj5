package com.nova.ai.forge

import com.nova.ai.ai.ModelCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Streams a website from Gemini (SSE). Keys, prompts and HTML are never logged. */
class WebsiteForgeClient(private val apiKey: String, private val fallbackModel: String) {

    class Result(val text: String, val finishReason: String?, val httpCode: Int, val error: String?)

    companion object {
        internal val http: OkHttpClient by lazy {
            OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).build()
        }
        @Volatile private var cachedModel: String? = null
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"

        /** Picks a flash model from ListModels (never a hard-coded id). Falls back to [fallback] if the lookup fails. */
        internal fun resolveModel(apiKey: String, fallback: String): String {
            cachedModel?.let { return it }
            try {
                http.newCall(Request.Builder().url(BASE + "models?pageSize=200").header("x-goog-api-key", apiKey).build()).execute().use { r ->
                    if (!r.isSuccessful) return ModelCatalog.clean(fallback, ModelCatalog.DEFAULT_CHAT)
                    val arr = JSONObject(r.body?.string().orEmpty()).optJSONArray("models") ?: return ModelCatalog.clean(fallback, ModelCatalog.DEFAULT_CHAT)
                    val gen = ArrayList<String>()
                    for (i in 0 until arr.length()) {
                        val m = arr.optJSONObject(i) ?: continue
                        val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                        var ok = false
                        for (k in 0 until methods.length()) if (methods.optString(k) == "generateContent") ok = true
                        if (ok) gen.add(m.optString("name").removePrefix("models/"))
                    }
                    val pick = pickModel(gen) ?: return ModelCatalog.clean(fallback, ModelCatalog.DEFAULT_CHAT)
                    cachedModel = pick
                    return pick
                }
            } catch (e: Exception) { return ModelCatalog.clean(fallback, ModelCatalog.DEFAULT_CHAT) }
        }

        internal fun pickModel(generateContentModels: List<String>): String? =
            generateContentModels.firstOrNull { n -> n.contains("flash") && listOf("live", "image", "tts").none { n.contains(it) } }
                ?: generateContentModels.firstOrNull()
    }

    suspend fun stream(system: String, user: String, onDelta: (String) -> Unit): Result = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext Result("", null, 0, "No Gemini API key set. Add one in Settings.")
        val model = resolveModel(apiKey, fallbackModel)
        val gen = JSONObject().put("temperature", 0.9)
        if (model.contains("2.5")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))   // otherwise the first token takes a minute
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
            .put("generationConfig", gen)
        val req = Request.Builder()
            .url(BASE + "models/$model:streamGenerateContent?alt=sse")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val call = http.newCall(req)
        val job = currentCoroutineContext()[Job]
        job?.invokeOnCompletion { if (it != null) call.cancel() }          // cancelling the collector cancels the network call
        val sb = StringBuilder()
        var finish: String? = null
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) {
                    val detail = try { JSONObject(r.body?.string().orEmpty()).optJSONObject("error")?.optString("status").orEmpty() } catch (e: Exception) { "" }
                    return@withContext Result("", null, r.code, ForgeErrors.friendly(r.code, detail).let { if (ForgeErrors.isOverloaded(r.code, detail)) "OVERLOADED" else it })
                }
                val src = r.body?.source() ?: return@withContext Result("", null, r.code, "Empty response from Gemini.")
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = src.readUtf8Line() ?: break
                    val data = SseParser.dataOf(line) ?: continue
                    SseParser.extractError(data)?.let { e ->
                        return@withContext Result(sb.toString(), finish, 0, if (ForgeErrors.isOverloaded(0, e)) "OVERLOADED" else ForgeErrors.friendly(0, e))
                    }
                    val t = SseParser.extractText(data)
                    if (t.isNotEmpty()) { sb.append(t); onDelta(t) }
                    SseParser.extractFinishReason(data)?.let { finish = it }
                }
            }
        } catch (e: IOException) {
            currentCoroutineContext().ensureActive()
            return@withContext Result(sb.toString(), finish, 0, "Couldn't reach Gemini. Check your internet connection.")
        }
        Result(sb.toString(), finish, 200, null)
    }
}
