package com.nova.ai.security

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech

/**
 * The security alarm: Android's alarm sound plus a spoken warning, for a limited time. Nothing here records or captures anything.
 * The sound uses the alarm audio stream, so the phone's alarm volume applies (Nova does not change your system volume).
 */
class SecurityAlarmManager private constructor(private val app: Context) {
    companion object {
        @Volatile private var inst: SecurityAlarmManager? = null
        fun get(ctx: Context): SecurityAlarmManager =
            inst ?: synchronized(this) { inst ?: SecurityAlarmManager(ctx.applicationContext).also { inst = it } }
        private const val REPEAT_MS = 6000L
    }

    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile var active = false
        private set
    private var message = ""
    private val repeat = object : Runnable {
        override fun run() { if (active) { speakNow(); main.postDelayed(this, REPEAT_MS) } }
    }
    private val autoStop = Runnable { stop() }

    fun trigger(p: Prefs, test: Boolean = false) {
        main.post { start(p, test) }
    }

    private fun start(p: Prefs, test: Boolean) {
        if (active) return
        active = true
        message = p.secWarning
        val seconds = if (test) 5 else p.secAlarmSec
        if (p.secAlarmSound) startSound()
        if (p.secSpeak) {
            if (tts == null) tts = TextToSpeech(app) { st -> ttsReady = st == TextToSpeech.SUCCESS; if (ttsReady && active) speakNow() }
            else if (ttsReady) speakNow()
            main.postDelayed(repeat, REPEAT_MS)
        }
        main.postDelayed(autoStop, seconds * 1000L)
    }

    private fun speakNow() {
        val t = tts ?: return
        if (!ttsReady) return
        try {
            t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            t.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nova_security")
        } catch (e: Exception) { }
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            mp.setDataSource(app, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) { player = null }
    }

    fun stop() {
        main.post {
            active = false
            main.removeCallbacks(repeat); main.removeCallbacks(autoStop)
            try { player?.stop() } catch (e: Exception) { }
            try { player?.release() } catch (e: Exception) { }
            player = null
            try { tts?.stop() } catch (e: Exception) { }
        }
    }

    fun release() {
        stop()
        main.post { try { tts?.shutdown() } catch (e: Exception) { }; tts = null; ttsReady = false }
    }
}
