package com.nova.ai.accessibility

/** Why screen control cannot be used right now (pure data, no Android classes, so it can be unit-tested). */
enum class A11yProblem { NONE, NOT_ENABLED_IN_SETTINGS, NOT_CONNECTED, ACTIONS_SWITCH_OFF, SCREEN_UNREADABLE, BLOCKED_APP }

/** How a tap was delivered. STALE means the element no longer exists, so nothing was tapped. */
enum class TapMethod { NODE, GESTURE, STALE, NONE }

/**
 * One honest snapshot of screen-control readiness. Each field is a separate fact:
 * "enabled in Settings" and "service connected" are NOT the same thing (Samsung can leave a service ON but unbound).
 */
data class A11yStatus(
    /** null = could not be read. */
    val enabledInSettings: Boolean?,
    val connected: Boolean,
    val screenReadable: Boolean,
    val screenActionsOn: Boolean,
    val foreground: String,
    val blockedForeground: Boolean
) {
    val problem: A11yProblem
        get() = when {
            !connected && enabledInSettings == false -> A11yProblem.NOT_ENABLED_IN_SETTINGS
            !connected -> A11yProblem.NOT_CONNECTED
            !screenActionsOn -> A11yProblem.ACTIONS_SWITCH_OFF
            !screenReadable -> A11yProblem.SCREEN_UNREADABLE
            blockedForeground -> A11yProblem.BLOCKED_APP
            else -> A11yProblem.NONE
        }

    val ready: Boolean get() = problem == A11yProblem.NONE

    fun explain(hinglish: Boolean = false): String = when (problem) {
        A11yProblem.NONE ->
            if (hinglish) "Screen control tayyar hai (app: ${foreground.ifBlank { "unknown" }})." else "Screen control is ready (app: ${foreground.ifBlank { "unknown" }})."
        A11yProblem.NOT_ENABLED_IN_SETTINGS ->
            if (hinglish) "NOVA AI ka Accessibility service band hai. Settings → Accessibility me on karo."
            else "The NOVA AI accessibility service is off. Turn it on in Settings → Accessibility."
        A11yProblem.NOT_CONNECTED ->
            if (hinglish) "Accessibility on dikh raha hai par service connect nahi hai. Ek baar off karke phir on karo."
            else "Accessibility shows ON but the service isn't connected. Switch it off and on once."
        A11yProblem.ACTIONS_SWITCH_OFF ->
            if (hinglish) "Screen actions ka master switch band hai (Screen Assistant me on karo)."
            else "The Screen actions master switch is off (turn it on in Screen Assistant)."
        A11yProblem.SCREEN_UNREADABLE ->
            if (hinglish) "Service connected hai par abhi screen padhi nahi ja sakti (app accessibility info nahi deta ya screen badal rahi hai)."
            else "The service is connected but the screen can't be read right now (the app hides its UI from accessibility, or the screen is changing)."
        A11yProblem.BLOCKED_APP ->
            if (hinglish) "Ye payment/banking/password app hai, yahan main kuch nahi karungi."
            else "This is a payment, banking or password app, so I won't act here."
    }
}

/** Parses Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES (pure, so it can be unit-tested). */
object EnabledServiceParser {
    /** True when [raw] lists pkg/cls, in the long form (pkg/pkg.Cls) or the short form (pkg/.Cls). */
    fun contains(raw: String?, pkg: String, cls: String): Boolean {
        if (raw.isNullOrBlank()) return false
        return raw.split(':').any { entry ->
            val e = entry.trim()
            val slash = e.indexOf('/')
            if (slash <= 0 || slash == e.lastIndex) false
            else {
                val p = e.substring(0, slash)
                var c = e.substring(slash + 1)
                if (c.startsWith(".")) c = p + c
                p.equals(pkg, ignoreCase = true) && c.equals(cls, ignoreCase = true)
            }
        }
    }
}

/** Compares what the user asked to type with what the field really shows afterwards. */
object TextVerify {
    private fun norm(s: String): String =
        java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFC).replace(Regex("\\s+"), " ").trim().lowercase()

    fun matches(expected: String, actual: String?): Boolean = actual != null && norm(expected) == norm(actual)
}
