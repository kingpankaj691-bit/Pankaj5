package com.nova.ai.live

import android.util.Base64
import com.nova.ai.ai.model.LiveModality
import com.nova.ai.ai.model.LiveModalityPolicy
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Full-duplex Gemini Live voice client (WebSocket). The key is used only to open the socket and is never logged. */
class GeminiLiveClient(
    private val apiKey: () -> String,
    private val listener: Listener,
    private val model: String = MODEL,
    /** The ONE response modality requested for this session. Chosen from the model's capabilities, never both and never guessed. */
    private val modality: LiveModality = LiveModality.AUDIO
) {

    interface Listener {
        fun onSetupComplete()
        fun onAudioChunk(pcm24k: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTurnComplete()
        fun onInterrupted()
        fun onError(message: String)
        fun onClosed()
        /** The server closed the socket with a code that is not a normal close. Default: treat as a plain close. */
        fun onClosedWithReason(code: Int, reason: String) { onClosed() }
        /** An error that retrying cannot fix (bad key, unknown model, quota). Default: a normal error. */
        fun onFatalError(message: String) { onError(message) }
        /** The server refused the requested response modality (close code 1007). Retrying the same setup can never work. */
        fun onModalityRejected(tried: LiveModality, reason: String) { onFatalError("The model does not support $tried responses on the Live API.") }
    }

    companion object {
        /**
         * Fallback model. The engine normally passes the model chosen in Jarvis settings (ModelCatalog.DEFAULT_LIVE = gemini-3.8-live).
         * gemini-3.1-flash-live-preview and gemini-2.5-flash-native-audio-preview are retired by Google on 17 Nov 2026.
         */
        const val MODEL = "models/gemini-3.8-live"
        const val WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key="
        fun modelPath(id: String): String = "models/" + id.trim().removePrefix("models/")
    }

    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val dedup = ToolCallDeduplicator()
    @Volatile private var ws: WebSocket? = null
    @Volatile private var ready = false
    /** Sample rate of the PCM passed to [sendAudio]. Gemini wants 16 kHz; if the phone only opened 44.1/48 kHz the real rate is sent so the audio is not garbled. */
    @Volatile var inputRate: Int = 16000

    fun isReady() = ready

    fun connect(systemInstruction: String, voiceName: String = "Aoede", tools: JSONArray = LiveTools.declarations()) {
        val key = apiKey()
        if (key.isBlank()) { listener.onFatalError("No Gemini API key set. Add one in Settings."); return }
        dedup.clear()
        ready = false
        ws = http.newWebSocket(Request.Builder().url(WS_URL + key).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setupMessage(model, systemInstruction, voiceName, tools, modality).toString()) }
            override fun onMessage(webSocket: WebSocket, text: String) { handle(text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(bytes.utf8()) }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                try { webSocket.close(1000, null) } catch (e: Exception) { }
                if (LiveModalityPolicy.isModalityRejection(code, reason)) {
                    listener.onModalityRejected(LiveModalityPolicy.triedModality(reason) ?: modality, reason)
                } else if (code != 1000 && code != 1001) {
                    val c = LiveErrors.classify(null, code, reason)
                    if (c.fatal) listener.onFatalError(c.message) else listener.onClosedWithReason(code, reason)
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { ready = false; if (code == 1000 || code == 1001) listener.onClosed() }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                val c = LiveErrors.classify(response?.code, null, "")
                if (response?.code != null && c.fatal) listener.onFatalError(c.message)
                else listener.onError("Live connection lost: ${t.message ?: "network error"}")
            }
        })
    }

    private fun handle(raw: String) {
        if (LiveMessageParser.parse(raw, listener, dedup)) ready = true
    }

    fun sendAudio(pcm: ByteArray, length: Int = pcm.size) {
        if (!ready) return
        val s = ws ?: return
        if (s.queueSize() > 1_000_000L) return
        s.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("mimeType", "audio/pcm;rate=$inputRate")
            .put("data", Base64.encodeToString(pcm, 0, length, Base64.NO_WRAP)))).toString())
    }

    fun sendToolResponse(id: String, name: String, result: JSONObject) {
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray()
            .put(JSONObject().put("id", id).put("name", name).put("response", result)))).toString())
    }

    fun disconnect() {
        val wasReady = ready
        ready = false
        try {
            if (wasReady) ws?.send("""{"realtimeInput":{"audioStreamEnd":true}}""")   // lets the server finish the open turn
            ws?.close(1000, "bye")
        } catch (e: Exception) { }
        ws = null
    }
}

internal fun setupMessage(model: String, systemInstruction: String, voice: String, tools: JSONArray, modality: LiveModality = LiveModality.AUDIO): JSONObject {
    val gen = JSONObject().put("responseModalities", JSONArray().put(modality.name))
    // A voice only makes sense for audio output; sending speechConfig to a TEXT session is another way to get error 1007.
    if (modality == LiveModality.AUDIO) {
        gen.put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))))
    }
    val setup = JSONObject()
        .put("model", model)
        .put("generationConfig", gen)
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
        .put("inputAudioTranscription", JSONObject())
    if (modality == LiveModality.AUDIO) {
        setup.put("outputAudioTranscription", JSONObject())
        setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", blockingIfNeeded(model, tools))))
    }
    return JSONObject().put("setup", setup)
}

/**
 * Setup for a speech-to-text-only Live session (the *-transcribe-live models). Those models REQUIRE responseModalities TEXT
 * and accept no voice, tools or system instruction; a conversational Live model is the opposite and requires AUDIO.
 */
internal fun transcriptionSetupMessage(model: String, modality: LiveModality = LiveModality.TEXT): JSONObject = JSONObject().put("setup", JSONObject()
    .put("model", GeminiLiveClient.modelPath(model))
    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put(modality.name)))
    .put("inputAudioTranscription", JSONObject().put("languageCodes", JSONArray())))

/**
 * gemini-3.8-live runs function calls non-blocking by default (the model keeps talking while the tool runs). Nova's tools
 * answer with a result the model must wait for ("opened YouTube"), so they are declared BLOCKING, as Google's migration notes say.
 * Older models only support blocking calls and do not need the field.
 */
internal fun blockingIfNeeded(model: String, tools: JSONArray): JSONArray {
    if (!model.contains("3.8-live")) return tools
    val out = JSONArray()
    for (i in 0 until tools.length()) out.put(JSONObject(tools.getJSONObject(i).toString()).put("behavior", "BLOCKING"))
    return out
}

/** Pure parser for server messages, so it can be unit-tested. Returns true when the message was setupComplete. */
object LiveMessageParser {
    fun parse(raw: String, l: GeminiLiveClient.Listener, dedup: ToolCallDeduplicator): Boolean {
        val j = try { JSONObject(raw) } catch (e: Exception) { return false }
        if (j.has("setupComplete")) { l.onSetupComplete(); return true }
        j.optJSONObject("error")?.let {
            val c = LiveErrors.classify(it.optInt("code").takeIf { n -> n > 0 }, null, it.optString("message"))
            if (c.fatal) l.onFatalError(c.message) else l.onError(it.optString("message").take(160))
            return false
        }
        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.optJSONObject(i) ?: continue
                val id = c.optString("id")
                if (!dedup.firstTime(id)) continue
                l.onToolCall(id, c.optString("name"), c.optJSONObject("args") ?: JSONObject())
            }
        }
        val sc = j.optJSONObject("serverContent") ?: return false
        sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val d = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                if (d.optString("mimeType").startsWith("audio/pcm")) {
                    val b = try { java.util.Base64.getMimeDecoder().decode(d.optString("data")) } catch (e: Exception) { null }
                    if (b != null && b.isNotEmpty()) l.onAudioChunk(b)
                }
            }
        }
        sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let { l.onInputTranscript(it) }
        sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let { l.onOutputTranscript(it) }
        if (sc.optBoolean("interrupted")) l.onInterrupted()
        if (sc.optBoolean("turnComplete")) l.onTurnComplete()
        return false
    }
}
