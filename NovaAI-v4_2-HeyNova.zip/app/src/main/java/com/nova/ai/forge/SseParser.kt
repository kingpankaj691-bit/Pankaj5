package com.nova.ai.forge

import org.json.JSONObject

/** Parses Gemini streamGenerateContent?alt=sse lines. Never logs anything. */
object SseParser {
    /** The JSON after "data:", or null for blank lines, comments and [DONE]. */
    fun dataOf(line: String): String? {
        if (!line.startsWith("data:")) return null
        val p = line.removePrefix("data:").trim()
        return if (p.isEmpty() || p == "[DONE]") null else p
    }

    fun extractText(json: String): String {
        val parts = try { JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") } catch (e: Exception) { null } ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    fun extractError(json: String): String? {
        val e = try { JSONObject(json).optJSONObject("error") } catch (x: Exception) { null } ?: return null
        val status = e.optString("status")
        val msg = e.optString("message")
        return if (status.isNotEmpty()) "$status: $msg" else msg.ifEmpty { "error" }
    }

    fun extractFinishReason(json: String): String? =
        try { JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason")?.takeIf { it.isNotEmpty() } } catch (e: Exception) { null }
}

/** Turns API failures into something Nova can say out loud. */
object ForgeErrors {
    fun friendly(httpCode: Int, detail: String): String = when {
        httpCode == 503 || detail.contains("UNAVAILABLE", true) || detail.contains("overloaded", true) ->
            "Gemini is overloaded right now. Please try again in a minute."
        httpCode == 429 || detail.contains("RESOURCE_EXHAUSTED", true) -> "Gemini quota reached. Try again later."
        httpCode == 401 || httpCode == 403 -> "Gemini rejected the API key."
        httpCode == 404 -> "The Gemini model was not found. Change the model in Settings."
        httpCode == 400 -> "Gemini could not process this request."
        else -> "Gemini error. Please try again."
    }
    fun isOverloaded(httpCode: Int, detail: String) = httpCode == 503 || detail.contains("UNAVAILABLE", true) || detail.contains("overloaded", true)
}
