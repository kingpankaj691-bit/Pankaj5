package com.nova.ai.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Foreground service that owns the MediaProjection session and shows a visible, stoppable notification. */
class ScreenCaptureService : Service() {
    companion object {
        private const val CH = "nova_vision"
        private const val ID = 4107
        private const val START = "com.nova.ai.vision.START"
        private const val STOP = "com.nova.ai.vision.STOP"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"

        fun start(ctx: Context, code: Int, data: Intent) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ScreenCaptureService::class.java).setAction(START).putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data))
        }
        fun stop(ctx: Context) {
            ScreenCaptureManager.release()
            ctx.stopService(Intent(ctx, ScreenCaptureService::class.java))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { ScreenCaptureManager.release(); stopForegroundCompat(); stopSelf(); return START_NOT_STICKY }
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "NOVA screen vision", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, ScreenCaptureService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("NOVA screen vision is on")
            .setContentText("NOVA can look at your screen only when you ask. Tap Stop to end it.")
            .setOngoing(true).setCategory(Notification.CATEGORY_SERVICE)
            .addAction(0, "Stop", stopPi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(ID, n)
        if (!ScreenCaptureManager.begin(this, code, data)) { stopForegroundCompat(); stopSelf() }
        return START_NOT_STICKY
    }

    private fun stopForegroundCompat() { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true) }
    override fun onDestroy() { ScreenCaptureManager.release(); super.onDestroy() }
}
