package com.nova.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.security.SecurityAlarmManager
import com.nova.ai.security.SecurityEvents
import com.nova.ai.security.SecurityGate
import com.nova.ai.security.SecurityModeManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings for the motion / pick-up alert. Everything here is explicit: nothing arms until the person turns it on. */
@Composable
internal fun SecurityModeSection(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(p.securityModeOn) }
    var sens by remember { mutableStateOf(p.secSensitivity) }
    var gyro by remember { mutableStateOf(p.secUseGyro) }
    var arm by remember { mutableStateOf(p.secArmDelaySec.toFloat()) }
    var cool by remember { mutableStateOf(p.secCooldownSec.toFloat()) }
    var alarmLen by remember { mutableStateOf(p.secAlarmSec.toFloat()) }
    var sound by remember { mutableStateOf(p.secAlarmSound) }
    var speak by remember { mutableStateOf(p.secSpeak) }
    var warning by remember { mutableStateOf(p.secWarning) }
    var bio by remember { mutableStateOf(p.secDisarmBio) }
    var failAlarm by remember { mutableStateOf(p.secFailAlarm) }
    var msg by remember { mutableStateOf("") }
    var rev by remember { mutableIntStateOf(0) }
    val events = remember(rev, on) { SecurityEvents.list(p).take(8) }

    fun disarm() { msg = SecurityModeManager.disarm(ctx, p); on = false; rev++ }

    GlassSettingSection("Security Mode (motion / pick-up alert)") {
        GText("Uses the accelerometer (and gyroscope if you allow it) to sound an alarm when the phone is moved or picked up. It never takes photos, records sound, tracks location or identifies anyone. A notification stays visible while it is on, and it does not turn itself back on after a restart.", size = 12.sp, color = g.subtext)
        ToggleRow("Security Mode", SecurityModeManager.status(p), on) { want ->
            if (want) { msg = SecurityModeManager.arm(ctx, p); on = p.securityModeOn; rev++ }
            else if (p.secDisarmBio && SecurityGate.canBiometric(ctx)) vm.auth = AuthRequest("Turn off Security Mode") { disarm(); "Security Mode off." }
            else disarm()
        }
        GText("Sensitivity", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("low" to "Low", "medium" to "Medium", "high" to "High").forEach { (k, l) -> GlassChip(l, sens == k, { sens = k; p.secSensitivity = k }) }
        }
        ToggleRow("Use gyroscope too", "Catches twisting; a little more battery", gyro) { gyro = it; p.secUseGyro = it }
        GlassSlider("Arming delay", "${arm.toInt()} s", arm, { arm = it; p.secArmDelaySec = it.toInt() }, 5f..30f)
        GlassSlider("Cooldown after an alarm", "${cool.toInt()} s", cool, { cool = it; p.secCooldownSec = it.toInt() }, 10f..120f)
        GlassSlider("Alarm length", "${alarmLen.toInt()} s", alarmLen, { alarmLen = it; p.secAlarmSec = it.toInt() }, 5f..60f)
        ToggleRow("Alarm sound", "Uses your phone's alarm volume", sound) { sound = it; p.secAlarmSound = it }
        ToggleRow("Spoken warning", null, speak) { speak = it; p.secSpeak = it }
        GlassTextField(warning, { warning = it; p.secWarning = it }, Modifier.fillMaxWidth(), placeholder = "Warning message")
        ToggleRow("Fingerprint or screen lock to turn it off", "Recommended", bio) { bio = it; p.secDisarmBio = it }
        ToggleRow("Alarm after 3 failed unlocks in Nova", "Counts only Nova's own fingerprint/screen-lock prompt", failAlarm) { failAlarm = it; p.secFailAlarm = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Test alarm", { SecurityAlarmManager.get(ctx).trigger(p, test = true); msg = "Playing the alarm for 5 seconds." })
            GlassButton("Stop alarm", { SecurityAlarmManager.get(ctx).stop() })
        }
        GText("Anyone can say \"stop alarm\" out loud, so turn on Owner Mode with fingerprint to protect voice commands for stopping it.", size = 12.sp, color = g.subtext)
        if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)
    }
    GlassSettingSection("Security events") {
        GText("Only Nova's own events are listed. Android does not tell apps about failed unlocks of the phone or of other apps.", size = 12.sp, color = g.subtext)
        if (events.isEmpty()) GText("Nothing recorded.", size = 12.sp, color = g.subtext)
        events.forEach { GlassListItem(it.kind, SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(it.at)) + " · " + it.detail) }
        if (events.isNotEmpty()) GlassButton("Clear events", { SecurityEvents.clear(p); rev++ })
    }
}
