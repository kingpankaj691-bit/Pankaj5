package com.nova.ai.live

/** Rolling window of the last turns, kept in RAM only. Used to continue a conversation after a reconnect without greeting again. */
class ConversationMemory(private val maxTurns: Int = 12, private val maxRecapChars: Int = 1600) {
    enum class Role { USER, ASSISTANT }
    data class Turn(val role: Role, val text: String)

    private val turns = ArrayList<Turn>()

    @Synchronized
    fun add(role: Role, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        turns.add(Turn(role, t))
        while (turns.size > maxTurns) turns.removeAt(0)
    }

    @Synchronized fun size(): Int = turns.size
    @Synchronized fun clear() = turns.clear()

    /** "User: ..." / "You: ..." lines, limited to the last [maxRecapChars] characters. Null when there is nothing yet. */
    @Synchronized
    fun recap(): String? {
        if (turns.isEmpty()) return null
        val s = turns.joinToString("\n") { (if (it.role == Role.USER) "User: " else "You: ") + it.text }
        return if (s.length <= maxRecapChars) s else s.takeLast(maxRecapChars)
    }
}
