package com.nova.ai.suite

/**
 * Maps the app in front (package name from the accessibility service) to guidance added to the prompt, so Nova helps with what the
 * app is for. It only chooses instructions; the actual content always comes from the real screen text/OCR the user asked about.
 */
object AppContext {
    enum class Kind { MESSAGING, BROWSER, CODE, SOCIAL, VIDEO_EDITOR, OTHER }

    fun kindOf(pkg: String): Kind = when {
        pkg.startsWith("com.whatsapp") || pkg == "org.telegram.messenger" || pkg == "com.google.android.apps.messaging" || pkg == "com.samsung.android.messaging" -> Kind.MESSAGING
        pkg == "com.android.chrome" || pkg == "org.mozilla.firefox" || pkg == "com.brave.browser" || pkg == "com.sec.android.app.sbrowser" || pkg == "com.microsoft.emmx" -> Kind.BROWSER
        pkg == "com.foxdebug.acode" || pkg == "com.itsaky.androidide" || pkg == "com.termux" || pkg.startsWith("com.rosemoe") -> Kind.CODE
        pkg == "com.instagram.android" -> Kind.SOCIAL
        pkg == "com.alightcreative.motion" || pkg == "com.capcut.editor" || pkg == "com.lemon.lvoverseas" -> Kind.VIDEO_EDITOR
        else -> Kind.OTHER
    }

    fun label(pkg: String): String = when (kindOf(pkg)) {
        Kind.MESSAGING -> "a messaging app"
        Kind.BROWSER -> "a web browser"
        Kind.CODE -> "a code editor or terminal"
        Kind.SOCIAL -> "Instagram"
        Kind.VIDEO_EDITOR -> "a video editor"
        Kind.OTHER -> "an app"
    }

    /** Extra instructions for the model. Empty for unknown apps (no guessing). */
    private fun hintsOn(): Boolean = try { Features.getBool(com.nova.ai.NovaApp.instance, "app_hints", true) } catch (e: Exception) { true }

    fun hint(pkg: String): String = if (!hintsOn()) "" else when (kindOf(pkg)) {
        Kind.MESSAGING -> "The user is in a messaging app. Use only the conversation text provided. Drafts must be short, natural, in the language of the chat, and are never sent by Nova."
        Kind.BROWSER -> "The user is in a browser. Summarize or explain only the page text provided, and say if it looks cut off."
        Kind.CODE -> "The user is in a code editor or terminal. Read the code or error text provided, name the likely cause (Kotlin or Gradle), and give a minimal corrected snippet. Do not claim to have run anything."
        Kind.SOCIAL -> "The user is in Instagram. Help with captions and hashtags from the visible text; do not claim to see the video itself unless a screenshot was provided."
        Kind.VIDEO_EDITOR -> "The user is in a video editor. Describe visible tools, layers and effects from the text or screenshot provided and explain steps; say if something is not visible."
        Kind.OTHER -> ""
    }

    /** Wraps the screen text for the selected Gemini model together with the app hint. */
    fun buildPrompt(pkg: String, question: String, screenText: String): String {
        val h = hint(pkg)
        return buildString {
            if (pkg.isNotBlank()) append("Foreground app: ").append(pkg).append(" (").append(label(pkg)).append(")\n")
            if (h.isNotBlank()) append(h).append('\n')
            append("Visible screen text (may be incomplete):\n").append(screenText.take(8000)).append("\n\nUser request: ").append(question)
        }
    }
}
