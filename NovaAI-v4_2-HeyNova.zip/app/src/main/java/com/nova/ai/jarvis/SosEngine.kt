package com.nova.ai.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.nova.ai.automation.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Voice-triggered emergency: after a 10 second countdown you can cancel, Nova sends your location by SMS to your emergency
 * contacts, calls the first one, and keeps sending location updates every 5 minutes (up to 6 times) until you cancel.
 * She never calls the police or an emergency number by herself.
 */
object SosEngine {
    @Volatile var pending = false
        private set
    @Volatile var active = false
        private set
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private const val NOTIF = 4400

    class Contact(val name: String, val number: String)

    fun contacts(ctx: Context): List<Contact> = JarvisPrefs(ctx).sosContacts.lines().mapNotNull { line ->
        val p = line.split(':', limit = 2)
        val num = (p.getOrNull(1) ?: p[0]).filter { it.isDigit() || it == '+' }
        if (num.length < 5) null else Contact(if (p.size > 1) p[0].trim() else num, num)
    }

    fun trigger(ctx: Context): String {
        val app = ctx.applicationContext
        if (pending || active) return "SOS pehle se chal raha hai."
        val list = contacts(app)
        if (list.isEmpty()) return "Emergency contacts set nahi hain. Nova ki Jarvis settings mein add karo."
        pending = true
        TaskerBridge.event(app, "sos_countdown", "")
        postNotice(app, "SOS shuru ho raha hai", "10 second mein emergency contacts ko location bheji jayegi. Rokne ke liye Cancel dabao.", true)
        Announcer.speak(app, "SOS 10 second mein shuru hoga. Rokne ke liye cancel bolo.")
        job = scope.launch {
            delay(10_000)
            if (pending) fire(app, list)
        }
        return "SOS countdown shuru. Rokne ke liye cancel bolo."
    }

    fun cancel(ctx: Context): String {
        val app = ctx.applicationContext
        val wasActive = active
        if (!pending && !active) return "Koi SOS chal nahi raha."
        pending = false; active = false
        job?.cancel(); job = null
        androidx.core.app.NotificationManagerCompat.from(app).cancel(NOTIF)
        if (wasActive) sms(app, contacts(app), "I'm safe now. Please ignore my earlier SOS message. (Nova AI)")
        return if (wasActive) "SOS band kar diya. Contacts ko bata diya ki aap theek ho." else "SOS cancel kar diya."
    }

    private suspend fun fire(ctx: Context, list: List<Contact>) {
        pending = false; active = true
        TaskerBridge.event(ctx, "sos_started", "")
        Announcer.speak(ctx, "Main madad bula rahi hoon.")
        postNotice(ctx, "SOS active", "Location emergency contacts ko bheji ja rahi hai. Rokne ke liye Cancel dabao.", true)
        var loc = bestLocation(ctx)
        sms(ctx, list, message(loc, false))
        if (JarvisPrefs(ctx).sosCall) call(ctx, list.first().number)
        var n = 0
        while (active && n < 6) {
            delay(5 * 60_000L)
            if (!active) return
            loc = bestLocation(ctx) ?: loc
            sms(ctx, list, message(loc, true))
            n++
        }
        active = false
    }

    private fun message(l: Location?, update: Boolean): String {
        val where = if (l != null) "https://maps.google.com/?q=${l.latitude},${l.longitude} (accuracy ${l.accuracy.toInt()} m)" else "location unavailable"
        return (if (update) "SOS update: " else "SOS! I need help. ") + "My location: $where. Sent automatically by Nova AI."
    }

    private fun sms(ctx: Context, list: List<Contact>, text: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            postNotice(ctx, "SOS: SMS permission missing", "Allow Send SMS in Nova's Jarvis settings so location can be sent.", false)
            return
        }
        @Suppress("DEPRECATION")
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        for (c in list) try { sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(text), null, null) } catch (e: Exception) { }
    }

    @SuppressLint("MissingPermission")
    private fun call(ctx: Context, number: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return
        try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).placeCall(Uri.fromParts("tel", number, null), Bundle())
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun bestLocation(ctx: Context): Location? {
        if (!LocationReminders.hasPermission(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = LocationReminders.lastKnown(ctx)
        if (last != null && System.currentTimeMillis() - last.time < 120_000) return last
        if (Build.VERSION.SDK_INT >= 30) {
            val provider = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).firstOrNull { try { lm.isProviderEnabled(it) } catch (e: Exception) { false } }
            if (provider != null) {
                val fresh = withTimeoutOrNull(8000) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        try { lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(ctx)) { l -> if (cont.isActive) cont.resume(l) } }
                        catch (e: Exception) { if (cont.isActive) cont.resume(null) }
                    }
                }
                if (fresh != null) return fresh
            }
        }
        return last
    }

    private fun postNotice(ctx: Context, title: String, text: String, withCancel: Boolean) {
        val actions = if (withCancel) listOf("Cancel" to PendingIntent.getBroadcast(ctx, 9, Intent(ctx, SosCancelReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)) else emptyList()
        Notifier.post(ctx, NOTIF, title, text, Notifier.openApp(ctx), actions)
    }
}

class SosCancelReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { SosEngine.cancel(ctx) }
}
