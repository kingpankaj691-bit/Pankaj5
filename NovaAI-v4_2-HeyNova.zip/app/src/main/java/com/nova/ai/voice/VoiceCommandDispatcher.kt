package com.nova.ai.voice

import android.app.Application
import android.os.SystemClock
import com.nova.ai.jarvis.Interpreter
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.jarvis.SosEngine
import com.nova.ai.jarvis.TaskerBridge
import com.nova.ai.jarvis.Roman
import com.nova.ai.jarvis.WakePhrases
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Recognized text -> CommandRouter.
 *
 * The microphone and speech-to-text run continuously; this stage only decides which sentences are meant for Nova.
 * That is a text check on the transcript (not an audio wake-word engine): with "Only answer when I say Nova" on, a sentence
 * needs the word "Nova" in it. Turn that option off and every recognized sentence is treated as a command.
 *
 * Delivery: if the app UI is alive its ViewModel runs the command through the full router and shows it in the chat.
 * Otherwise [HeadlessAssistant] answers (local router, then GeminiProvider/OfflineProvider, then TTS).
 */
class VoiceCommandDispatcher(private val app: Application, private val prefs: Prefs) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var headless: HeadlessAssistant? = null
    @Volatile private var armedUntil = 0L

    private val jp = JarvisPrefs(app)
    private var nameRegex: Regex? = null
    private var nameFor = ""

    /** The wake name can be changed in settings at any time; the pattern follows it. */
    private fun name(): Regex {
        val n = jp.wakeName
        if (n != nameFor || nameRegex == null) {
            nameFor = n
            val alt = if (n == "nova") "nova|novaa|nowa" else Regex.escape(n)
            nameRegex = Regex("(?<![\\p{L}\\p{N}])($alt)(?![\\p{L}\\p{N}])" + (if (n == "nova") "|नोवा" else ""), RegexOption.IGNORE_CASE)
        }
        return nameRegex!!
    }
    private val edge = charArrayOf(' ', ',', '.', '!', '?', ':', ';', '-', '।')

    fun onRecognized(raw: String) {
        val text = Roman.latin(raw.trim())          // Hindi in Devanagari -> Roman Hinglish, which the command router understands
        if (text.isEmpty()) return
        VoiceState.heard.value = text
        NovaSession.noteActivity()                  // keeps a "Hey Nova" conversation open for follow-up sentences
        val now = SystemClock.elapsedRealtime()
        val cmd: String
        if (!prefs.wakeEnabled || Interpreter.active || VoiceState.wakeGated || SosEngine.pending || SosEngine.active) {
            // already addressed to Nova (trigger off, interpreter on, or the offline wake word just fired): drop the name if it is in the sentence
            // Hey Nova / Hello Nova / "Nova, listen" / "Nova, are you there?": the whole phrase is the wake word, not part of the command
            val t = if (VoiceState.wakeGated) WakePhrases.strip(text, jp.activeWakePhrases()) else text
            val m0 = name().find(t)
            cmd = if (m0 == null) t else (t.substring(m0.range.last + 1).trim(*edge).ifEmpty { t.substring(0, m0.range.first).trim(*edge) })
        } else {
            val m = name().find(text)
            if (m != null) {
                val after = text.substring(m.range.last + 1).trim(*edge)
                val before = text.substring(0, m.range.first).trim(*edge)
                cmd = if (after.isNotEmpty()) after else before
            } else if (now < armedUntil) {
                cmd = text                       // the user said just "Nova" in the previous clip
            } else {
                return                           // not addressed to Nova
            }
        }
        if (cmd.isEmpty()) { armedUntil = now + 12000; deliver("") }
        else { armedUntil = 0; TaskerBridge.event(app, "heard", cmd); deliver(cmd) }
    }

    private fun deliver(cmd: String) {
        if (VoiceBus.uiIsListening()) {
            VoiceBus.commands.tryEmit(cmd)
            return
        }
        scope.launch {
            NovaSession.busy.value = true
            try {
                val h = headless ?: HeadlessAssistant(app, prefs).also { headless = it }
                h.handle(cmd)
            } finally { NovaSession.busy.value = false }
        }
    }

    /** Spoken answer to a bare wake phrase such as "Nova, are you there?" (the headless assistant replies "Yes?"). */
    fun acknowledge() = deliver("")

    /** The wake phrase was itself the question ("Jaan, kaisi ho?"): answer it now. */
    fun say(command: String) = deliver(command)

    fun close() {
        scope.cancel()
        headless?.close()
        headless = null
    }
}
