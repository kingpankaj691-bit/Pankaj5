package com.nova.ai.files

import com.nova.ai.commands.Cat
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level
import com.nova.ai.commands.UiBridge
import com.nova.ai.ui.FileManagerNav
import com.nova.ai.ui.SettingsNav

/**
 * Voice and chat commands for the File Manager. Commands only OPEN the right File Manager view with the request filled in:
 * reading happens on the phone, Gemini needs the consent dialog, and nothing is deleted or moved without its own confirmation there.
 * Marked private, so they don't work from the lock screen.
 */
class FileCommands {
    fun route(raw: String, @Suppress("UNUSED_PARAMETER") t: String): CmdResult? {
        val intent = FileIntents.parse(raw) ?: return null
        val say = when (intent) {
            is FileIntent.Read -> "Looking for your latest document to read. I read it on the phone, nothing is uploaded."
            is FileIntent.Search -> "Searching ${intent.label}."
            FileIntent.LatestDownload -> "Opening your latest download."
            FileIntent.SummarizeCurrent -> "Here's a local summary. Gemini is only used if you approve it."
            FileIntent.AnalyzeProject -> "Looking for your coding projects."
            FileIntent.FindDuplicates -> "Scanning for duplicate files. Nothing is deleted without your approval."
            is FileIntent.Organize -> "I'll show you a plan first. Nothing moves until you confirm."
            FileIntent.OpenManager -> "Opening File Manager."
        }
        return CmdResult(true, Cat.APP_COMMAND, "", Level.Info, {
            val nav = UiBridge.navigate
            if (nav == null) "Open Settings, then File Manager."
            else { SettingsNav.request = "filemgr"; FileManagerNav.intent = intent; nav(4); say }
        }, "files", true)
    }
}
