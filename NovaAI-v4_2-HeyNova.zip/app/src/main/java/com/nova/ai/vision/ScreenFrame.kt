package com.nova.ai.vision

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/** One screenshot held in RAM only. It is never written to disk. */
class ScreenFrame(val bitmap: Bitmap, val screenWidth: Int, val screenHeight: Int, val pkg: String, val takenAt: Long = System.currentTimeMillis()) {
    fun jpeg(quality: Int = 70): ByteArray = ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
    fun recycle() { if (!bitmap.isRecycled) bitmap.recycle() }
}
