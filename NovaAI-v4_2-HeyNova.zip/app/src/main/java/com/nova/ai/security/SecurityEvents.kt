package com.nova.ai.security

import android.content.Context
import com.nova.ai.automation.Notifier
import org.json.JSONArray
import org.json.JSONObject

data class SecurityEvent(val at: Long, val kind: String, val detail: String)

/**
 * A small local log of things that happened to Nova's OWN security (motion alert, failed fingerprint/screen-lock inside Nova).
 * It never records other apps' passwords or failures; Android does not expose those.
 */
object SecurityEvents {
    private const val MAX = 50
    private const val WINDOW_MS = 5 * 60 * 1000L

    fun list(p: Prefs): List<SecurityEvent> = try {
        val a = JSONArray(p.securityEvents)
        (0 until a.length()).map { val o = a.getJSONObject(it); SecurityEvent(o.optLong("t"), o.optString("k"), o.optString("d")) }.reversed()
    } catch (e: Exception) { emptyList() }

    fun record(ctx: Context, p: Prefs, kind: String, detail: String, notify: Boolean = true) {
        try {
            val a = JSONArray(p.securityEvents)
            a.put(JSONObject().put("t", System.currentTimeMillis()).put("k", kind).put("d", detail))
            val trimmed = JSONArray()
            for (i in maxOf(0, a.length() - MAX) until a.length()) trimmed.put(a.get(i))
            p.securityEvents = trimmed.toString()
        } catch (e: Exception) { }
        if (notify) Notifier.post(ctx, 6100, "Nova security: $kind", detail)
    }

    fun clear(p: Prefs) { p.securityEvents = "[]" }

    /** Called when Nova's own fingerprint/screen-lock prompt rejects an attempt. May sound the alarm if the user enabled that. */
    fun recordFailedAuth(ctx: Context, detail: String) {
        val p = Prefs(ctx)
        record(ctx, p, "Failed unlock", detail, notify = false)
        val now = System.currentTimeMillis()
        val recent = list(p).count { it.kind == "Failed unlock" && now - it.at < WINDOW_MS }
        if (recent >= 3) {
            Notifier.post(ctx, 6101, "Nova security: repeated failed unlocks", "$recent failed attempts in the last 5 minutes.")
            if (p.secFailAlarm) SecurityAlarmManager.get(ctx).trigger(p)
        }
    }
}
