package com.nova.ai.media

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size

enum class MediaKind { ALL, IMAGES, VIDEOS }

data class MediaEntry(
    val uri: Uri, val id: Long, val name: String, val mime: String, val size: Long, val dateSec: Long,
    val durationMs: Long, val album: String, val isVideo: Boolean, val width: Int, val height: Int
)
data class Album(val name: String, val count: Int)

/**
 * Reads photos and videos through MediaStore only. What it returns is exactly what Android lets Nova see:
 * with "selected photos" access that is just the shared subset, and with no permission it is empty (never invented).
 */
object MediaRepository {
    private val filesUri: Uri get() = MediaStore.Files.getContentUri("external")
    private val cache = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 10).toInt().coerceAtLeast(4096)) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    private val projection = arrayOf(
        MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE,
        MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_ADDED, MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT, MediaStore.MediaColumns.DURATION
    )

    private fun typeClause(kind: MediaKind) = when (kind) {
        MediaKind.IMAGES -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}"
        MediaKind.VIDEOS -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}"
        MediaKind.ALL -> "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE},${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO})"
    }

    fun list(ctx: Context, kind: MediaKind = MediaKind.ALL, album: String? = null, offset: Int = 0, limit: Int = 90): List<MediaEntry> {
        if (MediaAccess.level(ctx) == MediaAccessLevel.NONE) return emptyList()
        val sel = StringBuilder(typeClause(kind)); val args = ArrayList<String>()
        if (album != null) { sel.append(" AND ${MediaStore.MediaColumns.BUCKET_DISPLAY_NAME}=?"); args.add(album) }
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel.toString())
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toTypedArray())
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Files.FileColumns.DATE_ADDED, MediaStore.Files.FileColumns._ID))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit); putInt(ContentResolver.QUERY_ARG_OFFSET, offset)
        }
        val out = ArrayList<MediaEntry>()
        try {
            ctx.contentResolver.query(filesUri, projection, b, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0); val video = c.getInt(5) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                    val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    out.add(MediaEntry(ContentUris.withAppendedId(base, id), id, c.getString(1) ?: "item", c.getString(2) ?: "", c.getLong(3), c.getLong(4),
                        if (video && !c.isNull(9)) c.getLong(9) else 0L, c.getString(6) ?: "Other", video, c.getInt(7), c.getInt(8)))
                }
            }
        } catch (e: Exception) { /* provider unavailable or permission changed mid-query: return what we have, never fake items */ }
        return out
    }

    fun albums(ctx: Context): List<Album> {
        if (MediaAccess.level(ctx) == MediaAccessLevel.NONE) return emptyList()
        val counts = LinkedHashMap<String, Int>()
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, typeClause(MediaKind.ALL))
            putInt(ContentResolver.QUERY_ARG_LIMIT, 20000)
        }
        try { ctx.contentResolver.query(filesUri, arrayOf(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME), b, null)?.use { c ->
            while (c.moveToNext()) { val n = c.getString(0) ?: "Other"; counts[n] = (counts[n] ?: 0) + 1 }
        } } catch (e: Exception) { }
        return counts.map { Album(it.key, it.value) }.sortedByDescending { it.count }
    }

    fun count(ctx: Context, kind: MediaKind): Int = try {
        if (MediaAccess.level(ctx) == MediaAccessLevel.NONE) 0 else
        ctx.contentResolver.query(filesUri, arrayOf(MediaStore.Files.FileColumns._ID), Bundle().apply { putString(ContentResolver.QUERY_ARG_SQL_SELECTION, typeClause(kind)) }, null)?.use { it.count } ?: 0
    } catch (e: Exception) { 0 }

    /** True if the item still exists and Nova can still read it (used to verify deletes and moves). */
    fun exists(ctx: Context, uri: Uri): Boolean = try { ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { it.moveToFirst() } == true } catch (e: Exception) { false }

    fun relativePath(ctx: Context, uri: Uri): String? = try {
        if (Build.VERSION.SDK_INT < 29) null else ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.RELATIVE_PATH), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }

    /** Thumbnail from the system (cached). Returns null if it can't be produced; the UI then shows a placeholder instead of a fake image. */
    fun thumbnail(ctx: Context, uri: Uri, px: Int = 256): Bitmap? {
        val key = "$uri@$px"; cache.get(key)?.let { return it }
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(px, px), null)
            else ctx.contentResolver.openInputStream(uri)?.use { s2 ->
                BitmapFactory.decodeStream(s2, null, BitmapFactory.Options().apply { inSampleSize = 4 })
            }
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    fun clearCache() = cache.evictAll()
}
