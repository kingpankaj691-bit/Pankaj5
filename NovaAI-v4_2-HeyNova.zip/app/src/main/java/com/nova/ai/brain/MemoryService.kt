package com.nova.ai.brain

sealed class SaveResult {
    data class Saved(val item: BrainItem) : SaveResult()
    data class Updated(val item: BrainItem) : SaveResult()
    data class Duplicate(val item: BrainItem) : SaveResult()
    object Blocked : SaveResult()
}

/** Writes, edits, de-duplicates and queries long-term memories. Every multi-step write runs in one transaction. */
class MemoryService(private val store: BrainStore, private val clock: () -> Long = { System.currentTimeMillis() }) {

    fun all(): List<BrainItem> = store.items()
    fun byCategory(c: BrainCategory): List<BrainItem> = store.items().filter { it.category == c }
    fun item(id: Long): BrainItem? = store.item(id)

    fun save(c: Candidate, source: String, topicId: Long = 0, projectOverride: String = ""): SaveResult {
        if (c.sensitivity == Sensitivity.BLOCK || c.content.isBlank()) return SaveResult.Blocked
        val now = clock()
        val project = projectOverride.ifBlank { c.project }
        return store.tx {
            val existing = store.items().firstOrNull { e ->
                e.category == c.category && (Txt.similar(e.content, c.content) ||
                    (c.category == BrainCategory.PROJECT && e.title.equals(c.title, true)))
            }
            if (existing != null) {
                val better = c.content.length > existing.content.length + 12 || (c.category == BrainCategory.PROJECT && c.status != existing.status && c.status.isNotEmpty())
                if (better || (c.dueAt != 0L && c.dueAt != existing.dueAt)) {
                    val upd = existing.copy(content = if (better) c.content else existing.content, status = c.status.ifEmpty { existing.status },
                        dueAt = if (c.dueAt != 0L) c.dueAt else existing.dueAt, importance = maxOf(existing.importance, c.importance), updatedAt = now,
                        hash = Txt.hash(if (better) c.content else existing.content))
                    store.saveItem(upd)
                    SaveResult.Updated(store.item(existing.id) ?: upd)
                } else {
                    store.touch(listOf(existing.id), now)
                    SaveResult.Duplicate(existing)
                }
            } else {
                val item = BrainItem(0, c.category, c.title.ifBlank { Txt.clip(c.content, 60) }, c.content, project, topicId, c.status, c.dueAt, c.importance,
                    now, now, now, source, false, Txt.hash(c.content), 1)
                val id = store.saveItem(item)
                if (c.category == BrainCategory.PROJECT && c.title.isNotBlank()) ensureProject(c.title, c.status.ifEmpty { Status.ONGOING }, now)
                SaveResult.Saved(item.copy(id = id))
            }
        }
    }

    fun ensureProject(name: String, status: String, now: Long = clock()): ProjectRec {
        val existing = store.projects().firstOrNull { it.name.equals(name, true) }
        if (existing != null) return existing
        val p = ProjectRec(0, name.trim(), status, updatedAt = now)
        return p.copy(id = store.saveProject(p))
    }

    fun update(id: Long, content: String): BrainItem? {
        val old = store.item(id) ?: return null
        if (MemoryExtractor.isBlocked(content)) return null
        val upd = old.copy(content = content.trim(), title = Txt.clip(content.trim(), 60), updatedAt = clock(), hash = Txt.hash(content))
        store.saveItem(upd)
        return store.item(id)
    }

    fun setStatus(id: Long, status: String): BrainItem? {
        val old = store.item(id) ?: return null
        store.saveItem(old.copy(status = status, updatedAt = clock()))
        return store.item(id)
    }

    fun setPinned(id: Long, pinned: Boolean) { store.item(id)?.let { store.saveItem(it.copy(pinned = pinned)) } }
    fun setDue(id: Long, dueAt: Long) { store.item(id)?.let { store.saveItem(it.copy(dueAt = dueAt, updatedAt = clock())) } }
    fun delete(id: Long): Boolean = store.deleteItem(id)
    fun clearCategory(c: BrainCategory): Int = store.deleteCategory(c)
    fun clearAll(): Int = store.deleteAllItems()

    /** Best matches for a spoken hint like "mera phone" or "voice engine task". */
    fun find(hint: String, categories: Set<BrainCategory> = emptySet(), limit: Int = 5): List<Scored> =
        Retrieval.search(store.items(), RetrievalQuery(hint, categories), clock(), limit)

    /** Open tasks (pending or postponed), optionally for one project, most recent first. */
    fun pendingTasks(project: String? = null): List<BrainItem> =
        store.items().filter { it.category == BrainCategory.TASK && it.status != Status.DONE }
            .filter { project == null || it.project.equals(project, true) }
            .sortedWith(compareBy<BrainItem> { if (it.dueAt == 0L) Long.MAX_VALUE else it.dueAt }.thenByDescending { it.updatedAt })

    fun countsByCategory(): Map<BrainCategory, Int> = store.items().groupingBy { it.category }.eachCount()
}

/** Personal Intelligence Profile: built only from things the user explicitly said. Nothing is inferred. */
class ProfileService(private val store: BrainStore) {
    companion object {
        val LABELS = linkedMapOf(
            "answer_length" to "Answer length", "comm_style" to "Communication style", "fav_ui" to "Favourite UI / design", "fav_apps" to "Favourite apps",
            "skill" to "Technical level", "goals" to "Goals", "dislikes" to "Dislikes", "tools" to "Tools used", "working_style" to "Working style", "workflows" to "Preferred workflows"
        )
    }

    private fun key(k: String) = "profile.$k"
    fun get(k: String): String = store.getState(key(k)).orEmpty()
    fun set(k: String, v: String) = store.putState(key(k), v)
    fun clear() { LABELS.keys.forEach { set(it, "") } }
    fun fields(): Map<String, String> = LABELS.keys.associateWith { get(it) }.filterValues { it.isNotBlank() }

    private fun addList(k: String, v: String) {
        val cur = get(k).split(" | ").filter { it.isNotBlank() }.toMutableList()
        if (cur.none { Txt.similar(it, v) }) cur.add(Txt.clip(v, 60))
        set(k, cur.takeLast(6).joinToString(" | "))
    }

    /** Called only with candidates the user really said (and that were saved). */
    fun observe(c: Candidate) {
        val l = c.content.lowercase()
        when (c.category) {
            BrainCategory.PREFERENCE, BrainCategory.LIKE_DISLIKE, BrainCategory.INSTRUCTION -> {
                when {
                    Regex("(short|chhota|chota|brief|concise|sankshipt|chhote)").containsMatchIn(l) && Regex("(answer|jawab|reply|uttar)").containsMatchIn(l) -> set("answer_length", "short")
                    Regex("(detail|detailed|lamba|lamb|vistar|step by step|explain)").containsMatchIn(l) && Regex("(answer|jawab|reply|samjhao|uttar)").containsMatchIn(l) -> set("answer_length", "detailed")
                }
                if (Regex("\\b(casual|friendly|formal|professional|funny|serious)\\b").containsMatchIn(l)) set("comm_style", Regex("\\b(casual|friendly|formal|professional|funny|serious)\\b").find(l)!!.value)
                if (c.category == BrainCategory.PREFERENCE && Regex("\\b(ui|design|theme|glass|interface|dark|light|layout)\\b").containsMatchIn(l)) addList("fav_ui", c.title)
                if (c.category == BrainCategory.LIKE_DISLIKE && Regex("(nahi|not|hate|nafrat|dislike|bura|bekaar)").containsMatchIn(l)) addList("dislikes", c.title)
                Regex("(?i)(?:favou?rite|pasandida)\\s+app\\s+(?:is|hai)\\s+([\\w .+-]{2,30})").find(c.content)?.let { addList("fav_apps", it.groupValues[1].trim()) }
                if (Regex("(?i)(step by step|ek ek step|one step at a time)").containsMatchIn(l)) set("working_style", "step by step")
            }
            BrainCategory.FUTURE_PLAN -> if (Regex("(goal|banna|banana)").containsMatchIn(l)) addList("goals", c.title)
            BrainCategory.PERSONAL, BrainCategory.CUSTOM -> {
                if (Regex("(?i)\\b(beginner|new to coding|naya hoon|expert|senior|advanced|intermediate)\\b").containsMatchIn(l)) set("skill", Regex("(?i)\\b(beginner|new to coding|naya hoon|expert|senior|advanced|intermediate)\\b").find(l)!!.value)
                Regex("(?i)\\b(?:i use|main)\\s+([A-Za-z][\\w .+-]{1,24})\\s+(?:use karta|use karti|for coding|for editing)").find(c.content)?.let { addList("tools", it.groupValues[1].trim()) }
            }
            else -> {}
        }
    }

    /** Short description for the AI. Empty when nothing was shared. */
    fun summary(): String {
        val f = fields()
        if (f.isEmpty()) return ""
        return f.entries.joinToString("; ") { (LABELS[it.key] ?: it.key) + ": " + it.value }
    }
}
