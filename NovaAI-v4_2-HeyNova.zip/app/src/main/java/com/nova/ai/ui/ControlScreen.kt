package com.nova.ai.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.accessibility.NovaAccessibilityService

@Composable
fun ControlCard(glyph: String, title: String, value: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    GlassCard(
        modifier.heightIn(min = 112.dp).pressable(onClick).semantics { contentDescription = "$title, $value" },
        glow = active, tint = if (active) g.accent.a(0.22f) else androidx.compose.ui.graphics.Color.Transparent
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            GText(glyph, size = 26.sp)
            GText(title, weight = FontWeight.SemiBold)
            GText(value, size = 13.sp, color = g.subtext)
        }
    }
}

@Composable
fun ControlScreen(vm: NovaViewModel) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val wifi = remember(tick) { vm.device.wifiOn() }
    val bt = remember(tick) { vm.device.btOn() }
    val battery = remember(tick) { vm.device.batteryPct() }
    val bright = remember(tick) { vm.device.brightnessPct() }
    var volume by remember(tick) { mutableFloatStateOf(vm.device.volumePct()) }
    var sheet by remember { mutableStateOf(false) }
    val (listening, setListening) = rememberListenToggle()
    val a11y = tick >= 0 && NovaAccessibilityService.instance != null

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GText("Control Center", size = 24.sp, weight = FontWeight.SemiBold)
        GText("Where Android blocks silent changes, Nova opens the right Settings page instead.", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlCard("📶", "Wi-Fi", if (wifi) "On • tap for settings" else "Off • tap for settings", wifi,
                { openSystem(ctx, Settings.ACTION_WIFI_SETTINGS) }, Modifier.weight(1f))
            ControlCard("🔵", "Bluetooth", if (bt) "On • tap for settings" else "Off • tap for settings", bt,
                { openSystem(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlCard("🔦", "Flashlight", if (vm.device.torchOn) "On" else "Off", vm.device.torchOn, { vm.toggleTorch() }, Modifier.weight(1f))
            ControlCard("☀", "Brightness", if (bright >= 0) "$bright% • open display" else "Open display", false,
                { openSystem(ctx, Settings.ACTION_DISPLAY_SETTINGS) }, Modifier.weight(1f))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                GlassSlider("🔊 Media volume", "${(volume * 100).toInt()}%", volume, { volume = it; vm.device.setVolumePct(it) }, 0f..1f)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlCard("🔋", "Battery", if (battery >= 0) "$battery% • tap for settings" else "Unavailable", false,
                { openSystem(ctx, Intent.ACTION_POWER_USAGE_SUMMARY) }, Modifier.weight(1f))
            ControlCard("🛰", "Device Intelligence", if (vm.profile == null) "Scan my phone" else "View report", false, { if (vm.profile == null) vm.startScan() else vm.navigateTo = 5 }, Modifier.weight(1f))
        }
        GlassSettingSection("Background assistant") {
            GlassListItem("Background Voice", if (listening) "Microphone is ON. A notification is showing; stop it there or here."
            else "Microphone is OFF.", trailing = { GlassSwitch(listening, setListening) })
            GlassListItem("Screen assistant", if (a11y) "Accessibility enabled" else "Accessibility disabled (enable it under Settings → Screen control)")
        }
        GlassButton("Open Command Center", { vm.navigateTo = 6 }, Modifier.fillMaxWidth(), primary = true)
        GlassButton("People & Memory", { vm.navigateTo = 7 }, Modifier.fillMaxWidth())
    }
    if (sheet) ScanSheet(vm) { sheet = false }
}
