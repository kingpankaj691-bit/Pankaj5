package com.nova.ai.media

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

/** A system dialog the user must approve before Android lets Nova change or delete media it doesn't own. */
class PendingApproval(val sender: IntentSender, val kind: Kind, val uris: List<Uri>, val target: String = "") {
    enum class Kind { TRASH, DELETE, MOVE }
}
sealed class ActionStart {
    class NeedsApproval(val pending: PendingApproval) : ActionStart()
    class Done(val message: String) : ActionStart()
    class Unsupported(val message: String) : ActionStart()
}

/**
 * Open / copy / organize / delete. Android itself shows the authorization dialog for changing or deleting other apps' media (API 30+),
 * so nothing here happens silently. Every result is re-checked against MediaStore before it is reported.
 */
object MediaActions {
    private val safeAlbum = Regex("[A-Za-z0-9 _.-]{1,40}")
    fun validAlbumName(n: String) = n.trim().matches(safeAlbum) && !n.contains("..")

    fun open(ctx: Context, e: MediaEntry): String = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(e.uri, e.mime.ifBlank { if (e.isVideo) "video/*" else "image/*" })
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)); "Opening ${e.name}."
    } catch (x: Exception) { "No app on this phone can open ${e.name}." }

    /** Copies into Pictures/<album> or Movies/<album> as a new item. Android 10+. The original is untouched. */
    fun copyToAlbum(ctx: Context, e: MediaEntry, album: String): String {
        if (Build.VERSION.SDK_INT < 29) return "Copying into an album needs Android 10 or newer. Use “Save a copy to…” to pick a place instead."
        if (!validAlbumName(album)) return "Album names can use letters, numbers, spaces, - _ . only."
        val cr = ctx.contentResolver
        val base = if (e.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, e.name); put(MediaStore.MediaColumns.MIME_TYPE, e.mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, (if (e.isVideo) "Movies/" else "Pictures/") + album.trim())
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val dest = cr.insert(base, v) ?: return "Android refused to create the copy."
        return try {
            val src = cr.openInputStream(e.uri) ?: throw IllegalStateException("can't read the original")
            val out = cr.openOutputStream(dest) ?: throw IllegalStateException("can't write the copy")
            val n = src.use { i -> out.use { o -> i.copyTo(o) } }
            cr.update(dest, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            if (n > 0 && MediaRepository.exists(ctx, dest)) "Copied ${e.name} to ${if (e.isVideo) "Movies" else "Pictures"}/${album.trim()} (${n / 1024} KB, verified)." else { try { cr.delete(dest, null, null) } catch (x: Exception) { }; "The copy came out empty, so I removed it." }
        } catch (x: Exception) { try { cr.delete(dest, null, null) } catch (y: Exception) { }; "Copy failed: ${x.message}" }
    }

    /** Copies to a place the user picked with the Storage Access Framework (CreateDocument). */
    fun copyToUri(ctx: Context, e: MediaEntry, dest: Uri): String = try {
        val n = ctx.contentResolver.openInputStream(e.uri)!!.use { i -> ctx.contentResolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
        if (n > 0) "Saved a copy of ${e.name} (${n / 1024} KB)." else "The copy was empty."
    } catch (x: Exception) { "Couldn't save the copy: ${x.message}" }

    /** Move to the Trash (recoverable). Android 11+. The user approves in a system dialog. */
    fun trash(ctx: Context, items: List<MediaEntry>): ActionStart =
        if (Build.VERSION.SDK_INT >= 30 && items.isNotEmpty())
            ActionStart.NeedsApproval(PendingApproval(MediaStore.createTrashRequest(ctx.contentResolver, items.map { it.uri }, true).intentSender, PendingApproval.Kind.TRASH, items.map { it.uri }))
        else delete(ctx, items)

    /** Permanent delete. Android 11+: system dialog. Android 10: only items Nova may modify (user approves). Older: unsupported. */
    fun delete(ctx: Context, items: List<MediaEntry>): ActionStart {
        if (items.isEmpty()) return ActionStart.Done("Nothing selected.")
        val cr = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= 30)
            return ActionStart.NeedsApproval(PendingApproval(MediaStore.createDeleteRequest(cr, items.map { it.uri }).intentSender, PendingApproval.Kind.DELETE, items.map { it.uri }))
        if (Build.VERSION.SDK_INT == 29) return deleteApi29(ctx, items)
        return ActionStart.Unsupported("Deleting photos needs Android 10 or newer without the old storage permission. Please delete them in your Gallery app.")
    }

    @androidx.annotation.RequiresApi(29)
    private fun deleteApi29(ctx: Context, items: List<MediaEntry>): ActionStart {
        val cr = ctx.contentResolver
        for (e in items) try { cr.delete(e.uri, null, null) } catch (x: RecoverableSecurityException) {
            return ActionStart.NeedsApproval(PendingApproval(x.userAction.actionIntent.intentSender, PendingApproval.Kind.DELETE, listOf(e.uri)))
        } catch (x: SecurityException) { return ActionStart.Unsupported("Android won't let Nova delete ${e.name}.") }
        return ActionStart.Done(verifyGone(ctx, items.map { it.uri }, "Deleted"))
    }

    /** Moves into Pictures/<album> (or Movies/<album>). Android 11+, with the system's write approval. */
    fun organize(ctx: Context, items: List<MediaEntry>, album: String): ActionStart {
        if (Build.VERSION.SDK_INT < 30) return ActionStart.Unsupported("Organizing other apps' photos needs Android 11 or newer. Android 10 and older don't allow it without broad storage access.")
        if (!validAlbumName(album)) return ActionStart.Unsupported("Album names can use letters, numbers, spaces, - _ . only.")
        if (items.isEmpty()) return ActionStart.Done("Nothing selected.")
        return ActionStart.NeedsApproval(PendingApproval(MediaStore.createWriteRequest(ctx.contentResolver, items.map { it.uri }).intentSender, PendingApproval.Kind.MOVE, items.map { it.uri }, album.trim()))
    }

    /** Called after the system dialog returns OK. Does the move if needed, then verifies against MediaStore before reporting. */
    fun finish(ctx: Context, p: PendingApproval, items: List<MediaEntry>): String = when (p.kind) {
        PendingApproval.Kind.TRASH -> verifyGone(ctx, p.uris, "Moved to Trash")
        PendingApproval.Kind.DELETE -> verifyGone(ctx, p.uris, "Deleted")
        PendingApproval.Kind.MOVE -> {
            var ok = 0; var bad = 0
            for (e in items.filter { it.uri in p.uris }) try {
                val root = if (e.isVideo) "Movies/" else "Pictures/"
                ctx.contentResolver.update(e.uri, ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, root + p.target) }, null, null)
                if (MediaRepository.relativePath(ctx, e.uri)?.trimEnd('/') == (root + p.target)) ok++ else bad++
            } catch (x: Exception) { bad++ }
            if (bad == 0) "Moved $ok item${if (ok == 1) "" else "s"} to ${p.target} (verified)." else "Moved $ok, but $bad could not be moved or verified."
        }
    }

    /** Trashed items disappear from normal queries, so "gone" is the right check for both trash and delete. */
    private fun verifyGone(ctx: Context, uris: List<Uri>, verb: String): String {
        val left = uris.count { MediaRepository.exists(ctx, it) }
        return if (left == 0) "$verb ${uris.size} item${if (uris.size == 1) "" else "s"} (verified)." else "$verb ${uris.size - left} of ${uris.size}; $left still exist."
    }
}
