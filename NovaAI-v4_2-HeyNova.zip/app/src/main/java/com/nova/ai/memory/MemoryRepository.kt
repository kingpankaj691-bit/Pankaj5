package com.nova.ai.memory

import com.nova.ai.core.MemoryManager
import com.nova.ai.security.Prefs

/**
 * One front door for everything the memory screens need: view, search, edit, delete, forget one, disable, clear all.
 * It sits on top of the existing memory engine (SQLite, sensitive-text filter, forget-list) instead of replacing it.
 */
class MemoryRepository(private val memory: MemoryManager, private val prefs: Prefs) {

    companion object {
        /** The categories Nova's memory is organised around. The engine also has goal and command-preference extras. */
        val CORE_CATEGORIES = listOf(
            MemCategory.USER_PREFERENCE, MemCategory.IMPORTANT_FACT, MemCategory.ROUTINE, MemCategory.DEVICE_PREFERENCE,
            MemCategory.PERSONALITY_PREFERENCE, MemCategory.CONVERSATION_CONTEXT, MemCategory.TEMPORARY_CONTEXT
        )
    }

    var enabled: Boolean
        get() = prefs.memoryEnabled
        set(v) { prefs.memoryEnabled = v }

    fun all(): List<MemoryEntry> = if (!enabled) emptyList() else memory.saved() + memory.temporary()
    fun grouped(): Map<MemCategory, List<MemoryEntry>> = all().groupBy { it.category }
    fun search(query: String): List<MemoryEntry> = all().filter { it.content.contains(query.trim(), ignoreCase = true) }
    fun edit(id: Long, text: String) = memory.update(id, text)
    fun delete(id: Long) = memory.delete(id)
    /** Deletes it and remembers not to save the same thing again. */
    fun forget(id: Long) = memory.forget(id)
    fun clear() = memory.clear()
}
