package com.nova.ai.device

import android.Manifest
import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.ContactsContract
import android.provider.Settings
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.media.AudioManager
import android.provider.AlarmClock
import android.bluetooth.BluetoothAdapter
import android.net.wifi.WifiNetworkSuggestion

class DeviceController(private val ctx: Context) {
    var torchOn by mutableStateOf(false)
        private set

    fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent); true
    } catch (e: Exception) { false }

    fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This device has no flashlight."
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Flashlight is on." else "Flashlight is off."
        } catch (e: Exception) { "I couldn't control the flashlight." }
    }

    fun openSettings(action: String, name: String): String =
        if (launch(Intent(action))) "Opening $name." else "I couldn't open $name."

    /** (label, package) of the best installed launchable app for a spoken name, or null. */
    fun findApp(query: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val pkg = com.nova.ai.screen.AppNameMatcher.pickBest(apps, query) ?: return null
        return (apps.firstOrNull { it.second == pkg }?.first ?: query) to pkg
    }

    fun openPackage(pkg: String, label: String): String {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "I can't open $label."
        return if (launch(i)) "Opening $label." else "I couldn't open $label."
    }

    fun openApp(query: String): String {
        val (label, pkg) = findApp(query) ?: return "I couldn't find an app called $query."
        return openPackage(pkg, label)
    }

    /** Opens the chat with [phone] in WhatsApp with [text] prefilled in the message box. Nothing is sent. */
    fun openWhatsAppChat(pkg: String, phone: String, text: String): Boolean = try {
        val digits = phone.filter { it.isDigit() }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(text))).setPackage(pkg)
        launch(i)
    } catch (e: Exception) { false }

    fun appLabel(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    fun isInstalled(pkg: String): Boolean = try { ctx.packageManager.getLaunchIntentForPackage(pkg) != null } catch (e: Exception) { false }

    /** Real connectivity: a network that Android has validated as having internet (not just "Wi-Fi is on"). */
    fun hasInternet(): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) { true }   // unknown: don't block the task

    /** True while any app is playing audio (used with the player UI to confirm a video really plays). */
    fun isAudioPlaying(): Boolean = try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive } catch (e: Exception) { false }

    private fun browsableIntent() = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")).addCategory(Intent.CATEGORY_BROWSABLE)

    /** The system default browser, or null when Android would show a chooser. */
    fun defaultBrowserPackage(): String? = try {
        ctx.packageManager.resolveActivity(browsableIntent(), PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            ?.takeIf { it != "android" && !it.contains("resolver", true) && !it.contains("chooser", true) }
    } catch (e: Exception) { null }

    fun installedBrowserPackages(): List<String> = try {
        ctx.packageManager.queryIntentActivities(browsableIntent(), 0).map { it.activityInfo.packageName }.distinct()
    } catch (e: Exception) { emptyList() }

    fun openUrl(url: String, name: String): String =
        if (launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "Opening $name." else "I couldn't open $name."

    fun openCamera(): String =
        if (launch(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) "Opening camera." else "I couldn't open the camera."

    fun openDialer(number: String?): String {
        val i = Intent(Intent.ACTION_DIAL, if (number != null) Uri.parse("tel:" + Uri.encode(number)) else null)
        return if (launch(i)) "Dialer is ready. Tap the call button to confirm." else "I couldn't open the dialer."
    }

    fun findNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
    }

    /** Opens the contact card for [name] (needs Contacts permission); falls back to the contacts list. */
    fun openContact(name: String): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return "I need Contacts permission to find $name."
        return try {
            ctx.contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY),
                "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { c ->
                if (c.moveToFirst()) {
                    val uri = ContactsContract.Contacts.getLookupUri(c.getLong(0), c.getString(1))
                    if (launch(Intent(Intent.ACTION_VIEW, uri))) "Opening contact $name." else "I couldn't open that contact."
                } else "I couldn't find a contact called $name."
            } ?: "I couldn't read contacts."
        } catch (e: Exception) { "I couldn't read contacts." }
    }

    /** Transparent device scan: only standard, non-private system info. */
    fun deviceInfo(): String {
        val sb = StringBuilder()
        sb.append("Model: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        try {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0) sb.append("Battery: ${level * 100 / scale}%${if (charging) " (charging)" else ""}\n")
        } catch (e: Exception) { }
        try {
            val s = StatFs(Environment.getDataDirectory().path)
            val total = s.blockCountLong * s.blockSizeLong
            val free = s.availableBlocksLong * s.blockSizeLong
            sb.append("Storage: ${gb(total - free)} used of ${gb(total)}\n")
        } catch (e: Exception) { }
        try {
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            sb.append("RAM: ${gb(mi.totalMem - mi.availMem)} used of ${gb(mi.totalMem)}\n")
        } catch (e: Exception) { }
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val net = when {
                caps == null -> "offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                else -> "connected"
            }
            sb.append("Network: $net\n")
        } catch (e: Exception) { }
        try {
            val w = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            sb.append("Wi-Fi: ${if (w.isWifiEnabled) "on" else "off"}\n")
        } catch (e: Exception) { }
        try {
            val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            sb.append("Bluetooth: ${if (bt == null) "unavailable" else if (bt.isEnabled) "on" else "off"}\n")
        } catch (e: Exception) { }
        val dm = ctx.resources.displayMetrics
        sb.append("Display: ${dm.widthPixels}x${dm.heightPixels}, ${dm.densityDpi} dpi")
        return sb.toString()
    }

    fun wifiOn(): Boolean = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }

    fun btOn(): Boolean = try {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) { false }

    fun batteryPct(): Int = try {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (l < 0) -1 else l * 100 / sc
    } catch (e: Exception) { -1 }

    fun brightnessPct(): Int = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
    } catch (e: Exception) { -1 }

    fun volumePct(): Float = try {
        val a = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        a.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    } catch (e: Exception) { 0f }

    fun setVolumePct(f: Float) {
        try {
            val a = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            a.setStreamVolume(AudioManager.STREAM_MUSIC, (f * a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
        } catch (e: Exception) { }
    }

    fun listApps(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    fun openPackage(pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return launch(i)
    }

    fun openGallery(): String {
        val r = openApp("gallery"); if (r.startsWith("Opening")) return r
        val p = openApp("photos"); if (p.startsWith("Opening")) return p
        return if (launch(Intent(Intent.ACTION_VIEW, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI))) "Opening gallery." else "I couldn't open the gallery."
    }

    fun openFiles(): String {
        val r = openApp("files"); if (r.startsWith("Opening")) return r
        return if (launch(Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE))) "Opening files." else "I couldn't open Files."
    }

    fun wifiStatusText(): String {
        val w = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!w.isWifiEnabled) return "Wi-Fi is off."
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val onWifi = cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        if (!onWifi) return "Wi-Fi is on but not connected."
        @Suppress("DEPRECATION")
        val ssid = w.connectionInfo?.ssid?.trim('"')
        return if (ssid.isNullOrBlank() || ssid == "<unknown ssid>") "Wi-Fi is on and connected. Android hides the network name without Location permission."
        else "Wi-Fi is on and connected to $ssid."
    }

    /** Asks Android to add a network. The password goes only to the system dialog and is never stored. */
    fun addWifiNetwork(ssid: String, pass: String): String {
        if (Build.VERSION.SDK_INT < 30) return "This Android version can't add networks from apps. " + openSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
        return try {
            val b = WifiNetworkSuggestion.Builder().setSsid(ssid)
            if (pass.isNotEmpty()) b.setWpa2Passphrase(pass)
            val i = Intent(Settings.ACTION_WIFI_ADD_NETWORKS)
                .putParcelableArrayListExtra(Settings.EXTRA_WIFI_NETWORK_LIST, arrayListOf(b.build()))
            if (launch(i)) "Android will ask you to confirm adding $ssid." else "Android rejected that. " + openSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
        } catch (e: Exception) { "I couldn't add that network. " + openSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings") }
    }

    fun requestBluetoothOn(): String {
        if (btOn()) return "Bluetooth is already on."
        return if (launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))) "Android is asking you to allow Bluetooth."
        else "Android needs you to do this in settings. " + openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
    }

    /** Opens the SMS composer only. The user reviews and taps Send; Nova never sends messages by itself. */
    fun openSms(number: String?): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number ?: "")))
        return if (launch(i)) "Message composer is open. Review it and tap Send." else "I couldn't open a messaging app."
    }

    fun setTimer(seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Timer set." else "No clock app handled the timer."
    }

    fun setAlarm(hour: Int, minute: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Alarm set for %02d:%02d.".format(hour, minute) else "No clock app handled the alarm."
    }

    private fun gb(b: Long) = String.format("%.1f GB", b / 1073741824.0)

    companion object {
        val SETTINGS = mapOf(
            "wifi" to (Settings.ACTION_WIFI_SETTINGS to "Wi-Fi settings"),
            "bluetooth" to (Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth settings"),
            "display" to (Settings.ACTION_DISPLAY_SETTINGS to "display settings"),
            "battery" to (Intent.ACTION_POWER_USAGE_SUMMARY to "battery settings"),
            "mobile" to (Settings.ACTION_WIRELESS_SETTINGS to "network settings"),
            "sound" to (Settings.ACTION_SOUND_SETTINGS to "sound settings"),
            "settings" to (Settings.ACTION_SETTINGS to "Settings")
        )
    }
}
