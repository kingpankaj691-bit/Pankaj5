package com.nova.ai.suite

import android.content.Context
import com.google.mlkit.vision.common.InputImage
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.security.Prefs
import com.nova.ai.vision.ScreenCaptureManager
import com.nova.ai.vision.TextRecognitionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Screen translation, text extraction and summaries shown in the overlay sheet. Runs only when you ask (voice, orb menu or orb
 * double tap). Text comes from the accessibility tree first; if that is empty and you started Screen Vision, one frame is read with
 * on-device OCR. Text is sent to the selected Gemini model only for translate/summarize, never for plain extraction.
 */
object ScreenTools {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val languages = listOf("hindi", "hinglish", "english", "urdu", "bengali", "tamil", "telugu", "marathi", "gujarati", "punjabi", "spanish", "french", "german", "arabic", "japanese", "korean", "chinese", "russian", "portuguese")

    /** Target language named in a command, or null. */
    fun languageIn(text: String): String? = languages.firstOrNull { text.lowercase().contains(it) }?.replaceFirstChar { it.uppercase() }

    private fun working(on: Boolean) { FloatingOrb.processing = on; FloatingOrb.current?.refresh() }

    private fun accessibilityText(): Pair<String, String> {
        val s = NovaAccessibilityService.instance?.snapshot() ?: return "" to ""
        return s.pkg to s.text(6000)
    }

    private suspend fun ocr(): String {
        val frame = ScreenCaptureManager.capture() ?: return ""
        val mgr = TextRecognitionManager()
        return try {
            val maxSide = PerfProfile.ocrMaxSide(com.nova.ai.NovaApp.instance)
            val src = frame.bitmap
            val scale = maxSide.toFloat() / maxOf(src.width, src.height)
            val bmp = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
            val t = try {
                suspendCancellableCoroutine<String> { c -> mgr.read(InputImage.fromBitmap(bmp, 0)) { if (c.isActive) c.resume(it) } }
            } finally { if (bmp !== src) bmp.recycle() }
            if (t.startsWith("I couldn't find readable text")) "" else t
        } finally { mgr.close(); frame.recycle() }
    }

    /** Text of what is on screen right now plus the app it belongs to. Empty text means nothing readable was found. */
    internal suspend fun readNow(): Pair<String, String> {
        val (pkg, t) = accessibilityText()
        if (t.isNotBlank()) return pkg to t
        val o = ocr()
        return (pkg.ifBlank { NovaAccessibilityService.activePackage() }) to o
    }

    internal fun aiReady(p: Prefs) = p.hasActiveKey() && p.aiEnabled && !p.localOnly

    private fun noText(ctx: Context) {
        NovaSheet.update("I couldn't read this screen. Turn on Nova in Accessibility, or start Screen Vision from the Screen Assistant page so I can read pixels with OCR.", false)
    }

    private fun gated(ctx: Context, key: String, name: String): Boolean {
        if (Features.enabled(ctx, key)) return false
        NovaSheet.show(ctx, name, Features.off(name), false, listOf(SheetAction("Close", true) { NovaSheet.hide() })); return true
    }

    private fun needOverlay(ctx: Context): Boolean {
        if (NovaSheet.canShow(ctx)) return false
        SystemControls.openOverlay(ctx); return true
    }

    /** Translation of already-read text with the selected model; returns the translation, or a plain message if AI is unavailable. */
    internal suspend fun aiTranslate(ctx: Context, pkg: String, text: String, target: String): String {
        val p = Prefs(ctx)
        if (!aiReady(p)) return "Translation needs an API key, AI on and local-only off.\n\n" + text.trim()
        val sys = "Detect the source language automatically (Hindi, Hinglish, English or any other). Translate the screen text into $target, keeping meaning and tone. " +
            "Ignore UI noise such as icons, times and battery. Output only the translation."
        return when (val r = SwitchingProvider(p).chat(listOf(true to AppContext.buildPrompt(pkg, "Translate to $target", text)), sys, null)) {
            is AiResult.Ok -> r.text.trim()
            is AiResult.Err -> "⚠ " + r.msg
        }
    }

    fun extract(ctx: Context) {
        if (gated(ctx, Features.VISION, "Vision & OCR") || needOverlay(ctx)) return
        NovaSheet.show(ctx, "Extracted text", "", true)
        scope.launch {
            working(true)
            val (_, t) = readNow()
            working(false)
            if (t.isBlank()) noText(ctx) else NovaSheet.update(t.trim(), false)
        }
    }

    fun translate(ctx: Context, target: String) {
        if (gated(ctx, Features.SCREEN, "Screen Intelligence") || needOverlay(ctx)) return
        NovaSheet.show(ctx, "Translate to $target", "", true)
        scope.launch {
            working(true)
            try {
                val (pkg, t) = readNow()
                if (t.isBlank()) { noText(ctx); return@launch }
                val p = Prefs(ctx)
                if (!aiReady(p)) { NovaSheet.update("Translation needs an API key, AI on and local-only off.\n\nText found:\n" + t.trim(), false); return@launch }
                val sys = "Detect the source language automatically (Hindi, Hinglish, English or any other). Translate the screen text into $target, keeping meaning and tone. " +
                    "Ignore UI noise such as icons, times and battery. If a line is already in $target keep it. Output only the translation."
                val r = SwitchingProvider(p).chat(listOf(true to AppContext.buildPrompt(pkg, "Translate to $target", t)), sys, null)
                NovaSheet.update(when (r) { is AiResult.Ok -> r.text.trim(); is AiResult.Err -> "⚠ " + r.msg }, false)
            } finally { working(false) }
        }
    }

    fun summarize(ctx: Context) {
        if (gated(ctx, Features.SCREEN, "Screen Intelligence") || needOverlay(ctx)) return
        NovaSheet.show(ctx, "Screen summary", "", true)
        scope.launch {
            working(true)
            try {
                val (pkg, t) = readNow()
                if (t.isBlank()) { noText(ctx); return@launch }
                val p = Prefs(ctx)
                if (!aiReady(p)) { NovaSheet.update("Summaries need an API key, AI on and local-only off.\n\nText found:\n" + t.trim(), false); return@launch }
                val sys = "Summarize what is on this screen in a few short lines in the user's language (Hindi/Hinglish/English as the text suggests). Mention errors or warnings first if any."
                val r = SwitchingProvider(p).chat(listOf(true to AppContext.buildPrompt(pkg, "Summarize this screen", t)), sys, null)
                NovaSheet.update(when (r) { is AiResult.Ok -> r.text.trim(); is AiResult.Err -> "⚠ " + r.msg }, false)
            } finally { working(false) }
        }
    }

    /** "WhatsApp par reply draft karo": reads the visible chat, offers 3 replies. Choosing one types it into the message box; Nova never presses Send here. */
    fun draftReply(ctx: Context) {
        if (gated(ctx, Features.SCREEN, "Screen Intelligence") || needOverlay(ctx)) return
        NovaSheet.show(ctx, "Reply drafts", "", true)
        scope.launch {
            working(true)
            try {
                val (pkg, t) = readNow()
                if (t.isBlank()) { noText(ctx); return@launch }
                val p = Prefs(ctx)
                if (!aiReady(p)) { NovaSheet.update("Reply drafts need an API key, AI on and local-only off.", false); return@launch }
                val sys = "You see a chat screen. Write 3 short reply options (friendly, neutral, brief) to the LAST incoming message, in the language of the chat. " +
                    "Reply with ONLY JSON: {\"replies\":[\"...\",\"...\",\"...\"]}. Never invent facts or promises."
                val r = SwitchingProvider(p).chat(listOf(true to AppContext.buildPrompt(pkg, "Draft replies", t)), sys, null)
                val txt = (r as? AiResult.Ok)?.text ?: run { NovaSheet.update("⚠ " + (r as AiResult.Err).msg, false); return@launch }
                val replies = try {
                    val a = org.json.JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1)).getJSONArray("replies")
                    (0 until a.length()).map { a.getString(it).trim() }.filter { it.isNotBlank() }.take(3)
                } catch (e: Exception) { emptyList() }
                if (replies.isEmpty()) { NovaSheet.update(txt.trim(), false); return@launch }
                val actions = replies.mapIndexed { i, rep -> SheetAction("Use ${i + 1}", i == 0) { insertReply(ctx, rep) } }
                NovaSheet.update(replies.mapIndexed { i, rep -> "${i + 1}. $rep" }.joinToString("\n\n") + "\n\nI only type the reply into the box. You press Send.", false, actions)
            } finally { working(false) }
        }
    }

    private fun insertReply(ctx: Context, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Nova", text))
        val ok = NovaAccessibilityService.instance?.typeTextChecked(text) == null && NovaAccessibilityService.instance != null
        NovaSheet.hide()
        if (!ok) NovaSheet.show(ctx, "Reply", "Couldn't type into the box, so the reply is on your clipboard: paste it.", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
    }

    /** "Is text ko copy karo": copies your selection; else the focused field; else the whole visible screen text. */
    fun copyText(ctx: Context): String {
        val svc = NovaAccessibilityService.instance ?: return "Accessibility is off, so I can't read the screen."
        val (t, what) = svc.selectedText()?.let { it to "selected text" } ?: svc.focusedFieldText()?.takeIf { it.isNotBlank() }?.let { it to "the text in this field" }
            ?: (svc.snapshot()?.text(8000).orEmpty() to "everything visible on the screen")
        if (t.isBlank()) return "I found no text to copy."
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Nova", t))
        return "Copied $what (${t.length} characters)."
    }
}
