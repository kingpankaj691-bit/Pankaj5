package com.nova.ai.vision

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** On-device text recognition (ML Kit). Reads Latin and Devanagari (Hindi) text and keeps whichever read found more. Nothing is uploaded. */
class TextRecognitionManager {
    private val latin: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val devanagari: TextRecognizer = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())

    fun read(input: InputImage, done: (String) -> Unit) {
        var latinText: String? = null
        var devText: String? = null
        fun finish() {
            val a = latinText ?: return
            val b = devText ?: return
            val best = if (b.length > a.length) b else a
            done(if (best.isBlank()) "I couldn't find readable text. Hold the phone steady, closer to the text, with good light." else best.trim())
        }
        latin.process(input).addOnSuccessListener { latinText = it.text; finish() }.addOnFailureListener { latinText = ""; finish() }
        devanagari.process(input).addOnSuccessListener { devText = it.text; finish() }.addOnFailureListener { devText = ""; finish() }
    }

    fun close() { try { latin.close(); devanagari.close() } catch (e: Exception) { } }
}
