package com.nova.ai.files

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File

/**
 * Every File Manager operation goes through here: access check → storage-volume check → safety rules → the real operation →
 * verified result → history. Callers run these on a background thread (they do real file I/O). Delete is only ever called after the
 * user confirmed in a dialog; nothing here deletes or changes anything on its own initiative.
 */
object FileOps {
    private fun roots(ctx: Context) = StorageVolumes.roots(ctx)

    private fun canon(p: String) = try { File(p).canonicalPath } catch (e: Exception) { p }

    /** Why a path can't be touched by path, or null. */
    private fun pathProblem(ctx: Context, path: String): String? {
        val c = canon(path)
        if (!PathRules.isWithinAny(roots(ctx), c)) return "That's outside your phone's storage."
        return PathRules.blockedReason(c)
    }

    private fun needWrite(ctx: Context): String? {
        val a = FileAccess.state(ctx, 0)
        return if (a.canWrite) null else "Changing files needs “All files access” (Android 11+) or the storage permission (Android 8-9)."
    }

    private fun log(ctx: Context, op: FileOp, name: String, target: String, r: OpResult) =
        FileHistory.record(ctx, op, name, target, if (r.ok) FileStatus.OK else FileStatus.FAILED, if (r.ok) "" else r.message.take(120))

    private fun merge(label: String, results: List<OpResult>): OpResult {
        if (results.size == 1) return results[0]
        val ok = results.count { it.ok }; val bad = results.size - ok
        val msg = if (bad == 0) "$label: all $ok items done (verified)." else "$label: $ok done, $bad failed. " + results.firstOrNull { !it.ok }?.message.orEmpty()
        return OpResult(bad == 0, msg, ok, bad)
    }

    private suspend fun forEachPath(ctx: Context, items: List<FileItem>, destDir: String?, op: FileOp,
        local: (File, File?) -> OpResult, shizuku: suspend (String, String?) -> OpResult): OpResult {
        val canWrite = FileAccess.state(ctx, 0).canWrite
        val destProblem = destDir?.let { pathProblem(ctx, it) }
        val results = ArrayList<OpResult>()
        for (item in items) {
            val srcProblem = pathProblem(ctx, item.path)
            val r: OpResult = when {
                srcProblem != null -> OpResult(false, srcProblem, 0, 1)
                destProblem != null -> OpResult(false, destProblem, 0, 1)
                canWrite -> local(File(canon(item.path)), destDir?.let { File(canon(it)) })
                ShizukuFiles.ready() -> shizuku(item.path, destDir)
                else -> OpResult(false, needWrite(ctx) ?: "Not allowed.", 0, 1)
            }
            log(ctx, op, item.name, destDir.orEmpty(), r)
            results.add(r)
        }
        return merge(op.label, results)
    }

    suspend fun copy(ctx: Context, items: List<FileItem>, destDir: String): OpResult =
        forEachPath(ctx, items, destDir, FileOp.COPY, { s, d -> LocalFs.copy(s, d!!) }, { s, d -> ShizukuFiles.copy(s, d!!) })

    suspend fun move(ctx: Context, items: List<FileItem>, destDir: String): OpResult =
        forEachPath(ctx, items, destDir, FileOp.MOVE, { s, d -> LocalFs.move(s, d!!) }, { s, d -> ShizukuFiles.move(s, d!!) })

    fun rename(ctx: Context, item: FileItem, newName: String): OpResult {
        val r = pathProblem(ctx, item.path)?.let { OpResult(false, it, 0, 1) } ?: needWrite(ctx)?.let { OpResult(false, it, 0, 1) } ?: LocalFs.rename(File(canon(item.path)), newName)
        log(ctx, FileOp.RENAME, item.name, newName, r); return r
    }

    suspend fun mkdir(ctx: Context, parent: String, name: String): OpResult {
        val r = pathProblem(ctx, parent)?.let { OpResult(false, it, 0, 1) }
            ?: if (FileAccess.state(ctx, 0).canWrite) LocalFs.mkdir(File(canon(parent)), name)
            else if (ShizukuFiles.ready()) ShizukuFiles.mkdir(parent, name)
            else OpResult(false, needWrite(ctx) ?: "Not allowed.", 0, 1)
        log(ctx, FileOp.MKDIR, name, parent, r); return r
    }

    /** Only after the user confirmed. DeleteGuard refuses volumes, standard folders and protected places no matter what. */
    suspend fun delete(ctx: Context, items: List<FileItem>): OpResult {
        val canWrite = FileAccess.state(ctx, 0).canWrite; val rs = roots(ctx)
        val results = ArrayList<OpResult>()
        for (item in items) {
            val c = canon(item.path)
            val refusal = DeleteGuard.refusal(c, rs)
            val r: OpResult = when {
                refusal != null -> OpResult(false, refusal, 0, 1)
                canWrite -> LocalFs.delete(File(c))
                ShizukuFiles.ready() && !item.isDir -> ShizukuFiles.delete(c)
                else -> OpResult(false, needWrite(ctx) ?: "Not allowed.", 0, 1)
            }
            log(ctx, FileOp.DELETE, item.name, "", r); results.add(r)
        }
        return merge("Delete", results)
    }

    /** Photos/videos/audio that only exist as MediaStore items (no path access). Android shows its own approval dialog. */
    fun mediaStoreDeleteRequest(ctx: Context, items: List<FileItem>): IntentSender? {
        val uris = items.mapNotNull { it.uri?.let(Uri::parse) }
        if (Build.VERSION.SDK_INT < 30 || uris.isEmpty()) return null
        return try { MediaStore.createDeleteRequest(ctx.contentResolver, uris).intentSender } catch (e: Exception) { null }
    }

    fun zip(ctx: Context, items: List<FileItem>, destDir: String, name: String): OpResult {
        val n = (name.trim().ifBlank { "archive" }).let { if (it.lowercase().endsWith(".zip")) it else "$it.zip" }
        val r = pathProblem(ctx, destDir)?.let { OpResult(false, it, 0, 1) } ?: needWrite(ctx)?.let { OpResult(false, it, 0, 1) }
            ?: NameRules.validate(n)?.let { OpResult(false, it, 0, 1) }
            ?: items.firstNotNullOfOrNull { pathProblem(ctx, it.path) }?.let { OpResult(false, it, 0, 1) }
            ?: run {
                val dir = File(canon(destDir))
                LocalFs.zip(items.map { File(canon(it.path)) }, File(dir, NameRules.uniqueName(n) { File(dir, it).exists() }))
            }
        log(ctx, FileOp.ZIP, n, destDir, r); return r
    }

    fun unzip(ctx: Context, item: FileItem, destDir: String): OpResult {
        val r = pathProblem(ctx, destDir)?.let { OpResult(false, it, 0, 1) } ?: pathProblem(ctx, item.path)?.let { OpResult(false, it, 0, 1) }
            ?: needWrite(ctx)?.let { OpResult(false, it, 0, 1) } ?: LocalFs.unzip(File(canon(item.path)), File(canon(destDir)))
        log(ctx, FileOp.UNZIP, item.name, destDir, r); return r
    }

    /** Opens Android's Sharesheet. The user picks where it goes; Nova uploads nothing itself. */
    fun share(ctx: Context, items: List<FileItem>): String {
        val uris = items.filter { !it.isDir }.mapNotNull { FileOpener.uriFor(ctx, it) }
        if (uris.isEmpty()) return "Nothing here can be shared (folders can't be shared; zip them first)."
        return try {
            val send = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE)
            send.type = if (uris.size == 1) FileOpener.mimeFor(items.first { !it.isDir }) else "*/*"
            if (uris.size == 1) send.putExtra(Intent.EXTRA_STREAM, uris[0]) else send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            val clip = ClipData.newRawUri("files", uris[0]); uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
            send.clipData = clip; send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(send, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
            FileHistory.record(ctx, FileOp.SHARE, if (items.size == 1) items[0].name else "${uris.size} files", "Sharesheet", FileStatus.OK, "")
            "Choose where to share ${if (uris.size == 1) items.first { !it.isDir }.name else "${uris.size} files"}."
        } catch (e: Exception) {
            FileHistory.record(ctx, FileOp.SHARE, items.firstOrNull()?.name.orEmpty(), "", FileStatus.FAILED, "no sharing app")
            "I couldn't open the share sheet."
        }
    }

    // ── Organize: preview first, then move ──
    fun organizePlan(ctx: Context, dir: String): Pair<List<OrganizePlanner.Move>, String> {
        pathProblem(ctx, dir)?.let { return emptyList<OrganizePlanner.Move>() to it }
        val kids = try { File(canon(dir)).listFiles() } catch (e: Exception) { null } ?: return emptyList<OrganizePlanner.Move>() to "Android didn't let Nova read that folder."
        return OrganizePlanner.plan(kids.filter { it.isFile }.map { FileBrowser.fromFile(it) }) to ""
    }

    fun organizeExecute(ctx: Context, dir: String, plan: List<OrganizePlanner.Move>): OpResult {
        needWrite(ctx)?.let { return OpResult(false, it, 0, 1) }
        pathProblem(ctx, dir)?.let { return OpResult(false, it, 0, 1) }
        val base = File(canon(dir)); var ok = 0; var bad = 0
        for (m in plan) {
            val folder = File(base, m.toFolder)
            if (!folder.isDirectory && !folder.mkdirs()) { bad++; continue }
            val src = File(canon(m.from))
            if (src.parentFile?.canonicalPath != base.canonicalPath) { bad++; continue }       // plan is stale or tampered with
            val r = LocalFs.move(src, folder)
            if (r.ok) ok++ else bad++
        }
        val res = OpResult(bad == 0, if (bad == 0) "Organized $ok file${if (ok == 1) "" else "s"} into type folders (verified)." else "Organized $ok, but $bad couldn't be moved.", ok, bad)
        FileHistory.record(ctx, FileOp.ORGANIZE, base.name, "$ok moved", if (res.ok) FileStatus.OK else FileStatus.FAILED, if (bad > 0) "$bad failed" else "")
        return res
    }

    // ── Duplicates (read-only scan; deleting goes through delete() after confirmation) ──
    fun findDuplicates(ctx: Context, scanRoots: List<String>, alive: () -> Boolean): List<List<FileItem>> {
        val safe = scanRoots.filter { pathProblem(ctx, it) == null }.map { File(canon(it)) }
        val files = LocalFs.listFiles(safe, 50_000, alive)
        return LocalFs.findDuplicates(files, alive).map { g -> g.map { FileBrowser.fromFile(it) } }
    }
}
