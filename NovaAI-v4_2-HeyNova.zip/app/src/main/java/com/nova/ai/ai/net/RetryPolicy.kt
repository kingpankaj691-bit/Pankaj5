package com.nova.ai.ai.net

import kotlin.random.Random

/**
 * Exponential back-off with jitter that respects Retry-After and can never loop forever:
 * a hard retry count, a hard wall-clock budget, and no retry at all for permanent errors.
 */
class RetryPolicy(
    val maxRetries: Int = 2,
    val baseMs: Long = 800L,
    val capMs: Long = 20_000L,
    /** A server that asks us to wait longer than this is not waited for; the error is shown instead. */
    val maxRetryAfterMs: Long = 30_000L,
    val budgetMs: Long = 120_000L,
    val retryOnResponseTimeout: Boolean = false,
    private val random: Random = Random.Default
) {
    /**
     * @param retriesDone how many retries already happened (0 for the first failure)
     * @param elapsedMs time spent since the first attempt started
     * @return milliseconds to wait before the next attempt, or null to give up
     */
    fun nextDelayMs(retriesDone: Int, error: GeminiError, elapsedMs: Long = 0L): Long? {
        if (!error.kind.retryable) return null
        if (error.kind == GeminiErrorKind.RESPONSE_TIMEOUT && !retryOnResponseTimeout) return null
        if (retriesDone >= maxRetries) return null
        val ra = error.retryAfterMs
        if (ra != null && ra > maxRetryAfterMs) return null
        val exp = minOf(capMs, baseMs shl retriesDone.coerceIn(0, 20))
        val jittered = exp / 2 + random.nextLong(exp / 2 + 1)      // "equal jitter": never below half, never above the cap
        val wait = maxOf(jittered, ra ?: 0L)
        if (elapsedMs + wait > budgetMs) return null
        return wait
    }

    companion object {
        /** Typed chat: two retries for transient failures. */
        fun chat() = RetryPolicy(maxRetries = 2)
        /** Background voice, web search, vision: one quick retry so the pipeline never stalls. */
        fun voice() = RetryPolicy(maxRetries = 1, baseMs = 500L, capMs = 4_000L, maxRetryAfterMs = 8_000L, budgetMs = 40_000L)
        fun none() = RetryPolicy(maxRetries = 0)
    }
}
