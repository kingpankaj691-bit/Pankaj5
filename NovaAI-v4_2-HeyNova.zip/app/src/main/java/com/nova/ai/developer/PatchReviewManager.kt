package com.nova.ai.developer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class PatchStatus { NEW, REVIEWED, APPLIED, REJECTED }
data class Patch(val id: Long, val title: String, val body: String, val status: PatchStatus, val at: Long)

/**
 * A shelf for AI-suggested fixes. A suggestion is only text for a developer to read; Nova never applies, compiles or runs it.
 * "Applied" just records that YOU changed the code yourself in AndroidIDE.
 */
class PatchReviewManager(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "patch_review.json")

    fun list(): List<Patch> = try {
        val a = JSONArray(if (file.exists()) file.readText() else "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it)
            Patch(o.getLong("id"), o.getString("title"), o.getString("body"), PatchStatus.values().firstOrNull { s -> s.name == o.optString("status") } ?: PatchStatus.NEW, o.optLong("at")) }
            .sortedByDescending { it.at }
    } catch (e: Exception) { emptyList() }

    private fun save(items: List<Patch>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("status", it.status.name).put("at", it.at)) }
        file.writeText(a.toString())
    }

    fun add(title: String, body: String): Patch {
        val p = Patch(System.currentTimeMillis(), title.take(80), DiagnosticsManager.sanitize(body).take(20000), PatchStatus.NEW, System.currentTimeMillis())
        save((list() + p).sortedByDescending { it.at }.take(30))
        return p
    }

    fun setStatus(id: Long, s: PatchStatus) = save(list().map { if (it.id == id) it.copy(status = s) else it })
    fun delete(id: Long) = save(list().filter { it.id != id })
}
