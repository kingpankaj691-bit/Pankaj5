package com.nova.ai.control

import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import com.nova.ai.accessibility.NovaAccessibilityService

/** One row of the "what can Nova do on THIS phone right now" matrix. Computed from real state, never hard-coded as available. */
data class CapabilityRow(val name: String, val supported: Boolean, val via: String, val note: String)

object Capabilities {
    fun rows(ctx: Context): List<CapabilityRow> {
        val sz = ShizukuManager.refresh().status == ShizukuStatus.READY
        val write = Settings.System.canWrite(ctx)
        val dnd = (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted
        val a11y = NovaAccessibilityService.instance != null
        val sdk = Build.VERSION.SDK_INT
        return listOf(
            CapabilityRow("Brightness", write || sz, if (write) "Settings API" else if (sz) "Shizuku" else "-", if (write || sz) "Verified by reading it back" else "Needs 'Modify system settings' or Shizuku"),
            CapabilityRow("Screen timeout", write || sz, if (write) "Settings API" else if (sz) "Shizuku" else "-", if (write || sz) "" else "Needs 'Modify system settings' or Shizuku"),
            CapabilityRow("Auto-rotate", write || sz, if (write) "Settings API" else if (sz) "Shizuku" else "-", ""),
            CapabilityRow("Volume", true, "AudioManager", ""),
            CapabilityRow("Flashlight", true, "Camera API", ""),
            CapabilityRow("Wi-Fi on/off", sz, if (sz) "Shizuku" else "Settings panel (manual)", if (sz) "" else "Android ${sdk} blocks apps from toggling Wi-Fi"),
            CapabilityRow("Bluetooth on/off", sz, if (sz) "Shizuku" else "System dialog / Settings (manual)", if (sz) "" else "Turning off needs Shizuku"),
            CapabilityRow("Do Not Disturb", dnd || sz, if (dnd) "Policy access" else if (sz) "Shizuku" else "-", if (dnd || sz) "" else "Grant Do Not Disturb access"),
            CapabilityRow("Force-stop an app", sz, if (sz) "Shizuku (asks first)" else "App info screen (manual)", "Android never allows this without Shizuku/root"),
            CapabilityRow("Tap / swipe / type on screen", a11y || sz, if (a11y) "Accessibility" else if (sz) "Shizuku input" else "-", if (a11y) "Not in payment/banking/password apps" else "Enable the Accessibility service"),
            CapabilityRow("Read screen & buttons", a11y, "Accessibility", if (a11y) "" else "Enable the Accessibility service"),
            CapabilityRow("Battery / storage / device info", true, "Android API", ""),
            CapabilityRow("Uninstall an app (you confirm in Android)", AppInstaller.canUninstall(ctx), "Android uninstall screen", if (AppInstaller.canUninstall(ctx)) "Never silent; never system, security or protected apps" else "Uninstall permission missing in this build"),
            CapabilityRow("Install an APK (you confirm in Android)", AppInstaller.canInstallUnknown(ctx), "Android installer screen", if (AppInstaller.canInstallUnknown(ctx)) "Never silent" else "Turn on \"Allow from this source\" for Nova AI first"),
            CapabilityRow("Install / uninstall apps silently", false, "-", "Never done; Android's own screens always ask you"),
            CapabilityRow("Factory reset / change lock security", false, "-", "Blocked by design; the owner must do this in Android"),
            CapabilityRow("Root-only operations", false, "-", "Not needed and not used")
        )
    }

    fun summary(ctx: Context): String {
        val r = rows(ctx)
        val yes = r.filter { it.supported }.joinToString(", ") { it.name }
        val no = r.filter { !it.supported }.joinToString(", ") { it.name }
        return "Available now: $yes. Not available: $no."
    }
}
