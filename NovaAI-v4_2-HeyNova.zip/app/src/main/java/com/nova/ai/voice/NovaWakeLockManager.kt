package com.nova.ai.voice

import android.content.Context
import android.os.PowerManager

/**
 * Holds a PARTIAL_WAKE_LOCK (CPU on, screen may be off) only while Background Voice is enabled and the microphone is open.
 * It is released on pause, stop, fatal error and in the service's onDestroy.
 */
class NovaWakeLockManager(ctx: Context) {
    private val pm = ctx.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
    private var lock: PowerManager.WakeLock? = null

    @Synchronized
    fun isHeld(): Boolean = lock?.isHeld == true

    @Synchronized
    fun acquire() {
        if (lock?.isHeld == true) return
        val l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Nova:BackgroundVoice")
        l.setReferenceCounted(false)
        l.acquire()
        lock = l
    }

    @Synchronized
    fun release() {
        try {
            lock?.let { if (it.isHeld) it.release() }
        } catch (e: RuntimeException) {
            // Already released by the system; nothing left to free.
        }
        lock = null
    }
}
