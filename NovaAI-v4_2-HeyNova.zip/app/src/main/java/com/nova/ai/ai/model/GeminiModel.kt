package com.nova.ai.ai.model

/** What a model is for. Decided from the official method list (models.list) and, only when that is missing, from the id. */
enum class ModelKind { TEXT, LIVE_CONVERSATION, LIVE_TRANSCRIBE, TTS, IMAGE, EMBEDDING, OTHER }

/** The single response modality a Live API session may request. Live sessions accept ONE modality, never a mix. */
enum class LiveModality {
    AUDIO, TEXT;

    fun flipped(): LiveModality = if (this == AUDIO) TEXT else AUDIO
}

/** What Nova may do with a model. Every feature checks this before it uses the model. */
data class ModelCapabilities(
    val kind: ModelKind,
    /** generateContent (REST text/chat). */
    val generateContent: Boolean,
    /** streamGenerateContent. Always paired with generateContent on the Gemini API. */
    val streaming: Boolean,
    /** bidiGenerateContent (WebSocket Live API). */
    val liveApi: Boolean,
    /** Native audio in/out over the Live API. */
    val nativeAudio: Boolean,
    /** Response modality to request on a Live session, or null when the model has no Live API. */
    val liveModality: LiveModality?,
    /** false = inferred from the id only (the model list has not been loaded or does not contain it). */
    val known: Boolean
) {
    /** Can answer typed/voice-fallback questions through generateContent. */
    val chatCapable: Boolean get() = generateContent && kind == ModelKind.TEXT

    /** Can hold a spoken two-way conversation over the Live API. */
    val nativeLive: Boolean get() = liveApi && (kind == ModelKind.TEXT || kind == ModelKind.LIVE_CONVERSATION)

    val transcription: Boolean get() = kind == ModelKind.LIVE_TRANSCRIBE
    val tts: Boolean get() = kind == ModelKind.TTS

    /** May be chosen as Nova's active model. */
    val selectable: Boolean get() = chatCapable || nativeLive
}

object ModelClassifier {
    private val ttsId = Regex("(^|[-_.])tts($|[-_.])")

    /**
     * [methods] = supportedGenerationMethods from models.list. When [known] is false nothing is known about the model except its id
     * (offline, list not loaded, or a custom id), so only obvious id patterns are used and generateContent is assumed for plain names.
     */
    fun classify(id: String, methods: Set<String>, known: Boolean = true): ModelCapabilities {
        val n = id.lowercase().removePrefix("models/")
        val hasGen = methods.contains("generateContent")
        val hasBidi = methods.contains("bidiGenerateContent")
        val liveName = n.contains("live") || n.contains("native-audio")
        val kind = when {
            ttsId.containsMatchIn(n) -> ModelKind.TTS
            n.contains("transcribe") -> ModelKind.LIVE_TRANSCRIBE
            n.startsWith("imagen") || (n.contains("image") && !liveName) -> ModelKind.IMAGE
            n.contains("embedding") || (known && !hasGen && methods.any { it.contains("embed", ignoreCase = true) }) -> ModelKind.EMBEDDING
            known && !hasGen && hasBidi -> ModelKind.LIVE_CONVERSATION
            known && !hasGen -> ModelKind.OTHER
            !known && liveName -> ModelKind.LIVE_CONVERSATION
            else -> ModelKind.TEXT
        }
        val liveApi = when (kind) {
            ModelKind.LIVE_TRANSCRIBE, ModelKind.LIVE_CONVERSATION -> true
            ModelKind.TEXT -> known && hasBidi
            else -> false
        }
        val generate = if (known) hasGen else (kind == ModelKind.TEXT || kind == ModelKind.TTS || kind == ModelKind.IMAGE)
        val nativeAudio = kind != ModelKind.LIVE_TRANSCRIBE && kind != ModelKind.TTS && liveApi &&
            (n.contains("native-audio") || n.contains("live") || kind == ModelKind.LIVE_CONVERSATION)
        val modality = when {
            kind == ModelKind.LIVE_TRANSCRIBE -> LiveModality.TEXT
            liveApi -> LiveModality.AUDIO
            else -> null
        }
        return ModelCapabilities(kind, generate, generate && kind == ModelKind.TEXT, liveApi, nativeAudio, modality, known)
    }
}

/** One entry of the Gemini model list. */
data class GeminiModel(
    /** Id without the "models/" prefix, exactly as it goes into a request. */
    val id: String,
    val displayName: String = "",
    val description: String = "",
    val inputTokenLimit: Int = 0,
    val outputTokenLimit: Int = 0,
    val methods: Set<String> = emptySet(),
    val version: String = "",
    val thinking: Boolean = false,
    val maxTemperature: Double? = null,
    /** false for entries that come from Nova's built-in offline list instead of Google's model list. */
    val verified: Boolean = true
) {
    val caps: ModelCapabilities by lazy { ModelClassifier.classify(id, methods, verified) }

    val label: String get() = displayName.ifBlank { id }

    val family: String
        get() {
            val n = id.lowercase()
            return when {
                n.contains("transcribe") -> "Transcribe"
                n.contains("flash-lite") || n.contains("flash_lite") -> "Flash-Lite"
                n.contains("flash") -> "Flash"
                n.contains("pro") -> "Pro"
                n.contains("gemma") -> "Gemma"
                else -> "Other"
            }
        }

    /** Short capability tags for the Settings list. */
    fun badges(): List<String> {
        val c = caps
        val out = ArrayList<String>()
        when (c.kind) {
            ModelKind.TEXT -> out.add("Chat")
            ModelKind.LIVE_CONVERSATION -> out.add("Live voice only")
            ModelKind.LIVE_TRANSCRIBE -> out.add("Speech-to-text")
            ModelKind.TTS -> out.add("Text-to-speech")
            ModelKind.IMAGE -> out.add("Image")
            ModelKind.EMBEDDING -> out.add("Embeddings")
            ModelKind.OTHER -> out.add("Other")
        }
        if (c.streaming) out.add("Streaming")
        if (c.nativeLive && c.kind == ModelKind.TEXT) out.add(if (c.nativeAudio) "Live (native audio)" else "Live")
        if (thinking) out.add("Thinking")
        if (!verified) out.add("Not verified")
        return out
    }

    fun limitsText(): String {
        fun k(n: Int) = when {
            n >= 1_000_000 -> "${n / 1_000_000}M"
            n >= 1_000 -> "${n / 1_000}K"
            else -> "$n"
        }
        return if (inputTokenLimit > 0 || outputTokenLimit > 0) "in ${k(inputTokenLimit)} · out ${k(outputTokenLimit)} tokens" else ""
    }
}

object ModelSort {
    private val version = Regex("(\\d+)(?:\\.(\\d+))?")

    fun versionKey(id: String): Int {
        val m = version.find(id) ?: return 0
        val major = m.groupValues[1].toIntOrNull() ?: 0
        val minor = m.groupValues[2].toIntOrNull() ?: 0
        return major * 1000 + minor
    }

    /** "-latest" aliases first, then the highest version, then by id. */
    val comparator: Comparator<GeminiModel> =
        compareBy<GeminiModel>({ !it.id.endsWith("-latest") }, { -versionKey(it.id) }, { it.id })
}
