package com.nova.ai.files

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A privacy receipt: when a document's text was sent to Gemini, how much, and whether it was a file or a project. Never file names, never contents. */
object AnalysisLedger {
    data class Entry(val time: Long, val chars: Int, val kind: String)
    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "file_analysis_log.json")

    fun list(ctx: Context): List<Entry> = try {
        val f = file(ctx); if (!f.exists()) emptyList() else JSONArray(f.readText()).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { Entry(it.optLong("t"), it.optInt("c"), it.optString("k")) } } }
    } catch (e: Exception) { emptyList() }

    @Synchronized fun add(ctx: Context, chars: Int, kind: String) {
        val all = (listOf(Entry(System.currentTimeMillis(), chars, kind)) + list(ctx)).take(100)
        try { file(ctx).writeText(JSONArray().also { a -> all.forEach { a.put(JSONObject().put("t", it.time).put("c", it.chars).put("k", it.kind)) } }.toString()) } catch (e: Exception) { }
    }

    fun clear(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }
}
