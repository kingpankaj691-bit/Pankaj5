package com.nova.ai.voice

import android.os.SystemClock
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.live.LiveOrbState
import com.nova.ai.live.LiveSession
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Process-wide state of the "Hey Nova" conversation. It does not own the microphone or any window:
 * the [com.nova.ai.jarvis.WakeGateEngine] writes it (wake heard / conversation over), the service and the orb read it.
 */
object NovaSession {
    /** True from the wake phrase until the conversation window closes. */
    val awake = MutableStateFlow(false)
    /** Dispatcher is working on a command (set around the headless answer). */
    val busy = MutableStateFlow(false)
    /** Settings test: forces the orb into one phase regardless of the real pipeline. */
    val forced = MutableStateFlow<OrbPhase?>(null)

    /** Counts wake phrases heard, so the settings screen can show a live "Hey Nova detected" test result. */
    val wakeCount = MutableStateFlow(0)
    val lastWakeHeard = MutableStateFlow("")
    @Volatile var lastWakeAt = 0L

    /** Emits the phrase that was heard, once per wake. */
    val wakeEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)

    /** Time of the last recognized command, so the conversation window can be kept open by real activity. */
    @Volatile var activityAt = 0L

    fun noteActivity() { activityAt = SystemClock.elapsedRealtime() }

    /** The last wake phrase was Hindi / Hinglish: short acknowledgements are spoken the same way ("Haan, boliye?"). */
    @Volatile var hindiHint = false

    /** [id] is the phrase id (see WakePhrases), [label] what to show the user. */
    fun onWake(id: String, label: String, hindi: Boolean = false) {
        lastWakeAt = SystemClock.elapsedRealtime()
        lastWakeHeard.value = label
        hindiHint = hindi
        awake.value = true
        wakeCount.value = wakeCount.value + 1
        wakeEvents.tryEmit(id)
    }

    /** The user dismissed the orb or the window timed out. Silences Nova and lets the gate close the conversation. */
    fun end() {
        awake.value = false
        VoiceState.interruptSpeech()
    }

    /** Nova is working on an answer (Gemini Live thinking, the headless assistant, or an on-screen task). */
    fun isThinking(): Boolean = LiveSession.state.value == LiveOrbState.THINKING || busy.value

    /** Nova is busy (thinking or talking): the conversation must stay open. */
    fun isBusy(): Boolean = VoiceState.speaking.value || isThinking()

    fun current(): OrbPhase = OrbPhases.derive(
        forced.value, VoiceState.running.value, VoiceState.paused.value, VoiceState.wakeGated, awake.value,
        VoiceState.speaking.value, isThinking(), FloatingOrb.processing
    )

    fun reset() { awake.value = false; busy.value = false; forced.value = null }
}
