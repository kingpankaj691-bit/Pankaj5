package com.nova.ai.commands

/** Tiny offline calculator: + - * / % ^ and parentheses, with a few spoken words. */
object Calc {
    fun fromText(raw: String): String? {
        var t = raw.lowercase().replace("what is", "").replace("what's", "").replace("calculate", "").replace("kitna hota hai", "")
            .replace("equals", "").replace("?", "").trim()
        t = t.replace("plus", "+").replace("minus", "-").replace("multiplied by", "*").replace("times", "*").replace("into", "*")
            .replace(" x ", "*").replace("divided by", "/").replace("over", "/")
        if (!Regex("^[0-9+\\-*/().^% ]+$").matches(t) || !t.any { it.isDigit() } || !t.any { it in "+-*/^%" }) return null
        return try {
            val v = P(t.replace(" ", "")).parse()
            if (v.isNaN() || v.isInfinite()) null
            else if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString() else "%.4f".format(v).trimEnd('0').trimEnd('.')
        } catch (e: Exception) { null }
    }

    private class P(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
        fun expr(): Double { var v = term(); while (i < s.length && (s[i] == '+' || s[i] == '-')) { val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r }; return v }
        fun term(): Double {
            var v = pow()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) { val op = s[i++]; val r = pow(); v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r } }
            return v
        }
        fun pow(): Double { val b = unary(); if (i < s.length && s[i] == '^') { i++; return Math.pow(b, pow()) }; return b }
        fun unary(): Double { if (i < s.length && s[i] == '-') { i++; return -unary() }; if (i < s.length && s[i] == '+') { i++; return unary() }; return atom() }
        fun atom(): Double {
            if (s[i] == '(') { i++; val v = expr(); if (s[i] != ')') throw IllegalArgumentException(); i++; return v }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(st, i).toDouble()
        }
    }
}
