package com.nova.ai.scanner

import android.content.Context
import java.io.File

/** The generated profile lives only in this app's private storage until the user deletes it. */
class DeviceProfileStore(ctx: Context) {
    private val file = File(ctx.filesDir, "device_profile.json")
    fun load(): DeviceProfile? = try { if (file.exists()) DeviceProfile.fromJson(file.readText()) else null } catch (e: Exception) { null }
    fun save(p: DeviceProfile) { try { file.writeText(p.toJson()) } catch (e: Exception) { } }
    fun delete() { try { file.delete() } catch (e: Exception) { } }
}
