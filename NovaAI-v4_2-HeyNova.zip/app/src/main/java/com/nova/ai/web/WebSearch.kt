package com.nova.ai.web

import com.nova.ai.ai.GeminiHttp
import com.nova.ai.security.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI

enum class WebKind { SEARCH, NEWS, PRICE, RESEARCH, OFFICIAL, YOUTUBE }
data class WebIntent(val kind: WebKind, val query: String)
data class WebSource(val title: String, val url: String, val domain: String, val https: Boolean, val trusted: Boolean)
data class WebAnswer(val text: String, val sources: List<WebSource>)
sealed class WebResult { data class Ok(val answer: WebAnswer) : WebResult(); data class Err(val msg: String) : WebResult() }

/** Pluggable search backend. The built-in one uses Gemini's Google Search grounding; others can be added later. */
interface WebSearchProvider {
    val name: String
    suspend fun search(intent: WebIntent, languageHint: String): WebResult
}

/** Reads the user's wording (Hindi/Hinglish/English) and decides if it is a web request. */
object WebIntentParser {
    private val yt = Regex("(?i)\\b(?:youtube|yt)\\b.*\\b(?:search|dhundo|dhoondo|dekho|play|chalao)\\b|\\b(?:search|dhundo|dhoondo)\\b.*\\byoutube\\b")
    private val lead = Regex("(?i)^(?:please |nova |hey nova )?(?:internet|web|google|net|online)\\s*(?:par|pe|me|mein|on)?\\s*(?:search|dhundo|dhoondo|dekho|khojo)?\\s*(?:karo|kar do|kijiye)?\\s*[:,]?\\s*")

    fun parse(raw: String): WebIntent? {
        val t = raw.trim().trim('.', '!', '?')
        val l = t.lowercase()
        if (yt.containsMatchIn(l)) {
            val q = l.replace(Regex("(?i)\\b(youtube|yt|par|pe|me|mein|on|search|karo|kar do|dhundo|dhoondo|dekho|play|chalao|for|ko|ka|ki)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            return if (q.isNotBlank()) WebIntent(WebKind.YOUTUBE, q) else null
        }
        val starts = listOf("internet par", "internet pe", "internet me", "internet mein", "web search", "search the web", "google search", "google karo", "google par", "online search", "net par")
        if (starts.any { l.startsWith(it) || l.contains(it) }) {
            val q = t.replace(lead, "").replace(Regex("(?i)^(?:search the web for|web search for|search for|search)\\s+"), "").trim()
            return if (q.length > 1) WebIntent(WebKind.SEARCH, q) else null
        }
        Regex("(?i)^(?:latest|aaj ki|taza|today'?s)?\\s*(?:news|khabar|khabrein|samachar)\\b(.*)$").find(l)?.let {
            val topic = it.groupValues[1].replace(Regex("(?i)\\b(batao|bata do|dikhao|sunao|about|on|ke baare mein)\\b"), " ").trim()
            if (l.contains("latest") || l.contains("batao") || l.contains("aaj") || l.contains("taza") || l.startsWith("news")) return WebIntent(WebKind.NEWS, topic.ifBlank { "top headlines" })
        }
        if (Regex("(?i)\\b(latest news|news batao|khabar batao|top news|headlines)\\b").containsMatchIn(l))
            return WebIntent(WebKind.NEWS, l.replace(Regex("(?i)\\b(latest|news|batao|bata do|khabar|top|headlines|about|on|ki|ke baare mein)\\b"), " ").replace(Regex("\\s+"), " ").trim().ifBlank { "top headlines" })
        Regex("(?i)^(.+?)\\s+(?:ka|ki|ke)?\\s*price\\s*(?:search\\s*karo|kya hai|batao|bata do|kitna hai)?$").find(t)?.let { return WebIntent(WebKind.PRICE, it.groupValues[1].trim() + " price") }
        Regex("(?i)^(?:iska|iski|iske)\\s+price\\s+(?:search\\s*karo|batao|kya hai)").find(t)?.let { return WebIntent(WebKind.PRICE, "__context__ price") }
        if (Regex("(?i)\\bofficial (?:website|site)\\b").containsMatchIn(l)) {
            val q = l.replace(Regex("(?i)\\b(official|website|site|dhundo|dhoondo|dhoondh|ka|ki|ke|search|karo|find|of|the|batao)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            return if (q.isNotBlank()) WebIntent(WebKind.OFFICIAL, q) else null
        }
        Regex("(?i)^(?:is|iss) (?:topic|baat) ko research karo|^research (.+)$|^(.+?) (?:ko|par) research karo$").find(t)?.let {
            val q = it.groupValues.drop(1).firstOrNull { g -> g.isNotBlank() } ?: "__context__"
            return WebIntent(WebKind.RESEARCH, q.trim())
        }
        return null
    }
}

object SourceVerifier {
    private val trustedSuffix = listOf(".gov", ".gov.in", ".nic.in", ".edu", ".ac.in", ".ac.uk", ".gov.uk", ".europa.eu", ".int")
    private val trustedDomains = setOf(
        "wikipedia.org", "reuters.com", "apnews.com", "bbc.com", "bbc.co.uk", "who.int", "un.org", "nasa.gov", "developer.android.com",
        "kotlinlang.org", "github.com", "thehindu.com", "indianexpress.com", "ndtv.com", "timesofindia.indiatimes.com", "pib.gov.in",
        "support.google.com", "play.google.com", "youtube.com", "britannica.com", "nature.com", "mayoclinic.org"
    )

    fun domainOf(url: String, title: String): String {
        val host = try { URI(url).host.orEmpty() } catch (e: Exception) { "" }
        // Grounding links are redirect URLs; the title is then the real site name.
        val h = if (host.contains("vertexaisearch") || host.contains("google.com") && url.contains("grounding")) title else host
        return h.lowercase().removePrefix("www.").trim()
    }

    fun check(title: String, url: String): WebSource {
        val d = domainOf(url, title)
        val trusted = trustedDomains.any { d == it || d.endsWith(".$it") } || trustedSuffix.any { d.endsWith(it) }
        return WebSource(title.ifBlank { d }, url, d, url.startsWith("https://"), trusted)
    }

    /** De-duplicates by domain, drops non-https, lists trusted sources first. */
    fun verify(raw: List<WebSource>): List<WebSource> =
        raw.filter { it.https }.distinctBy { it.domain.ifBlank { it.url } }.sortedByDescending { it.trusted }.take(5)
}

class GeminiGroundedSearch(private val prefs: Prefs) : WebSearchProvider {
    override val name = "Gemini + Google Search"

    override suspend fun search(intent: WebIntent, languageHint: String): WebResult {
        val task = when (intent.kind) {
            WebKind.NEWS -> "Give the latest news on: ${intent.query}. List 3 to 5 items, each one short line, newest first, with the date when known."
            WebKind.PRICE -> "Find the current price of: ${intent.query}. Give the price range seen in reliable sources, the date and the currency. Say if prices vary by seller or region."
            WebKind.RESEARCH -> "Research this topic and summarize the key facts in under 150 words, then list 3 key points: ${intent.query}"
            WebKind.OFFICIAL -> "Find the official website for: ${intent.query}. Give the exact official URL and what it is. Do not give third-party sites as official."
            else -> "Answer this using current web results: ${intent.query}"
        }
        val system = "You are NOVA's web research step. Use Google Search. Prefer official and reliable sources. Never invent facts, prices, quotes or URLs; " +
            "if sources disagree or you can't find it, say so plainly. Keep it short enough to read aloud, plain text, no markdown. $languageHint"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", task)))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", prefs.maxTokens.coerceAtLeast(600)))
        val out = GeminiHttp.post(prefs, body)
        val j = out.json ?: return WebResult.Err(out.error ?: "Search failed.")
        val text = GeminiHttp.textOf(j)
        val chunks = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        val raw = ArrayList<WebSource>()
        if (chunks != null) for (i in 0 until chunks.length()) {
            val w = chunks.getJSONObject(i).optJSONObject("web") ?: continue
            raw.add(SourceVerifier.check(w.optString("title"), w.optString("uri")))
        }
        val sources = SourceVerifier.verify(raw)
        if (text.isBlank()) return WebResult.Err("I couldn't get a reliable answer from the web for that.")
        if (sources.isEmpty()) return WebResult.Ok(WebAnswer("$text\n\n(No verifiable source links were returned, so treat this with caution.)", emptyList()))
        return WebResult.Ok(WebAnswer(text, sources))
    }
}

/** Entry point used by the ViewModel: checks availability honestly, runs the provider, formats the answer. */
class WebSearchManager(
    private val prefs: Prefs,
    private val provider: WebSearchProvider = GeminiGroundedSearch(prefs),
    private val fallback: com.nova.ai.search.SearchFallback = com.nova.ai.search.SearchFallback(prefs)
) {
    fun parse(raw: String): WebIntent? = WebIntentParser.parse(raw)

    fun unavailableReason(online: Boolean): String? = when {
        prefs.localOnly -> "Local-only mode is on, so I can't search the internet. Turn it off in Privacy & Security."
        !prefs.webSearchOn -> "Web search is switched off in Settings."
        !online -> "Internet is not available right now, so I can't search the web."
        !prefs.aiEnabled -> "AI is disabled in Settings, and web search needs it."
        else -> null
    }

    /** Gemini grounded search when Gemini is the active provider with a key; otherwise public, key-free search. */
    private fun grounded() = prefs.aiProvider != Prefs.PROVIDER_OPENAI && prefs.geminiEnabled && prefs.apiKey.isNotBlank()

    suspend fun run(intent: WebIntent, languageHint: String): String {
        if (!grounded()) return fallback.run(intent, languageHint)
        return when (val r = provider.search(intent, languageHint)) {
            is WebResult.Err -> "⚠ ${r.msg}"
            is WebResult.Ok -> {
                val a = r.answer
                if (a.sources.isEmpty()) a.text
                else a.text + "\n\nSources: " + a.sources.joinToString(", ") { it.domain + if (it.trusted) " ✓" else "" }
            }
        }
    }
}
