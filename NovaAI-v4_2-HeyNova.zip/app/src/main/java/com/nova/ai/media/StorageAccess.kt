package com.nova.ai.media

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import com.nova.ai.BuildConfig
import java.io.File

data class DocEntry(val name: String, val docId: String, val uri: Uri, val mime: String, val size: Long, val isDir: Boolean)

/** Storage Access Framework: folders the user explicitly granted. Nothing outside them is reachable. */
object Saf {
    /** Keeps the grant across restarts. Read+write if Android allows it, otherwise read-only (still useful for browsing). */
    fun persist(ctx: Context, tree: Uri): Boolean = try {
        ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION); true
    } catch (e: Exception) {
        try { ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION); true } catch (x: Exception) { false }
    }

    /** What Android really keeps for this folder right now (a stored URI string is NOT proof of access). */
    fun grantLevel(ctx: Context, tree: Uri): GrantLevel = try {
        val g = ctx.contentResolver.persistedUriPermissions.firstOrNull { it.uri == tree }
        when {
            g == null || !g.isReadPermission -> GrantLevel.NONE
            g.isWritePermission -> GrantLevel.READ_WRITE
            else -> GrantLevel.READ
        }
    } catch (e: Exception) { GrantLevel.NONE }

    fun hasGrant(ctx: Context, tree: Uri, write: Boolean = false): Boolean =
        grantLevel(ctx, tree).let { if (write) it == GrantLevel.READ_WRITE else it != GrantLevel.NONE }

    /** null = Android refused or the folder is unreadable (NOT an empty folder). */
    fun listChecked(ctx: Context, tree: Uri, docId: String): List<DocEntry>? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        return try {
            val c = ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null) ?: return null
            val out = ArrayList<DocEntry>()
            c.use { while (it.moveToNext()) {
                val id = it.getString(0); val mime = it.getString(2) ?: ""
                out.add(DocEntry(it.getString(1) ?: id, id, DocumentsContract.buildDocumentUriUsingTree(tree, id), mime, if (it.isNull(3)) 0 else it.getLong(3), mime == DocumentsContract.Document.MIME_TYPE_DIR))
            } }
            out.sortedWith(compareByDescending<DocEntry> { it.isDir }.thenBy { it.name.lowercase() })
        } catch (e: Exception) { null }
    }

    private fun exists(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } == true
    } catch (x: Exception) { false }

    private fun displayName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (x: Exception) { null }

    /** Renames a file inside a shared folder and checks the new name really exists. */
    fun rename(ctx: Context, e: DocEntry, newName: String): String {
        com.nova.ai.files.NameRules.validate(newName)?.let { return it }
        val n = newName.trim()
        if (n == e.name) return "Same name; nothing to change."
        return try {
            val r = DocumentsContract.renameDocument(ctx.contentResolver, e.uri, n)
            if (r != null && displayName(ctx, r) == n) "Renamed ${e.name} to $n (verified)." else "Android didn't let me rename ${e.name}."
        } catch (x: Exception) { "I couldn't rename ${e.name}: ${x.message}" }
    }

    /**
     * Moves a file into another folder you shared. Same-folder-tree moves use Android's move; otherwise copy, verify, then remove the
     * original. If the copy does not verify the original is NOT touched. Caller has already told the user the original is removed.
     */
    fun move(ctx: Context, e: DocEntry, srcTree: Uri, srcParentDocId: String, dstTree: Uri, dstDocId: String): String {
        val srcParent = DocumentsContract.buildDocumentUriUsingTree(srcTree, srcParentDocId)
        val dstParent = DocumentsContract.buildDocumentUriUsingTree(dstTree, dstDocId)
        if (srcParent == dstParent) return "${e.name} is already in that folder."
        if (Build.VERSION.SDK_INT >= 24 && srcTree == dstTree) {
            val moved = try { DocumentsContract.moveDocument(ctx.contentResolver, e.uri, srcParent, dstParent) } catch (x: Exception) { null }
            if (moved != null && exists(ctx, moved) && !exists(ctx, e.uri)) return "Moved ${e.name} (verified)."
        }
        val copied = copyInto(ctx, e, dstTree, dstDocId)
        if (!copied.contains("verified")) return "Move stopped: $copied The original was not touched."
        return if (delete(ctx, e).contains("verified")) "Moved ${e.name} (verified)." else "Copied ${e.name}, but couldn't remove the original."
    }

    fun rootDocId(tree: Uri): String = DocumentsContract.getTreeDocumentId(tree)

    fun list(ctx: Context, tree: Uri, docId: String): List<DocEntry> {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = ArrayList<DocEntry>()
        try {
            ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0); val mime = c.getString(2) ?: ""
                    out.add(DocEntry(c.getString(1) ?: id, id, DocumentsContract.buildDocumentUriUsingTree(tree, id), mime, if (c.isNull(3)) 0 else c.getLong(3), mime == DocumentsContract.Document.MIME_TYPE_DIR))
                }
            }
        } catch (e: Exception) { }
        return out.sortedWith(compareByDescending<DocEntry> { it.isDir }.thenBy { it.name.lowercase() })
    }

    fun open(ctx: Context, e: DocEntry): String = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(e.uri, e.mime.ifBlank { "*/*" }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)); "Opening ${e.name}."
    } catch (x: Exception) { "No app can open ${e.name}." }

    /** Deletes and then checks it is really gone. Caller must have asked the user first. */
    fun delete(ctx: Context, e: DocEntry): String = try {
        val ok = DocumentsContract.deleteDocument(ctx.contentResolver, e.uri)
        val still = try { ctx.contentResolver.query(e.uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } == true } catch (x: Exception) { false }
        if (ok && !still) "Deleted ${e.name} (verified)." else "I couldn't delete ${e.name}."
    } catch (x: Exception) { "I couldn't delete ${e.name}: ${x.message}" }

    fun createFolder(ctx: Context, tree: Uri, parentDocId: String, name: String): String {
        if (name.isBlank() || name.contains('/') || name.contains("..")) return "That folder name isn't allowed."
        return try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentDocId)
            val r = DocumentsContract.createDocument(ctx.contentResolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, name.trim())
            if (r != null) "Created folder ${name.trim()}." else "Couldn't create the folder."
        } catch (x: Exception) { "Couldn't create the folder: ${x.message}" }
    }

    /** Copies a file into another granted folder; verifies the byte count and removes a copy that doesn't match. */
    fun copyInto(ctx: Context, src: DocEntry, tree: Uri, destDocId: String): String {
        var dest: Uri? = null
        return try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, destDocId)
            val out = DocumentsContract.createDocument(ctx.contentResolver, parent, src.mime.ifBlank { "application/octet-stream" }, src.name) ?: throw IllegalStateException("can't create the file")
            dest = out
            val n = ctx.contentResolver.openInputStream(src.uri)!!.use { i -> ctx.contentResolver.openOutputStream(out)!!.use { o -> i.copyTo(o) } }
            if (src.size == 0L || n == src.size) "Copied ${src.name} ($n bytes, verified)."
            else { try { DocumentsContract.deleteDocument(ctx.contentResolver, out) } catch (x: Exception) { }; "The copy of ${src.name} didn't match the original ($n vs ${src.size} bytes), so I removed it." }
        } catch (x: Exception) {
            dest?.let { try { DocumentsContract.deleteDocument(ctx.contentResolver, it) } catch (y: Exception) { } }
            "Copy failed: ${x.message}"
        }
    }
}

enum class GrantLevel { NONE, READ, READ_WRITE }

/**
 * Optional MANAGE_EXTERNAL_STORAGE ("All files access"). Google Play only allows it for a few app categories, so it is offered ONLY in the
 * direct (non-Play) build, only on Android 11+, and only if the user turns it on in Android's own settings page. Everything works without it.
 */
object AllFiles {
    fun available(): Boolean = Build.VERSION.SDK_INT >= 30 && !BuildConfig.PLAY_BUILD
    fun granted(): Boolean = Build.VERSION.SDK_INT >= 30 && try { Environment.isExternalStorageManager() } catch (e: Exception) { false }

    fun openSettings(ctx: Context): String {
        if (!available()) return if (BuildConfig.PLAY_BUILD) "All files access isn't offered in the Play Store build." else "All files access needs Android 11 or newer."
        return try {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Turn on “Allow access to manage all files” for Nova AI, then come back."
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Find Nova AI in the list and allow it." } catch (x: Exception) { "I couldn't open that settings page." }
        }
    }

    /** Lists a normal directory. Only works when granted; otherwise returns null and callers say why. */
    fun list(path: String): List<File>? {
        if (!granted()) return null
        val f = File(path).canonicalFile
        val root = Environment.getExternalStorageDirectory().canonicalFile
        if (!f.path.startsWith(root.path)) return null          // never browse outside shared storage
        return f.listFiles()?.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    fun delete(path: String): String {
        if (!granted()) return "All files access isn't granted."
        val f = File(path).canonicalFile
        if (!f.path.startsWith(Environment.getExternalStorageDirectory().canonicalFile.path + "/")) return "That path is outside shared storage."
        if (f.isDirectory) return "I only delete single files, not folders."
        val ok = f.delete()
        return if (ok && !f.exists()) "Deleted ${f.name} (verified)." else "I couldn't delete ${f.name}."
    }
}
