package com.nova.ai.people

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

/** The only place that talks to Room. Everything is stored in this app's private database file. */
class PersonRepository(private val db: PeopleDatabase) {
    private val dao = db.dao()

    fun observe(): Flow<List<PersonWithData>> = dao.observeAll()
    suspend fun all(): List<PersonWithData> = dao.all()

    suspend fun createPerson(p: PersonEntity, aliases: List<String>, relation: PersonMemoryEntity?): Long = db.withTransaction {
        val id = dao.insertPerson(p)
        aliases.map { normName(it) }.filter { it.isNotBlank() }.distinct().forEach { dao.insertAlias(AliasEntity(personId = id, alias = it)) }
        if (relation != null) dao.insertMemory(relation.copy(personId = id))
        id
    }

    suspend fun update(p: PersonEntity) = dao.updatePerson(p)
    suspend fun addAlias(id: Long, alias: String) { val a = normName(alias); if (a.isNotBlank()) dao.insertAlias(AliasEntity(personId = id, alias = a)) }
    suspend fun addMemory(m: PersonMemoryEntity) = dao.insertMemory(m)
    suspend fun updateMemory(m: PersonMemoryEntity) = dao.updateMemory(m)
    suspend fun deleteMemory(id: Long) = dao.deleteMemory(id)
    suspend fun deleteMemoriesFor(id: Long) = dao.deleteMemoriesFor(id)
    suspend fun deletePerson(id: Long) = dao.deletePerson(id)
    suspend fun purgeExpired(now: Long) = dao.purgeExpired(now)
    suspend fun isBlocked(hash: String) = dao.blockedCount(hash) > 0
    suspend fun block(hash: String, label: String) = dao.block(BlockedEntity(hash, label))

    suspend fun deleteEverything() = db.withTransaction { dao.deleteAllPersons(); dao.clearBlocked() }

    /** Merges [removeId] into [keepId] without losing aliases or memories. */
    suspend fun merge(keepId: Long, removeId: Long) = db.withTransaction {
        val all = dao.all()
        val keep = all.firstOrNull { it.person.personId == keepId } ?: return@withTransaction
        val rem = all.firstOrNull { it.person.personId == removeId } ?: return@withTransaction
        dao.moveMemories(removeId, keepId)
        dao.moveAliases(removeId, keepId)
        dao.insertAlias(AliasEntity(personId = keepId, alias = normName(rem.person.name)))
        if (rem.person.nickname.isNotBlank()) dao.insertAlias(AliasEntity(personId = keepId, alias = normName(rem.person.nickname)))
        dao.updatePerson(keep.person.copy(
            lastInteraction = maxOf(keep.person.lastInteraction, rem.person.lastInteraction),
            notes = listOf(keep.person.notes, rem.person.notes).filter { it.isNotBlank() }.joinToString("\n"),
            lastContext = keep.person.lastContext.ifBlank { rem.person.lastContext }
        ))
        dao.deletePerson(removeId)
    }
}
