package com.nova.ai.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nova.ai.voice.NovaVoiceForegroundService
import com.nova.ai.voice.VoicePermissionManager
import com.nova.ai.voice.VoiceState

fun startMic(ctx: Context) {
    try { NovaVoiceForegroundService.start(ctx) } catch (e: Exception) { VoiceState.detail.value = "Android did not allow Background Voice to start: ${e.message}" }
}

fun stopMic(ctx: Context) {
    try { NovaVoiceForegroundService.stop(ctx) } catch (e: Exception) { }
}

fun pauseMic(ctx: Context) {
    try { NovaVoiceForegroundService.pause(ctx) } catch (e: Exception) { }
}

fun resumeMic(ctx: Context) {
    try { NovaVoiceForegroundService.resume(ctx) } catch (e: Exception) { }
}

fun openAppSettings(ctx: Context) {
    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun openSystem(ctx: Context, action: String) {
    try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

/** Bumps whenever the app returns to the foreground, so status read from the system can refresh. */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

/**
 * Mic button. Tapping it starts the Background Voice foreground service (microphone type + visible notification), so the
 * microphone keeps running after the screen is left, instead of the old one-shot recognizer that stopped after 4-5 s.
 * Asks for Microphone (and Notification) permission first. With [toggle] = true a second tap pauses/stops it again.
 */
@Composable
fun rememberMicAction(vm: NovaViewModel, toggle: Boolean = true): () -> Unit {
    val ctx = LocalContext.current
    val running by VoiceState.running.collectAsState()
    val paused by VoiceState.paused.collectAsState()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        val missing = VoicePermissionManager.missingExplanation(ctx)
        if (missing == null) startMic(ctx)
        else { VoiceState.detail.value = missing; Toast.makeText(ctx, missing, Toast.LENGTH_LONG).show(); vm.note(missing) }
    }
    return {
        when {
            !VoicePermissionManager.canStart(ctx) -> launcher.launch(VoicePermissionManager.runtimePermissions())
            !running -> startMic(ctx)
            paused -> resumeMic(ctx)
            toggle -> stopMic(ctx)
        }
    }
}

/**
 * Returns (isListening, setListening). Turning it on asks for the microphone (and notification) permission first and only
 * starts the service when both are granted; otherwise it explains what is missing and does not touch the microphone.
 */
@Composable
fun rememberListenToggle(): Pair<Boolean, (Boolean) -> Unit> {
    val ctx = LocalContext.current
    val on by VoiceState.running.collectAsState()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        val missing = VoicePermissionManager.missingExplanation(ctx)
        if (missing == null) startMic(ctx)
        else { VoiceState.detail.value = missing; Toast.makeText(ctx, missing, Toast.LENGTH_LONG).show() }
    }
    return on to { want ->
        if (!want) stopMic(ctx)
        else if (VoicePermissionManager.canStart(ctx)) startMic(ctx)
        else launcher.launch(VoicePermissionManager.runtimePermissions())
    }
}

/** Opens the phone maker's auto-start page when we know it. Android doesn't report auto-start status to apps. */
fun openAutoStart(ctx: Context): Boolean {
    val targets = when (Build.MANUFACTURER.lowercase()) {
        "xiaomi", "redmi", "poco" -> listOf("com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity")
        "oppo", "realme" -> listOf("com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity")
        "vivo" -> listOf("com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")
        "huawei", "honor" -> listOf("com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
        "samsung" -> listOf("com.samsung.android.lool" to "com.samsung.android.sm.battery.ui.BatteryActivity")
        "oneplus" -> listOf("com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")
        else -> emptyList()
    }
    for ((pkg, cls) in targets) {
        try { ctx.startActivity(Intent().setComponent(ComponentName(pkg, cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true } catch (e: Exception) { }
    }
    return false
}
