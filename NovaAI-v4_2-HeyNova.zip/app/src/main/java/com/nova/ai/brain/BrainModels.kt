package com.nova.ai.brain

/** The 17 memory categories of the NOVA memory engine. */
enum class BrainCategory(val label: String) {
    PERSONAL("Personal Information"),
    PREFERENCE("User Preferences"),
    LIKE_DISLIKE("Likes and Dislikes"),
    PROJECT("Work and Projects"),
    IMPORTANT_CONVERSATION("Important Conversations"),
    INSTRUCTION("Previous Instructions"),
    TASK("Ongoing Tasks"),
    FUTURE_PLAN("Future Plans"),
    LEARNING("Learning Progress"),
    FREQUENT_COMMAND("Frequently Used Commands"),
    DECISION("Important Decisions"),
    CUSTOM("Custom User Information"),
    DATE_EVENT("Important Dates and Events"),
    REMINDER("User-defined Reminders"),
    PROJECT_FILE("Project Files and References"),
    TOPIC("Conversation Topics"),
    NOTE("Personal Notes");

    companion object {
        fun parse(s: String?): BrainCategory = values().firstOrNull { it.name == s } ?: CUSTOM
    }
}

object Status {
    const val NONE = ""
    const val ONGOING = "ONGOING"
    const val PENDING = "PENDING"
    const val POSTPONED = "POSTPONED"
    const val DONE = "DONE"
    fun open(s: String) = s == PENDING || s == POSTPONED || s == ONGOING
}

data class BrainItem(
    val id: Long = 0,
    val category: BrainCategory,
    val title: String,
    val content: String,
    val project: String = "",
    val topicId: Long = 0,
    val status: String = Status.NONE,
    val dueAt: Long = 0,
    val importance: Float = 0.6f,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val lastUsedAt: Long = 0,
    val source: String = "chat",
    val pinned: Boolean = false,
    val hash: String = "",
    val version: Int = 1
)

data class Turn(
    val id: Long = 0, val convId: String = "main", val topicId: Long = 0,
    val fromUser: Boolean, val text: String, val ts: Long, val lang: String = ""
)

data class TopicRec(
    val id: Long = 0,
    val title: String,
    val keywords: String = "",          // space separated, most recent last
    val summary: String = "",           // newline separated user points
    val lastStep: String = "",
    val nextStep: String = "",
    val unanswered: String = "",        // newline separated questions Nova asked and the user has not answered
    val instructions: String = "",      // newline separated
    val project: String = "",
    val status: String = "ACTIVE",      // ACTIVE | PAUSED | DONE
    val createdAt: Long = 0,
    val updatedAt: Long = 0
)

data class ProjectRec(
    val id: Long = 0, val name: String, val status: String = Status.ONGOING, val description: String = "",
    val version: String = "", val rootUri: String = "", val updatedAt: Long = 0, val lastIndexedAt: Long = 0
)

data class FileRec(
    val id: Long = 0, val projectId: Long, val uri: String, val name: String, val relPath: String,
    val mime: String = "", val size: Long = 0, val modified: Long = 0, val indexedAt: Long = 0,
    val tokens: String = "", val stale: Boolean = false
)

data class ReminderRec(
    val id: Long = 0, val itemId: Long = 0, val title: String, val fireAt: Long,
    val repeatMs: Long = 0, val enabled: Boolean = true, val lastFired: Long = 0
)

enum class VaultKind(val label: String) {
    NOTE("Personal note"), DOCUMENT("Important document"), RECORD("Secure record"),
    CREDENTIAL_REF("Project credential"), ACCOUNT_REF("Account information"), FILE_REF("Secure file reference")
}

/** Encrypted vault row. [cipher] holds IV + ciphertext; the label is the only plain text and must never contain a secret. */
class VaultRec(val id: Long = 0, val label: String, val kind: VaultKind, val cipher: ByteArray, val createdAt: Long, val updatedAt: Long)

enum class Sensitivity { NONE, ASK, BLOCK }

data class Candidate(
    val category: BrainCategory, val title: String, val content: String,
    val project: String = "", val status: String = Status.NONE, val dueAt: Long = 0,
    val importance: Float = 0.6f, val sensitivity: Sensitivity = Sensitivity.NONE,
    val explicit: Boolean = false, val reason: String = ""
)

enum class Directive { NONE, REMEMBER, DONT_SAVE }

/** The storage contract. [SqlBrainStore] is the real one; tests use an in-memory copy. */
interface BrainStore {
    fun saveItem(item: BrainItem): Long
    fun item(id: Long): BrainItem?
    fun items(): List<BrainItem>
    fun deleteItem(id: Long): Boolean
    fun deleteCategory(cat: BrainCategory): Int
    fun deleteAllItems(): Int
    fun versions(itemId: Long): List<Pair<Int, String>>
    fun touch(ids: Collection<Long>, now: Long)

    fun addTurn(t: Turn): Long
    fun turns(limit: Int, topicId: Long = 0): List<Turn>
    fun clearTurns()

    fun saveTopic(t: TopicRec): Long
    fun topic(id: Long): TopicRec?
    fun topics(): List<TopicRec>
    fun deleteTopic(id: Long)

    fun getState(key: String): String?
    fun putState(key: String, value: String)
    fun statePrefix(prefix: String): Map<String, String>

    fun saveProject(p: ProjectRec): Long
    fun projects(): List<ProjectRec>
    fun deleteProject(id: Long)
    fun replaceFiles(projectId: Long, files: List<FileRec>)
    fun files(projectId: Long = 0): List<FileRec>

    fun saveReminder(r: ReminderRec): Long
    fun reminders(): List<ReminderRec>
    fun deleteReminder(id: Long)

    fun saveVault(v: VaultRec): Long
    fun vault(): List<VaultRec>
    fun deleteVault(id: Long)

    fun integrityOk(): Boolean
    fun sizeBytes(): Long
    fun wipeAll()
    fun <T> tx(block: () -> T): T
}
