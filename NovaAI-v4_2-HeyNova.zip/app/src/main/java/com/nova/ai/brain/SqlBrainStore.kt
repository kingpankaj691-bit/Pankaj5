package com.nova.ai.brain

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

/**
 * The permanent local memory database (nova_brain.db, framework SQLite, never leaves the phone).
 * Versioned migrations, WAL journal, transactions around every multi-row write, quick integrity check.
 * It is separate from the older nova.db, which is left untouched.
 */
class SqlBrainStore(private val ctx: Context, name: String = DB_NAME) : SQLiteOpenHelper(ctx.applicationContext, name, null, MIGRATIONS.size), BrainStore {

    companion object {
        const val DB_NAME = "nova_brain.db"
        private const val MAX_TURNS = 3000

        /** Migration i upgrades the schema to version i+1. Never edit an old step; add a new one at the end. */
        val MIGRATIONS: List<List<String>> = listOf(
            listOf(
                "CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, title TEXT, content TEXT NOT NULL, project TEXT DEFAULT '', topic_id INTEGER DEFAULT 0, status TEXT DEFAULT '', due_at INTEGER DEFAULT 0, importance REAL DEFAULT 0.6, created INTEGER, updated INTEGER, last_used INTEGER, source TEXT, pinned INTEGER DEFAULT 0, hash TEXT, version INTEGER DEFAULT 1)",
                "CREATE INDEX idx_items_cat ON items(category)",
                "CREATE INDEX idx_items_hash ON items(hash)",
                "CREATE TABLE turns(id INTEGER PRIMARY KEY AUTOINCREMENT, conv TEXT, topic_id INTEGER DEFAULT 0, from_user INTEGER, text TEXT, ts INTEGER, lang TEXT)",
                "CREATE INDEX idx_turns_topic ON turns(topic_id)",
                "CREATE TABLE topics(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, keywords TEXT, summary TEXT, last_step TEXT, next_step TEXT, unanswered TEXT, instructions TEXT, project TEXT, status TEXT, created INTEGER, updated INTEGER)",
                "CREATE TABLE state(k TEXT PRIMARY KEY, v TEXT)",
                "CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, status TEXT, description TEXT, version TEXT, root_uri TEXT, updated INTEGER, indexed INTEGER)",
                "CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, uri TEXT, name TEXT, rel_path TEXT, mime TEXT, size INTEGER, modified INTEGER, indexed INTEGER, tokens TEXT, stale INTEGER DEFAULT 0)",
                "CREATE INDEX idx_files_proj ON files(project_id)",
                "CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER DEFAULT 0, title TEXT, fire_at INTEGER, repeat_ms INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1, last_fired INTEGER DEFAULT 0)",
                "CREATE TABLE vault(id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT, kind TEXT, cipher BLOB, created INTEGER, updated INTEGER)"
            ),
            listOf(   // v2: memory versioning
                "CREATE TABLE item_versions(item_id INTEGER, version INTEGER, title TEXT, content TEXT, ts INTEGER)",
                "CREATE INDEX idx_item_versions ON item_versions(item_id)"
            )
        )
    }

    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.enableWriteAheadLogging() }
    override fun onCreate(db: SQLiteDatabase) { for (m in MIGRATIONS) for (sql in m) db.execSQL(sql) }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        for (i in oldVersion until newVersion) for (sql in MIGRATIONS[i]) db.execSQL(sql)
    }
    /** Installing an older build must never wipe the memory. */
    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    override fun <T> tx(block: () -> T): T {
        val db = writableDatabase
        db.beginTransaction()
        try { val r = block(); db.setTransactionSuccessful(); return r } finally { db.endTransaction() }
    }

    // ───────── items ─────────
    private val ITEM = "id,category,title,content,project,topic_id,status,due_at,importance,created,updated,last_used,source,pinned,hash,version"
    private fun item(c: Cursor) = BrainItem(c.getLong(0), BrainCategory.parse(c.getString(1)), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5),
        c.getString(6) ?: "", c.getLong(7), c.getFloat(8), c.getLong(9), c.getLong(10), c.getLong(11), c.getString(12) ?: "chat", c.getInt(13) == 1, c.getString(14) ?: "", c.getInt(15))

    private fun values(i: BrainItem, version: Int) = ContentValues().apply {
        put("category", i.category.name); put("title", i.title); put("content", i.content); put("project", i.project); put("topic_id", i.topicId)
        put("status", i.status); put("due_at", i.dueAt); put("importance", i.importance); put("created", i.createdAt); put("updated", i.updatedAt)
        put("last_used", i.lastUsedAt); put("source", i.source); put("pinned", if (i.pinned) 1 else 0); put("hash", i.hash); put("version", version)
    }

    override fun saveItem(item: BrainItem): Long = tx {
        val rec = item
        val db = writableDatabase
        if (rec.id == 0L) db.insertOrThrow("items", null, values(rec, 1))
        else {
            val old = item(rec.id)
            val ver = if (old != null && old.content != rec.content) {
                db.insert("item_versions", null, ContentValues().apply { put("item_id", old.id); put("version", old.version); put("title", old.title); put("content", old.content); put("ts", System.currentTimeMillis()) })
                old.version + 1
            } else old?.version ?: rec.version
            db.update("items", values(rec, ver), "id=?", arrayOf(rec.id.toString()))
            rec.id
        }
    }

    override fun item(id: Long): BrainItem? = readableDatabase.rawQuery("SELECT $ITEM FROM items WHERE id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) item(it) else null }

    override fun items(): List<BrainItem> {
        val out = ArrayList<BrainItem>()
        readableDatabase.rawQuery("SELECT $ITEM FROM items ORDER BY pinned DESC, updated DESC", null).use { c -> while (c.moveToNext()) try { out.add(item(c)) } catch (e: Exception) { } }
        return out
    }

    override fun deleteItem(id: Long): Boolean = tx {
        writableDatabase.delete("item_versions", "item_id=?", arrayOf(id.toString()))
        writableDatabase.delete("reminders", "item_id=?", arrayOf(id.toString()))
        writableDatabase.delete("items", "id=?", arrayOf(id.toString())) > 0
    }
    override fun deleteCategory(cat: BrainCategory): Int = tx {
        writableDatabase.execSQL("DELETE FROM item_versions WHERE item_id IN (SELECT id FROM items WHERE category=?)", arrayOf(cat.name))
        writableDatabase.execSQL("DELETE FROM reminders WHERE item_id IN (SELECT id FROM items WHERE category=?)", arrayOf(cat.name))
        writableDatabase.delete("items", "category=?", arrayOf(cat.name))
    }
    override fun deleteAllItems(): Int = tx {
        writableDatabase.delete("item_versions", null, null); writableDatabase.delete("reminders", null, null); writableDatabase.delete("items", null, null)
    }
    override fun versions(itemId: Long): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        readableDatabase.rawQuery("SELECT version,content FROM item_versions WHERE item_id=? ORDER BY version DESC", arrayOf(itemId.toString())).use { while (it.moveToNext()) out.add(it.getInt(0) to it.getString(1)) }
        return out
    }
    override fun touch(ids: Collection<Long>, now: Long) {
        if (ids.isEmpty()) return
        tx { ids.forEach { writableDatabase.update("items", ContentValues().apply { put("last_used", now) }, "id=?", arrayOf(it.toString())) } }
    }

    // ───────── turns ─────────
    override fun addTurn(t: Turn): Long {
        val id = writableDatabase.insert("turns", null, ContentValues().apply {
            put("conv", t.convId); put("topic_id", t.topicId); put("from_user", if (t.fromUser) 1 else 0); put("text", t.text); put("ts", t.ts); put("lang", t.lang)
        })
        if (id % 100L == 0L) writableDatabase.execSQL("DELETE FROM turns WHERE id <= ?", arrayOf(id - MAX_TURNS))
        return id
    }
    override fun turns(limit: Int, topicId: Long): List<Turn> {
        val out = ArrayList<Turn>()
        val sql = "SELECT id,conv,topic_id,from_user,text,ts,lang FROM turns" + (if (topicId != 0L) " WHERE topic_id=$topicId" else "") + " ORDER BY id DESC LIMIT $limit"
        readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out.add(Turn(c.getLong(0), c.getString(1) ?: "main", c.getLong(2), c.getInt(3) == 1, c.getString(4) ?: "", c.getLong(5), c.getString(6) ?: "")) }
        return out.reversed()
    }
    override fun clearTurns() { writableDatabase.delete("turns", null, null) }

    // ───────── topics ─────────
    private val TOPIC = "id,title,keywords,summary,last_step,next_step,unanswered,instructions,project,status,created,updated"
    private fun topic(c: Cursor) = TopicRec(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
        c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "", c.getString(9) ?: "ACTIVE", c.getLong(10), c.getLong(11))
    override fun saveTopic(t: TopicRec): Long {
        val v = ContentValues().apply {
            put("title", t.title); put("keywords", t.keywords); put("summary", t.summary); put("last_step", t.lastStep); put("next_step", t.nextStep)
            put("unanswered", t.unanswered); put("instructions", t.instructions); put("project", t.project); put("status", t.status); put("created", t.createdAt); put("updated", t.updatedAt)
        }
        return if (t.id == 0L) writableDatabase.insertOrThrow("topics", null, v) else { writableDatabase.update("topics", v, "id=?", arrayOf(t.id.toString())); t.id }
    }
    override fun topic(id: Long): TopicRec? = readableDatabase.rawQuery("SELECT $TOPIC FROM topics WHERE id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) topic(it) else null }
    override fun topics(): List<TopicRec> {
        val out = ArrayList<TopicRec>()
        readableDatabase.rawQuery("SELECT $TOPIC FROM topics ORDER BY updated DESC", null).use { while (it.moveToNext()) out.add(topic(it)) }
        return out
    }
    override fun deleteTopic(id: Long) { writableDatabase.delete("topics", "id=?", arrayOf(id.toString())) }

    // ───────── state ─────────
    override fun getState(key: String): String? = readableDatabase.rawQuery("SELECT v FROM state WHERE k=?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else null }
    override fun putState(key: String, value: String) {
        writableDatabase.insertWithOnConflict("state", null, ContentValues().apply { put("k", key); put("v", value) }, SQLiteDatabase.CONFLICT_REPLACE)
    }
    override fun statePrefix(prefix: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        readableDatabase.rawQuery("SELECT k,v FROM state WHERE k>=? AND k<? ORDER BY k", arrayOf(prefix, prefix + "\uffff")).use { while (it.moveToNext()) out[it.getString(0)] = it.getString(1) ?: "" }
        return out
    }

    // ───────── projects and files ─────────
    private fun project(c: Cursor) = ProjectRec(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: Status.ONGOING, c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "", c.getLong(6), c.getLong(7))
    override fun saveProject(p: ProjectRec): Long {
        val v = ContentValues().apply { put("name", p.name); put("status", p.status); put("description", p.description); put("version", p.version); put("root_uri", p.rootUri); put("updated", p.updatedAt); put("indexed", p.lastIndexedAt) }
        return if (p.id == 0L) writableDatabase.insertOrThrow("projects", null, v) else { writableDatabase.update("projects", v, "id=?", arrayOf(p.id.toString())); p.id }
    }
    override fun projects(): List<ProjectRec> {
        val out = ArrayList<ProjectRec>()
        readableDatabase.rawQuery("SELECT id,name,status,description,version,root_uri,updated,indexed FROM projects ORDER BY updated DESC", null).use { while (it.moveToNext()) out.add(project(it)) }
        return out
    }
    override fun deleteProject(id: Long) = tx { writableDatabase.delete("files", "project_id=?", arrayOf(id.toString())); writableDatabase.delete("projects", "id=?", arrayOf(id.toString())); Unit }

    override fun replaceFiles(projectId: Long, files: List<FileRec>) = tx {
        val db = writableDatabase
        db.delete("files", "project_id=?", arrayOf(projectId.toString()))
        for (f in files) db.insert("files", null, ContentValues().apply {
            put("project_id", projectId); put("uri", f.uri); put("name", f.name); put("rel_path", f.relPath); put("mime", f.mime); put("size", f.size)
            put("modified", f.modified); put("indexed", f.indexedAt); put("tokens", f.tokens); put("stale", if (f.stale) 1 else 0)
        })
        Unit
    }
    override fun files(projectId: Long): List<FileRec> {
        val out = ArrayList<FileRec>()
        val sql = "SELECT id,project_id,uri,name,rel_path,mime,size,modified,indexed,tokens,stale FROM files" + (if (projectId != 0L) " WHERE project_id=$projectId" else "")
        readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out.add(FileRec(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "", c.getLong(6), c.getLong(7), c.getLong(8), c.getString(9) ?: "", c.getInt(10) == 1)) }
        return out
    }

    // ───────── reminders ─────────
    override fun saveReminder(r: ReminderRec): Long {
        val v = ContentValues().apply { put("item_id", r.itemId); put("title", r.title); put("fire_at", r.fireAt); put("repeat_ms", r.repeatMs); put("enabled", if (r.enabled) 1 else 0); put("last_fired", r.lastFired) }
        return if (r.id == 0L) writableDatabase.insertOrThrow("reminders", null, v) else { writableDatabase.update("reminders", v, "id=?", arrayOf(r.id.toString())); r.id }
    }
    override fun reminders(): List<ReminderRec> {
        val out = ArrayList<ReminderRec>()
        readableDatabase.rawQuery("SELECT id,item_id,title,fire_at,repeat_ms,enabled,last_fired FROM reminders ORDER BY fire_at", null).use { while (it.moveToNext()) out.add(ReminderRec(it.getLong(0), it.getLong(1), it.getString(2) ?: "", it.getLong(3), it.getLong(4), it.getInt(5) == 1, it.getLong(6))) }
        return out
    }
    override fun deleteReminder(id: Long) { writableDatabase.delete("reminders", "id=?", arrayOf(id.toString())) }

    // ───────── vault (ciphertext only) ─────────
    override fun saveVault(v: VaultRec): Long {
        val cv = ContentValues().apply { put("label", v.label); put("kind", v.kind.name); put("cipher", v.cipher); put("created", v.createdAt); put("updated", v.updatedAt) }
        return if (v.id == 0L) writableDatabase.insertOrThrow("vault", null, cv) else { writableDatabase.update("vault", cv, "id=?", arrayOf(v.id.toString())); v.id }
    }
    override fun vault(): List<VaultRec> {
        val out = ArrayList<VaultRec>()
        readableDatabase.rawQuery("SELECT id,label,kind,cipher,created,updated FROM vault ORDER BY updated DESC", null).use { c ->
            while (c.moveToNext()) out.add(VaultRec(c.getLong(0), c.getString(1) ?: "", try { VaultKind.valueOf(c.getString(2)) } catch (e: Exception) { VaultKind.RECORD }, c.getBlob(3) ?: ByteArray(0), c.getLong(4), c.getLong(5)))
        }
        return out
    }
    override fun deleteVault(id: Long) { writableDatabase.delete("vault", "id=?", arrayOf(id.toString())) }

    // ───────── maintenance ─────────
    override fun integrityOk(): Boolean = try {
        readableDatabase.rawQuery("PRAGMA quick_check(1)", null).use { it.moveToFirst() && it.getString(0).equals("ok", true) }
    } catch (e: Exception) { false }

    override fun sizeBytes(): Long {
        val base = ctx.getDatabasePath(DB_NAME)
        return listOf(base, File(base.path + "-wal"), File(base.path + "-shm")).sumOf { if (it.exists()) it.length() else 0L }
    }

    /** Deletes memories, topics, conversation log, projects, files, reminders and settings state. The secure vault is NOT touched. */
    override fun wipeAll() = tx {
        for (t in listOf("items", "item_versions", "turns", "topics", "state", "projects", "files", "reminders")) writableDatabase.delete(t, null, null)
        Unit
    }
}
