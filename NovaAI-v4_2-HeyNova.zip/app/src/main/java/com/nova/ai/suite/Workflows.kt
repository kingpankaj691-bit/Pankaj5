package com.nova.ai.suite

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MediaItem(val uri: Uri, val name: String, val folder: String, val sizeBytes: Long, val durationMs: Long, val addedSec: Long) {
    fun describe(): String {
        val s = durationMs / 1000
        val dur = "%d:%02d".format(s / 60, s % 60)
        val whenText = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(addedSec * 1000))
        return "$name\n$dur · ${sizeBytes / 1024 / 1024} MB · $whenText" + if (folder.isNotBlank()) "\n$folder" else ""
    }
}

data class Draft(val title: String, val description: String, val tags: List<String>)

/**
 * Multi-step workflows that cross apps. Every workflow: shows what it found, asks you to confirm before leaving Nova, hands data over
 * with a normal Android share intent (content URI), fills text fields through accessibility only if you enabled it, and NEVER presses
 * the final Upload/Send/Publish button: you do that. Each run is recorded in a short history. Cancel from any preview.
 */
object Workflows {
    const val YOUTUBE = "com.google.android.youtube"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    val active: Boolean get() = job?.isActive == true || ScreenAgent.active

    // ───────── media lookup ─────────
    fun hasMediaPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    fun latestVideos(ctx: Context, limit: Int = 5): List<MediaItem> {
        val cols = ArrayList(listOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED))
        val hasPath = Build.VERSION.SDK_INT >= 29
        if (hasPath) cols.add(MediaStore.MediaColumns.RELATIVE_PATH)
        val out = ArrayList<MediaItem>()
        try {
            ctx.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cols.toTypedArray(), null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val id = c.getLong(0)
                    out.add(MediaItem(Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()), c.getString(1).orEmpty(), if (hasPath) c.getString(5).orEmpty() else "", c.getLong(2), c.getLong(3), c.getLong(4)))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // ───────── drafting ─────────
    /** Parses the model's JSON answer (fences and extra words tolerated). */
    fun parseDraft(raw: String): Draft? {
        val a = raw.indexOf('{'); val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try {
            val o = JSONObject(raw.substring(a, b + 1))
            val title = o.optString("title").trim()
            if (title.isBlank()) return null
            val tags = o.optJSONArray("tags")?.let { arr -> (0 until arr.length()).map { arr.optString(it).trim().removePrefix("#") }.filter { it.isNotBlank() } }.orEmpty()
            Draft(title.take(100), o.optString("description").trim().take(4500), tags.take(15))
        } catch (e: Exception) { null }
    }

    fun fallbackDraft(item: MediaItem): Draft {
        val stem = File(item.name).nameWithoutExtension.replace('_', ' ').replace('-', ' ').trim()
        return Draft(stem.ifBlank { "My new video" }.take(100), "", emptyList())
    }

    private suspend fun draft(ctx: Context, item: MediaItem, hint: String, platform: String = "YouTube"): Pair<Draft, String> {
        val p = Prefs(ctx)
        if (!p.hasActiveKey() || !p.aiEnabled || p.localOnly) return fallbackDraft(item) to "AI is off or has no key, so the title comes from the file name. Edit it in YouTube."
        val sys = if (platform == "Instagram") "You write Instagram captions. Reply with ONLY a JSON object: {\"title\": a short hook line under 60 chars, \"description\": a 1-3 line caption, \"tags\": up to 10 hashtags without #}. " +
            "Use the language the user wrote their request in (Hindi/Hinglish/English). Base it only on the file name and the user's words; do not invent facts about the video's content."
        else "You write YouTube metadata. Reply with ONLY a JSON object: {\"title\": string under 70 chars, \"description\": 2-4 short lines, \"tags\": up to 8 strings}. " +
            "Use the language the user wrote their request in (Hindi/Hinglish/English). Base it only on the file name and the user's words; do not invent facts about the video's content."
        val r = SwitchingProvider(p).chat(listOf(true to "File name: ${item.name}\nUser request: ${hint.take(300)}"), sys, null)
        return when (r) {
            is AiResult.Ok -> (parseDraft(r.text) ?: fallbackDraft(item)) to ""
            is AiResult.Err -> fallbackDraft(item) to "⚠ ${r.msg}"
        }
    }

    // ───────── sheet helpers ─────────
    internal suspend fun ask(ctx: Context, title: String, body: String, options: List<Pair<String, Int>>): Int {
        val gate = CompletableDeferred<Int>()
        val actions = options.mapIndexed { i, (label, code) -> SheetAction(label, i == 0) { gate.complete(code) } }
        NovaSheet.show(ctx, title, body, false, actions)
        return try { gate.await() } finally { }
    }

    internal fun fail(ctx: Context, name: String, why: String) {
        NovaSheet.show(ctx, name, "✗ $why", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
        History.add(ctx, name, "failed: " + why.take(80))
    }

    private fun copy(ctx: Context, text: String) {
        try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Nova", text)) } catch (e: Exception) { }
    }

    fun cancel() { job?.cancel(); job = null; if (ScreenAgent.active) ScreenAgent.cancel() }

    // ───────── choose the right file ─────────
    /** Shows the newest video and lets you step to older ones. Returns null if cancelled or none found (a message is already shown). */
    private suspend fun chooseVideo(ctx: Context, name: String): MediaItem? {
        NovaSheet.show(ctx, name, "1/4  Finding your latest exported video…", true)
        if (!hasMediaPermission(ctx)) { fail(ctx, name, "Nova needs the Photos and videos permission. Android Settings > Apps > Nova AI > Permissions."); return null }
        val items = latestVideos(ctx, 5)
        if (items.isEmpty()) {
            val a = ask(ctx, name, "I found no videos in the media library. Pick one with the document picker?", listOf("Pick a file…" to 1, "Cancel" to 0))
            if (a == 1) { NovaSheet.hide(); val u = PickerActivity.pick(ctx, "video/*").await(); if (u != null) return PickerActivity.itemFrom(ctx, u) }
            NovaSheet.hide(); History.add(ctx, name, "cancelled"); return null
        }
        var i = 0
        while (true) {
            val it = items[i]
            val opts = ArrayList<Pair<String, Int>>().apply { add("Use this video" to 1); if (i + 1 < items.size) add("Older one" to 2); add("Pick a file…" to 3); add("Cancel" to 0) }
            when (ask(ctx, "$name — is this the right video?", it.describe(), opts)) {
                1 -> return it
                2 -> i++
                3 -> {
                    NovaSheet.hide()
                    val uri = PickerActivity.pick(ctx, "video/*").await()
                    if (uri != null) return PickerActivity.itemFrom(ctx, uri)
                    NovaSheet.show(ctx, name, "No file chosen.", false)
                }
                else -> { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return null }
            }
        }
    }

    // ───────── workflow 1: YouTube upload prep ─────────
    fun youtubePrep(ctx: Context, hint: String): String {
        val app = ctx.applicationContext
        if (!Features.enabled(app, Features.WORKFLOWS)) return Features.off("Cross-App Workflows")
        if (!NovaSheet.canShow(app)) return SystemControls.openOverlay(app)
        cancel()
        job = scope.launch { youtubeFlow(app, hint) }
        return "Workflow shuru: latest export dhoondh rahi hoon. Har step par aapse poochhungi."
    }

    private suspend fun youtubeFlow(ctx: Context, hint: String) {
        val name = "YouTube upload prep"
        val item = chooseVideo(ctx, name) ?: return
        NovaSheet.show(ctx, name, "2/4  Writing title and description…", true)
        var (d, note) = draft(ctx, item, hint)
        var autoUpload = false
        while (true) {
            val body = "Video: ${item.name}\n\nTitle:\n${d.title}\n\nDescription:\n${d.description.ifBlank { "(empty)" }}" +
                (if (d.tags.isNotEmpty()) "\n\nTags: " + d.tags.joinToString(" ") { "#$it" } else "") + (if (note.isNotBlank()) "\n\n$note" else "") +
                "\n\n\"Open & fill\" stops before Upload. \"Fill & upload\" also presses Next/Upload by itself after you choose visibility and the kids setting."
            when (ask(ctx, "$name — preview", body, listOf("Fill & upload" to 4, "Open & fill only" to 1, "Regenerate" to 2, "Copy text" to 3, "Cancel" to 0))) {
                1 -> break
                4 -> { autoUpload = true; break }
                2 -> { NovaSheet.show(ctx, name, "Writing another version…", true); val r = draft(ctx, item, "$hint (different wording)"); d = r.first; note = r.second }
                3 -> { copy(ctx, d.title + "\n\n" + d.description + if (d.tags.isNotEmpty()) "\n\n" + d.tags.joinToString(" ") { "#$it" } else ""); note = "Copied to clipboard." }
                else -> { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
            }
        }
        var visibility = ""; var kids = false
        if (autoUpload) {
            if (NovaAccessibilityService.instance == null) { fail(ctx, name, "Accessibility is off, so I can't press Upload. Turn on Nova in Accessibility or use \"Open & fill only\"."); return }
            val v = ask(ctx, "$name — visibility", "Who can see this video after upload? You choose; I won't.", listOf("Private" to 1, "Unlisted" to 2, "Public" to 3, "Cancel" to 0))
            if (v == 0) { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
            visibility = when (v) { 1 -> "Private"; 2 -> "Unlisted"; else -> "Public" }
            val k = ask(ctx, "$name — audience", "YouTube asks if the video is made for kids. This is your legal declaration, so you answer it.", listOf("No, not made for kids" to 1, "Yes, made for kids" to 2, "Cancel" to 0))
            if (k == 0) { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
            kids = k == 2
            val c = ask(ctx, "$name — final check", "Nova will now fill the title/description, set audience (${if (kids) "made for kids" else "not made for kids"}), visibility $visibility, and press Upload.\n\nVideo: ${item.name}", listOf("Go ahead" to 1, "Cancel" to 0))
            if (c == 0) { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
        }
        NovaSheet.show(ctx, name, "3/4  Opening YouTube…", true)
        copy(ctx, d.title + "\n\n" + d.description)                       // safety net: paste if a field can't be filled
        val opened = openShare(ctx, item.uri, YOUTUBE, d.title, d.description)
        if (!opened) { fail(ctx, name, "I couldn't open YouTube. The title and description are on your clipboard."); return }
        val filled = fillFields(d)
        val result = when {
            filled.first && filled.second -> "Title and description filled."
            filled.first -> "Title filled. Description: paste it (it is on your clipboard)."
            else -> "I couldn't fill the fields${if (NovaAccessibilityService.instance == null) " (Accessibility is off)" else ""}. Title and description are on your clipboard: paste them."
        }
        if (autoUpload) {
            if (!(filled.first && filled.second)) {
                NovaSheet.show(ctx, name, "4/4  $result\n\nI did not press Upload because the fields are not confirmed filled. Check, then upload yourself.", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
                History.add(ctx, name, "filled partly, not uploaded"); return
            }
            NovaSheet.hide()
            val pressed = AutoPress.youtubePublish(visibility, kids)
            NovaSheet.show(ctx, name, "4/4  $result\n$pressed", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
            History.add(ctx, name, (if (pressed.startsWith("Pressed")) "uploaded ($visibility): " else "stopped: ") + item.name.take(30))
            return
        }
        NovaSheet.show(ctx, name, "4/4  $result\n\nCheck everything, then tap Upload yourself.", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
        History.add(ctx, name, "ready: " + item.name.take(40))
    }

    // ───────── workflow 1b: Instagram upload ─────────
    const val INSTAGRAM = "com.instagram.android"

    fun instagramPrep(ctx: Context, hint: String): String {
        val app = ctx.applicationContext
        if (!Features.enabled(app, Features.WORKFLOWS)) return Features.off("Cross-App Workflows")
        if (!NovaSheet.canShow(app)) return SystemControls.openOverlay(app)
        cancel()
        job = scope.launch { instagramFlow(app, hint) }
        return "Instagram workflow shuru: latest video dhoondh rahi hoon. Har step par poochhungi."
    }

    private suspend fun instagramFlow(ctx: Context, hint: String) {
        val name = "Instagram upload"
        val item = chooseVideo(ctx, name) ?: return
        val k = ask(ctx, "$name — type", "Post this as a Reel or a normal feed Post?", listOf("Reel" to 1, "Post" to 2, "Cancel" to 0))
        if (k == 0) { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
        val kind = if (k == 1) "Reels" else "Feed"
        NovaSheet.show(ctx, name, "Writing a caption…", true)
        var (d, note) = draft(ctx, item, hint, "Instagram")
        var press = false
        fun captionOf(x: Draft) = (x.description.ifBlank { x.title } + if (x.tags.isNotEmpty()) "\n\n" + x.tags.joinToString(" ") { "#$it" } else "").take(2200)
        while (true) {
            val body = "Video: ${item.name}\nType: $kind\n\nCaption:\n${captionOf(d)}" + (if (note.isNotBlank()) "\n\n$note" else "") +
                "\n\n\"Open & fill\" stops before Share. \"Fill & share\" presses Next/Share by itself. (Instagram may limit accounts that act like bots; Nova does one run only when you approve it.)"
            when (ask(ctx, "$name — preview", body, listOf("Fill & share" to 4, "Open & fill only" to 1, "Regenerate" to 2, "Copy text" to 3, "Cancel" to 0))) {
                1 -> break
                4 -> { press = true; break }
                2 -> { NovaSheet.show(ctx, name, "Writing another version…", true); val r = draft(ctx, item, "$hint (different wording)", "Instagram"); d = r.first; note = r.second }
                3 -> { copy(ctx, captionOf(d)); note = "Copied to clipboard." }
                else -> { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
            }
        }
        if (NovaAccessibilityService.instance == null) {
            copy(ctx, captionOf(d)); openShare(ctx, item.uri, INSTAGRAM, "", captionOf(d))
            NovaSheet.show(ctx, name, "Accessibility is off, so I opened Instagram only. The caption is on your clipboard.", false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
            History.add(ctx, name, "opened only"); return
        }
        if (press) {
            val c = ask(ctx, "$name — final check", "Nova will open Instagram, add the caption and press Share for a $kind.\n\nVideo: ${item.name}", listOf("Go ahead" to 1, "Cancel" to 0))
            if (c == 0) { NovaSheet.hide(); History.add(ctx, name, "cancelled"); return }
        }
        NovaSheet.hide()
        copy(ctx, captionOf(d))
        if (!openShare(ctx, item.uri, INSTAGRAM, "", captionOf(d))) { fail(ctx, name, "I couldn't open Instagram. The caption is on your clipboard."); return }
        delay(2000)
        val msg = AutoPress.instagramPublish(kind, captionOf(d), press)
        NovaSheet.show(ctx, name, msg, false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
        History.add(ctx, name, (if (msg.contains("pressed Share")) "shared ($kind): " else "ready: ") + item.name.take(30))
    }

    // ───────── workflow 2: share latest video to any app ─────────
    fun shareLatest(ctx: Context, spoken: String): String {
        val app = ctx.applicationContext
        if (!Features.enabled(app, Features.WORKFLOWS)) return Features.off("Cross-App Workflows")
        if (!NovaSheet.canShow(app)) return SystemControls.openOverlay(app)
        cancel()
        job = scope.launch {
            val name = "Share latest video"
            val item = chooseVideo(app, name) ?: return@launch
            val target = shareTargets(app).firstOrNull { it.second.length >= 3 && spoken.lowercase().contains(it.second.lowercase()) }
            val label = target?.second ?: "a chooser"
            val who = AutoPress.recipientIn(spoken)
            val canSend = target != null && who != null && NovaAccessibilityService.instance != null
            val opts = ArrayList<Pair<String, Int>>().apply { if (canSend) add("Open & send to $who" to 2); add("Open only" to 1); add("Cancel" to 0) }
            val note = if (who != null && target != null && NovaAccessibilityService.instance == null) "\n\n(Accessibility is off, so I can only open the app.)" else ""
            val choice = ask(app, "$name — confirm", "${item.name}\n\nTo: ${if (target != null) label else "Android's share chooser"}" + (if (who != null) "\nRecipient: $who" else "") +
                (if (canSend) "\n\n\"Open & send\" picks the chat named $who and presses Send by itself; if the name matches more than one chat I stop." else "") + note, opts)
            when (choice) {
                1, 2 -> {
                    if (!openShare(app, item.uri, target?.first, "", "")) { fail(app, name, "I couldn't open that app."); return@launch }
                    if (choice == 2 && canSend && target != null && who != null) {
                        NovaSheet.hide()
                        delay(1500)
                        val msg = AutoPress.sendTo(target.first, who)
                        NovaSheet.show(app, name, msg, false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
                        History.add(app, name, (if (msg.startsWith("Pressed")) "sent to $who" else "stopped") + " via " + label)
                    } else { NovaSheet.hide(); History.add(app, name, "opened $label") }
                }
                else -> { NovaSheet.hide(); History.add(app, name, "cancelled") }
            }
        }
        return "Latest video dhoondh rahi hoon. Bhejne se pehle aapse poochhungi."
    }

    /** Apps that accept shared video: (package, label). */
    fun shareTargets(ctx: Context): List<Pair<String, String>> = try {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_SEND).setType("video/*"), 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinct()
    } catch (e: Exception) { emptyList() }

    /** Hands the video to another app with a normal share intent. [pkg] null = Android chooser. */
    fun openShare(ctx: Context, uri: Uri, pkg: String?, title: String, text: String): Boolean = try {
        val send = Intent(Intent.ACTION_SEND).setType("video/*").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (title.isNotBlank()) send.putExtra(Intent.EXTRA_SUBJECT, title).putExtra(Intent.EXTRA_TITLE, title)
        if (text.isNotBlank()) send.putExtra(Intent.EXTRA_TEXT, text)
        if (pkg != null) { send.setPackage(pkg); ctx.startActivity(send) }
        else ctx.startActivity(Intent.createChooser(send, "Share video").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        true
    } catch (e: Exception) { false }

    // ───────── accessibility field filling ─────────
    private val titleWords = listOf("title", "add a title", "शीर्षक", "titulo")
    private val descWords = listOf("description", "describe your video", "add a description", "विवरण", "वर्णन")

    /** Waits up to ~20 s for the upload form, then fills the Title and Description fields. Never touches buttons. Returns (titleFilled, descFilled). */
    private suspend fun fillFields(d: Draft): Pair<Boolean, Boolean> {
        val svc = NovaAccessibilityService.instance ?: return false to false
        var t = false; var de = false
        var tries = 0
        while (tries < 28 && !(t && de)) {
            delay(700); tries++
            val snap = svc.snapshot() ?: continue
            if (!snap.pkg.contains("youtube")) continue
            for (e in snap.editable) {
                if (e.password) continue
                val label = (e.hint + " " + e.desc + " " + e.text).lowercase()
                if (!t && titleWords.any { label.contains(it) }) t = svc.setTextOn(e, d.title)
                else if (!de && d.description.isNotBlank() && descWords.any { label.contains(it) }) de = svc.setTextOn(e, d.description)
            }
        }
        return t to (de || d.description.isBlank())
    }

    // ───────── task history ─────────
    object History {
        private fun file(ctx: Context) = File(ctx.filesDir, "workflow_history.json")
        fun list(ctx: Context): List<Triple<Long, String, String>> = try {
            val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
            (0 until a.length()).map { a.getJSONObject(it).let { o -> Triple(o.getLong("t"), o.getString("n"), o.getString("s")) } }
        } catch (e: Exception) { emptyList() }
        fun add(ctx: Context, name: String, status: String) {
            try {
                val cur = list(ctx).toMutableList(); cur.add(0, Triple(System.currentTimeMillis(), name, status))
                val a = JSONArray(); cur.take(30).forEach { a.put(JSONObject().put("t", it.first).put("n", it.second).put("s", it.third)) }
                file(ctx).writeText(a.toString())
            } catch (e: Exception) { }
        }
        fun clear(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }
    }
}
