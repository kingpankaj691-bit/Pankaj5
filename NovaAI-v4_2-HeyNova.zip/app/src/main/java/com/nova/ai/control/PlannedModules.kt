package com.nova.ai.control

import com.nova.ai.future.NovaModule

/**
 * Extension points for features that are NOT built yet. They are interfaces only, registered nowhere, and the UI labels each
 * one "Planned" until a real implementation is registered in [com.nova.ai.future.ModuleRegistry]. Nothing here pretends to work.
 */
interface SmartAppAutomationModule : NovaModule { suspend fun run(app: String, goal: String): String }
interface FileManagementModule : NovaModule { suspend fun organize(folder: String, rule: String): String }
interface NotificationAutomationModule : NovaModule { fun addRule(appPackage: String, keyword: String, action: String): Boolean }
interface BrowserAutomationModule : NovaModule { suspend fun perform(url: String, goal: String): String }
interface WorkflowModule : NovaModule { suspend fun runWorkflow(name: String): String }
interface CodingAssistModule : NovaModule { suspend fun assist(task: String, code: String): String }

data class PlannedModule(val id: String, val title: String, val status: String, val note: String)

object PlannedModules {
    fun all(): List<PlannedModule> {
        fun st(id: String, built: Boolean) = if (com.nova.ai.future.ModuleRegistry.has(id)) "Available" else if (built) "Partly available" else "Planned"
        return listOf(
            PlannedModule("smart_app_automation", "Smart app automation", st("smart_app_automation", true), "Screen plans (open app, search, tap, type) already exist; per-app recipes are planned."),
            PlannedModule("file_management", "File management", st("file_management", true), "File search/index exists; move/organize/delete workflows are planned and will always ask first."),
            PlannedModule("notification_automation", "Notification automation", st("notification_automation", true), "Notification summaries exist; rule-based actions are planned."),
            PlannedModule("music_control", "Music control", st("music_control", true), "Open/search YouTube works; transport keys work via Shizuku/Accessibility; a full player module is planned."),
            PlannedModule("camera_assist", "Camera assistance", st("camera_assist", true), "Camera vision exists; guided photo assistance is planned."),
            PlannedModule("document_ops", "Document operations", st("document_ops", true), "File Q&A exists; editing/export is planned."),
            PlannedModule("coding_assist", "Coding assistance", st("coding_assist", true), "Developer tools exist."),
            PlannedModule("browser_automation", "Browser automation", st("browser_automation", false), "Planned. Not implemented."),
            PlannedModule("workflows", "Multi-step workflows", st("workflows", true), "Workflows screen exists; control-engine steps as workflow actions are planned."),
            PlannedModule("smart_home", "Smart home", st("smart_home", true), "Existing SmartHome support remains; see Jarvis Pack."),
            PlannedModule("computer_control", "Computer control", st("computer_control", true), "PC companion script exists; deeper control is planned.")
        )
    }
}
