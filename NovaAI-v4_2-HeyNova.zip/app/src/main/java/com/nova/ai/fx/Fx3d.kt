package com.nova.ai.fx

import android.annotation.SuppressLint
import android.graphics.RuntimeShader
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nova.ai.live.LiveOrbState
import com.nova.ai.live.LiveSession
import com.nova.ai.ui.LocalGlass
import com.nova.ai.ui.NovaOrb
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

private const val AGSL = """
uniform float2 res; uniform float time; uniform float amp; uniform float2 tilt;
uniform half3 core; uniform half3 rim; uniform half3 halo;
float h(float2 p){ return fract(sin(dot(p, float2(127.1,311.7))) * 43758.5453); }
float n(float2 p){ float2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(h(i),h(i+float2(1,0)),f.x), mix(h(i+float2(0,1)),h(i+float2(1,1)),f.x), f.y); }
float fbm(float2 p){ float v=0.0, a=0.5; for(int i=0;i<4;i++){ v+=a*n(p); p*=2.0; a*=0.5; } return v; }
half4 main(float2 fc){
  float2 uv = (fc - 0.5*res) / (0.5*min(res.x,res.y));
  float r0 = 0.62 + amp*0.12;
  float d = length(uv);
  if (d > r0) {
    float g = exp(-(d - r0) * 5.0) * (0.55 + amp);
    return half4(halo * g, g);
  }
  float z = sqrt(max(0.0, r0*r0 - d*d)) / r0;
  float3 N = normalize(float3(uv / r0, z));
  float3 L = normalize(float3(-0.5 + tilt.x, -0.6 + tilt.y, 0.8));
  float diff = max(dot(N, L), 0.0);
  float3 Hh = normalize(L + float3(0,0,1));
  float spec = pow(max(dot(N, Hh), 0.0), 40.0);
  float fres = pow(1.0 - z, 2.6);
  float e = fbm(N.xy * 2.2 + float2(time*0.15, -time*0.1)) ;
  float3 base = mix(float3(core) * 0.55, float3(core), e) * (0.35 + 0.9*diff) * (1.0 + amp*0.8);
  float3 col = base + float3(rim) * fres * 0.9 + spec * 0.55;
  return half4(half3(col), 1.0);
}
"""

private fun palette(s: LiveOrbState): Triple<Color, Color, Color> = when (s) {
    LiveOrbState.IDLE -> Triple(Color(0xFF8B5CF6), Color(0xFFFF6FAE), Color(0xFF8B5CF6))
    LiveOrbState.LISTENING -> Triple(Color(0xFF3FE0D0), Color(0xFF9FFFF3), Color(0xFF3FE0D0))
    LiveOrbState.THINKING -> Triple(Color(0xFF7C8CFF), Color(0xFFB9A6FF), Color(0xFF7C8CFF))
    LiveOrbState.SPEAKING -> Triple(Color(0xFFFFB547), Color(0xFFFF6FAE), Color(0xFFFF8A3D))
    LiveOrbState.CONNECTING -> Triple(Color(0xFFFFB547), Color(0xFFFFD28A), Color(0xFFFFB547))
    LiveOrbState.ERROR -> Triple(Color(0xFF7A2030), Color(0xFFFF7A85), Color(0xFFFF7A85))
}

/** GPU-shaded 3D orb (AGSL, Android 13+). Falls back to the existing NovaOrb on older phones. Light follows the phone's tilt. */
@SuppressLint("NewApi")
@Composable
fun NovaOrb3D(state: LiveOrbState, size: Dp, amplitude: Float, modifier: Modifier = Modifier) {
    if (Build.VERSION.SDK_INT < 33) {
        NovaOrb(when (state) { LiveOrbState.LISTENING -> "Listening"; LiveOrbState.SPEAKING -> "Speaking"; LiveOrbState.THINKING -> "Thinking"; LiveOrbState.ERROR -> "Error"; else -> "Idle" }, modifier.size(size), level = { amplitude })
        return
    }
    val reduced = LocalGlass.current.reduced
    val ctx = LocalContext.current
    var tilt by remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(reduced) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { tilt = Offset(tilt.x * 0.9f + (e.values[0] / 9.8f) * 0.1f * 0.6f, tilt.y * 0.9f + (e.values[1] / 9.8f) * 0.1f * 0.6f) }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (!reduced && acc != null) sm.registerListener(l, acc, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm?.unregisterListener(l) }
    }
    val t = if (reduced) 0f else {
        val inf = rememberInfiniteTransition(label = "orb3d")
        val v by inf.animateFloat(0f, 1000f, infiniteRepeatable(tween(1_000_000, easing = LinearEasing), RepeatMode.Restart), label = "t")
        v
    }
    val shader = remember { RuntimeShader(AGSL) }
    val (c, r, hl) = palette(state)
    val pulse = if (state == LiveOrbState.LISTENING && !reduced) 0.04f * sin(t * 2.4f) else 0f
    Canvas(modifier.size(size).semantics { contentDescription = "Nova status: ${state.name.lowercase()}" }) {
        shader.setFloatUniform("res", this.size.width, this.size.height)
        shader.setFloatUniform("time", t * (if (state == LiveOrbState.THINKING) 2.2f else 1f))
        shader.setFloatUniform("amp", (amplitude + pulse).coerceIn(0f, 1f))
        shader.setFloatUniform("tilt", if (reduced) 0f else tilt.x, if (reduced) 0f else tilt.y)
        shader.setFloatUniform("core", c.red, c.green, c.blue)
        shader.setFloatUniform("rim", r.red, r.green, r.blue)
        shader.setFloatUniform("halo", hl.red, hl.green, hl.blue)
        drawRect(ShaderBrush(shader))
    }
}

/** Slim glowing border: violet at rest, pink while speaking, red on error. Hosting is up to the caller. */
@Composable
fun ListeningEdgeGlow(modifier: Modifier = Modifier) {
    val st by LiveSession.state.collectAsState()
    val active by LiveSession.isActive.collectAsState()
    if (!active) return
    val col = when (st) { LiveOrbState.ERROR -> Color(0xFFFF7A85); LiveOrbState.SPEAKING -> Color(0xFFFF6FAE); else -> Color(0xFF8B5CF6) }
    Canvas(modifier.fillMaxSize()) {
        val w = 26.dp.toPx()
        for (i in 0 until 4) drawRect(col.copy(alpha = (0.28f - i * 0.06f).coerceAtLeast(0.02f)), Offset(i * w / 5, i * w / 5), androidx.compose.ui.geometry.Size(size.width - 2 * i * w / 5, size.height - 2 * i * w / 5), style = Stroke(w - i * w / 5f))
    }
}

object SplashSession { @Volatile var played = false }

/** Once-per-process 3D intro: stars streak past, an orb condenses at the centre, then it dissolves (<= 2.2 s, tap to skip). */
@Composable
fun NovaSplash3D(onFinished: () -> Unit) {
    if (SplashSession.played) { LaunchedEffect(Unit) { onFinished() }; return }
    val reduced = LocalGlass.current.reduced
    var p by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val total = if (reduced) 400L else 2200L
        var t = 0L
        while (t < total) { delay(16); t += 16; p = t / total.toFloat() }
        SplashSession.played = true
        onFinished()
    }
    Box(Modifier.fillMaxSize().semantics { contentDescription = "Nova intro, tap to skip" }
        .pointerInput(Unit) { detectTapGestures { SplashSession.played = true; onFinished() } }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Color(0xFF06050E).copy(alpha = if (p > 0.85f) (1f - p) / 0.15f else 1f))
            val c = Offset(size.width / 2, size.height / 2)
            for (i in 0 until 60) {
                val a = i * 2.399f; val sp = 0.3f + (i % 7) * 0.12f
                val d = ((p * sp * 2f + (i % 5) * 0.2f) % 1f) * size.minDimension * 0.7f
                drawCircle(Color.White.copy(alpha = 0.7f * (1f - d / (size.minDimension * 0.7f))), 2f + (i % 3), Offset(c.x + cos(a) * d, c.y + sin(a) * d))
            }
            val rr = size.minDimension * 0.16f * (0.2f + 0.8f * minOf(1f, p * 1.6f))
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFB547), Color(0xFFFF6FAE), Color.Transparent), c, rr * 2.2f), rr * 2.2f, c)
            drawCircle(Color(0xFFFFB547).copy(alpha = 0.9f), rr, c)
        }
    }
}
