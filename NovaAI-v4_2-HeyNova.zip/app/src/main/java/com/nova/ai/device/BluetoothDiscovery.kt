package com.nova.ai.device

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

/** Nearby classic-Bluetooth discovery (about 12 s). Needs "Nearby devices" on Android 12+. Names only; no pairing happens. */
class BluetoothDiscovery(private val ctx: Context) {
    private fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    suspend fun scan(): String {
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter ?: return "This device has no Bluetooth."
        if (Build.VERSION.SDK_INT >= 31 && !(ok(Manifest.permission.BLUETOOTH_SCAN) && ok(Manifest.permission.BLUETOOTH_CONNECT)))
            return "I need the Nearby devices permission first. Grant it in Permissions."
        if (!ad.isEnabled) return "Bluetooth is off. Say \"turn Bluetooth on\" first."
        val found = LinkedHashMap<String, String>()
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action != BluetoothDevice.ACTION_FOUND) return
                val d: BluetoothDevice = (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)) ?: return
                val name = try { d.name } catch (e: SecurityException) { null }
                found[d.address] = name ?: "Unnamed device"
            }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(BluetoothDevice.ACTION_FOUND), ContextCompat.RECEIVER_NOT_EXPORTED)
        try {
            if (ad.isDiscovering) ad.cancelDiscovery()
            if (!ad.startDiscovery()) return "Android wouldn't start Bluetooth discovery."
            delay(12000)
            ad.cancelDiscovery()
        } catch (e: SecurityException) { return "Bluetooth scan was blocked by missing permission." }
        finally { try { ctx.unregisterReceiver(r) } catch (e: Exception) {} }
        return if (found.isEmpty()) "No nearby Bluetooth devices found."
        else "Nearby: " + found.values.distinct().take(10).joinToString(", ") + ". Open Bluetooth settings to pair."
    }
}
