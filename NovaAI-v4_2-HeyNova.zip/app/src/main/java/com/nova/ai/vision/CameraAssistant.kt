package com.nova.ai.vision

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.Executors

/**
 * Owns the camera for Nova's Camera screen. The camera is bound only between [start] and [stop], and the Camera screen calls
 * [stop] when the person leaves it, so the camera never runs in the background and never starts by itself.
 */
class CameraAssistant(private val ctx: Context) {
    val analyzer = MLKitAnalyzer()
    private val executor = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null

    /** [onState] reports (running, errorMessage). Call on the main thread, after the camera permission is granted. */
    fun start(owner: LifecycleOwner, surface: Preview.SurfaceProvider, front: Boolean, onState: (Boolean, String) -> Unit) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!p.hasCamera(selector)) { onState(false, "This phone has no ${if (front) "front" else "back"} camera."); return@addListener }
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(surface) }
                val ia = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                ia.setAnalyzer(executor, analyzer)
                p.bindToLifecycle(owner, selector, preview, ia)
                analysis = ia
                onState(true, "")
            } catch (e: Exception) {
                onState(false, "Camera couldn't start: ${e.message ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    /** Releases the camera completely. */
    fun stop() {
        try { analysis?.clearAnalyzer() } catch (e: Exception) { }
        analysis = null
        try { provider?.unbindAll() } catch (e: Exception) { }
        analyzer.gesture = null
    }

    fun shutdown() {
        stop()
        analyzer.close()
        executor.shutdown()
    }
}
