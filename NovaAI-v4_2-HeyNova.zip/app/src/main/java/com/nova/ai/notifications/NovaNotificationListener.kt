package com.nova.ai.notifications

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.nova.ai.jarvis.Announcer
import com.nova.ai.jarvis.JarvisPrefs

/** A message notification that has a "Reply" action (WhatsApp, Messages, Telegram...). Kept in RAM only. */
class ReplyTarget(val key: String, val pkg: String, val sender: String, val text: String, val action: Notification.Action, val time: Long)

/** Keeps the last few notifications in RAM only (never written to disk, never sent anywhere automatically). */
class NovaNotificationListener : NotificationListenerService() {
    companion object {
        val recent = java.util.Collections.synchronizedList(mutableListOf<String>())
        @Volatile var instance: NovaNotificationListener? = null
        private val live = java.util.concurrent.ConcurrentHashMap<String, StatusBarNotification>()
        private val replyTargets = java.util.concurrent.ConcurrentHashMap<String, ReplyTarget>()

        private fun matches(n: StatusBarNotification, app: String): Boolean =
            app.isBlank() || n.packageName.lowercase().contains(app.lowercase())

        /** Dismisses notifications that Android allows to be cleared (not ongoing ones). Returns how many. */
        fun dismiss(app: String): Int {
            val s = instance ?: return -1
            var c = 0
            live.values.filter { matches(it, app) && it.isClearable }.forEach { try { s.cancelNotification(it.key); c++ } catch (e: Exception) {} }
            return c
        }

        /** Opens the newest matching notification through its own PendingIntent. */
        fun open(app: String): Boolean {
            val n = live.values.filter { matches(it, app) }.maxByOrNull { it.postTime } ?: return false
            return try { n.notification.contentIntent?.send(); n.notification.contentIntent != null } catch (e: Exception) { false }
        }

        fun summaryText(): String =
            synchronized(recent) { if (recent.isEmpty()) "No recent notifications from allowed apps. Choose apps in Settings > Notifications." else recent.takeLast(10).joinToString("\n") }

        /** Newest first. */
        fun messages(limit: Int = 5): List<ReplyTarget> = replyTargets.values.sortedByDescending { it.time }.take(limit)

        /** Sends [text] through the app's own reply action. Returns a short result sentence. */
        fun reply(ctx: Context, who: String, text: String): String {
            if (instance == null) return "Notification access is off. Enable it in Notifications."
            val t = (if (who.isBlank()) messages(1).firstOrNull()
                else messages(20).firstOrNull { it.sender.contains(who, true) || it.pkg.contains(who, true) })
                ?: return if (who.isBlank()) "There is no recent message to reply to." else "I don't see a recent message from $who."
            val ri = t.action.remoteInputs?.firstOrNull() ?: return "That message can't be replied to from here."
            return try {
                val i = Intent()
                val b = Bundle().apply { putCharSequence(ri.resultKey, text) }
                RemoteInput.addResultsToIntent(t.action.remoteInputs, i, b)
                t.action.actionIntent.send(ctx, 0, i)
                "Reply bhej diya ${t.sender} ko."
            } catch (e: Exception) { "Couldn't send the reply: the app didn't accept it." }
        }
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null; live.clear(); replyTargets.clear() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { sbn?.let { live.remove(it.key); replyTargets.remove(it.key) } }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (n.packageName == packageName) return
        live[n.key] = n
        val allowed = getSharedPreferences("nova_prefs", MODE_PRIVATE).getStringSet("notif_allowed", emptySet()) ?: emptySet()
        if (n.packageName !in allowed) return
        val e = n.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: ""
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        synchronized(recent) {
            recent.add("${n.packageName.substringAfterLast('.')}: $title - $text")
            while (recent.size > 20) recent.removeAt(0)
        }
        // Messages you can reply to by voice. Group summaries are skipped.
        val isSummary = (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        val reply = n.notification.actions?.firstOrNull { a -> !a.remoteInputs.isNullOrEmpty() }
        if (reply != null && !isSummary) {
            replyTargets[n.key] = ReplyTarget(n.key, n.packageName, title, text, reply, n.postTime)
            if (JarvisPrefs(this).carMode) Announcer.speak(this, "$title ne bheja: $text. Reply karna hai to bolo, Nova reply karo.")
        }
    }
}
