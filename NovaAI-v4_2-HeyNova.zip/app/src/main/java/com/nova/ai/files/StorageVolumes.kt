package com.nova.ai.files

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import java.io.File

data class VolumeInfo(
    val id: String, val label: String, val root: String, val removable: Boolean,
    val total: Long, val free: Long, val readOnly: Boolean
) {
    val used: Long get() = (total - free).coerceAtLeast(0)
}

/** Internal storage and any mounted SD card / USB drive, as Android reports them. Nothing is assumed: an absent card is simply not listed. */
object StorageVolumes {
    /** Folders that exist on most phones. Only the ones that really exist on a volume are shown. */
    val standardFolders = listOf("Download", "Documents", "DCIM", "Pictures", "Movies", "Music", "Recordings", "Podcasts", "Audiobooks", "Ringtones", "Alarms", "Notifications")

    fun list(ctx: Context): List<VolumeInfo> {
        val out = ArrayList<VolumeInfo>(); val seen = HashSet<String>()
        fun add(id: String, label: String, dir: File?, removable: Boolean, ro: Boolean) {
            if (dir == null) return
            val root = try { dir.canonicalPath } catch (e: Exception) { return }
            if (!seen.add(root)) return
            val (total, free) = try { StatFs(root).let { it.totalBytes to it.availableBytes } } catch (e: Exception) { 0L to 0L }
            out.add(VolumeInfo(id, label, root, removable, total, free, ro))
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
                for (v in sm.storageVolumes) {
                    val st = v.state
                    if (st != Environment.MEDIA_MOUNTED && st != Environment.MEDIA_MOUNTED_READ_ONLY) continue
                    val desc = v.getDescription(ctx).orEmpty()
                    val label = when {
                        v.isPrimary -> "Internal Storage"
                        desc.contains("usb", true) -> "USB drive"
                        else -> "SD Card"
                    }
                    add(v.uuid ?: "primary", label, v.directory, v.isRemovable, st == Environment.MEDIA_MOUNTED_READ_ONLY)
                }
            } else {
                add("primary", "Internal Storage", Environment.getExternalStorageDirectory(), false, false)
                // Android 8-10 only exposes other volumes through each volume's app-specific folder; cut that suffix off to get the volume root.
                ctx.getExternalFilesDirs(null).filterNotNull().forEach { d ->
                    val p = d.path
                    if (p.contains("/Android/data")) {
                        val root = File(p.substringBefore("/Android/data"))
                        if (root.exists()) add(root.name, if (Environment.isExternalStorageRemovable(d)) "SD Card" else "Internal Storage", root, Environment.isExternalStorageRemovable(d), false)
                    }
                }
            }
        } catch (e: Exception) { /* storage service unavailable: fall through to the primary directory below */ }
        if (out.isEmpty()) add("primary", "Internal Storage", Environment.getExternalStorageDirectory(), false, false)
        return out
    }

    fun roots(ctx: Context): List<String> = list(ctx).map { it.root }

    /** Which of the usual folders exist on this volume. */
    fun existingStandardFolders(volume: VolumeInfo): List<File> =
        standardFolders.map { File(volume.root, it) }.filter { try { it.isDirectory } catch (e: Exception) { false } }
}
