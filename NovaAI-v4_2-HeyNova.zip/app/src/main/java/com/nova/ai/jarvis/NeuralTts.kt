package com.nova.ai.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import com.nova.ai.ai.GeminiHttp
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * More natural voice through Gemini text-to-speech (generateContent with AUDIO output, raw 16-bit PCM back).
 * If anything fails (no internet, quota, wrong model name) [speak] reports failure and the caller uses Android's own TTS.
 */
class NeuralTts(private val ctx: Context, private val prefs: Prefs) {
    private val jp = JarvisPrefs(ctx)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var track: AudioTrack? = null

    fun enabled(): Boolean = jp.neuralTts && !prefs.localOnly && prefs.aiEnabled && prefs.apiKey.isNotBlank()

    /** [onStarted] runs when audio is about to play; [onFinished] gets true when it played, false when the caller should fall back. */
    fun speak(text: String, onStarted: () -> Unit, onFinished: (Boolean) -> Unit) {
        stop()
        job = scope.launch {
            val clean = text.replace(Regex("[*_`#>]"), "").trim()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", clean)))))
                .put("generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", jp.ttsVoiceName)))))
            val out = GeminiHttp.post(prefs, body, jp.ttsModel, readTimeoutMs = 30000)
            val part = out.json?.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?.let { a -> (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull { it.has("inlineData") } }
                ?.optJSONObject("inlineData")
            val data = part?.optString("data").orEmpty()
            if (data.isEmpty()) { onFinished(false); return@launch }
            val rate = Regex("rate=(\\d+)").find(part?.optString("mimeType").orEmpty())?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            val pcm = try { Base64.decode(data, Base64.DEFAULT) } catch (e: Exception) { onFinished(false); return@launch }
            play(pcm, rate, onStarted, onFinished)
        }
    }

    private suspend fun play(pcm: ByteArray, rate: Int, onStarted: () -> Unit, onFinished: (Boolean) -> Unit) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { onFinished(false); return }
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) { onFinished(false); return }
        track = t
        try {
            t.setVolume(prefs.ttsVolume.coerceIn(0f, 1f))
            t.play()
            onStarted()
            var off = 0
            while (off < pcm.size && scope.isActive && track === t) {
                val n = t.write(pcm, off, minOf(4096, pcm.size - off))
                if (n <= 0) break
                off += n
            }
            val frames = pcm.size / 2
            var guard = 0
            while (track === t && t.playbackHeadPosition < frames && guard < 600) { delay(50); guard++ }
            onFinished(true)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            onFinished(false)
        } finally {
            try { t.stop() } catch (e: Exception) { }
            try { t.release() } catch (e: Exception) { }
            if (track === t) track = null
        }
    }

    fun stop() {
        job?.cancel(); job = null
        val t = track; track = null
        try { t?.stop() } catch (e: Exception) { }
    }

    fun shutdown() { stop(); scope.cancel() }
}
