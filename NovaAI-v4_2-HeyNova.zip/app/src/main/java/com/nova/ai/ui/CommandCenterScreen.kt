package com.nova.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.NovaApp
import com.nova.ai.automation.Routine
import com.nova.ai.automation.RoutineManager
import com.nova.ai.device.DeviceAlerts
import com.nova.ai.device.NetworkMonitor
import com.nova.ai.device.TemperatureMonitor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun describe(r: Routine): String {
    val trig = when (r.trigger) {
        "TIME_DAILY" -> "Every day at ${r.trigValue}"
        "TIME_WEEKLY" -> RoutineManager.describeWeekly(r.trigValue)
        "TIME_ONCE" -> "Once at " + SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(r.fireAt))
        "BATTERY_LOW" -> "When battery is ${r.trigValue.ifBlank { "15" }}% or lower"
        else -> "When ${r.trigValue.ifBlank { "any Bluetooth device" }} connects"
    }
    return trig + " → " + if (r.action == "OFFER_APP") "offer to open an app" else "notify: ${r.actValue}"
}

@Composable
fun CommandCenterScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    val mic = rememberMicAction(vm)
    var cmd by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf(false) }
    var rev by remember { mutableIntStateOf(0) }
    val notes = remember(rev) { vm.db.notes() }
    val routines = remember(rev) { vm.automation.list() }
    val log = remember(rev, vm.changes.size) { vm.changeDetector.log() }
    val last = vm.messages.lastOrNull { !it.fromUser }?.text ?: ""
    fun run() { if (cmd.isNotBlank()) { vm.send(cmd); cmd = "" } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            Column(Modifier.weight(1f)) {
                GText("Command Center", size = 22.sp, weight = FontWeight.SemiBold)
                GText("Local commands run on the phone first. Gemini is used only when needed.", size = 11.sp, color = g.subtext)
            }
            StatChip(if (vm.online) "ONLINE" else "OFFLINE")
        }
        GlassSettingSection("Run a command") {
            GlassTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), placeholder = "Type a command…",
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { run() }))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Run", { run() }, primary = true)
                GlassButton("Speak", mic, glyph = "🎤")
            }
            if (last.isNotBlank()) GText(last, size = 14.sp, color = g.accent)
        }
        GlassSettingSection("Try saying") {
            listOf(
                "Device" to listOf("scan my phone", "what did you find", "what changed on my phone", "what is my battery", "flashlight on"),
                "Apps & phone" to listOf("open YouTube", "open settings", "wifi status", "show connected bluetooth devices"),
                "Productivity" to listOf("start a timer for 5 minutes", "set alarm for 7 am", "note: buy milk", "show notes", "remind me in 10 minutes to stretch", "calculate 12 * 5"),
                "Memory & modes" to listOf("remember this", "forget that", "what do you remember", "switch to developer mode", "talk normally")
            ).forEach { (title, cmds) ->
                GText(title, size = 12.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    cmds.forEach { c -> GlassChip(c, false, { vm.send(c) }) }
                }
            }
        }
        GlassSettingSection("Notes") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassTextField(noteText, { noteText = it }, Modifier.weight(1f), placeholder = "New note")
                GlassButton("Add", { if (noteText.isNotBlank()) { vm.db.addNote(noteText.trim()); noteText = ""; rev++ } }, primary = true)
            }
            if (notes.isEmpty()) GText("No notes yet.", size = 12.sp, color = g.subtext)
            notes.take(20).forEach { n ->
                GlassListItem(n.second, trailing = { SmallAction("Delete", "Delete note") { vm.db.deleteNote(n.first); rev++ } })
            }
        }
        GlassSettingSection("Reminders & routines") {
            GText("Routines only notify you or offer to open an app. Nothing runs silently.", size = 12.sp, color = g.subtext)
            if (routines.isEmpty()) GText("No routines yet. Try \"remind me in 10 minutes to stretch\".", size = 12.sp, color = g.subtext)
            routines.forEach { r ->
                GlassListItem(r.name + (if (r.trigger == "TIME_ONCE" && !r.enabled) " (done)" else ""), describe(r), trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GlassSwitch(r.enabled) { vm.automation.setEnabled(r.id, it); rev++ }
                        SmallAction("Delete", "Delete routine") { vm.automation.delete(r.id); rev++ }
                    }
                })
            }
            GlassButton("New routine", { sheet = true }, Modifier.fillMaxWidth(), primary = true)
        }
        DeviceAlertsSection(vm)
        ModesSection(vm)
        GlassSettingSection("What changed on my phone") {
            if (log.isEmpty()) GText("No changes recorded yet.", size = 12.sp, color = g.subtext)
            log.take(8).forEach { (t, text) ->
                GlassListItem(text, SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(t)))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Check now", { vm.detectNow(); rev++ })
                GlassButton("Rescan device", { vm.startScan() }, primary = true)
            }
        }
        GlassSettingSection("Works offline") {
            listOf("Flashlight, volume, open apps and settings", "Battery, device, storage, Wi-Fi and Bluetooth status", "Time, date, calculator",
                "Timers and alarms (system clock app)", "Notes, reminders and local memory", "Device scan and change detection",
                "Voice recognition and speech only if offline voice data is installed").forEach { GText("✓  $it", size = 13.sp) }
            GText("Open-ended AI answers need internet. Nova will say so instead of pretending.", size = 12.sp, color = g.subtext)
        }
    }
    if (sheet) RoutineSheet(vm, { sheet = false }) { rev++ }
}

@Composable
private fun RoutineSheet(vm: NovaViewModel, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val g = LocalGlass.current
    var name by remember { mutableStateOf("") }
    var trig by remember { mutableStateOf("TIME_DAILY") }
    var value by remember { mutableStateOf("") }
    var act by remember { mutableStateOf("NOTIFY") }
    var text by remember { mutableStateOf("") }
    var appName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    GlassSheet(onDismiss, "New routine") {
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Name (e.g. Study time)")
        GText("When", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("TIME_DAILY" to "Daily at a time", "TIME_WEEKLY" to "Weekly on days", "BATTERY_LOW" to "Battery low", "BT_CONNECTED" to "Bluetooth connects").forEach { (k, l) -> GlassChip(l, trig == k, { trig = k; value = "" }) }
        }
        GlassTextField(value, { value = it }, Modifier.fillMaxWidth(), placeholder = when (trig) {
            "TIME_DAILY" -> "Time, 24-hour HH:MM (e.g. 07:00)"; "TIME_WEEKLY" -> "Days and time, e.g. tue,sat 18:00"; "BATTERY_LOW" -> "Battery % (default 15)"; else -> "Device name contains (blank = any)"
        })
        GText("Then", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Notify me", act == "NOTIFY", { act = "NOTIFY" }); GlassChip("Offer to open an app", act == "OFFER_APP", { act = "OFFER_APP" })
        }
        if (act == "NOTIFY") GlassTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = "Message")
        else GlassTextField(appName, { appName = it }, Modifier.fillMaxWidth(), placeholder = "App name (e.g. YouTube Music)")
        if (err.isNotBlank()) GText(err, size = 13.sp, color = g.accent)
        GlassButton("Save routine", {
            val tv = when (trig) {
                "TIME_DAILY" -> Regex("^(\\d{1,2}):(\\d{2})$").find(value.trim())?.let { m ->
                    val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
                    if (h in 0..23 && mi in 0..59) "%02d:%02d".format(h, mi) else null
                }
                "TIME_WEEKLY" -> RoutineManager.parseWeeklyInput(value)
                "BATTERY_LOW" -> (value.trim().toIntOrNull() ?: 15).coerceIn(5, 50).toString()
                else -> value.trim()
            }
            val pkg = if (act == "OFFER_APP") vm.device.listApps().firstOrNull { it.first.contains(appName.trim(), true) }?.second else null
            when {
                tv == null -> err = if (trig == "TIME_WEEKLY") "Enter days and a time, like tue,sat 18:00." else "Enter the time as HH:MM, like 07:00."
                act == "NOTIFY" && text.isBlank() -> err = "Enter a message."
                act == "OFFER_APP" && pkg == null -> err = "I couldn't find that app."
                else -> {
                    vm.automation.create(Routine(0, name.ifBlank { "Routine" }, trig, tv, act, if (act == "NOTIFY") text.trim() else pkg!!, true, trig == "TIME_DAILY" || trig == "TIME_WEEKLY", 0, System.currentTimeMillis(), 0))
                    onSaved(); onDismiss()
                }
            }
        }, Modifier.fillMaxWidth(), primary = true)
    }
}


@Composable
private fun DeviceAlertsSection(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var bat by remember { mutableStateOf(p.batteryAlerts) }
    var full by remember { mutableStateOf(p.batteryFullAlert) }
    var low by remember { mutableStateOf(p.batteryLowPct.toFloat()) }
    var crit by remember { mutableStateOf(p.batteryCritPct.toFloat()) }
    var temp by remember { mutableStateOf(p.tempAlerts) }
    var warn by remember { mutableStateOf(p.tempWarnC.toFloat()) }
    var reading by remember { mutableStateOf("") }
    var netText by remember { mutableStateOf("") }
    GlassSettingSection("Device alerts") {
        GText("Alerts use Android's own battery and thermal readings and are off until you turn them on. Background checks can be up to 15 minutes late.", size = 12.sp, color = g.subtext)
        ToggleRow("Battery alerts", "Low, critically low and fully charged", bat) { bat = it; p.batteryAlerts = it; DeviceAlerts.schedule(NovaApp.instance, p) }
        if (bat) {
            GlassSlider("Low battery alert", "${low.toInt()}%", low, { low = it; p.batteryLowPct = it.toInt() }, 10f..50f)
            GlassSlider("Critical battery alert", "${crit.toInt()}%", crit, { crit = it; p.batteryCritPct = it.toInt() }, 3f..20f)
            ToggleRow("Fully charged alert", null, full) { full = it; p.batteryFullAlert = it }
        }
        ToggleRow("Temperature alerts", "Battery temperature and Android's thermal status", temp) { temp = it; p.tempAlerts = it; DeviceAlerts.schedule(NovaApp.instance, p) }
        if (temp) GlassSlider("Warn at", "${warn.toInt()}°C", warn, { warn = it; p.tempWarnC = it.toInt() }, 35f..50f)
        GText("Sensor availability varies by phone. Nova never shows a CPU or GPU number because Android doesn't give one to apps on most devices.", size = 12.sp, color = g.subtext)
        GlassButton("Check temperature now", { reading = TemperatureMonitor(NovaApp.instance, p).describe() })
        if (reading.isNotBlank()) GText(reading, size = 13.sp, color = g.accent)
        GlassButton("Check network", { val n = NetworkMonitor.shared(NovaApp.instance); n.measureAsync(); netText = n.describe() + " (latency refreshes in a few seconds; tap again)" })
        if (netText.isNotBlank()) GText(netText, size = 13.sp, color = g.accent)
    }
}

@Composable
private fun ModesSection(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    val app = NovaApp.instance
    val clip = LocalClipboardManager.current
    val timeOk = Regex("^([01]?\\d|2[0-3]):[0-5]\\d$")
    var nightNow by remember { mutableStateOf(p.nightActive) }
    var sched by remember { mutableStateOf(p.nightScheduleOn) }
    var nStart by remember { mutableStateOf(p.nightStart) }
    var nEnd by remember { mutableStateOf(p.nightEnd) }
    var editing by remember { mutableStateOf(p.editingActive) }
    var tpl by remember { mutableStateOf(p.editingTemplate) }
    var days by remember { mutableStateOf(if (p.editingDays.isBlank()) "" else p.editingDays.lowercase() + " " + p.editingTime) }
    var msg by remember { mutableStateOf("") }
    GlassSettingSection("Night & Editing mode") {
        GText("Modes only change Nova's own volume, theme and notifications, or open an Android settings page for you. They never switch protected system settings by themselves.", size = 12.sp, color = g.subtext)
        ToggleRow("Night mode now", "Quieter Nova voice and dark theme", nightNow) { nightNow = it; msg = if (it) RoutineManager.nightOn(app, p) else RoutineManager.nightOff(p) }
        ToggleRow("Night mode schedule", "Every day between the times below", sched) { sched = it; p.nightScheduleOn = it; RoutineManager.syncAll(app, p) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassTextField(nStart, { nStart = it }, Modifier.weight(1f), placeholder = "On 22:00")
            GlassTextField(nEnd, { nEnd = it }, Modifier.weight(1f), placeholder = "Off 06:00")
        }
        GlassButton("Save night times", {
            if (timeOk.matches(nStart.trim()) && timeOk.matches(nEnd.trim())) {
                fun fix(s: String) = s.trim().split(":").let { "%02d:%02d".format(it[0].toInt(), it[1].toInt()) }
                p.nightStart = fix(nStart); p.nightEnd = fix(nEnd); RoutineManager.syncAll(app, p); msg = "Night times saved."
            } else msg = "Use 24-hour times like 22:00."
        })
        ToggleRow("Editing mode", "Pauses Nova's own proactive notifications", editing) { editing = it; msg = if (it) RoutineManager.editingOn(p) else RoutineManager.editingOff(p) }
        GText("Editing template (description you can copy)", size = 12.sp, color = g.subtext)
        GlassTextField(tpl, { tpl = it; p.editingTemplate = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 4)
        GlassButton("Copy template", { clip.setText(AnnotatedString(tpl)); msg = "Template copied." })
        GText("Editing days (a notification on these days)", size = 12.sp, color = g.subtext)
        GlassTextField(days, { days = it }, Modifier.fillMaxWidth(), placeholder = "e.g. tue,sat 18:00")
        GlassButton("Save editing days", {
            val tv = RoutineManager.parseWeeklyInput(days, p.editingTime)
            val parsed = tv?.let { RoutineManager.decode(it) }
            if (parsed == null) msg = "Enter days and a time, like tue,sat 18:00."
            else { RoutineManager.setEditingDays(vm.automation, p, parsed.first, parsed.second); msg = RoutineManager.describeWeekly(tv) }
        })
        if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)
    }
}
