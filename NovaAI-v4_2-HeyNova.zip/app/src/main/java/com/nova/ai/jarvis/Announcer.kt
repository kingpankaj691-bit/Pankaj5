package com.nova.ai.jarvis

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.nova.ai.ai.Emotion
import com.nova.ai.security.Prefs
import com.nova.ai.voice.VoiceManager

/** Speaks things Nova says on her own (call announcements, briefings, reminders), outside of a chat reply. */
object Announcer {
    private val main = Handler(Looper.getMainLooper())
    private var voice: VoiceManager? = null

    fun speak(ctx: Context, text: String) {
        val app = ctx.applicationContext
        main.post {
            try {
                val v = voice ?: VoiceManager(app as android.app.Application, Prefs(app)).also { voice = it }
                // First use: the TTS engine may still be starting, so give it a moment.
                if (v.ttsAvailable()) v.speak(text, Emotion.Normal) else main.postDelayed({ voice?.speak(text, Emotion.Normal) }, 1500)
            } catch (e: Exception) { }
        }
    }

    fun stop() { main.post { voice?.stopSpeaking() } }

    fun release() {
        main.post { try { voice?.shutdown() } catch (e: Exception) { }; voice = null }
    }
}
