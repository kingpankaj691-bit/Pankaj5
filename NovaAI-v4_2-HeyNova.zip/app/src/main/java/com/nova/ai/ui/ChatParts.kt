package com.nova.ai.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class Seg {
    data class Txt(val t: String) : Seg()
    data class Code(val lang: String, val code: String) : Seg()
}

fun parseSegments(s: String): List<Seg> {
    val out = mutableListOf<Seg>()
    val re = Regex("```([A-Za-z0-9_+#-]*)\\n?([\\s\\S]*?)```")
    var last = 0
    for (m in re.findAll(s)) {
        if (m.range.first > last) {
            val t = s.substring(last, m.range.first).trim()
            if (t.isNotEmpty()) out.add(Seg.Txt(t))
        }
        out.add(Seg.Code(m.groupValues[1], m.groupValues[2].trimEnd()))
        last = m.range.last + 1
    }
    if (last < s.length) {
        val t = s.substring(last).trim()
        if (t.isNotEmpty()) out.add(Seg.Txt(t))
    }
    return out
}

private val KEYWORDS = setOf(
    "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while", "return", "import",
    "package", "def", "from", "in", "is", "as", "null", "None", "true", "false", "True", "False", "this", "self",
    "new", "public", "private", "protected", "static", "void", "int", "String", "const", "let", "function", "async",
    "await", "try", "catch", "except", "throw", "override", "suspend", "data", "enum", "with", "lambda"
)
private val TOKEN = Regex("""(//.*|#.*)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|\b(\d+(?:\.\d+)?)\b|\b([A-Za-z_]\w*)\b""")

fun highlight(code: String, keyword: Color): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in TOKEN.findAll(code)) {
        if (m.range.first > last) append(code.substring(last, m.range.first))
        val s = m.value
        val color: Color? = when {
            m.groups[1] != null -> Color(0xFF7D8AA5)
            m.groups[2] != null -> Color(0xFF8BE9A8)
            m.groups[3] != null -> Color(0xFFFFC27A)
            s in KEYWORDS -> keyword
            else -> null
        }
        if (color == null) append(s) else withStyle(SpanStyle(color = color)) { append(s) }
        last = m.range.last + 1
    }
    if (last < code.length) append(code.substring(last))
}

@Composable
fun SmallAction(label: String, description: String, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        Modifier.heightIn(min = 48.dp).pressable(onClick).padding(horizontal = 8.dp).semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { GText(label, size = 12.sp, color = g.accent, weight = FontWeight.Medium) }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val g = LocalGlass.current
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF05070F).a(0.74f))
            .border(1.dp, Color.White.a(0.12f), shape)
    ) {
        Row(Modifier.fillMaxWidth().background(Color.White.a(0.06f)).padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (lang.isBlank()) "code" else lang, Modifier.weight(1f), color = Color.White.a(0.7f), fontSize = 12.sp)
            SmallAction(if (copied) "Copied" else "Copy", "Copy code") { clip.setText(AnnotatedString(code)); copied = true }
        }
        Text(
            highlight(code, Color(0xFFB9A8FF)),
            Modifier.horizontalScroll(rememberScrollState()).padding(12.dp),
            color = Color(0xFFE6EDF7), fontFamily = FontFamily.Monospace, fontSize = 13.sp, softWrap = false
        )
    }
}

@Composable
fun TypingIndicator() {
    val g = LocalGlass.current
    val phase = rememberPhase(1200)
    GlassCard(Modifier.padding(vertical = 4.dp), shape = RoundedCornerShape(20.dp), tint = g.accent.a(0.08f)) {
        Canvas(Modifier.padding(horizontal = 18.dp, vertical = 16.dp).size(44.dp, 10.dp)) {
            for (i in 0..2) {
                val q = (phase.value + i * 0.18f) % 1f
                val a = 0.35f + 0.65f * (if (q < 0.5f) q * 2f else (1f - q) * 2f)
                drawCircle(g.accent.a(a), 4.dp.toPx(), androidx.compose.ui.geometry.Offset(5.dp.toPx() + i * 17.dp.toPx(), size.height / 2f))
            }
        }
    }
}

@Composable
fun MessageBubble(
    m: ChatMsg, animate: Boolean, isLastNova: Boolean, speaking: Boolean, showActions: Boolean,
    onReplay: () -> Unit, onRegenerate: () -> Unit
) {
    val g = LocalGlass.current
    val clip = LocalClipboardManager.current
    var visible by remember { mutableStateOf(!animate) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible,
        enter = if (g.reduced) EnterTransition.None
        else fadeIn(tween(260)) + slideInVertically(initialOffsetY = { it / 3 }) + scaleIn(initialScale = 0.96f)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
            GlassCard(
                Modifier.widthIn(max = 560.dp), shape = RoundedCornerShape(22.dp),
                glow = !m.fromUser, tint = if (m.fromUser) Color.Black.a(if (g.dark) 0.22f else 0.04f) else g.accent.a(0.10f)
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    parseSegments(m.text).forEach { seg ->
                        when (seg) {
                            is Seg.Txt -> GText(seg.t)
                            is Seg.Code -> CodeBlock(seg.lang, seg.code)
                        }
                    }
                    if (!m.fromUser && showActions) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SmallAction("Copy", "Copy reply") { clip.setText(AnnotatedString(m.text)) }
                            SmallAction("Replay", "Read reply aloud", onReplay)
                            if (isLastNova) SmallAction("Regenerate", "Regenerate reply", onRegenerate)
                            if (isLastNova && speaking) GText("  ● Speaking", size = 12.sp, color = g.subtext)
                        }
                    }
                }
            }
        }
    }
}
