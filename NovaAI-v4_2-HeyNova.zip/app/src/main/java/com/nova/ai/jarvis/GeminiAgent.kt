package com.nova.ai.jarvis

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.GeminiHttp
import com.nova.ai.core.AIProvider
import com.nova.ai.modules.CalendarImpl
import com.nova.ai.modules.WeatherImpl
import com.nova.ai.notifications.NovaNotificationListener
import com.nova.ai.security.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Gemini function calling: Gemini itself decides which phone tool to use, for example
 * "meri battery kam hai, kuch karo" or "kal ka mausam dekh ke batao aur music chalao".
 * Sensitive actions (messages, PC, smart home, anything that needs confirmation) are never run from here.
 */
class GeminiAgent(
    private val ctx: Context,
    private val prefs: Prefs,
    /** Runs one natural-language phone command through the normal command router and returns what happened. */
    private val phoneCommand: suspend (String) -> String
) : AIProvider {

    private fun fn(name: String, desc: String, vararg props: Pair<String, String>): JSONObject {
        val p = JSONObject(); props.forEach { p.put(it.first, JSONObject().put("type", "STRING").put("description", it.second)) }
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", p).put("required", JSONArray(props.map { it.first })))
        return o
    }

    private val declarations = JSONArray()
        .put(fn("phone_command", "Run a command on the user's phone in plain words, e.g. 'open YouTube', 'flashlight on', 'battery status', 'set a timer for 5 minutes', 'wifi status'.", "command" to "The command in the user's words"))
        .put(fn("get_weather", "Current weather and 3-day forecast.", "place" to "City name, or empty for the user's home city"))
        .put(fn("get_calendar", "Upcoming calendar events.", "days" to "Number of days ahead, 1 to 7"))
        .put(fn("get_notifications", "The user's most recent notifications from allowed apps."))
        .put(fn("get_time", "Current local date and time."))
        .put(fn("media_control", "Control music playback or volume.", "action" to "play, pause, next, previous, volume_up, volume_down or mute"))

    private suspend fun runTool(name: String, args: JSONObject): String = try {
        when (name) {
            "phone_command" -> phoneCommand(args.optString("command"))
            "get_weather" -> WeatherImpl(ctx, prefs).forecast(args.optString("place").ifBlank { null })
            "get_calendar" -> CalendarImpl(ctx).upcoming(args.optString("days").toIntOrNull() ?: 1)
            "get_notifications" -> NovaNotificationListener.summaryText()
            "get_time" -> SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
            "media_control" -> Media.control(ctx, args.optString("action"))
            else -> "Unknown tool."
        }
    } catch (e: Exception) { "The tool failed: ${e.message}" }

    override suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String?): AiResult {
        if (prefs.localOnly) return AiResult.Err("Local-only mode is on. Gemini is not used.")
        val contents = JSONArray()
        history.forEach { (isUser, text) ->
            contents.put(JSONObject().put("role", if (isUser) "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val sys = system + "\nYou can call tools to act on the phone. Use a tool when the user asks you to do or check something; otherwise just answer. " +
            "After using tools, reply in one or two short spoken sentences. If a tool says it needs confirmation, tell the user to say that command directly."
        repeat(5) {
            val body = JSONObject()
                .put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations)))
                .put("generationConfig", JSONObject().put("temperature", prefs.temperature.toDouble()).put("maxOutputTokens", prefs.maxTokens))
            val out = GeminiHttp.post(prefs, body, model)
            val j = out.json ?: return AiResult.Err(out.error ?: "Gemini request failed.")
            val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return AiResult.Err("Gemini returned an empty answer (it may have been blocked).")
            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) {
                val text = GeminiHttp.textOf(j)
                return if (text.isBlank()) AiResult.Err("Gemini returned an empty answer.") else AiResult.Ok(text)
            }
            contents.put(JSONObject().put("role", "model").put("parts", parts))          // echoed unchanged (keeps thought signatures)
            val replies = JSONArray()
            for (c in calls) {
                val fc = c.getJSONObject("functionCall")
                val name = fc.optString("name")
                val res = runTool(name, fc.optJSONObject("args") ?: JSONObject())
                replies.put(JSONObject().put("functionResponse", JSONObject().put("name", name).put("response", JSONObject().put("result", res.take(2000)))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", replies))
        }
        return AiResult.Err("That needed too many steps. Try asking in smaller parts.")
    }
}

/** Music keys and volume, shared by the voice command and the agent tool. */
object Media {
    fun control(ctx: Context, action: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun key(code: Int) { am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)) }
        return when (action.lowercase().trim()) {
            "play", "resume" -> { key(KeyEvent.KEYCODE_MEDIA_PLAY); "Playing." }
            "pause", "stop" -> { key(KeyEvent.KEYCODE_MEDIA_PAUSE); "Paused." }
            "next" -> { key(KeyEvent.KEYCODE_MEDIA_NEXT); "Next." }
            "previous", "prev" -> { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Previous." }
            "volume_up", "up" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume up." }
            "volume_down", "down" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume down." }
            "mute" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Muted." }
            "max", "full" -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI); "Volume full." }
            else -> "I don't know that media action."
        }
    }
}
