package com.nova.ai.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.files.FileAccess
import com.nova.ai.files.FileAccessRules
import com.nova.ai.files.DuplicateRules
import com.nova.ai.files.FileOps
import com.nova.ai.files.FileIntent
import com.nova.ai.files.FileContext
import com.nova.ai.files.ProjectAnalyzer
import com.nova.ai.files.SearchQuery
import com.nova.ai.files.ItemKey
import com.nova.ai.files.OpResult
import com.nova.ai.files.OrganizePlanner
import com.nova.ai.media.MediaRepository
import android.app.Activity
import android.net.Uri
import androidx.activity.result.IntentSenderRequest
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import com.nova.ai.files.FileBrowser
import com.nova.ai.files.FileCatalog
import com.nova.ai.files.FileFormat
import com.nova.ai.files.FileHistory
import com.nova.ai.files.FileItem
import com.nova.ai.files.FileKind
import com.nova.ai.files.FileOp
import com.nova.ai.files.FileOpener
import com.nova.ai.files.FileSection
import com.nova.ai.files.FileSort
import com.nova.ai.files.FileStatus
import com.nova.ai.files.FileTypes
import com.nova.ai.files.PathRules
import com.nova.ai.files.QueryBox
import com.nova.ai.files.SortMode
import com.nova.ai.files.StorageUsage
import com.nova.ai.files.StorageVolumes
import com.nova.ai.media.AllFiles
import com.nova.ai.media.Saf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Lets Home, a voice command or a notification open a particular File Manager view ("home", "search", "usage", "history", "sec:DOWNLOADS"). Consumed once. */
object FileManagerNav {
    var request by mutableStateOf<String?>(null)
    /** A voice/chat request (read, search, latest download, summary, project, duplicates, organize). Consumed once; it only opens views, never sends or deletes. */
    var intent by mutableStateOf<FileIntent?>(null)
}

/** Items waiting to be pasted. Lives for the app session only; nothing is copied until you open a destination and tap Paste. */
object FileClipboard {
    var items by mutableStateOf<List<FileItem>>(emptyList())
    var move by mutableStateOf(false)
    fun clear() { items = emptyList() }
}

private val TYPE_CHIPS: List<Pair<String, Set<FileKind>>> = listOf(
    "All" to emptySet<FileKind>(), "PDF" to FileTypes.kindsForWord("pdf"), "Docs" to FileTypes.documentKinds, "Images" to FileTypes.kindsForWord("images"),
    "Videos" to FileTypes.kindsForWord("videos"), "Audio" to FileTypes.kindsForWord("audio"), "APK" to FileTypes.kindsForWord("apk"),
    "Archives" to FileTypes.kindsForWord("zip"), "Code" to FileTypes.kindsForWord("code")
)
private val DAY_CHIPS = listOf("Any date" to 0, "Today" to 1, "7 days" to 7, "30 days" to 30)

/** Settings → File Manager. Part 1: browse, search, preview details, open, storage usage and history. */
@Composable
internal fun FileManagerPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val tick = rememberResumeTick()
    var bump by remember { mutableIntStateOf(0) }
    var view by rememberSaveable { mutableStateOf("home") }
    var browsePath by rememberSaveable { mutableStateOf("") }
    var sortName by rememberSaveable { mutableStateOf(SortMode.DATE.name) }
    var showHidden by rememberSaveable { mutableStateOf(false) }
    var limit by remember { mutableIntStateOf(100) }
    var msg by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<FileItem?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    // Part 2: selection, operations, duplicates, organize
    val selected = remember { mutableStateListOf<String>() }
    var selecting by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var renameTarget by remember { mutableStateOf<FileItem?>(null) }
    var renameText by remember { mutableStateOf("") }
    var newFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var zipItems by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var zipName by remember { mutableStateOf("archive") }
    var pendingUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var dupGroups by remember { mutableStateOf<List<List<FileItem>>>(emptyList()) }
    var dupScanned by remember { mutableStateOf(false) }
    var dupScope by rememberSaveable { mutableIntStateOf(0) }
    var orgDir by rememberSaveable { mutableStateOf("") }
    var orgPlan by remember { mutableStateOf<List<OrganizePlanner.Move>>(emptyList()) }
    var confirmOrganize by remember { mutableStateOf(false) }

    // Part 3: reading, analysis, projects
    var analysis by remember { mutableStateOf<AnalyzeTarget?>(null) }
    var projects by remember { mutableStateOf<List<File>>(emptyList()) }
    var projectsScanned by remember { mutableStateOf(false) }

    var items by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var listing by remember { mutableStateOf<FileBrowser.Listing?>(null) }
    var recent by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var counts by remember { mutableStateOf<Map<FileSection, Int>>(emptyMap()) }
    var usage by remember { mutableStateOf<StorageUsage?>(null) }
    var loading by remember { mutableStateOf(false) }

    var qText by rememberSaveable { mutableStateOf("") }
    var typeSel by rememberSaveable { mutableIntStateOf(0) }
    var daysSel by rememberSaveable { mutableIntStateOf(0) }
    var folderText by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }

    val sort = SortMode.values().firstOrNull { it.name == sortName } ?: SortMode.DATE
    val access = remember(tick, bump) { FileAccess.state(ctx, vm.prefs.storageTrees.size) }
    val volumes = remember(tick, bump) { StorageVolumes.list(ctx) }

    LaunchedEffect(FileManagerNav.request) { FileManagerNav.request?.let { view = it; limit = 100; FileManagerNav.request = null } }

    fun goHome() { view = "home"; limit = 100; selecting = false; selected.clear() }
    fun goBack() {
        if (view == "browse" && browsePath.isNotEmpty()) {
            val root = volumes.firstOrNull { PathRules.isWithin(it.root, browsePath) }?.root
            val up = if (root != null) PathRules.parent(browsePath, root) else null
            if (up != null) browsePath = up else browsePath = ""
        } else goHome()
    }
    BackHandler(enabled = view != "home") { goBack() }

    val askMedia = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        bump++
        FileHistory.record(ctx, FileOp.PERMISSION, "Media permission", "", if (r.values.any { it }) FileStatus.OK else FileStatus.DENIED, "${r.values.count { it }} of ${r.size} allowed")
    }
    val chooseTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            if (Saf.persist(ctx, u)) { vm.prefs.storageTrees = vm.prefs.storageTrees + u.toString(); msg = "Folder added. Nova can only see inside it." }
            else msg = "Android didn't keep that folder grant."
            bump++
        }
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val uris = pendingUris; pendingUris = emptyList()
        scope.launch {
            val gone = withContext(Dispatchers.IO) { uris.count { !MediaRepository.exists(ctx, Uri.parse(it)) } }
            msg = if (r.resultCode == Activity.RESULT_OK) "Deleted $gone of ${uris.size} (verified)." else "Delete cancelled. Nothing was removed."
            FileHistory.record(ctx, FileOp.DELETE, "${uris.size} media item(s)", "", if (r.resultCode == Activity.RESULT_OK && gone == uris.size) FileStatus.OK else if (r.resultCode == Activity.RESULT_OK) FileStatus.FAILED else FileStatus.CANCELLED, "")
            selected.clear(); selecting = false; bump++
        }
    }

    LaunchedEffect(view, tick, bump, sortName, limit, browsePath, showHidden) {
        when {
            view == "home" -> {
                loading = true
                withContext(Dispatchers.IO) {
                    recent = FileCatalog.recent(ctx, 5)
                    counts = FileSection.values().filter { it != FileSection.RECENT }.associateWith { FileCatalog.count(ctx, it) }
                }
                loading = false
            }
            view.startsWith("sec:") -> {
                val sec = runCatching { FileSection.valueOf(view.removePrefix("sec:")) }.getOrNull()
                if (sec != null) {
                    loading = true
                    items = withContext(Dispatchers.IO) { FileSort.sort(FileCatalog.section(ctx, sec, sort, limit), sort) }
                    loading = false
                }
            }
            view == "browse" && browsePath.isNotEmpty() -> {
                loading = true
                listing = withContext(Dispatchers.IO) { FileBrowser.list(ctx, browsePath, sort, showHidden) }
                loading = false
            }
            view == "usage" -> {
                loading = true
                usage = withContext(Dispatchers.IO) { FileCatalog.usage(ctx) }
                loading = false
            }
        }
    }

    fun openFolder(path: String) {
        if (!access.pathAccess) {
            msg = "Browsing folders needs “All files access” (Android 11+). Turn it on below, or use “Choose a folder…” to open one folder without it."
        } else { browsePath = path; view = "browse"; msg = "" }
    }

    val scopes = remember(volumes) {
        fun sub(n: String) = volumes.map { File(it.root, n).path }.filter { File(it).isDirectory }
        listOf("Downloads" to sub("Download"), "Documents" to sub("Documents"), "Pictures" to sub("Pictures"), "DCIM" to sub("DCIM"), "All storage" to volumes.map { it.root })
    }
    fun startDupScan() {
        if (!access.pathAccess) { msg = "Scanning folders needs “All files access” (Android 11+). Turn it on in the Access box."; return }
        val roots = scopes[dupScope.coerceIn(0, scopes.size - 1)].second
        if (roots.isEmpty()) { msg = "That folder doesn't exist on this phone."; return }
        msg = ""; loading = true; dupScanned = true; selected.clear()
        scope.launch { dupGroups = withContext(Dispatchers.IO) { FileOps.findDuplicates(ctx, roots) { isActive } }; loading = false }
    }
    fun startProjectScan() {
        if (!access.pathAccess) { msg = "Finding projects needs “All files access” (Android 11+). You can still open a folder you chose and use “Analyze this folder”."; return }
        msg = ""; loading = true; projectsScanned = true
        scope.launch { projects = withContext(Dispatchers.IO) { ProjectAnalyzer.findProjects(volumes.map { File(it.root) }, 30) { isActive } }; loading = false }
    }
    suspend fun searchNow(q: SearchQuery) {
        loading = true; searched = true
        results = withContext(Dispatchers.IO) {
            var r = FileCatalog.search(ctx, q, SortMode.DATE, 200)
            if (r.isEmpty() && access.pathAccess) r = FileCatalog.walk(StorageVolumes.roots(ctx), q, 200, alive = { isActive })
            r
        }
        loading = false
    }

    fun runSearch() {
        val q = QueryBox.parse(qText).withFilters(TYPE_CHIPS[typeSel].second, DAY_CHIPS[daysSel].second, folderText)
        if (q.isEmpty) { msg = "Type a name or pick a filter first."; return }
        msg = ""
        scope.launch { searchNow(q) }
    }

    LaunchedEffect(FileManagerNav.intent) {
        val ask = FileManagerNav.intent ?: return@LaunchedEffect
        FileManagerNav.intent = null; selecting = false; selected.clear(); limit = 100
        if (!access.canSeeAnything && ask !is FileIntent.OpenManager) { view = "home"; msg = "Nova can't see any files yet. Allow access first, then ask again."; return@LaunchedEffect }
        when (ask) {
            is FileIntent.Read -> {
                val f = withContext(Dispatchers.IO) { FileCatalog.search(ctx, SearchQuery(text = ask.text, kinds = ask.kinds), SortMode.DATE, 1).firstOrNull() }
                if (f == null) { view = "search"; msg = "I couldn't find a matching document." } else { view = "home"; analysis = AnalyzeTarget(f) }
            }
            is FileIntent.Search -> { view = "search"; qText = ask.query.text; folderText = ask.query.folder; typeSel = 0; daysSel = 0; msg = "Showing ${ask.label}."; searchNow(ask.query) }
            FileIntent.LatestDownload -> {
                val f = withContext(Dispatchers.IO) { FileCatalog.latestDownload(ctx) }
                view = "home"; if (f == null) msg = "I couldn't find a download Nova can see." else { FileContext.last = f; msg = FileOpener.open(ctx, f) }
            }
            FileIntent.SummarizeCurrent -> {
                val f = FileContext.last
                if (f == null) { view = "sec:RECENT"; msg = "Open or pick a document first, then ask for the summary." } else { view = "home"; analysis = AnalyzeTarget(f, summary = true) }
            }
            FileIntent.AnalyzeProject -> { view = "projects"; startProjectScan() }
            FileIntent.FindDuplicates -> { view = "dups"; selecting = true; dupScope = 0; startDupScan() }
            is FileIntent.Organize -> {
                view = "organize"
                val dir = volumes.firstOrNull()?.let { v -> File(v.root, ask.folder.ifBlank { "Download" }).path }
                if (dir != null && File(dir).isDirectory) {
                    orgDir = dir
                    val (plan, why) = withContext(Dispatchers.IO) { FileOps.organizePlan(ctx, dir) }
                    orgPlan = plan; msg = if (why.isNotBlank()) why else if (plan.isEmpty()) "Nothing to organize there." else "Here's the plan. Nothing moves until you confirm."
                } else msg = "Pick the folder to organize."
            }
            FileIntent.OpenManager -> view = "home"
        }
    }

    fun visibleItems(): List<FileItem> = when {
        view.startsWith("sec:") -> items
        view == "browse" -> (listing as? FileBrowser.Listing.Ok)?.items.orEmpty()
        view == "search" -> results
        view == "dups" -> dupGroups.flatten()
        else -> emptyList()
    }
    fun selectedItems(): List<FileItem> = visibleItems().filter { ItemKey.of(it) in selected }
    fun toggle(f: FileItem) { val k = ItemKey.of(f); if (k in selected) selected.remove(k) else selected.add(k) }
    fun tap(f: FileItem) { if (selecting) toggle(f) else if (f.isDir) { browsePath = f.path; view = "browse" } else { FileContext.last = f; detail = f } }
    fun changeAccessOk(): Boolean {
        if (!access.canWrite && !access.shizukuReady) { msg = "Changing files needs “All files access” (Android 11+), the storage permission (Android 8-9) or Shizuku. Open the Access box on the dashboard."; return false }
        return true
    }
    fun runOp(label: String, block: suspend () -> OpResult) {
        if (busy) return
        busy = true; msg = "$label…"
        scope.launch {
            val r = try { withContext(Dispatchers.IO) { block() } } catch (e: Exception) { OpResult(false, "$label failed: ${e.message}") }
            msg = r.message; busy = false; selected.clear(); selecting = false
            if (view == "dups") dupGroups = withContext(Dispatchers.IO) { dupGroups.map { gr -> gr.filter { File(it.path).exists() } }.filter { it.size >= 2 } }
            bump++
        }
    }
    fun startPaste(list: List<FileItem>, move: Boolean) {
        if (list.isEmpty()) { msg = "Select something first."; return }
        if (!changeAccessOk()) return
        FileClipboard.items = list; FileClipboard.move = move
        msg = "${list.size} item${if (list.size == 1) "" else "s"} ready to ${if (move) "move" else "copy"}. Open the destination folder and tap Paste."
        selecting = false; selected.clear(); detail = null
        if (view != "browse") { browsePath = ""; view = "browse" }
    }
    fun doPaste() {
        val dest = browsePath; val list = FileClipboard.items; val mv = FileClipboard.move
        if (dest.isEmpty() || list.isEmpty()) return
        runOp(if (mv) "Moving" else "Copying") { if (mv) FileOps.move(ctx, list, dest) else FileOps.copy(ctx, list, dest) }
        if (mv) FileClipboard.clear()
    }
    fun askDelete(list: List<FileItem>) { if (list.isEmpty()) msg = "Select something first." else confirmDelete = list }
    fun doDelete(list: List<FileItem>) {
        val pathOk = access.canWrite || access.shizukuReady
        val viaPath = if (pathOk) list.filter { it.path.isNotBlank() } else emptyList()
        val viaMedia = list.filter { it.uri != null && it !in viaPath }
        val unhandled = list.size - viaPath.size - viaMedia.size
        if (viaPath.isNotEmpty()) runOp("Deleting") { FileOps.delete(ctx, viaPath) }
        if (viaMedia.isNotEmpty()) {
            val sender = FileOps.mediaStoreDeleteRequest(ctx, viaMedia)
            if (sender != null) { pendingUris = viaMedia.mapNotNull { it.uri }; deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            else msg = "Android 11+ is needed to delete these without “All files access”."
        }
        if (unhandled > 0 && viaPath.isEmpty() && viaMedia.isEmpty()) changeAccessOk()
    }
    fun shareNow(list: List<FileItem>) { msg = FileOps.share(ctx, list) }
    fun parentOf(f: FileItem) = f.path.substringBeforeLast('/', "")

    @Composable fun SelectionBar() {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip(if (selecting) "Done" else "Select", selecting, { selecting = !selecting; selected.clear() })
            if (selecting) {
                GlassButton("All", { selected.clear(); selected.addAll(visibleItems().map { ItemKey.of(it) }) })
                GlassButton("Copy", { startPaste(selectedItems(), false) }, enabled = selected.isNotEmpty())
                GlassButton("Move", { startPaste(selectedItems(), true) }, enabled = selected.isNotEmpty())
                GlassButton("Share", { shareNow(selectedItems()) }, enabled = selected.isNotEmpty())
                GlassButton("Analyze", { selectedItems().singleOrNull()?.let { t -> analysis = if (t.isDir) AnalyzeTarget(folder = t.path) else AnalyzeTarget(t); selecting = false; selected.clear() } }, enabled = selected.size == 1)
                GlassButton("Zip", { val l = selectedItems(); if (changeAccessOk()) { zipItems = l; zipName = "archive" } }, enabled = selected.isNotEmpty())
                GlassButton("Delete…", { askDelete(selectedItems()) }, enabled = selected.isNotEmpty())
            }
        }
        if (selecting) GText("${selected.size} selected", size = 12.sp, color = g.subtext)
    }

    if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)

    when {
        // ───────────────────────── Home dashboard ─────────────────────────
        view == "home" -> {
            GlassSettingSection("Storage") {
                volumes.forEach { v ->
                    Column(Modifier.fillMaxWidth().pressable({ openFolder(v.root) }).padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GText((if (v.removable) "💾 " else "📱 ") + v.label, Modifier.weight(1f), weight = FontWeight.SemiBold)
                            GText("${FileFormat.size(v.used)} of ${FileFormat.size(v.total)}", size = 12.sp, color = g.subtext)
                        }
                        FmBar(FileFormat.percent(v.used, v.total))
                        GText("${FileFormat.size(v.free)} free" + if (v.readOnly) " · read-only" else "", size = 12.sp, color = g.subtext)
                    }
                }
                if (volumes.none { it.removable }) GText("No SD card detected.", size = 12.sp, color = g.subtext)
                if (access.pathAccess) {
                    volumes.firstOrNull()?.let { v ->
                        val std = StorageVolumes.existingStandardFolders(v)
                        if (std.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            std.forEach { f -> GlassChip(f.name, false, { openFolder(f.path) }) }
                        }
                    }
                }
            }

            GlassSettingSection("Browse") {
                val tiles = listOf(
                    Triple("🕘", "Recent Files", "") to { view = "sec:RECENT" },
                    Triple("📄", "Documents", counts[FileSection.DOCUMENTS]?.let { "$it" } ?: "") to { view = "sec:DOCUMENTS" },
                    Triple("🖼", "Images", counts[FileSection.IMAGES]?.let { "$it" } ?: "") to { view = "sec:IMAGES" },
                    Triple("🎬", "Videos", counts[FileSection.VIDEOS]?.let { "$it" } ?: "") to { view = "sec:VIDEOS" },
                    Triple("🎵", "Audio", counts[FileSection.AUDIO]?.let { "$it" } ?: "") to { view = "sec:AUDIO" },
                    Triple("⬇️", "Downloads", counts[FileSection.DOWNLOADS]?.let { "$it" } ?: "") to { view = "sec:DOWNLOADS" },
                    Triple("📦", "APKs", counts[FileSection.APKS]?.let { "$it" } ?: "") to { view = "sec:APKS" },
                    Triple("🗜", "Archives", counts[FileSection.ARCHIVES]?.let { "$it" } ?: "") to { view = "sec:ARCHIVES" },
                    Triple("🔎", "Search", "name · type · date") to { view = "search" },
                    Triple("📊", "Storage Usage", "by category") to { view = "usage" },
                    Triple("📜", "History", "what Nova did") to { view = "history" },
                    Triple("💻", "Code projects", "analyze") to { view = "projects" },
                    Triple("♻️", "Duplicates", "find copies") to { view = "dups"; selecting = true; selected.clear() },
                    Triple("🗂", "Organize", "sort by type") to { view = "organize" },
                    Triple("📁", "Browse folders", if (access.pathAccess) "all folders" else "needs access") to { openFolder(volumes.firstOrNull()?.root ?: "") }
                )
                tiles.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (t, click) -> FmTile(t.first, t.second, t.third, click, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            if (recent.isNotEmpty()) GlassSettingSection("Recent") {
                recent.forEach { f -> GlassListItem(f.name, FileFormat.rowSubtitle(f), glyph = f.kind.glyph, onClick = { detail = f }) }
                GlassButton("See all recent files", { view = "sec:RECENT" })
            }

            AiFileAnalysisSection(vm, bump) { bump++ }

            GlassSettingSection("Access") {
                access.lines().forEach { GText(it, size = 13.sp, color = g.subtext) }
                if (!access.anyMedia) GlassButton("Allow photos, videos & audio", { askMedia.launch(FileAccessRules.permissionsToRequest(access.sdk).toTypedArray()) }, Modifier.fillMaxWidth(), primary = true)
                if (access.allFilesAvailable) GlassButton(if (access.allFilesGranted) "All files access: on (open settings)" else "Allow all files access…", { msg = AllFiles.openSettings(ctx) }, Modifier.fillMaxWidth())
                if (access.sdk <= 28 && !access.canWrite) GlassButton("Allow changing files (Android 8-9)", { askMedia.launch(FileAccessRules.writePermissionsToRequest(access.sdk).toTypedArray()) }, Modifier.fillMaxWidth())
                GlassButton("Choose a folder…", { chooseTree.launch(null) }, Modifier.fillMaxWidth())
                GlassButton("Photo Picker & selected photos", { SettingsNav.request = "photos" }, Modifier.fillMaxWidth())
                GText("Documents, downloads, APKs and archives appear here once “All files access” is on, or for a folder you chose. Nova can never open other apps' private data (Android/data, /data/data) and never claims to.", size = 12.sp, color = g.subtext)
            }
        }

        // ───────────────────────── A category (Documents, Images, Downloads...) ─────────────────────────
        view.startsWith("sec:") -> {
            val sec = runCatching { FileSection.valueOf(view.removePrefix("sec:")) }.getOrNull() ?: FileSection.RECENT
            FmHeader(sec.glyph + " " + sec.label) { goHome() }
            SortChips(sort) { sortName = it.name }
            if (loading && items.isEmpty()) GText("Loading…", size = 13.sp, color = g.subtext)
            if (!loading && items.isEmpty()) {
                val needsFiles = sec in setOf(FileSection.DOCUMENTS, FileSection.DOWNLOADS, FileSection.APKS, FileSection.ARCHIVES, FileSection.RECENT)
                GText(
                    if (!access.canSeeAnything) "Nova can't see any files yet. Go back and allow access first."
                    else if (needsFiles && !access.pathAccess) "Nothing to show. Android only lets Nova list these once “All files access” is on."
                    else "Nothing found here.", size = 14.sp, color = g.subtext
                )
            }
            SelectionBar()
            items.forEach { f -> FmRow(f, selecting, ItemKey.of(f) in selected) { tap(f) } }
            if (items.size >= limit) GlassButton("Show more", { limit += 100 }, Modifier.fillMaxWidth())
        }

        // ───────────────────────── Folder browser ─────────────────────────
        view == "browse" -> {
            FmHeader("📁 Folders") { goHome() }
            if (browsePath.isEmpty()) {
                GlassSettingSection("Choose a storage") {
                    volumes.forEach { v -> GlassListItem(v.label, "${FileFormat.size(v.free)} free", glyph = if (v.removable) "💾" else "📱", onClick = { openFolder(v.root) }) }
                }
            } else {
                val root = volumes.firstOrNull { PathRules.isWithin(it.root, browsePath) }?.root ?: browsePath
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PathRules.breadcrumb(browsePath, root).forEach { (n, p) -> GlassChip(n, p == PathRules.normalize(browsePath), { browsePath = p }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Up", { goBack() })
                    GlassChip(if (showHidden) "Hidden: shown" else "Hidden: off", showHidden, { showHidden = !showHidden })
                }
                SortChips(sort) { sortName = it.name }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("New folder…", { if (changeAccessOk()) { newFolderName = ""; newFolderDialog = true } })
                    GlassButton("Organize this folder", { orgDir = browsePath; orgPlan = emptyList(); view = "organize" })
                    GlassButton("Analyze this folder", { analysis = AnalyzeTarget(folder = browsePath) })
                }
                if (FileClipboard.items.isNotEmpty()) GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), tint = g.accent.a(0.10f)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GText("${FileClipboard.items.size} item${if (FileClipboard.items.size == 1) "" else "s"} to ${if (FileClipboard.move) "move" else "copy"} here: ${PathRules.leaf(browsePath)}", size = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Paste here", { doPaste() }, primary = true, enabled = !busy)
                            GlassButton("Cancel", { FileClipboard.clear() })
                        }
                    }
                }
                SelectionBar()
                when (val l = listing) {
                    null -> GText("Loading…", size = 13.sp, color = g.subtext)
                    is FileBrowser.Listing.NoAccess -> GText(l.reason, size = 14.sp, color = g.subtext)
                    is FileBrowser.Listing.Blocked -> GText(l.reason, size = 14.sp, color = g.subtext)
                    is FileBrowser.Listing.Ok -> {
                        if (l.items.isEmpty()) GText("Empty folder.", size = 14.sp, color = g.subtext)
                        l.items.take(limit).forEach { f -> FmRow(f, selecting, ItemKey.of(f) in selected) { tap(f) } }
                        if (l.items.size > limit || l.truncated) GlassButton("Show more", { limit += 100 }, Modifier.fillMaxWidth())
                    }
                }
            }
        }

        // ───────────────────────── Search ─────────────────────────
        view == "search" -> {
            FmHeader("🔎 Search files") { goHome() }
            GlassSettingSection("Find") {
                GlassTextField(qText, { qText = it }, Modifier.fillMaxWidth(), placeholder = "File name, e.g. invoice  (filters: ext:pdf  in:download  days:7  min:5mb)")
                GText("Type", size = 12.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TYPE_CHIPS.forEachIndexed { i, (label, _) -> GlassChip(label, typeSel == i, { typeSel = i }) }
                }
                GText("Date modified", size = 12.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DAY_CHIPS.forEachIndexed { i, (label, _) -> GlassChip(label, daysSel == i, { daysSel = i }) }
                }
                GlassTextField(folderText, { folderText = it }, Modifier.fillMaxWidth(), placeholder = "Folder contains… (optional, e.g. Download)")
                GlassButton("Search", { runSearch() }, Modifier.fillMaxWidth(), primary = true)
            }
            if (loading) GText("Searching…", size = 13.sp, color = g.subtext)
            else if (searched && results.isEmpty()) GText(if (access.canSeeAnything) "No files matched. Files outside what Android lets Nova see can't be searched." else "Nova can't see any files yet. Allow access on the dashboard first.", size = 14.sp, color = g.subtext)
            if (results.isNotEmpty()) SelectionBar()
            results.forEach { f -> FmRow(f, selecting, ItemKey.of(f) in selected) { tap(f) } }
        }

        // ───────────────────────── Storage usage ─────────────────────────
        view == "usage" -> {
            FmHeader("📊 Storage usage") { goHome() }
            val totalUsed = volumes.sumOf { it.used }
            volumes.forEach { v ->
                GlassSettingSection(v.label) {
                    FmBar(FileFormat.percent(v.used, v.total))
                    GText("${FileFormat.size(v.used)} used · ${FileFormat.size(v.free)} free · ${FileFormat.size(v.total)} total", size = 13.sp, color = g.subtext)
                }
            }
            val u = usage
            if (u == null || loading) GText("Counting…", size = 13.sp, color = g.subtext)
            else GlassSettingSection("By category (files Nova can see)") {
                if (u.slices.isEmpty()) GText("Nothing counted. Allow access on the dashboard first.", size = 13.sp, color = g.subtext)
                u.slices.forEach { s ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row { GText("${s.glyph} ${s.label}", Modifier.weight(1f)); GText("${FileFormat.size(s.bytes)} · ${s.count}", size = 12.sp, color = g.subtext) }
                        FmBar(FileFormat.percent(s.bytes, totalUsed))
                    }
                }
                val rest = totalUsed - u.indexedBytes
                if (rest > 0) GText("Not counted: about ${FileFormat.size(rest)} (apps, system data and files Android doesn't show Nova).", size = 12.sp, color = g.subtext)
                if (u.capped) GText("Very large library: only the first 300,000 files were counted.", size = 12.sp, color = g.subtext)
            }
        }

        // ───────────────────────── Duplicates ─────────────────────────
        view == "dups" -> {
            FmHeader("♻️ Duplicate files") { selecting = false; selected.clear(); goHome() }
            GlassSettingSection("Where to look") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    scopes.forEachIndexed { i, (label, _) -> GlassChip(label, dupScope == i, { dupScope = i }) }
                }
                GText("Finds files that are byte-for-byte identical (same size, then a fingerprint). Nothing is deleted until you select copies and confirm; at least one copy of each is always kept.", size = 12.sp, color = g.subtext)
                GlassButton(if (loading) "Scanning…" else "Scan", { startDupScan() }, Modifier.fillMaxWidth(), primary = true, enabled = !loading)
            }
            if (dupScanned && !loading && dupGroups.isEmpty()) GText("No duplicates found.", size = 14.sp, color = g.subtext)
            if (dupGroups.isNotEmpty()) {
                GText("${dupGroups.size} group${if (dupGroups.size == 1) "" else "s"} · about ${FileFormat.size(DuplicateRules.wasted(dupGroups))} could be freed", size = 13.sp, weight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Keep oldest, select the rest", { selected.clear(); selected.addAll(DuplicateRules.extras(dupGroups)) })
                    GlassButton("Delete selected…", {
                        if (selected.isEmpty()) msg = "Select the copies to delete first."
                        else if (!DuplicateRules.safeSelection(dupGroups, selected.toSet())) msg = "Every copy in some group is selected. Keep at least one of each."
                        else askDelete(selectedItems())
                    }, enabled = selected.isNotEmpty())
                }
                GText("${selected.size} selected", size = 12.sp, color = g.subtext)
                dupGroups.take(60).forEach { gr ->
                    GlassSettingSection("${gr.size} copies · ${FileFormat.size(gr.first().size)} each") {
                        gr.forEach { f -> FmRow(f, true, ItemKey.of(f) in selected) { toggle(f) } }
                    }
                }
            }
        }

        // ───────────────────────── Code projects ─────────────────────────
        view == "projects" -> {
            FmHeader("💻 Code projects") { goHome() }
            GlassSettingSection("Find") {
                GText("Looks a few levels deep for folders that contain a build or project file (Gradle, package.json, pubspec.yaml, pom.xml…). Counting files and lines happens on your phone; Gemini only gets an outline if you approve it.", size = 12.sp, color = g.subtext)
                GlassButton(if (loading) "Looking…" else "Find projects", { startProjectScan() }, Modifier.fillMaxWidth(), primary = true, enabled = !loading)
            }
            if (projectsScanned && !loading && projects.isEmpty()) GText("No projects found. Open the project's folder in Browse and tap “Analyze this folder”.", size = 14.sp, color = g.subtext)
            projects.forEach { p -> GlassListItem(p.name, p.parent.orEmpty(), glyph = "💻", onClick = { analysis = AnalyzeTarget(folder = p.path) }) }
        }

        // ───────────────────────── Organize ─────────────────────────
        view == "organize" -> {
            FmHeader("🗂 Organize by type") { goHome() }
            GlassSettingSection("Folder to organize") {
                val std = volumes.firstOrNull()?.let { StorageVolumes.existingStandardFolders(it) }.orEmpty()
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    std.forEach { f -> GlassChip(f.name, orgDir == f.path, { orgDir = f.path; orgPlan = emptyList() }) }
                }
                if (orgDir.isNotEmpty()) GText(orgDir, size = 12.sp, color = g.subtext)
                GText("Loose files directly inside the folder are moved into Documents, Images, Videos, Audio, Archives, APKs, Code and Other sub-folders. You see the full plan first, and nothing is deleted or overwritten.", size = 12.sp, color = g.subtext)
                GlassButton("Preview plan", {
                    if (orgDir.isEmpty()) msg = "Pick a folder first."
                    else scope.launch { val (plan, why) = withContext(Dispatchers.IO) { FileOps.organizePlan(ctx, orgDir) }; orgPlan = plan; msg = if (why.isNotBlank()) why else if (plan.isEmpty()) "Nothing to organize in that folder." else "" }
                }, Modifier.fillMaxWidth(), primary = true)
            }
            if (orgPlan.isNotEmpty()) {
                GlassSettingSection("Plan: ${orgPlan.size} file${if (orgPlan.size == 1) "" else "s"}") {
                    OrganizePlanner.summary(orgPlan).forEach { (folder, n) -> GlassListItem("$folder/", "$n file${if (n == 1) "" else "s"}") }
                    orgPlan.take(8).forEach { m -> GText("${m.name}  →  ${m.toFolder}/", size = 12.sp, color = g.subtext, maxLines = 1) }
                    if (orgPlan.size > 8) GText("…and ${orgPlan.size - 8} more", size = 12.sp, color = g.subtext)
                    GlassButton("Move ${orgPlan.size} files…", { if (changeAccessOk()) confirmOrganize = true }, Modifier.fillMaxWidth(), primary = true, enabled = !busy)
                }
            }
        }

        // ───────────────────────── History ─────────────────────────
        view == "history" -> {
            FmHeader("📜 File history") { goHome() }
            val rec = remember(bump, tick) { FileHistory.all(ctx) }
            GText("What Nova did with files. Stored only on this phone, holds names and folders (never contents), never uploaded.", size = 12.sp, color = g.subtext)
            if (rec.isEmpty()) GText("Nothing yet.", size = 14.sp, color = g.subtext)
            rec.take(100).forEach { r ->
                GlassListItem("${r.op.label}: ${r.name.ifBlank { "—" }}", FileFormat.date(r.time) + " · " + r.status.name.lowercase() + (if (r.note.isNotBlank()) " · ${r.note}" else ""))
            }
            if (rec.isNotEmpty()) GlassButton("Clear history…", { confirmClear = true }, Modifier.fillMaxWidth())
        }
    }

    detail?.let { d ->
        GlassDialog({ detail = null }, d.name, "Open", { msg = FileOpener.open(ctx, d) }) {
            GText("Type: ${d.kind.label}${if (d.ext.isNotBlank()) " (.${d.ext})" else ""}", size = 14.sp)
            GText("Size: ${FileFormat.size(d.size)}", size = 14.sp)
            GText("Modified: ${FileFormat.date(d.modified)}", size = 14.sp)
            GText("Location: ${d.path.ifBlank { "(managed by Android)" }}", size = 14.sp)
            if (d.kind == FileKind.APK) GText("Opening an APK starts Android's installer, which asks you before anything is installed.", size = 12.sp, color = g.subtext)
            if (FileReaderHint.canRead(d)) GlassButton("Read & analyze…", { detail = null; analysis = AnalyzeTarget(d) }, Modifier.fillMaxWidth(), primary = true)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Copy", { startPaste(listOf(d), false) })
                GlassButton("Move", { startPaste(listOf(d), true) })
                GlassButton("Share", { detail = null; shareNow(listOf(d)) })
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Rename…", { if (changeAccessOk()) { detail = null; renameTarget = d; renameText = d.name } })
                GlassButton("Zip", { if (changeAccessOk()) { detail = null; zipItems = listOf(d); zipName = d.name.substringBeforeLast('.') } })
                if (d.ext == "zip") GlassButton("Extract", { detail = null; if (changeAccessOk()) runOp("Extracting") { FileOps.unzip(ctx, d, parentOf(d)) } })
                GlassButton("Delete…", { detail = null; askDelete(listOf(d)) })
            }
        }
    }
    analysis?.let { a -> FileAnalysisHost(vm, a) { analysis = null } }
    renameTarget?.let { t ->
        GlassDialog({ renameTarget = null }, "Rename", "Rename", { runOp("Renaming") { FileOps.rename(ctx, t, renameText) } }) {
            GlassTextField(renameText, { renameText = it }, Modifier.fillMaxWidth(), placeholder = "New name")
        }
    }
    if (newFolderDialog) GlassDialog({ newFolderDialog = false }, "New folder", "Create", { val dir = browsePath; val n = newFolderName; runOp("Creating folder") { FileOps.mkdir(ctx, dir, n) } }) {
        GlassTextField(newFolderName, { newFolderName = it }, Modifier.fillMaxWidth(), placeholder = "Folder name")
    }
    if (zipItems.isNotEmpty()) GlassDialog({ zipItems = emptyList() }, "Compress ${zipItems.size} item${if (zipItems.size == 1) "" else "s"}", "Create ZIP", {
        val list = zipItems; val name = zipName; val dir = if (view == "browse" && browsePath.isNotEmpty()) browsePath else parentOf(list.first())
        runOp("Compressing") { FileOps.zip(ctx, list, dir, name) }
    }) {
        GlassTextField(zipName, { zipName = it }, Modifier.fillMaxWidth(), placeholder = "Archive name")
        GText("The ZIP is created next to the files (or in the folder you're viewing). Originals stay untouched.", size = 12.sp, color = g.subtext)
    }
    if (confirmDelete.isNotEmpty()) {
        val list = confirmDelete
        GlassDialog({ confirmDelete = emptyList() }, "Delete ${if (list.size == 1) list[0].name else "${list.size} items"}?", "Delete", { doDelete(list) }) {
            // The user must see exactly what goes: up to 12 names with their folder, then an honest count of the rest.
            list.take(12).forEach { GText("• ${it.name}" + (com.nova.ai.files.PathRules.leaf(it.folder).takeIf { f -> f.isNotBlank() }?.let { f -> "  ($f)" } ?: ""), size = 14.sp, maxLines = 1) }
            if (list.size > 12) GText("…and ${list.size - 12} more that are also selected", size = 13.sp, color = g.accent)
            if (list.any { it.isDir }) GText("Folders are deleted with everything inside them.", size = 13.sp, color = g.accent)
            GText("This permanently deletes ${if (list.size == 1) "it" else "them"}. It can't be undone.", size = 14.sp)
        }
    }
    if (confirmOrganize) GlassDialog({ confirmOrganize = false }, "Organize ${orgPlan.size} files?", "Move files", {
        val dir = orgDir; val plan = orgPlan; orgPlan = emptyList()
        runOp("Organizing") { FileOps.organizeExecute(ctx, dir, plan) }
    }) {
        GText("Files are moved into type sub-folders inside ${PathRules.leaf(orgDir)}. Nothing is deleted or overwritten.", size = 14.sp)
    }
    if (confirmClear) GlassDialog({ confirmClear = false }, "Clear file history?", "Clear", { FileHistory.clear(ctx); bump++ }) {
        GText("This only removes Nova's log. No files are touched.", size = 14.sp)
    }
}

@Composable
private fun FmHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassIconButton("‹", "Back to File Manager", onBack)
        GText(title, size = 18.sp, weight = FontWeight.SemiBold)
    }
}

@Composable
private fun SortChips(current: SortMode, onPick: (SortMode) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SortMode.values().forEach { m -> GlassChip(m.label, current == m, { onPick(m) }) }
    }
}

@Composable
private fun FmRow(f: FileItem, selecting: Boolean, checked: Boolean, onClick: () -> Unit) {
    GlassListItem(f.name, FileFormat.rowSubtitle(f), glyph = if (selecting) (if (checked) "☑" else "☐") else f.kind.glyph, onClick = onClick)
}

@Composable
private fun FmTile(glyph: String, label: String, sub: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    GlassCard(modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().pressable(onClick).padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            GText(glyph, size = 22.sp)
            GText(label, weight = FontWeight.Medium, maxLines = 1)
            GText(sub.ifBlank { " " }, size = 12.sp, color = g.subtext, maxLines = 1)
        }
    }
}

@Composable
private fun FmBar(fraction: Float) {
    val g = LocalGlass.current
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(g.text.a(0.12f))) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(50)).background(g.accent))
    }
}

/** Which files the Read & analyze button is offered for. */
private object FileReaderHint {
    fun canRead(f: FileItem): Boolean = !f.isDir && (f.ext == "pdf" || f.ext == "apk" || com.nova.ai.files.DocReader.readable(f.name))
}
