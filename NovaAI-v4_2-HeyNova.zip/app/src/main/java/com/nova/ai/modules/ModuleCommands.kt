package com.nova.ai.modules

sealed class ModuleCall {
    data class Weather(val place: String?) : ModuleCall()
    data class Calendar(val days: Int) : ModuleCall()
    data class Translate(val text: String, val to: String) : ModuleCall()
    data class MusicPlay(val query: String) : ModuleCall()
    object MusicPause : ModuleCall(); object MusicResume : ModuleCall(); object MusicNext : ModuleCall(); object MusicPrev : ModuleCall()
    data class Quiz(val topic: String) : ModuleCall()
    data class Travel(val destination: String, val days: Int) : ModuleCall()
    data class DayPlan(val goals: String) : ModuleCall()
    data class Gaming(val game: String, val question: String) : ModuleCall()
    data class Home(val device: String, val action: String) : ModuleCall()
    data class Pc(val command: String) : ModuleCall()
    data class Forward(val device: String, val command: String) : ModuleCall()
    data class NotifDismiss(val app: String) : ModuleCall()
    data class NotifOpen(val app: String) : ModuleCall()
    object OpenTools : ModuleCall()

    val sensitive: Boolean get() = this is Pc || this is Forward || this is Home || this is NotifDismiss
    val prompt: String get() = when (this) {
        is Pc -> "Send \"$command\" to your PC?"; is Forward -> "Send \"$command\" to $device?"
        is Home -> "Turn $action: $device?"; is NotifDismiss -> "Dismiss ${if (app.isBlank()) "all" else app} notifications?"
        else -> ""
    }
}

/** Hindi / Hinglish / English phrases for the feature modules. Returns null when the text isn't a module request. */
object ModuleCommands {
    private val notDevices = Regex("(?i)\\b(wifi|wi-fi|bluetooth|flashlight|torch|airplane|hotspot|mobile data|data|location|dnd|vision|mic|microphone|silent|volume|brightness|screen|assistant|background|wake|nfc)\\b")

    fun parse(raw: String): ModuleCall? {
        val t0 = raw.trim().trim('.', '!', '?')
        val t = t0.replace(Regex("(?i)^(hey )?nova[ ,]*"), "").trim()
        val l = t.lowercase()

        // notifications
        Regex("^(?:dismiss|clear|hatao|saaf karo|remove)\\s+(?:all |my |saari |sab )?notifications?(?:\\s+(?:from|of)\\s+(.+))?$").find(l)?.let { return ModuleCall.NotifDismiss(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s+(?:ki|ke)\\s+notifications?\\s+(?:hatao|saaf karo|clear karo)$").find(l)?.let { return ModuleCall.NotifDismiss(it.groupValues[1].trim()) }
        Regex("^(?:open|kholo)\\s+(?:the\\s+)?(?:latest |last |new )?notification(?:\\s+(?:from|of)\\s+(.+))?$").find(l)?.let { return ModuleCall.NotifOpen(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s+(?:ki|ka|ke)\\s+notification\\s+(?:kholo|open karo)$").find(l)?.let { return ModuleCall.NotifOpen(it.groupValues[1].trim()) }

        // image / document / camera
        if (Regex("camera se (?:dekho|dekh ke|batao)|photo (?:kheench|le) ke batao|ask about (?:this |an? )?(?:image|photo|pdf|document)|(?:pdf|document) (?:padho|summari[sz]e|samjhao)|image (?:samjhao|describe karo)|summari[sz]e (?:this |my )?(?:pdf|document)").containsMatchIn(l)) return ModuleCall.OpenTools

        // weather
        if (Regex("\\b(weather|mausam)\\b").containsMatchIn(l)) {
            val place = l.replace(Regex("\\b(weather|mausam|what'?s|what is|the|how'?s|kaisa|kaisi|hai|ka|ki|ke|in|at|for|mein|me|batao|bata do|today|aaj|kal|tomorrow|forecast|kya|check|karo|dikhao|abhi|right now|now|outside|bahar)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            return ModuleCall.Weather(place.ifBlank { null }?.let { original(t, it) })
        }

        // calendar
        if (Regex("(my |meri |mera )?(calendar|schedule|meetings?|appointments?|events)\\b").containsMatchIn(l) &&
            Regex("(show|batao|dikhao|what|kya|upcoming|next|aaj|today|kal|tomorrow|week|check|read|sunao)").containsMatchIn(l) && !l.contains("remind")) {
            val days = when { Regex("week|hafte|hafta|7 days").containsMatchIn(l) -> 7; Regex("tomorrow|kal").containsMatchIn(l) -> 2; else -> 1 }
            return ModuleCall.Calendar(days)
        }

        // translation
        Regex("^translate\\s+(.+?)\\s+(?:to|into|in)\\s+([a-z]+)$").find(l)?.let { return ModuleCall.Translate(original(t, it.groupValues[1]), it.groupValues[2]) }
        Regex("^(.+?)\\s+(?:ko\\s+)?([a-z]+)\\s+(?:mein|me|main)\\s+(?:translate|anuvaad|batao|bolo)(?:\\s+karo|\\s+kar do)?$").find(l)?.let { return ModuleCall.Translate(original(t, it.groupValues[1]), it.groupValues[2]) }

        // music
        if (Regex("^(?:pause|stop|roko|band karo)\\s+(?:the\\s+)?(?:music|song|gaana|gana)|^(?:music|song|gaana|gana)\\s+(?:pause|roko|band)").containsMatchIn(l)) return ModuleCall.MusicPause
        if (Regex("^(?:resume|continue)\\s+(?:the\\s+)?(?:music|song)|^(?:music|gaana)\\s+(?:resume|phir se chalao)").containsMatchIn(l)) return ModuleCall.MusicResume
        if (Regex("^(?:next|agla)\\s+(?:song|gaana|gana|track)").containsMatchIn(l)) return ModuleCall.MusicNext
        if (Regex("^(?:previous|pichla|last)\\s+(?:song|gaana|gana|track)").containsMatchIn(l)) return ModuleCall.MusicPrev
        Regex("^(?:play|chalao|bajao)\\s+(?:some\\s+)?(?:music|song|songs|gaana|gana)\\s*(.*)$").find(l)?.let { return ModuleCall.MusicPlay(original(t, it.groupValues[1]).replace(Regex("(?i)^(?:by|of|ka|ke|ki)\\s+"), "")) }
        Regex("^(?:play|chalao|bajao)\\s+(.+?)\\s+(?:song|gaana|gana)$").find(l)?.let { return ModuleCall.MusicPlay(original(t, it.groupValues[1])) }
        Regex("^(.+?)\\s+(?:ka|ke|ki)\\s+(?:gaana|gana|song|songs)\\s+(?:chalao|bajao|play karo)$").find(l)?.let { return ModuleCall.MusicPlay(original(t, it.groupValues[1])) }

        // study, travel, productivity, gaming
        Regex("^quiz\\s+(?:me\\s+)?(?:on|about)\\s+(.+)$").find(l)?.let { return ModuleCall.Quiz(original(t, it.groupValues[1])) }
        Regex("^(.+?)\\s+(?:par|pe|ka|ke baare mein)\\s+quiz\\s+(?:lo|do|karo)$").find(l)?.let { return ModuleCall.Quiz(original(t, it.groupValues[1])) }
        Regex("^(?:plan|make|create)\\s+(?:a\\s+|an\\s+)?(?:(\\d+)[- ]day\\s+)?trip\\s+to\\s+(.+?)(?:\\s+for\\s+(\\d+)\\s+days?)?$").find(l)?.let {
            val d = it.groupValues[1].ifBlank { it.groupValues[3] }.toIntOrNull() ?: 3
            return ModuleCall.Travel(original(t, it.groupValues[2]), d.coerceIn(1, 14))
        }
        Regex("^(.+?)\\s+(?:ki|ka)\\s+trip\\s+plan\\s+karo(?:\\s+(\\d+)\\s+din)?$").find(l)?.let { return ModuleCall.Travel(original(t, it.groupValues[1]), it.groupValues[2].toIntOrNull()?.coerceIn(1, 14) ?: 3) }
        Regex("^(?:plan my day|mera din plan karo|productivity plan|plan my tasks)\\s*[:,-]?\\s*(.*)$").find(l)?.let { return ModuleCall.DayPlan(original(t, it.groupValues[1])) }
        Regex("^gaming\\s+tips?\\s+(?:for|on)\\s+(.+)$").find(l)?.let { return ModuleCall.Gaming(original(t, it.groupValues[1]), "") }
        Regex("^(.+?)\\s+(?:ke\\s+)?gaming\\s+tips?$").find(l)?.let { return ModuleCall.Gaming(original(t, it.groupValues[1]), "") }

        // connected endpoints
        Regex("^(?:pc|computer|laptop)\\s*(?:par|pe|ko|me|mein)?\\s*[:,]?\\s*(.+)$").find(l)?.let { return ModuleCall.Pc(original(t, it.groupValues[1])) }
        Regex("^(?:send to|forward to|bhejo)\\s+(.+?)\\s*[:,]\\s*(.+)$").find(l)?.let { return ModuleCall.Forward(original(t, it.groupValues[1]), original(t, it.groupValues[2])) }
        Regex("^(?:turn|switch)\\s+(on|off)\\s+(?:the\\s+)?(.+)$").find(l)?.let { if (!notDevices.containsMatchIn(it.groupValues[2])) return ModuleCall.Home(original(t, it.groupValues[2]), it.groupValues[1]) }
        Regex("^(.+?)\\s+(on|off)\\s+karo$").find(l)?.let { if (!notDevices.containsMatchIn(it.groupValues[1])) return ModuleCall.Home(original(t, it.groupValues[1]), it.groupValues[2]) }
        return null
    }

    private fun original(t: String, lowered: String): String {
        val i = t.lowercase().indexOf(lowered.lowercase())
        return if (i >= 0) t.substring(i, i + lowered.length).trim() else lowered.trim()
    }
}
