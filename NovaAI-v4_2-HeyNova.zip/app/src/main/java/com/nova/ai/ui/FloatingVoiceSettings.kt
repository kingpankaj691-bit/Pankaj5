package com.nova.ai.ui

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.jarvis.VoskModelManager
import com.nova.ai.jarvis.WakePhrases
import com.nova.ai.voice.NovaSession
import com.nova.ai.voice.NovaVoiceForegroundService
import com.nova.ai.voice.VoicePermissionManager
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import com.nova.ai.jarvis.WakeVocab
import kotlinx.coroutines.launch

/**
 * "Nova Floating Voice Assistant": Hey Nova, the Galaxy Orb, wake phrases, effects, battery saving, microphone privacy, tests and a
 * permission checklist. Everything here writes the same JarvisPrefs / Prefs the rest of Nova already uses.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun NovaFloatingVoiceSettings(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val jp = remember { JarvisPrefs(ctx) }
    val scope = rememberCoroutineScope()
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }

    var hey by remember { mutableStateOf(jp.heyNova) }
    var orbOn by remember { mutableStateOf(jp.orb) }
    var idleSmall by remember { mutableStateOf(jp.orbIdleMinimized) }
    var reduced by remember { mutableStateOf(jp.orbReduced) }
    var battery by remember { mutableStateOf(jp.batterySaver) }
    var haptics by remember { mutableStateOf(jp.orbHaptics) }
    var name by remember { mutableStateOf(jp.wakeName) }
    var phraseVersion by remember { mutableIntStateOf(0) }       // bumps on every phrase / name change
    var plan by remember { mutableStateOf<WakePhrases.Plan?>(null) }
    var lang by remember { mutableStateOf(vm.prefs.language) }
    var pending by remember { mutableStateOf(false) }          // a change that needs the voice engine to restart
    var note by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var baseline by remember { mutableIntStateOf(0) }
    var testMsg by remember { mutableStateOf("") }
    var orbMsg by remember { mutableStateOf("") }

    val running by VoiceState.running.collectAsState()
    val paused by VoiceState.paused.collectAsState()
    val heard by NovaSession.wakeCount.collectAsState()
    val voskStatus by VoskModelManager.status.collectAsState()

    val micOk = remember(tick, refresh) { VoicePermissionManager.hasMic(ctx) }
    val notifOk = remember(tick, refresh) { VoicePermissionManager.notificationsAllowed(ctx) }
    val overlayOk = remember(tick, refresh) { Settings.canDrawOverlays(ctx) }
    val modelOk = remember(tick, refresh, voskStatus) { VoskModelManager.isInstalled(ctx, WakePhrases.EN) }
    val hiModelOk = remember(tick, refresh, voskStatus) { VoskModelManager.isInstalled(ctx, WakePhrases.HI) }
    val batteryFree = remember(tick, refresh) { try { (ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) } catch (e: Exception) { false } }

    /** Starts Background Voice, or applies the new settings to it when it is already running. */
    fun startOrApply() {
        if (!VoicePermissionManager.canStart(ctx)) { note = VoicePermissionManager.missingExplanation(ctx) ?: ""; return }
        if (running) NovaVoiceForegroundService.applySettings(ctx) else startMic(ctx)
        pending = false; note = ""
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++; if (jp.heyNova) startOrApply() }

    LaunchedEffect(heard) {
        if (testing && heard > baseline) { testing = false; testMsg = "Heard \"${NovaSession.lastWakeHeard.value}\". The wake word works." }
    }
    LaunchedEffect(testing) {
        if (testing) { delay(20_000); if (testing) { testing = false; testMsg = "Nothing heard in 20 seconds. Say it clearly near the phone, check the model below is installed, or try another wake phrase." } }
    }

    // Which phrases the installed models can really recognize (reads each model's word list, so off the main thread)
    LaunchedEffect(phraseVersion, tick, refresh, voskStatus) {
        WakeVocab.forget()
        plan = withContext(Dispatchers.IO) { WakeVocab.planFor(ctx, jp) }
    }
    // Phrase changes reach the running wake engine by themselves: wait for you to finish, then rebuild its recognizers once.
    LaunchedEffect(phraseVersion) {
        if (phraseVersion > 0) { delay(1_200); if (running && !paused) NovaVoiceForegroundService.applySettings(ctx); pending = false }
    }
    val shown = remember(phraseVersion) { jp.enabledPhrases().sortedByDescending { it.id == jp.defaultPhraseId }.map { it.label }.ifEmpty { listOf("Hey Nova") } }

    GlassSettingSection("Nova Floating Voice Assistant") {
        GText("Say \"Hey Nova\" in any app. A glowing orb appears over it, Nova listens, answers by voice, and the orb disappears when you are done.", size = 13.sp, color = g.subtext)

        ToggleRow("Enable Hey Nova", "The wake phrase is detected on this phone. Nothing is sent to Gemini or any cloud service before you say it.", hey) { on ->
            hey = on; jp.heyNova = on
            idleSmall = jp.orbIdleMinimized
            if (on && overlayOk && !orbOn) { orbOn = true; jp.orb = true }
            if (on) {
                if (!micOk || !notifOk) permLauncher.launch(VoicePermissionManager.runtimePermissions()) else startOrApply()
            } else {
                pending = running
            }
        }
        ToggleRow("Enable floating Galaxy Orb", "Shows the orb over other apps. Needs \"Display over other apps\".", orbOn) { orbOn = it; jp.orb = it; pending = running }
        if (orbOn && !overlayOk) GlassButton("Allow display over other apps", { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth())

        GText("Wake word", size = 13.sp)
        GlassTextField(name, { name = it; jp.wakeName = it; phraseVersion++ }, Modifier.fillMaxWidth(), placeholder = "Name you call me (nova, jarvis, max...)")
        WakeWordManager(jp, name, plan) { phraseVersion++ }

        GText("Voice language", size = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "Auto (Hindi / English / Hinglish)", "english" to "English", "hindi" to "Hindi", "hinglish" to "Hinglish").forEach { (id, label) ->
                GlassChip(label, lang == id, { lang = id; vm.prefs.language = id })
            }
        }
        GText("Applies to the next conversation. Nova follows your language, including Hinglish, in Auto.", size = 12.sp, color = g.subtext)

        GText("Orb animation", size = 13.sp)
        ToggleRow("Keep a small orb on screen when idle", "Off: the orb is hidden until you say the wake phrase.", idleSmall) { idleSmall = it; jp.orbIdleMinimized = it; FloatingOrb.current?.refresh() }
        ToggleRow("Reduced effects", "Fewer particles and about 20 frames per second. Saves battery.", reduced) { reduced = it; jp.orbReduced = it; FloatingOrb.current?.refresh() }
        ToggleRow("Haptic feedback", "A short tick when Nova starts listening.", haptics) { haptics = it; jp.orbHaptics = it }
        ToggleRow("Battery-saving mode", "Reduced effects, the wake recognizer skips silence, and conversations close sooner. Android's own battery saver also reduces the orb effects automatically.", battery) { battery = it; jp.batterySaver = it; pending = running; FloatingOrb.current?.refresh() }

        if (pending) {
            GText("Some changes need the voice engine to restart (the microphone is re-opened once).", size = 12.sp, color = g.accent)
            GlassButton("Apply changes", { startOrApply() }, Modifier.fillMaxWidth(), primary = true)
        }

        GText("Microphone privacy", size = 13.sp)
        ToggleRow("Pause microphone", if (running) "Turns the microphone fully off until you switch it back on. Hey Nova will not hear anything while paused." else "Background Voice is off, so the microphone is not in use.", paused) { on -> if (on) pauseMic(ctx) else resumeMic(ctx) }
        GText(
            when {
                !running -> "Microphone: off."
                paused -> "Microphone: off (paused)."
                hey -> "Microphone: on, listening only for the wake phrase on this phone. Android shows its microphone indicator and Nova shows a notification while it is on."
                else -> "Microphone: on (Background Voice). Android shows its microphone indicator and Nova shows a notification while it is on."
            }, size = 12.sp, color = g.subtext
        )

        GText("Tests", size = 13.sp)
        GlassButton(if (testing) "Say \"${shown.first()}\" now…" else "Test voice activation", {
            if (!hey) { testMsg = "Turn on Hey Nova first." }
            else if (plan?.isEmpty != false) { testMsg = "No wake phrase is ready yet. Download an offline model (see below) and check the phrase list." }
            else { baseline = heard; testMsg = ""; testing = true; if (!running || paused) { if (paused) resumeMic(ctx) else startOrApply() } }
        }, Modifier.fillMaxWidth(), enabled = !testing)
        if (testMsg.isNotBlank()) GText(testMsg, size = 12.sp, color = g.accent)
        GlassButton("Test floating orb", { orbMsg = if (FloatingOrb.demo(ctx)) "Playing listening, thinking and speaking over this screen…" else "Allow display over other apps first." }, Modifier.fillMaxWidth())
        if (orbMsg.isNotBlank()) GText(orbMsg, size = 12.sp, color = g.accent)
        if (note.isNotBlank()) GText(note, size = 12.sp, color = g.accent)

        GText("Permissions and status", size = 13.sp)
        GlassListItem("Microphone permission", if (micOk) "Allowed" else "Missing. Hey Nova cannot hear you without it.", trailing = {
            if (!micOk) GlassButton("Allow", { permLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO)) })
        })
        GlassListItem("Notifications", if (notifOk) "Allowed" else "Missing. Android requires the \"microphone is on\" notification, so Nova will not start without it. Allow it in Settings > Apps > Nova AI > Notifications.", trailing = {
            if (!notifOk) GlassButton("Open", { openAppSettings(ctx) })
        })
        GlassListItem("Display over other apps", if (overlayOk) "Allowed" else "Missing. Nova still talks, but the orb cannot appear over other apps. Enable \"Allow display over other apps\" for Nova AI.", trailing = {
            if (!overlayOk) GlassButton("Allow", { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        })
        GlassListItem("Offline wake-word model (English, India)", if (modelOk) "Installed" else "Not installed (about ${VoskModelManager.spec(WakePhrases.EN).sizeMb} MB). Hey Nova stays silent until it is downloaded.", trailing = {
            if (!modelOk) GlassButton("Download", { scope.launch { note = VoskModelManager.download(ctx, WakePhrases.EN) ?: ""; refresh++ } })
        })
        GlassListItem("Offline model for Hindi / Hinglish phrases", if (hiModelOk) "Installed" else "Not installed. Needed for \"Jaan, kaisi ho?\", \"Hello Jaan, suno\", \"Nova, meri baat suno\" and Hindi custom phrases.", trailing = {
            if (!hiModelOk) GlassButton("Download", { scope.launch { note = VoskModelManager.download(ctx, WakePhrases.HI) ?: ""; refresh++ } })
        })
        if (voskStatus.isNotBlank()) GText(voskStatus, size = 12.sp, color = g.accent)
        GlassListItem("Battery optimization", if (batteryFree) "Unrestricted. Android is least likely to stop Nova in the background." else "Optimized. Some phones stop background microphone apps. For reliable Hey Nova, set Nova AI to Unrestricted / Don't optimize.", trailing = {
            if (!batteryFree) GlassButton("Open", { try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { openAppSettings(ctx) } })
        })
        GlassListItem("Hey Nova service", if (!running) "Off. It starts when you turn Hey Nova on." else if (paused) "Paused (microphone off)" else "Running")
        GText("After a phone restart Android does not allow apps to start the microphone in the background. Tap \"Resume listening\" in Nova's notification, or open Nova once.", size = 12.sp, color = g.subtext)
    }
}

