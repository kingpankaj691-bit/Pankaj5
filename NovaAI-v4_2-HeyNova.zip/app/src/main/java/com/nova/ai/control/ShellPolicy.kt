package com.nova.ai.control

/**
 * The secure command manager's gatekeeper. Nova never runs free-form shell text: a command must match one of the
 * allow-listed shapes below, with every value range-checked, and contain no shell metacharacters.
 * The same check runs again inside the Shizuku shell process, so a bug in the app cannot widen what the shell will run.
 */
object ShellPolicy {
    enum class Risk { READ, SAFE, CONFIRM }

    sealed class Decision {
        data class Allow(val risk: Risk) : Decision()
        data class Deny(val reason: String) : Decision()
    }

    private val meta = Regex("""[;&|`$<>\\\n\r(){}*?"'~!#^]""")
    private val pkgRx = Regex("""[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+""")

    /** Packages Nova will never force-stop: the system, this app, Shizuku itself, and security-critical apps. */
    private val protectedPrefixes = listOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.providers",
        "com.android.server", "com.android.launcher", "com.google.android.gms", "com.google.android.gsf",
        "com.nova.ai", "moe.shizuku.privileged.api", "com.termux"
    )

    private val keys = setOf(
        "KEYCODE_BACK", "KEYCODE_HOME", "KEYCODE_APP_SWITCH", "KEYCODE_VOLUME_UP", "KEYCODE_VOLUME_DOWN",
        "KEYCODE_MEDIA_PLAY_PAUSE", "KEYCODE_MEDIA_NEXT", "KEYCODE_MEDIA_PREVIOUS", "KEYCODE_WAKEUP", "KEYCODE_DPAD_UP",
        "KEYCODE_DPAD_DOWN", "KEYCODE_DPAD_LEFT", "KEYCODE_DPAD_RIGHT", "KEYCODE_ENTER", "KEYCODE_TAB", "KEYCODE_ESCAPE"
    )

    fun isProtectedPackage(pkg: String) = protectedPrefixes.any { pkg == it || pkg.startsWith("$it.") }

    private fun range(s: String, lo: Long, hi: Long) = s.toLongOrNull()?.let { it in lo..hi } == true

    fun validate(command: String): Decision {
        val c = command.trim().replace(Regex(" +"), " ")
        if (c.isEmpty()) return Decision.Deny("Empty command.")
        if (c.length > 300) return Decision.Deny("Command too long.")
        if (c.any { it.isISOControl() }) return Decision.Deny("Control characters are not allowed.")
        if (meta.containsMatchIn(c)) return Decision.Deny("Shell operators and quotes are not allowed.")
        val p = c.split(' ')

        fun allow(r: Risk) = Decision.Allow(r)
        fun deny(why: String) = Decision.Deny(why)

        return when (p[0]) {
            "settings" -> when {
                p.size == 4 && p[1] == "get" && p[2] in setOf("system", "global", "secure") && p[3].matches(Regex("[a-z0-9_]+")) -> allow(Risk.READ)
                p.size == 5 && p[1] == "put" && p[2] == "system" -> when (p[3]) {
                    "screen_brightness" -> if (range(p[4], 1, 255)) allow(Risk.SAFE) else deny("Brightness must be 1-255.")
                    "screen_brightness_mode", "accelerometer_rotation" -> if (range(p[4], 0, 1)) allow(Risk.SAFE) else deny("Value must be 0 or 1.")
                    "user_rotation" -> if (range(p[4], 0, 3)) allow(Risk.SAFE) else deny("Rotation must be 0-3.")
                    "screen_off_timeout" -> if (range(p[4], 5_000, 1_800_000)) allow(Risk.SAFE) else deny("Timeout must be 5 s to 30 min.")
                    else -> deny("That system setting is not on Nova's allow-list.")
                }
                else -> deny("Only reading settings, or changing the allow-listed display settings, is permitted.")
            }
            "svc" -> if (p.size == 3 && p[1] in setOf("wifi", "bluetooth") && p[2] in setOf("enable", "disable")) allow(Risk.SAFE) else deny("Only Wi-Fi and Bluetooth can be toggled with svc.")
            "cmd" -> when {
                p.size == 4 && p[1] == "notification" && p[2] == "set_dnd" && p[3] in setOf("on", "off", "priority", "none", "alarms") -> allow(Risk.SAFE)
                p.size == 6 && p[1] == "media_session" && p[2] == "volume" && p[3] == "--stream" && range(p[4], 0, 10) && p[5] == "--get" -> allow(Risk.READ)
                p.size == 7 && p[1] == "media_session" && p[2] == "volume" && p[3] == "--stream" && range(p[4], 0, 10) && p[5] == "--set" && range(p[6], 0, 100) -> allow(Risk.SAFE)
                p.size == 3 && p[1] == "statusbar" && p[2] in setOf("expand-notifications", "expand-settings", "collapse") -> allow(Risk.SAFE)
                p.size in 4..5 && p[1] == "package" && p[2] == "list" && p[3] == "packages" && (p.size == 4 || p[4] in setOf("-3", "-s")) -> allow(Risk.READ)
                else -> deny("That cmd service is not on Nova's allow-list.")
            }
            "input" -> when {
                p.size == 3 && p[1] == "keyevent" && p[2] in keys -> allow(Risk.SAFE)
                p.size == 4 && p[1] == "tap" && range(p[2], 0, 10_000) && range(p[3], 0, 10_000) -> allow(Risk.SAFE)
                p.size in 6..7 && p[1] == "swipe" && p.drop(2).all { range(it, 0, 10_000) } -> allow(Risk.SAFE)
                p.size == 3 && p[1] == "text" && p[2].matches(Regex("[A-Za-z0-9%._@-]{1,200}")) -> allow(Risk.SAFE)
                else -> deny("That input command is not on Nova's allow-list.")
            }
            "am" -> when {
                p.size == 3 && p[1] == "force-stop" && p[2].matches(pkgRx) ->
                    if (isProtectedPackage(p[2])) deny("${p[2]} is a protected system or security app.") else allow(Risk.CONFIRM)
                else -> deny("Only force-stop is allowed with am.")
            }
            "pm" -> if (p.size in 3..4 && p[1] == "list" && p[2] == "packages" && (p.size == 3 || p[3] in setOf("-3", "-s"))) allow(Risk.READ)
                    else deny("Installing, uninstalling, clearing data or disabling apps is never done silently. Use Android's own screens.")
            "dumpsys" -> if (p.size == 2 && p[1] == "battery") allow(Risk.READ) else deny("Only 'dumpsys battery' is allowed.")
            "wm" -> if (p.size == 2 && p[1] in setOf("size", "density")) allow(Risk.READ) else deny("wm may only be read.")
            "getprop" -> if (p.size == 2 && p[1].matches(Regex("ro\\.[a-z0-9._]+"))) allow(Risk.READ) else deny("Only read-only ro.* properties.")
            "ls", "cp", "mv", "mkdir", "rm" -> fileCommand(p)
            else -> deny("'${p[0]}' is not an allow-listed command.")
        }
    }

    // ── File Manager (Shizuku): shared storage only, no spaces/wildcards, single files, never inside Android/ except reading ──
    private val sharedPath = Regex("""/(storage/emulated/[0-9]+|sdcard)(/[A-Za-z0-9._+@=,-]+)*""")
    private val androidDir = Regex("""/(storage/emulated/[0-9]+|sdcard)/Android(/.*)?""")

    private fun isShared(x: String) = x.matches(sharedPath) && x.split('/').none { it == "." || it == ".." }
    private fun inAndroid(x: String) = androidDir.matches(x)
    private fun depth(x: String): Int { val n = x.split('/').count { it.isNotEmpty() }; return if (x.startsWith("/sdcard")) n - 1 else n - 3 }

    private fun fileCommand(p: List<String>): Decision {
        fun deny(why: String) = Decision.Deny(why)
        return when (p[0]) {
            "ls" -> if (p.size == 3 && p[1] == "-1p" && isShared(p[2])) Decision.Allow(Risk.READ) else deny("Only 'ls -1p <shared-storage path>' is allowed.")
            "cp" -> if (p.size == 3 && isShared(p[1]) && isShared(p[2]) && !inAndroid(p[2])) Decision.Allow(Risk.CONFIRM) else deny("cp works between shared-storage paths, never into Android/, and without spaces or wildcards.")
            "mv" -> if (p.size == 3 && isShared(p[1]) && isShared(p[2]) && !inAndroid(p[1]) && !inAndroid(p[2]) && depth(p[1]) >= 2) Decision.Allow(Risk.CONFIRM) else deny("mv works on files inside shared storage, never in Android/, and without spaces or wildcards.")
            "mkdir" -> if (p.size == 2 && isShared(p[1]) && !inAndroid(p[1]) && depth(p[1]) >= 1) Decision.Allow(Risk.CONFIRM) else deny("mkdir works inside shared storage, never in Android/.")
            "rm" -> if (p.size == 2 && isShared(p[1]) && !inAndroid(p[1]) && depth(p[1]) >= 2) Decision.Allow(Risk.CONFIRM) else deny("rm deletes one file (no flags, no folders) in shared storage, never in Android/.")
            else -> deny("Not allowed.")
        }
    }

    /** Escapes text for `input text` (spaces become %s). Returns null when the text has characters the shell path can't type safely. */
    fun inputTextArg(text: String): String? {
        val t = text.take(200).replace(" ", "%s")
        return if (t.isNotEmpty() && t.matches(Regex("[A-Za-z0-9%._@-]{1,200}"))) t else null
    }
}
