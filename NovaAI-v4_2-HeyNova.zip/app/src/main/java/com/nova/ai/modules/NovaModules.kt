package com.nova.ai.modules

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.MediaStore
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.nova.ai.automation.AutomationEngine
import com.nova.ai.automation.Routine
import com.nova.ai.device.DeviceController
import com.nova.ai.future.*
import com.nova.ai.memory.MemoryDb
import com.nova.ai.security.Prefs
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun lang(hint: String) = if (hint.isBlank()) "" else " $hint"

class WeatherImpl(private val ctx: Context, private val prefs: Prefs) : WeatherModule {
    override val id = "weather"; override val title = "Weather"

    private fun codeText(c: Int) = when (c) {
        0 -> "clear sky"; 1 -> "mostly clear"; 2 -> "partly cloudy"; 3 -> "overcast"; 45, 48 -> "fog"
        51, 53, 55 -> "drizzle"; 56, 57 -> "freezing drizzle"; 61 -> "light rain"; 63 -> "rain"; 65 -> "heavy rain"
        66, 67 -> "freezing rain"; 71, 73, 75, 77 -> "snow"; 80, 81, 82 -> "rain showers"; 85, 86 -> "snow showers"
        95 -> "thunderstorm"; 96, 99 -> "thunderstorm with hail"; else -> "mixed weather"
    }

    private fun lastKnown(): Pair<Double, Double>? {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }?.let { it.latitude to it.longitude }
        } catch (e: SecurityException) { null }
    }

    override suspend fun forecast(place: String?): String {
        var lat: Double; var lon: Double; var name: String
        val q = place?.takeIf { it.isNotBlank() } ?: prefs.homeCity.takeIf { it.isNotBlank() }
        if (q != null) {
            val g = Net.getJson("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + Uri.encode(q))
                ?: return "I couldn't reach the weather service. Check your internet."
            val r = g.optJSONArray("results")?.optJSONObject(0) ?: return "I couldn't find a place called $q."
            lat = r.getDouble("latitude"); lon = r.getDouble("longitude"); name = r.optString("name", q)
        } else {
            val l = lastKnown() ?: return "Which city? Say \"weather in Delhi\", or set a home city in Tools."
            lat = l.first; lon = l.second; name = "your location"
        }
        val j = Net.getJson("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&timezone=auto&forecast_days=3" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code")
            ?: return "I couldn't reach the weather service. Check your internet."
        val c = j.optJSONObject("current") ?: return "The weather service returned no data."
        val d = j.optJSONObject("daily")
        val sb = StringBuilder("$name: ${c.optDouble("temperature_2m").toInt()}°C, ${codeText(c.optInt("weather_code"))}, feels like ${c.optDouble("apparent_temperature").toInt()}°C, humidity ${c.optInt("relative_humidity_2m")}%, wind ${c.optDouble("wind_speed_10m").toInt()} km/h.")
        if (d != null) {
            val mx = d.optJSONArray("temperature_2m_max"); val mn = d.optJSONArray("temperature_2m_min"); val rain = d.optJSONArray("precipitation_probability_max")
            val labels = listOf("Today", "Tomorrow", "Day after")
            for (i in 0 until minOf(3, mx?.length() ?: 0)) sb.append("\n${labels[i]}: ${mn?.optDouble(i)?.toInt()}–${mx?.optDouble(i)?.toInt()}°C, rain chance ${rain?.optInt(i)}%.")
        }
        return sb.toString()
    }
}

class CalendarImpl(private val ctx: Context) : CalendarModule {
    override val id = "calendar"; override val title = "Calendar"
    override suspend fun upcoming(days: Int): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
            return "I need Calendar permission. Grant it in Permissions."
        val now = System.currentTimeMillis()
        val end = now + days.coerceIn(1, 30) * 86400000L
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { android.content.ContentUris.appendId(it, now); android.content.ContentUris.appendId(it, end) }.build()
        val out = ArrayList<String>()
        try {
            ctx.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                val f = SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()); val fd = SimpleDateFormat("EEE d MMM", Locale.getDefault())
                while (c.moveToNext() && out.size < 8) {
                    val t = c.getString(0).orEmpty().ifBlank { "(no title)" }
                    val b = Date(c.getLong(1))
                    out.add("• $t — " + if (c.getInt(2) == 1) fd.format(b) + " (all day)" else f.format(b))
                }
            }
        } catch (e: Exception) { return "I couldn't read the calendar." }
        return if (out.isEmpty()) "Nothing on your calendar for the next $days day${if (days > 1) "s" else ""}." else "Upcoming:\n" + out.joinToString("\n")
    }
}

class TranslationImpl(private val task: GeminiTask) : TranslationModule {
    override val id = "translation"; override val title = "Translation"
    override suspend fun translate(text: String, from: String?, to: String): String =
        task.run("You are a precise translator. Output only the translation into $to${if (from != null) " from $from" else ""}. Keep names, numbers and tone. No notes.", text, maxTokens = 800)
}

class MusicImpl(private val ctx: Context, private val device: DeviceController) : MusicModule {
    override val id = "music"; override val title = "Music"
    private fun key(code: Int): Boolean = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); true
    } catch (e: Exception) { false }
    override fun play(query: String): Boolean {
        if (query.isBlank()) return key(KeyEvent.KEYCODE_MEDIA_PLAY)
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(SearchManager.QUERY, query).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        return device.launch(i)
    }
    override fun pause() = key(KeyEvent.KEYCODE_MEDIA_PAUSE)
    fun next() = key(KeyEvent.KEYCODE_MEDIA_NEXT)
    fun previous() = key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    fun resume() = key(KeyEvent.KEYCODE_MEDIA_PLAY)
}

class GeminiBackedStudy(private val task: GeminiTask) : StudyAssistantModule {
    override val id = "study"; override val title = "Study assistant"
    override suspend fun quiz(topic: String) = task.run("You are a patient tutor. Make a 5-question quiz on the topic, mixing easy and medium. Number the questions, do NOT give answers; end with \"Say answers when you are ready.\" Plain text.", topic)
}
class GeminiBackedGaming(private val task: GeminiTask) : GamingAssistantModule {
    override val id = "gaming"; override val title = "Gaming assistant"
    override suspend fun tip(game: String, question: String) = task.run("You are a concise gaming coach. Give practical tips for $game. If you are unsure about the current patch or version, say so. Plain text, short.", question.ifBlank { "Give me 5 beginner tips." })
}
class GeminiBackedTravel(private val task: GeminiTask) : TravelAssistantModule {
    override val id = "travel"; override val title = "Travel assistant"
    override suspend fun plan(destination: String, days: Int) = task.run("You are a travel planner. Make a day-by-day plan with realistic pacing, local food ideas and a short packing list. Prices, opening hours and visa rules change: tell the user to verify them. Plain text.", "$days-day trip to $destination", maxTokens = 1400)
}
class GeminiBackedProductivity(private val task: GeminiTask) : ProductivityModule {
    override val id = "productivity"; override val title = "Productivity assistant"
    override suspend fun plan(goals: List<String>) = task.run("You are a productivity coach. Turn the goals into a realistic schedule for the day with priorities, short breaks and the single most important task first. Plain text.", goals.joinToString("; "), maxTokens = 1000)
}

class ImageImpl(private val task: GeminiTask) : ImageUnderstandingModule, CameraAssistantModule, DocumentModule, PdfModule {
    override val id = "image_understanding"; override val title = "Image understanding"
    private val sys = "You analyze user-provided files for a voice assistant. Answer only from the content. Don't reveal passwords, OTPs or card numbers if visible. Short plain text."
    override suspend fun describe(image: ByteArray, question: String) = task.run(sys, question.ifBlank { "Describe this image." }, image, "image/jpeg")
    override suspend fun analyze(photo: ByteArray, question: String) = describe(photo, question)
    override suspend fun summarize(uri: String, question: String) = task.run(sys, question.ifBlank { "Summarize this document." })
    override suspend fun ask(uri: String, question: String) = task.run(sys, question.ifBlank { "Summarize this PDF." })

    /** Reads a user-picked file (Storage Access Framework) and asks Gemini about it. */
    suspend fun askAboutFile(ctx: Context, uri: Uri, question: String): String {
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        return try {
            when {
                mime.startsWith("image/") -> {
                    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return "I couldn't open that image."
                    describe(jpeg(bmp), question)
                }
                mime == "application/pdf" -> {
                    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return "I couldn't open that PDF."
                    if (bytes.size > 15_000_000) "That PDF is too large (limit about 15 MB)." else task.run(sys, question.ifBlank { "Summarize this PDF." }, bytes, "application/pdf", 1200)
                }
                mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") -> {
                    val txt = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return "I couldn't open that file."
                    task.run(sys, question.ifBlank { "Summarize this document." } + "\n\n--- document ---\n" + txt.take(60000), maxTokens = 1000)
                }
                else -> "I can read images, PDFs and text files. This type ($mime) isn't supported yet."
            }
        } catch (e: Exception) { "I couldn't read that file." }
    }

    /** File Manager: text that was extracted on the phone and approved by the user in a consent dialog. */
    suspend fun askAboutText(text: String, question: String): String = try {
        task.run(sys, question.ifBlank { "Summarize this document." } + "\n\n--- document ---\n" + text.take(30000), maxTokens = 1000)
    } catch (e: Exception) { "I couldn't get an answer right now." }

    fun jpeg(b: Bitmap, maxSide: Int = 1600): ByteArray {
        val s = minOf(1f, maxSide.toFloat() / maxOf(b.width, b.height))
        val bm = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
        return ByteArrayOutputStream().also { bm.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
    }
}

/** Smart home, PC control and multi-device all use the same safe pattern: POST to an endpoint YOU run and configure. */
class WebhookImpl(private val prefs: Prefs, private val kind: String) : SmartHomeModule, PcControlModule, MultiDeviceModule {
    override val id = kind
    override val title = when (kind) { "smart_home" -> "Smart home"; "pc_control" -> "PC control"; else -> "Multi-device" }
    private fun url() = when (kind) { "smart_home" -> prefs.hookHome; "pc_control" -> prefs.hookPc; else -> prefs.hookDevices }
    private suspend fun send(body: JSONObject): String {
        val u = url()
        if (u.isBlank()) return "No endpoint is set for $title. Add it in Tools → Connections."
        val (ok, txt) = Net.postJson(u, prefs.hookToken, body.put("source", "NOVA"))
        return if (ok) "Done. ($txt)" else "⚠ $txt"
    }
    override suspend fun command(device: String, action: String) = send(JSONObject().put("type", "smart_home").put("device", device).put("action", action))
    override suspend fun send(command: String) = send(JSONObject().put("type", "pc").put("command", command))
    override suspend fun forward(deviceName: String, command: String) = send(JSONObject().put("type", "forward").put("device", deviceName).put("command", command))
}

class RemindersImpl(private val automation: AutomationEngine) : ReminderModule {
    override val id = "reminders"; override val title = "Reminders"
    override fun schedule(text: String, atMillis: Long): Boolean {
        val now = System.currentTimeMillis()
        automation.create(Routine(0, "Reminder", "TIME_ONCE", "", "NOTIFY", text, true, false, atMillis.coerceAtLeast(now + 5000), now, 0)); return true
    }
}
class NotesImpl(private val db: MemoryDb) : NotesModule {
    override val id = "notes"; override val title = "Notes"
    override fun add(text: String) = db.addNote(text)
    override fun all(): List<String> = db.notes().map { it.second }
}

/** Registers every implemented module so the rest of the app can look them up. */
class NovaModules(val ctx: Context, val prefs: Prefs, db: MemoryDb, automation: AutomationEngine, device: DeviceController) {
    val task = GeminiTask(prefs)
    val weather = WeatherImpl(ctx, prefs); val calendar = CalendarImpl(ctx); val translation = TranslationImpl(task)
    val music = MusicImpl(ctx, device); val study = GeminiBackedStudy(task); val gaming = GeminiBackedGaming(task)
    val travel = GeminiBackedTravel(task); val productivity = GeminiBackedProductivity(task); val image = ImageImpl(task)
    val home = WebhookImpl(prefs, "smart_home"); val pc = WebhookImpl(prefs, "pc_control"); val devices = WebhookImpl(prefs, "multi_device")
    init {
        listOf<NovaModule>(weather, calendar, translation, music, study, gaming, travel, productivity, image, home, pc, devices,
            RemindersImpl(automation), NotesImpl(db)).forEach { ModuleRegistry.register(it) }
    }
}
