package com.nova.ai.jarvis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.nova.ai.automation.Notifier
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Runs once a minute inside the Background Voice service: spoken morning briefing at your chosen time,
 * "meeting in 15 minutes", and a low-battery warning. Each message is said once. Nothing runs when Background Voice is off.
 */
class ProactiveEngine(private val ctx: Context, private val prefs: Prefs) {
    private val jp = JarvisPrefs(ctx)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val said = HashSet<String>()
    private var batteryAt = 0L

    fun start() {
        if (job != null) return
        job = scope.launch {
            while (isActive) {
                try { tick() } catch (e: Exception) { }
                delay(60_000)
            }
        }
    }

    fun stop() { job?.cancel(); job = null; scope.cancel() }

    /** Not while a call is going on. */
    private fun quiet(): Boolean = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode != AudioManager.MODE_NORMAL

    private suspend fun tick() {
        if (quiet()) return
        val cal = Calendar.getInstance()
        val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
        val minute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        val bm = jp.briefingMinute
        if (bm >= 0 && jp.lastBriefingDay != day && minute in bm..(bm + 30)) {
            jp.lastBriefingDay = day
            val text = Briefing.build(ctx, prefs)
            Notifier.post(ctx, 4300, "Your briefing", text)
            Announcer.speak(ctx, text)
        }

        if (!jp.proactive) return
        // Calendar: something starts in the next 5 to 20 minutes.
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED) {
            val now = System.currentTimeMillis()
            val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                .also { android.content.ContentUris.appendId(it, now + 5 * 60_000L); android.content.ContentUris.appendId(it, now + 20 * 60_000L) }.build()
            try {
                ctx.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                    null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                    while (c.moveToNext()) {
                        if (c.getInt(2) == 1) continue
                        val key = "ev-" + c.getString(0) + c.getLong(1)
                        if (said.add(key)) {
                            val mins = ((c.getLong(1) - now) / 60000L).toInt().coerceAtLeast(1)
                            val msg = "${c.getString(0).orEmpty().ifBlank { "Aapka event" }} $mins minute mein shuru hoga."
                            Notifier.post(ctx, 4301, "Coming up", msg)
                            Announcer.speak(ctx, msg)
                        }
                    }
                }
            } catch (e: Exception) { }
        }
        // Battery: low and not charging, at most once every 3 hours.
        val bat = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bat.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (pct in 1..15 && !bat.isCharging && System.currentTimeMillis() - batteryAt > 3 * 3600_000L) {
            batteryAt = System.currentTimeMillis()
            Announcer.speak(ctx, "Battery sirf $pct percent hai. Charger laga lijiye.")
        }
        if (said.size > 200) said.clear()
    }
}
