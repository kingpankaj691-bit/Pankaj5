package com.nova.ai.voice

/** The four orb animation states. */
enum class OrbPhase { IDLE, LISTENING, THINKING, SPEAKING }

/** Pure rule that turns the pipeline's flags into one orb phase (unit tested on the JVM). */
object OrbPhases {
    /**
     * @param gated   the offline wake gate is in charge (Hey Nova on)
     * @param awake   a conversation is open (the wake phrase was heard and has not timed out)
     * @param working Nova is busy with an on-screen task (screen agent, OCR, translate)
     */
    fun derive(
        override: OrbPhase?, micRunning: Boolean, paused: Boolean, gated: Boolean, awake: Boolean,
        speaking: Boolean, thinking: Boolean, working: Boolean
    ): OrbPhase {
        if (override != null) return override
        if (working) return OrbPhase.THINKING
        if (!micRunning || paused) return OrbPhase.IDLE
        if (speaking) return OrbPhase.SPEAKING
        if (thinking) return OrbPhase.THINKING
        return if (gated && awake) OrbPhase.LISTENING else OrbPhase.IDLE
    }

    fun label(p: OrbPhase): String = when (p) {
        OrbPhase.LISTENING -> "Listening…"
        OrbPhase.THINKING -> "Nova is thinking"
        OrbPhase.SPEAKING -> "Nova is speaking"
        OrbPhase.IDLE -> ""
    }
}
