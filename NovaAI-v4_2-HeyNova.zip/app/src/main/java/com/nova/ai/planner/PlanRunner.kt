package com.nova.ai.planner

import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.accessibility.TextVerify
import com.nova.ai.device.DeviceController
import com.nova.ai.screen.ActionResult
import com.nova.ai.screen.ActionValidator
import com.nova.ai.screen.AppKind
import com.nova.ai.screen.AppUi
import com.nova.ai.screen.FailureKind
import com.nova.ai.screen.Failures
import com.nova.ai.screen.Kind
import com.nova.ai.screen.PageProblem
import com.nova.ai.screen.PlaybackOutcome
import com.nova.ai.screen.PlaybackVerdict
import com.nova.ai.screen.ScreenActionExecutor
import com.nova.ai.screen.ScreenSearch
import com.nova.ai.screen.ScreenSnapshot
import com.nova.ai.screen.UiElement
import com.nova.ai.screen.UiPlayback
import com.nova.ai.screen.Verdict
import com.nova.ai.screen.byId
import com.nova.ai.screen.cands
import com.nova.ai.screen.texts
import com.nova.ai.security.Prefs
import com.nova.ai.vision.Resolution
import com.nova.ai.vision.UIElementResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

class RunReport(val ok: Boolean, val message: String)

/**
 * CommandExecutor for screen plans: Plan → Permission check → Observe screen → Find element → Act → Wait for the UI →
 * Verify the real result → Report. It stops at the first step that cannot be proven and names ONE cause; steps that
 * already succeeded are kept in the report. It never claims a page loaded or a video plays without checking.
 */
class PlanRunner(
    private val prefs: Prefs,
    private val device: DeviceController,
    private val exec: ScreenActionExecutor,
    private val resolver: UIElementResolver,
    private val host: PlanHost
) {
    private val wa = WhatsAppFlow(prefs, device, exec, host)
    @Volatile var lastQuery: String = ""
    /** Package the current plan is working in (set by the open step, checked by later steps). */
    @Volatile private var appPkg: String = ""
    @Volatile private var audioWasActive = false
    @Volatile private var lastResultTitle = ""

    private fun t(hing: Boolean, hi: String, en: String) = if (hing) hi else en
    private fun fail(kind: FailureKind, h: Boolean, detail: String = "") = ActionResult(false, Failures.message(kind, detail, h))
    private fun workPkg(): String = appPkg.ifBlank { exec.foreground() }
    private fun clip(s: String, n: Int = 70) = if (s.length <= n) s else s.take(n - 1) + "…"

    suspend fun run(plan: Plan): RunReport {
        val h = plan.hinglish
        if (plan.touchesScreen) {
            // Only connection + master switch up front; the blocked-app rule is checked per action, against the app in front at that moment.
            val v = ActionValidator.baseFor(NovaAccessibilityService.instance != null, prefs.screenActionsOn, "")
            if (v is Verdict.Denied) return RunReport(false, v.reason)
        }
        if (plan.needsInternet && !device.hasInternet()) return RunReport(false, Failures.message(FailureKind.NO_INTERNET, "", h))
        appPkg = ""; lastResultTitle = ""
        val done = ArrayList<String>()
        for ((i, step) in plan.steps.withIndex()) {
            currentCoroutineContext().ensureActive()   // a cancelled task must not perform one more action
            host.progress(plan.summary())
            val r = try { runStep(step, h) } catch (e: CancellationException) { throw e } catch (e: Exception) { ActionResult(false, "Something went wrong: ${e.message}") }
            if (!r.ok) {
                val prefix = if (done.isEmpty()) "" else t(h, "Pehle ${done.joinToString(", ")} ho gaya. ", "Done so far: ${done.joinToString(", ")}. ")
                return RunReport(false, prefix + t(h, "Phir yahan ruk gaya: ", "Then I stopped: ") + r.message)
            }
            done.add(r.message.trimEnd('.'))
            if (i < plan.steps.lastIndex) delay(350)
        }
        return RunReport(true, if (done.size == 1) done[0] + "." else done.joinToString(". ") + ".")
    }

    private suspend fun gate(v: Verdict, what: String, h: Boolean): ActionResult? = when (v) {
        is Verdict.Denied -> ActionResult(false, v.reason)
        is Verdict.NeedsConfirm -> if (host.confirm(t(h, "${v.reason}. $what — kar doon?", "${v.reason}. $what — go ahead?"))) null else ActionResult(false, t(h, "Theek hai, cancel kar diya.", "Okay, cancelled."))
        Verdict.Allowed -> null
    }

    private suspend fun runStep(step: Step, h: Boolean): ActionResult = when (step) {
        is Step.OpenApp -> openApp(step.name, h)
        is Step.OpenBrowser -> openBrowser(step.name, h)
        Step.Back -> exec.back()
        Step.Home -> exec.home()
        Step.Recents -> exec.recents()
        Step.Notifications -> exec.notifications()
        Step.Describe -> ActionResult(true, exec.snapshot()?.outline(900) ?: "I can't see the screen.")
        is Step.Scroll -> exec.scrollSmart(step.down)
        is Step.Swipe -> exec.swipe(step.dir)
        is Step.Tap -> tapLike(step.query, h) { e -> exec.tapElement(e) }
        is Step.LongPress -> tapLike(step.query, h, long = true) { e -> exec.longPressElement(e) }
        is Step.DoubleTap -> tapLike(step.query, h, double = true) { e -> exec.doubleTapElement(e) }
        is Step.SearchInApp -> searchInApp(step.query, h)
        is Step.TypeInto -> typeInto(step.text, step.field, h)
        is Step.OpenResult -> openResult(step.ordinal, h)
        is Step.WhatsAppOpenChat -> wa.openChat(step.contact, h)
        is Step.WhatsAppSend -> wa.send(step.contact, step.message, h)
        Step.ReadWhatsApp -> wa.readVisible(h)
        Step.ReadResults -> readResults(h)
        Step.VerifyPlayback -> verifyPlayback(h)
        is Step.Find -> find(step.query, h)
    }

    // ───────── opening apps (proven foreground) ─────────
    private suspend fun openApp(name: String, h: Boolean): ActionResult {
        val (label, pkg) = device.findApp(name) ?: return fail(FailureKind.APP_NOT_INSTALLED, h, name)
        return launchAndConfirm(label, pkg, h)
    }

    private suspend fun openBrowser(name: String?, h: Boolean): ActionResult {
        val pkg: String
        if (!name.isNullOrBlank()) {
            pkg = device.findApp(name)?.second ?: return fail(FailureKind.BROWSER_NOT_INSTALLED, h, name)
        } else {
            pkg = prefs.browserPackage.takeIf { it.isNotBlank() && device.isInstalled(it) }
                ?: device.defaultBrowserPackage()
                ?: device.installedBrowserPackages().firstOrNull()
                ?: return fail(FailureKind.BROWSER_NOT_INSTALLED, h, "browser")
        }
        return launchAndConfirm(device.appLabel(pkg), pkg, h)
    }

    /** Launch (if needed), then wait until the app is REALLY in front and its screen can be read. */
    private suspend fun launchAndConfirm(label: String, pkg: String, h: Boolean): ActionResult {
        audioWasActive = device.isAudioPlaying()
        if (exec.foreground() != pkg) {
            val r = device.openPackage(pkg, label)
            if (!r.startsWith("Opening")) return ActionResult(false, r)
            if (!exec.waitForPackage(setOf(pkg), 6500)) return fail(FailureKind.APP_NOT_IN_FRONT, h, label)
        }
        appPkg = pkg
        exec.waitFor(4500) { it.pkg == pkg && it.elements.size >= 3 } ?: return fail(FailureKind.SCREEN_UNREADABLE, h, label)
        delay(300)
        return ActionResult(true, t(h, "$label khola", "Opened $label"))
    }

    // ───────── generic tap / type / find (unchanged behaviour, verified executor underneath) ─────────
    private suspend fun tapLike(query: String, h: Boolean, long: Boolean = false, double: Boolean = false, act: suspend (UiElement) -> ActionResult): ActionResult {
        val snap = awaitSnapshot() ?: return ActionResult(false, t(h, "Screen dikh nahi rahi. Screen Assistant on hai?", "I can't see the screen. Is Screen Assistant on?"))
        when (val res = resolver.resolve(query, snap)) {
            is Resolution.None -> return ActionResult(false, res.reason)
            is Resolution.Point -> {
                gate(ActionValidator.forGesture(prefs, ActionValidator.isRisky(res.label)), res.label, h)?.let { return it }
                return when {
                    long -> exec.longPressAt(res.x, res.y)
                    double -> exec.doubleTapAt(res.x, res.y)
                    else -> exec.tapAt(res.x, res.y)
                }.let { if (it.ok) ActionResult(true, t(h, "${res.label} tap kiya", "Tapped ${res.label}")) else it }
            }
            is Resolution.Nodes -> {
                val e = pick(res.matches.map { it.el to it.score }, query, h)
                    ?: return ActionResult(false, t(h, "Theek hai, kuch select nahi kiya.", "Okay, I didn't select anything."))
                gate(ActionValidator.forElement(prefs, e, query), e.label.take(40), h)?.let { return it }
                val r = act(e)
                if (r.ok && r.changed == false)
                    return ActionResult(false, t(h, "${e.label.take(40).ifBlank { query }} dabaya par screen me koi badlaav nahi dikha.", "I tapped ${e.label.take(40).ifBlank { query }} but the screen didn't change."))
                return if (r.ok) ActionResult(true, t(h, "${e.label.take(40).ifBlank { query }} par kaam ho gaya", r.message)) else r
            }
        }
    }

    /** Returns the element, or null if there is none / the user cancelled. Asks when several matches are about equally good. */
    private suspend fun pick(cands: List<Pair<UiElement, Int>>, query: String, h: Boolean): UiElement? {
        if (cands.isEmpty()) return null
        val top = cands[0].second
        val close = cands.filter { top - it.second <= 10 }.take(5)
        if (close.size == 1) return close[0].first
        val labels = close.mapIndexed { i, (e, _) -> "${i + 1}. ${e.label.take(40).ifBlank { e.kind }} (${position(e)})" }
        val q = ScreenSearch.clean(query).ifBlank { query }
        val idx = host.choose(t(h, "${close.size} \"$q\" options mil rahe hain. Kaunsa select karun?", "I found ${close.size} \"$q\" options. Which one?"), labels)
        if (idx < 0 || idx >= close.size) return null
        return close[idx].first
    }

    private fun position(e: UiElement): String {
        val ws = NovaAccessibilityService.instance?.screenSize() ?: return ""
        val v = when { e.cy < ws.second / 3 -> "top"; e.cy > ws.second * 2 / 3 -> "bottom"; else -> "middle" }
        val x = when { e.cx < ws.first / 3 -> "left"; e.cx > ws.first * 2 / 3 -> "right"; else -> "center" }
        return "$v-$x"
    }

    // ───────── search (open field → focus → type → verify text → submit → wait for results) ─────────
    private class Target(val el: UiElement, val isField: Boolean)

    private fun findSearchTarget(snap: ScreenSnapshot, pkg: String): Target? {
        val cs = snap.cands()
        AppUi.searchField(cs, pkg)?.let { c -> snap.byId(c.id)?.let { return Target(it, true) } }
        AppUi.searchEntry(cs, pkg)?.let { c -> snap.byId(c.id)?.let { return Target(it, false) } }
        if (AppUi.kindOf(pkg) == AppKind.OTHER) ScreenSearch.searchTargets(snap).firstOrNull()?.let { return Target(it, it.editable) }
        return null
    }

    private fun visible(snap: ScreenSnapshot): String =
        snap.elements.map { it.label.take(24) }.filter { it.isNotBlank() }.distinct().take(8).joinToString(", ").ifBlank { "nothing readable" }

    private fun resultsReady(s: ScreenSnapshot, kind: AppKind): Boolean = when (kind) {
        AppKind.YOUTUBE -> AppUi.youtubeResults(s.cands(), s.width, s.height).isNotEmpty() && s.editable.none { it.focused }
        AppKind.BROWSER -> AppUi.browserResults(s.cands(), s.height).isNotEmpty() && s.editable.none { it.focused }
        AppKind.OTHER -> s.elements.isNotEmpty()
    }

    private suspend fun searchInApp(query: String, h: Boolean): ActionResult {
        if (!device.hasInternet()) return fail(FailureKind.NO_INTERNET, h)
        var snap = exec.waitFor(3500) { it.elements.isNotEmpty() } ?: return fail(FailureKind.SCREEN_UNREADABLE, h, device.appLabel(workPkg()))
        val pkg = snap.pkg.ifBlank { workPkg() }
        if (appPkg.isNotBlank() && pkg != appPkg) return fail(FailureKind.APP_NOT_IN_FRONT, h, device.appLabel(appPkg))
        val kind = AppUi.kindOf(pkg)

        // 1. find the search field, or the button that opens it
        var target = findSearchTarget(snap, pkg)
        if (target == null && kind != AppKind.OTHER) {
            // One safe retry: we may be on a video / inner page. Go back once and look again.
            if (exec.back().ok) {
                delay(700)
                exec.waitFor(2500) { it.pkg == pkg && it.elements.isNotEmpty() }?.let { snap = it; target = findSearchTarget(it, pkg) }
            }
        }
        val tgt = target ?: return fail(FailureKind.SEARCH_FIELD_NOT_FOUND, h, visible(snap))
        gate(ActionValidator.forTyping(prefs, tgt.el), "search", h)?.let { return it }

        // 2. open / focus it (tap), then wait for a real text field
        if (!tgt.isField || !tgt.el.focused) {
            val r = exec.tapElement(tgt.el)
            if (!r.ok) return r
            delay(500)
        }
        snap = exec.waitFor(3500) { s -> AppUi.searchField(s.cands(), pkg) != null || s.editable.any { it.focused && !it.password } }
            ?: return fail(FailureKind.FIELD_NOT_OPENED, h)
        val field = AppUi.searchField(snap.cands(), pkg)?.let { snap.byId(it.id) }
            ?: snap.editable.firstOrNull { it.focused && !it.password }
            ?: return fail(FailureKind.FIELD_NOT_OPENED, h)
        gate(ActionValidator.forTyping(prefs, field), "search", h)?.let { return it }
        if (!field.focused) {                       // confirm focus; typeText also verifies by reading the field back
            exec.tapElement(field)
            delay(400)
        }

        // 3. type (skipped when the field already shows the query, so nothing is typed twice), text read back inside typeText
        if (!TextVerify.matches(query, exec.readField(field))) {
            val typed = exec.typeText(query, field)
            if (!typed.ok) return typed
        }

        // 4. submit and prove the screen reacted
        val before = exec.foreground()
        val sub = exec.submit()
        if (!sub.ok) return fail(FailureKind.SEARCH_NOT_SUBMITTED, h, sub.message)
        if (before.isNotBlank() && exec.foreground() != before && appPkg.isNotBlank()) return fail(FailureKind.APP_NOT_IN_FRONT, h, device.appLabel(appPkg))

        // 5. wait for results, or say why there are none
        val results = exec.waitFor(9000) { resultsReady(it, kind) }
        if (results == null) {
            val problem = exec.snapshot()?.let { AppUi.pageProblem(it.texts()) }
            return when (problem) {
                PageProblem.OFFLINE -> fail(FailureKind.NO_INTERNET, h)
                PageProblem.SITE_UNREACHABLE -> fail(FailureKind.SITE_UNREACHABLE, h)
                PageProblem.CONSENT -> fail(FailureKind.CONSENT_PAGE, h)
                PageProblem.LOAD_FAILED -> fail(FailureKind.NO_RESULTS, h, t(h, "App ne \"kuch galat hua\" dikhaya.", "The app showed \"something went wrong\"."))
                null -> fail(FailureKind.NO_RESULTS, h, t(h, "9 second tak intezaar kiya.", "I waited 9 seconds."))
            }
        }
        if (kind == AppKind.BROWSER && AppUi.pageProblem(results.texts()) == PageProblem.CONSENT) return fail(FailureKind.CONSENT_PAGE, h)
        lastQuery = query
        return ActionResult(true, t(h, "\"$query\" search kiya", "Searched \"$query\""))
    }

    private suspend fun typeInto(text: String, field: String?, h: Boolean): ActionResult {
        val snap = awaitSnapshot() ?: return ActionResult(false, t(h, "Screen dikh nahi rahi.", "I can't see the screen."))
        var target: UiElement? = null
        if (field != null) {
            val m = ScreenSearch.find(snap, field, Kind.FIELD).firstOrNull()
            target = m?.el ?: return ActionResult(false, t(h, "\"$field\" naam ka field nahi mila.", "I couldn't find a field called \"$field\"."))
        } else target = snap.editable.firstOrNull { it.focused && !it.password }
        gate(ActionValidator.forTyping(prefs, target), "type", h)?.let { return it }
        if (target == null) return ActionResult(false, t(h, "Pehle koi text field select karo, phir bolo.", "Tap a text field first, then ask again."))
        val r = exec.typeText(text, target)
        return if (r.ok) ActionResult(true, t(h, "Likh diya", "Typed it")) else r
    }

    // ───────── results ─────────
    private fun rows(snap: ScreenSnapshot, pkg: String): List<UiElement> {
        val cs = snap.cands()
        val ids = when (AppUi.kindOf(pkg)) {
            AppKind.YOUTUBE -> AppUi.youtubeResults(cs, snap.width, snap.height)
            AppKind.BROWSER -> AppUi.browserResults(cs, snap.height)
            AppKind.OTHER -> return ScreenSearch.results(snap)
        }
        return ids.mapNotNull { snap.byId(it.id) }
    }

    private suspend fun openResult(ordinal: Int, h: Boolean): ActionResult {
        val pkg0 = workPkg()
        val kind = AppUi.kindOf(pkg0)
        val snap = exec.waitFor(4000) { rows(it, it.pkg.ifBlank { pkg0 }).isNotEmpty() }
        if (snap == null) {
            val now = exec.snapshot()
            if (now != null && AppUi.onYoutubeVideoPage(now.cands(), now.pkg)) return ActionResult(true, t(h, "Video page pehle se khula hai", "A video page is already open"))
            return fail(FailureKind.RESULT_NOT_FOUND, h, t(h, "Pehle search karo ya scroll karo.", "Search first or scroll."))
        }
        val pkg = snap.pkg.ifBlank { pkg0 }
        val list = rows(snap, pkg)
        val el: UiElement? = if (ordinal > 0) list.getOrNull(ordinal - 1) else {
            val best = AppUi.bestForQuery(list.map { it.toCandForPick() }, lastQuery)
            best?.let { b -> list.firstOrNull { it.index == b.id } }
        }
        if (el == null) return fail(FailureKind.RESULT_NOT_FOUND, h, t(h, "Result number $ordinal nahi mila.", "There is no result number $ordinal on screen."))
        gate(ActionValidator.forContent(prefs, el), el.label.take(40), h)?.let { return it }

        val beforeUrl = AppUi.urlText(snap.cands())
        val titleBefore = el.label
        val tap = exec.tapContent(el)
        if (!tap.ok) return tap

        // verify the destination really loaded
        when (kind) {
            AppKind.YOUTUBE -> {
                val page = exec.waitFor(9000) { AppUi.onYoutubeVideoPage(it.cands(), it.pkg) }
                if (page == null) {
                    val problem = exec.snapshot()?.let { AppUi.pageProblem(it.texts()) }
                    return when (problem) {
                        PageProblem.OFFLINE -> fail(FailureKind.NO_INTERNET, h)
                        else -> fail(FailureKind.PAGE_NOT_LOADED, h, t(h, "Video page nahi dikha.", "No video page appeared."))
                    }
                }
            }
            AppKind.BROWSER -> {
                val moved = exec.waitFor(10000) { s ->
                    val u = AppUi.urlText(s.cands())
                    (u.isNotBlank() && beforeUrl.isNotBlank() && u != beforeUrl) || AppUi.browserResults(s.cands(), s.height).none { it.label == titleBefore }
                }
                if (moved == null) return fail(FailureKind.PAGE_NOT_LOADED, h, t(h, "Page badla hi nahi.", "The page didn't change."))
                delay(1500)
                when (exec.snapshot()?.let { AppUi.pageProblem(it.texts()) }) {
                    PageProblem.OFFLINE -> return fail(FailureKind.NO_INTERNET, h)
                    PageProblem.SITE_UNREACHABLE -> return fail(FailureKind.SITE_UNREACHABLE, h)
                    PageProblem.CONSENT -> return fail(FailureKind.CONSENT_PAGE, h)
                    else -> {}
                }
            }
            AppKind.OTHER -> if (tap.changed != true) return fail(FailureKind.PAGE_NOT_LOADED, h, t(h, "Dabane ke baad screen nahi badli.", "The screen didn't change after the tap."))
        }
        lastResultTitle = titleBefore.take(80)
        return ActionResult(true, t(h, "Result khola: ${clip(titleBefore, 50)}", "Opened: ${clip(titleBefore, 50)}"))
    }

    private fun UiElement.toCandForPick() = com.nova.ai.screen.Cand(index, text, desc, hint, viewId, cls, clickable, editable, focused, enabled, bounds.left, bounds.top, bounds.right, bounds.bottom)

    private suspend fun readResults(h: Boolean): ActionResult {
        val snap = exec.waitFor(3500) { it.elements.isNotEmpty() } ?: return fail(FailureKind.SCREEN_UNREADABLE, h, device.appLabel(workPkg()))
        val pkg = snap.pkg.ifBlank { workPkg() }
        val titles = rows(snap, pkg).map { clip(it.label) }.distinct().take(5)
        if (titles.isEmpty()) {
            return when (AppUi.pageProblem(snap.texts())) {
                PageProblem.OFFLINE -> fail(FailureKind.NO_INTERNET, h)
                PageProblem.SITE_UNREACHABLE -> fail(FailureKind.SITE_UNREACHABLE, h)
                PageProblem.CONSENT -> fail(FailureKind.CONSENT_PAGE, h)
                else -> fail(FailureKind.RESULT_NOT_FOUND, h)
            }
        }
        return ActionResult(true, t(h, "Results dikh rahe hain: ", "I can see: ") + titles.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString(" | "))
    }

    // ───────── playback: never claimed without proof ─────────
    private suspend fun verifyPlayback(h: Boolean): ActionResult {
        val pkg = workPkg()
        if (AppUi.kindOf(pkg) != AppKind.YOUTUBE) return ActionResult(false, t(h, "Main sirf YouTube app me playback check kar sakti hoon.", "I can only check playback inside the YouTube app."))
        exec.waitFor(6000) { AppUi.onYoutubeVideoPage(it.cands(), it.pkg) } ?: return fail(FailureKind.PAGE_NOT_LOADED, h, t(h, "Video page nahi dikha.", "No video page appeared."))
        var outcome = PlaybackOutcome.UNCONFIRMED
        var triedPlay = false
        var revealed = false
        var i = 0
        while (i < 18) {                         // about 9 seconds
            val s = exec.snapshot()
            val cs = s?.cands().orEmpty()
            val ui = if (s != null) AppUi.playbackUi(cs) else UiPlayback.UNKNOWN
            outcome = PlaybackVerdict.decide(device.isAudioPlaying(), audioWasActive, ui)
            if (outcome == PlaybackOutcome.CONFIRMED) break
            if (outcome == PlaybackOutcome.PAUSED && !triedPlay && s != null) {   // one safe retry: press the player's own Play control
                triedPlay = true
                AppUi.playControl(cs)?.let { c -> s.byId(c.id)?.let { exec.tapContent(it) } }
            } else if (outcome == PlaybackOutcome.UNCONFIRMED && !revealed && i == 6 && s != null) {   // controls hidden: a tap on the player only shows them
                revealed = true
                AppUi.playerSurface(cs)?.let { c -> s.byId(c.id)?.let { exec.tapContent(it) } }
            }
            delay(500); i++
        }
        return when (outcome) {
            PlaybackOutcome.CONFIRMED -> ActionResult(true, t(h, "Video chal raha hai${if (lastResultTitle.isNotBlank()) ": " + clip(lastResultTitle, 50) else ""}", "Playing${if (lastResultTitle.isNotBlank()) ": " + clip(lastResultTitle, 50) else ""}"))
            PlaybackOutcome.PAUSED -> fail(FailureKind.PAUSED, h)
            PlaybackOutcome.UNCONFIRMED -> fail(FailureKind.PLAYBACK_UNCONFIRMED, h)
        }
    }

    private suspend fun find(query: String, h: Boolean): ActionResult {
        val snap = awaitSnapshot() ?: return ActionResult(false, t(h, "Screen dikh nahi rahi.", "I can't see the screen."))
        return when (val res = resolver.resolve(query, snap)) {
            is Resolution.None -> ActionResult(false, res.reason)
            is Resolution.Point -> ActionResult(true, t(h, "Screenshot me ${res.label} dikha.", "I can see ${res.label} on the screenshot."))
            is Resolution.Nodes -> {
                val cands = res.matches.map { it.el to it.score }
                val top = cands[0].second
                val close = cands.filter { top - it.second <= 10 }.take(5)
                if (close.size == 1) {
                    val e = close[0].first
                    val what = "${e.label.take(40)} (${e.kind}, ${position(e)})"
                    if (host.confirm(t(h, "$what mil gaya. Tap karun?", "Found $what. Tap it?"))) {
                        gate(ActionValidator.forElement(prefs, e, query), e.label.take(40), h)?.let { return it }
                        val r = exec.tapElement(e)
                        if (r.ok) ActionResult(true, t(h, "$what mil gaya aur tap kar diya", "Found and tapped $what")) else r
                    } else ActionResult(true, t(h, "$what mil gaya", "Found $what"))
                } else {
                    val labels = close.mapIndexed { i, (e, _) -> "${i + 1}. ${e.label.take(40).ifBlank { e.kind }} (${position(e)})" }
                    val q = ScreenSearch.clean(query).ifBlank { query }
                    val idx = host.choose(t(h, "${close.size} \"$q\" options mil rahe hain. Kaunsa select karun?", "I found ${close.size} \"$q\" options. Which one?"), labels)
                    if (idx < 0) ActionResult(true, t(h, "Theek hai, kuch tap nahi kiya.", "Okay, I didn't tap anything."))
                    else {
                        val e = close[idx].first
                        gate(ActionValidator.forElement(prefs, e, query), e.label.take(40), h)?.let { return it }
                        exec.tapElement(e)
                    }
                }
            }
        }
    }

    private suspend fun awaitSnapshot(): ScreenSnapshot? = exec.waitFor(2500) { it.elements.isNotEmpty() }
}
