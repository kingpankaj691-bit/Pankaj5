package com.nova.ai.developer

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class UpdateInfo(val versionCode: Long, val versionName: String, val apkUrl: String, val sha256: String, val notes: String)

/**
 * Update flow with no dynamic code loading and no shell:
 *   metadata over HTTPS -> compare version -> you approve -> download over HTTPS -> SHA-256 must match -> the APK must be signed by
 *   the SAME certificate as the installed Nova and have the same package -> Android's own installer asks you to install.
 * The signature check is what proves it comes from you; the hash only proves the download wasn't damaged.
 */
class UpdateManager(private val ctx: Context) {
    companion object {
        private const val MAX_APK_BYTES = 200L * 1024 * 1024
        private val client by lazy { OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build() }
    }

    private val apkFile get() = File(File(ctx.cacheDir, "updates").also { it.mkdirs() }, "nova-update.apk")

    fun installedVersionCode(): Long = PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))

    /** Metadata JSON: {"versionCode":25,"versionName":"2.5","apkUrl":"https://…/nova.apk","sha256":"<64 hex>","notes":"…"} */
    suspend fun check(metadataUrl: String): Pair<UpdateInfo?, String> = withContext(Dispatchers.IO) {
        if (!metadataUrl.startsWith("https://")) return@withContext null to "The update address must start with https://"
        try {
            client.newCall(Request.Builder().url(metadataUrl).build()).execute().use { r ->
                if (!r.isSuccessful) return@withContext null to "The update server answered ${r.code}."
                if (!r.request.url.isHttps) return@withContext null to "The update server redirected to a non-HTTPS address."
                val j = JSONObject(r.body?.string().orEmpty())
                val info = UpdateInfo(j.getLong("versionCode"), j.optString("versionName"), j.getString("apkUrl"), j.getString("sha256").lowercase(), j.optString("notes"))
                if (!info.apkUrl.startsWith("https://")) return@withContext null to "The APK address must be https."
                if (!Regex("^[0-9a-f]{64}$").matches(info.sha256)) return@withContext null to "The update metadata has no valid SHA-256."
                if (info.versionCode <= installedVersionCode()) null to "You're up to date (version code ${installedVersionCode()})."
                else info to "Update ${info.versionName.ifBlank { info.versionCode.toString() }} is available."
            }
        } catch (e: Exception) { null to "Couldn't check for updates: ${e.message ?: "network error"}" }
    }

    /** Downloads, then verifies hash, package, version and signing certificate. Returns an error message, or null when it is safe to install. */
    suspend fun downloadAndVerify(info: UpdateInfo, onProgress: (Int) -> Unit): String? = withContext(Dispatchers.IO) {
        val f = apkFile
        try {
            f.delete()
            val md = MessageDigest.getInstance("SHA-256")
            client.newCall(Request.Builder().url(info.apkUrl).build()).execute().use { r ->
                if (!r.isSuccessful) return@withContext "Download failed (${r.code})."
                if (!r.request.url.isHttps) return@withContext "The download redirected to a non-HTTPS address."
                val body = r.body ?: return@withContext "Empty download."
                val total = body.contentLength()
                if (total > MAX_APK_BYTES) return@withContext "The file is larger than the allowed size."
                var read = 0L
                body.byteStream().use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            read += n
                            if (read > MAX_APK_BYTES) { f.delete(); return@withContext "The file is larger than the allowed size." }
                            md.update(buf, 0, n); out.write(buf, 0, n)
                            if (total > 0) onProgress((read * 100 / total).toInt())
                        }
                    }
                }
            }
            val got = md.digest().joinToString("") { "%02x".format(it) }
            if (got != info.sha256) { f.delete(); return@withContext "The download's SHA-256 does not match. It was discarded." }
            verifyPackage(f, info) ?: return@withContext null
        } catch (e: Exception) {
            f.delete(); "Download failed: ${e.message ?: "network error"}"
        }
    }

    /** null = OK, otherwise the problem (and the file is deleted). */
    private fun verifyPackage(f: File, info: UpdateInfo): String? {
        val pm = ctx.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else @Suppress("DEPRECATION") PackageManager.GET_SIGNATURES
        val archive = pm.getPackageArchiveInfo(f.absolutePath, flags)
        val installed = try { pm.getPackageInfo(ctx.packageName, flags) } catch (e: Exception) { null }
        fun fail(m: String): String { f.delete(); return m }
        if (archive == null || installed == null) return fail("Android couldn't read the downloaded APK.")
        if (archive.packageName != ctx.packageName) return fail("The APK is for a different app. Discarded.")
        if (PackageInfoCompat.getLongVersionCode(archive) != info.versionCode) return fail("The APK's version doesn't match the update metadata. Discarded.")
        val a = signers(archive); val b = signers(installed)
        if (a.isEmpty() || b.isEmpty() || a != b) return fail("The APK is not signed with the same key as this Nova, so it will not be installed.")
        return null
    }

    private fun signers(p: PackageInfo): Set<String> {
        val sigs = if (Build.VERSION.SDK_INT >= 28) p.signingInfo?.apkContentsSigners else @Suppress("DEPRECATION") p.signatures
        return sigs?.map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }?.toSet() ?: emptySet()
    }

    /** Hands the verified APK to Android's installer, which asks you to confirm. Returns a message for the user. */
    fun install(): String {
        val f = apkFile
        if (!f.exists()) return "Nothing downloaded yet."
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Allow \"Install unknown apps\" for Nova on the page that opened, then tap Install again."
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Android's installer is open. Confirm there to update."
    }

    fun discard() { apkFile.delete() }
}
