package com.nova.ai.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.control.Capabilities
import com.nova.ai.control.PlannedModules
import com.nova.ai.control.ShizukuManager
import com.nova.ai.control.ShizukuStatus
import com.nova.ai.control.TaskHistory
import com.nova.ai.control.TaskStatus
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun yn(b: Boolean) = if (b) "Yes" else "No"

/** Settings → Advanced System Control → Shizuku. Shows only what the system reports; never claims access it does not have. */
@Composable
internal fun ShizukuPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val scope = rememberCoroutineScope()
    val s by ShizukuManager.state.collectAsState()
    var test by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(tick) { ShizukuManager.init(ctx); ShizukuManager.refresh() }

    GlassSettingSection("Connection") {
        GlassListItem("Shizuku app", if (s.installed || s.running) "Installed" else "Not installed")
        GlassListItem("Shizuku service", if (s.running) "Running (v${s.serverVersion}, ${s.mode})" else "Not running")
        GlassListItem("Nova permission", if (s.granted) "Granted" else if (s.status == ShizukuStatus.PERMISSION_DENIED) "Denied" else "Not granted")
        GlassListItem("Shell connection", if (s.status == ShizukuStatus.READY && s.serviceBound) "Connected" else if (s.status == ShizukuStatus.READY) "Ready, not connected yet" else "Not connected")
        GText(s.detail, size = 12.sp, color = g.accent)
        GText("Root is not required and never used by Nova. Android ${ShizukuManager.sdk()}.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Actions") {
        if (!s.installed && !s.running)
            GlassButton("Get Shizuku (official page)", { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }, primary = true)
        if (s.installed && !s.running)
            GlassButton("Open Shizuku app", { ctx.packageManager.getLaunchIntentForPackage(ShizukuManager.PACKAGE)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, primary = true)
        if (s.status == ShizukuStatus.NEEDS_PERMISSION || s.status == ShizukuStatus.PERMISSION_DENIED)
            GlassButton("Request permission", { scope.launch { busy = true; val ok = ShizukuManager.requestPermission(); test = if (ok) "Permission granted." else "Permission was not granted."; busy = false } }, primary = true, enabled = !busy)
        GlassButton("Reconnect", { scope.launch { busy = true; test = if (ShizukuManager.reconnect()) "Reconnected." else "Could not reconnect: ${ShizukuManager.state.value.detail}"; busy = false } }, enabled = s.running && !busy)
        GlassButton("Test connection", { scope.launch { busy = true; val r = ShizukuManager.testConnection(); test = if (r.ok) "Works. Shell reports Android API ${r.out.trim()}." else "Failed: $r"; busy = false } }, enabled = s.status == ShizukuStatus.READY && !busy)
        GlassButton("Refresh status", { ShizukuManager.refresh() })
        if (test.isNotBlank()) GText(test, size = 12.sp, color = g.accent)
    }
    val rows = remember(tick, s) { Capabilities.rows(ctx) }
    GlassSettingSection("Supported operations") {
        rows.filter { it.supported }.forEach { GlassListItem(it.name, "via ${it.via}" + if (it.note.isNotBlank()) " — ${it.note}" else "") }
    }
    GlassSettingSection("Unsupported right now") {
        rows.filter { !it.supported }.forEach { GlassListItem(it.name, it.note.ifBlank { "Needs a permission or service that is not available" }) }
    }
    GlassSettingSection("How it stays safe") {
        GText("Nova runs only allow-listed commands (display settings, Wi-Fi/Bluetooth toggles, Do Not Disturb, media volume, input keys, force-stop with confirmation, read-only info). Shell operators are rejected and each command is checked again inside the Shizuku process. Installing, uninstalling, clearing data, factory reset and security settings are never done silently.", size = 12.sp, color = g.subtext)
    }
}

/** Advanced System Control dashboard: services, permissions, capabilities, running tasks, history, failures, planned modules. */
@Composable
internal fun AdvancedControlPage(vm: NovaViewModel, openShizuku: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val s by ShizukuManager.state.collectAsState()
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(tick) { ShizukuManager.init(ctx); TaskHistory.init(ctx); ShizukuManager.refresh(); refresh++ }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm:ss", Locale.getDefault()) }
    val log = remember(refresh, tick) { TaskHistory.log.all() }
    val rows = remember(tick, s) { Capabilities.rows(ctx) }

    GlassSettingSection("Services") {
        GlassListItem("Shizuku", s.status.name.lowercase().replace('_', ' '), onClick = openShizuku)
        GlassListItem("Accessibility service", if (tick >= 0 && NovaAccessibilityService.instance != null) "Enabled" else "Disabled")
        GlassListItem("Screen Assistant actions", if (vm.prefs.screenActionsOn) "Allowed" else "Off")
        GlassListItem("Screen Vision", if (vm.visionActive) "On" else "Off")
    }
    GlassSettingSection("Available system operations") {
        rows.forEach { GlassListItem(it.name, (if (it.supported) "Available via ${it.via}" else "Not available") + if (it.note.isNotBlank()) " — ${it.note}" else "") }
    }
    GlassSettingSection("Running now") {
        val r = log.filter { it.status == TaskStatus.RUNNING }
        if (r.isEmpty()) GText("Nothing is running.", size = 12.sp, color = g.subtext) else r.forEach { GlassListItem(it.title, "Started ${fmt.format(Date(it.time))}") }
    }
    GlassSettingSection("Recent automation history") {
        if (log.isEmpty()) GText("No control tasks yet. Try “brightness kam kar do”.", size = 12.sp, color = g.subtext)
        log.take(12).forEach { GlassListItem("${it.title} — ${it.status.name.lowercase().replace('_', ' ')}", "${fmt.format(Date(it.time))} · ${it.method.ifBlank { "-" }} · ${it.message.take(90)}") }
        if (log.isNotEmpty()) GlassButton("Clear history", { TaskHistory.clear(); refresh++ })
    }
    GlassSettingSection("Failed operations") {
        val f = TaskHistory.log.failed()
        if (f.isEmpty()) GText("No failures recorded.", size = 12.sp, color = g.subtext)
        f.take(8).forEach { GlassListItem(it.title, "${it.status.name.lowercase()} · ${it.message.take(110)}") }
    }
    GlassSettingSection("Device compatibility") {
        GlassListItem("Android", "API ${android.os.Build.VERSION.SDK_INT} (${android.os.Build.VERSION.RELEASE}) · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
        GlassListItem("Modify system settings", yn(android.provider.Settings.System.canWrite(ctx)))
        GlassListItem("Do Not Disturb access", yn((ctx.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted))
        GlassListItem("Notification listener", yn(androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)))
    }
    GlassSettingSection("Planned modules (interfaces only)") {
        PlannedModules.all().forEach { GlassListItem("${it.title} — ${it.status}", it.note) }
    }
}
