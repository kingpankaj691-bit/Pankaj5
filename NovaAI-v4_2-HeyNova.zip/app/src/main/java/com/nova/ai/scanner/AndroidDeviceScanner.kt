package com.nova.ai.scanner

import android.Manifest
import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Display
import android.view.accessibility.AccessibilityManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.core.AppManager
import com.nova.ai.core.DeviceScanner
import com.nova.ai.core.PermissionManager
import com.nova.ai.security.Prefs
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Reads only what Android exposes to a normal app without special access. It never reads files,
 * messages, other apps' data or Wi-Fi passwords. Anything gated by a permission Nova doesn't hold is marked Restricted.
 */
class AndroidDeviceScanner(
    private val ctx: Context,
    private val prefs: Prefs,
    private val apps: AppManager,
    private val perms: PermissionManager
) : DeviceScanner {

    override val steps = listOf(
        "device" to "Device", "android" to "Android", "hardware" to "Hardware", "processor" to "Processor & graphics", "display" to "Display",
        "battery" to "Battery", "storage" to "Storage", "memory" to "Memory", "network" to "Network",
        "wifi" to "Wi-Fi", "bluetooth" to "Bluetooth", "sensors" to "Sensors", "cameras" to "Cameras",
        "audio" to "Audio", "speech" to "Speech & language", "apps" to "Applications", "permissions" to "Permissions",
        "notifications" to "Notifications", "accessibility" to "Accessibility", "features" to "System features", "nova" to "NOVA readiness"
    )
    private val hw = HardwareCapabilityManager(ctx, prefs)

    private val pm = ctx.packageManager
    private var cachedApps: List<AppInfo> = emptyList()

    suspend fun refreshApps() { cachedApps = withContext(Dispatchers.IO) { apps.inventory() } }

    override suspend fun scan(onStep: (Int, String) -> Unit, paced: Boolean): DeviceProfile {
        val out = mutableListOf<ScanSection>()
        cachedApps = withContext(Dispatchers.IO) { apps.inventory() }
        steps.forEachIndexed { i, (id, title) ->
            onStep(i, title)
            out.add(build(id))
            if (paced) delay(230)
        }
        onStep(steps.size, "Complete")
        return DeviceProfile(System.currentTimeMillis(), out, cachedApps)
    }

    override suspend fun build(id: String): ScanSection = withContext(Dispatchers.IO) {
        val title = steps.firstOrNull { it.first == id }?.second ?: id
        try {
            when (id) {
                "device" -> device(); "android" -> androidInfo(); "hardware" -> hardware(); "display" -> display()
                "battery" -> battery(); "storage" -> storage(); "memory" -> memory(); "network" -> network()
                "wifi" -> wifi(); "bluetooth" -> bluetooth(); "sensors" -> sensors(); "cameras" -> cameras()
                "audio" -> audio(); "apps" -> appsSection(); "permissions" -> permissions()
                "processor" -> hw.processor(); "speech" -> hw.speech(); "nova" -> hw.novaMatrix()
                "notifications" -> notifications(); "accessibility" -> accessibility(); else -> features()
            }.let { sec -> val ex = hw.extras(id); if (ex.isEmpty()) sec else sec.copy(items = sec.items + ex) }
        } catch (e: Exception) {
            ScanSection(id, title, "Unavailable", null, listOf(ScanItem("Status", "Android didn't expose this (${e.javaClass.simpleName})", "Restricted")))
        }
    }

    // ───────── helpers ─────────
    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun gb(b: Long) = String.format("%.1f GB", b / 1073741824.0)
    private fun has(f: String) = pm.hasSystemFeature(f)
    private fun status(avail: Boolean, perm: String? = null) =
        if (!avail) "Not available" else if (perm != null && !granted(perm)) "Restricted" else "Available"
    private fun item(label: String, avail: Boolean, perm: String? = null, detail: String? = null): ScanItem {
        val s = status(avail, perm)
        return ScanItem(label, if (s == "Restricted") "Present, needs permission" else s, s, detail)
    }

    // ───────── sections ─────────
    private fun device(): ScanSection {
        val items = mutableListOf(
            ScanItem("Manufacturer", Build.MANUFACTURER), ScanItem("Model", Build.MODEL), ScanItem("Brand", Build.BRAND),
            ScanItem("Device", Build.DEVICE), ScanItem("Product", Build.PRODUCT),
            ScanItem("Uptime", uptime(SystemClock.elapsedRealtime())),
            ScanItem("CPU cores", Runtime.getRuntime().availableProcessors().toString()),
            ScanItem("Hardware", Build.HARDWARE), ScanItem("ABIs", Build.SUPPORTED_ABIS.joinToString())
        )
        if (Build.VERSION.SDK_INT >= 31) items.add(ScanItem("SoC", "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"))
        items.add(ScanItem("CPU clock/model", "Not reliably exposed by Android", "Restricted"))
        return ScanSection("device", "Device", "${Build.MANUFACTURER} ${Build.MODEL}", null, items)
    }

    private fun uptime(ms: Long): String { val m = ms / 60000; return "${m / 1440}d ${(m / 60) % 24}h ${m % 60}m" }

    private fun androidInfo() = ScanSection("android", "Android", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", null, listOf(
        ScanItem("Version", Build.VERSION.RELEASE), ScanItem("SDK", Build.VERSION.SDK_INT.toString()),
        ScanItem("Security patch", Build.VERSION.SECURITY_PATCH), ScanItem("Build ID", Build.ID),
        ScanItem("Build display", Build.DISPLAY), ScanItem("Build type", Build.TYPE)
    ))

    private fun hardware(): ScanSection {
        val items = listOf(
            item("Camera", has("android.hardware.camera.any")),
            item("Front camera", has("android.hardware.camera.front")),
            item("Rear camera", has("android.hardware.camera")),
            item("Flash", has("android.hardware.camera.flash")),
            item("Microphone", has("android.hardware.microphone"), Manifest.permission.RECORD_AUDIO),
            item("GPS", has("android.hardware.location.gps"), Manifest.permission.ACCESS_FINE_LOCATION),
            item("Accelerometer", has("android.hardware.sensor.accelerometer")),
            item("Gyroscope", has("android.hardware.sensor.gyroscope")),
            item("Magnetometer", has("android.hardware.sensor.compass")),
            item("Proximity sensor", has("android.hardware.sensor.proximity")),
            item("Light sensor", has("android.hardware.sensor.light")),
            item("Barometer", has("android.hardware.sensor.barometer")),
            item("NFC", has("android.hardware.nfc")),
            item("Fingerprint", has("android.hardware.fingerprint")),
            item("Face biometrics", has("android.hardware.biometrics.face")),
            item("Bluetooth", has("android.hardware.bluetooth"), if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_CONNECT else null),
            item("Bluetooth LE", has("android.hardware.bluetooth_le")),
            item("Wi-Fi", has("android.hardware.wifi")),
            item("Telephony", has("android.hardware.telephony")),
            item("USB host", has("android.hardware.usb.host")),
            item("USB accessory", has("android.hardware.usb.accessory"))
        )
        val avail = items.count { it.status == "Available" }
        return ScanSection("hardware", "Hardware", "$avail of ${items.size} available", avail / items.size.toFloat(), items)
    }

    private fun display(): ScanSection {
        val dm = ctx.resources.displayMetrics
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        val hz = d?.refreshRate ?: 0f
        val modes = d?.supportedModes?.map { "${it.physicalWidth}x${it.physicalHeight} @ ${"%.0f".format(it.refreshRate)}Hz" }?.distinct() ?: emptyList()
        return ScanSection("display", "Display", "${dm.widthPixels}x${dm.heightPixels} • ${"%.0f".format(hz)} Hz", null, listOf(
            ScanItem("Resolution", "${dm.widthPixels} x ${dm.heightPixels}"), ScanItem("Density", "${dm.densityDpi} dpi (${dm.density}x)"),
            ScanItem("Refresh rate", "${"%.0f".format(hz)} Hz"), ScanItem("Supported modes", "${modes.size}", null, modes.joinToString("\n")),
            ScanItem("Font scale", ctx.resources.configuration.fontScale.toString())
        ))
    }

    private fun battery(): ScanSection {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level < 0) -1 else level * 100 / scale
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val plug = when (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC charger"; BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"; else -> "Battery"
        }
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1).let { if (it < 0) "Unavailable" else "%.1f °C".format(it / 10.0) }
        val health = when (b?.getIntExtra(BatteryManager.EXTRA_HEALTH, 1) ?: 1) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"; BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"; BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"; BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"; else -> "Unknown"
        }
        val saver = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return ScanSection("battery", "Battery", if (pct >= 0) "$pct%${if (charging) " (charging)" else ""}" else "Unavailable",
            if (pct >= 0) pct / 100f else null, listOf(
                ScanItem("Level", if (pct >= 0) "$pct%" else "Unavailable"), ScanItem("Charging", if (charging) "Yes" else "No"),
                ScanItem("Power source", plug), ScanItem("Battery saver", if (saver) "On" else "Off"),
                ScanItem("Temperature", temp), ScanItem("Health", health),
                ScanItem("Technology", b?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown")
            ))
    }

    private fun mediaCount(uri: android.net.Uri, perm: String): ScanItem {
        val label = when (uri) { MediaStore.Images.Media.EXTERNAL_CONTENT_URI -> "Photos"; MediaStore.Video.Media.EXTERNAL_CONTENT_URI -> "Videos"; else -> "Audio" }
        if (!granted(perm)) return ScanItem(label, "Needs Media permission", "Restricted")
        val n = try { ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { it.count } } catch (e: Exception) { null }
        return ScanItem(label, n?.toString() ?: "Unavailable")
    }

    private fun storage(): ScanSection {
        val s = StatFs(Environment.getDataDirectory().path)
        val total = s.blockCountLong * s.blockSizeLong
        val free = s.availableBlocksLong * s.blockSizeLong
        val used = total - free
        val t33 = Build.VERSION.SDK_INT >= 33
        val items = listOf(
            ScanItem("Total", gb(total)), ScanItem("Used", gb(used)), ScanItem("Available", gb(free)),
            mediaCount(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, if (t33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE),
            mediaCount(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, if (t33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE),
            mediaCount(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, if (t33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE),
            ScanItem("Documents & files", "Only files you pick with the system file picker", "Restricted"),
            ScanItem("Other apps' private data", "Not accessible (Android sandbox)", "Restricted")
        )
        return ScanSection("storage", "Storage", "${gb(used)} used of ${gb(total)}", used / total.toFloat(), items)
    }

    private fun memory(): ScanSection {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val used = mi.totalMem - mi.availMem
        return ScanSection("memory", "Memory", "${gb(used)} used of ${gb(mi.totalMem)}", used / mi.totalMem.toFloat(), listOf(
            ScanItem("Total RAM", gb(mi.totalMem)), ScanItem("Available", gb(mi.availMem)),
            ScanItem("Low-memory state", if (mi.lowMemory) "Yes" else "No"),
            ScanItem("Low RAM device", if (am.isLowRamDevice) "Yes" else "No"), ScanItem("App memory class", "${am.memoryClass} MB")
        ))
    }

    private fun network(): ScanSection {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val type = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        val internet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        return ScanSection("network", "Network", if (caps == null) "Offline" else "$type${if (internet) ", internet OK" else ", no internet"}", null, listOf(
            ScanItem("Connected", if (caps != null) "Yes" else "No"), ScanItem("Type", type),
            ScanItem("Internet reachable", if (internet) "Yes" else "No"),
            ScanItem("Metered", if (caps != null && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) "Yes" else "No"),
            ScanItem("Downlink estimate", if (caps != null) "${caps.linkDownstreamBandwidthKbps / 1000} Mbps" else "n/a"),
            ScanItem("VPN active", if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) "Yes" else "No")
        ))
    }

    @Suppress("DEPRECATION")
    private fun wifi(): ScanSection {
        val w = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!w.isWifiEnabled) return ScanSection("wifi", "Wi-Fi", "Off", null, listOf(ScanItem("State", "Off")))
        val info = w.connectionInfo
        val raw = info?.ssid?.trim('"')
        val ssid = if (raw.isNullOrBlank() || raw == "<unknown ssid>") "Hidden by Android (needs Location permission)" else raw
        val connected = info != null && info.networkId != -1
        val items = mutableListOf(ScanItem("State", "On"), ScanItem("Connected", if (connected) "Yes" else "No"))
        if (connected) {
            items.add(ScanItem("Network", ssid, if (raw.isNullOrBlank() || raw == "<unknown ssid>") "Restricted" else null))
            items.add(ScanItem("Signal", "${info?.rssi} dBm")); items.add(ScanItem("Link speed", "${info?.linkSpeed} Mbps"))
            items.add(ScanItem("Frequency", "${info?.frequency} MHz"))
        }
        items.add(ScanItem("Nearby network list", "Needs Location permission (not requested)", "Restricted"))
        items.add(ScanItem("Saved passwords", "Never read or shown by Nova", "Restricted"))
        return ScanSection("wifi", "Wi-Fi", if (connected) "On • ${if (ssid.startsWith("Hidden")) "connected" else ssid}" else "On, not connected", null, items)
    }

    private suspend fun profileDevices(adapter: BluetoothAdapter, profile: Int): List<BluetoothDevice> =
        withTimeoutOrNull(1500) {
            suspendCancellableCoroutine<List<BluetoothDevice>> { cont ->
                val l = object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                        val d = try { proxy.connectedDevices } catch (e: Exception) { emptyList() }
                        try { adapter.closeProfileProxy(p, proxy) } catch (e: Exception) { }
                        if (cont.isActive) cont.resume(d)
                    }
                    override fun onServiceDisconnected(p: Int) {}
                }
                val ok = try { adapter.getProfileProxy(ctx, l, profile) } catch (e: Exception) { false }
                if (!ok && cont.isActive) cont.resume(emptyList())
            }
        } ?: emptyList()

    private fun btPermOk() = Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_CONNECT)

    suspend fun connectedBluetooth(): List<String> {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return emptyList()
        if (!adapter.isEnabled || !btPermOk()) return emptyList()
        val all = profileDevices(adapter, BluetoothProfile.A2DP) + profileDevices(adapter, BluetoothProfile.HEADSET)
        return try { all.map { it.name ?: it.address }.distinct() } catch (e: SecurityException) { emptyList() }
    }

    private suspend fun bluetooth(): ScanSection {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: return ScanSection("bluetooth", "Bluetooth", "Unavailable", null, listOf(ScanItem("Hardware", "Not available", "Not available")))
        val on = adapter.isEnabled
        val items = mutableListOf(ScanItem("State", if (on) "On" else "Off"))
        if (!btPermOk()) {
            items.add(ScanItem("Paired & connected devices", "Needs Nearby devices permission", "Restricted"))
        } else {
            val bonded = try { adapter.bondedDevices.map { it.name ?: it.address } } catch (e: SecurityException) { emptyList() }
            items.add(ScanItem("Paired devices", "${bonded.size}", null, bonded.joinToString("\n")))
            val conn = if (on) connectedBluetooth() else emptyList()
            items.add(ScanItem("Connected (audio)", "${conn.size}", null, conn.joinToString("\n")))
        }
        return ScanSection("bluetooth", "Bluetooth", if (on) "On" else "Off", null, items)
    }

    private fun sensors(): ScanSection {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val all = sm.getSensorList(Sensor.TYPE_ALL)
        fun s(label: String, type: Int): ScanItem {
            val x = sm.getDefaultSensor(type)
            return ScanItem(label, if (x != null) "Available" else "Not available", if (x != null) "Available" else "Not available", x?.let { "${it.name} (${it.vendor})" })
        }
        val items = listOf(
            s("Accelerometer", Sensor.TYPE_ACCELEROMETER), s("Gyroscope", Sensor.TYPE_GYROSCOPE), s("Magnetometer", Sensor.TYPE_MAGNETIC_FIELD),
            s("Proximity", Sensor.TYPE_PROXIMITY), s("Light", Sensor.TYPE_LIGHT), s("Barometer", Sensor.TYPE_PRESSURE),
            s("Step counter", Sensor.TYPE_STEP_COUNTER), s("Gravity", Sensor.TYPE_GRAVITY), s("Rotation vector", Sensor.TYPE_ROTATION_VECTOR),
            s("Humidity", Sensor.TYPE_RELATIVE_HUMIDITY), s("Ambient temperature", Sensor.TYPE_AMBIENT_TEMPERATURE),
            ScanItem("All reported sensors", "${all.size}", null, all.joinToString("\n") { it.name })
        )
        return ScanSection("sensors", "Sensors", "${all.size} sensors", null, items)
    }

    private fun cameras(): ScanSection {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val items = mutableListOf<ScanItem>()
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Front"; CameraCharacteristics.LENS_FACING_BACK -> "Rear"; else -> "External"
            }
            val flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "Full"; CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "Level 3"
                CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "Limited"; else -> "Legacy"
            }
            val size = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(android.graphics.ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height }
            items.add(ScanItem("Camera $id ($facing)", "${size?.let { "${it.width}x${it.height}" } ?: "?"}", "Available", "Flash: ${if (flash) "yes" else "no"} • Hardware level: $level"))
        }
        items.add(ScanItem("Nova camera permission", if (granted(Manifest.permission.CAMERA)) "Granted" else "Not granted", if (granted(Manifest.permission.CAMERA)) "Available" else "Restricted"))
        return ScanSection("cameras", "Cameras", "${cm.cameraIdList.size} cameras", null, items)
    }

    private fun audioTypeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Speaker"; AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in mic"; AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired headphones"; AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth audio"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth call audio"; AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"; AudioDeviceInfo.TYPE_HDMI -> "HDMI"; else -> "Type $t"
    }

    private fun audio(): ScanSection {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { audioTypeName(it.type) }.distinct()
        val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS).map { audioTypeName(it.type) }.distinct()
        val vol = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val mic = has("android.hardware.microphone")
        return ScanSection("audio", "Audio", "Mic ${status(mic, Manifest.permission.RECORD_AUDIO).lowercase()}", null, listOf(
            item("Microphone", mic, Manifest.permission.RECORD_AUDIO),
            ScanItem("Output devices", "${outs.size}", null, outs.joinToString("\n")),
            ScanItem("Input devices", "${ins.size}", null, ins.joinToString("\n")),
            ScanItem("Media volume", "$vol%"),
            ScanItem("Output sample rate", (am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) ?: "?") + " Hz"),
            ScanItem("Speech output engine", "Android text-to-speech")
        ))
    }

    private fun appsSection(): ScanSection {
        val list = cachedApps.ifEmpty { apps.inventory() }
        val cats = list.groupingBy { it.category }.eachCount()
        val order = listOf("Social", "Media", "Games", "Tools", "Education", "Communication", "Productivity", "System", "Development", "Other")
        val items = mutableListOf(ScanItem("Visible apps", "${list.size}"), ScanItem("Launchable", "${list.count { it.launchable }}"))
        order.forEach { c -> items.add(ScanItem(c, "${cats[c] ?: 0}", null, list.filter { it.category == c }.joinToString("\n") { it.name })) }
        items.add(ScanItem("Package visibility", "Android only shows apps Nova is allowed to see", "Restricted"))
        return ScanSection("apps", "Applications", "${list.size} apps (${list.count { it.launchable }} launchable)", null, items)
    }

    private fun permissions(): ScanSection {
        val mine = perms.novaPermissions()
        val ok = mine.count { perms.isGranted(it) }
        val items = mutableListOf<ScanItem>()
        mine.forEach { p ->
            val g = perms.isGranted(p)
            items.add(ScanItem(p.name, (if (g) "Enabled" else "Disabled") + " • " + (if (p.required) "Required" else "Optional"), if (g) "Available" else "Restricted", p.why))
        }
        items.add(ScanItem("Foreground service (mic)", if (VoiceState.running.value) "Running" else "Stopped"))
        // Metadata Android exposes about other visible apps: which sensitive permissions they hold. No private data is read.
        val groups = linkedMapOf(
            "Microphone" to Manifest.permission.RECORD_AUDIO, "Camera" to Manifest.permission.CAMERA,
            "Location" to Manifest.permission.ACCESS_FINE_LOCATION, "Contacts" to Manifest.permission.READ_CONTACTS
        )
        val holders = groups.keys.associateWith { mutableListOf<String>() }
        @Suppress("DEPRECATION")
        for (a in cachedApps) {
            try {
                val pi = pm.getPackageInfo(a.pkg, PackageManager.GET_PERMISSIONS)
                val req = pi.requestedPermissions ?: continue
                val flags = pi.requestedPermissionsFlags ?: continue
                groups.forEach { (g, perm) ->
                    val i = req.indexOf(perm)
                    if (i >= 0 && (flags[i] and android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) holders[g]!!.add(a.name)
                }
            } catch (e: Exception) { }
        }
        holders.forEach { (g, names) -> items.add(ScanItem("Apps with $g access", "${names.size}", null, names.sorted().joinToString("\n"))) }
        return ScanSection("permissions", "Permissions", "$ok of ${mine.size} Nova permissions granted", ok / mine.size.toFloat(), items)
    }

    private fun notifications(): ScanSection {
        val enabled = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        val listener = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        return ScanSection("notifications", "Notifications", if (listener) "Access on" else "Access off", null, listOf(
            ScanItem("Nova can post notifications", if (enabled) "Yes" else "No"),
            ScanItem("Notification access", if (listener) "Enabled" else "Disabled"),
            ScanItem("Apps included", "${prefs.notifAllowed.size}")
        ))
    }

    private fun accessibility(): ScanSection {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val names = am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .map { it.resolveInfo.loadLabel(pm).toString() }
        val on = NovaAccessibilityService.instance != null
        return ScanSection("accessibility", "Accessibility", if (on) "Screen assistant on" else "Screen assistant off", null, listOf(
            ScanItem("Nova screen assistant", if (on) "Enabled" else "Disabled"),
            ScanItem("Enabled services (all apps)", "${names.size}", null, names.joinToString("\n"))
        ))
    }

    private fun features(): ScanSection {
        val f = pm.systemAvailableFeatures.mapNotNull { it.name }.sorted()
        return ScanSection("features", "System features", "${f.size} features", null, listOf(
            ScanItem("Advertised features", "${f.size}", null, f.joinToString("\n")),
            ScanItem("Wi-Fi Direct", if (has("android.hardware.wifi.direct")) "Available" else "Not available"),
            ScanItem("Live wallpapers", if (has("android.software.live_wallpaper")) "Available" else "Not available")
        ))
    }
}
