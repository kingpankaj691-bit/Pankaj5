package com.nova.ai.suite

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class AssetItem(val id: String, val name: String, val type: String, val sizeBytes: Long, val addedAt: Long, val lastUsed: Long, val mime: String)

/**
 * Nova's asset library: images, videos, audio, editing presets, XML templates, project files, scripts, code snippets and plugins.
 * Files are copied into Nova's private storage (files/assets/<type>/) with an index, so they stay available even if the original moves.
 * Preview, copy, share (FileProvider), export (system "save as" picker), open, recent history and delete are real; drag-and-drop uses
 * Android's global drag with a content URI and only works where the target app accepts drops (usually split-screen).
 */
object AssetManager {
    val types = listOf("image", "video", "audio", "preset", "template", "project", "script", "snippet", "plugin", "other")
    private val textTypes = setOf("template", "script", "snippet", "preset")
    private const val INDEX = "assets_index.json"

    fun typeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif" -> "image"
            "mp4", "mkv", "mov", "webm", "3gp", "avi" -> "video"
            "mp3", "wav", "m4a", "aac", "ogg", "flac", "opus" -> "audio"
            "alp", "cube", "lut", "3dl", "preset", "xmp" -> "preset"
            "xml" -> "template"
            "zip", "7z", "tar", "gz", "gradle", "kts", "toml", "properties" -> "project"
            "sh", "py", "js", "bat" -> "script"
            "txt", "md", "kt", "java", "html", "css", "json", "yaml", "yml", "csv" -> "snippet"
            "jar", "dex", "so" -> "plugin"
            else -> "other"
        }
    }

    fun mimeOf(name: String): String = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
    fun isText(item: AssetItem) = item.type in textTypes || item.type == "project" && item.name.substringAfterLast('.').lowercase() in setOf("gradle", "kts", "toml", "properties")

    private fun root(ctx: Context) = File(ctx.filesDir, "assets").also { it.mkdirs() }
    fun fileOf(ctx: Context, item: AssetItem) = File(File(root(ctx), item.type), item.id)
    fun uriOf(ctx: Context, item: AssetItem): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", fileOf(ctx, item))

    // ── index ──
    private fun readIndex(ctx: Context): MutableList<AssetItem> = try {
        val a = JSONArray(File(ctx.filesDir, INDEX).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> AssetItem(o.getString("id"), o.getString("name"), o.getString("type"), o.getLong("size"), o.getLong("added"), o.getLong("used"), o.optString("mime")) } }.toMutableList()
    } catch (e: Exception) { mutableListOf() }

    private fun writeIndex(ctx: Context, items: List<AssetItem>) {
        try {
            val a = JSONArray(); items.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type).put("size", it.sizeBytes).put("added", it.addedAt).put("used", it.lastUsed).put("mime", it.mime)) }
            File(ctx.filesDir, INDEX).writeText(a.toString())
        } catch (e: Exception) { }
    }

    fun list(ctx: Context, type: String? = null): List<AssetItem> = readIndex(ctx).filter { type == null || it.type == type }.sortedByDescending { it.addedAt }
    fun recent(ctx: Context, n: Int = 5): List<AssetItem> = readIndex(ctx).sortedByDescending { it.lastUsed }.take(n)

    private fun displayName(ctx: Context, uri: Uri): String {
        try { ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { return it } } } catch (e: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "asset"
    }

    private fun safe(name: String) = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(100).ifBlank { "asset" }

    /** Copies a picked file into the library. Returns null if it can't be read. */
    fun importUri(ctx: Context, uri: Uri): AssetItem? {
        val name = safe(displayName(ctx, uri))
        val type = typeOf(name)
        val dir = File(root(ctx), type).also { it.mkdirs() }
        var id = name; var n = 1
        while (File(dir, id).exists()) { id = name.substringBeforeLast('.', name) + "_" + n++ + (if (name.contains('.')) "." + name.substringAfterLast('.') else "") }
        val dest = File(dir, id)
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use { input.copyTo(it) } } ?: return null
            val now = System.currentTimeMillis()
            val item = AssetItem(id, name, type, dest.length(), now, now, mimeOf(name))
            val all = readIndex(ctx); all.add(item); writeIndex(ctx, all)
            item
        } catch (e: Exception) { dest.delete(); null }
    }

    /** Saves text (for example the clipboard) as a snippet file. */
    fun saveSnippet(ctx: Context, name: String, text: String): AssetItem? {
        val clean = safe(name).let { if (it.contains('.')) it else "$it.txt" }
        val dir = File(root(ctx), "snippet").also { it.mkdirs() }
        var id = clean; var n = 1
        while (File(dir, id).exists()) { id = clean.substringBeforeLast('.') + "_" + n++ + "." + clean.substringAfterLast('.') }
        return try {
            File(dir, id).writeText(text)
            val now = System.currentTimeMillis()
            val item = AssetItem(id, clean, "snippet", File(dir, id).length(), now, now, mimeOf(clean))
            val all = readIndex(ctx); all.add(item); writeIndex(ctx, all); item
        } catch (e: Exception) { null }
    }

    fun markUsed(ctx: Context, item: AssetItem) {
        val all = readIndex(ctx)
        val i = all.indexOfFirst { it.id == item.id && it.type == item.type }
        if (i >= 0) { all[i] = all[i].copy(lastUsed = System.currentTimeMillis()); writeIndex(ctx, all) }
    }

    fun delete(ctx: Context, item: AssetItem): Boolean {
        fileOf(ctx, item).delete()
        val all = readIndex(ctx); val ok = all.removeAll { it.id == item.id && it.type == item.type }; writeIndex(ctx, all); return ok
    }

    // ── preview / copy / share / export / open / drag ──
    fun previewText(ctx: Context, item: AssetItem, max: Int = 4000): String? =
        if (!isText(item)) null else try { fileOf(ctx, item).bufferedReader().use { r -> val b = CharArray(max); val n = r.read(b); if (n > 0) String(b, 0, n) else "" } } catch (e: Exception) { null }

    fun previewBitmap(ctx: Context, item: AssetItem, maxSide: Int = 512): Bitmap? {
        if (item.type != "image") return null
        return try {
            val f = fileOf(ctx, item).absolutePath
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f, o)
            var s = 1; while (o.outWidth / s > maxSide * 2 || o.outHeight / s > maxSide * 2) s *= 2
            BitmapFactory.decodeFile(f, BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.RGB_565 })
        } catch (e: Exception) { null }
    }

    /** Text assets are copied as text; every other asset is copied as a file reference other apps can paste. */
    fun copy(ctx: Context, item: AssetItem): String {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        markUsed(ctx, item)
        if (isText(item)) {
            val t = try { fileOf(ctx, item).readText().take(200_000) } catch (e: Exception) { return "Couldn't read the file." }
            cm.setPrimaryClip(ClipData.newPlainText(item.name, t)); return "Text copied (${t.length} characters)."
        }
        cm.setPrimaryClip(ClipData.newUri(ctx.contentResolver, item.name, uriOf(ctx, item))); return "File reference copied. Apps that accept files can paste it."
    }

    fun share(ctx: Context, item: AssetItem): Boolean = try {
        markUsed(ctx, item)
        val send = Intent(Intent.ACTION_SEND).setType(item.mime.ifBlank { "*/*" }).putExtra(Intent.EXTRA_STREAM, uriOf(ctx, item)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share " + item.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)); true
    } catch (e: Exception) { false }

    fun open(ctx: Context, item: AssetItem): Boolean = try {
        markUsed(ctx, item)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(ctx, item), item.mime.ifBlank { "*/*" }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** Writes the asset to a location the user picked with the system "save as" dialog. */
    fun exportTo(ctx: Context, item: AssetItem, dest: Uri): Boolean = try {
        markUsed(ctx, item)
        ctx.contentResolver.openOutputStream(dest)?.use { out -> fileOf(ctx, item).inputStream().use { it.copyTo(out) } } != null
    } catch (e: Exception) { false }

    /** ClipData for a global drag. Only apps that accept dropped content (multi-window targets) will react. */
    fun dragClip(ctx: Context, item: AssetItem): ClipData { markUsed(ctx, item); return ClipData.newUri(ctx.contentResolver, item.name, uriOf(ctx, item)) }

    fun humanSize(b: Long) = when { b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0); b >= 1024 -> "${b / 1024} KB"; else -> "$b B" }
}
