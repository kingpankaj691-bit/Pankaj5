package com.nova.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.security.Prefs
import com.nova.ai.suite.AppContext
import com.nova.ai.suite.AudioDucker
import com.nova.ai.suite.GitHubActions
import com.nova.ai.suite.LogAnalyzer
import com.nova.ai.suite.PendingCommand
import com.nova.ai.suite.SystemControls
import com.nova.ai.suite.TermuxBridge
import com.nova.ai.vision.ScreenCaptureManager
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun openSettings(ctx: Context, action: String, pkgUri: Boolean = false) {
    try {
        val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkgUri) i.data = Uri.parse("package:" + ctx.packageName)
        ctx.startActivity(i)
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { }
    }
}

/** Live status of every sensitive capability, with the switch or Android page that controls it. Nothing here hides or changes anything silently. */
@Composable
fun PrivacyDashboardScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var rev by remember { mutableIntStateOf(0) }
    val voiceRunning by VoiceState.running.collectAsState()
    val voicePaused by VoiceState.paused.collectAsState()
    var duck by remember { mutableStateOf(AudioDucker.enabled(ctx)) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(rev) { }
    val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val a11y = NovaAccessibilityService.instance != null
    val notifAccess = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val overlay = Settings.canDrawOverlays(ctx)
    val capture = ScreenCaptureManager.active
    val dnd = SystemControls.dndAccessGranted(ctx)

    @Composable
    fun row(title: String, on: Boolean, detail: String, openAction: String?, pkg: Boolean = false) {
        val act: (() -> Unit)? = if (openAction != null) {
            val go: () -> Unit = { openSettings(ctx, openAction, pkg); rev = rev + 1 }
            go
        } else null
        val tr: (@Composable () -> Unit)? = if (openAction != null) {
            val t: @Composable () -> Unit = { GText("Manage ›", size = 12.sp, color = g.subtext) }
            t
        } else null
        GlassListItem(title, detail + if (on) "" else " — off", glyph = if (on) "🟢" else "⚪", onClick = act, trailing = tr)
    }

    SubPage("Privacy Dashboard", onBack) {
        GlassSettingSection("What Nova can access right now") {
            row("Microphone", mic, if (mic) "Permission granted" else "Permission not granted", Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true)
            row("Background voice service", voiceRunning && !voicePaused, if (!voiceRunning) "Not running" else if (voicePaused) "Paused (microphone released)" else "Running, notification visible", null)
            row("Accessibility (screen reading & control)", a11y, if (a11y) "Enabled" else "Not enabled", Settings.ACTION_ACCESSIBILITY_SETTINGS)
            row("Notification access", notifAccess, if (notifAccess) "Enabled" else "Not enabled", "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            row("Live OCR", com.nova.ai.suite.LiveOcr.running, if (com.nova.ai.suite.LiveOcr.running) "Reading the screen every few seconds — say \"live OCR band karo\" to stop" else "Not running", null)
            row("Screen capture", capture, if (capture) "Active — stop it from the notification" else "Not capturing", null)
            row("Display over other apps (orb, sheets)", overlay, if (overlay) "Allowed" else "Not allowed", Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
            row("Do Not Disturb access", dnd, if (dnd) "Granted" else "Not granted", Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            GText("Turn any of these off in the Android page it opens. Nova can't re-enable them by itself.", size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Controls") {
            GlassListItem("Lower other audio while Nova talks", "Uses Android audio focus; never changes your media volume", trailing = {
                GlassSwitch(duck) { duck = it; AudioDucker.setEnabled(ctx, it) }
            })
        }
        GlassSettingSection("Floating orb") {
            var dbl by remember { mutableStateOf(ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getString(com.nova.ai.jarvis.FloatingOrb.PREF_DOUBLE, "none") ?: "none") }
            GlassListItem("Double tap action", com.nova.ai.jarvis.FloatingOrb.doubleLabel(dbl) + " · tap to change", onClick = {
                val c = com.nova.ai.jarvis.FloatingOrb.doubleChoices
                dbl = c[(c.indexOf(dbl) + 1) % c.size]
                ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).edit().putString(com.nova.ai.jarvis.FloatingOrb.PREF_DOUBLE, dbl).apply()
            })
            GText("Tap talks, long press opens the quick menu, drag moves it. With a double-tap action set, a single tap waits a third of a second.", size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Data kept on this phone") {
            val n = remember(rev) { LogAnalyzer.history(ctx).size }
            GlassListItem("Error history", "$n saved analysis result(s), stored only in app storage")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Clear error history", { LogAnalyzer.clearHistory(ctx); msg = "Error history cleared."; rev++ })
                GlassButton("Remove GitHub token", { GitHubActions(Prefs(ctx)).token = ""; msg = "GitHub token removed." })
            }
            if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.subtext)
        }
    }
}

/** Termux, GitHub Actions, log analysis and system shortcuts. Every action that changes something shows a preview and waits for you. */
@Composable
fun DevIntegrationsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val prefs = remember { Prefs(ctx) }
    val gh = remember { GitHubActions(prefs) }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    // Termux
    var cmdText by remember { mutableStateOf("") }
    var workDir by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<PendingCommand?>(null) }
    val termuxResult by TermuxBridge.last.collectAsState()

    // GitHub
    var token by remember { mutableStateOf("") }
    var repo by remember { mutableStateOf(gh.repo) }
    var workflow by remember { mutableStateOf(gh.workflow) }
    var branch by remember { mutableStateOf(gh.branch) }
    var runsText by remember { mutableStateOf("") }
    var confirmTrigger by remember { mutableStateOf(false) }
    var repoChoices by remember { mutableStateOf<List<String>>(emptyList()) }
    var wfChoices by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var apk by remember { mutableStateOf<com.nova.ai.suite.ApkFile?>(null) }

    // Logs
    var logText by remember { mutableStateOf("") }
    var logResult by remember { mutableStateOf("") }

    fun explain(text: String, what: String) {
        if (!prefs.hasActiveKey() || prefs.localOnly || !prefs.aiEnabled) { msg = "AI explanation needs an API key, AI on and local-only off. The sanitized text goes to your selected model."; return }
        busy = true; msg = "Asking the selected model…"
        scope.launch {
            val sys = "You are a senior Android/Kotlin engineer. Explain the error in plain words, then give a minimal fix in fenced code. Nova AI: package com.nova.ai, Kotlin, Compose, minSdk 26. Do not invent APIs or versions. Say if unsure." + AppContext.hint("com.itsaky.androidide")
            val r = withContext(Dispatchers.IO) { SwitchingProvider(prefs).chat(listOf(true to "$what:\n" + LogAnalyzer.clean(text).takeLast(9000)), sys, null) }
            logResult = when (r) { is AiResult.Ok -> r.text.trim(); is AiResult.Err -> "⚠ " + r.msg }
            busy = false; msg = ""
        }
    }

    SubPage("Developer Integrations", onBack) {
        GlassSettingSection("Termux") {
            val inst = TermuxBridge.installed(ctx)
            val perm = TermuxBridge.permissionGranted(ctx)
            GText(if (!inst) "Termux is not installed." else if (!perm) "Termux found. Permission \"Run commands in Termux environment\" is not granted (Android Settings > Apps > Nova AI > Permissions)." else "Termux ready. Also needs allow-external-apps = true in ~/.termux/termux.properties.", size = 12.sp, color = g.subtext)
            GlassTextField(workDir, { workDir = it }, Modifier.fillMaxWidth(), placeholder = "Project folder (e.g. /data/data/com.termux/files/home/NovaAI)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("git status", { cmdText = TermuxBridge.gitStatus(workDir.ifBlank { "." }) })
                GlassButton("git log", { cmdText = TermuxBridge.gitLog(workDir.ifBlank { "." }) })
                GlassButton("Gradle debug build", { cmdText = TermuxBridge.gradleAssembleDebug(workDir.ifBlank { "." }) })
            }
            GlassTextField(cmdText, { cmdText = it }, Modifier.fillMaxWidth(), placeholder = "Command to run", singleLine = false, minLines = 2)
            GlassButton("Review command", {
                val (p, why) = TermuxBridge.prepare(cmdText, workDir.ifBlank { "" }, "Typed by you")
                pending = p; msg = why ?: ""
            }, primary = true, enabled = cmdText.isNotBlank())
            pending?.let { c ->
                GlassCard(Modifier.fillMaxWidth(), strong = true) {
                    androidx.compose.foundation.layout.Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GText("Nova will send exactly this to Termux:", size = 12.sp, color = g.subtext)
                        GText(c.command, size = 13.sp)
                        GText("Folder: ${c.workDir}", size = 11.sp, color = g.subtext)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Approve & run", { msg = TermuxBridge.run(ctx, c) ?: "Sent. Waiting for the result…"; pending = null }, primary = true)
                            GlassButton("Cancel", { pending = null })
                        }
                    }
                }
            }
            termuxResult?.let { r ->
                GText("Exit code ${r.exitCode}" + if (r.error.isNotBlank()) " · ${r.error}" else "", size = 12.sp)
                if (r.stdout.isNotBlank()) GText(r.stdout.takeLast(1500), size = 11.sp, color = g.subtext)
                if (r.stderr.isNotBlank()) GText(r.stderr.takeLast(1500), size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Analyze errors", { val t = r.stderr + "\n" + r.stdout; logText = t; logResult = LogAnalyzer.summary(LogAnalyzer.analyze(t)) })
                    GlassButton("Copy output", { clip.setText(AnnotatedString(r.stdout + "\n" + r.stderr)) })
                }
            }
        }

        GlassSettingSection("GitHub Actions") {
            GText("Use a fine-grained token limited to one repository with Actions read/write. It is stored encrypted and never shown again.", size = 12.sp, color = g.subtext)
            GlassTextField(token, { token = it }, Modifier.fillMaxWidth(), placeholder = if (gh.token.isBlank()) "Personal access token" else "Token saved (type to replace)", visual = PasswordVisualTransformation())
            GlassTextField(repo, { repo = it }, Modifier.fillMaxWidth(), placeholder = "owner/repository")
            GlassTextField(workflow, { workflow = it }, Modifier.fillMaxWidth(), placeholder = "Workflow file (e.g. build.yml)")
            GlassTextField(branch, { branch = it }, Modifier.fillMaxWidth(), placeholder = "Branch (main)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Save", {
                    if (!gh.validRepo(repo.trim())) msg = "Repository must look like owner/name."
                    else { if (token.isNotBlank()) gh.token = token.trim(); token = ""; gh.repo = repo; gh.workflow = workflow; gh.branch = branch; msg = "GitHub settings saved." }
                }, primary = true)
                GlassButton("Run workflow…", { confirmTrigger = true }, enabled = gh.configured() && workflow.isNotBlank())
                GlassButton(if (busy) "Checking…" else "Check status", {
                    if (!busy) { busy = true; scope.launch {
                        val res = withContext(Dispatchers.IO) { gh.runs(5) }
                        runsText = res.error ?: res.value.orEmpty().joinToString("\n") { "${fmt.format(Date())} · " + gh.describe(it) + "\n${it.url}" }.ifBlank { "No runs yet." }
                        busy = false } }
                })
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Pick repository", { if (gh.token.isBlank() && token.isBlank()) msg = "Save a token first." else { if (token.isNotBlank()) gh.token = token.trim(); scope.launch { val r = withContext(Dispatchers.IO) { gh.myRepos() }; repoChoices = r.value.orEmpty(); msg = r.error ?: "" } } })
                GlassButton("Pick workflow", { if (!gh.validRepo(repo.trim())) msg = "Choose or type a repository first." else { gh.repo = repo; scope.launch { val r = withContext(Dispatchers.IO) { gh.workflows() }; wfChoices = r.value.orEmpty(); msg = r.error ?: "" } } })
                GlassButton(if (busy) "Working…" else "Download latest APK", {
                    if (!busy && gh.configured()) { busy = true; scope.launch {
                        val res = withContext(Dispatchers.IO) { gh.runs(5) }
                        val run = res.value?.firstOrNull { it.status == "completed" && it.conclusion == "success" }
                        if (run == null) { msg = res.error ?: "No successful run found yet."; busy = false; return@launch }
                        val arts = withContext(Dispatchers.IO) { gh.artifactList(run.id) }.value.orEmpty().filter { !it.expired }
                        val art = arts.firstOrNull { it.name.contains("apk", true) } ?: arts.firstOrNull()
                        if (art == null) { msg = "That run has no downloadable artifact."; busy = false; return@launch }
                        msg = "Downloading ${art.name}…"
                        val r = withContext(Dispatchers.IO) { gh.downloadApk(ctx, art) }
                        apk = r.value; msg = r.error ?: "Downloaded. Compare the SHA-256 before installing."; busy = false
                    } }
                })
            }
            repoChoices.take(30).forEach { r -> GlassListItem(r, "Tap to use", onClick = { repo = r; gh.repo = r; repoChoices = emptyList() }) }
            wfChoices.forEach { (n, f) -> GlassListItem(n, f, onClick = { workflow = f; gh.workflow = f; wfChoices = emptyList() }) }
            apk?.let { a ->
                GlassCard(Modifier.fillMaxWidth(), strong = true) {
                    androidx.compose.foundation.layout.Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GText("${a.file.name} · ${a.sizeBytes / 1024 / 1024} MB", size = 14.sp)
                        GText("SHA-256: " + a.sha256, size = 11.sp, color = g.subtext)
                        GText("Checked: valid zip, contains an .apk. Android's installer will ask you to confirm.", size = 11.sp, color = g.subtext)
                        GlassButton("Install", { try { ctx.startActivity(gh.installIntent(ctx, a.file)) } catch (e: Exception) { msg = "Couldn't open the installer: ${e.message}" } }, primary = true)
                    }
                }
            }
            if (confirmTrigger) GlassCard(Modifier.fillMaxWidth(), strong = true) {
                androidx.compose.foundation.layout.Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GText("Start workflow ${gh.workflow} on ${gh.branch} in ${gh.repo}?", size = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Yes, start", { confirmTrigger = false; scope.launch { val r = withContext(Dispatchers.IO) { gh.trigger() }; msg = r.error ?: "Workflow started. Tap Check status in a minute." } }, primary = true)
                        GlassButton("Cancel", { confirmTrigger = false })
                    }
                }
            }
            if (runsText.isNotBlank()) GText(runsText, size = 12.sp, color = g.subtext)
            GText("Artifact downloads need your GitHub login, so Nova links the run page instead of a direct APK URL.", size = 11.sp, color = g.subtext)
        }

        GlassSettingSection("Log & build error analysis") {
            GlassTextField(logText, { logText = it }, Modifier.fillMaxWidth(), placeholder = "Paste a Gradle / Kotlin / crash log", singleLine = false, minLines = 4)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Analyze", {
                    val f = LogAnalyzer.analyze(logText); logResult = LogAnalyzer.summary(f)
                    if (f.isNotEmpty()) LogAnalyzer.remember(ctx, logResult)
                }, primary = true, enabled = logText.isNotBlank())
                GlassButton("Nova's own logcat", { scope.launch { logText = withContext(Dispatchers.IO) { LogAnalyzer.ownLogcat(300) }.ifBlank { "Logcat isn't available on this phone." } } })
                GlassButton(if (busy) "Asking…" else "Explain with AI", { if (!busy && logText.isNotBlank()) explain(logText, "Build/crash log") }, enabled = logText.isNotBlank())
            }
            if (logResult.isNotBlank()) { GText(logResult, size = 13.sp); GlassButton("Copy", { clip.setText(AnnotatedString(logResult)) }) }
            val hist = remember(logResult) { LogAnalyzer.history(ctx).take(5) }
            hist.forEach { (t, s) -> GlassListItem(fmt.format(Date(t)), s.lines().firstOrNull().orEmpty()) }
            GText("Android only lets Nova read its own logcat. Logs from other apps need you to paste or share them.", size = 11.sp, color = g.subtext)
        }

        GlassSettingSection("Workflow history") {
            val wh = remember(msg) { com.nova.ai.suite.Workflows.History.list(ctx).take(6) }
            if (wh.isEmpty()) GText("No workflows run yet. Try: \"latest exported video YouTube upload ke liye title description prepare karo\".", size = 12.sp, color = g.subtext)
            wh.forEach { (t, n, st) -> GlassListItem(n, fmt.format(Date(t)) + " · " + st) }
            if (wh.isNotEmpty()) GlassButton("Clear history", { com.nova.ai.suite.Workflows.History.clear(ctx); msg = "Workflow history cleared." })
        }

        GlassSettingSection("System shortcuts") {
            var dndOn by remember { mutableStateOf(SystemControls.dndOn(ctx)) }
            GlassListItem("Do Not Disturb", if (SystemControls.dndAccessGranted(ctx)) "Priority only when on" else "Needs special access (opens the page)", trailing = {
                GlassSwitch(dndOn) { v -> msg = SystemControls.setDnd(ctx, v); dndOn = SystemControls.dndOn(ctx) }
            })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Bluetooth", { msg = SystemControls.openBluetooth(ctx) })
                GlassButton("Wi-Fi", { msg = SystemControls.openWifi(ctx) })
                GlassButton("Airplane", { msg = SystemControls.openAirplane(ctx) })
                GlassButton("Display", { msg = SystemControls.openDisplay(ctx) })
                GlassButton("Private DNS", { msg = SystemControls.openPrivateDns(ctx) })
            }
            GText(SystemControls.networkInfo(ctx) + " " + SystemControls.batteryInfo(ctx), size = 12.sp, color = g.subtext)
        }
        if (msg.isNotBlank()) GText(msg, size = 13.sp)
    }
}
