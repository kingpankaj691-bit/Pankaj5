package com.nova.ai.security

import android.app.KeyguardManager
import android.content.Context
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level

/** Decides what Nova may do while the phone is locked. Private data is never revealed on the lock screen. */
object LockPolicy {
    fun isLocked(ctx: Context): Boolean {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isDeviceLocked || km.isKeyguardLocked
    }

    /** Returns null when allowed, otherwise what Nova should say. */
    fun check(r: CmdResult, prefs: Prefs): String? {
        if (r.sensitiveInfo) return "That's private. Unlock your phone first."
        val ok = when (r.tag) {
            "flashlight" -> prefs.lockFlashlight
            "timer" -> prefs.lockTimer
            "status" -> prefs.lockStatus
            "basic" -> prefs.lockBasic
            else -> if (r.level == Level.Sensitive && prefs.lockRequireUnlock) false else prefs.lockBasic
        }
        return if (ok) null else "Unlock your phone first."
    }
}
