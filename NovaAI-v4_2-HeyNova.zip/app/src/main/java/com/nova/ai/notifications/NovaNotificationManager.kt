package com.nova.ai.notifications

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.nova.ai.core.NotificationManager
import com.nova.ai.security.Prefs

class NovaNotificationManager(private val ctx: Context, private val prefs: Prefs) : NotificationManager {
    override fun isAccessEnabled() = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    override fun allowedApps(): Set<String> = prefs.notifAllowed
    override fun setAllowedApps(s: Set<String>) { prefs.notifAllowed = s }
    override fun summary(): String = NovaNotificationListener.summaryText()
}
