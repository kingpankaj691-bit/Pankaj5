package com.nova.ai.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.security.Prefs
import com.nova.ai.suite.AppContext
import com.nova.ai.suite.AssetItem
import com.nova.ai.suite.AssetManager
import com.nova.ai.suite.AudioDucker
import com.nova.ai.suite.DeviceMgmt
import com.nova.ai.suite.Features
import com.nova.ai.suite.GitHubActions
import com.nova.ai.suite.LiveOcr
import com.nova.ai.suite.LogAnalyzer
import com.nova.ai.suite.Retention
import com.nova.ai.suite.ScreenTools
import com.nova.ai.suite.SecurityWatch
import com.nova.ai.suite.SystemControls
import com.nova.ai.suite.TermuxBridge
import com.nova.ai.suite.UsageInfo
import com.nova.ai.suite.Workflows
import com.nova.ai.voice.VoiceState
import com.nova.ai.vision.ScreenCaptureManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun Context.activity(): Activity? { var c: Context = this; while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }; return null }
private fun launchSettings(ctx: Context, action: String, pkg: Boolean = false) {
    try { val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); if (pkg) i.data = Uri.parse("package:" + ctx.packageName); ctx.startActivity(i) } catch (e: Exception) { }
}

@Composable private fun FeatureSwitch(ctx: Context, key: String, label: String) {
    var on by remember { mutableStateOf(Features.enabled(ctx, key)) }
    GlassListItem(label, if (on) "On" else "Off — Nova's entry points for this section refuse to run", trailing = { GlassSwitch(on) { on = it; Features.set(ctx, key, it) } })
}

@Composable private fun PrefSwitch(ctx: Context, key: String, title: String, detail: String, def: Boolean = true) {
    var on by remember { mutableStateOf(Features.getBool(ctx, key, def)) }
    GlassListItem(title, detail, trailing = { GlassSwitch(on) { on = it; Features.putBool(ctx, key, it) } })
}

@Composable private fun Status(title: String, on: Boolean, detail: String, onClick: (() -> Unit)? = null) {
    val g = LocalGlass.current
    val tr: (@Composable () -> Unit)? = if (onClick != null) {
        val t: @Composable () -> Unit = { GText("Manage ›", size = 12.sp, color = g.subtext) }
        t
    } else null
    GlassListItem(title, detail, glyph = if (on) "🟢" else "⚪", onClick = onClick, trailing = tr)
}

/** The 12 sections of the spec in one place. Every section has a real on/off, permission status, configuration and usage status. */
@Composable
fun ControlCenterScreen(open: (Int) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var rev by remember { mutableIntStateOf(0) }
    val voiceRunning by VoiceState.running.collectAsState()
    val prefs = remember { Prefs(ctx) }
    val jp = remember { JarvisPrefs(ctx) }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    val langs = remember { listOf("None", "Hindi", "English", "Hinglish") }

    SubPage("Control Center", onBack) {
        val tick = rev   // re-read statuses after a change
        val a11y = SecurityWatch.snapshot(ctx)["Accessibility"] == true
        val overlay = Settings.canDrawOverlays(ctx)

        GlassSettingSection("1 · Screen Intelligence") {
            FeatureSwitch(ctx, Features.SCREEN, "Enable screen understanding")
            Status("Accessibility (reads the screen)", a11y, if (a11y) "Enabled" else "Not enabled", { launchSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS); rev++ })
            PrefSwitch(ctx, "app_hints", "App-aware help", "WhatsApp, Chrome, AndroidIDE, Instagram, CapCut get tailored guidance")
            val fg = NovaAccessibilityService.foregroundPackage
            GText("In front now: " + if (fg.isBlank()) "unknown" else "$fg (${AppContext.label(fg)})", size = 12.sp, color = g.subtext)
            GlassButton("Summarize this screen", { ScreenTools.summarize(ctx) })
        }

        GlassSettingSection("2 · Vision & OCR") {
            FeatureSwitch(ctx, Features.VISION, "Enable OCR features")
            Status("Screen capture (for unselectable text)", ScreenCaptureManager.active, if (ScreenCaptureManager.active) "Active" else "Not capturing — start Screen Vision on the Screen Assistant page", null)
            var lang by remember { mutableStateOf(Features.getString(ctx, "ocr_lang", "None")) }
            GlassListItem("Live OCR translation", "Language: $lang · tap to change", onClick = { lang = langs[(langs.indexOf(lang) + 1) % langs.size]; Features.putString(ctx, "ocr_lang", lang) })
            GlassListItem("Live OCR", if (LiveOcr.running) "Running" + (LiveOcr.target?.let { " → $it" } ?: "") else "Stopped — or say \"live OCR on\"", trailing = {
                GlassSwitch(LiveOcr.running) { v -> if (v) LiveOcr.start(ctx, lang.takeIf { it != "None" }) else LiveOcr.stop(ctx); rev++ }
            })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Extract text", { ScreenTools.extract(ctx) }); GlassButton("Translate screen", { ScreenTools.translate(ctx, lang.takeIf { it != "None" } ?: "Hindi") })
            }
        }

        GlassSettingSection("3 · Accessibility Automation") {
            FeatureSwitch(ctx, Features.AUTOMATION, "Enable the agent (\"khud karo ...\")")
            var actionsOn by remember { mutableStateOf(prefs.screenActionsOn) }
            GlassListItem("Screen actions (taps, typing)", "Master switch for everything that touches other apps", trailing = { GlassSwitch(actionsOn) { actionsOn = it; prefs.screenActionsOn = it } })
            var steps by remember { mutableIntStateOf(Features.getInt(ctx, "agent_steps", 30)) }
            GlassListItem("Agent step limit", "$steps steps per task · tap to change", onClick = { steps = when (steps) { 10 -> 20; 20 -> 30; else -> 10 }; Features.putInt(ctx, "agent_steps", steps) })
            Status("Agent / workflow running", Workflows.active, if (Workflows.active) "Running" else "Idle", null)
            if (Workflows.active) GlassButton("Stop now", { Workflows.cancel(); rev++ })
        }

        GlassSettingSection("4 · Floating Orb") {
            var orb by remember { mutableStateOf(jp.orb) }
            GlassListItem("Show the orb", "Applies when the background voice starts next", trailing = { GlassSwitch(orb) { orb = it; jp.orb = it } })
            Status("Display over other apps", overlay, if (overlay) "Allowed" else "Not allowed", { launchSettings(ctx, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true); rev++ })
            var dbl by remember { mutableStateOf(Features.getString(ctx, com.nova.ai.jarvis.FloatingOrb.PREF_DOUBLE, "none")) }
            GlassListItem("Double tap", com.nova.ai.jarvis.FloatingOrb.doubleLabel(dbl) + " · tap to change", onClick = {
                val c = com.nova.ai.jarvis.FloatingOrb.doubleChoices; dbl = c[(c.indexOf(dbl) + 1) % c.size]; Features.putString(ctx, com.nova.ai.jarvis.FloatingOrb.PREF_DOUBLE, dbl)
            })
            GText("Tap talks · long press = quick menu · drag moves and snaps to the edge. Dot: green online, grey offline.", size = 12.sp, color = g.subtext)
        }

        GlassSettingSection("5 · Voice & Wake Word") {
            val mic = SecurityWatch.snapshot(ctx)["Microphone"] == true
            Status("Microphone", mic, if (mic) "Granted" else "Not granted", { launchSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true); rev++ })
            Status("Background voice", voiceRunning, if (voiceRunning) "Running (notification visible)" else "Not running", null)
            var name by remember { mutableStateOf(jp.wakeName) }
            GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Wake name (default: nova)")
            GlassButton("Save wake name", { jp.wakeName = name })
            var gate by remember { mutableStateOf(jp.wakeGate) }
            GlassListItem("Offline wake gate", "Nothing goes to Gemini until the offline recognizer hears the name", trailing = { GlassSwitch(gate) { gate = it; jp.wakeGate = it } })
            var intr by remember { mutableStateOf(jp.interrupt) }
            GlassListItem("Interrupt Nova while she speaks", "Uses the echo-cancelling microphone", trailing = { GlassSwitch(intr) { intr = it; jp.interrupt = it } })
            GText("Porcupine wake word is not included: it needs your own Picovoice AccessKey and a trained model file (third-party licence). The offline Vosk wake name above works without any account.", size = 11.sp, color = g.subtext)
        }

        GlassSettingSection("6 · Audio Control") {
            var duck by remember { mutableStateOf(AudioDucker.enabled(ctx)) }
            GlassListItem("Lower other audio while Nova talks", "Android audio focus; calls are never interrupted", trailing = { GlassSwitch(duck) { duck = it; AudioDucker.setEnabled(ctx, it) } })
            var duckUser by remember { mutableStateOf(AudioDucker.duckOnUser(ctx)) }
            GlassListItem("Also lower it while I speak", "Triggered by your microphone level", trailing = { GlassSwitch(duckUser) { duckUser = it; AudioDucker.setDuckOnUser(ctx, it) } })
            val dnd = SystemControls.dndAccessGranted(ctx)
            Status("Do Not Disturb access", dnd, if (dnd) "Granted · ${if (SystemControls.dndOn(ctx)) "DND is on" else "DND is off"}" else "Not granted", { launchSettings(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS); rev++ })
        }

        GlassSettingSection("7 · Cross-App Workflows") {
            FeatureSwitch(ctx, Features.WORKFLOWS, "Enable workflows (YouTube, Instagram, share)")
            val media = Workflows.hasMediaPermission(ctx)
            Status("Photos & videos permission", media, if (media) "Granted" else "Not granted — you can still use the document picker", { launchSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true); rev++ })
            val h = Workflows.History.list(ctx)
            GText("${h.size} runs in history" + (h.firstOrNull()?.let { " · last: ${it.second} (${fmt.format(Date(it.first))})" } ?: ""), size = 12.sp, color = g.subtext)
            GlassButton("Clear workflow history", { Workflows.History.clear(ctx); rev++ })
        }

        GlassSettingSection("8 · Developer Tools") {
            val n = LogAnalyzer.history(ctx).size
            GlassListItem("Build & crash analysis", "$n saved results · Developer Integrations", onClick = { open(20) })
            GlassListItem("Developer tools (code helper)", "Existing Nova developer page", onClick = { open(17) })
        }

        GlassSettingSection("9 · Termux Integration") {
            FeatureSwitch(ctx, Features.TERMUX, "Enable Termux commands")
            val inst = TermuxBridge.installed(ctx); val perm = TermuxBridge.permissionGranted(ctx)
            Status("Termux installed", inst, if (inst) "Yes" else "No", null)
            Status("Run-commands permission", perm, if (perm) "Granted" else "Not granted (Settings > Apps > Nova AI > Permissions)", { launchSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true) })
            GText("Also needs allow-external-apps = true in ~/.termux/termux.properties. Every command is shown to you first.", size = 12.sp, color = g.subtext)
            GlassButton("Open command review", { open(20) })
        }

        GlassSettingSection("10 · GitHub Actions") {
            FeatureSwitch(ctx, Features.GITHUB, "Enable GitHub Actions")
            val gh = remember { GitHubActions(prefs) }
            Status("Token and repository", gh.configured(), if (gh.configured()) gh.repo + (if (gh.workflow.isNotBlank()) " · " + gh.workflow else "") else "Not set up", { open(20) })
            GText("Pick repository, workflow, trigger, status, logs and APK download in Developer Integrations.", size = 12.sp, color = g.subtext)
        }

        GlassSettingSection("11 · Device Management") {
            val owner = DeviceMgmt.isDeviceOwner(ctx)
            Status("Device Owner (kiosk, app suspension)", owner, if (owner) "Nova is Device Owner" else "Not enrolled (optional)", { open(23) })
            val bo = DeviceMgmt.batteryOptIgnored(ctx)
            Status("Battery optimisation exemption", bo, if (bo) "Nova is exempt — background voice survives longer" else "Not exempt — Android may stop background voice", { DeviceMgmt.requestBatteryExemption(ctx); rev++ })
            val last = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getLong("last_boot_init", 0L)
            GText("Boot receiver: " + if (last > 0) "last ran ${fmt.format(Date(last))}" else "has not run yet (runs after a restart)", size = 12.sp, color = g.subtext)
            GlassButton("Apps, restrictions, kiosk, pinning", { open(23) })
        }

        GlassSettingSection("12 · Privacy & Security") {
            FeatureSwitch(ctx, Features.WATCH, "Watch Nova's own permissions and service")
            var days by remember { mutableIntStateOf(Retention.days(ctx)) }
            GlassListItem("Keep histories for", if (days == 0) "Until I clear them" else "$days days · tap to change", onClick = { val c = Retention.choices; days = c[(c.indexOf(days) + 1) % c.size]; Retention.setDays(ctx, days) })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Privacy Dashboard", { open(19) }); GlassButton("Security Activity", { open(24) })
            }
        }
    }
}

// ───────────────────────────── Assets ─────────────────────────────
private fun startDrag(view: View, ctx: Context, item: AssetItem): Boolean = try {
    view.startDragAndDrop(AssetManager.dragClip(ctx, item), View.DragShadowBuilder(view), null, View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ)
} catch (e: Exception) { false }

@Composable
fun AssetScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    var rev by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf<AssetItem?>(null) }
    var msg by remember { mutableStateOf("") }
    var exporting by remember { mutableStateOf<AssetItem?>(null) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            val n = withContext(Dispatchers.IO) { uris.count { AssetManager.importUri(ctx, it) != null } }
            msg = "Imported $n of ${uris.size} file(s)."; rev++
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val it = exporting
        if (uri != null && it != null) scope.launch { val ok = withContext(Dispatchers.IO) { AssetManager.exportTo(ctx, it, uri) }; msg = if (ok) "Exported ${it.name}." else "Export failed." }
        exporting = null
    }

    SubPage("Asset Manager", onBack) {
        val tick = rev
        val all = AssetManager.list(ctx, filter)
        GlassSettingSection("Library") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Import files", { importer.launch(arrayOf("*/*")) }, primary = true)
                GlassButton("Save clipboard as snippet", {
                    val t = (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    msg = if (t.isBlank()) "Clipboard is empty." else (AssetManager.saveSnippet(ctx, "snippet_" + SimpleDateFormat("MMdd_HHmm", Locale.US).format(Date()) + ".txt", t)?.let { "Saved ${it.name}." } ?: "Couldn't save."); rev++
                })
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GlassButton("All", { filter = null; sel = null })
                AssetManager.types.forEach { t -> GlassButton(t, { filter = t; sel = null }) }
            }
            if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.subtext)
        }

        val recent = AssetManager.recent(ctx, 4)
        if (recent.isNotEmpty() && filter == null) GlassSettingSection("Recent") {
            recent.forEach { a -> GlassListItem(a.name, a.type + " · " + AssetManager.humanSize(a.sizeBytes), onClick = { sel = a }) }
        }

        GlassSettingSection(if (filter == null) "All assets (${all.size})" else "$filter (${all.size})") {
            if (all.isEmpty()) GText("Nothing here yet. Import files, or save text from the clipboard.", size = 12.sp, color = g.subtext)
            all.take(60).forEach { a -> GlassListItem(a.name, a.type + " · " + AssetManager.humanSize(a.sizeBytes), onClick = { sel = a }) }
            if (all.size > 60) GText("Showing 60. Use a type filter to narrow.", size = 11.sp, color = g.subtext)
        }

        sel?.let { item ->
            GlassSettingSection("Selected: ${item.name}") {
                val bmp = remember(item.id) { AssetManager.previewBitmap(ctx, item) }
                if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = item.name, modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp))
                val txt = remember(item.id) { AssetManager.previewText(ctx, item) }
                if (txt != null) GText(txt.take(1200), size = 12.sp, color = g.subtext)
                if (bmp == null && txt == null) GText("${item.type} · ${AssetManager.humanSize(item.sizeBytes)} — use Open to preview in another app.", size = 12.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Open", { msg = if (AssetManager.open(ctx, item)) "" else "No app can open this type."; rev++ })
                    GlassButton("Copy", { msg = AssetManager.copy(ctx, item); rev++ })
                    GlassButton("Share", { if (!AssetManager.share(ctx, item)) msg = "Couldn't share."; rev++ })
                    GlassButton("Export…", { exporting = item; exporter.launch(item.name) })
                    GlassButton("Delete", { AssetManager.delete(ctx, item); sel = null; msg = "Deleted."; rev++ })
                }
                GlassCard(Modifier.fillMaxWidth().pointerInput(item.id) { detectTapGestures(onLongPress = { msg = if (startDrag(view, ctx, item)) "Dragging… drop it into an app that accepts files (split-screen)." else "Drag couldn't start." }) }) {
                    Column(Modifier.padding(14.dp)) {
                        GText("⠿  Hold here, then drag into another app", size = 13.sp)
                        GText("Works only where the other app accepts dropped files (usually split-screen). Otherwise use Share.", size = 11.sp, color = g.subtext)
                    }
                }
            }
        }
    }
}

// ───────────────────────────── Device management ─────────────────────────────
@Composable
fun DeviceMgmtScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val clip = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    var rev by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<String?>(null) }
    var confirmRelease by remember { mutableStateOf(false) }
    val apps = remember(rev) { DeviceMgmt.inventory(ctx) }

    SubPage("Device Management", onBack) {
        val tick = rev
        val owner = DeviceMgmt.isDeviceOwner(ctx)
        GlassSettingSection("Device Owner & kiosk") {
            GlassListItem("Device Owner", if (owner) "Nova is Device Owner" else "Not enrolled. Optional; needed only for kiosk and app suspension.", glyph = if (owner) "🟢" else "⚪")
            if (!owner) {
                GText("Enrol once from a computer (the phone must have no Google/Samsung account added):", size = 12.sp, color = g.subtext)
                GText(DeviceMgmt.adbCommand(ctx), size = 12.sp)
                GlassButton("Copy command", { clip.setPrimaryClip(ClipData.newPlainText("adb", DeviceMgmt.adbCommand(ctx))); msg = "Command copied." })
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Start kiosk", { msg = ctx.activity()?.let { DeviceMgmt.enableKiosk(it) } ?: "Open this screen from Nova's main window." }, primary = true)
                    GlassButton("Exit kiosk", { msg = ctx.activity()?.let { DeviceMgmt.exitKiosk(it) } ?: "Open this screen from Nova's main window." })
                    GlassButton("Release Device Owner…", { confirmRelease = true })
                }
                if (confirmRelease) GlassCard(Modifier.fillMaxWidth(), strong = true) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GText("Release Device Owner? Suspended apps are un-suspended and Nova becomes a normal app again.", size = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Release", { msg = DeviceMgmt.releaseOwner(ctx); confirmRelease = false; rev++ }, primary = true)
                            GlassButton("Cancel", { confirmRelease = false })
                        }
                    }
                }
            }
            GText("You can always uninstall Nova or release Device Owner. Nothing is hidden and Nova never blocks the phone app, Settings or System UI.", size = 11.sp, color = g.subtext)
        }

        GlassSettingSection("Screen pinning") {
            GText("Pinning keeps one app on screen until you hold Back + Recents. It needs Settings > Biometrics and security > Other security settings > Pin windows.", size = 12.sp, color = g.subtext)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Pin Nova", { msg = ctx.activity()?.let { DeviceMgmt.pinScreen(it) } ?: "Open this screen from Nova's main window." })
                GlassButton("Security settings", { DeviceMgmt.openSecuritySettings(ctx) })
            }
        }

        GlassSettingSection("Battery") {
            val bo = DeviceMgmt.batteryOptIgnored(ctx)
            GlassListItem("Battery optimisation", if (bo) "Nova is exempt" else "Not exempt: Android may stop background voice", glyph = if (bo) "🟢" else "⚪")
            if (!bo) GlassButton("Allow background use", { DeviceMgmt.requestBatteryExemption(ctx); rev++ })
            GText("Samsung also has Settings > Battery > Background usage limits > Never sleeping apps. Add Nova AI there.", size = 11.sp, color = g.subtext)
        }

        GlassSettingSection("Installed apps (${apps.size}) & restrictions") {
            GlassTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = "Search apps")
            val shown = apps.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }.take(40)
            val restricted = DeviceMgmt.restricted(ctx)
            shown.forEach { a ->
                GlassListItem(a.label, a.pkg + " · v" + a.version + (if (a.system) " · system" else "") + (if (a.pkg in restricted) " · RESTRICTED" else ""), onClick = { picked = if (picked == a.pkg) null else a.pkg })
                if (picked == a.pkg) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Open", { msg = if (a.pkg in restricted) "Restricted by you. Unrestrict it first." else if (DeviceMgmt.launch(ctx, a.pkg)) "" else "Couldn't open." })
                    GlassButton("App info", { DeviceMgmt.appInfo(ctx, a.pkg) })
                    GlassButton(if (a.pkg in restricted) "Unrestrict" else "Restrict", { msg = DeviceMgmt.setRestricted(ctx, a.pkg, a.pkg !in restricted); rev++ })
                    if (!a.system) GlassButton("Uninstall", { msg = DeviceMgmt.uninstall(ctx, a.pkg) })
                }
            }
            if (apps.size > shown.size) GText("Showing ${shown.size}. Search to find others.", size = 11.sp, color = g.subtext)
            GText(if (owner) "Restricting an app also suspends it (Device Owner)." else "Without Device Owner, a restriction only stops Nova's voice launcher and agent from opening the app.", size = 11.sp, color = g.subtext)
        }
        if (msg.isNotBlank()) GText(msg, size = 13.sp)
    }
}

// ───────────────────────────── Security activity ─────────────────────────────
@Composable
fun SecurityActivityScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var rev by remember { mutableIntStateOf(0) }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    var msg by remember { mutableStateOf("") }
    SubPage("Security Activity", onBack) {
        val tick = rev
        GlassSettingSection("Monitoring") {
            FeatureSwitch(ctx, Features.WATCH, "Watch Nova's own permissions and background service")
            GText("Only Nova itself is watched: permission changes, the background voice service ending unexpectedly, restarts. No other app, no screenshots, no credentials.", size = 12.sp, color = g.subtext)
            GlassButton("Check now", { val n = SecurityWatch.check(ctx); msg = if (n == 0) "No changes since the last check." else "$n change(s) found."; rev++ })
            if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Right now") {
            SecurityWatch.snapshot(ctx).forEach { (k, v) -> GlassListItem(k, if (v) "On" else "Off", glyph = if (v) "🟢" else "⚪") }
        }
        GlassSettingSection("Activity history") {
            val ev = SecurityWatch.events(ctx, 30)
            if (ev.isEmpty()) GText("Nothing recorded yet.", size = 12.sp, color = g.subtext)
            ev.forEach { e -> GlassListItem(e.text, fmt.format(Date(e.t)) + " · " + e.kind) }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                var days by remember { mutableIntStateOf(Retention.days(ctx)) }
                GlassButton(if (days == 0) "Keep: until cleared" else "Keep: $days days", { val c = Retention.choices; days = c[(c.indexOf(days) + 1) % c.size]; Retention.setDays(ctx, days) })
                GlassButton("Clear history", { SecurityWatch.clear(ctx); rev++ })
            }
        }
        GlassSettingSection("App activity (optional)") {
            val ok = SecurityWatch.usageAccess(ctx)
            GlassListItem("Usage access", if (ok) "Granted — today's most used apps below, nothing is stored" else "Not granted. Android's own permission; Nova asks only if you want this.", glyph = if (ok) "🟢" else "⚪",
                onClick = { launchSettings(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS); rev++ })
            UsageInfo.topApps(ctx, 5).forEach { (name, min) -> GlassListItem(name, "$min min today") }
        }
    }
}
