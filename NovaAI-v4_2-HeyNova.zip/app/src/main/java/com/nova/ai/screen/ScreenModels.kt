package com.nova.ai.screen

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** One visible, accessible UI element. Passwords never carry text. */
data class UiElement(
    val index: Int,
    val text: String,
    val desc: String,
    val hint: String,
    val viewId: String,
    val cls: String,
    val pkg: String,
    val bounds: Rect,
    val clickable: Boolean,
    val longClickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val checkable: Boolean,
    val checked: Boolean,
    val selected: Boolean,
    val focused: Boolean,
    val enabled: Boolean,
    val password: Boolean,
    val depth: Int,
    /** Kept only for the lifetime of one ScreenSnapshot. */
    val node: AccessibilityNodeInfo?
) {
    val label: String get() = text.ifBlank { desc }.ifBlank { hint }.ifBlank { viewId.substringAfterLast('/') }
    val cx: Int get() = bounds.centerX()
    val cy: Int get() = bounds.centerY()
    val kind: String get() = when {
        editable -> "text field"
        cls.contains("CheckBox", true) || cls.contains("Switch", true) || cls.contains("Toggle", true) -> "switch"
        cls.contains("Button", true) || (clickable && cls.contains("ImageView", true)) -> "button"
        scrollable -> "list"
        clickable -> "clickable item"
        else -> "text"
    }
    val area: Int get() = bounds.width() * bounds.height()
}

class ScreenSnapshot(val pkg: String, val width: Int, val height: Int, val elements: List<UiElement>) {
    val clickable get() = elements.filter { it.clickable && it.enabled }
    val editable get() = elements.filter { it.editable }
    val scrollable get() = elements.filter { it.scrollable }

    fun text(max: Int = 3000): String {
        val sb = StringBuilder()
        for (e in elements) {
            val l = if (e.password) "" else e.text.ifBlank { e.desc }
            if (l.isNotBlank()) sb.append(l.take(160)).append(". ")
            if (sb.length > max) break
        }
        return sb.toString().trim()
    }

    /** Compact structural description (labels and kinds only) for the user or for Gemini. */
    fun outline(max: Int = 2500): String {
        val sb = StringBuilder("App: $pkg\n")
        for (e in elements) {
            if (e.password) { sb.append("- password field\n"); continue }
            val l = e.label
            if (l.isBlank() && !e.editable && !e.scrollable) continue
            sb.append("- ").append(e.kind).append(": ").append(l.take(80)).append('\n')
            if (sb.length > max) break
        }
        return sb.toString().trim()
    }
}

/**
 * Outcome of one screen action.
 * [ok] = Android accepted the action (never set without a real result). [changed] = the screen visibly reacted
 * (null = not checked). [blocked] = refused by a safety/permission rule, so retrying is pointless.
 */
data class ActionResult(val ok: Boolean, val message: String, val changed: Boolean? = null, val blocked: Boolean = false)

/** Android-free views of a snapshot for the matching rules in [AppUi] (password fields are never included). */
fun UiElement.toCand() = Cand(
    index, text, desc, hint, viewId, cls, clickable, editable, focused, enabled,
    bounds.left, bounds.top, bounds.right, bounds.bottom
)
fun ScreenSnapshot.cands(): List<Cand> = elements.filter { !it.password }.map { it.toCand() }
fun ScreenSnapshot.byId(id: Int): UiElement? = elements.firstOrNull { it.index == id }
fun ScreenSnapshot.texts(): List<String> = elements.filter { !it.password }.flatMap { listOf(it.text, it.desc) }.filter { it.isNotBlank() }
