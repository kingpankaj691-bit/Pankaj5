package com.nova.ai.ai.net

import com.nova.ai.ai.model.GeminiModel
import com.nova.ai.ai.model.ModelListParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * The one HTTP path to the Gemini REST API. The API key goes in the x-goog-api-key header (never in the URL) and is never logged.
 * Failures are classified ([GeminiError]); transient ones are retried by [RetryPolicy]; cancelling the coroutine cancels the call.
 */
class GeminiRestClient(private val base: OkHttpClient = OkHttpClient.Builder().build()) {

    data class Timeouts(val connectMs: Long = GeminiTimeouts.CONNECT_MS, val responseMs: Long = 60_000L)

    sealed class Result {
        class Ok(val json: JSONObject, val retries: Int) : Result()
        class Fail(val error: GeminiError, val retries: Int) : Result()
    }

    sealed class ListResult {
        class Ok(val models: List<GeminiModel>) : ListResult()
        class Fail(val error: GeminiError) : ListResult()
    }

    companion object {
        const val ROOT = "https://generativelanguage.googleapis.com/v1beta"
        val shared: GeminiRestClient by lazy { GeminiRestClient() }
    }

    suspend fun generate(
        apiKey: String, modelId: String, body: JSONObject,
        timeouts: Timeouts = Timeouts(), policy: RetryPolicy = RetryPolicy.chat()
    ): Result {
        if (apiKey.isBlank()) return Result.Fail(GeminiError(GeminiErrorKind.NO_KEY, model = modelId), 0)
        val req = Request.Builder()
            .url("$ROOT/models/$modelId:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return call(req, timeouts, modelId, policy)
    }

    /** Lists every model the key can see (all pages). */
    suspend fun listModels(apiKey: String, timeouts: Timeouts = Timeouts(responseMs = 30_000L)): ListResult {
        if (apiKey.isBlank()) return ListResult.Fail(GeminiError(GeminiErrorKind.NO_KEY))
        val all = ArrayList<GeminiModel>()
        var token: String? = null
        var pages = 0
        do {
            val url = "$ROOT/models".toHttpUrl().newBuilder().addQueryParameter("pageSize", "1000")
                .apply { token?.let { addQueryParameter("pageToken", it) } }.build()
            val req = Request.Builder().url(url).header("x-goog-api-key", apiKey).get().build()
            when (val r = call(req, timeouts, null, RetryPolicy.chat())) {
                is Result.Fail -> return ListResult.Fail(r.error)
                is Result.Ok -> {
                    val page = ModelListParser.parsePage(r.json)
                    all.addAll(page.models)
                    token = page.nextPageToken
                }
            }
            pages++
        } while (token != null && pages < 20)
        return ListResult.Ok(all)
    }

    private suspend fun call(req: Request, t: Timeouts, modelId: String?, policy: RetryPolicy): Result {
        val started = System.currentTimeMillis()
        var retries = 0
        while (true) {
            when (val r = once(req, t, modelId)) {
                is Result.Ok -> return Result.Ok(r.json, retries)
                is Result.Fail -> {
                    val wait = policy.nextDelayMs(retries, r.error, System.currentTimeMillis() - started) ?: return Result.Fail(r.error, retries)
                    retries++
                    delay(wait)               // cancellable: leaving the screen or pressing Stop ends the loop at once
                }
            }
        }
    }

    private suspend fun once(req: Request, t: Timeouts, modelId: String?): Result {
        val client = base.newBuilder()
            .connectTimeout(t.connectMs, TimeUnit.MILLISECONDS)
            .readTimeout(t.responseMs, TimeUnit.MILLISECONDS)
            .writeTimeout(GeminiTimeouts.CONNECT_MS, TimeUnit.MILLISECONDS)
            .build()
        val call = client.newCall(req)
        return try {
            call.await().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    try { Result.Ok(JSONObject(text), 0) }
                    catch (e: Exception) { Result.Fail(GeminiError(GeminiErrorKind.UNKNOWN, resp.code, "unreadable response", null, modelId), 0) }
                } else {
                    Result.Fail(GeminiErrors.fromHttp(resp.code, text, resp.header("Retry-After"), modelId), 0)
                }
            }
        } catch (e: CancellationException) {
            throw e                                   // never swallow cancellation: that caused stuck "loading" states and duplicate answers
        } catch (e: IOException) {
            Result.Fail(GeminiErrors.fromException(e, modelId, call.isCanceled()), 0)
        } catch (e: Exception) {
            Result.Fail(GeminiErrors.fromException(e, modelId), 0)
        }
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { try { cancel() } catch (e: Throwable) { } }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (cont.isActive) cont.resumeWithException(e) }
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }
}
