package com.nova.ai.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import com.nova.ai.accessibility.AccessibilitySettings
import com.nova.ai.control.ShizukuManager
import com.nova.ai.files.FileAccess
import com.nova.ai.media.Saf
import com.nova.ai.security.Prefs
import com.nova.ai.voice.VoicePermissionManager

/** Reads the real state of everything the dashboard shows. Call off the main thread. */
object DashboardProbe {
    fun collect(ctx: Context, prefs: Prefs, screenCaptureActive: Boolean): DashInputs {
        val trees = prefs.storageTrees
        val valid = trees.count { try { Saf.hasGrant(ctx, Uri.parse(it)) } catch (e: Exception) { false } }
        val micPerm = listOf(Manifest.permission.RECORD_AUDIO)
        val mic = VoicePermissionManager.hasMic(ctx)
        val needsRuntimeNotif = Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        val notifPerm = listOf(Manifest.permission.POST_NOTIFICATIONS)
        return DashInputs(
            a11y = AccessibilitySettings.status(ctx, prefs),
            shizuku = ShizukuManager.refresh(),
            files = FileAccess.state(ctx, valid),
            safTotal = trees.size,
            safValid = valid,
            micGranted = mic,
            micPermanentlyDenied = !mic && PermissionMemory.isBlocked(ctx, micPerm),
            notificationsAllowed = VoicePermissionManager.notificationsAllowed(ctx),
            notificationsCanAsk = needsRuntimeNotif && !PermissionMemory.isBlocked(ctx, notifPerm),
            screenCaptureActive = screenCaptureActive,
            online = online(ctx)
        )
    }

    private fun online(ctx: Context): Boolean? = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val c = cm.getNetworkCapabilities(cm.activeNetwork)
        c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) { null }
}
