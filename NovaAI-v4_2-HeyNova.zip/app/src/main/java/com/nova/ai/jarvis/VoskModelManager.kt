package com.nova.ai.jarvis

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads and stores the small offline speech models (Vosk). Only done when the user taps Download. */
object VoskModelManager {
    class Spec(val id: String, val label: String, val url: String, val dirName: String, val sizeMb: Int)

    val specs = listOf(
        Spec("en-in", "English (India)", "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip", "vosk-model-small-en-in-0.4", 36),
        Spec("hi", "Hindi", "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip", "vosk-model-small-hi-0.22", 42)
    )

    val status = MutableStateFlow("")

    fun spec(id: String): Spec = specs.firstOrNull { it.id == id } ?: specs[0]
    fun dir(ctx: Context, id: String) = File(File(ctx.filesDir, "vosk"), spec(id).dirName)
    fun isInstalled(ctx: Context, id: String) = File(dir(ctx, id), "am").exists()

    /** Returns null on success, otherwise an error message. */
    suspend fun download(ctx: Context, id: String): String? = withContext(Dispatchers.IO) {
        val sp = spec(id)
        val root = File(ctx.filesDir, "vosk").apply { mkdirs() }
        val tmp = File(ctx.cacheDir, "${sp.dirName}.zip")
        var conn: HttpURLConnection? = null
        try {
            status.value = "Downloading ${sp.label} (about ${sp.sizeMb} MB)…"
            conn = (URL(sp.url).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true }
            if (conn.responseCode !in 200..299) return@withContext "Download failed (HTTP ${conn.responseCode})."
            val total = conn.contentLengthLong
            var done = 0L
            conn.inputStream.use { input -> tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) status.value = "Downloading ${sp.label}: ${(done * 100 / total).toInt()}%"
                }
            } }
            status.value = "Unpacking ${sp.label}…"
            val rootPath = root.canonicalPath + File.separator
            ZipInputStream(tmp.inputStream().buffered()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val f = File(root, e.name)
                    if (!f.canonicalPath.startsWith(rootPath)) continue          // never write outside the model folder
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { zin.copyTo(it) } }
                }
            }
            if (!isInstalled(ctx, id)) return@withContext "The downloaded model looks incomplete."
            status.value = "${sp.label} model installed."
            null
        } catch (e: Exception) {
            status.value = ""
            "Download failed: ${e.message}"
        } finally { conn?.disconnect(); tmp.delete() }
    }

    fun delete(ctx: Context, id: String) { dir(ctx, id).deleteRecursively(); status.value = "" }
}
