package com.nova.ai.vision

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import com.nova.ai.accessibility.NovaAccessibilityService
import kotlinx.coroutines.delay

/**
 * Optional visual understanding through Android MediaProjection. It exists only after the user approves Android's own
 * "start recording or casting" dialog, shows a persistent notification while active, keeps at most the newest frame in RAM
 * and is stopped by the notification button, by Android, or by NOVA's Stop command.
 */
object ScreenCaptureManager {
    @Volatile var active = false
        private set
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var held: Image? = null
    private var w = 0
    private var h = 0
    private var screenW = 0
    private var screenH = 0
    private val lock = Any()

    fun createConsentIntent(ctx: Context): Intent =
        (ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent()

    /** Called by ScreenCaptureService after it is already in the foreground (required on Android 14+). */
    fun begin(ctx: Context, resultCode: Int, data: Intent): Boolean {
        release()
        return try {
            val mgr = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mgr.getMediaProjection(resultCode, data) ?: return false
            val dm = ctx.resources.displayMetrics
            screenW = dm.widthPixels; screenH = dm.heightPixels
            val scale = minOf(1f, 1080f / screenW)
            w = (screenW * scale).toInt().coerceAtLeast(2); h = (screenH * scale).toInt().coerceAtLeast(2)
            val t = HandlerThread("nova-capture").also { it.start() }
            val handler = Handler(t.looper)
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { release() } }, Handler(Looper.getMainLooper()))
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
                synchronized(lock) { held?.close(); held = img }
            }, handler)
            display = p.createVirtualDisplay("nova-vision", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
            projection = p; reader = r; thread = t; active = true
            true
        } catch (e: Exception) { release(); false }
    }

    /** Converts the newest frame to a bitmap. Waits briefly for the first frame after starting. */
    suspend fun capture(): ScreenFrame? {
        if (!active) return null
        var tries = 0
        while (synchronized(lock) { held } == null && tries < 12) { delay(150); tries++ }
        synchronized(lock) {
            val img = held ?: return null
            return try {
                val plane = img.planes[0]
                val pixelStride = plane.pixelStride
                val rowPadding = plane.rowStride - pixelStride * w
                val bmp = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val out = if (bmp.width != w) Bitmap.createBitmap(bmp, 0, 0, w, h).also { bmp.recycle() } else bmp
                ScreenFrame(out, screenW, screenH, NovaAccessibilityService.activePackage())
            } catch (e: Exception) { null }
        }
    }

    fun release() {
        active = false
        synchronized(lock) { try { held?.close() } catch (e: Exception) {}; held = null }
        try { display?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        try { thread?.quitSafely() } catch (e: Exception) {}
        display = null; reader = null; projection = null; thread = null
    }
}
