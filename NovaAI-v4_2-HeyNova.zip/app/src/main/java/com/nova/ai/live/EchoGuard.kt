package com.nova.ai.live

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Keeps Nova from hearing her own voice on the loudspeaker. While audio is playing the mic is muted; after the last
 * chunk it stays muted for [tailMs] (room echo). A watchdog force-unmutes after [watchdogMs] if a stop was never reported.
 * The class takes its scope so tests can drive it with virtual time.
 */
class EchoGuardCore(
    private val scope: CoroutineScope,
    private val tailMs: Long = ECHO_TAIL_MS,
    private val watchdogMs: Long = 60_000L
) {
    companion object { const val ECHO_TAIL_MS = 450L }

    private val lock = Any()
    private var active = 0
    @Volatile private var muted = false
    private var tailJob: Job? = null
    private var watchdog: Job? = null

    fun isMicMuted(): Boolean = muted
    fun activePlaybacks(): Int = synchronized(lock) { active }

    fun notifyPlaybackStarted() = synchronized(lock) {
        active++
        muted = true
        tailJob?.cancel(); tailJob = null
        watchdog?.cancel()
        watchdog = scope.launch { delay(watchdogMs); reset() }
    }

    fun notifyPlaybackStopped() = synchronized(lock) {
        if (active > 0) active--
        if (active == 0) {
            watchdog?.cancel(); watchdog = null
            tailJob?.cancel()
            tailJob = scope.launch { delay(tailMs); synchronized(lock) { if (active == 0) muted = false } }
        }
    }

    fun reset() = synchronized(lock) {
        active = 0
        muted = false
        tailJob?.cancel(); tailJob = null
        watchdog?.cancel(); watchdog = null
    }
}

/** Process-wide instance used by the live voice engine. */
object EchoGuard {
    private val core = EchoGuardCore(CoroutineScope(SupervisorJob() + Dispatchers.Default))
    fun notifyPlaybackStarted() = core.notifyPlaybackStarted()
    fun notifyPlaybackStopped() = core.notifyPlaybackStopped()
    fun isMicMuted() = core.isMicMuted()
    fun reset() = core.reset()
}
