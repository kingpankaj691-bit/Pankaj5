package com.nova.ai.live

/** Remembers recent tool-call ids so a call that the server repeats is executed only once. Bounded; oldest ids are dropped. */
class ToolCallDeduplicator(private val capacity: Int = 64) {
    private val seen = LinkedHashSet<String>()

    /** True the first time an id is offered, false for every repeat. Blank ids are never treated as duplicates. */
    @Synchronized
    fun firstTime(id: String): Boolean {
        if (id.isBlank()) return true
        if (!seen.add(id)) return false
        while (seen.size > capacity) {
            val it = seen.iterator()
            it.next(); it.remove()
        }
        return true
    }

    @Synchronized fun clear() = seen.clear()
}
