package com.nova.ai.jarvis

/**
 * The wake phrases (English, Hindi and Hinglish) and how they are turned into something the offline Vosk models can really recognize.
 * Pure Kotlin, no Android classes, so it is unit tested on the JVM.
 *
 * A phrase has one or more *forms*: the same phrase written for a particular offline model. The English (India) model hears
 * "hey nova"; the Hindi model returns Devanagari ("जान कैसी हो"). At start-up [plan] checks every word of every form against the
 * model's real vocabulary (graph/words.txt), keeps only forms the model can produce, and loads only the models that are needed.
 * A phrase none of whose forms the models know is reported as unavailable instead of being silently weakened
 * (Vosk drops out-of-vocabulary grammar words, which would make "hi jaan" fire on a bare "hi").
 */
object WakePhrases {
    const val EN = "en-in"
    const val HI = "hi"

    class Form(val model: String, val text: String)

    /**
     * @param reply  null: only open the conversation. "": acknowledge ("Yes?" / "Haan, boliye?"). Text: said to Nova as the command,
     *               because the phrase itself is the question ("kaisi ho?"); the live session starts after Nova has answered.
     * @param hindi  Hindi / Hinglish phrase: Nova answers in that language style.
     */
    class Phrase(val id: String, val label: String, val forms: List<Form>, val reply: String? = null, val hindi: Boolean = false, val custom: Boolean = false, val on: Boolean = true)

    /** Built-in phrases that are on by default. "nova_listen" and "nova_there" are extra and off by default. */
    val DEFAULT_IDS = listOf(
        "hey_nova", "hello_nova", "hi_nova", "hi_jaan", "hey_jaan", "hello_jaan",
        "jaan_how", "jaan_kaisi", "jaan_kya", "hello_jaan_suno", "nova_suno", "jaan_listen"
    )
    private val ALIASES = mapOf("hey" to "hey_nova", "hello" to "hello_nova", "hi" to "hi_nova", "listen" to "nova_listen", "there" to "nova_there")
    const val NONE = "-"

    /** Lower case letters, digits and single spaces only (same rule JarvisPrefs.wakeName applies). Blank becomes "nova". */
    fun cleanName(raw: String): String =
        raw.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim().replace(Regex("\\s+"), " ").ifBlank { "nova" }

    private fun en(t: String) = Form(EN, t)
    private fun hi(t: String) = Form(HI, t)

    fun builtins(name: String): List<Phrase> {
        val n = cleanName(name)
        val N = n.split(' ').joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        val nova = n == "nova"
        fun hiNova(vararg t: String) = if (nova) t.map { hi(it) } else emptyList()
        return listOf(
            Phrase("hey_nova", "Hey $N", listOf(en("hey $n")) + hiNova("हे नोवा")),
            Phrase("hello_nova", "Hello $N", listOf(en("hello $n")) + hiNova("हेलो नोवा", "हैलो नोवा")),
            Phrase("hi_nova", "Hi $N", listOf(en("hi $n")) + hiNova("हाय नोवा")),
            Phrase("hi_jaan", "Hi Jaan", listOf(en("hi jaan"), hi("हाय जान"), hi("हाई जान"))),
            Phrase("hey_jaan", "Hey Jaan", listOf(en("hey jaan"), hi("हे जान"), hi("हेय जान"))),
            Phrase("hello_jaan", "Hello Jaan", listOf(en("hello jaan"), hi("हेलो जान"), hi("हैलो जान"), hi("हलो जान"))),
            Phrase("jaan_how", "Jaan, how are you?", listOf(en("jaan how are you"), hi("जान हाउ आर यू")), reply = "how are you?"),
            Phrase("jaan_kaisi", "Jaan, kaisi ho?", listOf(hi("जान कैसी हो"), en("jaan kaisi ho")), reply = "kaisi ho?", hindi = true),
            Phrase("jaan_kya", "Jaan, kya kar rahi ho?", listOf(hi("जान क्या कर रही हो"), en("jaan kya kar rahi ho")), reply = "kya kar rahi ho?", hindi = true),
            Phrase("hello_jaan_suno", "Hello Jaan, suno", listOf(hi("हेलो जान सुनो"), hi("हैलो जान सुनो"), hi("हलो जान सुनो"), en("hello jaan suno")), reply = "", hindi = true),
            Phrase("nova_suno", "$N, meri baat suno", listOf(en("$n meri baat suno")) + hiNova("नोवा मेरी बात सुनो", "नॉवा मेरी बात सुनो"), reply = "", hindi = true),
            Phrase("jaan_listen", "Jaan, listen", listOf(en("jaan listen"), hi("जान लिसन"), hi("जान सुनो"))),
            Phrase("nova_listen", "$N, listen", listOf(en("$n listen"))),
            Phrase("nova_there", "$N, are you there?", listOf(en("$n are you there")), reply = "")
        )
    }

    // ───────── custom phrases ─────────

    private fun hasIndic(s: String) = s.any { it in '\u0900'..'\u097F' }

    /** One saved custom phrase. Stored one per line as "1|text" (on) or "0|text" (off); a plain line (older versions) means on. */
    class Custom(val text: String, val on: Boolean)

    fun parseEntries(raw: String): List<Custom> {
        val seen = HashSet<String>()
        val out = ArrayList<Custom>()
        for (line in raw.lines()) {
            val l = line.trim()
            if (l.isEmpty()) continue
            val flagged = l.length > 1 && l[1] == '|' && (l[0] == '0' || l[0] == '1')
            val t = norm(if (flagged) l.substring(2) else l)
            if (t.isNotBlank() && seen.add(t)) out.add(Custom(t, !flagged || l[0] == '1'))
        }
        return out.take(MAX_CUSTOM)
    }

    fun serialize(list: List<Custom>): String = list.joinToString("\n") { (if (it.on) "1|" else "0|") + it.text }

    fun parseCustom(raw: String): List<String> = parseEntries(raw).map { it.text }
    fun addCustom(raw: String, text: String): String = serialize((parseEntries(raw) + Custom(norm(text), true)).distinctBy { it.text }.take(MAX_CUSTOM))
    fun removeCustom(raw: String, id: String): String = serialize(parseEntries(raw).filter { "c:${it.text}" != id })
    fun setCustomEnabled(raw: String, id: String, on: Boolean): String = serialize(parseEntries(raw).map { if ("c:${it.text}" == id) Custom(it.text, on) else it })
    /** Replaces the text of one custom phrase, keeping its place and on/off state. */
    fun editCustom(raw: String, id: String, newText: String): String =
        serialize(parseEntries(raw).map { if ("c:${it.text}" == id) Custom(norm(newText), it.on) else it }.distinctBy { it.text })

    const val MAX_CUSTOM = 16

    /** Words so common in everyday speech that a phrase made only of them would fire constantly. */
    private val COMMON = setOf(
        "hi", "hello", "hey", "ok", "okay", "the", "a", "an", "is", "are", "you", "your", "how", "what", "who", "why", "where", "when", "yes", "no",
        "me", "my", "i", "we", "it", "this", "that", "and", "to", "of", "in", "on", "please", "listen", "hear", "can", "do", "did", "good",
        "morning", "night", "bye", "thanks", "thank", "there", "here", "so", "now", "kya", "hai", "ho", "hu", "main", "mera", "meri", "mere",
        "tum", "aap", "suno", "sun", "haan", "nahi", "na", "ji", "ek", "kaise", "kaisi", "kaisa", "kar", "rahi", "raha", "to", "toh", "bhi", "ye", "yeh", "wo", "woh"
    )

    /** Null when the phrase is acceptable, otherwise why not. Guards against phrases that would wake Nova during ordinary talk. */
    fun validateCustom(text: String): String? {
        val t = norm(text)
        val w = t.split(' ').filter { it.isNotEmpty() }
        return when {
            w.size < 2 -> "Use at least two words (for example \"hey buddy\"). A single common word would activate Nova by accident."
            w.size > 6 -> "Use at most six words."
            t.replace(" ", "").length < 6 -> "Too short: such a short phrase would be heard in ordinary speech. Use a longer one."
            w.all { it in COMMON } -> "Too common: every word is an everyday word, so Nova would wake up in normal conversation. Include a distinctive name (like \"hey buddy\" or \"jaan suno\")."
            else -> null
        }
    }

    /** The existing phrase that says the same thing (any spelling Nova already listens for), or null. [exceptId] skips the phrase being edited. */
    fun duplicateOf(catalog: List<Phrase>, text: String, exceptId: String? = null): Phrase? {
        val t = norm(text)
        return catalog.firstOrNull { p -> p.id != exceptId && (norm(p.label) == t || p.forms.any { norm(it.text) == t }) }
    }

    /** Full check for adding or editing: wording rules, then duplicates. */
    fun checkCustom(catalog: List<Phrase>, text: String, exceptId: String? = null): String? {
        validateCustom(text)?.let { return it }
        val d = duplicateOf(catalog, text, exceptId) ?: return null
        return "Already in your list as \"${d.label}\"."
    }

    /**
     * Hindi-model spellings to try for a phrase typed in Roman letters (Hinglish), e.g. "meri jaan" -> "मेरी जान", produced by
     * [translit]. They are only used if the Hindi model's vocabulary contains every word.
     */
    fun customPhrase(text: String, translit: ((String) -> List<String>)? = null, on: Boolean = true): Phrase {
        val t = norm(text)
        val label = t.split(' ').joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        val forms = if (hasIndic(t)) listOf(hi(t)) else listOf(en(t)) + (translit?.invoke(t) ?: emptyList()).map { norm(it) }.filter { it.isNotBlank() && hasIndic(it) }.distinct().map { hi(it) }
        return Phrase("c:$t", label, forms, custom = true, hindi = hasIndic(t), on = on)
    }

    fun catalog(name: String, customRaw: String, translit: ((String) -> List<String>)? = null): List<Phrase> =
        builtins(name) + parseEntries(customRaw).map { customPhrase(it.text, translit, it.on) }

    // ───────── which phrases are on ─────────

    /** "hey_nova,hi_jaan" -> ids. Old ids (hey, hello...) are mapped; "-" means none; blank or unreadable means the defaults. */
    fun parseIds(csv: String): List<String> {
        if (csv.trim() == NONE) return emptyList()
        val all = builtins("nova").map { it.id }
        val ok = csv.split(',').map { it.trim() }.map { ALIASES[it] ?: it }.filter { it in all }.distinct()
        return ok.ifEmpty { DEFAULT_IDS }
    }

    fun joinIds(ids: Collection<String>): String = ids.distinct().joinToString(",").ifEmpty { NONE }

    /**
     * The phrases Nova listens for: ticked built-in phrases, custom phrases that are switched on, and always the default phrase
     * ([defaultId], "hey_nova" unless you chose another) so Nova can never be left with nothing to listen for.
     */
    fun enabled(catalog: List<Phrase>, ids: Collection<String>, defaultId: String = ""): List<Phrase> {
        val def = if (catalog.any { it.id == defaultId }) defaultId else "hey_nova"
        return catalog.filter { it.id == def || (if (it.custom) it.on else it.id in ids) }
    }

    // ───────── normalising and matching ─────────

    /** Lower case; letters, digits and combining marks (Devanagari vowel signs) only; single spaces. */
    fun norm(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}\\p{M}]+"), " ").trim()

    /** JSON array for Vosk's grammar parameter. Always ends with "[unk]" so other speech maps to "unknown", not to a wake phrase. */
    fun grammarJson(phrases: List<String>): String =
        (phrases.map { it.replace("\\", "\\\\").replace("\"", "\\\"") } + "[unk]").joinToString(",", "[", "]") { "\"$it\"" }

    /** Which phrase (if any) the recognizer text contains as whole words. Null when none matched. */
    fun match(heard: String, phrases: List<String>): String? {
        val h = " " + norm(heard) + " "
        return phrases.firstOrNull { p -> h.contains(" " + norm(p) + " ") }
    }

    /**
     * Removes the wake phrase from a transcript so the command is only what came after it
     * ("hey nova open youtube" -> "open youtube", "nova are you there" -> ""). Text without a phrase is returned unchanged.
     */
    fun strip(text: String, phrases: List<String>): String {
        var t = text.trim()
        for (p in phrases.sortedByDescending { it.length }) {
            if (p.isBlank()) continue
            val m = Regex("(?<![\\p{L}\\p{N}])" + p.trim().split(Regex("\\s+")).joinToString("[\\s,.!?:;-]+") { Regex.escape(it) } + "(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE).find(t) ?: continue
            t = (t.substring(0, m.range.first) + " " + t.substring(m.range.last + 1)).trim().trim(' ', ',', '.', '!', '?', ':', ';', '-')
            break
        }
        return t
    }

    // ───────── the recognition plan ─────────

    /** One offline model and the (normalized form, phrase id) pairs it must recognize. */
    class ModelPlan(val model: String, val forms: List<Pair<String, String>>) {
        val grammar: String get() = grammarJson(forms.map { it.first }.distinct())
        /** The phrase id the recognizer text contains (longest form first), or null. */
        fun identify(heard: String): String? {
            val h = " " + norm(heard) + " "
            return forms.sortedByDescending { it.first.length }.firstOrNull { h.contains(" " + it.first + " ") }?.second
        }
    }

    class Plan(val models: List<ModelPlan>, val unavailable: Map<String, String>) {
        fun modelFor(id: String): String? = models.firstOrNull { m -> m.forms.any { it.second == id } }?.model
        val isEmpty: Boolean get() = models.isEmpty()
    }

    fun modelLabel(model: String) = if (model == HI) "Hindi" else "English"

    /**
     * @param vocab model id -> its word list. A model id that is missing from the map is not installed; a null list means the
     *              vocabulary could not be read (the forms are then assumed valid, unverified).
     */
    fun plan(enabled: List<Phrase>, vocab: Map<String, Set<String>?>): Plan {
        val perModel = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        val bad = LinkedHashMap<String, String>()
        for (p in enabled) {
            var chosen: String? = null
            val missing = LinkedHashSet<String>()
            var needModel: String? = null
            val valid = ArrayList<Pair<String, String>>()
            for (f in p.forms) {
                if (!vocab.containsKey(f.model)) { if (needModel == null) needModel = f.model; continue }
                val words = vocab[f.model]
                val t = norm(f.text)
                val oov = if (words == null) emptyList() else t.split(' ').filter { it !in words }
                if (oov.isNotEmpty()) { missing.addAll(oov); continue }
                if (chosen == null) chosen = f.model
                if (f.model == chosen) valid.add(t to p.id)
            }
            if (chosen != null) perModel.getOrPut(chosen) { ArrayList() }.addAll(valid)
            else bad[p.id] =
                if (missing.isNotEmpty()) "the offline model does not know ${missing.joinToString(", ") { "\"$it\"" }}"
                else "needs the ${modelLabel(needModel ?: EN)} model (download it below)"
        }
        return Plan(perModel.map { ModelPlan(it.key, it.value) }, bad)
    }

    /**
     * Average word confidence of a Vosk result (needs Recognizer.setWords(true)); "[unk]" words are ignored.
     * True when the result carries no word details, so it never blocks a result that has nothing to judge.
     */
    fun confident(resultJson: String, min: Float): Boolean {
        val confs = Regex("\\{[^{}]*}").findAll(resultJson).mapNotNull { o ->
            val s = o.value
            val word = Regex("\"word\"\\s*:\\s*\"([^\"]*)\"").find(s)?.groupValues?.get(1)
            val c = Regex("\"conf\"\\s*:\\s*([0-9.eE+-]+)").find(s)?.groupValues?.get(1)?.toFloatOrNull()
            if (word == null || word == "[unk]" || c == null) null else c
        }.toList()
        return confs.isEmpty() || confs.average() >= min
    }
}

/**
 * How long a conversation stays open after the wake phrase. It stays open while Nova is busy (thinking or speaking) or you are
 * talking, and closes [followUpMs] after the last activity, so follow-up sentences need no wake phrase. Pure logic, unit tested.
 */
class ConversationWindow(private val initialMs: Long = 10_000L, private val followUpMs: Long = 8_000L) {
    @Volatile var openUntil = 0L
        private set

    fun open(now: Long) { openUntil = maxOf(openUntil, now + initialMs) }
    fun isOpen(now: Long) = now < openUntil
    /** Call on every audio chunk. [active] = Nova is busy or the user is speaking. */
    fun touch(now: Long, active: Boolean) { if (active) openUntil = maxOf(openUntil, now + followUpMs) }
    fun close() { openUntil = 0L }
}
