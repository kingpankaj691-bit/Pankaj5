package com.nova.ai.suite

import android.content.Context
import com.nova.ai.developer.DiagnosticsManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class LogFinding(val kind: String, val file: String, val line: Int, val message: String)

/**
 * Finds Kotlin/Gradle/Android errors in build output or logs you paste, share or capture from Nova's own process. Android only
 * lets an app read its own logcat without special permission, and Nova never asks for READ_LOGS. Secrets are removed before any
 * text is shown, stored or sent to the selected Gemini model.
 */
object LogAnalyzer {
    private val kotlinErr = Regex("""^e:\s+(?:file://)?(\S+?\.kt):?\s*\(?(\d+)[:,]\s*(\d+)\)?:?\s*(.+)$""", RegexOption.MULTILINE)
    private val kotlinWarn = Regex("""^w:\s+(?:file://)?(\S+?\.kt):?\s*\(?(\d+)[:,]\s*(\d+)\)?:?\s*(.+)$""", RegexOption.MULTILINE)
    private val gradleTask = Regex("""Execution failed for task '([^']+)'""")
    private val wentWrong = Regex("""\* What went wrong:\s*\n(.+)""")
    private val exception = Regex("""^(?:Caused by: )?([a-zA-Z0-9_.]+(?:Exception|Error)):?\s*(.*)$""", RegexOption.MULTILINE)
    private val atFrame = Regex("""^\s+at\s+(com\.nova\.[^\s(]+)\(([^:)]+):(\d+)\)""", RegexOption.MULTILINE)

    private val ghToken = Regex("""(gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})""")
    fun clean(raw: String): String = ghToken.replace(DiagnosticsManager.sanitize(raw), "[github-token]")

    fun analyze(raw: String): List<LogFinding> {
        val text = clean(raw)
        val out = ArrayList<LogFinding>()
        kotlinErr.findAll(text).forEach { out.add(LogFinding("kotlin-error", File(it.groupValues[1]).name, it.groupValues[2].toInt(), it.groupValues[4].trim())) }
        kotlinWarn.findAll(text).take(5).forEach { out.add(LogFinding("kotlin-warning", File(it.groupValues[1]).name, it.groupValues[2].toInt(), it.groupValues[4].trim())) }
        gradleTask.find(text)?.let { m ->
            val why = wentWrong.find(text)?.groupValues?.get(1)?.trim().orEmpty()
            out.add(LogFinding("gradle-failure", m.groupValues[1], 0, why.ifBlank { "Task failed" }))
        }
        exception.findAll(text).take(6).forEach { m ->
            val frame = atFrame.find(text.substring(m.range.last.coerceAtMost(text.length - 1)))
            out.add(LogFinding("exception", frame?.groupValues?.get(2).orEmpty(), frame?.groupValues?.get(3)?.toIntOrNull() ?: 0, m.groupValues[1].substringAfterLast('.') + ": " + m.groupValues[2].trim()))
        }
        return out.distinctBy { Triple(it.kind, it.file, it.message) }
    }

    fun summary(findings: List<LogFinding>): String {
        if (findings.isEmpty()) return "I couldn't find a Kotlin, Gradle or crash error in that text."
        val errs = findings.filter { it.kind != "kotlin-warning" }
        val head = "Found ${errs.size} problem(s)" + if (findings.size > errs.size) " and ${findings.size - errs.size} warning(s)." else "."
        return head + "\n" + errs.take(6).joinToString("\n") { f ->
            "• " + (if (f.file.isNotBlank()) "${f.file}${if (f.line > 0) ":${f.line}" else ""} — " else "") + f.message.take(160)
        }
    }

    /** Own-process logcat only (Android limits apps to this). Returns an empty string if logcat isn't available. */
    fun ownLogcat(lines: Int = 300): String = try {
        val p = ProcessBuilder("logcat", "-d", "-t", lines.coerceIn(20, 1000).toString(), "-v", "time").redirectErrorStream(true).start()
        val t = p.inputStream.bufferedReader().use { it.readText() }
        p.destroy(); t.takeLast(40000)
    } catch (e: Exception) { "" }

    // ── error history (private app storage, newest first, 50 max) ──
    private fun file(ctx: Context) = File(ctx.filesDir, "error_history.json")
    fun history(ctx: Context): List<Pair<Long, String>> = try {
        val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getLong("t") to o.getString("s") } }
    } catch (e: Exception) { emptyList() }
    fun remember(ctx: Context, summary: String) {
        try {
            val cur = history(ctx).toMutableList(); cur.add(0, System.currentTimeMillis() to summary.take(500))
            val a = JSONArray(); cur.take(50).forEach { a.put(JSONObject().put("t", it.first).put("s", it.second)) }
            file(ctx).writeText(a.toString())
        } catch (e: Exception) { }
    }
    fun clearHistory(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }
}
