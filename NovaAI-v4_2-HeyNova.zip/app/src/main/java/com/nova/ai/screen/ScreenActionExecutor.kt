package com.nova.ai.screen

import android.graphics.Path
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.accessibility.TapMethod
import com.nova.ai.accessibility.TextVerify
import com.nova.ai.security.Prefs
import kotlinx.coroutines.delay

enum class Dir { UP, DOWN, LEFT, RIGHT }

/**
 * The only class that performs screen actions. Every public function validates first, uses official Accessibility APIs
 * and reports honestly: [ActionResult.ok] means Android accepted the action, [ActionResult.changed] says whether the
 * screen really reacted, and typing is read back from the field before it is called "typed".
 */
class ScreenActionExecutor(private val prefs: Prefs) {
    private val svc get() = NovaAccessibilityService.instance

    fun available() = svc != null && prefs.screenActionsOn
    fun snapshot(): ScreenSnapshot? = try { svc?.snapshot() } catch (e: Exception) { null }
    /** The app really in front (live window), not just the last window event. */
    fun foreground(): String = NovaAccessibilityService.activePackage()
    fun uiVersion(): Long = NovaAccessibilityService.contentVersion.get()
    /** What a text field really shows right now (null = unreadable, gone, or a password field). */
    fun readField(e: UiElement): String? = svc?.freshText(e)

    private fun denied(v: Verdict): ActionResult? = when (v) {
        is Verdict.Denied -> ActionResult(false, v.reason, blocked = true)
        else -> null
    }
    private fun off() = ActionResult(false, "Screen control is off.", blocked = true)

    /** True when the screen reported any change after [sinceVersion], false on timeout. */
    suspend fun waitForUiChange(sinceVersion: Long, timeoutMs: Long = 1500): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            if (uiVersion() != sinceVersion) return true
            delay(100); waited += 100
        }
        return uiVersion() != sinceVersion
    }

    // ───────── taps ─────────
    suspend fun tapElement(e: UiElement, verify: Boolean = true): ActionResult {
        denied(ActionValidator.forElement(prefs, e))?.let { return it }
        return tapChecked(e, verify)
    }

    /** Tap a piece of content (search result / video / chat row): the title is not treated as an instruction. */
    suspend fun tapContent(e: UiElement, verify: Boolean = true): ActionResult {
        denied(ActionValidator.forContent(prefs, e))?.let { return it }
        return tapChecked(e, verify)
    }

    private suspend fun tapChecked(e: UiElement, verify: Boolean): ActionResult {
        val s = svc ?: return off()
        val before = uiVersion()
        val label = e.label.take(40)
        return when (s.tapElementDetailed(e)) {
            TapMethod.STALE -> ActionResult(false, "The screen changed before I could tap \"$label\". I need to look at it again.")
            TapMethod.NONE -> ActionResult(false, "Android didn't accept the tap on \"$label\". This app may not allow accessibility taps there.")
            TapMethod.NODE, TapMethod.GESTURE -> {
                val changed = if (verify) waitForUiChange(before) else null
                ActionResult(true, "Tapped $label.", changed = changed)
            }
        }
    }

    suspend fun longPressElement(e: UiElement): ActionResult {
        denied(ActionValidator.forElement(prefs, e))?.let { return it }
        val s = svc ?: return off()
        val before = uiVersion()
        val ok = s.longClickElement(e)
        if (!ok) return ActionResult(false, "That long press didn't go through.")
        return ActionResult(true, "Long-pressed ${e.label.take(40)}.", changed = waitForUiChange(before))
    }

    suspend fun doubleTapElement(e: UiElement): ActionResult {
        denied(ActionValidator.forElement(prefs, e))?.let { return it }
        return doubleTapAt(e.cx, e.cy)
    }

    suspend fun tapAt(x: Int, y: Int): ActionResult {
        denied(ActionValidator.forGesture(prefs))?.let { return it }
        val s = svc ?: return off()
        val before = uiVersion()
        return if (s.gesture(listOf(Triple(s.tapPath(x.toFloat(), y.toFloat()), 0L, 60L)))) ActionResult(true, "Tapped.", changed = waitForUiChange(before))
        else ActionResult(false, "The app or Android blocked that tap.")
    }

    suspend fun doubleTapAt(x: Int, y: Int): ActionResult {
        denied(ActionValidator.forGesture(prefs))?.let { return it }
        val s = svc ?: return off()
        val ok = s.gesture(listOf(Triple(s.tapPath(x.toFloat(), y.toFloat()), 0L, 50L), Triple(s.tapPath(x.toFloat(), y.toFloat()), 140L, 50L)))
        return if (ok) ActionResult(true, "Double-tapped.") else ActionResult(false, "The double tap didn't go through.")
    }

    suspend fun longPressAt(x: Int, y: Int): ActionResult {
        denied(ActionValidator.forGesture(prefs))?.let { return it }
        val s = svc ?: return off()
        return if (s.gesture(listOf(Triple(s.tapPath(x.toFloat(), y.toFloat()), 0L, 900L)))) ActionResult(true, "Long-pressed.") else ActionResult(false, "The long press didn't go through.")
    }

    /** Swipe the way a finger would move: Dir.UP means finger moves up (content scrolls down). */
    suspend fun swipe(dir: Dir, fraction: Float = 0.5f, durationMs: Long = 320): ActionResult {
        denied(ActionValidator.forGesture(prefs))?.let { return it }
        val s = svc ?: return off()
        val (w, h) = s.screenSize()
        val cx = w / 2f; val cy = h / 2f
        val dx = w * fraction / 2f; val dy = h * fraction / 2f
        val p = Path()
        when (dir) {
            Dir.UP -> { p.moveTo(cx, cy + dy); p.lineTo(cx, cy - dy) }
            Dir.DOWN -> { p.moveTo(cx, cy - dy); p.lineTo(cx, cy + dy) }
            Dir.LEFT -> { p.moveTo(cx + dx, cy); p.lineTo(cx - dx, cy) }
            Dir.RIGHT -> { p.moveTo(cx - dx, cy); p.lineTo(cx + dx, cy) }
        }
        val before = uiVersion()
        return if (s.gesture(listOf(Triple(p, 0L, durationMs)))) ActionResult(true, "Swiped.", changed = waitForUiChange(before, 800))
        else ActionResult(false, "The swipe was blocked by the app or Android.")
    }

    suspend fun drag(x1: Int, y1: Int, x2: Int, y2: Int): ActionResult {
        denied(ActionValidator.forGesture(prefs))?.let { return it }
        val s = svc ?: return off()
        val p = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        return if (s.gesture(listOf(Triple(p, 0L, 800L)))) ActionResult(true, "Dragged.") else ActionResult(false, "The drag was blocked by the app or Android.")
    }

    fun scroll(forward: Boolean): ActionResult {
        denied(ActionValidator.base(prefs))?.let { return it }
        val s = svc ?: return off()
        return if (s.scroll(forward)) ActionResult(true, if (forward) "Scrolling down." else "Scrolling up.")
        else ActionResult(false, "I couldn't find anything scrollable here.")
    }

    /** Scroll with the accessibility action first, then a real swipe if the app doesn't expose scroll actions. */
    suspend fun scrollSmart(down: Boolean): ActionResult {
        val before = uiVersion()
        val a = scroll(down)
        if (a.blocked) return a
        if (a.ok) return a.copy(changed = waitForUiChange(before, 800))
        return swipe(if (down) Dir.UP else Dir.DOWN)
    }

    fun back(): ActionResult { denied(ActionValidator.base(prefs))?.let { return it }; return if (svc?.back() == true) ActionResult(true, "Going back.") else ActionResult(false, "Back didn't work.") }
    fun home(): ActionResult { denied(ActionValidator.base(prefs))?.let { return it }; return if (svc?.home() == true) ActionResult(true, "Going home.") else ActionResult(false, "Home didn't work.") }
    fun recents(): ActionResult { denied(ActionValidator.base(prefs))?.let { return it }; return if (svc?.recents() == true) ActionResult(true, "Opening recent apps.") else ActionResult(false, "Recent apps didn't open.") }
    fun notifications(): ActionResult { denied(ActionValidator.base(prefs))?.let { return it }; return if (svc?.notifications() == true) ActionResult(true, "Opening the notification shade.") else ActionResult(false, "I couldn't open it.") }

    // ───────── typing ─────────
    /**
     * Type into a specific field (preferred) or the focused one, then READ THE FIELD BACK. "Typed it" is only
     * reported when the field really shows the text. Never into password / PIN / OTP fields.
     */
    suspend fun typeText(text: String, field: UiElement? = null): ActionResult {
        denied(ActionValidator.forTyping(prefs, field, text))?.let { return it }
        val s = svc ?: return off()
        var shown: String? = null
        if (field != null) {
            s.focusElement(field)
            if (s.setTextOn(field, text)) {
                delay(200)
                shown = s.freshText(field) ?: s.focusedFieldText()
                if (TextVerify.matches(text, shown)) return ActionResult(true, "Typed it.", changed = true)
            }
            // The field may have been re-created by the app (new node): retry on whatever now has input focus.
            delay(200)
        }
        if (s.typeText(text)) {
            delay(200)
            shown = s.focusedFieldText()
            if (TextVerify.matches(text, shown)) return ActionResult(true, "Typed it.", changed = true)
        }
        return when {
            shown != null -> ActionResult(false, "I sent the text but the field shows \"${shown.take(40)}\" instead, so I won't call it typed.")
            field == null -> ActionResult(false, "No text field has focus. Tap a text field first, then ask again.")
            else -> ActionResult(false, "Android didn't accept text in that field.")
        }
    }

    /**
     * Presses the keyboard's Search/Enter on the focused field (Android 11+), otherwise the on-screen Search button.
     * Reports success only when the screen actually changed afterwards.
     */
    suspend fun submit(): ActionResult {
        denied(ActionValidator.base(prefs))?.let { return it }
        val s = svc ?: return off()
        delay(250)   // let the typing events settle so they aren't mistaken for the result
        val before = uiVersion()
        if (s.imeEnter() && waitForUiChange(before, 2500)) return ActionResult(true, "Submitted.", changed = true)
        val snap = snapshot()
        val btn = snap?.let { sn -> ScreenSearch.find(sn, "search", Kind.BUTTON).firstOrNull { !it.el.editable }?.el }
        if (btn != null) {
            val r = tapElement(btn)
            if (r.ok && r.changed == true) return r.copy(message = "Pressed the Search button.")
            if (r.ok) return ActionResult(false, "I pressed the Search button but the screen didn't change.")
            return r
        }
        return ActionResult(false, "I couldn't press Search: the keyboard's Enter wasn't accepted and there is no Search button on screen.")
    }

    // ───────── waiting ─────────
    /** Wait until the app in front matches [hint] (loose: name contained in the package), or the timeout passes. */
    suspend fun waitForApp(hint: String, timeoutMs: Long = 6000): Boolean {
        val h = hint.lowercase().filter { it.isLetterOrDigit() }
        val exact = AppNameMatcher.exactPackageFor(hint)
        var waited = 0L
        while (waited < timeoutMs) {
            val p = foreground().lowercase()
            if (h.isEmpty() || (exact != null && p == exact) || (exact == null && p.contains(h))) return true
            delay(250); waited += 250
        }
        return false
    }

    /** Wait until one of the exact [packages] is the app in front. */
    suspend fun waitForPackage(packages: Collection<String>, timeoutMs: Long = 6000): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            if (foreground() in packages) return true
            delay(250); waited += 250
        }
        return foreground() in packages
    }

    /** Poll for a snapshot where [cond] holds. */
    suspend fun waitFor(timeoutMs: Long = 4000, cond: (ScreenSnapshot) -> Boolean): ScreenSnapshot? {
        var waited = 0L
        while (waited <= timeoutMs) {
            val s = snapshot()
            if (s != null && cond(s)) return s
            delay(300); waited += 300
        }
        return null
    }
}
