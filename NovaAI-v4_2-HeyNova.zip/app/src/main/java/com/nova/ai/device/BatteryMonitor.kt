package com.nova.ai.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

data class BatterySnapshot(val percent: Int, val charging: Boolean, val full: Boolean, val tempC: Float?)

/** Reads the sticky battery broadcast. No polling loop: it is only read when a broadcast or a scheduled check asks for it. */
class BatteryMonitor(private val ctx: Context) {
    fun snapshot(): BatterySnapshot? {
        val i: Intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return null
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = level * 100 / scale
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val full = st == BatteryManager.BATTERY_STATUS_FULL || (charging && pct >= 100)
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return BatterySnapshot(pct, charging, full, if (t == Int.MIN_VALUE) null else t / 10f)
    }

    fun describe(): String {
        val s = snapshot() ?: return "I can't read the battery right now."
        return "Battery is at ${s.percent}%" + when {
            s.full -> " and fully charged."
            s.charging -> " and charging."
            else -> "."
        }
    }
}
