package com.nova.ai.suite

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nova.ai.automation.Notifier
import com.nova.ai.voice.VoiceState
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

data class SecEvent(val t: Long, val kind: String, val text: String)

/**
 * Transparent security monitoring of NOVA ITSELF: which permissions/access it has, whether its background voice service died
 * unexpectedly, and a visible activity history. It never watches other people, never records screens or credentials, and you can
 * switch it off (Control Center > Privacy & Security). Checks run when Nova starts, after boot and in the 12-hour maintenance job.
 */
object SecurityWatch {
    private const val FILE = "security_activity.json"
    private const val MAX = 100

    fun enabled(ctx: Context) = Features.enabled(ctx, Features.WATCH)
    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    fun events(ctx: Context, n: Int = 30): List<SecEvent> = try {
        val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText() ?: "[]")
        (0 until minOf(a.length(), n)).map { a.getJSONObject(it).let { o -> SecEvent(o.getLong("t"), o.getString("k"), o.getString("x")) } }
    } catch (e: Exception) { emptyList() }

    fun log(ctx: Context, kind: String, text: String) {
        if (!enabled(ctx)) return
        try {
            val cur = events(ctx, MAX).toMutableList(); cur.add(0, SecEvent(System.currentTimeMillis(), kind, text))
            val a = JSONArray(); cur.take(MAX).forEach { a.put(JSONObject().put("t", it.t).put("k", it.kind).put("x", it.text)) }
            file(ctx).writeText(a.toString())
        } catch (e: Exception) { }
    }

    fun clear(ctx: Context) { try { file(ctx).delete() } catch (e: Exception) { } }

    /** Current state of everything Nova can be given. Pure reads, no side effects. */
    fun snapshot(ctx: Context): LinkedHashMap<String, Boolean> {
        val m = LinkedHashMap<String, Boolean>()
        m["Microphone"] = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val enabledA11y = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        m["Accessibility"] = enabledA11y.contains(ctx.packageName + "/")
        m["Notification access"] = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        m["Display over other apps"] = Settings.canDrawOverlays(ctx)
        m["Do Not Disturb access"] = SystemControls.dndAccessGranted(ctx)
        m["Usage access"] = usageAccess(ctx)
        m["Device Owner"] = DeviceMgmt.isDeviceOwner(ctx)
        return m
    }

    fun usageAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    // Voice service life cycle: a clean stop clears the flag, a kill (swipe, memory, battery manager) does not.
    fun serviceStarted(ctx: Context) { Features.putBool(ctx, "sw_voice_running", true) }
    fun serviceStopped(ctx: Context) { Features.putBool(ctx, "sw_voice_running", false) }

    /** Compares with the last check, logs changes and alerts about permissions that were switched off or on. Returns number of changes. */
    fun check(ctx: Context): Int {
        if (!enabled(ctx)) return 0
        var changes = 0
        val now = snapshot(ctx)
        val first = !Features.getBool(ctx, "sw_initialised", false)
        for ((name, on) in now) {
            val key = "sw_last_" + name.replace(' ', '_')
            val was = Features.getBool(ctx, key, on)
            if (!first && was != on) {
                changes++
                log(ctx, if (on) "permission-on" else "permission-off", "$name " + if (on) "was turned on" else "was turned off")
                val sensitive = name == "Microphone" || name == "Accessibility" || name == "Notification access" || name == "Device Owner"
                if (sensitive) Notifier.post(ctx, 6300 + (name.hashCode() and 0xFF), "Nova: $name changed", "$name was ${if (on) "turned on" else "turned off"}. Open Nova > More > Security Activity.")
            }
            Features.putBool(ctx, key, on)
        }
        Features.putBool(ctx, "sw_initialised", true)
        if (Features.getBool(ctx, "sw_voice_running", false) && !VoiceState.running.value) {
            changes++
            Features.putBool(ctx, "sw_voice_running", false)
            log(ctx, "service-killed", "Background voice stopped unexpectedly (Android or the battery manager ended it)")
            Notifier.post(ctx, 6299, "Nova's background voice stopped", "Android ended it. Open Nova to start it again, and check battery settings: Control Center > Device Management.")
        }
        return changes
    }
}

/** Optional: today's most used apps, only if you granted Usage access (Android's own special permission). Nothing is stored. */
object UsageInfo {
    fun topApps(ctx: Context, n: Int = 5): List<Pair<String, Long>> {
        if (!SecurityWatch.usageAccess(ctx)) return emptyList()
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
            val pm = ctx.packageManager
            usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis())
                .filter { it.totalTimeInForeground > 60_000 }
                .sortedByDescending { it.totalTimeInForeground }.take(n)
                .map { s -> (try { pm.getApplicationInfo(s.packageName, 0).loadLabel(pm).toString() } catch (e: Exception) { s.packageName }) to s.totalTimeInForeground / 60000 }
        } catch (e: Exception) { emptyList() }
    }
}

/** Automatic expiry of Nova's own histories. 0 days = keep until you clear them. */
object Retention {
    val choices = listOf(0, 7, 30, 90)
    fun days(ctx: Context) = Features.getInt(ctx, "retention_days", 30)
    fun setDays(ctx: Context, d: Int) { Features.putInt(ctx, "retention_days", d); purge(ctx) }

    fun purge(ctx: Context) {
        val d = days(ctx)
        if (d <= 0) return
        val cutoff = System.currentTimeMillis() - d * 86_400_000L
        for (name in listOf("error_history.json", "workflow_history.json", "security_activity.json")) {
            try {
                val f = File(ctx.filesDir, name)
                if (!f.exists()) continue
                val a = JSONArray(f.readText()); val keep = JSONArray()
                for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.optLong("t") >= cutoff) keep.put(o) }
                if (keep.length() != a.length()) f.writeText(keep.toString())
            } catch (e: Exception) { }
        }
    }
}
