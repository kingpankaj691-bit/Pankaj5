package com.nova.ai.brain

import java.security.MessageDigest
import kotlin.math.exp
import kotlin.math.sqrt

/** Small text toolkit shared by the memory engine: tokens, hashes, a local hashed-n-gram "embedding", similarity. Pure Kotlin. */
object Txt {
    private val splitter = Regex("[^\\p{L}\\p{N}\\p{M}]+")

    val STOP: Set<String> = setOf(
        "the", "and", "for", "are", "was", "were", "with", "that", "this", "you", "your", "what", "when", "how", "can", "did", "does", "has", "have",
        "had", "will", "would", "could", "should", "from", "into", "about", "tell", "please", "nova", "hey", "ok", "okay", "its", "our", "his", "her",
        "kya", "hai", "hain", "tha", "thi", "the", "ho", "hoon", "hu", "hun", "raha", "rahi", "rahe", "karo", "kar", "karna", "karne", "kiya", "ka", "ki", "ke",
        "ko", "se", "me", "mein", "main", "par", "pe", "aur", "ya", "to", "toh", "bhi", "hi", "ye", "yeh", "woh", "wo", "us", "is", "iss", "uss", "mera",
        "meri", "mere", "mujhe", "tumhe", "tum", "aap", "hum", "humne", "maine", "tune", "ek", "koi", "kuch", "abhi", "phir", "bata", "batao", "bataya",
        "yaad", "dilao", "wala", "wali", "wale", "baat", "na", "nahi", "nahin", "jo", "kaun", "kab", "kahan", "kyun", "kaise",
        "है", "हैं", "था", "थी", "का", "की", "के", "को", "से", "में", "पर", "और", "यह", "वह", "तो", "ने", "कर", "करो", "मैं", "मुझे", "हम", "क्या"
    )

    // Words that mean roughly the same thing for retrieval (English, Hinglish, Hindi).
    private val SYN: List<Set<String>> = listOf(
        setOf("phone", "mobile", "handset", "smartphone", "device", "fon", "फोन", "मोबाइल"),
        setOf("project", "prj", "application", "app", "software", "प्रोजेक्ट"),
        setOf("ui", "design", "interface", "theme", "look", "style", "layout", "glass", "liquid"),
        setOf("task", "todo", "pending", "adhura", "adhure", "kaam", "work", "feature", "baaki"),
        setOf("voice", "speech", "mic", "microphone", "awaaz", "bolna", "audio"),
        setOf("memory", "yaad", "remember", "recall", "save", "saved"),
        setOf("code", "source", "kotlin", "script", "program", "file", "class"),
        setOf("model", "gemini", "llm", "ai"),
        setOf("birthday", "janamdin", "bday"),
        setOf("meeting", "appointment", "interview", "exam"),
        setOf("editing", "edit", "video", "reel", "premiere", "capcut"),
        setOf("learn", "learning", "seekh", "seekhna", "study", "padhai", "course")
    )

    fun norm(s: String): String = splitter.replace(s.lowercase(), " ").trim()

    private fun stem(w: String): String = when {
        w.length > 5 && w.endsWith("ing") -> w.dropLast(3)
        w.length > 4 && w.endsWith("ed") -> w.dropLast(2)
        w.length > 4 && w.endsWith("es") -> w.dropLast(2)
        w.length > 3 && w.endsWith("s") -> w.dropLast(1)
        else -> w
    }

    /** Meaningful lower-case words (stop words removed, light stemming). */
    fun tokens(s: String): List<String> =
        norm(s).split(' ').filter { it.length >= 2 && it !in STOP }.map { stem(it) }

    fun tokenSet(s: String): Set<String> = tokens(s).toSet()

    /** Tokens plus the words they are close to ("phone" also brings "mobile"). */
    fun expand(tokens: Collection<String>): Set<String> {
        val out = HashSet<String>(tokens)
        for (g in SYN) if (tokens.any { it in g }) out.addAll(g)
        return out
    }

    fun hash(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(tokens(s).sorted().joinToString(" ").ifBlank { norm(s) }.toByteArray(Charsets.UTF_8))
        return d.take(8).joinToString("") { "%02x".format(it) }
    }

    fun sha256Hex(b: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private const val DIM = 256

    /** Local semantic-ish vector: hashed character trigrams plus words. Not a neural embedding; it captures spelling and word overlap. */
    fun embed(s: String): FloatArray {
        val v = FloatArray(DIM)
        val n = norm(s)
        if (n.isEmpty()) return v
        val padded = " $n "
        for (i in 0..padded.length - 3) v[Math.floorMod(padded.substring(i, i + 3).hashCode(), DIM)] += 1f
        for (w in expand(tokens(s))) v[Math.floorMod(("w:$w").hashCode(), DIM)] += 2f
        var sum = 0f
        for (x in v) sum += x * x
        val len = sqrt(sum)
        if (len > 0f) for (i in v.indices) v[i] /= len
        return v
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        for (i in a.indices) d += a[i] * b[i]
        return d
    }

    fun jaccard(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        val inter = a.count { it in b }
        return inter.toFloat() / (a.size + b.size - inter)
    }

    /** True when two statements say the same thing (duplicate detection). */
    fun similar(a: String, b: String): Boolean {
        if (hash(a) == hash(b)) return true
        val ta = tokenSet(a); val tb = tokenSet(b)
        if (ta.size >= 3 && tb.size >= 3 && jaccard(ta, tb) >= 0.8f) return true
        return ta.size >= 3 && tb.size >= 3 && cosine(embed(a), embed(b)) >= 0.93f
    }

    fun recency(updatedAt: Long, now: Long): Float {
        val days = ((now - updatedAt).coerceAtLeast(0)) / 86_400_000.0
        return exp(-days / 60.0).toFloat()
    }

    fun clip(s: String, n: Int): String = if (s.length <= n) s else s.take(n - 1).trimEnd() + "…"
}
