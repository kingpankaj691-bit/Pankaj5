package com.nova.ai.jarvis

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import com.nova.ai.live.LiveSession
import com.nova.ai.suite.VoiceLevel
import com.nova.ai.voice.OrbPhase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The Galaxy Orb: a glass sphere with a galaxy inside, a glowing outer ring, particles and audio-reactive waves.
 *
 *  IDLE      small, still sphere (nothing animates, so an idle orb costs no battery)
 *  LISTENING sound-wave rings and a circular waveform follow the microphone; the outer ring swells with your voice
 *  THINKING  particles circle the sphere and the ring spins
 *  SPEAKING  rings expand and contract with Nova's voice
 *
 * Everything is drawn in a 200 x 200 "unit space" scaled to the view, so gradients are built once and never rebuilt while the
 * window grows or shrinks. onDraw allocates nothing. Reduced effects: fewer particles, a 20 fps cap, a simpler waveform.
 * The view is square at the top ([width] = orb size); when it is taller, the extra space under it holds the status label.
 */
internal class GalaxyOrbView(ctx: Context) : View(ctx) {
    var phase = OrbPhase.IDLE
        private set
    var reduced = false
    var micOn = true
    var problem = false
    var online = true
    var label = ""
    var onConfig: (() -> Unit)? = null

    // ── paints and shaders (unit space, centred on 0,0) ──
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(0f, 0f, 98f, intArrayOf(0x884FC3F7.toInt(), 0x445B5CFF, 0x00000000), floatArrayOf(0.55f, 0.76f, 1f), Shader.TileMode.CLAMP)
    }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        shader = SweepGradient(0f, 0f, intArrayOf(0xFF22D3EE.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFE0F2FE.toInt(), 0xFF22D3EE.toInt()), null)
    }
    private val cometP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt() }
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(-22f, -26f, 92f, intArrayOf(0xFF8FB8FF.toInt(), 0xFF4B3FD0.toInt(), 0xFF15133F.toInt(), 0xFF05061A.toInt()), floatArrayOf(0f, 0.36f, 0.74f, 1f), Shader.TileMode.CLAMP)
    }
    private val nebulaCyanP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(26f, 30f, 58f, intArrayOf(0x9000E5FF.toInt(), 0x00000000), null, Shader.TileMode.CLAMP)
    }
    private val nebulaVioletP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(-30f, 12f, 48f, intArrayOf(0x70C084FC.toInt(), 0x00000000), null, Shader.TileMode.CLAMP)
    }
    private val shadeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, -62f, 0f, 62f, intArrayOf(0x30FFFFFF, 0x00FFFFFF, 0x38000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f; color = 0x66FFFFFF }
    private val specP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99FFFFFF.toInt() }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val waveP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF67E8F9.toInt() }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; strokeJoin = Paint.Join.ROUND; color = 0xFFE0F7FF.toInt() }
    private val badgeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC0B1026.toInt() }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f; color = 0x44A5B4FC }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12f, resources.displayMetrics)
    }
    private val bodyClip = Path().apply { addCircle(0f, 0f, 62f, Path.Direction.CW) }
    private val wave = Path()
    private val ringArc = RectF()
    private val pill = RectF()

    // ── particles (fixed arrays, no allocation per frame) ──
    private val pAng = FloatArray(MAX_P); private val pRad = FloatArray(MAX_P); private val pSpd = FloatArray(MAX_P)
    private val pSize = FloatArray(MAX_P); private val pTw = FloatArray(MAX_P); private val pCol = IntArray(MAX_P)
    private val palette = intArrayOf(0xFFFFFFFF.toInt(), 0xFF67E8F9.toInt(), 0xFFA5B4FC.toInt(), 0xFFC4B5FD.toInt())

    // ── animation clock ──
    private var t = 0f
    private var ringAngle = 0f
    private var lvl = 0f
    private var last = 0L
    private var running = false

    init {
        val rnd = java.util.Random(7L)
        for (i in 0 until MAX_P) {
            pAng[i] = rnd.nextFloat() * TAU
            pRad[i] = 10f + rnd.nextFloat() * 48f
            pSpd[i] = (0.25f + rnd.nextFloat() * 0.6f) * (if (rnd.nextBoolean()) 1f else -1f)
            pSize[i] = 0.8f + rnd.nextFloat() * 1.6f
            pTw[i] = rnd.nextFloat() * TAU
            pCol[i] = palette[rnd.nextInt(palette.size)]
        }
    }

    fun setPhase(p: OrbPhase) {
        phase = p
        if (p == OrbPhase.IDLE) lvl = 0f
        syncAnimation()
        invalidate()
    }

    private fun shouldRun() = isAttachedToWindow && phase != OrbPhase.IDLE

    fun syncAnimation() {
        if (shouldRun()) { if (!running) { running = true; last = SystemClock.uptimeMillis(); postOnAnimation(frame) } }
        else running = false
    }

    private val frame = object : Runnable {
        override fun run() {
            if (!running || !shouldRun()) { running = false; return }
            val now = SystemClock.uptimeMillis()
            if (reduced && now - last < 48L) { postOnAnimation(this); return }      // 20 fps cap
            val dt = min((now - last) / 1000f, 0.05f)
            last = now
            step(dt)
            invalidate()
            postOnAnimation(this)
        }
    }

    private fun step(dt: Float) {
        t += dt
        val target = when (phase) {
            OrbPhase.LISTENING -> VoiceLevel.level.value
            OrbPhase.SPEAKING -> max(LiveSession.amplitude.value, 0.30f + 0.22f * sin(t * 7f) * sin(t * 2.3f + 1f))   // TTS has no level: a soft synthetic pulse
            OrbPhase.THINKING -> 0.12f
            OrbPhase.IDLE -> 0f
        }.coerceIn(0f, 1f)
        lvl += (target - lvl) * min(1f, dt * 12f)
        val speed = when (phase) { OrbPhase.THINKING -> 150f; OrbPhase.SPEAKING -> 50f; OrbPhase.LISTENING -> 22f; OrbPhase.IDLE -> 0f }
        ringAngle = (ringAngle + speed * dt) % 360f
        val boost = if (phase == OrbPhase.THINKING) 4f else 1f
        val n = particleCount()
        for (i in 0 until n) pAng[i] = (pAng[i] + pSpd[i] * boost * dt) % TAU
    }

    private fun particleCount() = if (reduced) 10 else MAX_P

    override fun onAttachedToWindow() { super.onAttachedToWindow(); syncAnimation() }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(frame); super.onDetachedFromWindow() }
    override fun onConfigurationChanged(newConfig: Configuration?) { super.onConfigurationChanged(newConfig); onConfig?.invoke() }

    override fun onDraw(canvas: Canvas) {
        val d = width.toFloat()
        if (d <= 0f) return
        canvas.save()
        canvas.translate(d / 2f, d / 2f)
        val k = d / 200f
        canvas.scale(k, k)
        drawOrb(canvas)
        canvas.restore()
        drawBadges(canvas, d)
        if (label.isNotEmpty() && height > d * 1.12f) drawLabel(canvas, d)
    }

    private fun drawOrb(c: Canvas) {
        val active = phase != OrbPhase.IDLE
        val breathe = 1f + 0.025f * sin(t * 1.6f) + 0.07f * lvl
        c.save(); c.scale(breathe, breathe)

        // soft neon glow
        glowP.alpha = if (active) 255 else 150
        c.drawCircle(0f, 0f, 98f, glowP)

        // audio-reactive wave rings
        when (phase) {
            OrbPhase.LISTENING -> for (i in 0 until 3) {
                val p = (t * 0.55f + i / 3f) % 1f
                waveP.strokeWidth = 1.8f
                waveP.alpha = (((1f - p) * (0.25f + 0.65f * lvl)) * 255f).toInt().coerceIn(0, 255)
                c.drawCircle(0f, 0f, 66f + 32f * p, waveP)
            }
            OrbPhase.SPEAKING -> for (i in 0 until 3) {
                val s = 0.5f + 0.5f * sin(t * 3f + i * 2.1f)
                waveP.strokeWidth = 2f
                waveP.alpha = ((0.18f + 0.35f * (1f - i * 0.25f)) * 255f).toInt()
                c.drawCircle(0f, 0f, 68f + (6f + 20f * (0.35f + lvl)) * s + i * 5f, waveP)
            }
            else -> {}
        }

        // glowing outer ring (rotates while thinking, swells with the voice while listening)
        val ringR = 78f + 6f * lvl
        ringP.strokeWidth = (if (active) 3.2f else 2.2f) + 4.5f * lvl
        ringP.alpha = if (active) 255 else 170
        c.save(); c.rotate(ringAngle); c.drawCircle(0f, 0f, ringR, ringP); c.restore()
        if (phase == OrbPhase.THINKING) {                              // bright comet running around the ring
            cometP.strokeWidth = 5f; cometP.alpha = 230
            ringArc.set(-ringR, -ringR, ringR, ringR)
            c.drawArc(ringArc, ringAngle * 1.7f, 70f, false, cometP)
        }

        // glass sphere with the galaxy inside
        c.drawCircle(0f, 0f, 62f, bodyP)
        c.save(); c.clipPath(bodyClip)
        c.drawCircle(0f, 0f, 62f, nebulaCyanP)
        c.drawCircle(0f, 0f, 62f, nebulaVioletP)
        if (active || !reduced) drawParticles(c, active)
        c.restore()
        if (active) drawWaveform(c)
        c.drawCircle(0f, 0f, 62f, shadeP)                                // glass depth
        c.drawCircle(0f, 0f, 61f, rimP)                                  // rim light
        c.save(); c.rotate(-28f); c.drawOval(-30f, -50f, 14f, -26f, specP); c.restore()    // specular highlight
        dotP.color = 0x33FFFFFF; c.drawCircle(21f, 26f, 8f, dotP)        // bounce light

        // particles that orbit outside the sphere while thinking
        if (phase == OrbPhase.THINKING) {
            val n = if (reduced) 4 else 9
            for (i in 0 until n) {
                val a = ringAngle * PI.toFloat() / 180f * 1.3f + i * TAU / n
                dotP.color = pCol[i]; dotP.alpha = 230
                c.drawCircle(cos(a) * 90f, sin(a) * 90f, 2.4f + (i % 3) * 0.5f, dotP)
            }
        }
        c.restore()
    }

    private fun drawParticles(c: Canvas, active: Boolean) {
        val n = particleCount()
        for (i in 0 until n) {
            val tw = 0.55f + 0.45f * sin(t * 2.2f + pTw[i])
            dotP.color = pCol[i]
            dotP.alpha = ((if (active) 0.95f else 0.55f) * tw * 255f).toInt().coerceIn(0, 255)
            c.drawCircle(cos(pAng[i]) * pRad[i], sin(pAng[i]) * pRad[i], pSize[i], dotP)
        }
    }

    /** Circular waveform inside the sphere: the radius wobbles with the sound level. */
    private fun drawWaveform(c: Canvas) {
        val pts = if (reduced) 28 else 56
        val amp = 3f + 15f * lvl
        wave.reset()
        for (i in 0..pts) {
            val a = i * TAU / pts
            val r = 40f + amp * (0.6f * sin(a * 5f + t * 6f) + 0.4f * sin(a * 9f - t * 4.3f))
            val x = cos(a) * r; val y = sin(a) * r
            if (i == 0) wave.moveTo(x, y) else wave.lineTo(x, y)
        }
        wave.close()
        lineP.alpha = 235
        c.drawPath(wave, lineP)
    }

    private fun drawBadges(c: Canvas, d: Float) {
        // microphone indicator (bottom right of the orb): green = listening for Hey Nova, grey = paused, red = problem
        val r = d * 0.052f
        val cx = d * 0.80f; val cy = d * 0.80f
        badgeP.color = 0xFF0B1026.toInt(); c.drawCircle(cx, cy, r * 1.45f, badgeP)
        badgeP.color = when { problem -> 0xFFFF5252.toInt(); micOn -> 0xFF00E676.toInt(); else -> 0xFF9E9E9E.toInt() }
        c.drawCircle(cx, cy, r, badgeP)
        // connection dot (top right): green = online, grey = offline
        badgeP.color = if (online) 0xFF00E676.toInt() else 0xFF9E9E9E.toInt()
        c.drawCircle(d * 0.88f, d * 0.12f, d * 0.035f, badgeP)
    }

    private fun drawLabel(c: Canvas, d: Float) {
        val tw = textP.measureText(label)
        val padX = textP.textSize * 0.9f
        val h = textP.textSize * 1.9f
        val cy = d + (height - d) / 2f
        pill.set(width / 2f - tw / 2f - padX, cy - h / 2f, width / 2f + tw / 2f + padX, cy + h / 2f)
        c.drawRoundRect(pill, h / 2f, h / 2f, pillP)
        c.drawRoundRect(pill, h / 2f, h / 2f, pillStroke)
        c.drawText(label, width / 2f, cy + textP.textSize * 0.35f, textP)
    }

    private companion object {
        const val MAX_P = 28
        const val TAU = 6.2831855f
    }
}
