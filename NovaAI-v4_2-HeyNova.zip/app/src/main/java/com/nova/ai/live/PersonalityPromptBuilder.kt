package com.nova.ai.live

import com.nova.ai.ai.Personality

/** Builds the system instruction for the full-duplex Live session. Uses Nova's own personalities and the saved assistant name. */
object PersonalityPromptBuilder {

    /** Language setting values as stored in Prefs.language: auto | english | hindi | hinglish | manual. */
    fun build(
        personality: Personality,
        customPersonality: String,
        language: String,
        manualLanguageName: String,
        detected: String?,
        recap: String?,
        assistantName: String,
        toolInstruction: String = LiveTools.TOOL_INSTRUCTION,
        /** Conversation-level language lock from the memory engine. Null keeps the older wording. */
        lockedLanguage: String? = null,
        /** Topic, profile, relevant memories and recent messages from the memory engine, rebuilt on every (re)connection. */
        brainContext: String? = null
    ): String {
        val parts = ArrayList<String>()
        parts.add("You are $assistantName, a persistent personal voice assistant living on the user's phone. Keep replies short and conversational, like spoken conversation.")
        if (toolInstruction.isNotBlank()) parts.add(toolInstruction)
        val persona = if (personality == Personality.Custom) customPersonality.ifBlank { "Neutral, clear and helpful." } else personality.prompt
        parts.add("Personality: ${personality.label}. $persona")
        parts.add(if (language == "auto" && !lockedLanguage.isNullOrBlank()) lockedLanguage else languagePolicy(language, manualLanguageName, detected))
        if (!brainContext.isNullOrBlank()) parts.add(brainContext)
        parts.add(
            "Safety: never claim to be human or to have a body. No sexually explicit content. If the user asks you to stop a topic or change tone, do it immediately. " +
                "Vary your phrasing from reply to reply."
        )
        if (personality == Personality.GFMode || personality == Personality.Companion || personality == Personality.Emotional) {
            parts.add("Never claim to be human or to have a body, never be sexually explicit, and immediately respect any request to change tone or topic.")
        }
        if (recap != null) parts.add("This is a continuing conversation — do not greet again. Recap:\n$recap")
        return parts.joinToString("\n\n")
    }

    internal fun languagePolicy(language: String, manualName: String, detected: String?): String = when (language) {
        "english" -> "Language: always speak English."
        "hindi" -> "Language: always speak Hindi (Devanagari script is not needed; speak naturally)."
        "hinglish" -> "Language: always speak Hinglish, Hindi mixed with English in a natural spoken way."
        "manual" -> "Language: always speak ${manualName.ifBlank { "the language the user selected" }}."
        else -> "Language: match the language of the user's latest turn (Hindi, Hinglish or English) turn by turn, and never translate what they said." +
            (if (!detected.isNullOrBlank()) " The user last spoke: $detected." else "")
    }
}
