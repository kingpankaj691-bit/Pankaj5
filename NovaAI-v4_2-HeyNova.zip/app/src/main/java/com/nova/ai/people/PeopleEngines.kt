package com.nova.ai.people

import com.nova.ai.memory.Confidence
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

enum class Verdict { REMEMBER, TEMPORARY, IGNORE }

data class PeopleDecision(val verdict: Verdict, val importance: Float, val confidence: Confidence, val expiresAt: Long, val reason: String)

fun endOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
}.timeInMillis

/** Confidence fades for unconfirmed things that haven't been used. User-confirmed items keep their confidence. */
class MemoryConfidenceEngine {
    fun effective(c: String, confirmed: Boolean, createdAt: Long, lastUsedAt: Long, now: Long = System.currentTimeMillis()): Confidence {
        val base = try { Confidence.valueOf(c) } catch (e: Exception) { Confidence.LOW }
        if (confirmed) return base
        val idleDays = (now - maxOf(createdAt, lastUsedAt)) / 86400000L
        return when { idleDays > 180 -> Confidence.LOW; idleDays > 60 && base == Confidence.HIGH -> Confidence.MEDIUM; else -> base }
    }
}

/** Decides REMEMBER / TEMPORARY / IGNORE for person-related information. Sensitive text is never remembered. */
class MemoryDecisionEngine(private val isSensitive: (String) -> Boolean) {
    fun relationship() = PeopleDecision(Verdict.REMEMBER, 0.9f, Confidence.HIGH, 0, "Saved because you explicitly told NOVA about this person.")

    fun context(today: Boolean): PeopleDecision =
        if (today) PeopleDecision(Verdict.TEMPORARY, 0.5f, Confidence.MEDIUM, endOfToday(), "It's about today only, so NOVA forgets it automatically.")
        else PeopleDecision(Verdict.REMEMBER, 0.6f, Confidence.MEDIUM, System.currentTimeMillis() + 60L * 86400000L,
            "Saved because you told NOVA this about them. It expires after 60 days unless you keep it.")

    fun note(text: String, explicit: Boolean): PeopleDecision = when {
        isSensitive(text) -> PeopleDecision(Verdict.IGNORE, 0f, Confidence.LOW, 0, "It looks like private information, so NOVA didn't save it.")
        explicit -> PeopleDecision(Verdict.REMEMBER, 0.85f, Confidence.HIGH, 0, "Saved because you asked NOVA to remember it.")
        else -> PeopleDecision(Verdict.IGNORE, 0.1f, Confidence.LOW, 0, "You didn't ask NOVA to remember it.")
    }
}

/** Remember / temporary context / ignore for ordinary messages that mention a saved person. */
class ConversationContextEngine {
    private val temporal = Regex("(?i)\\b(aaj|today|tonight|kal|tomorrow|abhi|right now)\\b")
    fun classify(text: String, mentionsPerson: Boolean): Verdict =
        if (!mentionsPerson) Verdict.IGNORE else if (temporal.containsMatchIn(text) && text.length <= 160) Verdict.TEMPORARY else Verdict.IGNORE
}

/**
 * Optional future module. No speaker model is installed, NOVA never records audio for this, and a voice match would only
 * personalize chat (never authorize anything). Low confidence always leads to a question.
 */
interface SpeakerModule { val available: Boolean; suspend fun identify(): Pair<Long, Float>? }

class SpeakerIdentificationManager(private val module: SpeakerModule? = null) {
    val installed: Boolean get() = module?.available == true
    suspend fun identify(): Pair<Long, Float>? = module?.takeIf { it.available }?.identify()
}

class PersonProfileResolver {
    /** Returns the matched person (or null) and a question to ask when confidence is low. */
    fun fromSpeaker(result: Pair<Long, Float>?, people: List<PersonWithData>, hindi: Boolean): Pair<PersonWithData?, String?> {
        if (result == null) return null to null
        val p = people.firstOrNull { it.person.personId == result.first } ?: return null to null
        val q = if (result.second >= 0.85f) null
        else if (hindi) "Main sure nahi hoon ki ye ${p.person.name} hain. Kya aap confirm karna chahte hain?"
        else "I'm not sure this is ${p.person.name}. Would you like to confirm?"
        return p to q
    }
}

class PrivacyManager {
    /** Smallest useful line for an AI request. */
    fun minimalLine(p: PersonWithData) = "${p.person.name} is the user's ${p.person.relLabel.lowercase()}."

    /** User-initiated export of everything stored locally. */
    fun export(people: List<PersonWithData>): String = JSONObject()
        .put("exportedAt", System.currentTimeMillis())
        .put("people", JSONArray(people.map { pw ->
            JSONObject().put("name", pw.person.name).put("nickname", pw.person.nickname).put("preferredAddress", pw.person.preferredAddress)
                .put("relationship", pw.person.relLabel).put("category", pw.person.category).put("userConfirmed", pw.person.userConfirmed)
                .put("createdAt", pw.person.createdAt).put("lastInteraction", pw.person.lastInteraction).put("style", pw.person.style)
                .put("notes", pw.person.notes).put("lastContext", pw.person.lastContext).put("aliases", JSONArray(pw.aliases.map { it.alias }))
                .put("memories", JSONArray(pw.memories.map { m ->
                    JSONObject().put("kind", m.kind).put("content", m.content).put("confidence", m.confidence).put("source", m.source)
                        .put("importance", m.importance.toDouble()).put("createdAt", m.createdAt).put("expiresAt", m.expiresAt)
                        .put("userConfirmed", m.userConfirmed).put("reason", m.reason)
                }))
        })).toString(2)
}
