package com.nova.ai.security

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Turns Security Mode on and off. Only an explicit user action calls [arm]; nothing re-arms by itself, not even after a reboot. */
object SecurityModeManager {

    fun isArmed(p: Prefs) = p.securityModeOn && SecurityMonitorService.running

    fun arm(ctx: Context, p: Prefs): String {
        val app = ctx.applicationContext
        return try {
            ContextCompat.startForegroundService(app, Intent(app, SecurityMonitorService::class.java).setAction(SecurityMonitorService.ACTION_START))
            p.securityModeOn = true
            "Security Mode on. Put the phone down: it arms in ${p.secArmDelaySec} seconds, then sounds an alarm if it is moved or picked up. " +
                "A notification stays visible while it is on."
        } catch (e: Exception) {
            "Android didn't let me start Security Mode from here. Open Nova > Settings > Security & Voice Lock and turn it on there."
        }
    }

    fun disarm(ctx: Context, p: Prefs): String {
        val app = ctx.applicationContext
        p.securityModeOn = false
        SecurityAlarmManager.get(app).stop()
        app.stopService(Intent(app, SecurityMonitorService::class.java))
        return "Security Mode off."
    }

    fun status(p: Prefs): String =
        if (isArmed(p)) "Security Mode is on." else if (p.securityModeOn) "Security Mode was on but isn't running. Turn it on again." else "Security Mode is off."
}
