package com.nova.ai.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioRecordingConfiguration
import android.media.AudioRouting
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Continuous PCM capture with the native AudioRecord. No SpeechRecognizer, so there is no start/stop cycle and no system beep.
 * Chunks are handed to the [SpeechProcessingEngine] as they arrive; nothing is written to disk and nothing piles up in RAM.
 *
 * Failure policy: every retry loop is bounded. When the limit is hit the capture reports [Events.onFatal] and ends;
 * it never restarts itself forever.
 */
@SuppressLint("NewApi")
class AudioCapture(
    private val ctx: Context,
    private val engine: SpeechProcessingEngine,
    private val events: Events,
    /** Experimental barge-in: VOICE_COMMUNICATION has echo cancellation so Nova can be interrupted while she speaks. */
    private val preferCommunication: Boolean = false
) {
    interface Events {
        /** AudioRecord is open and recording. [info] says which microphone (built-in, Bluetooth, wired...). */
        fun onListening(info: String)
        /** The microphone was released or silenced for a reason that may pass (call, other app). */
        fun onWaiting(reason: String)
        /** Capture gave up. Nothing is running afterwards. */
        fun onFatal(message: String)
    }

    companion object {
        private val SAMPLE_RATES = intArrayOf(16000, 44100, 48000)
        private val SOURCES = intArrayOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        private const val MAX_OPEN_FAILURES = 5
        private const val MAX_READ_FAILURES = 5
    }

    /** Hook for a future Bluetooth / USB microphone picker. Null = let Android choose. */
    @Volatile var preferredDevice: AudioDeviceInfo? = null

    private class Opened(val rec: AudioRecord, val format: PcmFormat, val chunkBytes: Int)

    private val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val lock = Any()
    @Volatile private var record: AudioRecord? = null
    @Volatile private var scope: CoroutineScope? = null
    private var job: Job? = null
    private var routingListener: Any? = null          // AudioRouting.OnRoutingChangedListener (API 28+)
    private var recordingCallback: AudioManager.AudioRecordingCallback? = null
    @Volatile private var silenced = false
    private var lastRate = 0
    private var lastOpenError = ""
    private var engineFormat: PcmFormat? = null
    private val effects = ArrayList<android.media.audiofx.AudioEffect>()

    fun start() {
        synchronized(lock) {
            if (job != null) return
            val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope = s
            job = s.launch { loop() }
        }
    }

    /** Stops the loop, stops and releases AudioRecord, stops the engine. Safe to call more than once and from any thread. */
    fun stop() {
        val s: CoroutineScope?
        synchronized(lock) {
            s = scope
            scope = null
            job = null
        }
        s?.cancel()
        closeRecord()
        unregisterSilenceWatch()
        try { engine.stop() } catch (e: Exception) { }
    }

    // ───────── main loop ─────────

    private suspend fun CoroutineScope.loop() {
        var openFailures = 0
        var readFailures = 0
        var buffer = ByteArray(0)
        try {
            registerSilenceWatch()
            while (isActive) {
                if (!VoicePermissionManager.hasMic(ctx)) {
                    events.onFatal("Microphone permission was revoked. Background Voice stopped.")
                    return
                }
                if (inCall()) {
                    closeRecord()
                    events.onWaiting("Phone call in progress. Microphone released.")
                    while (isActive && inCall()) delay(1000)
                    continue
                }
                var rec = record
                if (rec == null) {
                    val opened = openRecord()
                    if (opened == null) {
                        openFailures++
                        if (openFailures >= MAX_OPEN_FAILURES) {
                            events.onFatal(lastOpenError.ifBlank { "Could not open the microphone." })
                            return
                        }
                        events.onWaiting("$lastOpenError Retrying ($openFailures/$MAX_OPEN_FAILURES)...")
                        delay(2000L * openFailures)
                        continue
                    }
                    openFailures = 0
                    rec = opened.rec
                    buffer = ByteArray(opened.chunkBytes)
                    if (engineFormat != opened.format) {
                        engine.start(opened.format, this)
                        engineFormat = opened.format
                    }
                    silenced = false
                    events.onListening(describe(rec.routedDevice))
                }
                val n = rec.read(buffer, 0, buffer.size)
                when {
                    n > 0 -> {
                        readFailures = 0
                        if (!silenced) { engine.processAudio(buffer, n); com.nova.ai.suite.VoiceLevel.feed(buffer, n) }
                    }
                    n == 0 -> delay(10)
                    else -> {
                        if (!isActive) return
                        readFailures++
                        closeRecord()
                        if (readFailures >= MAX_READ_FAILURES) {
                            events.onFatal("Reading from the microphone keeps failing (error $n).")
                            return
                        }
                        events.onWaiting("Microphone read failed (error $n). Reopening...")
                        delay(500L * readFailures)
                    }
                }
            }
        } finally {
            closeRecord()
            unregisterSilenceWatch()
            try { engine.stop() } catch (e: Exception) { }
        }
    }

    // ───────── AudioRecord ─────────

    @SuppressLint("MissingPermission")
    private fun openRecord(): Opened? {
        val rates = SAMPLE_RATES.toMutableList()
        if (lastRate != 0 && rates.remove(lastRate)) rates.add(0, lastRate)
        for (rate in rates) {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) {
                lastOpenError = "Unsupported audio configuration ($rate Hz)."
                continue
            }
            val sources = if (preferCommunication) intArrayOf(MediaRecorder.AudioSource.VOICE_COMMUNICATION) + SOURCES else SOURCES
            for (src in sources) {
                var created: AudioRecord? = null
                try {
                    val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
                    created = r
                    if (r.state != AudioRecord.STATE_INITIALIZED) {
                        lastOpenError = "Microphone could not be initialized at $rate Hz."
                        r.release()
                        continue
                    }
                    preferredDevice?.let { r.setPreferredDevice(it) }
                    r.startRecording()
                    if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                        lastOpenError = "The microphone is already in use by another app."
                        r.release()
                        continue
                    }
                    if (preferCommunication) attachEffects(r)
                    if (Build.VERSION.SDK_INT >= 28) watchRouting(r)
                    synchronized(lock) { record = r }
                    lastRate = rate
                    val chunk = (rate / 25) * 2            // 40 ms of mono PCM16: low latency for the live voice
                    return Opened(r, PcmFormat(rate, 1), chunk)
                } catch (e: SecurityException) {
                    lastOpenError = "Microphone permission was denied by Android."
                    try { created?.release() } catch (x: Exception) { }
                    return null
                } catch (e: Exception) {
                    lastOpenError = "Microphone error: ${e.message ?: e.javaClass.simpleName}"
                    try { created?.release() } catch (x: Exception) { }
                }
            }
        }
        if (lastOpenError.isBlank()) lastOpenError = "No supported audio configuration."
        return null
    }

    /** Barge-in needs the phone's echo canceller (and noise suppressor) on this recording, otherwise Nova hears herself. Missing on a few phones: then the engine's level gate is the fallback. */
    private fun attachEffects(r: AudioRecord) {
        try {
            if (android.media.audiofx.AcousticEchoCanceler.isAvailable()) android.media.audiofx.AcousticEchoCanceler.create(r.audioSessionId)?.let { it.setEnabled(true); effects.add(it) }
            if (android.media.audiofx.NoiseSuppressor.isAvailable()) android.media.audiofx.NoiseSuppressor.create(r.audioSessionId)?.let { it.setEnabled(true); effects.add(it) }
        } catch (e: Exception) { }
    }

    private fun releaseEffects() {
        for (e in effects) { try { e.release() } catch (x: Exception) { } }
        effects.clear()
    }

    private fun closeRecord() {
        releaseEffects()
        val r: AudioRecord?
        synchronized(lock) {
            r = record
            record = null
        }
        if (r == null) return
        if (Build.VERSION.SDK_INT >= 28) unwatchRouting(r)
        try { if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) r.stop() } catch (e: Exception) { }
        try { r.release() } catch (e: Exception) { }
    }

    /** Reports when Android re-routes the microphone (Bluetooth headset connected / disconnected, wired mic plugged). Capture itself keeps running. */
    @androidx.annotation.RequiresApi(28)
    private fun watchRouting(r: AudioRecord) {
        try {
            val l = AudioRouting.OnRoutingChangedListener { router ->
                val dev = (router as? AudioRecord)?.routedDevice
                if (!silenced) events.onListening(describe(dev))
            }
            r.addOnRoutingChangedListener(l, null)
            routingListener = l
        } catch (e: Exception) { }
    }

    @androidx.annotation.RequiresApi(28)
    private fun unwatchRouting(r: AudioRecord) {
        val l = routingListener as? AudioRouting.OnRoutingChangedListener
        routingListener = null
        try { if (l != null) r.removeOnRoutingChangedListener(l) } catch (e: Exception) { }
    }

    // ───────── calls and other apps ─────────

    /** Phone call or VoIP call: Android uses these audio modes. We release the microphone for the duration. While the phone only rings, we keep listening so you can say "uthao" or "kaat do". */
    private fun inCall(): Boolean {
        val m = audioManager.mode
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION
    }

    /** Android 10+ silences (not stops) a recording when a higher-priority app takes the microphone. */
    private fun registerSilenceWatch() {
        if (Build.VERSION.SDK_INT < 29 || recordingCallback != null) return
        val cb = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
                val r = record ?: return
                val mine = configs?.firstOrNull { it.clientAudioSessionId == r.audioSessionId } ?: return
                val s = mine.isClientSilenced
                if (s == silenced) return
                silenced = s
                if (s) events.onWaiting("Another app or a call took the microphone. Waiting for it to be free.")
                else events.onListening(describe(r.routedDevice))
            }
        }
        try {
            audioManager.registerAudioRecordingCallback(cb, null)
            recordingCallback = cb
        } catch (e: Exception) { }
    }

    private fun unregisterSilenceWatch() {
        val cb = recordingCallback ?: return
        recordingCallback = null
        try { audioManager.unregisterAudioRecordingCallback(cb) } catch (e: Exception) { }
    }

    private fun describe(d: AudioDeviceInfo?): String = "Microphone: " + when (d?.type) {
        null -> "active"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "built-in"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth headset"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired headset"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "other (type ${d?.type})"
    }
}
