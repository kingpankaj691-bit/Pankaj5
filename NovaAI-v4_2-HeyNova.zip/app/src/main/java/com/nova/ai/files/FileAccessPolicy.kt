package com.nova.ai.files

/** What a file task needs from Android. */
enum class FileNeed { IMAGES, VIDEOS, AUDIO, DOCUMENTS, ANY_PATH, WRITE }

/** What the user can do about a missing permission (the UI turns this into a button that opens the right Android page). */
enum class FixAction { NONE, OPEN_ALL_FILES_SETTINGS, REQUEST_MEDIA_PERMISSION, PICK_FOLDER, REQUEST_WRITE_PERMISSION }

sealed class Access {
    data class Granted(val via: String, val partial: Boolean = false) : Access()
    data class Denied(val reason: String, val fix: FixAction) : Access()
}

/** One honest row for a permission dashboard. [ok] null = not applicable / not offered. */
data class StatusLine(val label: String, val ok: Boolean?, val detail: String, val fix: FixAction = FixAction.NONE)

/**
 * Decides, from the REAL permission state, whether a file task can work, and if not, says exactly which permission is missing.
 * Replaces "files can't be accessed" with a specific reason and fix. Pure Kotlin (unit-tested).
 */
object FileAccessPolicy {
    private fun t(h: Boolean, hi: String, en: String) = if (h) hi else en

    private fun allFilesFix(s: FileAccessState) = if (s.allFilesAvailable) FixAction.OPEN_ALL_FILES_SETTINGS else FixAction.PICK_FOLDER

    fun decide(s: FileAccessState, need: FileNeed, hinglish: Boolean = false): Access {
        val h = hinglish
        return when (need) {
            FileNeed.IMAGES -> media(s, s.images, "photos", "photos", true, h)
            FileNeed.VIDEOS -> media(s, s.videos, "videos", "videos", true, h)
            FileNeed.AUDIO -> media(s, s.audio, "music and audio", "music and audio", false, h)
            FileNeed.DOCUMENTS -> when {
                s.sdk >= 30 && s.allFilesGranted -> Access.Granted("All files access")
                s.sdk <= 28 && s.legacyRead -> Access.Granted("storage permission")
                s.allFilesAvailable -> Access.Denied(t(h,
                    "Documents, PDF aur doosri files dhundhne ke liye \"All files access\" off hai. Use on karo, ya koi folder chuno.",
                    "\"All files access\" is off, and documents, PDFs and other non-media files are only visible with it. Turn it on, or pick a folder."), FixAction.OPEN_ALL_FILES_SETTINGS)
                else -> Access.Denied(t(h,
                    "Is Android version par documents sirf tumhare chune hue folder me dikh sakte hain. Folder chuno.",
                    "On this Android version documents are only visible inside a folder you pick. Pick a folder."), FixAction.PICK_FOLDER)
            }
            FileNeed.ANY_PATH -> if (s.pathAccess) Access.Granted(if (s.sdk >= 30) "All files access" else "storage permission")
                else Access.Denied(t(h, "Folders ko path se kholne ke liye \"All files access\" chahiye. Ya folder chuno.", "Browsing folders by path needs \"All files access\". Or pick a folder."), allFilesFix(s))
            FileNeed.WRITE -> when {
                s.canWrite -> Access.Granted(if (s.sdk >= 30) "All files access" else "storage permission")
                s.shizukuReady -> Access.Granted("Shizuku (copy, move, delete and new folder only; rename and zip need All files access)", partial = true)
                s.sdk <= 28 -> Access.Denied(t(h, "Files badalne ke liye storage ki write permission chahiye.", "Changing files needs the storage write permission."), FixAction.REQUEST_WRITE_PERMISSION)
                s.allFilesAvailable -> Access.Denied(t(h, "Files badalne ke liye \"All files access\" off hai. Use on karo.", "Changing files needs \"All files access\", which is off. Turn it on."), FixAction.OPEN_ALL_FILES_SETTINGS)
                else -> Access.Denied(t(h, "Files sirf tumhare chune hue folder ke andar badal sakti hoon. Folder chuno.", "I can only change files inside a folder you pick. Pick a folder."), FixAction.PICK_FOLDER)
            }
        }
    }

    private fun media(s: FileAccessState, granted: Boolean, what: String, whatHi: String, selectedCounts: Boolean, h: Boolean): Access = when {
        s.sdk >= 30 && s.allFilesGranted -> Access.Granted("All files access")
        granted -> Access.Granted("$what permission")
        selectedCounts && s.selectedOnly -> Access.Granted("only the $what you selected", partial = true)
        else -> Access.Denied(t(h, "$whatHi ki permission off hai. Permissions me allow karo.", "The $what permission is off. Allow it in permissions."), FixAction.REQUEST_MEDIA_PERMISSION)
    }

    /** MediaStore mime patterns → what Android must allow. No filter at all means every kind of file. */
    fun needsFor(mimes: List<String>): Set<FileNeed> {
        if (mimes.isEmpty()) return setOf(FileNeed.IMAGES, FileNeed.VIDEOS, FileNeed.AUDIO, FileNeed.DOCUMENTS)
        return mimes.map {
            val m = it.lowercase()
            when {
                m.startsWith("image/") -> FileNeed.IMAGES
                m.startsWith("video/") -> FileNeed.VIDEOS
                m.startsWith("audio/") -> FileNeed.AUDIO
                else -> FileNeed.DOCUMENTS
            }
        }.toSet()
    }

    /**
     * Null when a search can run (at least partly); otherwise the reason none of it can. If only some kinds are allowed the
     * search still runs and simply returns what Android lets Nova see.
     */
    fun searchProblem(s: FileAccessState, mimes: List<String>, hinglish: Boolean = false): String? {
        val results = needsFor(mimes).map { decide(s, it, hinglish) }
        if (results.any { it is Access.Granted }) return null
        return (results.firstOrNull { it is Access.Denied } as? Access.Denied)?.reason
    }

    /** Every file-related permission as its own line, from the real state. Nothing is reported granted unless Android says so. */
    fun report(s: FileAccessState): List<StatusLine> = listOf(
        StatusLine("All files access", if (s.allFilesAvailable) s.allFilesGranted else null,
            if (!s.allFilesAvailable) "Not offered in this build / Android version" else if (s.allFilesGranted) "Granted" else "Not granted",
            if (s.allFilesAvailable && !s.allFilesGranted) FixAction.OPEN_ALL_FILES_SETTINGS else FixAction.NONE),
        StatusLine("Photos", s.images || s.selectedOnly, if (s.images) "Granted" else if (s.selectedOnly) "Only the photos you selected" else "Not granted",
            if (!s.images) FixAction.REQUEST_MEDIA_PERMISSION else FixAction.NONE),
        StatusLine("Videos", s.videos || s.selectedOnly, if (s.videos) "Granted" else if (s.selectedOnly) "Only the videos you selected" else "Not granted",
            if (!s.videos) FixAction.REQUEST_MEDIA_PERMISSION else FixAction.NONE),
        StatusLine("Music and audio", s.audio, if (s.audio) "Granted" else "Not granted", if (!s.audio) FixAction.REQUEST_MEDIA_PERMISSION else FixAction.NONE),
        StatusLine("Browse folders by path", s.pathAccess, if (s.pathAccess) "Yes" else "No", if (!s.pathAccess) FixAction.OPEN_ALL_FILES_SETTINGS.takeIf { s.allFilesAvailable } ?: FixAction.PICK_FOLDER else FixAction.NONE),
        StatusLine("Change files by path", s.canWrite, if (s.canWrite) "Yes" else "No", if (!s.canWrite) FixAction.OPEN_ALL_FILES_SETTINGS.takeIf { s.allFilesAvailable } ?: FixAction.PICK_FOLDER else FixAction.NONE),
        StatusLine("Chosen folders (SAF)", s.safFolders > 0, if (s.safFolders > 0) "${s.safFolders} folder(s)" else "None yet", if (s.safFolders == 0) FixAction.PICK_FOLDER else FixAction.NONE),
        StatusLine("Shizuku file helper", s.shizukuReady, if (s.shizukuReady) "Ready" else "Not connected")
    )
}
