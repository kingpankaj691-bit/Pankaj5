package com.nova.ai.memory

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.nova.ai.core.MemoryManager
import com.nova.ai.security.Prefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Local rules engine that decides what is worth remembering (importance, usefulness, sensitivity, expiry, context).
 * Nothing is sent to any server for classification. Sensitive text is never stored.
 */
class MemoryEngine(ctx: Context, private val prefs: Prefs, val db: MemoryDb = MemoryDb.get(ctx)) : MemoryManager {
    var rev by mutableIntStateOf(0)
        private set
    private var lastSavedId = -1L

    private val sensitive = listOf(
        Regex("(?i)\\b(password|passcode|passwd|pin|otp|cvv|cvc|ssn|aadhaar|aadhar|api key|apikey|secret key|token)\\b"),
        Regex("\\b\\d{13,19}\\b"), Regex("\\b\\d{4}[ -]\\d{4}[ -]\\d{4}\\b"),
        Regex("AIza[0-9A-Za-z_\\-]{20,}"), Regex("sk-[A-Za-z0-9]{20,}")
    )
    private val temporary = Regex("(?i)\\b(today|tonight|tomorrow|this (morning|evening|afternoon|week)|right now|abhi|aaj|kal)\\b")
    private val notWorth = Regex("(?i)^(what|who|when|where|why|how|kya|kaun|kab|kahan|kyun|kaise|open|call|play|set|start|stop|turn|show|scan|tell|can you|could you|please|hey|hi|hello|thanks|thank you|ok|okay)\\b")
    private val patterns: List<Triple<MemCategory, Regex, String>> = listOf(
        Triple(MemCategory.COMMAND_PREFERENCE, Regex("(?i)\\b(when i say|whenever i say|if i say)\\b"), "It sounded like a rule for how you want me to respond to a command."),
        Triple(MemCategory.PERSONALITY_PREFERENCE, Regex("(?i)\\b(talk like|be more|speak in|reply in|respond in|use .* mode)\\b"), "It sounded like a preference for my personality or style."),
        Triple(MemCategory.DEVICE_PREFERENCE, Regex("(?i)\\b(flashlight|volume|brightness|bluetooth|wifi|wi-fi|battery)\\b.*\\b(always|prefer|usually|default)\\b"), "It sounded like a lasting preference about your phone settings."),
        Triple(MemCategory.LONG_TERM_GOAL, Regex("(?i)\\b(my goal|i want to (learn|become|build|start)|i'?m (learning|preparing|building)|i am (learning|preparing|building)|long[- ]term)\\b"), "It sounded like a long-term goal of yours."),
        Triple(MemCategory.ROUTINE, Regex("(?i)\\b(every (day|morning|night|evening|week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|each (monday|tuesday|wednesday|thursday|friday|saturday|sunday)|(mondays|tuesdays|wednesdays|thursdays|fridays|saturdays|sundays)|daily|i usually|roz|har (somvar|mangalvar|budhvar|guruvar|shukravar|shanivar|ravivar))\\b"), "It sounded like part of your routine."),
        Triple(MemCategory.IMPORTANT_FACT, Regex("(?i)\\b(my name is|mera naam|i am a|i'm a|i work|i study|i live|my birthday|my (mother|father|sister|brother|wife|husband|friend))\\b"), "It sounded like an important fact about you."),
        Triple(MemCategory.USER_PREFERENCE, Regex("(?i)\\b(i prefer|i like|i love|i hate|i don'?t like|call me|my favou?rite|please always|always (use|speak|talk|reply)|mujhe .* pasand)\\b"), "It sounded like a lasting preference, which helps me fit my answers to you.")
    )

    private fun hash(s: String) = s.lowercase().filter { it.isLetterOrDigit() }.hashCode().toString()
    private fun isSensitive(t: String) = sensitive.any { it.containsMatchIn(t) }
    fun redact(t: String): String = sensitive.fold(t) { acc, r -> r.replace(acc, "[redacted]") }

    private fun endOfDay(addDays: Int): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, addDays); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
    }.timeInMillis

    private fun tempExpiry(t: String): Long {
        val l = t.lowercase()
        return when {
            l.contains("tomorrow") || l.contains("kal") -> endOfDay(1)
            l.contains("this week") -> System.currentTimeMillis() + 7 * 86400000L
            l.contains("today") || l.contains("tonight") || l.contains("aaj") || l.contains("this ") -> endOfDay(0)
            else -> System.currentTimeMillis() + 86400000L
        }
    }

    /** Pure decision: importance, usefulness, sensitivity, user preference, expiration, context. */
    fun decide(text: String, explicit: Boolean): MemoryDecision {
        val t = text.trim()
        if (t.length < 4) return MemoryDecision(false, null, 0f, Confidence.LOW, 0, "Too short to be useful.", false)
        if (isSensitive(t)) return MemoryDecision(false, null, 0f, Confidence.LOW, 0, "It looked like private information (password, PIN, card, ID or key), so I didn't save it.", true)
        if (db.isBlocked(hash(t))) return MemoryDecision(false, null, 0f, Confidence.LOW, 0, "You told me to forget this earlier.", false)
        if (!explicit && (notWorth.containsMatchIn(t) || t.endsWith("?"))) return MemoryDecision(false, null, 0.05f, Confidence.LOW, 0, "A question or command isn't worth remembering.", false)
        if (temporary.containsMatchIn(t)) {
            return MemoryDecision(explicit || t.length > 12, MemCategory.TEMPORARY_CONTEXT, if (explicit) 0.6f else 0.45f,
                if (explicit) Confidence.HIGH else Confidence.MEDIUM, tempExpiry(t), "It's only useful for a short time, so I'll forget it automatically.", false)
        }
        for ((cat, re, why) in patterns) {
            if (re.containsMatchIn(t)) return MemoryDecision(true, cat, if (explicit) 0.9f else 0.7f, if (explicit) Confidence.HIGH else Confidence.MEDIUM, 0, why, false)
        }
        return if (explicit) MemoryDecision(true, MemCategory.IMPORTANT_FACT, 0.85f, Confidence.HIGH, 0, "You asked me to remember it.", false)
        else MemoryDecision(false, null, 0.2f, Confidence.LOW, 0, "Not clearly useful later, so it stays only in the current conversation.", false)
    }

    private fun save(text: String, d: MemoryDecision, explicit: Boolean): Long {
        val key = hash(text)
        val existing = db.memories().firstOrNull { hash(it.content) == key }
        val now = System.currentTimeMillis()
        if (existing != null) { db.touch(listOf(existing.id), now); return existing.id }
        val reason = (if (explicit) "You asked me to remember it. " else "") + d.reason
        val id = db.insertMemory(MemoryEntry(0, d.category ?: MemCategory.IMPORTANT_FACT, text.trim(), d.importance, d.confidence, now, now, d.expiresAt,
            if (explicit) "explicit request" else "conversation", explicit, false, reason.trim()))
        rev++
        return id
    }

    override fun remember(text: String?, previous: String?): String {
        if (!prefs.memoryEnabled) return "Memory is turned off in Settings."
        val src = (text?.takeIf { it.isNotBlank() } ?: previous)?.trim() ?: return "Tell me what to remember."
        val d = decide(src, true)
        if (d.sensitive) { db.addIgnored(d.reason, "Sensitive"); rev++; return "I won't save that. It looks like private information." }
        if (!d.save) return d.reason
        lastSavedId = save(src, d, true)
        return if (d.category == MemCategory.TEMPORARY_CONTEXT) "Okay. I'll keep that for a short while." else "Okay, I'll remember that."
    }

    /** For "remind me about X" with no time: keep it only as short-term context. */
    fun rememberTemporary(text: String): String {
        if (!prefs.memoryEnabled) return "Memory is turned off in Settings."
        if (isSensitive(text)) { db.addIgnored("It looked like private information, so I didn't save it.", "Sensitive"); rev++; return "I won't save that." }
        val now = System.currentTimeMillis()
        val exp = if (temporary.containsMatchIn(text)) tempExpiry(text) else endOfDay(1)
        lastSavedId = db.insertMemory(MemoryEntry(0, MemCategory.TEMPORARY_CONTEXT, text.trim(), 0.6f, Confidence.HIGH, now, now, exp, "reminder request", true, false,
            "You asked me to remind you, but gave no time, so I'm keeping it as temporary context that expires on its own."))
        rev++
        return "Okay."
    }

    override fun observe(text: String) {
        if (!prefs.memoryEnabled) return
        val low = text.lowercase().trim()
        if (low.startsWith("remember") || low.startsWith("forget") || low.startsWith("nova remember") || low.startsWith("nova forget")) return
        val d = decide(text, false)
        if (d.sensitive) { db.addIgnored(d.reason, "Sensitive information"); rev++; return }
        if (d.save && d.importance >= 0.6f && d.confidence != Confidence.LOW) lastSavedId = save(text, d, false)
    }

    fun isSensitiveText(t: String) = isSensitive(t)

    /** "Never remember similar information": blocks this text and removes matching memories. */
    override fun neverRemember(text: String?) {
        val t = text?.trim().orEmpty()
        if (t.isEmpty()) return
        db.block(hash(t))
        db.memories().filter { hash(it.content) == hash(t) }.forEach { db.deleteMemory(it.id) }
        rev++
    }

    override fun forgetLast(): String {
        if (lastSavedId < 0 || db.memory(lastSavedId) == null) return "I haven't saved anything recently."
        db.deleteMemory(lastSavedId); lastSavedId = -1; rev++
        return "Okay, forgotten."
    }

    override fun saved() = db.memories().filter { it.category != MemCategory.TEMPORARY_CONTEXT && it.category != MemCategory.CONVERSATION_CONTEXT }
    override fun recent() = db.memories().filter { it.lastUsedAt > it.createdAt }.sortedByDescending { it.lastUsedAt }.take(10)
    override fun temporary() = db.memories().filter { it.category == MemCategory.TEMPORARY_CONTEXT || it.category == MemCategory.CONVERSATION_CONTEXT }
    override fun ignored() = db.ignored()
    override fun update(id: Long, content: String) { if (!isSensitive(content)) { db.updateContent(id, content.trim()); rev++ } }
    override fun delete(id: Long) { db.deleteMemory(id); rev++ }
    override fun forget(id: Long) { db.memory(id)?.let { db.block(hash(it.content)) }; db.deleteMemory(id); rev++ }
    override fun pin(id: Long, pinned: Boolean) { db.setPinned(id, pinned); rev++ }
    override fun count() = db.countMemories()
    override fun clear() { db.clearMemories(); lastSavedId = -1; rev++ }
    override fun purgeExpired(): Int { val n = db.purge(System.currentTimeMillis(), prefs.memoryExpiryDays); if (n > 0) rev++; return n }

    /** Long-term memory and short-term context for the AI prompt. Low-confidence items are never presented as fact. */
    override fun promptContext(): String {
        if (!prefs.memoryEnabled) return ""
        val now = System.currentTimeMillis()
        val all = db.memories().filter { it.expiresAt == 0L || it.expiresAt > now }
        val long = all.filter { it.category != MemCategory.TEMPORARY_CONTEXT && it.category != MemCategory.CONVERSATION_CONTEXT && it.confidence != Confidence.LOW }
            .sortedWith(compareByDescending<MemoryEntry> { it.pinned }.thenByDescending { it.importance }.thenByDescending { it.lastUsedAt }).take(12)
        val short = all.filter { it.category == MemCategory.TEMPORARY_CONTEXT || it.category == MemCategory.CONVERSATION_CONTEXT }.take(6)
        db.touch((long + short).map { it.id }, now)
        val sb = StringBuilder()
        if (long.isNotEmpty()) sb.append("Long-term memory about the user:\n").append(long.joinToString("\n") { "- " + it.content + if (it.confidence == Confidence.MEDIUM) " (unconfirmed, don't treat as certain)" else "" })
        if (short.isNotEmpty()) { if (sb.isNotEmpty()) sb.append("\n"); sb.append("Short-term context:\n").append(short.joinToString("\n") { "- " + it.content }) }
        return sb.toString()
    }

    override fun summaryText(): String {
        val s = saved().take(8)
        return if (s.isEmpty()) "I haven't saved anything yet." else "I remember: " + s.joinToString("; ") { it.content }
    }

    fun why(e: MemoryEntry): String {
        val exp = if (e.expiresAt == 0L) "never (until you delete it)" else SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(e.expiresAt))
        return e.reason.ifBlank { "Saved from our conversation." } + "\n\nConfidence: ${e.confidence.name}. Importance: ${"%.2f".format(e.importance)}. Expires: $exp."
    }
}
