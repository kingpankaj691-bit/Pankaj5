package com.nova.ai.brain

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.nova.ai.media.Saf

/** Pure helpers: project version detection and natural-language file search over indexed records. */
object ProjectFiles {
    private val versionRe = Regex("[vV]?(\\d{1,3})[._](\\d{1,3})(?:[._](\\d{1,3}))?")
    private val skipDirs = setOf(".git", "build", "node_modules", ".gradle", ".idea", "__pycache__", ".cxx", "intermediates")
    val textExt = setOf("kt", "java", "xml", "md", "txt", "json", "py", "js", "ts", "html", "css", "gradle", "kts", "yml", "yaml", "properties", "toml", "c", "cpp", "h", "swift", "dart", "sh", "csv")

    fun skipDir(name: String) = name in skipDirs

    private fun tuple(m: MatchResult) = Triple(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].ifEmpty { "0" }.toInt())

    /** Highest version-looking number in file or folder names ("NovaAI-v3_8-complete.zip" gives 3.8), else "" . */
    fun latestVersion(names: List<String>): String {
        var best: Triple<Int, Int, Int>? = null; var label = ""
        for (n in names) for (m in versionRe.findAll(n)) {
            val t = tuple(m)
            if (t.first > 99) continue
            val b = best
            if (b == null || compareValues(t.first * 1_000_000 + t.second * 1_000 + t.third, b.first * 1_000_000 + b.second * 1_000 + b.third) > 0) { best = t; label = if (t.third != 0) "${t.first}.${t.second}.${t.third}" else "${t.first}.${t.second}" }
        }
        return label
    }

    /** Words worth searching for in a source or text file: class, object, fun, def, headings, and a Gradle versionName. */
    fun symbols(name: String, text: String): String {
        val out = LinkedHashSet<String>()
        val raw = ArrayList<String>()
        Regex("\\b(?:class|object|interface|fun|def|function|struct)\\s+([A-Za-z_][A-Za-z0-9_]{2,40})").findAll(text).take(120).forEach { raw.add(it.groupValues[1]) }
        raw.forEach { out.add(it.lowercase()); out.addAll(splitCamel(it)) }
        Regex("(?m)^#{1,3}\\s+(.{3,60})$").findAll(text).take(20).forEach { Txt.tokens(it.groupValues[1]).forEach { t -> out.add(t) } }
        Regex("versionName\\s*=?\\s*\"([^\"]+)\"").find(text)?.let { out.add("versionname=" + it.groupValues[1]) }
        Regex("\"version\"\\s*:\\s*\"([^\"]+)\"").find(text)?.let { out.add("version=" + it.groupValues[1]) }
        return out.take(200).joinToString(" ")
    }

    fun splitCamel(s: String): List<String> = s.replace(Regex("([a-z0-9])([A-Z])"), "$1 $2").lowercase().split(' ', '_').filter { it.length >= 3 }

    fun nameTokens(rec: FileRec): Set<String> = (Txt.tokens(rec.name.replace('.', ' ').replace('_', ' ').replace('-', ' ')) + splitCamel(rec.name.substringBeforeLast('.')) + Txt.tokens(rec.relPath.replace('/', ' '))).toSet()

    /** Ranked files for a spoken request. Only files that were really found in the index are returned; nothing is guessed. */
    fun search(files: List<FileRec>, query: String, limit: Int = 8): List<Pair<FileRec, Float>> {
        val q = Txt.expand(Txt.tokens(query))
        if (q.isEmpty()) return emptyList()
        return files.filter { !it.stale }.map { f ->
            val nt = nameTokens(f); val st = f.tokens.split(' ').toSet()
            var s = 0f
            for (t in q) { if (t in nt) s += 2f else if (nt.any { it.length >= 4 && t.length >= 4 && (it.startsWith(t) || t.startsWith(it)) }) s += 1f; if (t in st) s += 1.5f }
            f to s
        }.filter { it.second >= 2f }.sortedByDescending { it.second }.take(limit)
    }

    fun structure(files: List<FileRec>): String {
        val top = files.groupingBy { it.relPath.substringBefore('/', "(root)") }.eachCount().entries.sortedByDescending { it.value }.take(8)
        return top.joinToString("; ") { "${it.key} (${it.value} files)" }
    }
}

data class IndexReport(val added: Int, val changed: Int, val removed: Int, val total: Int, val truncated: Boolean, val error: String = "", val skipped: Int = 0)

/** A failed or partial folder read must never delete what was indexed before. */
object IndexSafety {
    /** Old records that sit under folders which could not be read this time: they are kept instead of being dropped. */
    fun keepUnreadable(old: Collection<FileRec>, skippedDirs: List<String>): List<FileRec> {
        if (skippedDirs.isEmpty()) return emptyList()
        return old.filter { r -> skippedDirs.any { d -> d.isEmpty() || r.relPath.startsWith("$d/") } }
    }
}

/**
 * Indexes a folder the user picked with the Android folder picker (Storage Access Framework). Only that folder is read, only
 * file names, sizes, dates and a few searchable words are stored, and file contents are read again from the phone when needed.
 * A file that changed is re-read; a file that disappeared is dropped, so Nova never claims a file exists that was not found.
 */
object FileIndexer {
    private const val MAX_FILES = 6000
    private const val MAX_DEPTH = 10
    private const val MAX_READ = 64 * 1024
    private const val MAX_TEXT_SIZE = 512 * 1024L

    private val COLS = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED)

    fun index(ctx: Context, store: BrainStore, project: ProjectRec, now: Long = System.currentTimeMillis()): IndexReport {
        val root = try { Uri.parse(project.rootUri) } catch (e: Exception) { return IndexReport(0, 0, 0, 0, false, "Invalid folder") }
        val old = store.files(project.id).associateBy { it.uri }
        val found = ArrayList<FileRec>()
        var added = 0; var changed = 0; var truncated = false
        val resolver = ctx.contentResolver
        val skipped = ArrayList<String>()          // folders Android would not let us read this time
        try {
            val rootId = DocumentsContract.getTreeDocumentId(root)
            val queue = ArrayDeque<Triple<String, String, Int>>()      // documentId, relative path, depth
            queue.add(Triple(rootId, "", 0))
            while (queue.isNotEmpty() && !truncated) {
                val (docId, rel, depth) = queue.removeFirst()
                val children = DocumentsContract.buildChildDocumentsUriUsingTree(root, docId)
                val cursor = resolver.query(children, COLS, null, null, null)
                if (cursor == null) {
                    // A null cursor is Android refusing, not an empty folder. Never treat it as "no files".
                    if (docId == rootId) return IndexReport(0, 0, 0, old.size, false, rootProblem(ctx, root))
                    skipped.add(rel); continue
                }
                cursor.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0); val name = c.getString(1) ?: continue; val mime = c.getString(2) ?: ""
                        val size = if (c.isNull(3)) 0L else c.getLong(3); val mod = if (c.isNull(4)) 0L else c.getLong(4)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (!ProjectFiles.skipDir(name) && depth < MAX_DEPTH) queue.add(Triple(id, if (rel.isEmpty()) name else "$rel/$name", depth + 1))
                            continue
                        }
                        if (found.size >= MAX_FILES) { truncated = true; break }
                        val uri = DocumentsContract.buildDocumentUriUsingTree(root, id).toString()
                        val prev = old[uri]
                        val unchanged = prev != null && prev.size == size && prev.modified == mod && !prev.stale
                        val tokens = if (unchanged) prev!!.tokens else readTokens(ctx, Uri.parse(uri), name, size)
                        if (prev == null) added++ else if (!unchanged) changed++
                        found.add(FileRec(0, project.id, uri, name, if (rel.isEmpty()) name else "$rel/$name", mime, size, mod, now, tokens, false))
                    }
                }
            }
        } catch (e: Exception) { return IndexReport(0, 0, 0, old.size, false, rootProblem(ctx, root, e.javaClass.simpleName)) }
        // Folders that could not be read keep their old records, so a permission hiccup cannot wipe the index.
        val keep = IndexSafety.keepUnreadable(old.values, skipped).filter { k -> found.none { it.uri == k.uri } }
        found.addAll(keep)
        val removed = old.keys.count { u -> found.none { it.uri == u } }
        store.tx {
            store.replaceFiles(project.id, found)
            val version = ProjectFiles.latestVersion(found.map { it.name } + found.map { it.tokens.split(' ').filter { t -> t.startsWith("versionname=") || t.startsWith("version=") }.joinToString(" ") })
            store.saveProject(project.copy(version = version.ifBlank { project.version }, updatedAt = now, lastIndexedAt = now))
        }
        return IndexReport(added, changed, removed, found.size, truncated, skipped = skipped.size)
    }

    /** Says WHY the folder can't be read: permission gone, or something else. The old index is left untouched. */
    private fun rootProblem(ctx: Context, root: Uri, cause: String = ""): String =
        if (!Saf.hasGrant(ctx, root)) "Nova no longer has permission for this folder (it was removed or Android reset it). Pick the folder again. The old index was kept."
        else "Android wouldn't let Nova read this folder${if (cause.isNotBlank()) " ($cause)" else ""}. The old index was kept."

    private fun readTokens(ctx: Context, uri: Uri, name: String, size: Long): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in ProjectFiles.textExt || size > MAX_TEXT_SIZE) return ""
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                val buf = ByteArray(MAX_READ); val n = s.read(buf).coerceAtLeast(0)
                ProjectFiles.symbols(name, String(buf, 0, n, Charsets.UTF_8))
            } ?: ""
        } catch (e: Exception) { "" }
    }

    /** Confirms the file is still there and unchanged, then returns up to [max] characters. Returns null (never an invented text) otherwise. */
    fun readText(ctx: Context, store: BrainStore, rec: FileRec, max: Int = 4000): String? {
        val uri = Uri.parse(rec.uri)
        return try {
            var size = -1L; var mod = -1L
            ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
                if (c.moveToFirst()) { size = if (c.isNull(0)) 0L else c.getLong(0); mod = if (c.isNull(1)) 0L else c.getLong(1) }
            }
            if (size < 0) return null
            if (size != rec.size || mod != rec.modified) {
                // changed since indexing: the stored words are stale
                val project = store.projects().firstOrNull { it.id == rec.projectId }
                if (project != null) index(ctx, store, project)
            }
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                val buf = ByteArray(max * 3); val n = s.read(buf).coerceAtLeast(0)
                String(buf, 0, n, Charsets.UTF_8).take(max)
            }
        } catch (e: Exception) { null }
    }
}
