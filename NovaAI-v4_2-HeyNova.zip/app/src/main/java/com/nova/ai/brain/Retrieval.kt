package com.nova.ai.brain

import kotlin.math.ln

data class Scored(val item: BrainItem, val score: Float)

data class RetrievalQuery(
    val text: String,
    val categories: Set<BrainCategory> = emptySet(),
    val project: String? = null,
    val from: Long = 0L,
    val to: Long = Long.MAX_VALUE,
    val topicId: Long = 0L
)

/**
 * Finds the few memories that matter for a question: keyword match (with Hindi/Hinglish/English synonyms), a local semantic
 * vector, and importance and recency ranking, with optional topic, project, category and time filters.
 * Unrelated memories are not returned at all, so one conversation does not leak into another.
 */
object Retrieval {
    private const val MIN_RELEVANCE = 0.22f

    private fun docText(i: BrainItem) = i.title + " " + i.content + " " + i.project

    private fun sameProject(name: String, i: BrainItem): Boolean {
        val p = Txt.tokenSet(name)
        return p.isNotEmpty() && p.all { it in Txt.tokenSet(docText(i)) }
    }

    fun search(items: List<BrainItem>, q: RetrievalQuery, now: Long, limit: Int = 8): List<Scored> {
        val qTok = Txt.tokens(q.text)
        val qExp = Txt.expand(qTok)
        val pool = items.filter { i ->
            (q.categories.isEmpty() || i.category in q.categories) &&
                (q.project == null || i.project.equals(q.project, true) || sameProject(q.project, i)) &&
                (i.updatedAt in q.from until q.to || i.createdAt in q.from until q.to) &&
                (q.topicId == 0L || i.topicId == q.topicId)
        }
        if (pool.isEmpty()) return emptyList()
        val docs = pool.map { Txt.tokenSet(docText(it)) }
        val n = pool.size.toFloat()
        fun idf(t: String): Float = ln(1f + n / (1f + docs.count { t in it })) + 0.5f
        val qVec = Txt.embed(q.text)
        val totalIdf = qTok.sumOf { idf(it).toDouble() }.toFloat().coerceAtLeast(0.001f)

        val out = ArrayList<Scored>()
        for ((idx, item) in pool.withIndex()) {
            val d = docs[idx]
            var hit = 0f
            for (t in qTok) {
                val direct = t in d || d.any { it.length >= 4 && t.length >= 4 && (it.startsWith(t) || t.startsWith(it)) }
                val syn = !direct && Txt.expand(listOf(t)).any { it in d }
                if (direct) hit += idf(t) else if (syn) hit += idf(t) * 0.6f
            }
            val kw = if (qTok.isEmpty()) 0f else (hit / totalIdf).coerceIn(0f, 1f)
            val sem = Txt.cosine(qVec, Txt.embed(docText(item))).coerceIn(0f, 1f)
            val onlyFilters = qTok.isEmpty()
            val relevance = if (onlyFilters) 0.5f else 0.6f * kw + 0.4f * sem
            if (!onlyFilters && kw == 0f && sem < 0.45f) continue
            if (relevance < MIN_RELEVANCE) continue
            val score = 0.70f * relevance + 0.15f * item.importance.coerceIn(0f, 1f) + 0.10f * Txt.recency(item.updatedAt, now) + if (item.pinned) 0.05f else 0f
            out.add(Scored(item, score))
        }
        return out.sortedByDescending { it.score }.take(limit)
    }

    /**
     * When the user asked for one thing ("mere editing project ka naam kya tha?") and two different memories fit almost equally well,
     * returns those candidates so Nova can ask which one is meant. Near-duplicates are not ambiguous.
     */
    fun ambiguous(results: List<Scored>): List<Scored>? {
        if (results.size < 2) return null
        val top = results[0]
        val close = results.filter { it.score >= top.score * 0.88f && it.score >= 0.35f }
        if (close.size < 2) return null
        val distinct = ArrayList<Scored>()
        for (r in close) if (distinct.none { Txt.similar(it.item.content, r.item.content) }) distinct.add(r)
        return if (distinct.size >= 2) distinct.take(3) else null
    }
}
