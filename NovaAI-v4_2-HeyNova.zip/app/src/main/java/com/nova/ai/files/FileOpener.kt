package com.nova.ai.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/** Opens a file in the app Android picks for its type. Opening only: nothing is changed, copied or uploaded. */
object FileOpener {
    fun mimeFor(item: FileItem): String {
        if (item.mime.isNotBlank() && item.mime != "application/octet-stream") return item.mime
        val fromAndroid = MimeTypeMap.getSingleton().getMimeTypeFromExtension(item.ext)
        return fromAndroid ?: FileTypes.mimeOf(item.name)
    }

    /** MediaStore items already carry a content:// address. Folder-browsed files go through FileProvider, and only inside the storage volumes. */
    fun uriFor(ctx: Context, item: FileItem): Uri? {
        item.uri?.let { return Uri.parse(it) }
        if (item.path.isBlank()) return null
        val canonical = try { File(item.path).canonicalPath } catch (e: Exception) { return null }
        if (!PathRules.isWithinAny(StorageVolumes.roots(ctx), canonical) || PathRules.blockedReason(canonical) != null) return null
        return try { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(canonical)) } catch (e: Exception) { null }
    }

    fun open(ctx: Context, item: FileItem): String {
        if (item.isDir) return "That's a folder."
        if (item.kind == FileKind.APK) {
            if (!com.nova.ai.control.AppInstaller.canInstallUnknown(ctx)) {
                com.nova.ai.control.AppInstaller.openUnknownSourcesSettings(ctx)
                FileHistory.record(ctx, FileOp.OPEN, item.name, "", FileStatus.FAILED, "install source not allowed")
                return "Android hasn't allowed Nova to install apps yet. I opened that page: turn on \"Allow from this source\" for Nova AI, then open the APK again."
            }
            if (item.path.isNotBlank()) com.nova.ai.control.AppInstaller.readApk(ctx, item.path)?.let { info ->
                (com.nova.ai.control.AppGuard.forInstall(info.pkg, info.label, ctx.packageName) as? com.nova.ai.control.AppVerdict.Refused)?.let { r ->
                    FileHistory.record(ctx, FileOp.OPEN, item.name, "", FileStatus.FAILED, "protected package"); return r.reason
                }
            }
        }
        val uri = uriFor(ctx, item)
        if (uri == null) { FileHistory.record(ctx, FileOp.OPEN, item.name, "", FileStatus.FAILED, "no readable address"); return "I couldn't get access to ${item.name}." }
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeFor(item)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            FileHistory.record(ctx, FileOp.OPEN, item.name, "", FileStatus.OK, "")
            if (item.kind == FileKind.APK) "Opening ${item.name} in Android's installer. You confirm there; I can't tell whether it gets installed." else "Opening ${item.name}."
        } catch (e: Exception) {
            FileHistory.record(ctx, FileOp.OPEN, item.name, "", FileStatus.FAILED, "no app")
            "No app on this phone can open ${item.name}."
        }
    }
}
