package com.nova.ai.live

/** The seven states the user sees. They are derived from the real engine state, never set by the UI on its own. */
enum class LiveStatus(val label: String) {
    READY("READY"), CONNECTING("CONNECTING"), LISTENING("LISTENING"), THINKING("THINKING"),
    SPEAKING("SPEAKING"), RECONNECTING("RECONNECTING"), ERROR("ERROR")
}

/** Pure mapping (no Android types) from the engine/service flags to what the Home screen shows. Unit-tested. */
object LiveStatusMapper {
    /**
     * @param serviceRunning the Background Voice foreground service is alive
     * @param paused         the user paused it (microphone released)
     * @param engineActive   the two-way Gemini Live engine owns the session ([LiveSession.isActive])
     * @param state          [LiveSession.state]
     * @param reconnecting   [LiveSession.reconnecting]
     * @param micOpen        AudioRecord is open (VoiceState.status == Listening)
     * @param legacy         Nova's older status text ("Thinking", "Speaking", ...) used only when another speech mode is selected
     */
    fun map(serviceRunning: Boolean, paused: Boolean, engineActive: Boolean, state: LiveOrbState,
            reconnecting: Boolean, micOpen: Boolean, legacy: String = ""): LiveStatus {
        if (engineActive && state == LiveOrbState.ERROR) return LiveStatus.ERROR
        if (!serviceRunning || paused) return LiveStatus.READY
        if (!engineActive) return when {
            legacy.equals("Speaking", true) -> LiveStatus.SPEAKING
            legacy.equals("Thinking", true) || legacy.equals("Processing", true) -> LiveStatus.THINKING
            micOpen -> LiveStatus.LISTENING
            else -> LiveStatus.CONNECTING
        }
        if (reconnecting) return LiveStatus.RECONNECTING
        return when (state) {
            LiveOrbState.CONNECTING -> LiveStatus.CONNECTING
            LiveOrbState.LISTENING -> LiveStatus.LISTENING
            LiveOrbState.THINKING -> LiveStatus.THINKING
            LiveOrbState.SPEAKING -> LiveStatus.SPEAKING
            LiveOrbState.ERROR -> LiveStatus.ERROR
            LiveOrbState.IDLE -> LiveStatus.CONNECTING
        }
    }
}

/** Controlled retry: linear back-off, a hard limit, and no retry at all for errors that retrying cannot fix. */
class ReconnectPolicy(private val maxAttempts: Int = 5, private val baseDelayMs: Long = 1200L, private val maxDelayMs: Long = 6000L) {
    var attempts = 0
        private set

    /** Returns the delay before the next attempt, or null when the limit is reached. */
    fun next(): Long? {
        if (attempts >= maxAttempts) return null
        attempts++
        return (baseDelayMs * attempts).coerceAtMost(maxDelayMs)
    }

    fun reset() { attempts = 0 }
}

/** Turns a WebSocket close code / reason / HTTP code into a message the user can act on. */
object LiveErrors {
    class Result(val message: String, val fatal: Boolean)

    fun classify(httpCode: Int?, closeCode: Int?, reason: String): Result {
        val r = reason.lowercase()
        return when {
            // Must come first: this message also contains "not supported", which used to be reported as "model not available".
            com.nova.ai.ai.model.LiveModalityPolicy.isModalityRejection(closeCode, reason) ->
                Result("This model does not support the response type Nova requested on the Live API (error ${closeCode ?: 1007}). " +
                    "Nova will not retry the same setup." + (if (reason.isNotBlank()) " Server: " + reason.take(140) else ""), true)
            httpCode == 401 || httpCode == 403 || "api key" in r || "api_key" in r || "permission" in r || "unauthenticated" in r ->
                Result("Gemini rejected the API key. Check it in Settings.", true)
            httpCode == 404 || "not found" in r || "not supported" in r || "is not found for api version" in r ->
                Result("This model is not available on the Live API for your key. Choose another model in Settings → Gemini → Model.", true)
            httpCode == 429 || "quota" in r || "exhausted" in r || "rate limit" in r ->
                Result("Gemini quota reached. Try again later.", true)
            httpCode == 400 || closeCode == 1007 ->
                Result("Gemini rejected the voice setup" + (if (reason.isNotBlank()) ": " + reason.take(120) else "."), true)
            else -> Result("Connection closed" + (if (closeCode != null) " ($closeCode)" else "") + (if (reason.isNotBlank()) ": " + reason.take(100) else ""), false)
        }
    }
}
