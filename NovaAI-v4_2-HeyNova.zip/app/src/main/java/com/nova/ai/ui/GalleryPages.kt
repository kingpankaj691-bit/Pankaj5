package com.nova.ai.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.media.AllFiles
import com.nova.ai.media.ActionStart
import com.nova.ai.media.DocEntry
import com.nova.ai.media.GrantLevel
import com.nova.ai.media.MediaAccess
import com.nova.ai.media.MediaAccessLevel
import com.nova.ai.media.MediaActions
import com.nova.ai.media.MediaEntry
import com.nova.ai.media.MediaKind
import com.nova.ai.media.MediaRepository
import com.nova.ai.media.PendingApproval
import com.nova.ai.media.PhotoPrivacy
import com.nova.ai.media.PhotoRef
import com.nova.ai.media.Saf
import com.nova.ai.media.UploadLedger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Photos chosen with the system Photo Picker this session. They are temporary grants; Nova can open/analyze/copy them but not delete them. */
object PickedMedia { val items = mutableStateListOf<PhotoRef>() }

private fun mb(b: Long) = if (b >= 1048576) String.format("%.1f MB", b / 1048576.0) else "${b / 1024} KB"

// ───────────────────────── Settings → Photos & Videos ─────────────────────────
@Composable
internal fun PhotosPage(vm: NovaViewModel, openGallery: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val level = remember(tick, refresh) { MediaAccess.level(ctx) }
    var counts by remember { mutableStateOf("") }
    LaunchedEffect(tick, refresh) { counts = withContext(Dispatchers.IO) { "${MediaRepository.count(ctx, MediaKind.IMAGES)} photos and ${MediaRepository.count(ctx, MediaKind.VIDEOS)} videos" } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(PhotoPrivacy.MAX_PHOTOS)) { uris ->
        uris.forEach { u -> if (PickedMedia.items.none { it.uri == u }) PickedMedia.items.add(PhotoRef(u, u.lastPathSegment ?: "picked item", (ctx.contentResolver.getType(u) ?: "").startsWith("video/"))) }
        if (uris.isNotEmpty()) openGallery()
    }
    var share by remember { mutableStateOf(vm.prefs.photosToGemini) }
    val ledger = remember(refresh) { UploadLedger.list(ctx) }
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }

    GlassSettingSection("What Nova can see right now") {
        GlassListItem("Access", MediaAccess.describe(level))
        GlassListItem("Visible to Nova", if (level == MediaAccessLevel.NONE) "Nothing" else counts.ifBlank { "Counting…" })
        if (level == MediaAccessLevel.SELECTED_ONLY) GText("You chose “selected photos”. Nova only knows about those; other photos on your phone are invisible to it.", size = 12.sp, color = g.subtext)
        if (level == MediaAccessLevel.NONE) GText("Nova has no permission to your photos or videos. You can still use the Photo Picker below without giving any permission.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Permission") {
        GText("Why: to show your photos and videos in Nova's Gallery with thumbnails, and let you open, copy, organize or delete them. Nothing leaves your phone unless you press Analyze and confirm.", size = 12.sp, color = g.subtext)
        val ask = MediaAccess.permissionsToRequest(Build.VERSION.SDK_INT).toTypedArray()
        if (level == MediaAccessLevel.NONE || level == MediaAccessLevel.IMAGES_ONLY || level == MediaAccessLevel.VIDEOS_ONLY)
            GlassButton("Allow photos & videos", { perm.launch(ask) }, primary = true)
        if (Build.VERSION.SDK_INT >= 34 && level == MediaAccessLevel.SELECTED_ONLY) GlassButton("Choose more photos to share", { perm.launch(ask) }, primary = true)
        GlassButton("Open Nova's permission settings", { try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } })
        GlassButton("Pick photos with the Photo Picker (no permission needed)", { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) })
        GlassButton("Open Gallery", openGallery, primary = level != MediaAccessLevel.NONE)
    }
    GlassSettingSection("Gemini and your photos") {
        ToggleRow("Allow Gemini photo analysis", "OFF by default. Even when ON, Nova asks every single time and sends only the photos you selected, once.", share) { share = it; vm.prefs.photosToGemini = it }
        GText("What is sent: a resized copy of each chosen photo (videos: one middle frame) without location or other metadata, plus your question. Never sent: your gallery, file names, albums, or anything you didn't select. Local-only mode blocks it completely.", size = 12.sp, color = g.subtext)
        if (ledger.isEmpty()) GText("Nothing has ever been sent.", size = 12.sp, color = g.accent)
        else {
            GText("Upload log (this phone only):", size = 12.sp, color = g.subtext)
            ledger.take(6).forEach { GText("${fmt.format(Date(it.first))} · ${it.second} ${if (it.third) "item(s) incl. video frame" else "photo(s)"}", size = 12.sp) }
            GlassButton("Clear upload log", { UploadLedger.clear(ctx); refresh++ })
        }
    }
}

// ───────────────────────── Gallery ─────────────────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun GalleryScreen(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val scope = rememberCoroutineScope()
    val mediaList = remember { mutableStateListOf<MediaEntry>() }
    var albums by remember { mutableStateOf(listOf<com.nova.ai.media.Album>()) }
    var kind by remember { mutableStateOf(MediaKind.ALL) }
    var album by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf(setOf<Uri>()) }
    var endReached by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val level = remember(tick, reload) { MediaAccess.level(ctx) }

    // dialogs
    var analyzeRefs by remember { mutableStateOf<List<PhotoRef>?>(null) }
    var question by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<Boolean?>(null) }        // false = trash, true = permanent
    var albumDialog by remember { mutableStateOf<String?>(null) }           // "copy" | "move"
    var albumName by remember { mutableStateOf("Nova") }
    var pending by remember { mutableStateOf<PendingApproval?>(null) }
    var pendingItems by remember { mutableStateOf(listOf<MediaEntry>()) }
    var saveCopyOf by remember { mutableStateOf<MediaEntry?>(null) }

    fun page(offset: Int) {
        if (loading && offset != 0) return
        loading = true
        scope.launch {
            val got = withContext(Dispatchers.IO) { MediaRepository.list(ctx, kind, album, offset, 90) }
            if (offset == 0) mediaList.clear()
            mediaList.addAll(got); endReached = got.size < 90; loading = false
        }
    }
    LaunchedEffect(kind, album, tick, reload) { selected = emptySet(); page(0); albums = withContext(Dispatchers.IO) { MediaRepository.albums(ctx) } }

    val approval = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val p = pending; pending = null
        msg = if (p == null) "" else if (r.resultCode == Activity.RESULT_OK) MediaActions.finish(ctx, p, pendingItems) else "You didn't approve it, so nothing was changed."
        reload++
    }
    fun start(a: ActionStart, affected: List<MediaEntry>) {
        when (a) {
            is ActionStart.Done -> { msg = a.message; reload++ }
            is ActionStart.Unsupported -> msg = a.message
            is ActionStart.NeedsApproval -> { pending = a.pending; pendingItems = affected; approval.launch(IntentSenderRequest.Builder(a.pending.sender).build()) }
        }
    }
    val saveCopy = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { dest ->
        val e = saveCopyOf; saveCopyOf = null
        if (dest != null && e != null) scope.launch { msg = withContext(Dispatchers.IO) { MediaActions.copyToUri(ctx, e, dest) } }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { reload++ }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(PhotoPrivacy.MAX_PHOTOS)) { uris ->
        uris.forEach { u -> if (PickedMedia.items.none { it.uri == u }) PickedMedia.items.add(PhotoRef(u, u.lastPathSegment ?: "picked item", (ctx.contentResolver.getType(u) ?: "").startsWith("video/"))) }
    }

    val sel = mediaList.filter { it.uri in selected }

    GlassSettingSection("Gallery") {
        GText(MediaAccess.describe(level), size = 12.sp, color = g.subtext)
        if (level == MediaAccessLevel.NONE) {
            GText("Nova can't see your photos yet. Allow access, or use the Photo Picker to share just the ones you choose.", size = 13.sp)
            GlassButton("Allow photos & videos", { perm.launch(MediaAccess.permissionsToRequest(Build.VERSION.SDK_INT).toTypedArray()) }, primary = true)
        }
        if (Build.VERSION.SDK_INT >= 34 && level == MediaAccessLevel.SELECTED_ONLY)
            GlassButton("Choose more photos to share", { perm.launch(MediaAccess.permissionsToRequest(Build.VERSION.SDK_INT).toTypedArray()) })
        GlassButton("Photo Picker", { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) })
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("All", kind == MediaKind.ALL, { kind = MediaKind.ALL })
            GlassChip("Photos", kind == MediaKind.IMAGES, { kind = MediaKind.IMAGES })
            GlassChip("Videos", kind == MediaKind.VIDEOS, { kind = MediaKind.VIDEOS })
        }
        if (albums.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("All albums", album == null, { album = null })
            albums.take(30).forEach { a -> GlassChip("${a.name} (${a.count})", album == a.name, { album = a.name }) }
        }
        if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.accent)
    }

    if (PickedMedia.items.isNotEmpty()) GlassSettingSection("Chosen with Photo Picker") {
        PickedMedia.items.toList().forEach { r ->
            GlassListItem(r.name, if (r.isVideo) "Video · temporary access" else "Photo · temporary access")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Open", { try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(r.uri, if (r.isVideo) "video/*" else "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { msg = "No app can open that." } })
                GlassButton("Analyze…", { question = ""; analyzeRefs = listOf(r) }, primary = true)
                GlassButton("Remove", { PickedMedia.items.remove(r) })
            }
        }
    }

    GlassSettingSection(if (selected.isEmpty()) "Your photos & videos" else "${selected.size} selected") {
        if (mediaList.isEmpty() && !loading) GText(if (level == MediaAccessLevel.NONE) "Nothing to show: no access." else "No photos or videos found here.", size = 13.sp, color = g.subtext)
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxWidth().height(460.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(mediaList, key = { it.uri.toString() }) { e ->
                val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, e.uri) { value = withContext(Dispatchers.IO) { MediaRepository.thumbnail(ctx, e.uri)?.asImageBitmap() } }
                val on = e.uri in selected
                Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(g.subtext.a(0.15f))
                    .then(if (on) Modifier.border(3.dp, g.accent, RoundedCornerShape(10.dp)) else Modifier)
                    .combinedClickable(onClick = { if (selected.isNotEmpty()) selected = if (on) selected - e.uri else selected + e.uri else msg = MediaActions.open(ctx, e) },
                        onLongClick = { selected = if (on) selected - e.uri else selected + e.uri })) {
                    val t = thumb
                    if (t != null) Image(t, e.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else GText(if (e.isVideo) "🎞" else "🖼", size = 22.sp, modifier = Modifier.align(Alignment.Center))
                    if (e.isVideo) GText("▶ ${e.durationMs / 60000}:${String.format("%02d", (e.durationMs / 1000) % 60)}", size = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(4.dp))
                    if (on) GText("✓", size = 18.sp, color = g.accent, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp))
                }
                if (mediaList.lastOrNull() == e && !endReached) LaunchedEffect(mediaList.size) { page(mediaList.size) }
            }
        }
        GText("Tap to open · long-press to select. Thumbnails stay on your phone.", size = 11.sp, color = g.subtext)
    }

    if (sel.isNotEmpty()) GlassSettingSection("Actions for ${sel.size} item${if (sel.size > 1) "s" else ""}") {
        GlassButton("Analyze with Gemini…", {
            if (sel.size > PhotoPrivacy.MAX_PHOTOS) msg = "Select at most ${PhotoPrivacy.MAX_PHOTOS} photos to analyze." else { question = ""; analyzeRefs = sel.map { PhotoRef(it.uri, it.name, it.isVideo) } }
        }, primary = true)
        if (sel.size == 1) {
            GlassButton("Open", { msg = MediaActions.open(ctx, sel[0]) })
            GlassButton("Save a copy to…", { saveCopyOf = sel[0]; saveCopy.launch(sel[0].name) })
        }
        GlassButton("Copy into an album…", { albumName = "Nova"; albumDialog = "copy" })
        GlassButton("Move to an album…", { albumName = "Nova"; albumDialog = "move" }, enabled = Build.VERSION.SDK_INT >= 30)
        GlassButton("Move to Trash…", { confirmDelete = false })
        GlassButton("Delete permanently…", { confirmDelete = true })
        GlassButton("Clear selection", { selected = emptySet() })
        if (Build.VERSION.SDK_INT < 30) GText("Moving and Trash need Android 11+. Android always asks you to approve changes to photos Nova didn't create.", size = 11.sp, color = g.subtext)
    }
    if (busy) GText("Asking Gemini…", size = 13.sp, color = g.accent)
    if (result.isNotBlank()) GlassSettingSection("Gemini's answer") { GText(result, size = 14.sp); GlassButton("Dismiss", { result = "" }) }

    // ── consent dialog: the ONLY path that can upload a photo ──
    analyzeRefs?.let { refs ->
        if (!vm.prefs.photosToGemini) {
            GlassDialog({ analyzeRefs = null }, "Gemini photo analysis is off") {
                GText("Turn on “Allow Gemini photo analysis” in Settings → Photos & Videos first. Nothing was sent.", size = 14.sp)
            }
        } else GlassDialog({ analyzeRefs = null }, "Send to Google Gemini?", "Send once", {
            analyzeRefs = null; busy = true; result = ""
            scope.launch { result = vm.analyzePhotos(refs, question); busy = false }
        }) {
            GText("You are about to send ${refs.size} ${if (refs.size == 1) "photo" else "photos"} to Google's Gemini: ${refs.joinToString { it.name.take(24) }}.", size = 14.sp)
            GText("Only a resized copy without location or metadata goes out (videos: one frame). Nothing else from your phone. This permission covers this one request only.", size = 12.sp, color = g.subtext)
            GlassTextField(question, { question = it }, Modifier.fillMaxWidth(), placeholder = "Ask about it (optional)")
        }
    }
    confirmDelete?.let { permanent ->
        GlassDialog({ confirmDelete = null }, if (permanent) "Delete permanently?" else "Move to Trash?", if (permanent) "Continue" else "Move to Trash", {
            val list = sel; confirmDelete = null
            start(if (permanent) MediaActions.delete(ctx, list) else MediaActions.trash(ctx, list), list)
        }) {
            GText(if (permanent) "${sel.size} item(s) will be deleted and can't be recovered. Android will ask you to approve once more." else "${sel.size} item(s) go to Trash and can be restored from your Gallery app. Android will ask you to approve.", size = 14.sp)
        }
    }
    albumDialog?.let { mode ->
        GlassDialog({ albumDialog = null }, if (mode == "copy") "Copy into album" else "Move to album", "Go", {
            val list = sel; albumDialog = null
            if (mode == "move") start(MediaActions.organize(ctx, list, albumName), list)
            else scope.launch { busy = true; msg = withContext(Dispatchers.IO) { list.joinToString("\n") { MediaActions.copyToAlbum(ctx, it, albumName) } }; busy = false; reload++ }
        }) {
            GText(if (mode == "copy") "Makes new copies in Pictures/Movies; the originals stay." else "Moves the originals into Pictures/Movies. Android asks you to approve.", size = 13.sp)
            GlassTextField(albumName, { albumName = it }, Modifier.fillMaxWidth(), placeholder = "Album name")
        }
    }
}

// ───────────────────────── Files & Storage ─────────────────────────
@Composable
internal fun FilesPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val scope = rememberCoroutineScope()
    var trees by remember { mutableStateOf(vm.prefs.storageTrees) }
    var tree by remember { mutableStateOf<Uri?>(null) }
    var stack by remember { mutableStateOf(listOf<String>()) }
    var entries by remember { mutableStateOf(listOf<DocEntry>()) }
    var msg by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<DocEntry?>(null) }
    var copyFrom by remember { mutableStateOf<DocEntry?>(null) }
    var moveFrom by remember { mutableStateOf<DocEntry?>(null) }
    var renameFrom by remember { mutableStateOf<DocEntry?>(null) }
    var renameTo by remember { mutableStateOf("") }
    var listError by remember { mutableStateOf(false) }
    var folderDialog by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var single by remember { mutableStateOf<Uri?>(null) }

    fun reloadDir() {
        val t = tree; val d = stack.lastOrNull()
        if (t != null && d != null) scope.launch {
            val r = withContext(Dispatchers.IO) { Saf.listChecked(ctx, t, d) }
            if (r == null) {   // Android refused: say so instead of showing a misleading "Empty folder"
                entries = emptyList(); listError = true
                msg = if (Saf.hasGrant(ctx, t)) "Android wouldn't let Nova read this folder." else "Nova lost permission for this folder. Remove it and add it again."
            } else { entries = r; listError = false }
        }
    }
    LaunchedEffect(tree, stack) { reloadDir() }

    val chooseTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { if (Saf.persist(ctx, u)) { vm.prefs.storageTrees = vm.prefs.storageTrees + u.toString(); trees = vm.prefs.storageTrees; msg = "Folder added. Nova can only see inside it." } else msg = "Android didn't keep that folder grant." }
    }
    val chooseFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> single = u }

    GlassSettingSection("Folders you gave Nova (Storage Access Framework)") {
        GText("Android's own folder picker. Nova can only see inside folders you choose, and you can remove one at any time.", size = 12.sp, color = g.subtext)
        GlassButton("Choose a folder…", { chooseTree.launch(null) }, primary = true)
        GlassButton("Pick a single file…", { chooseFile.launch(arrayOf("*/*")) })
        single?.let { u -> GlassListItem("Picked file", u.lastPathSegment ?: u.toString(), onClick = { try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { msg = "No app can open that." } }) }
        trees.forEach { s ->
            val u = Uri.parse(s)
            val level = remember(tick, s) { Saf.grantLevel(ctx, u) }
            GlassListItem(u.lastPathSegment ?: s,
                when (level) { GrantLevel.NONE -> "Permission lost: remove it and add the folder again"; GrantLevel.READ -> "Read only. Tap to browse"; GrantLevel.READ_WRITE -> "Tap to browse" },
                onClick = { tree = u; stack = listOf(Saf.rootDocId(u)) })
            GlassButton("Remove access", {
                try { ctx.contentResolver.releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) { }
                vm.prefs.storageTrees = vm.prefs.storageTrees - s; trees = vm.prefs.storageTrees; if (tree == u) { tree = null; stack = emptyList(); entries = emptyList() }
            })
        }
        if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.accent)
    }

    tree?.let { t ->
        GlassSettingSection("Browsing: ${stack.lastOrNull() ?: ""}") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Up", { if (stack.size > 1) stack = stack.dropLast(1) }, enabled = stack.size > 1)
                GlassButton("New folder…", { folderName = ""; folderDialog = true })
                GlassButton("Close", { tree = null; stack = emptyList(); entries = emptyList() })
            }
            if (entries.isEmpty() && !listError) GText("Empty folder.", size = 12.sp, color = g.subtext)
            entries.take(200).forEach { e ->
                GlassListItem((if (e.isDir) "📁 " else "") + e.name, if (e.isDir) "Folder" else mb(e.size),
                    onClick = { if (e.isDir) stack = stack + e.docId else msg = Saf.open(ctx, e) })
                if (!e.isDir) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Open", { msg = Saf.open(ctx, e) })
                    GlassButton("Copy to…", { copyFrom = e }, enabled = trees.isNotEmpty())
                    GlassButton("Delete…", { del = e })
                }
                if (!e.isDir) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Rename…", { renameTo = e.name; renameFrom = e })
                    GlassButton("Move to…", { moveFrom = e }, enabled = trees.isNotEmpty())
                }
            }
        }
    }

    GlassSettingSection("All files access (optional)") {
        val granted = remember(tick) { AllFiles.granted() }
        GlassListItem("Status", if (!AllFiles.available()) "Not offered in this build / Android version" else if (granted) "Granted" else "Not granted")
        GText("Everything above works without this. It lets Nova list files anywhere in shared storage, which Google Play only permits for special app types, so it exists only in the direct (non-Play) build and only if you switch it on in Android settings. Nova won't open it silently.", size = 12.sp, color = g.subtext)
        if (AllFiles.available()) GlassButton(if (granted) "Open settings (to turn off)" else "Open Android settings to allow…", { msg = AllFiles.openSettings(ctx) })
        if (granted) AllFilesBrowser { msg = it }
    }

    if (folderDialog) GlassDialog({ folderDialog = false }, "New folder", "Create", {
        val t = tree; val d = stack.lastOrNull(); folderDialog = false
        if (t != null && d != null) scope.launch { msg = withContext(Dispatchers.IO) { Saf.createFolder(ctx, t, d, folderName) }; reloadDir() }
    }) { GlassTextField(folderName, { folderName = it }, Modifier.fillMaxWidth(), placeholder = "Folder name") }
    del?.let { e ->
        GlassDialog({ del = null }, "Delete ${e.name}?", "Delete", { del = null; scope.launch { msg = withContext(Dispatchers.IO) { Saf.delete(ctx, e) }; reloadDir() } }) {
            GText("This permanently deletes the file from the folder you shared. It can't be undone.", size = 14.sp)
        }
    }
    renameFrom?.let { e ->
        GlassDialog({ renameFrom = null }, "Rename ${e.name}", "Rename", {
            val name = renameTo; renameFrom = null
            scope.launch { msg = withContext(Dispatchers.IO) { Saf.rename(ctx, e, name) }; reloadDir() }
        }) { GlassTextField(renameTo, { renameTo = it }, Modifier.fillMaxWidth(), placeholder = "New name") }
    }
    moveFrom?.let { src ->
        GlassDialog({ moveFrom = null }, "Move ${src.name} into…") {
            GText("The file is copied, checked, and only then removed from here. If the check fails the original stays.", size = 12.sp, color = g.subtext)
            trees.forEach { s -> val u = Uri.parse(s); GlassListItem(u.lastPathSegment ?: s, "Top level of this folder", onClick = {
                val srcTree = tree; val parent = stack.lastOrNull(); moveFrom = null
                if (srcTree != null && parent != null) scope.launch { msg = withContext(Dispatchers.IO) { Saf.move(ctx, src, srcTree, parent, u, Saf.rootDocId(u)) }; reloadDir() }
            }) }
        }
    }
    copyFrom?.let { src ->
        GlassDialog({ copyFrom = null }, "Copy ${src.name} into…") {
            trees.forEach { s -> val u = Uri.parse(s); GlassListItem(u.lastPathSegment ?: s, "Top level of this folder", onClick = {
                copyFrom = null; scope.launch { msg = withContext(Dispatchers.IO) { Saf.copyInto(ctx, src, u, Saf.rootDocId(u)) } }
            }) }
        }
    }
}

@Composable
private fun AllFilesBrowser(say: (String) -> Unit) {
    val g = LocalGlass.current
    var path by remember { mutableStateOf(android.os.Environment.getExternalStorageDirectory().path) }
    var delFile by remember { mutableStateOf<File?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val list = remember(path, tick) { AllFiles.list(path) }
    GlassListItem("Folder", path)
    GlassButton("Up", { File(path).parent?.let { path = it } }, enabled = path != android.os.Environment.getExternalStorageDirectory().path)
    if (list == null) GText("Can't list this folder.", size = 12.sp, color = g.subtext)
    list?.take(150)?.forEach { f ->
        GlassListItem((if (f.isDirectory) "📁 " else "") + f.name, if (f.isDirectory) "Folder" else mb(f.length()), onClick = { if (f.isDirectory) path = f.path })
        if (!f.isDirectory) GlassButton("Delete…", { delFile = f })
    }
    delFile?.let { f -> GlassDialog({ delFile = null }, "Delete ${f.name}?", "Delete", { say(AllFiles.delete(f.path)); delFile = null; tick++ }) { GText("Permanently deletes this file. It can't be undone.", size = 14.sp) } }
}
