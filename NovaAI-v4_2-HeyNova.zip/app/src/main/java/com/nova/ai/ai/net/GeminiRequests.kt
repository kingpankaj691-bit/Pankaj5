package com.nova.ai.ai.net

import com.nova.ai.ai.model.GeminiModel
import org.json.JSONArray
import org.json.JSONObject

/** Builds model-aware generateContent requests. Chat requests never carry responseModalities: text is the default for every text model. */
object GenerationConfigBuilder {
    fun build(temperature: Double, maxTokens: Int, model: GeminiModel?): JSONObject {
        val maxTemp = model?.maxTemperature?.takeIf { it > 0.0 } ?: 2.0
        var tokens = maxTokens.coerceAtLeast(64)
        val limit = model?.outputTokenLimit ?: 0
        if (limit > 0) tokens = tokens.coerceAtMost(limit)
        return JSONObject()
            .put("temperature", temperature.coerceIn(0.0, maxTemp))
            .put("maxOutputTokens", tokens)
    }
}

object ChatRequestBuilder {
    /** history: (isUser, text), oldest first. */
    fun build(history: List<Pair<Boolean, String>>, system: String, generationConfig: JSONObject): JSONObject {
        val contents = JSONArray()
        history.forEach { (isUser, text) ->
            contents.put(
                JSONObject().put("role", if (isUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject().put("contents", contents).put("generationConfig", generationConfig)
        if (system.isNotBlank()) body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        return body
    }
}

object ResponseParser {
    class Parsed(val text: String, val error: GeminiError?, val truncated: Boolean = false)

    /** Reads answer text, skipping "thought" parts, and explains blocks and empty answers instead of showing nothing. */
    fun parse(j: JSONObject, model: String? = null): Parsed {
        val block = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        val cand = j.optJSONArray("candidates")?.optJSONObject(0)
        if (cand == null) {
            return if (block.isNotEmpty()) Parsed("", GeminiError(GeminiErrorKind.BLOCKED, null, "reason: $block", null, model))
            else Parsed("", GeminiError(GeminiErrorKind.EMPTY, null, "no candidates returned", null, model))
        }
        val finish = cand.optString("finishReason")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text"))
        }
        val text = sb.toString().trim()
        if (text.isNotEmpty()) return Parsed(text, null, truncated = finish == "MAX_TOKENS")
        val blocked = setOf("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION", "IMAGE_SAFETY")
        return when {
            finish in blocked -> Parsed("", GeminiError(GeminiErrorKind.BLOCKED, null, "reason: $finish", null, model))
            finish == "MAX_TOKENS" -> Parsed("", GeminiError(GeminiErrorKind.EMPTY, null, "the model used all of its output tokens while thinking; raise Max output tokens in Settings → Gemini", null, model))
            else -> Parsed("", GeminiError(GeminiErrorKind.EMPTY, null, if (finish.isEmpty()) "no text in the answer" else "finish reason: $finish", null, model))
        }
    }
}
