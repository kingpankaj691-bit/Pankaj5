package com.nova.ai.device

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import com.nova.ai.automation.Notifier
import com.nova.ai.security.Prefs
import java.util.concurrent.TimeUnit

/**
 * Battery and temperature alerts. Each alert fires once when a level is crossed and is re-armed only after the level recovers,
 * so a phone sitting at 19% never nags. The state survives restarts in [Prefs.alertState].
 */
object DeviceAlerts {
    private const val B_LOW = 1
    private const val B_CRIT = 2
    private const val B_FULL = 4
    private const val T_WARN = 8
    private const val T_HOT = 16

    fun anyEnabled(p: Prefs) = p.batteryAlerts || p.tempAlerts

    fun evaluate(ctx: Context, p: Prefs, speak: ((String) -> Unit)?) {
        var st = p.alertState
        if (p.batteryAlerts) {
            val b = BatteryMonitor(ctx).snapshot()
            if (b != null) {
                if (b.charging) {
                    st = st and (B_LOW or B_CRIT).inv()
                    if (b.full && p.batteryFullAlert && st and B_FULL == 0) { st = st or B_FULL; fire(ctx, 5001, "Battery full", "Nova: Battery fully charged.", speak) }
                    if (!b.full && b.percent < 95) st = st and B_FULL.inv()
                } else {
                    st = st and B_FULL.inv()
                    if (b.percent <= p.batteryCritPct && st and B_CRIT == 0) {
                        st = st or B_CRIT or B_LOW
                        fire(ctx, 5002, "Battery critically low", "Nova: Battery critically low, ${b.percent}%. Please charge now.", speak)
                    } else if (b.percent <= p.batteryLowPct && st and B_LOW == 0) {
                        st = st or B_LOW
                        fire(ctx, 5003, "Battery low", "Nova: Battery ${b.percent}% par hai.", speak)
                    }
                    if (b.percent > p.batteryLowPct + 5) st = st and (B_LOW or B_CRIT).inv()
                }
            }
        }
        if (p.tempAlerts) {
            val r = TemperatureMonitor(ctx, p).read()
            when (r.heat) {
                Heat.HOT -> if (st and T_HOT == 0) { st = st or T_HOT or T_WARN; fire(ctx, 5004, "Phone is hot", TemperatureMonitor(ctx, p).describe(r), speak, thermal = true) }
                Heat.WARM -> {
                    st = st and T_HOT.inv()
                    if (st and T_WARN == 0) { st = st or T_WARN; fire(ctx, 5004, "Phone is warm", TemperatureMonitor(ctx, p).describe(r), speak, thermal = true) }
                }
                Heat.OK -> st = st and (T_WARN or T_HOT).inv()
                Heat.UNKNOWN -> { }
            }
        }
        if (st != p.alertState) p.alertState = st
    }

    private fun fire(ctx: Context, id: Int, title: String, text: String, speak: ((String) -> Unit)?, thermal: Boolean = false) {
        val tap = if (thermal) PendingIntent.getActivity(ctx, 77,
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else Notifier.openApp(ctx)
        Notifier.post(ctx, id, title, if (thermal) "$text Tap for battery saver settings." else text, tap)
        speak?.invoke(text)
    }

    /** A light 15-minute check for when Nova's screen and Background Voice are both closed. Scheduled only while an alert is on. */
    fun schedule(ctx: Context, p: Prefs) {
        val wm = WorkManager.getInstance(ctx)
        if (anyEnabled(p))
            wm.enqueueUniquePeriodicWork("device_alerts", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<DeviceAlertWorker>(15, TimeUnit.MINUTES).build())
        else wm.cancelUniqueWork("device_alerts")
    }
}

class DeviceAlertWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val p = Prefs(applicationContext)
        if (DeviceAlerts.anyEnabled(p)) DeviceAlerts.evaluate(applicationContext, p, null)
        return Result.success()
    }
}
