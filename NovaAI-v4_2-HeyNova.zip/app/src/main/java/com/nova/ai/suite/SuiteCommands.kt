package com.nova.ai.suite

import com.nova.ai.NovaApp
import com.nova.ai.commands.Cat
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level
import com.nova.ai.commands.UiBridge

/**
 * Voice/text commands for the system-control, privacy and developer-integration features. Hinglish and English.
 * Anything that changes state goes through the router's normal confirmation level; build/run commands only open the review screen.
 */
class SuiteCommands {
    private val ctx get() = NovaApp.instance
    private fun cmd(cat: Cat, level: Level = Level.Info, prompt: String = "", tag: String = "", sensitive: Boolean = false, run: () -> String) =
        CmdResult(true, cat, prompt, level, { val r = run(); Workflows.History.add(ctx, "Command: " + lastRaw.take(36), r.lineSequence().firstOrNull().orEmpty().take(60)); r }, tag, sensitive)
    @Volatile private var lastRaw = ""

    fun route(raw: String, t: String): CmdResult? {
        lastRaw = raw
        fun has(vararg w: String) = w.any { t.contains(it) }
        val off = has(" off", "band", "hata", "disable", "बंद")
        if (has("do not disturb", "dnd", "disturb mat", "डू नॉट डिस्टर्ब")) {
            return cmd(Cat.LOCAL_DEVICE_COMMAND, Level.Action, if (off) "Turn Do Not Disturb off?" else "Turn Do Not Disturb on?", "dnd") { SystemControls.setDnd(ctx, !off) }
        }
        if (has("live ocr", "live translate", "live text", "लाइव ओसीआर")) {
            val stop = has("band", "stop", "off", "rok", "disable", "बंद")
            val lang = if (has("translate", "anuvad")) (ScreenTools.languageIn(t) ?: "Hindi") else null
            return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) {
                if (stop) { LiveOcr.stop(ctx); "Live OCR band kar diya." }
                else LiveOcr.start(ctx, lang)
            }
        }
        if (has("khud karo", "khud se karo", "apne aap karo", "agent mode", "do it yourself", "jarvis mode", "khud kar do")) {
            val goal = listOf("khud se karo", "khud karo", "khud kar do", "apne aap karo", "agent mode", "do it yourself", "jarvis mode").fold(t) { acc, w -> acc.replace(w, " ") }.replace(Regex("\\s+"), " ").trim(' ', ',', ':', '-')
            return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) { ScreenAgent.start(ctx, goal) }
        }
        if (has("instagram") && has("upload", "reel", "post") && has("video", "export", "latest", "caption")) {
            return cmd(Cat.APP_COMMAND, Level.Action, "Start the Instagram upload workflow? I will find your latest video, write a caption and show a preview. Only if you choose \"Fill & share\" will I press Share by myself.", "files") { Workflows.instagramPrep(ctx, raw) }
        }
        if (has("live ocr", "live o.c.r", "live o c r", "लाइव ओसीआर", "लाइव ocr")) {
            val stopIt = has("band", "stop", "off", "hata", "bandh", "बंद")
            if (stopIt) return cmd(Cat.SCREEN_COMMAND, tag = "screen") { LiveOcr.stop(ctx) }
            val lang = ScreenTools.languageIn(t)
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Start Live OCR? It reads the text on your screen every few seconds until you say stop.", "screen", true) { LiveOcr.start(ctx, lang) }
        }
        if (has("youtube") && has("upload") && has("title", "description", "prepare", "export", "latest", "taiyaar")) {
            return cmd(Cat.APP_COMMAND, Level.Action, "Start the YouTube upload workflow? I will find your latest video, draft a title and description and show a preview. Only if you choose \"Fill & upload\" will I press Upload by myself.", "files") { Workflows.youtubePrep(ctx, raw) }
        }
        if ((has("latest video", "last video", "latest export", "recent video", "exported video")) && has("share", "bhej", "send", "bhejo")) {
            return cmd(Cat.APP_COMMAND, Level.Action, "Find your latest video and share it to another app? Only if you choose \"Open & send\" will I press Send by myself.", "files") { Workflows.shareLatest(ctx, t) }
        }
        if (has("reply draft", "reply likho", "reply karo", "draft a reply", "draft reply")) return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) { ScreenTools.draftReply(ctx); "Chat padh kar reply draft kar rahi hoon. Bhejna aap ko hai." }
        if (has("select all", "sab select", "sabhi select", "saara text select")) return cmd(Cat.SCREEN_COMMAND, tag = "screen") {
            if (com.nova.ai.accessibility.NovaAccessibilityService.instance?.selectAllInFocused() == true) "Selected all text in this box." else "I couldn't select (no focused text box, or Accessibility is off)."
        }
        if (has("copy karo", "copy this", "text copy", "copy the text", "copy kar do")) return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) { ScreenTools.copyText(ctx) }
        fun goTab(tab: Int, say: String): CmdResult = cmd(Cat.SETTINGS_COMMAND, tag = "basic") { val nav = UiBridge.navigate ?: return@cmd "Open Nova > More."; nav(tab); say }
        if (has("control center", "control centre", "nova settings sections")) return goTab(UiBridge.TAB_CONTROL_CENTER, "Control Center khol rahi hoon.")
        if (has("asset manager", "assets kholo", "asset library")) return goTab(UiBridge.TAB_ASSETS, "Asset Manager khol rahi hoon.")
        if (has("kiosk", "device owner", "app restriction", "app inventory", "installed apps", "screen pin")) return goTab(UiBridge.TAB_DEVICE_MGMT, "Device Management khol rahi hoon.")
        if (has("security activity", "security log", "security history", "permission history")) return goTab(UiBridge.TAB_SECURITY, "Security Activity khol rahi hoon.")
        val screenWord = has("screen", "page", "is text ko", "isko")
        if (screenWord && has("translate", "anuvad", "translation")) {
            val lang = ScreenTools.languageIn(t) ?: "Hindi"
            return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) { ScreenTools.translate(ctx, lang); "Screen translate kar rahi hoon ($lang). Neeche sheet mein dikhega." }
        }
        if (has("extract text", "text extract", "ocr karo", "screen ka text", "is image ka text")) {
            return cmd(Cat.SCREEN_COMMAND, Level.Info, "", "screen", true) { ScreenTools.extract(ctx); "Screen ka text nikaal rahi hoon. Sheet mein copy ya share kar sakte hain." }
        }
        if (has("quick menu", "nova menu", "show menu")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { NovaSheet.showMenu(ctx); "Menu dikha rahi hoon." }
        if (has("private dns", "dns settings", "dns kholo")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { SystemControls.openPrivateDns(ctx) }
        if (has("bluetooth settings", "bluetooth setting")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { SystemControls.openBluetooth(ctx) }
        if (has("wifi settings", "wi-fi settings", "wifi setting")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { SystemControls.openWifi(ctx) }
        if (has("airplane mode settings", "airplane settings", "flight mode settings")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { SystemControls.openAirplane(ctx) }
        if (has("display settings")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { SystemControls.openDisplay(ctx) }
        if (has("audio ducking", "duck audio", "music volume kam")) {
            val on = !off
            return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { AudioDucker.setEnabled(ctx, on); if (on) "Audio ducking on: other audio gets quieter while I talk." else "Audio ducking off." }
        }
        if (has("privacy dashboard", "privacy status", "privacy dikhao")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") {
            val nav = UiBridge.navigate ?: return@cmd "Open Nova > More > Privacy Dashboard."
            nav(UiBridge.TAB_PRIVACY_DASH); "Privacy Dashboard khol rahi hoon."
        }
        if (has("github build", "github status", "build status", "apk ready", "project build", "build karo", "build my project", "gradle build", "termux", "git status", "error history", "log analy")) return cmd(Cat.DEVELOPER_COMMAND, tag = "basic") {
            val nav = UiBridge.navigate ?: return@cmd "Open Nova > More > Developer Integrations."
            nav(UiBridge.TAB_DEV_INTEGRATIONS)
            "Developer Integrations khol rahi hoon. Wahan se command ya workflow dekh kar approve kijiye; main kuch bhi bina poochhe nahi chalati."
        }
        return null
    }
}
