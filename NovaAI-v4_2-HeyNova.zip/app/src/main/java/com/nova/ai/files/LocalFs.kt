package com.nova.ai.files

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Real file operations on java.io.File. Pure JVM (no Context) so they are unit-tested against temp folders.
 * Rules: never overwrite (a free name is chosen), verify every result before reporting it, clean up partial output on failure.
 * The caller (FileOps) has already checked access, storage volumes and the user's confirmation.
 */
object LocalFs {
    private fun free(dir: File, name: String) = File(dir, NameRules.uniqueName(name) { File(dir, it).exists() })

    private fun canon(f: File) = try { f.canonicalPath } catch (e: Exception) { f.absolutePath }

    fun treeStats(f: File): Pair<Int, Long> {
        if (f.isFile) return 1 to f.length()
        var n = 0; var b = 0L
        f.walkTopDown().filter { it.isFile }.forEach { n++; b += it.length() }
        return n to b
    }

    private fun copyStream(src: File, dest: File) {
        FileInputStream(src).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o, 64 * 1024) } }
        dest.setLastModified(src.lastModified())
    }

    private fun copyTreeRaw(src: File, dest: File) {
        if (src.isDirectory) {
            if (!dest.mkdirs() && !dest.isDirectory) throw IllegalStateException("can't create ${dest.name}")
            (src.listFiles() ?: throw IllegalStateException("can't read ${src.name}")).forEach { copyTreeRaw(it, File(dest, it.name)) }
        } else copyStream(src, dest)
    }

    private fun copyInto(src: File, destDir: File): Pair<OpResult, File?> {
        if (!src.exists()) return OpResult(false, "${src.name} no longer exists.", 0, 1) to null
        if (!destDir.isDirectory) return OpResult(false, "The destination isn't a folder.", 0, 1) to null
        if (src.isDirectory && (canon(destDir) == canon(src) || canon(destDir).startsWith(canon(src) + File.separator)))
            return OpResult(false, "I can't copy a folder into itself.", 0, 1) to null
        val target = free(destDir, src.name)
        return try {
            copyTreeRaw(src, target)
            if (treeStats(src) == treeStats(target)) OpResult(true, "Copied ${src.name} to ${destDir.name} (verified).", 1) to target
            else { target.deleteRecursively(); OpResult(false, "The copy of ${src.name} didn't match the original, so I removed it.", 0, 1) to null }
        } catch (e: Exception) { target.deleteRecursively(); OpResult(false, "Couldn't copy ${src.name}: ${e.message}", 0, 1) to null }
    }

    /** Copy a file or folder into [destDir]. */
    fun copy(src: File, destDir: File): OpResult = copyInto(src, destDir).first

    /** Move: instant rename on the same volume, otherwise copy → verify → delete the original. */
    fun move(src: File, destDir: File): OpResult {
        if (!src.exists()) return OpResult(false, "${src.name} no longer exists.", 0, 1)
        if (!destDir.isDirectory) return OpResult(false, "The destination isn't a folder.", 0, 1)
        if (canon(src.parentFile ?: src) == canon(destDir)) return OpResult(true, "${src.name} is already in ${destDir.name}.", 1)
        if (src.isDirectory && (canon(destDir) == canon(src) || canon(destDir).startsWith(canon(src) + File.separator)))
            return OpResult(false, "I can't move a folder into itself.", 0, 1)
        val target = free(destDir, src.name)
        if (src.renameTo(target) && target.exists() && !src.exists()) return OpResult(true, "Moved ${src.name} to ${destDir.name} (verified).", 1)
        val (c, copied) = copyInto(src, destDir)
        if (!c.ok || copied == null) return c
        return if (delete(src).ok) OpResult(true, "Moved ${src.name} to ${destDir.name} (verified).", 1)
        else OpResult(false, "Copied ${src.name}, but couldn't remove the original.", 0, 1)
    }

    fun rename(src: File, newName: String): OpResult {
        NameRules.validate(newName)?.let { return OpResult(false, it, 0, 1) }
        val n = newName.trim()
        if (n == src.name) return OpResult(true, "Same name; nothing to change.", 1)
        val target = File(src.parentFile, n)
        if (target.exists()) return OpResult(false, "“$n” already exists in this folder.", 0, 1)
        return if (src.renameTo(target) && target.exists() && !src.exists()) OpResult(true, "Renamed ${src.name} to $n (verified).", 1)
        else OpResult(false, "Android didn't let me rename ${src.name}.", 0, 1)
    }

    fun mkdir(parent: File, name: String): OpResult {
        NameRules.validate(name)?.let { return OpResult(false, it, 0, 1) }
        val d = File(parent, name.trim())
        if (d.exists()) return OpResult(false, "“${name.trim()}” already exists.", 0, 1)
        return if (d.mkdir() && d.isDirectory) OpResult(true, "Created folder ${d.name}.", 1) else OpResult(false, "Couldn't create the folder.", 0, 1)
    }

    /** Deletes a file, or a folder with everything inside. The caller has the user's confirmation and DeleteGuard's approval. */
    fun delete(f: File): OpResult {
        if (!f.exists()) return OpResult(true, "${f.name} was already gone.", 1)
        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
        return if (ok && !f.exists()) OpResult(true, "Deleted ${f.name} (verified).", 1) else OpResult(false, "I couldn't delete ${f.name}.", 0, 1)
    }

    fun zip(sources: List<File>, dest: File): OpResult {
        if (sources.isEmpty()) return OpResult(false, "Nothing selected.", 0, 1)
        var count = 0
        return try {
            ZipOutputStream(FileOutputStream(dest).buffered()).use { z ->
                fun add(f: File, entry: String) {
                    if (canon(f) == canon(dest)) return
                    if (f.isDirectory) {
                        z.putNextEntry(ZipEntry("$entry/")); z.closeEntry()
                        f.listFiles()?.forEach { add(it, "$entry/${it.name}") }
                    } else {
                        if (count >= ZipRules.MAX_ENTRIES) throw IllegalStateException("too many files (limit ${ZipRules.MAX_ENTRIES})")
                        z.putNextEntry(ZipEntry(entry).apply { time = f.lastModified() })
                        FileInputStream(f).use { it.copyTo(z, 64 * 1024) }; z.closeEntry(); count++
                    }
                }
                sources.forEach { add(it, it.name) }
            }
            val readBack = ZipFile(dest).use { zf -> zf.entries().asSequence().count { !it.isDirectory } }
            if (readBack == count) OpResult(true, "Created ${dest.name}: $count file${if (count == 1) "" else "s"} (verified).", count)
            else { dest.delete(); OpResult(false, "The archive didn't verify, so I removed it.", 0, 1) }
        } catch (e: Exception) { dest.delete(); OpResult(false, "Couldn't create the ZIP: ${e.message}", 0, 1) }
    }

    /** Extracts into a new folder named after the archive. Guards against zip-slip and zip bombs. */
    fun unzip(zipFile: File, destDir: File): OpResult {
        val out = free(destDir, zipFile.nameWithoutExtension.ifBlank { "extracted" })
        return try {
            if (!out.mkdir()) throw IllegalStateException("can't create the folder")
            val rootCanon = canon(out) + File.separator
            var files = 0; var total = 0L
            ZipFile(zipFile).use { zf ->
                if (zf.size() > ZipRules.MAX_ENTRIES) throw IllegalStateException("the archive has too many entries")
                for (e in zf.entries()) {
                    val rel = ZipRules.safeEntryName(e.name) ?: throw IllegalStateException("unsafe path in archive (${e.name.take(40)})")
                    val t = File(out, rel)
                    if (!canon(t).startsWith(rootCanon)) throw IllegalStateException("unsafe path in archive")
                    if (e.isDirectory) { t.mkdirs(); continue }
                    t.parentFile?.mkdirs()
                    zf.getInputStream(e).use { i -> FileOutputStream(t).use { o ->
                        val buf = ByteArray(64 * 1024); var n: Int
                        while (i.read(buf).also { n = it } > 0) {
                            total += n
                            if (total > ZipRules.MAX_TOTAL_BYTES) throw IllegalStateException("the archive expands beyond ${ZipRules.MAX_TOTAL_BYTES / 1073741824} GB")
                            o.write(buf, 0, n)
                        }
                    } }
                    files++
                }
            }
            OpResult(true, "Extracted $files file${if (files == 1) "" else "s"} into ${out.name}.", files)
        } catch (e: Exception) { out.deleteRecursively(); OpResult(false, "Couldn't extract ${zipFile.name}: ${e.message}", 0, 1) }
    }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { i -> val buf = ByteArray(64 * 1024); var n: Int; while (i.read(buf).also { n = it } > 0) md.update(buf, 0, n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Groups of byte-identical files (same size first, then SHA-256). Biggest waste first. */
    fun findDuplicates(files: List<File>, alive: () -> Boolean = { true }): List<List<File>> {
        val out = ArrayList<List<File>>()
        files.filter { it.isFile && it.length() > 0 }.groupBy { it.length() }.values.filter { it.size >= 2 }.forEach { same ->
            if (!alive()) return@forEach
            same.mapNotNull { f -> if (!alive()) null else try { sha256(f) to f } catch (e: Exception) { null } }
                .groupBy({ it.first }, { it.second }).values.filter { it.size >= 2 }.forEach { out.add(it) }
        }
        return out.sortedByDescending { (it.size - 1) * it[0].length() }
    }

    /** All regular files under [roots], bounded and cancellable, skipping protected locations. */
    fun listFiles(roots: List<File>, maxFiles: Int = 50_000, alive: () -> Boolean = { true }): List<File> {
        val out = ArrayList<File>(); val q = ArrayDeque<File>(roots)
        while (q.isNotEmpty() && alive() && out.size < maxFiles) {
            val d = q.removeFirst()
            if (PathRules.blockedReason(d.path) != null) continue
            for (k in (try { d.listFiles() } catch (e: Exception) { null } ?: continue)) {
                if (k.isDirectory) q.add(k) else if (out.size < maxFiles) out.add(k)
            }
        }
        return out
    }
}
