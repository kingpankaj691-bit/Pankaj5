package com.nova.ai.commands

/** Lets a command ask the visible app to open a screen. It is null while the app UI isn't alive, and commands then say so. */
object UiBridge {
    @Volatile var navigate: ((Int) -> Unit)? = null
    /** Opens the Developer tab and sends this text to the coding assistant there. */
    @Volatile var sendDev: ((String) -> Unit)? = null
    const val TAB_VISION = 16
    const val TAB_DEV_TOOLS = 17
    const val TAB_PRIVACY_DASH = 19
    const val TAB_DEV_INTEGRATIONS = 20
    const val TAB_CONTROL_CENTER = 21
    const val TAB_ASSETS = 22
    const val TAB_DEVICE_MGMT = 23
    const val TAB_SECURITY = 24
}
