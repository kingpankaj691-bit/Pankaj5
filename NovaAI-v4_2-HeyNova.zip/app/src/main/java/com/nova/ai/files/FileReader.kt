package com.nova.ai.files

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.core.content.pm.PackageInfoCompat
import com.google.mlkit.vision.common.InputImage
import com.nova.ai.vision.TextRecognitionManager
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/**
 * Reads a file's text ON THE PHONE. PDFs are read with Android's own PDF renderer plus on-device text recognition (no upload),
 * APKs show their package info, everything else goes through DocReader. Nothing here touches the network.
 */
object FileReader {
    private const val MAX_COPY = 50L * 1024 * 1024
    private const val MAX_PDF_PAGES = 5

    private fun usablePath(ctx: Context, item: FileItem): File? {
        if (item.path.isBlank()) return null
        val f = File(item.path)
        val canon = try { f.canonicalPath } catch (e: Exception) { return null }
        if (!PathRules.isWithinAny(StorageVolumes.roots(ctx), canon) || PathRules.blockedReason(canon) != null) return null
        return if (f.isFile && f.canRead()) File(canon) else null
    }

    /** A real file for [item]. MediaStore-only items are copied into the app's cache (and must be released afterwards). */
    private fun materialize(ctx: Context, item: FileItem, cap: Long = MAX_COPY): Pair<File, Boolean>? {
        usablePath(ctx, item)?.let { return it to false }
        val u = item.uri ?: return null
        if (item.size > cap) return null
        val tmp = File(ctx.cacheDir, "fm_read_${System.nanoTime()}_${item.name.take(40).replace(Regex("[^A-Za-z0-9._-]"), "_")}")
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(u))?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } } ?: return null
            tmp to true
        } catch (e: Exception) { tmp.delete(); null }
    }

    suspend fun read(ctx: Context, item: FileItem): DocText {
        if (item.isDir) return DocText(false, "", "That's a folder.")
        return when (item.ext) {
            "pdf" -> readPdf(ctx, item)
            "apk" -> apkInfo(ctx, item)
            else -> {
                if (!DocReader.readable(item.name)) return DocText(false, "", "Nova can't read ${item.kind.label.lowercase()} files as text.")
                val (f, temp) = materialize(ctx, item) ?: return DocText(false, "", "I couldn't open ${item.name}. Android didn't give Nova access to it.")
                try { DocReader.read(f) } finally { if (temp) f.delete() }
            }
        }
    }

    private suspend fun ocr(m: TextRecognitionManager, bmp: Bitmap): String = suspendCancellableCoroutine { c ->
        m.read(InputImage.fromBitmap(bmp, 0)) { text -> if (c.isActive) c.resume(if (text.startsWith("I couldn't find readable text")) "" else text) }
    }

    private suspend fun readPdf(ctx: Context, item: FileItem): DocText {
        val pfd: ParcelFileDescriptor = try {
            usablePath(ctx, item)?.let { ParcelFileDescriptor.open(it, ParcelFileDescriptor.MODE_READ_ONLY) }
                ?: item.uri?.let { ctx.contentResolver.openFileDescriptor(Uri.parse(it), "r") }
        } catch (e: Exception) { null } ?: return DocText(false, "", "I couldn't open that PDF.")
        val mgr = TextRecognitionManager()
        var renderer: PdfRenderer? = null
        return try {
            renderer = PdfRenderer(pfd)
            val total = renderer.pageCount; val n = minOf(total, MAX_PDF_PAGES)
            val sb = StringBuilder()
            for (i in 0 until n) {
                val page = renderer.openPage(i)
                val w = 1400; val h = (page.height.toFloat() * w / page.width).toInt().coerceIn(200, 3000)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); page.close()
                val t = ocr(mgr, bmp); bmp.recycle()
                if (t.isNotBlank()) sb.append("— page ${i + 1} —\n").append(t).append("\n\n")
                if (sb.length >= DocReader.MAX_CHARS) break
            }
            val text = DocReader.tidy(sb.toString())
            if (text.isBlank()) DocText(false, "", "I couldn't find readable text in the first $n page${if (n == 1) "" else "s"} (it may be a scan or photo-only PDF).", total > n, "On-device OCR")
            else DocText(true, text.take(DocReader.MAX_CHARS), "Read with on-device text recognition (first $n of $total pages). It can contain mistakes. Nothing was uploaded.", total > n || text.length > DocReader.MAX_CHARS, "On-device OCR")
        } catch (e: SecurityException) { DocText(false, "", "This PDF is password-protected, so I can't read it.")
        } catch (e: Exception) { DocText(false, "", "I couldn't read that PDF: ${e.message?.take(80)}")
        } finally { try { renderer?.close() } catch (e: Exception) { }; try { pfd.close() } catch (e: Exception) { }; mgr.close() }
    }

    private fun apkInfo(ctx: Context, item: FileItem): DocText {
        val (f, temp) = materialize(ctx, item, 150L * 1024 * 1024) ?: return DocText(false, "", "I couldn't open that APK.")
        return try {
            val pm = ctx.packageManager
            val info = pm.getPackageArchiveInfo(f.path, PackageManager.GET_PERMISSIONS) ?: return DocText(false, "", "Android couldn't read this APK (it may be damaged or a split package).")
            val app = info.applicationInfo?.also { it.sourceDir = f.path; it.publicSourceDir = f.path }
            val installed = try { pm.getPackageInfo(info.packageName, 0) } catch (e: Exception) { null }
            val perms = info.requestedPermissions?.map { it.substringAfterLast('.') }.orEmpty()
            DocText(true, buildString {
                append("App: ${app?.loadLabel(pm) ?: info.packageName}\nPackage: ${info.packageName}\nVersion: ${info.versionName ?: "?"} (${PackageInfoCompat.getLongVersionCode(info)})\n")
                if (app != null) append("Targets Android API ${app.targetSdkVersion}, needs API ${app.minSdkVersion}+\n")
                append(if (installed != null) "Installed on this phone: version ${installed.versionName ?: "?"}\n" else "Not installed on this phone.\n")
                append("Permissions asked: ${perms.size}\n"); perms.take(20).forEach { append("• $it\n") }; if (perms.size > 20) append("… and ${perms.size - 20} more\n")
                append("\nThis is only the package info. Nova did not install or upload the APK.")
            }, "", false, "APK package info")
        } catch (e: Exception) { DocText(false, "", "I couldn't read that APK: ${e.message?.take(80)}") } finally { if (temp) f.delete() }
    }
}
