package com.nova.ai.commands

import android.provider.Settings
import com.nova.ai.NovaApp
import com.nova.ai.automation.AutomationEngine
import com.nova.ai.automation.RoutineManager
import com.nova.ai.core.MemoryManager
import com.nova.ai.device.BatteryMonitor
import com.nova.ai.device.DeviceAlerts
import com.nova.ai.device.DeviceController
import com.nova.ai.device.NetworkMonitor
import com.nova.ai.device.TemperatureMonitor
import com.nova.ai.memory.ContextManager
import com.nova.ai.memory.MemoryDb
import com.nova.ai.memory.MemoryRepository
import com.nova.ai.security.Prefs

/**
 * Voice/text commands for Part 2: device alerts, temperature, network, weekly editing days, Night Mode, Editing Mode and
 * "what do I normally do on Tuesday". Plugged into LocalCommandRouter, so they work offline and through the existing confirm/lock rules.
 */
class ModeCommands(
    private val device: DeviceController,
    private val memory: MemoryManager,
    private val prefs: Prefs,
    private val db: MemoryDb
) {
    private val ctx get() = NovaApp.instance
    private val context by lazy { ContextManager(MemoryRepository(memory, prefs)) }
    private val onRe = Regex("\\b(on|chalu|enable|activate|start|shuru)\\b")
    private val offRe = Regex("\\b(off|band|disable|deactivate|stop|khatam)\\b")

    private fun cmd(cat: Cat, level: Level = Level.Info, prompt: String = "", tag: String = "", sensitive: Boolean = false, run: () -> String) =
        CmdResult(true, cat, prompt, level, run, tag, sensitive)

    fun route(raw: String, t: String): CmdResult? {
        fun has(vararg w: String) = w.any { t.contains(it) }
        val on = onRe.containsMatchIn(t)
        val off = offRe.containsMatchIn(t)
        val toggle: Boolean? = if (on == off) null else on
        val unclear = "Do you want it on or off?"

        // ── battery / temperature alerts ──
        if (has("battery alert")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") {
            if (toggle == null) unclear else {
                prefs.batteryAlerts = toggle; DeviceAlerts.schedule(ctx, prefs)
                if (toggle) "Battery alerts on. I'll tell you at ${prefs.batteryLowPct}%, at ${prefs.batteryCritPct}% and when it's fully charged. " +
                    "Android may delay checks by up to 15 minutes unless Nova's screen or Background Voice is open."
                else "Battery alerts off."
            }
        }
        if (has("temperature alert", "heat alert", "thermal alert")) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") {
            if (toggle == null) unclear else {
                prefs.tempAlerts = toggle; DeviceAlerts.schedule(ctx, prefs)
                if (toggle) "Temperature alerts on. I'll warn you at ${prefs.tempWarnC}°C battery temperature or when Android reports a high thermal status."
                else "Temperature alerts off."
            }
        }
        if (has("phone temperature", "device temperature", "battery temperature", "system temperature", "cpu temperature", "thermal status",
                "phone garam", "kitna garam", "phone kitna garam"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") { TemperatureMonitor(ctx, prefs).describe() }

        // ── network ──
        if (has("network status", "connection status", "internet status", "net status", "latency", "ping test", "network batao", "connection stable"))
            return cmd(Cat.GENERAL_QUERY, tag = "status") {
                val net = NetworkMonitor.shared(ctx)
                val before = net.lastLatencyMs
                net.measureAsync()
                net.describe() + if (before == null) " I'm measuring latency now; ask again in a few seconds." else " (Latency is from the last check; I'm refreshing it.)"
            }

        // ── memory: what do I normally do on <day> ──
        val days = RoutineManager.parseDays(t)
        if (days.size == 1 && Regex("\\b(normally|usually|generally|aam taur|aamtaur)\\b").containsMatchIn(t) && has("what", "kya", "kaun"))
            return cmd(Cat.SETTINGS_COMMAND, tag = "memory", sensitive = true) { context.answerForDay(days.first()) }

        // ── editing day schedule ──
        Regex("editing days?(?: to| on| is| are| for)? (.+)").find(t)?.let { m ->
            val d = RoutineManager.parseDays(m.groupValues[1])
            if (d.isNotEmpty()) {
                val time = Regex("(\\d{1,2}):(\\d{2})").find(m.groupValues[1])?.let { "%02d:%02d".format(it.groupValues[1].toInt().coerceIn(0, 23), it.groupValues[2].toInt().coerceIn(0, 59)) } ?: prefs.editingTime
                return cmd(Cat.SETTINGS_COMMAND, Level.Action, "Remind you every ${d.joinToString(", ") { RoutineManager.dayName(it) }} at $time?") {
                    RoutineManager.setEditingDays(AutomationEngine(ctx, db), prefs, d, time)
                    "Done. I'll notify you on ${d.joinToString(" and ") { RoutineManager.dayName(it) }} at $time that it's your editing day. It may arrive a few minutes late if the phone is in deep sleep."
                }
            }
        }
        Regex("editing app(?: is| to)? (.+)").find(t)?.let { m ->
            val q = m.groupValues[1].trim()
            return cmd(Cat.SETTINGS_COMMAND) {
                val app = device.listApps().firstOrNull { it.first.contains(q, ignoreCase = true) }
                if (app == null) "I couldn't find an app called \"$q\"." else { prefs.editingApp = app.second; "Okay, ${app.first} is your editing app." }
            }
        }
        if (has("editing template", "show template", "description template"))
            return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { "Here is your editing template:\n" + prefs.editingTemplate + "\n\nYou can edit and copy it in the Command Center." }

        // ── editing mode ──
        if (has("editing mode")) {
            if (toggle == null) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { "Editing mode is ${if (prefs.editingActive) "on" else "off"}. $unclear" }
            return if (toggle) cmd(Cat.SETTINGS_COMMAND, Level.Action, "Turn on editing mode? I may open your editing app or sound settings.") {
                val base = RoutineManager.editingOn(prefs)
                val opened = if (prefs.editingApp.isNotBlank()) {
                    if (device.openPackage(prefs.editingApp)) " Opening your editing app." else " I couldn't open the editing app from here; Android blocks that from the background."
                } else " " + device.openSettings(Settings.ACTION_SOUND_SETTINGS, "sound settings") + " Do Not Disturb can be turned on there."
                "$base$opened Say \"show editing template\" for your description template."
            } else cmd(Cat.SETTINGS_COMMAND, tag = "basic") { RoutineManager.editingOff(prefs) }
        }

        // ── night mode ──
        if (has("night mode")) {
            Regex("(\\d{1,2}:\\d{2})\\s*(?:to|till|until|-)\\s*(\\d{1,2}:\\d{2})").find(t)?.let { m ->
                fun fix(s: String) = s.split(":").let { "%02d:%02d".format(it[0].toInt().coerceIn(0, 23), it[1].toInt().coerceIn(0, 59)) }
                return cmd(Cat.SETTINGS_COMMAND, tag = "basic") {
                    prefs.nightStart = fix(m.groupValues[1]); prefs.nightEnd = fix(m.groupValues[2]); prefs.nightScheduleOn = true
                    RoutineManager.syncAll(ctx, prefs)
                    "Night mode will turn on at ${prefs.nightStart} and off at ${prefs.nightEnd} every day."
                }
            }
            if (toggle == null) return cmd(Cat.SETTINGS_COMMAND, tag = "basic") { "Night mode is ${if (prefs.nightActive) "on" else "off"}. $unclear" }
            return if (toggle) cmd(Cat.SETTINGS_COMMAND, tag = "basic") { RoutineManager.nightOn(ctx, prefs) }
            else cmd(Cat.SETTINGS_COMMAND, tag = "basic") { RoutineManager.nightOff(prefs) }
        }
        return null
    }
}
