package com.nova.ai.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.control.ShizukuManager
import com.nova.ai.media.AllFiles
import com.nova.ai.media.Saf
import com.nova.ai.permissions.DashFix
import com.nova.ai.permissions.DashItem
import com.nova.ai.permissions.DashState
import com.nova.ai.permissions.DashboardProbe
import com.nova.ai.permissions.PermissionDashboard
import com.nova.ai.permissions.PermissionMemory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun fixLabel(f: DashFix): String = when (f) {
    DashFix.NONE -> ""
    DashFix.OPEN_ACCESSIBILITY -> "Open Accessibility settings"
    DashFix.ENABLE_SCREEN_ACTIONS -> "Turn on screen actions"
    DashFix.SHIZUKU_INSTALL -> "Get Shizuku"
    DashFix.SHIZUKU_OPEN -> "Open Shizuku"
    DashFix.SHIZUKU_REQUEST -> "Allow Nova in Shizuku"
    DashFix.SHIZUKU_RECONNECT -> "Reconnect"
    DashFix.SHIZUKU_UPDATE -> "Update Shizuku"
    DashFix.OPEN_ALL_FILES -> "Open All files access"
    DashFix.PICK_FOLDER -> "Choose a folder"
    DashFix.REQUEST_MIC -> "Allow microphone"
    DashFix.REQUEST_NOTIFICATIONS -> "Allow notifications"
    DashFix.OPEN_APP_SETTINGS -> "Open app settings"
    DashFix.OPEN_NOTIFICATION_SETTINGS -> "Open notification settings"
    DashFix.START_SCREEN_CAPTURE -> "Start Screen Vision"
    DashFix.OPEN_NETWORK_SETTINGS -> "Open network settings"
}

/**
 * One accurate permission and capability dashboard. Every row is read from Android each time the screen opens or you come back to it;
 * nothing is shown as granted unless Android says so, and a button appears only for something that is actually missing.
 */
@Composable
internal fun PermissionDashboardPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val scope = rememberCoroutineScope()
    var bump by remember { mutableStateOf(0) }
    var items by remember { mutableStateOf<List<DashItem>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        PermissionMemory.afterResult(ctx, PermissionMemory.findActivity(ctx), res.keys.toList()); bump++
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            if (Saf.persist(ctx, u)) { vm.prefs.storageTrees = vm.prefs.storageTrees + u.toString(); msg = "Folder added." }
            else msg = "Android didn't keep that folder's permission."
            bump++
        }
    }

    LaunchedEffect(tick, bump, vm.visionActive) {
        items = withContext(Dispatchers.IO) { PermissionDashboard.build(DashboardProbe.collect(ctx, vm.prefs, vm.visionActive)) }
        loaded = true
    }

    fun ask(perm: String) { PermissionMemory.markAsked(ctx, listOf(perm)); permLauncher.launch(arrayOf(perm)) }
    fun url(u: String) { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { msg = "No browser to open $u" } }

    fun run(f: DashFix) {
        msg = ""
        when (f) {
            DashFix.NONE -> Unit
            DashFix.OPEN_ACCESSIBILITY -> openSystem(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS)
            DashFix.ENABLE_SCREEN_ACTIONS -> { vm.prefs.screenActionsOn = true; bump++ }
            DashFix.SHIZUKU_INSTALL, DashFix.SHIZUKU_UPDATE -> url("https://shizuku.rikka.app/download/")
            DashFix.SHIZUKU_OPEN -> {
                val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else msg = "The Shizuku app isn't installed."
            }
            DashFix.SHIZUKU_REQUEST -> scope.launch { ShizukuManager.requestPermission(); bump++ }
            DashFix.SHIZUKU_RECONNECT -> scope.launch { ShizukuManager.reconnect(); bump++ }
            DashFix.OPEN_ALL_FILES -> msg = AllFiles.openSettings(ctx)
            DashFix.PICK_FOLDER -> folderLauncher.launch(null)
            DashFix.REQUEST_MIC -> ask(Manifest.permission.RECORD_AUDIO)
            DashFix.REQUEST_NOTIFICATIONS -> ask(Manifest.permission.POST_NOTIFICATIONS)
            DashFix.OPEN_APP_SETTINGS -> openAppSettings(ctx)
            DashFix.OPEN_NOTIFICATION_SETTINGS -> try {
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { openAppSettings(ctx) }
            DashFix.START_SCREEN_CAPTURE -> vm.requestVision()
            DashFix.OPEN_NETWORK_SETTINGS -> openSystem(ctx, Settings.ACTION_WIRELESS_SETTINGS)
        }
    }

    if (!loaded) { GText("Checking what Android allows…", size = 13.sp, color = g.subtext); return }
    GText(PermissionDashboard.summary(items), size = 13.sp, color = if (PermissionDashboard.allClear(items)) Color(0xFF69F0AE) else Color(0xFFFFB74D))
    GText("Read from Android just now. Shizuku, Accessibility and All files access are separate permissions: one never grants another.", size = 12.sp, color = g.subtext)
    if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.accent)
    items.groupBy { it.group }.forEach { (group, rows) ->
        GlassSettingSection(group) {
            rows.forEach { it ->
                val color = when (it.state) { DashState.OK -> Color(0xFF69F0AE); DashState.ATTENTION -> Color(0xFFFF8A80); DashState.NOT_APPLICABLE -> g.subtext }
                val label = when (it.state) { DashState.OK -> "● OK"; DashState.ATTENTION -> "● Needs attention"; DashState.NOT_APPLICABLE -> "○ Optional / n.a." }
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row { GText(it.title, Modifier.weight(1f), weight = FontWeight.SemiBold); GText(label, size = 12.sp, color = color) }
                        GText(it.detail, size = 12.sp, color = g.subtext)
                        if (it.fix != DashFix.NONE) GlassButton(fixLabel(it.fix), { run(it.fix) }, primary = it.state == DashState.ATTENTION)
                    }
                }
            }
        }
    }
}
