package com.nova.ai.accessibility

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.nova.ai.screen.ActionValidator
import com.nova.ai.security.Prefs

/** Reads the real accessibility state from Android instead of assuming it. */
object AccessibilitySettings {
    private const val PKG = "com.nova.ai"
    private const val CLS = "com.nova.ai.accessibility.NovaAccessibilityService"

    /** What Android's Settings say (null if unreadable). This can be true while the service is not connected. */
    fun enabledInSettings(ctx: Context): Boolean? = try {
        val master = Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        val raw = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        master && EnabledServiceParser.contains(raw, ctx.packageName.ifBlank { PKG }, CLS)
    } catch (e: Exception) { null }

    fun status(ctx: Context, prefs: Prefs): A11yStatus {
        val svc = NovaAccessibilityService.instance
        val fg = NovaAccessibilityService.activePackage()
        return A11yStatus(
            enabledInSettings = enabledInSettings(ctx),
            connected = svc != null,
            screenReadable = svc?.canReadScreen() == true,
            screenActionsOn = prefs.screenActionsOn,
            foreground = fg,
            blockedForeground = ActionValidator.packageBlocked(fg)
        )
    }

    /** Opens the Accessibility settings page. */
    fun settingsIntent(): Intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
