package com.nova.ai.forge

/** Recognises "ek cafe ki website banao" / "build a landing page for my gym". Questions are ignored. */
object ForgeIntent {
    private val subject = Regex("(web\\s?site|web\\s?page|landing\\s?page|वेबसाइट)", RegexOption.IGNORE_CASE)
    private val verb = Regex("\\b(build|create|make|design|generate|develop|bana|banao|banado|banana|banaye|banaiye)\\b|बना", RegexOption.IGNORE_CASE)
    private val question = Regex("^(how|what|why|which|when|who|can you explain|kaise|kya|kyun|kyu|kaun)\\b", RegexOption.IGNORE_CASE)

    /** Returns the request text to build from, or null when this is not a build request. */
    fun extract(text: String): String? {
        val t = text.trim()
        if (t.isEmpty() || t.endsWith("?") || t.endsWith("？")) return null
        if (question.containsMatchIn(t)) return null
        if (!subject.containsMatchIn(t) || !verb.containsMatchIn(t)) return null
        return t
    }
}
