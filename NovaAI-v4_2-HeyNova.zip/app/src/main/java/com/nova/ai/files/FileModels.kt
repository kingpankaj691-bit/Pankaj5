package com.nova.ai.files

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pure Kotlin (no Android types) so every rule here is unit-testable on the JVM.
 * File Manager, Part 1: models, type detection, path rules, sorting and search matching.
 */

enum class FileKind(val glyph: String, val label: String) {
    PDF("📕", "PDF"), WORD("📘", "Word document"), SHEET("📗", "Spreadsheet"), SLIDES("📙", "Presentation"),
    TEXT("📝", "Text"), CODE("💻", "Code"), DATA("🧾", "Data file"), WEB("🌐", "Web page"),
    IMAGE("🖼", "Image"), VIDEO("🎬", "Video"), AUDIO("🎵", "Audio"), ARCHIVE("🗜", "Archive"),
    APK("📦", "APK"), FOLDER("📁", "Folder"), OTHER("📎", "File")
}

/** One file or folder as shown in the File Manager. [uri] is set for MediaStore items; folder-browsed items use [path] only. */
data class FileItem(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: FileKind,
    val uri: String? = null,
    val mime: String = "",
    val folder: String = ""
) {
    val ext: String get() = FileTypes.extOf(name)
}

object FileTypes {
    private val table = HashMap<String, FileKind>()
    private val mimes = HashMap<String, String>()

    private fun reg(kind: FileKind, vararg exts: String) { exts.forEach { table[it] = kind } }
    private fun mime(m: String, vararg exts: String) { exts.forEach { mimes[it] = m } }

    init {
        reg(FileKind.PDF, "pdf")
        reg(FileKind.WORD, "doc", "docx", "dot", "dotx", "odt", "rtf")
        reg(FileKind.SHEET, "xls", "xlsx", "xlsm", "ods")
        reg(FileKind.SLIDES, "ppt", "pptx", "odp")
        reg(FileKind.TEXT, "txt", "md", "log", "ini", "cfg", "conf", "properties")
        reg(FileKind.CODE, "kt", "kts", "java", "js", "jsx", "ts", "tsx", "py", "c", "cpp", "h", "cs", "go", "rs", "php", "rb", "swift",
            "sh", "gradle", "sql", "yml", "yaml", "toml", "css", "dart", "lua", "bat", "aidl")
        reg(FileKind.DATA, "csv", "tsv", "json", "xml")
        reg(FileKind.WEB, "html", "htm", "xhtml")
        reg(FileKind.IMAGE, "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg", "dng")
        reg(FileKind.VIDEO, "mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv")
        reg(FileKind.AUDIO, "mp3", "m4a", "aac", "wav", "ogg", "opus", "flac", "amr", "mid", "wma")
        reg(FileKind.ARCHIVE, "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "jar")
        reg(FileKind.APK, "apk", "apks", "xapk", "apkm")

        mime("application/pdf", "pdf"); mime("application/msword", "doc")
        mime("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx")
        mime("application/vnd.ms-excel", "xls")
        mime("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx")
        mime("application/vnd.ms-powerpoint", "ppt")
        mime("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx")
        mime("text/plain", "txt", "log", "ini", "cfg", "conf", "properties", "kt", "kts", "java", "js", "py", "c", "cpp", "h", "sh", "gradle", "sql", "yml", "yaml", "toml", "md")
        mime("text/csv", "csv"); mime("application/json", "json"); mime("text/xml", "xml"); mime("text/html", "html", "htm")
        mime("application/zip", "zip"); mime("application/vnd.android.package-archive", "apk")
    }

    fun extOf(name: String): String {
        val i = name.lastIndexOf('.')
        return if (i <= 0 || i == name.length - 1) "" else name.substring(i + 1).lowercase(Locale.ROOT)
    }

    fun kindOf(name: String): FileKind = table[extOf(name)] ?: FileKind.OTHER

    fun kindOfMime(mime: String): FileKind {
        val m = mime.lowercase(Locale.ROOT)
        return when {
            m.startsWith("image/") -> FileKind.IMAGE
            m.startsWith("video/") -> FileKind.VIDEO
            m.startsWith("audio/") -> FileKind.AUDIO
            m == "application/pdf" -> FileKind.PDF
            m == "application/vnd.android.package-archive" -> FileKind.APK
            m == "application/zip" || m == "application/x-zip-compressed" -> FileKind.ARCHIVE
            m.startsWith("text/") -> FileKind.TEXT
            else -> FileKind.OTHER
        }
    }

    /** Best guess from the file name; Android's MimeTypeMap is consulted first by the caller. */
    fun mimeOf(name: String): String = mimes[extOf(name)] ?: "application/octet-stream"

    val documentKinds: Set<FileKind> = setOf(FileKind.PDF, FileKind.WORD, FileKind.SHEET, FileKind.SLIDES, FileKind.TEXT, FileKind.DATA, FileKind.WEB)

    fun extsOf(kinds: Set<FileKind>): List<String> = table.filterValues { it in kinds }.keys.sorted()

    /** Text Nova can read directly (no conversion needed). */
    fun isPlainText(kind: FileKind) = kind == FileKind.TEXT || kind == FileKind.CODE || kind == FileKind.DATA || kind == FileKind.WEB

    /** Words people use for a file type, in English, Hindi (Roman) and Hinglish. Used by the search box and, in Part 3, by voice commands. */
    fun kindsForWord(word: String): Set<FileKind> = when (word.lowercase(Locale.ROOT)) {
        "pdf" -> setOf(FileKind.PDF)
        "doc", "docx", "word" -> setOf(FileKind.WORD)
        "xls", "xlsx", "excel", "sheet", "spreadsheet" -> setOf(FileKind.SHEET)
        "ppt", "pptx", "presentation", "slides" -> setOf(FileKind.SLIDES)
        "docs", "documents", "document" -> documentKinds
        "image", "images", "photo", "photos", "picture", "pictures", "tasveer" -> setOf(FileKind.IMAGE)
        "video", "videos" -> setOf(FileKind.VIDEO)
        "audio", "music", "song", "songs", "gaana", "gaane" -> setOf(FileKind.AUDIO)
        "apk", "apks", "app", "apps" -> setOf(FileKind.APK)
        "zip", "archive", "archives", "rar" -> setOf(FileKind.ARCHIVE)
        "code", "source" -> setOf(FileKind.CODE)
        "text", "txt" -> setOf(FileKind.TEXT)
        "json", "xml", "csv", "data" -> setOf(FileKind.DATA)
        "html", "web" -> setOf(FileKind.WEB)
        else -> emptySet()
    }
}

enum class FileSection(val label: String, val glyph: String) {
    RECENT("Recent Files", "🕘"), DOCUMENTS("Documents", "📄"), IMAGES("Images", "🖼"), VIDEOS("Videos", "🎬"),
    AUDIO("Audio", "🎵"), DOWNLOADS("Downloads", "⬇️"), APKS("APKs", "📦"), ARCHIVES("Archives", "🗜")
}

enum class SortMode(val label: String) { DATE("Newest"), NAME("Name"), SIZE("Size"), TYPE("Type") }

object FileSort {
    /** Folders always first. DATE newest first, SIZE biggest first, NAME and TYPE ascending. */
    fun sort(items: List<FileItem>, mode: SortMode): List<FileItem> {
        val cmp: Comparator<FileItem> = when (mode) {
            SortMode.DATE -> compareByDescending<FileItem> { it.modified }.thenBy { it.name.lowercase(Locale.ROOT) }
            SortMode.NAME -> compareBy<FileItem> { it.name.lowercase(Locale.ROOT) }
            SortMode.SIZE -> compareByDescending<FileItem> { it.size }.thenBy { it.name.lowercase(Locale.ROOT) }
            SortMode.TYPE -> compareBy<FileItem> { it.kind.label }.thenBy { it.name.lowercase(Locale.ROOT) }
        }
        return items.sortedWith(compareByDescending<FileItem> { it.isDir }.then(cmp))
    }
}

object FileFormat {
    fun size(b: Long): String = when {
        b < 0 -> "—"
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun date(ms: Long): String = if (ms <= 0) "unknown date" else SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

    fun shortDate(ms: Long): String = if (ms <= 0) "" else SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))

    fun rowSubtitle(i: FileItem): String {
        val where = PathRules.leaf(i.folder)
        return if (i.isDir) listOf("Folder", FileFormat.shortDate(i.modified)).filter { it.isNotBlank() }.joinToString(" · ")
        else listOf(size(i.size), shortDate(i.modified), where).filter { it.isNotBlank() }.joinToString(" · ")
    }

    fun percent(part: Long, whole: Long): Float = if (whole <= 0) 0f else (part.toDouble() / whole).toFloat().coerceIn(0f, 1f)

    /** "5mb", "200 KB", "1.5gb" → bytes. Returns null when it isn't a size. */
    fun parseSize(s: String): Long? {
        val m = Regex("^\\s*(\\d+(?:\\.\\d+)?)\\s*(b|kb|k|mb|m|gb|g)?\\s*$", RegexOption.IGNORE_CASE).find(s) ?: return null
        val n = m.groupValues[1].toDoubleOrNull() ?: return null
        val mul = when (m.groupValues[2].lowercase(Locale.ROOT)) { "kb", "k" -> 1024.0; "mb", "m" -> 1048576.0; "gb", "g" -> 1073741824.0; else -> 1.0 }
        return (n * mul).toLong()
    }
}

/** Rules about which paths Nova will even try to touch. Android enforces its own limits on top of these. */
object PathRules {
    fun normalize(p: String): String = if (p.length > 1) p.trimEnd('/') else p

    /** True when [path] is [root] itself or lies inside it. Works on already-canonical paths. */
    fun isWithin(root: String, path: String): Boolean {
        val r = normalize(root); val p = normalize(path)
        return p == r || p.startsWith("$r/")
    }

    fun isWithinAny(roots: List<String>, path: String) = roots.any { isWithin(it, path) }

    fun leaf(path: String): String = normalize(path).substringAfterLast('/')

    fun parent(path: String, root: String): String? {
        val p = normalize(path); val r = normalize(root)
        if (p == r || !isWithin(r, p)) return null
        return p.substringBeforeLast('/', r).ifBlank { r }
    }

    /** Folder chain from the volume root to [path], for a tappable breadcrumb. */
    fun breadcrumb(path: String, root: String): List<Pair<String, String>> {
        val p = normalize(path); val r = normalize(root)
        if (!isWithin(r, p)) return emptyList()
        val out = ArrayList<Pair<String, String>>(); out.add("Storage" to r)
        var cur = r
        p.removePrefix(r).split('/').filter { it.isNotEmpty() }.forEach { seg -> cur = "$cur/$seg"; out.add(seg to cur) }
        return out
    }

    private val androidPrivate = Regex("^(/storage/[^/]+|/sdcard|/mnt/[^/]+/[^/]+|/storage/emulated/[0-9]+)/Android/(data|obb)(/.*)?$")
    private val systemRoots = listOf("/data", "/system", "/vendor", "/proc", "/sys", "/dev", "/cache", "/mnt/runtime", "/apex", "/product")

    /**
     * Why a path is off-limits, or null if it is fine to try. Nova never claims access to other apps' private folders:
     * Android blocks them, and so do we, with an honest message instead of an empty list.
     */
    fun blockedReason(path: String): String? {
        val p = normalize(path)
        if (androidPrivate.matches(p)) return "Android keeps other apps' folders (Android/data and Android/obb) private. Nova can't list them."
        if (systemRoots.any { p == it || p.startsWith("$it/") }) return "This is a protected system or private app-data location. Android doesn't give apps access to it."
        if (p.split('/').any { it == ".." }) return "That path isn't allowed."
        return null
    }
}

data class SearchQuery(
    val text: String = "",
    val exts: Set<String> = emptySet(),
    val kinds: Set<FileKind> = emptySet(),
    val folder: String = "",
    val sinceMs: Long? = null,
    val untilMs: Long? = null,
    val minSize: Long = 0L
) {
    val isEmpty: Boolean get() = text.isBlank() && exts.isEmpty() && kinds.isEmpty() && folder.isBlank() && sinceMs == null && untilMs == null && minSize == 0L
    val hasTypeFilter: Boolean get() = exts.isNotEmpty() || kinds.isNotEmpty()

    /** Used by the folder walker; the MediaStore search expresses the same rules in SQL. */
    fun matches(i: FileItem): Boolean {
        if (i.isDir) return false
        val n = i.name.lowercase(Locale.ROOT)
        if (text.isNotBlank() && !text.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.isNotEmpty() }.all { n.contains(it) }) return false
        if (hasTypeFilter && !(i.ext in exts || i.kind in kinds)) return false
        if (folder.isNotBlank() && !(i.folder + "/" + i.path).lowercase(Locale.ROOT).contains(folder.lowercase(Locale.ROOT))) return false
        if (sinceMs != null && i.modified < sinceMs) return false
        if (untilMs != null && i.modified >= untilMs) return false
        if (i.size < minSize) return false
        return true
    }

    fun withFilters(extraKinds: Set<FileKind>, days: Int, folderText: String, now: Long = System.currentTimeMillis()): SearchQuery = copy(
        kinds = kinds + extraKinds,
        sinceMs = sinceMs ?: if (days > 0) now - days * 86_400_000L else null,
        folder = folder.ifBlank { folderText.trim() }
    )
}

object QueryBox {
    /**
     * Tiny query language for the search box: plain words search file names, plus optional filters
     * `ext:pdf,docx`  `type:images`  `in:download`  `days:7`  `min:5mb`.
     */
    fun parse(raw: String, now: Long = System.currentTimeMillis()): SearchQuery {
        val words = ArrayList<String>(); val exts = LinkedHashSet<String>(); val kinds = LinkedHashSet<FileKind>()
        var folder = ""; var since: Long? = null; var min = 0L
        for (tok in raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }) {
            val k = tok.substringBefore(':', "").lowercase(Locale.ROOT); val v = tok.substringAfter(':', "")
            when {
                k == "ext" && v.isNotBlank() -> v.split(',').map { it.trim().trimStart('.').lowercase(Locale.ROOT) }.filter { it.isNotEmpty() }.forEach { exts.add(it) }
                k == "type" && v.isNotBlank() -> kinds.addAll(FileTypes.kindsForWord(v))
                k == "in" && v.isNotBlank() -> folder = v
                k == "days" && v.toIntOrNull() != null -> since = now - v.toInt().coerceIn(1, 3650) * 86_400_000L
                k == "min" && FileFormat.parseSize(v) != null -> min = FileFormat.parseSize(v) ?: 0L
                else -> words.add(tok)
            }
        }
        return SearchQuery(words.joinToString(" "), exts, kinds, folder, since, null, min)
    }
}
