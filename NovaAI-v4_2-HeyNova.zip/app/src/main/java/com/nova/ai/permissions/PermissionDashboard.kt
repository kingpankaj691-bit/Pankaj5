package com.nova.ai.permissions

import com.nova.ai.accessibility.A11yStatus
import com.nova.ai.control.ShizukuSnapshot
import com.nova.ai.files.FileAccessState

enum class DashState { OK, ATTENTION, NOT_APPLICABLE }

enum class DashFix {
    NONE, OPEN_ACCESSIBILITY, ENABLE_SCREEN_ACTIONS, SHIZUKU_INSTALL, SHIZUKU_OPEN, SHIZUKU_REQUEST, SHIZUKU_RECONNECT, SHIZUKU_UPDATE,
    OPEN_ALL_FILES, PICK_FOLDER, REQUEST_MIC, REQUEST_NOTIFICATIONS, OPEN_APP_SETTINGS, OPEN_NOTIFICATION_SETTINGS, START_SCREEN_CAPTURE, OPEN_NETWORK_SETTINGS
}

data class DashItem(val id: String, val group: String, val title: String, val state: DashState, val detail: String, val fix: DashFix = DashFix.NONE)

/** Everything the dashboard shows, each read from Android at that moment (never remembered, never assumed). */
data class DashInputs(
    val a11y: A11yStatus,
    val shizuku: ShizukuSnapshot,
    val files: FileAccessState,
    val safTotal: Int,
    val safValid: Int,
    val micGranted: Boolean,
    val micPermanentlyDenied: Boolean,
    val notificationsAllowed: Boolean,
    /** Android 13+ runtime permission is missing and Android would still show its dialog. */
    val notificationsCanAsk: Boolean,
    val screenCaptureActive: Boolean,
    /** null = could not be checked. */
    val online: Boolean?
)

/**
 * One accurate list of what works and what doesn't. Each item is separate: Accessibility, the Screen Actions switch, the three
 * Shizuku layers, All files access, chosen folders, microphone, notifications, screen capture and internet are never merged, and
 * one never stands in for another. A fix button exists only when something is actually missing. Pure Kotlin (unit-tested).
 */
object PermissionDashboard {
    const val G_VOICE = "Voice and network"
    const val G_SCREEN = "Screen control"
    const val G_FILES = "Files"
    const val G_SHIZUKU = "Shizuku (optional)"

    fun build(i: DashInputs): List<DashItem> {
        val out = ArrayList<DashItem>()

        // Voice and network
        out += if (i.micGranted) DashItem("mic", G_VOICE, "Microphone", DashState.OK, "Allowed")
        else DashItem("mic", G_VOICE, "Microphone", DashState.ATTENTION,
            if (i.micPermanentlyDenied) "Denied, and Android won't ask again. Allow it in app settings." else "Not allowed yet. Nova can't hear you without it.",
            if (i.micPermanentlyDenied) DashFix.OPEN_APP_SETTINGS else DashFix.REQUEST_MIC)
        out += if (i.notificationsAllowed) DashItem("notif", G_VOICE, "Notifications", DashState.OK, "Allowed")
        else DashItem("notif", G_VOICE, "Notifications", DashState.ATTENTION,
            "Blocked. The \"microphone is on\" notification must be visible while Background Voice runs.",
            if (i.notificationsCanAsk) DashFix.REQUEST_NOTIFICATIONS else DashFix.OPEN_NOTIFICATION_SETTINGS)
        out += when (i.online) {
            true -> DashItem("net", G_VOICE, "Internet connection", DashState.OK, "Connected (Android reports a working network)")
            false -> DashItem("net", G_VOICE, "Internet connection", DashState.ATTENTION, "No working internet. Searches and AI answers need it.", DashFix.OPEN_NETWORK_SETTINGS)
            null -> DashItem("net", G_VOICE, "Internet connection", DashState.NOT_APPLICABLE, "Couldn't be checked")
        }

        // Screen control
        val a = i.a11y
        out += when {
            !a.connected -> DashItem("a11y", G_SCREEN, "Accessibility service", DashState.ATTENTION, a.explain(), DashFix.OPEN_ACCESSIBILITY)
            !a.screenReadable -> DashItem("a11y", G_SCREEN, "Accessibility service", DashState.ATTENTION,
                "Connected, but the current screen can't be read right now (the app hides its UI, or the screen is changing).")
            else -> DashItem("a11y", G_SCREEN, "Accessibility service", DashState.OK, "Connected and the screen is readable (app: ${a.foreground.ifBlank { "unknown" }})")
        }
        out += if (a.screenActionsOn) DashItem("actions", G_SCREEN, "Screen actions switch", DashState.OK, "On: Nova may tap, type and scroll when you ask")
        else DashItem("actions", G_SCREEN, "Screen actions switch", DashState.ATTENTION, "Off: Nova can read the screen but won't tap or type.", DashFix.ENABLE_SCREEN_ACTIONS)
        out += if (i.screenCaptureActive) DashItem("capture", G_SCREEN, "Screen capture (Screen Vision)", DashState.OK, "Running, notification showing")
        else DashItem("capture", G_SCREEN, "Screen capture (Screen Vision)", DashState.NOT_APPLICABLE, "Not running (optional). Android asks for approval each time you start it.", DashFix.START_SCREEN_CAPTURE)

        // Files
        val f = i.files
        out += when {
            !f.allFilesAvailable -> DashItem("allfiles", G_FILES, "All files access", DashState.NOT_APPLICABLE, "Not offered in this build or Android version")
            f.allFilesGranted -> DashItem("allfiles", G_FILES, "All files access", DashState.OK, "Granted")
            else -> DashItem("allfiles", G_FILES, "All files access", DashState.ATTENTION, "Not granted. Needed to find documents and to change files by path.", DashFix.OPEN_ALL_FILES)
        }
        out += when {
            i.safTotal == 0 -> DashItem("saf", G_FILES, "Chosen folders (SAF)", DashState.NOT_APPLICABLE, "No folder added yet (optional)", DashFix.PICK_FOLDER)
            i.safValid == i.safTotal -> DashItem("saf", G_FILES, "Chosen folders (SAF)", DashState.OK, "${i.safTotal} folder(s), Android still holds the permission for each")
            else -> DashItem("saf", G_FILES, "Chosen folders (SAF)", DashState.ATTENTION, "${i.safValid} of ${i.safTotal} folders still have permission. Remove the lost ones and add them again.", DashFix.PICK_FOLDER)
        }

        // Shizuku: three separate layers, none of which is Accessibility or All files access
        val z = i.shizuku
        val installed = z.installed || z.running
        out += when {
            !installed -> DashItem("sz_service", G_SHIZUKU, "Shizuku service", DashState.NOT_APPLICABLE, "Not installed (optional, only for advanced system control)", DashFix.SHIZUKU_INSTALL)
            !z.running -> DashItem("sz_service", G_SHIZUKU, "Shizuku service", DashState.ATTENTION, "Installed but not running. Open Shizuku and start it.", DashFix.SHIZUKU_OPEN)
            z.serverVersion < 11 -> DashItem("sz_service", G_SHIZUKU, "Shizuku service", DashState.ATTENTION, "Running, but version ${z.serverVersion} is too old (needs 11 or newer).", DashFix.SHIZUKU_UPDATE)
            else -> DashItem("sz_service", G_SHIZUKU, "Shizuku service", DashState.OK, "Running (${z.mode}, version ${z.serverVersion})")
        }
        out += when {
            !z.running -> DashItem("sz_perm", G_SHIZUKU, "Shizuku permission for Nova", DashState.NOT_APPLICABLE, "Needs the Shizuku service first")
            z.granted -> DashItem("sz_perm", G_SHIZUKU, "Shizuku permission for Nova", DashState.OK, "Granted (this is separate from Accessibility and All files access)")
            z.permanentlyDenied -> DashItem("sz_perm", G_SHIZUKU, "Shizuku permission for Nova", DashState.ATTENTION, "Denied. Allow Nova AI inside the Shizuku app.", DashFix.SHIZUKU_OPEN)
            else -> DashItem("sz_perm", G_SHIZUKU, "Shizuku permission for Nova", DashState.ATTENTION, "Not granted yet.", DashFix.SHIZUKU_REQUEST)
        }
        out += when {
            !z.running || !z.granted -> DashItem("sz_bind", G_SHIZUKU, "Shizuku binder / shell connection", DashState.NOT_APPLICABLE, "Needs the service and the permission first")
            z.serviceBound -> DashItem("sz_bind", G_SHIZUKU, "Shizuku binder / shell connection", DashState.OK, "Shell service connected")
            else -> DashItem("sz_bind", G_SHIZUKU, "Shizuku binder / shell connection", DashState.ATTENTION, "Permission is granted but the shell service isn't connected.", DashFix.SHIZUKU_RECONNECT)
        }
        return out
    }

    /** Never says everything is granted unless every applicable item is OK. */
    fun summary(items: List<DashItem>): String {
        val bad = items.filter { it.state == DashState.ATTENTION }
        val ok = items.count { it.state == DashState.OK }
        val na = items.count { it.state == DashState.NOT_APPLICABLE }
        return if (bad.isEmpty()) "$ok checks passed" + (if (na > 0) ", $na optional or not applicable" else "") + ". Nothing needs attention right now."
        else "${bad.size} need attention: ${bad.joinToString { it.title }}. $ok are fine."
    }

    fun allClear(items: List<DashItem>) = items.none { it.state == DashState.ATTENTION }
}

/** Decides whether Android will still show a permission dialog. */
object PermissionRules {
    /**
     * A permission we already asked for, that is still denied, and for which Android no longer explains why, will never show its
     * dialog again: the only fix is the app settings page. (Before the first request the "rationale" flag is false too, hence [askedBefore].)
     */
    fun permanentlyDenied(askedBefore: Boolean, granted: Boolean, showRationale: Boolean): Boolean = askedBefore && !granted && !showRationale
}
