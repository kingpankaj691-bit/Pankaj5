package com.nova.ai.developer

import com.nova.ai.ai.AiResult
import com.nova.ai.core.AIProvider

/**
 * Developer helpers. Code is generated, explained and shown for the user to read, copy or save. Nova never runs generated or
 * downloaded code, and never launches Termux or any shell.
 */
object CodeAssistant {
    /** Added to the coding prompt so answers never imply Nova will run anything. */
    const val POLICY = " Nova never runs code itself, so never say you ran, installed or executed anything; show the code, explain what it does, " +
        "and let the user review, copy or save it. Warn briefly before any code that deletes, moves or overwrites files."

    private val fence = Regex("```([A-Za-z0-9+#_-]*)\\n([\\s\\S]*?)```")
    fun extractCode(text: String): List<Pair<String, String>> = fence.findAll(text).map { it.groupValues[1] to it.groupValues[2].trimEnd() }.toList()

    /** Explains a sanitized crash log and suggests a fix as text. */
    suspend fun analyze(ai: AIProvider, log: String): String {
        val sys = "You are a senior Android/Kotlin engineer. Explain the likely cause of this crash in plain words, then suggest a minimal fix " +
            "as a Kotlin snippet or Gradle change in fenced blocks, and one test idea. The app is Nova AI (package com.nova.ai, minSdk 26, Kotlin, Compose). " +
            "Be honest about uncertainty. Do not invent APIs or library versions." + POLICY
        return when (val r = ai.chat(listOf(true to "Crash log (secrets removed):\n" + log.take(9000)), sys, null)) {
            is AiResult.Ok -> r.text.trim()
            is AiResult.Err -> "⚠ " + r.msg
        }
    }
}
