package com.nova.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatPane(vm: NovaViewModel, dev: Boolean, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val list = if (dev) vm.devMessages else vm.messages
    val state = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val mic = rememberMicAction(vm)
    LaunchedEffect(list.size, vm.generating) {
        if (list.isNotEmpty()) state.animateScrollToItem(if (vm.generating) list.size else list.size - 1)
    }
    val lastNova = list.indexOfLast { !it.fromUser }
    fun submit() { if (input.isNotBlank()) { vm.send(input, dev); input = "" } }

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                GText(if (dev) "Developer" else "Chat", size = 24.sp, weight = FontWeight.SemiBold)
                GText(if (dev) "Code assistant • Gemini" else "Personality: ${vm.personality.label}", size = 12.sp, color = g.subtext)
            }
            StatusPill(vm.displayStatus)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
            itemsIndexed(list) { i, m ->
                MessageBubble(
                    m, animate = i == list.lastIndex, isLastNova = i == lastNova,
                    speaking = vm.status == "Speaking", showActions = true,
                    onReplay = { vm.voice.speak(m.text) }, onRegenerate = { vm.regenerate(dev) }
                )
            }
            if (vm.generating) item { TypingIndicator() }
        }
        if (dev && vm.prefs.debugMode && vm.lastDebug.isNotBlank())
            GText("debug: ${vm.lastDebug}", size = 11.sp, color = g.subtext)
        if (dev) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Explain this code", "Fix this error", "Convert to Kotlin", "Android snippet", "Explain command")
                    .forEach { q -> GlassChip(q, false, { input = "$q: " }) }
            }
        }
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassTextField(
                input, { input = it }, Modifier.weight(1f), placeholder = if (dev) "Ask about code…" else "Ask Nova…",
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { submit() })
            )
            if (vm.generating) GlassIconButton("■", "Stop generation", { vm.stopGeneration() }, active = true)
            else {
                GlassIconButton("➤", "Send message", { submit() })
                if (!dev) GlassIconButton("🎤", "Speak to Nova", mic)
            }
            if (!dev) GlassIconButton("⏹", "Stop speaking", { vm.voice.stopSpeaking() })
        }
    }
}
