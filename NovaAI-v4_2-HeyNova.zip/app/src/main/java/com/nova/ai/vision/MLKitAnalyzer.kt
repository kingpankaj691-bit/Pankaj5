package com.nova.ai.vision

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage

enum class VisionTask { NONE, DESCRIBE, READ_TEXT }

/**
 * CameraX analyzer. It does nothing with a frame unless someone asked (a one-shot task) or gesture mode is on, so the camera
 * preview alone costs almost no battery. Frames are never saved or sent anywhere.
 */
class MLKitAnalyzer : ImageAnalysis.Analyzer {
    private val objects = ObjectDetectionManager()
    private val text = TextRecognitionManager()
    @Volatile private var task = VisionTask.NONE
    @Volatile private var callback: ((String) -> Unit)? = null
    @Volatile var gesture: GestureManager? = null

    /** Analyse the next camera frame. [onResult] is called once, on the main thread. */
    fun request(t: VisionTask, onResult: (String) -> Unit) { callback = onResult; task = t }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(image: ImageProxy) {
        gesture?.let { try { it.analyze(image) } catch (e: Exception) { } }
        val t = task
        val cb = callback
        val media = image.image
        if (t == VisionTask.NONE || cb == null || media == null) { image.close(); return }
        task = VisionTask.NONE
        callback = null
        val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
        val finish: (String) -> Unit = { r -> image.close(); cb(r) }
        try {
            if (t == VisionTask.DESCRIBE) objects.describe(input, finish) else text.read(input, finish)
        } catch (e: Exception) { finish("The camera frame couldn't be analysed.") }
    }

    fun close() { objects.close(); text.close() }
}
