package com.nova.ai.brain

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nova.ai.automation.Notifier

/**
 * Schedules the user's memory reminders with Android's AlarmManager (inexact alarms that may run a few minutes late, no special
 * permission) and posts a notification with the reminder title only. Timing and repeat are controlled by the user.
 */
object ReminderScheduler {
    const val ACTION = "com.nova.ai.brain.REMINDER"
    const val EXTRA_ID = "reminder_id"

    private fun pi(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(ctx, 910_000 + (id % 80_000).toInt(), Intent(ctx, BrainReminderReceiver::class.java).setAction(ACTION).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun schedule(ctx: Context, r: ReminderRec) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.cancel(pi(ctx, r.id))
        if (!r.enabled) return
        val at = if (r.fireAt > System.currentTimeMillis()) r.fireAt else if (r.repeatMs > 0) nextRepeat(r, System.currentTimeMillis()) else return
        try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, r.id)) } catch (e: Exception) { }
    }

    fun cancel(ctx: Context, id: Long) { (ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(pi(ctx, id)) }

    fun nextRepeat(r: ReminderRec, now: Long): Long {
        if (r.repeatMs <= 0) return r.fireAt
        var t = r.fireAt
        while (t <= now) t += r.repeatMs
        return t
    }

    fun rescheduleAll(ctx: Context, store: BrainStore) { store.reminders().forEach { schedule(ctx, it) } }
}

class BrainReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != ReminderScheduler.ACTION) return
        val id = intent.getLongExtra(ReminderScheduler.EXTRA_ID, 0L)
        val pending = goAsync()
        Thread {
            try {
                val brain = Brain.get(ctx)
                val r = brain.fireReminder(id) ?: return@Thread
                Notifier.post(ctx.applicationContext, 7000 + (r.id % 900).toInt(), "Nova reminder", r.title)
            } catch (e: Exception) { } finally { pending.finish() }
        }.start()
    }
}
