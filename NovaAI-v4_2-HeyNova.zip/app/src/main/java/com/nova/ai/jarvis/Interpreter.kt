package com.nova.ai.jarvis

import com.nova.ai.modules.GeminiTask
import com.nova.ai.security.Prefs

/** Live interpreter: while on, everything you say is translated between two languages and spoken back. */
object Interpreter {
    @Volatile var active = false
    @Volatile var a = "Hindi"
    @Volatile var b = "English"

    fun start(from: String, to: String) { a = from; b = to; active = true }
    fun stop() { active = false }

    suspend fun translate(prefs: Prefs, text: String): String {
        if (prefs.localOnly) return "Local-only mode is on, so the interpreter can't translate."
        val out = GeminiTask(prefs).run(
            "You are a live interpreter between $a and $b. If the user's sentence is in $a, output only its $b translation. " +
                "If it is in $b, output only its $a translation. If it is in another language, translate it to $b. " +
                "Output only the translation: no quotes, no notes, no explanations.",
            text, maxTokens = 300
        )
        return out.removePrefix("⚠ ").takeIf { out.startsWith("⚠") }?.let { "Translation failed: $it" } ?: out
    }
}
