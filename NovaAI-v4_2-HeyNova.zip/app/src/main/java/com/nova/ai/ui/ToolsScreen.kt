package com.nova.ai.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Image / camera / PDF / document questions, plus the optional connections for smart home, PC and other devices. */
@Composable
fun ToolsScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    val p = vm.prefs
    val scope = rememberCoroutineScope()
    var question by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var city by remember { mutableStateOf(p.homeCity) }
    var hHome by remember { mutableStateOf(p.hookHome) }
    var hPc by remember { mutableStateOf(p.hookPc) }
    var hDev by remember { mutableStateOf(p.hookDevices) }
    var tok by remember { mutableStateOf(p.hookToken) }

    fun run(block: suspend () -> String) {
        busy = true; result = "Working…"
        scope.launch { result = try { block() } catch (e: Exception) { "Something went wrong: ${e.message}" }; busy = false }
    }
    var speakResult by remember { mutableStateOf(false) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) run { vm.askAboutFile(uri, question).also { if (speakResult) vm.voice.speak(it, vm.emotion) } }
    }
    val ctx = LocalContext.current
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok: Boolean ->
        val u = photoUri
        if (ok && u != null) run { vm.askAboutFile(u, question).also { if (speakResult) vm.voice.speak(it, vm.emotion) } }
    }
    fun launchCamera() {
        val f = File(File(ctx.cacheDir, "images").apply { mkdirs() }, "shot.jpg")
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        photoUri = u
        takePhoto.launch(u)
    }
    val camPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok: Boolean ->
        if (ok) launchCamera() else result = "Camera permission is needed to take a photo. Allow it in Permissions."
    }
    fun openCamera() {
        if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) launchCamera()
        else camPermission.launch(android.Manifest.permission.CAMERA)
    }
    // Voice commands like "camera se dekho" or "pdf padho" land here.
    LaunchedEffect(vm.autoCamera) { if (vm.autoCamera) { vm.autoCamera = false; question = vm.toolsQuestion; speakResult = true; openCamera() } }
    LaunchedEffect(vm.autoPick) { if (vm.autoPick) { vm.autoPick = false; question = vm.toolsQuestion; speakResult = true; pickFile.launch(arrayOf("image/*", "application/pdf", "text/*")) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            GText("Tools", size = 22.sp, weight = FontWeight.SemiBold)
        }
        GlassSettingSection("Ask about an image, photo, PDF or document") {
            GlassTextField(question, { question = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2, placeholder = "Your question (optional)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("📷 Take photo", { speakResult = false; openCamera() }, enabled = !busy)
                GlassButton("📄 Pick file", { speakResult = false; pickFile.launch(arrayOf("image/*", "application/pdf", "text/*")) }, enabled = !busy, primary = true)
            }
            if (result.isNotBlank()) {
                GText(result, size = 14.sp)
                if (!busy) GlassButton("Read aloud", { vm.voice.speak(result, vm.emotion) })
            }
            GText("Only the file or photo you choose now is sent to Gemini, once, with your question. Nothing is stored.", size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Website Forge") {
            var sitePrompt by remember { mutableStateOf("") }
            var siteMsg by remember { mutableStateOf("") }
            GText("Describe a website and Nova builds it live: \"ek cafe ki website banao\".", size = 13.sp, color = g.subtext)
            GlassTextField(sitePrompt, { sitePrompt = it }, Modifier.fillMaxWidth(), placeholder = "What website should I build?", singleLine = false, minLines = 2)
            GlassButton("Build a website", { siteMsg = com.nova.ai.forge.ForgeController.start(ctx, sitePrompt.ifBlank { "a simple website" }).message }, Modifier.fillMaxWidth(), primary = true, enabled = sitePrompt.isNotBlank())
            GlassButton("My websites", { val savedSite = com.nova.ai.forge.ForgeController.saved(ctx).firstOrNull(); if (savedSite != null) { com.nova.ai.forge.ForgeController.openSaved(savedSite); com.nova.ai.forge.ForgeController.requestOpen() } else { siteMsg = "No saved websites yet." } }, Modifier.fillMaxWidth())
            if (siteMsg.isNotBlank()) GText(siteMsg, size = 12.sp, color = g.accent)
        }
        GlassSettingSection("Weather") {
            GlassTextField(city, { city = it; p.homeCity = it }, Modifier.fillMaxWidth(), placeholder = "Home city (used for \"weather\")")
            GText("Weather comes from Open-Meteo (no account). Without a home city NOVA uses your last known location if Location is allowed, else asks.", size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Connections: smart home · PC · other devices") {
            GText("NOVA sends a small JSON message to an address YOU run (for example a Home Assistant webhook, Node-RED, or the PC companion script in the project's companion folder). NOVA never talks to devices directly.", size = 12.sp, color = g.subtext)
            GlassTextField(hHome, { hHome = it; p.hookHome = it }, Modifier.fillMaxWidth(), placeholder = "Smart-home endpoint URL")
            GlassTextField(hPc, { hPc = it; p.hookPc = it }, Modifier.fillMaxWidth(), placeholder = "PC endpoint URL")
            GlassTextField(hDev, { hDev = it; p.hookDevices = it }, Modifier.fillMaxWidth(), placeholder = "Other-devices endpoint URL")
            GlassTextField(tok, { tok = it; p.hookToken = it }, Modifier.fillMaxWidth(), placeholder = "Access token (stored encrypted)", visual = PasswordVisualTransformation())
            GText("Try: \"turn off the bedroom light\", \"pc lock\", \"send to tablet: open youtube\". Each asks for confirmation first. Use https or your home network only.", size = 12.sp, color = g.subtext)
        }
        GlassSettingSection("Voice commands") {
            GlassListItem("Weather", "\"weather in Delhi\", \"aaj ka mausam\"")
            GlassListItem("Calendar", "\"my schedule today\", \"meetings this week\"")
            GlassListItem("Translate", "\"translate good morning to Hindi\", \"Namaste ko English mein translate karo\"")
            GlassListItem("Music", "\"play music Arijit Singh\", \"pause music\", \"next song\"")
            GlassListItem("Study / Gaming / Travel", "\"quiz me on photosynthesis\", \"gaming tips for Valorant\", \"plan a 3-day trip to Goa\"")
            GlassListItem("Productivity", "\"plan my day: gym, report, call Rahul\"")
            GlassListItem("Notifications", "\"dismiss notifications from whatsapp\", \"open latest notification\"")
        }
    }
}
