package com.nova.ai.jarvis

import android.content.Context
import android.os.BatteryManager
import com.nova.ai.modules.CalendarImpl
import com.nova.ai.modules.GeminiTask
import com.nova.ai.modules.WeatherImpl
import com.nova.ai.notifications.NovaNotificationListener
import com.nova.ai.security.Prefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Morning briefing: date, weather, today's calendar, battery and your latest notifications, spoken in a friendly way. */
object Briefing {
    suspend fun build(ctx: Context, prefs: Prefs): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when { hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; else -> "Good evening" }
        val sb = StringBuilder("$greet. Aaj ${SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())} hai.\n")
        if (!prefs.localOnly) {
            val w = try { WeatherImpl(ctx, prefs).forecast(null) } catch (e: Exception) { "" }
            if (w.isNotBlank() && !w.startsWith("Which city") && !w.startsWith("I couldn't")) sb.append("Weather: ").append(w.lines().take(2).joinToString(" ")).append('\n')
        }
        val cal = try { CalendarImpl(ctx).upcoming(1) } catch (e: Exception) { "" }
        if (cal.isNotBlank() && !cal.startsWith("I need")) sb.append("Calendar: ").append(cal.replace("\n", " ")).append('\n')
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (pct in 1..100) sb.append("Battery $pct%.\n")
        } catch (e: Exception) { }
        val notifs = synchronized(NovaNotificationListener.recent) { NovaNotificationListener.recent.takeLast(3).toList() }
        if (notifs.isNotEmpty()) sb.append("Recent notifications: ").append(notifs.joinToString("; ")).append('\n')
        val raw = sb.toString().trim()
        if (prefs.localOnly || prefs.apiKey.isBlank() || !prefs.aiEnabled) return raw
        val nice = GeminiTask(prefs).run(
            "Turn these facts into a short, warm spoken morning briefing (under 70 words). Keep every fact true, add nothing, use the user's language style (Hinglish if the facts mix Hindi). Plain text, no lists.",
            raw, maxTokens = 220
        )
        return if (nice.startsWith("⚠")) raw else nice
    }
}
