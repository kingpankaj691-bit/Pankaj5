package com.nova.ai.voice

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Everything that must be true before Background Voice may start:
 * microphone permission AND the ability to show the persistent notification (so the microphone is never used invisibly).
 */
object VoicePermissionManager {

    fun hasMic(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun notificationsAllowed(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = ctx.getSystemService(NotificationManager::class.java)?.getNotificationChannel(VoiceNotificationManager.CHANNEL_ID)
            if (ch != null && ch.importance == NotificationManager.IMPORTANCE_NONE) return false
        }
        return true
    }

    fun canStart(ctx: Context): Boolean = hasMic(ctx) && notificationsAllowed(ctx)

    /** Runtime permissions to request, in order. */
    fun runtimePermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    /** A clear sentence for the user, or null when everything needed is granted. */
    fun missingExplanation(ctx: Context): String? = when {
        !hasMic(ctx) ->
            "Background Voice needs the Microphone permission to hear you. Nova does not start the microphone without it. " +
                "Allow it in Settings > Apps > Nova AI > Permissions."
        !notificationsAllowed(ctx) ->
            "Background Voice needs notifications so the \"microphone is on\" notification can be shown. " +
                "Nova never uses the microphone invisibly. Allow notifications for Nova AI in Settings."
        else -> null
    }

    fun appSettingsIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
