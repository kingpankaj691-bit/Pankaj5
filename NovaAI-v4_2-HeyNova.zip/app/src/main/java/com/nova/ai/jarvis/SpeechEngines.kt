package com.nova.ai.jarvis

import android.content.Context
import com.nova.ai.ai.model.ModelManager
import com.nova.ai.ai.model.VoiceRoute
import com.nova.ai.live.GeminiLiveDuplexEngine
import com.nova.ai.security.Prefs
import com.nova.ai.voice.GeminiSpeechEngine
import com.nova.ai.voice.PcmFormat
import com.nova.ai.voice.SpeechProcessingEngine
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Picks the speech-to-text engine that Jarvis settings ask for. */
object SpeechEngines {
    fun create(ctx: Context, prefs: Prefs, jp: JarvisPrefs, onText: (String) -> Unit, onProblem: (String) -> Unit): SpeechProcessingEngine {
        // Two-way voice: the SELECTED model decides how. Native Gemini Live if that model supports it, otherwise
        // speech-to-text -> the same selected model -> text-to-speech. See RoutedVoiceEngine.
        // The offline wake gate (Hey Nova, or the older name-only gate) wraps the WHOLE pipeline, native Live included, so no audio
        // reaches Gemini before the wake phrase. Hey Nova also delays starting the Live connection until the phrase is heard.
        if (jp.sttMode == "duplex") return withWake(ctx, jp, RoutedVoiceEngine(ctx, prefs, jp, onText, onProblem), onProblem)
        VoiceState.voiceMode.value = ""
        return withWake(ctx, jp, base(ctx, prefs, jp, onText, onProblem), onProblem)
    }

    /**
     * The speech-to-text side of the fallback pipeline (live Gemini transcription with the offline recognizer as backup).
     * Not wrapped in the wake gate here: [create] already wraps the whole routed engine, and gating twice would swallow audio.
     */
    internal fun fallback(ctx: Context, prefs: Prefs, jp: JarvisPrefs, onText: (String) -> Unit, onProblem: (String) -> Unit): SpeechProcessingEngine =
        base(ctx, prefs, jp, onText, onProblem)

    private fun withWake(ctx: Context, jp: JarvisPrefs, base: SpeechProcessingEngine, onProblem: (String) -> Unit): SpeechProcessingEngine =
        if (jp.gateOn) WakeGateEngine(ctx, jp, base, onProblem, lazyInner = jp.heyNova) else base

    private fun base(ctx: Context, prefs: Prefs, jp: JarvisPrefs, onText: (String) -> Unit, onProblem: (String) -> Unit): SpeechProcessingEngine =
        when (jp.sttMode) {
            "clips" -> GeminiSpeechEngine(prefs, onText, onProblem)
            "offline" -> OfflineSpeechEngine(ctx, jp, onText, onProblem)
            "live" -> LiveSpeechEngine(prefs, jp, onText, onProblem, ctx)
            else -> AutoSpeechEngine(ctx, prefs, jp, onText, onProblem)
        }
}

/**
 * Live Gemini recognition first; if it is down (no internet, quota, bad key) and an offline model is installed,
 * the offline recognizer's results are used until Live works again. Audio is fed to both, text comes from one at a time.
 */
class AutoSpeechEngine(
    ctx: Context,
    prefs: Prefs,
    jp: JarvisPrefs,
    private val onText: (String) -> Unit,
    private val onProblem: (String) -> Unit
) : SpeechProcessingEngine {
    @Volatile private var liveOk = true
    private val live = LiveSpeechEngine(prefs, jp, onText, { p -> liveOk = p.isEmpty(); onProblem(p) }, ctx)
    private val offline: OfflineSpeechEngine? =
        if (VoskModelManager.isInstalled(ctx, jp.offlineLang)) OfflineSpeechEngine(ctx, jp, { t -> if (!liveOk) onText(t) }, { }) else null

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        live.start(format, scope)
        offline?.start(format, scope)
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        live.processAudio(audioData, length)
        offline?.processAudio(audioData, length)
    }

    override fun stop() { live.stop(); offline?.stop() }
}


/**
 * Chooses the voice pipeline for the model selected in Settings → Gemini, every time the microphone starts:
 *
 *  - Native Gemini Live  : the selected model supports the Live API -> real-time two-way audio (barge-in, reconnect, recap).
 *  - Universal fallback  : it does not -> microphone -> speech-to-text -> the SAME selected model (generateContent) -> text-to-speech,
 *                          and the microphone keeps listening afterwards. Conversation history is kept by the chat/headless layer.
 *  - Unavailable         : the selected model cannot answer at all -> a clear message, never a silent switch to another model.
 *
 * If the Live API refuses a model's audio output (error 1007), the refusal is remembered and the engine moves to the fallback
 * pipeline for the same model at once; nothing loops.
 */
class RoutedVoiceEngine(
    private val ctx: Context,
    private val prefs: Prefs,
    private val jp: JarvisPrefs,
    private val onText: (String) -> Unit,
    private val onProblem: (String) -> Unit
) : SpeechProcessingEngine {

    @Volatile private var delegate: SpeechProcessingEngine? = null
    @Volatile private var format = PcmFormat(16000, 1)
    @Volatile private var scope: CoroutineScope? = null
    @Volatile private var stopped = true

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        this.format = format
        this.scope = scope
        stopped = false
        begin(scope)
    }

    private fun begin(scope: CoroutineScope) {
        when (val route = ModelManager.voiceRoute(ctx)) {
            is VoiceRoute.NativeLive -> {
                VoiceState.voiceMode.value = "Voice: " + route.describe()
                val d = GeminiLiveDuplexEngine(
                    ctx, prefs, jp, onProblem,
                    modelId = route.modelId, modality = route.modality,
                    onNativeRejected = { why -> switchToFallback(route.modelId, why) }
                )
                delegate = d
                d.start(format, scope)
            }
            is VoiceRoute.Fallback -> startFallback(route.modelId, scope)
            is VoiceRoute.Unavailable -> {
                VoiceState.voiceMode.value = "Voice unavailable for the selected model"
                onProblem(route.reason + " Open Settings → Gemini → Model and choose another model.")
            }
        }
    }

    private fun startFallback(modelId: String, scope: CoroutineScope) {
        VoiceState.voiceMode.value = "Voice: " + VoiceRoute.Fallback(modelId, "").describe()
        val e = SpeechEngines.fallback(ctx, prefs, jp, onText, onProblem)
        delegate = e
        e.start(format, scope)
    }

    private fun switchToFallback(modelId: String, why: String) {
        val s = scope ?: return
        ModelManager.learnNoNative(ctx, modelId)
        s.launch {
            if (stopped) return@launch
            val old = delegate
            delegate = null
            try { old?.stop() } catch (e: Exception) { }
            if (stopped) return@launch
            startFallback(modelId, s)
            onProblem("$why Using speech-to-text → $modelId → text-to-speech instead.")
        }
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        delegate?.processAudio(audioData, length)
    }

    override fun stop() {
        stopped = true
        val d = delegate
        delegate = null
        try { d?.stop() } catch (e: Exception) { }
        scope = null
    }
}
