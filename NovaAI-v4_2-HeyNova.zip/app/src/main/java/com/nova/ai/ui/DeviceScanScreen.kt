package com.nova.ai.ui

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.nova.ai.permissions.PermItem
import com.nova.ai.scanner.DeviceProfile
import com.nova.ai.scanner.ScanItem
import com.nova.ai.scanner.ScanSection
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF69F0AE)
private val Amber = Color(0xFFFFC27A)

private fun dateOf(ms: Long) = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(ms))

@Composable
fun DeviceScanScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    var view by rememberSaveable { mutableStateOf("overview") }
    var detail by remember { mutableStateOf<ScanSection?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            Column {
                GText("NOVA DEVICE INTELLIGENCE", size = 17.sp, weight = FontWeight.SemiBold)
                GText("Only what Android lets Nova see. The report stays on this phone.", size = 11.sp, color = g.subtext)
            }
        }
        val p = vm.profile
        when {
            vm.scanning -> ScanningView(vm)
            p == null -> {
                GlassCard(Modifier.fillMaxWidth(), glow = true) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        GText("Scan my phone", size = 20.sp, weight = FontWeight.SemiBold)
                        GText("Nova inspects device, Android, hardware, display, battery, storage, memory, network, Wi-Fi, Bluetooth, sensors, cameras, audio, visible apps, permission status, notifications and accessibility status. It never reads your files, messages, passwords or other apps' private data.", size = 13.sp, color = g.subtext)
                        GlassButton("Start scan", { vm.startScan() }, Modifier.fillMaxWidth(), primary = true, glyph = "🛰")
                    }
                }
            }
            else -> {
                GlassCard(Modifier.fillMaxWidth(), glow = true, tint = Green.a(0.08f)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        GText("✓ SCAN COMPLETE", weight = FontWeight.Bold, color = Green)
                        GText(dateOf(p.time), size = 12.sp, color = g.subtext)
                        GText(p.summary(), size = 13.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Scan again", { vm.startScan(announce = false) }, primary = true)
                            GlassButton("Refresh", { vm.startScan(announce = false, paced = false) })
                            GlassButton("Delete scan data", { confirmDelete = true })
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("overview" to "Overview", "apps" to "Apps", "hardware" to "Hardware", "storage" to "Storage",
                        "battery" to "Battery", "network" to "Network", "perms" to "Permissions").forEach { (k, l) ->
                        GlassChip(l, view == k, { view = k })
                    }
                }
                when (view) {
                    "overview" -> Dashboard(vm, p) { detail = it }
                    "apps" -> AppsView(vm, p)
                    "hardware" -> listOf("device", "android", "hardware", "display", "sensors", "cameras", "audio", "features")
                        .forEach { id -> p.section(id)?.let { SectionCard(it) } }
                    "storage" -> StorageView(vm, p)
                    "battery" -> BatteryCenter(vm)
                    "network" -> NetworkCenter(vm)
                    else -> {
                        GText("NOVA Permission Intelligence", size = 16.sp, weight = FontWeight.SemiBold)
                        PermissionsPage()
                        p.section("permissions")?.let { SectionCard(it) }
                        p.section("notifications")?.let { SectionCard(it) }
                        p.section("accessibility")?.let { SectionCard(it) }
                    }
                }
            }
        }
    }
    detail?.let { sec -> GlassSheet({ detail = null }, sec.title) { sec.items.forEach { ItemRow(it) } } }
    if (confirmDelete) GlassDialog({ confirmDelete = false }, "Delete scan data?", "Delete", { vm.deleteScan() }) {
        GText("The stored device report will be removed from this phone.")
    }
}

@Composable
private fun ScanningView(vm: NovaViewModel) {
    val g = LocalGlass.current
    val steps = vm.scanner.steps
    val idx = vm.scanIndex.coerceIn(0, steps.size)
    val frac by animateFloatAsState(idx / steps.size.toFloat(), g.motion(), label = "scan")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NovaOrb("Thinking", Modifier.size(170.dp))
        GText("NOVA is scanning…", size = 20.sp, weight = FontWeight.SemiBold)
        GText(if (idx < steps.size) "Scanning ${steps[idx].second}…" else "Finishing…", color = g.accent)
        Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(g.text.a(0.12f))
            .semantics { contentDescription = "Scan progress ${(frac * 100).toInt()} percent" }) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(g.accent, g.accent2))))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                steps.forEachIndexed { i, s ->
                    val mark = if (i < idx) "✓" else if (i == idx) "●" else "○"
                    GText("$mark  ${s.second}", color = if (i <= idx) g.text else g.subtext)
                }
            }
        }
    }
}

@Composable
private fun ItemRow(item: ScanItem) {
    val g = LocalGlass.current
    var open by remember { mutableStateOf(false) }
    val color = when (item.status) { "Available" -> Green; "Restricted" -> Amber; "Not available" -> g.subtext; else -> g.text }
    Column(Modifier.fillMaxWidth().then(if (item.detail != null) Modifier.pressable({ open = !open }) else Modifier)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            GText(item.label, Modifier.weight(1f), size = 14.sp, color = g.subtext)
            GText(item.value, Modifier.weight(1f), size = 14.sp, color = color, align = androidx.compose.ui.text.style.TextAlign.End)
        }
        if (item.detail != null) {
            if (open) GText(item.detail, size = 12.sp, color = g.subtext, modifier = Modifier.padding(top = 4.dp))
            else GText("tap for details", size = 10.sp, color = g.subtext.a(0.6f))
        }
    }
}

@Composable
private fun SectionCard(s: ScanSection) {
    GlassSettingSection(s.title) { s.items.forEach { ItemRow(it) } }
}

@Composable
private fun Dashboard(vm: NovaViewModel, p: DeviceProfile, onOpen: (ScanSection) -> Unit) {
    val ids = listOf("battery", "storage", "memory", "network", "wifi", "bluetooth", "sensors", "cameras", "audio", "permissions")
    val secs = ids.mapNotNull { p.section(it) }
    secs.chunked(2).forEachIndexed { row, pair ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            pair.forEachIndexed { col, s -> DashCard(s, row * 2 + col, { onOpen(s) }, Modifier.weight(1f)) }
            if (pair.size == 1) Box(Modifier.weight(1f))
        }
    }
}

@Composable
private fun DashCard(s: ScanSection, index: Int, onClick: () -> Unit, modifier: Modifier) {
    val g = LocalGlass.current
    var shown by remember { mutableStateOf(g.reduced) }
    LaunchedEffect(Unit) { delay(70L * index); shown = true }
    val bar by animateFloatAsState(if (shown) (s.fraction ?: 0f) else 0f, tween(if (g.reduced) 0 else 800), label = "bar")
    val title = when (s.id) { "audio" -> "Microphone"; "permissions" -> "Security permissions"; "cameras" -> "Camera"; else -> s.title }
    AnimatedVisibility(shown, modifier = modifier, enter = if (g.reduced) androidx.compose.animation.EnterTransition.None else fadeIn(tween(300)) + slideInVertically { it / 4 }) {
        GlassCard(Modifier.fillMaxWidth().pressable(onClick).semantics { contentDescription = "$title: ${s.headline}. Tap for details" }, shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(title, size = 13.sp, color = g.subtext)
                GText(s.headline, size = 15.sp, weight = FontWeight.SemiBold, maxLines = 2)
                if (s.fraction != null) Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(g.text.a(0.12f))) {
                    Box(Modifier.fillMaxWidth(bar.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(g.accent))
                }
            }
        }
    }
}

@Composable
private fun AppsView(vm: NovaViewModel, p: DeviceProfile) {
    val g = LocalGlass.current
    var cat by remember { mutableStateOf("All") }
    var q by remember { mutableStateOf("") }
    var limit by remember { mutableIntStateOf(40) }
    val caps = remember(p) { vm.apps.capabilityMap() }
    val cats = listOf("All", "Social", "Media", "Games", "Tools", "Education", "Communication", "Productivity", "System", "Development", "Other")
    GlassSettingSection("App capability map") {
        caps.forEach { c ->
            GlassListItem(c.app, c.action, trailing = { GText(if (c.supported) "✓ Supported" else "Not available", size = 12.sp, color = if (c.supported) Green else g.subtext) })
        }
        GText("Supported means Android reports a handler. If Android rejects a launch, Nova says so.", size = 11.sp, color = g.subtext)
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        cats.forEach { c -> GlassChip(c, cat == c, { cat = c; limit = 40 }) }
    }
    GlassTextField(q, { q = it; limit = 40 }, Modifier.fillMaxWidth(), placeholder = "Search apps")
    val list = p.apps.filter { (cat == "All" || it.category == cat) && (q.isBlank() || it.name.contains(q, true) || it.pkg.contains(q, true)) }
    GText("${list.size} apps shown. Android only lists apps Nova is allowed to see.", size = 12.sp, color = g.subtext)
    list.take(limit).forEach { a ->
        val click: (() -> Unit)? = if (a.launchable) ({ if (!vm.apps.launch(a.pkg)) vm.note("I couldn't open ${a.name}.") }) else null
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Box(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                GlassListItem(
                    a.name,
                    "${a.pkg}\nv${a.version} (code ${a.code}) • ${a.category}\nInstalled ${dateOf(a.installed)} • Updated ${dateOf(a.updated)}" + (a.installer?.let { " • via $it" } ?: ""),
                    onClick = click,
                    trailing = { GText(if (a.launchable) "Open" else "No launcher", size = 12.sp, color = if (a.launchable) g.accent else g.subtext) }
                )
            }
        }
    }
    if (list.size > limit) GlassButton("Show more", { limit += 40 }, Modifier.fillMaxWidth())
}

@Composable
private fun StorageView(vm: NovaViewModel, p: DeviceProfile) {
    val g = LocalGlass.current
    val s = p.section("storage") ?: return
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GText("Storage Overview", size = 16.sp, weight = FontWeight.SemiBold)
            GText(s.headline)
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(g.text.a(0.12f))) {
                Box(Modifier.fillMaxWidth((s.fraction ?: 0f).coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(g.accent, g.accent2))))
            }
        }
    }
    SectionCard(s)
    GlassButton("Open Files", { vm.device.openFiles() }, Modifier.fillMaxWidth())
    GText("Nova never scans private app folders or silently reads your files. Use the system file picker to share a file.", size = 11.sp, color = g.subtext)
}

@Composable
private fun BatteryCenter(vm: NovaViewModel) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val sec by produceState<ScanSection?>(null, tick, refresh) { value = vm.scanner.build("battery") }
    val s = sec ?: run { GText("Reading battery…"); return }
    val pct = ((s.fraction ?: 0f) * 100).toInt()
    val charging = s.items.firstOrNull { it.label == "Charging" }?.value == "Yes"
    GlassCard(Modifier.fillMaxWidth(), glow = true) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GText("Battery Center", size = 16.sp, weight = FontWeight.SemiBold)
            GText("$pct%${if (charging) " • charging" else ""}", size = 30.sp, weight = FontWeight.Bold, color = g.accent)
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(g.text.a(0.12f))) {
                Box(Modifier.fillMaxWidth((s.fraction ?: 0f).coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(g.accent))
            }
        }
    }
    if (pct <= 20 && !charging) GlassCard(Modifier.fillMaxWidth(), tint = Amber.a(0.12f)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GText("Battery is low. Want me to open Battery Saver settings?")
            GlassButton("Open Battery Saver", { vm.device.openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS, "battery saver settings") }, primary = true)
        }
    }
    SectionCard(s)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Refresh", { refresh++ })
        GlassButton("Battery settings", { openSystem(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) })
    }
}

@Composable
private fun NetworkCenter(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val secs by produceState<List<ScanSection>>(emptyList(), tick, refresh) {
        value = listOf("network", "wifi", "bluetooth").map { vm.scanner.build(it) }
    }
    GText("Network Center", size = 16.sp, weight = FontWeight.SemiBold)
    if (secs.isEmpty()) GText("Reading network…")
    secs.forEach { SectionCard(it) }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Refresh", { refresh++ })
        GlassButton("Wi-Fi settings", { openSystem(ctx, Settings.ACTION_WIFI_SETTINGS) })
        GlassButton("Connect with password", { vm.wifiSheet = true }, primary = true)
        GlassButton("Bluetooth settings", { openSystem(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) })
    }
}

@Composable
fun WifiConnectSheet(vm: NovaViewModel, onDismiss: () -> Unit) {
    val g = LocalGlass.current
    var ssid by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    GlassSheet(onDismiss, "Connect to Wi-Fi") {
        GText("Android shows its own confirmation. The password goes only to Android and is never saved or shown by Nova.", size = 12.sp, color = g.subtext)
        GlassTextField(ssid, { ssid = it }, Modifier.fillMaxWidth(), placeholder = "Network name (SSID)")
        GlassTextField(pass, { pass = it }, Modifier.fillMaxWidth(), placeholder = "Password (empty for open network)",
            visual = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailing = { SmallAction(if (show) "Hide" else "Show", if (show) "Hide password" else "Show password") { show = !show } })
        GlassButton("Connect", { result = vm.device.addWifiNetwork(ssid.trim(), pass); pass = "" }, Modifier.fillMaxWidth(), primary = true, enabled = ssid.isNotBlank())
        GlassButton("Open Wi-Fi settings instead", { vm.device.openSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings") }, Modifier.fillMaxWidth())
        if (result.isNotBlank()) GText(result, size = 13.sp, color = g.accent)
    }
}
