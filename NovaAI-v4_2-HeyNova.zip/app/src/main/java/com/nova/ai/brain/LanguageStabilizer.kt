package com.nova.ai.brain

import com.nova.ai.language.LanguageCatalog
import com.nova.ai.language.LanguageDetector

/**
 * Conversation-level language lock. The language is chosen once, kept for the whole conversation, saved so it survives a
 * reconnect or restart, and changed only when the user asks or clearly and repeatedly speaks another language.
 * A single foreign word, a short phrase or a low-confidence detection never counts as a switch.
 */
class LanguageStabilizer(private val store: BrainStore) {
    data class State(val lang: String, val since: Long, val explicit: Boolean)

    companion object {
        const val HINGLISH = "hinglish"
        const val HINDI = "hindi"
        const val ENGLISH = "english"

        private const val VERB = "(?:mein\\s+|me\\s+|main\\s+)?(?:bolo|bol|baat|jawab|reply|answer|speak|samjhao|batao|boliye|chat|talk|mode)"
        private val explicitEnglish = Regex("(?i)(english|angrezi|angreji)\\s+$VERB|(speak|reply|answer|talk|chat|switch|respond)\\s+(to\\s+|in\\s+)?english")
        private val explicitHinglish = Regex("(?i)hinglish\\s+$VERB|(speak|reply|answer|talk|chat|switch|respond)\\s+(to\\s+|in\\s+)?hinglish")
        private val explicitHindi = Regex("(?i)(hindi|हिंदी|हिन्दी)\\s+$VERB|(speak|reply|answer|talk|chat|switch|respond)\\s+(to\\s+|in\\s+)?hindi|हिंदी\\s+में|हिन्दी\\s+में")

        /** The name of the language Nova should use, or null when the text is not a language-change request. */
        fun explicitChange(text: String): String? {
            val t = text.trim()
            if (explicitHinglish.containsMatchIn(t)) return HINGLISH
            if (explicitEnglish.containsMatchIn(t)) return ENGLISH
            if (explicitHindi.containsMatchIn(t)) return HINDI
            val l = t.lowercase()
            for (lang in LanguageCatalog.all) {
                val n = lang.english.lowercase()
                if (n == "english" || n == "hindi") continue
                if (Regex("\\b$n\\s+$VERB\\b|\\b(speak|reply|answer|talk|chat|switch|respond)\\s+(to\\s+|in\\s+)?$n\\b").containsMatchIn(l)) return lang.tag
            }
            return null
        }

        fun displayName(lang: String): String = when (lang) {
            HINGLISH -> "Hinglish (Hindi written in Roman letters mixed with English)"
            HINDI -> "Hindi"
            ENGLISH -> "English"
            else -> LanguageCatalog.byTag(lang)?.let { it.english + " (" + it.native + ")" } ?: lang
        }
    }

    fun state(): State? {
        val l = store.getState("lang.cur") ?: return null
        return State(l, store.getState("lang.since")?.toLongOrNull() ?: 0L, store.getState("lang.explicit") == "1")
    }

    private fun set(lang: String, now: Long, explicit: Boolean) {
        store.putState("lang.cur", lang); store.putState("lang.since", now.toString()); store.putState("lang.explicit", if (explicit) "1" else "0")
        store.putState("lang.cand", ""); store.putState("lang.candN", "0")
    }

    fun reset() { listOf("lang.cur", "lang.since", "lang.explicit", "lang.cand", "lang.candN").forEach { store.putState(it, "") } }

    /** Maps the on-device detector's answer onto the three main modes or a language tag. */
    internal fun classify(text: String): Pair<String, Boolean>? {
        val d = LanguageDetector.detect(text)
        val words = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val nonLatin = d.tag != "en-IN" && !d.hinglish && text.any { it.code > 0x24F }
        val lang = when {
            d.hinglish -> HINGLISH
            d.tag == "hi-IN" -> HINDI
            d.tag == "en-IN" -> ENGLISH
            else -> d.tag
        }
        val strong = d.confident && (words >= 4 || (nonLatin && text.count { it.isLetter() } >= 6))
        return if (d.confident) lang to strong else null
    }

    private fun needed(cur: String, cand: String): Int = when {
        cur == HINGLISH && cand == ENGLISH -> 4      // Hinglish already contains English
        cur == HINDI && cand == HINGLISH -> 3
        cur == ENGLISH && cand == HINGLISH -> 3
        else -> 3
    }

    /**
     * Feed every user message. [fixedMode] is Prefs.language (auto, english, hindi, hinglish, manual); a fixed mode always wins.
     * Returns the language state after this message.
     */
    fun observe(text: String, now: Long, fixedMode: String = "auto", manualTag: String = ""): State? {
        when (fixedMode) {
            "english" -> { if (state()?.lang != ENGLISH || state()?.explicit != true) set(ENGLISH, now, true); return state() }
            "hindi" -> { if (state()?.lang != HINDI || state()?.explicit != true) set(HINDI, now, true); return state() }
            "hinglish" -> { if (state()?.lang != HINGLISH || state()?.explicit != true) set(HINGLISH, now, true); return state() }
            "manual" -> { val tag = manualTag.ifBlank { ENGLISH }; if (state()?.lang != tag || state()?.explicit != true) set(tag, now, true); return state() }
        }
        explicitChange(text)?.let { set(it, now, true); return state() }
        val cur = state()
        val c = classify(text) ?: return cur
        val (lang, strong) = c
        if (cur == null) {
            // first language of the conversation: a clear sentence sets it; a very short first message can still set it when confident
            if (strong || text.trim().split(Regex("\\s+")).size >= 2) set(lang, now, false)
            return state()
        }
        if (lang == cur.lang) { store.putState("lang.cand", ""); store.putState("lang.candN", "0"); return cur }
        if (!strong) return cur                                     // one foreign word or a short phrase is not a switch
        val cand = store.getState("lang.cand").orEmpty()
        val n = if (cand == lang) (store.getState("lang.candN")?.toIntOrNull() ?: 0) + 1 else 1
        if (n >= needed(cur.lang, lang)) { set(lang, now, false); return state() }
        store.putState("lang.cand", lang); store.putState("lang.candN", n.toString())
        return cur
    }

    /** Instruction block for the AI. Gemini is told it may not choose the language itself. */
    fun policy(): String {
        val s = state()
        return if (s == null)
            "LANGUAGE: Reply in the same language the user writes in. Once the user's language is clear, keep using it for the whole conversation and never switch on your own."
        else
            "LANGUAGE LOCK: This conversation is in ${displayName(s.lang)}. Reply ONLY in ${displayName(s.lang)}. " +
                "Do not switch language, do not mix in another language, and do not decide the language yourself. " +
                "One word or phrase from another language is NOT a request to switch. Switch only if the user explicitly asks you to change the language. Never translate what the user said unless asked."
    }
}
