package com.nova.ai.brain

import java.time.ZoneId

/**
 * Local rules that decide what in a message is worth remembering and in which category.
 * Hindi, Hinglish and English phrases. Nothing is sent anywhere. Secrets are blocked here, before anything is stored.
 */
object MemoryExtractor {
    private val blocked = listOf(
        Regex("(?i)\\b(password|passcode|passwd|pass word|pin code|\\bpin\\b|otp|cvv|cvc|recovery code|backup code|seed phrase|secret key|private key|api[ _-]?key|apikey|access token|auth token|bearer)\\b"),
        Regex("\\b\\d{13,19}\\b"), Regex("\\b\\d{4}[ -]\\d{4}[ -]\\d{4}\\b"), Regex("AIza[0-9A-Za-z_\\-]{20,}"), Regex("\\bsk-[A-Za-z0-9]{20,}\\b"),
        Regex("(?i)\\b(aadhaar|aadhar|ssn|passport number|pan card number)\\b")
    )
    private val askCues = listOf(
        Regex("\\b\\d{8,12}\\b"), Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"),
        Regex("(?i)\\b(address|pata|ghar ka pata|salary|income|tankhwah|loan|udhaar|udhar|bank|paise|emi|debt|credit|health|bimari|bimaar|disease|diagnos\\w*|medicine|dawai|dawa|doctor|treatment|religion|dharm|political|vote|caste)\\b")
    )
    private val dontSave = Regex("(?i)(save mat|yaad mat|yaad na rakh|mat save|mat yaad|don'?t (save|remember|store)|do not (save|remember|store)|never remember|ise (save )?mat|ye (baat )?(save )?mat|bhool jao ye|forget this|no need to remember)")
    private val rememberCue = Regex("(?i)(yaad rakh|yaad rakhna|yaad rakhiye|yaad kar lo|yaad kar lena|remember (this|that|it)|please remember|nova remember|remember me|save (this|it|kar)|save karo|save kar do|note (kar|down|this)|isko save|ise save|ise yaad|isse yaad|noting|dhyan rakh)")
    private val question = Regex("(?i)^(what|who|when|where|why|how|which|kya|kaun|kab|kahan|kyun|kaise|kaunsa|konsa|kitna|kitne|kitni)\\b")
    private val command = Regex("(?i)^(open|call|play|set|start|stop|turn|show|scan|tell me|send|kholo|chalao|bajao|band karo|dikhao|bhejo|laga do|laga)\\b")
    private val smallTalk = Regex("(?i)^(hi|hello|hey|thanks|thank you|ok|okay|haan|han|nahi|no|yes|theek|thik|accha|achha|hmm|cool|nice|shukriya|dhanyavad)\\b[ .!,]*$")

    fun directive(text: String): Directive = when {
        dontSave.containsMatchIn(text) -> Directive.DONT_SAVE
        rememberCue.containsMatchIn(text) -> Directive.REMEMBER
        else -> Directive.NONE
    }

    fun isBlocked(text: String): Boolean = blocked.any { it.containsMatchIn(text) }
    fun needsAsk(text: String): Boolean = askCues.any { it.containsMatchIn(text) }

    fun redact(text: String): String = blocked.fold(text) { acc, r -> r.replace(acc, "[redacted]") }

    /** Removes the polite or command wrapper so only the fact remains: "Nova, ise yaad rakhna ki main ..." -> "main ...". */
    fun stripWrapper(text: String): String {
        var t = text.trim()
        t = t.replace(Regex("(?i)^(hey |hi |ok |okay )?nova[ ,:!.-]*"), "")
        t = t.replace(Regex("(?i)\\b(ise|isse|isko|ye baat|yeh baat|ye|this|that)\\s+(yaad rakhna|yaad rakho|yaad rakhiye|save karna|save karo|save kar do|remember)\\b[ ,:.!]*"), "")
        t = t.replace(Regex("(?i)\\b(yaad rakhna|yaad rakho|yaad rakhiye|please remember|remember that|remember this|remember|note kar lo|note kar do|note down|save kar lo|save karo|save kar do)\\s*(ki|that|:|-)?\\s*"), "")
        t = t.replace(Regex("(?i)^(ki|that)\\s+"), "")
        return t.trim().trim(',', ':', '-', ' ')
    }

    private fun words(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun phraseBefore(text: String, re: Regex): String {
        val m = re.find(text) ?: return ""
        return text.substring(0, m.range.first).replace(Regex("(?i)\\b(nova|mujhe|mereko|muje|mera|meri|mere|main|i|me|my|bahut|bohot|ek|ye|yeh|toh|to|hamesha|always|bhi)\\b"), " ")
            .replace(Regex("[,.!?]+"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun title(text: String, n: Int = 7): String =
        words(text.replace(Regex("[,.!?]+"), " ")).filter { it.lowercase() !in Txt.STOP }.take(n).joinToString(" ")

    private fun projectName(t: String): String {
        Regex("(?i)(?:project|app|application|website|game|bot)\\s+(?:called|named|name)\\s+([A-Za-z0-9][\\w .-]{1,30}?)(?:\\s+(?:par|pe|me|mein|ka|ko)\\b|[,.!?]|$)").find(t)?.let { return it.groupValues[1].trim() }
        Regex("(?i)\\b(?:main|mai|i|hum)\\s+(.{2,40}?)\\s+(?:project|app|application|website|game|bot)\\s+(?:par|pe|ka|ko|is|me|mein|bana|build|develop|work)").find(t)?.let { return it.groupValues[1].replace(Regex("(?i)^(ek|an|a|the|apne|apna|apni)\\s+"), "").trim() }
        Regex("(?i)(.{2,40}?)\\s+(?:project|app|application)\\s+(?:par|pe|pr)\\s+(?:kaam|work)").find(t)?.let { return it.groupValues[1].replace(Regex("(?i)^(main|mai|i|nova|ek|apne|abhi)\\s+"), "").trim() }
        Regex("(?i)(?:working on|building|developing|bana raha hoon|bana rahi hoon)\\s+(?:a |an |the |my )?(.{2,40}?)(?:\\s+(?:project|app|application)|[,.!?]|$)").find(t)?.let { return it.groupValues[1].trim() }
        return ""
    }

    fun extract(raw: String, nowMs: Long, zone: ZoneId = ZoneId.systemDefault(), explicit: Boolean = false): List<Candidate> {
        val original = raw.trim()
        if (original.length < 4) return emptyList()
        if (isBlocked(original)) return listOf(Candidate(BrainCategory.NOTE, "", "", sensitivity = Sensitivity.BLOCK, reason = "It looked like a password, PIN, OTP, card, ID or key."))
        val t = (if (explicit) stripWrapper(original) else original.replace(Regex("(?i)^(hey |hi |ok |okay )?nova[ ,:!.-]*"), "")).trim()
        if (t.length < 4 || smallTalk.containsMatchIn(t)) return emptyList()
        val l = t.lowercase()
        if (!explicit && (t.endsWith("?") || question.containsMatchIn(l) || command.containsMatchIn(l))) return emptyList()

        val due = DateResolver.resolve(t, nowMs, zone)
        val sens = if (needsAsk(t)) Sensitivity.ASK else Sensitivity.NONE
        fun c(cat: BrainCategory, title: String, base: Float, status: String = Status.NONE, project: String = "", dueAt: Long = 0, why: String = "") =
            Candidate(cat, title.ifBlank { Txt.clip(t, 60) }, t, project, status, dueAt, if (explicit) (base + 0.2f).coerceAtMost(1f) else base, sens, explicit, why)

        // reminders and tasks
        if (Regex("(?i)(yaad dila|remind me|reminder)").containsMatchIn(l) && due != null)
            return listOf(c(BrainCategory.REMINDER, title(t), 0.7f, Status.PENDING, dueAt = due.at, why = "You asked to be reminded."))
        if (Regex("(?i)(baad mein|baad me|later|abhi nahi|postpone|next time).{0,40}(karenge|karunga|karungi|implement|add|banayenge|dekhenge|karna)|(implement|add|complete|finish|fix).{0,30}(baad mein|baad me|later)").containsMatchIn(l))
            return listOf(c(BrainCategory.TASK, title(t), 0.75f, Status.POSTPONED, dueAt = 0, why = "You said it will be done later, so I keep it as a pending task."))
        if (Regex("(?i)(karna hai|karni hai|karne hain|karna padega|complete karna|finish karna|banana hai|banani hai|fix karna|todo|to-do|need to|have to|i must|pending hai|adhura|unfinished|\\bshould finish)").containsMatchIn(l))
            return listOf(c(BrainCategory.TASK, title(t), 0.75f, Status.PENDING, dueAt = due?.at ?: 0, why = "It sounded like something you still have to do."))
        // decisions and instructions
        if (Regex("(?i)(decide kiya|decided|final kiya|final hai|faisla|hum .{0,25}use karenge|we will use|we'll use|going with|chose|choose kiya|select kiya|tay kiya)").containsMatchIn(l))
            return listOf(c(BrainCategory.DECISION, title(t), 0.8f, why = "It sounded like a decision."))
        if (Regex("(?i)(hamesha|always|never|kabhi mat|har baar|from now on|aaj se|whenever i say|jab bhi main|isi tarah se|ye format)").containsMatchIn(l))
            return listOf(c(BrainCategory.INSTRUCTION, title(t), 0.8f, why = "It sounded like a standing instruction."))
        // projects
        val pn = projectName(t)
        if (pn.isNotBlank() && Regex("(?i)(project|app|application|website|game|bot|working on|building|developing|kaam kar|bana raha|bana rahi)").containsMatchIn(l))
            return listOf(c(BrainCategory.PROJECT, pn, 0.8f, Status.ONGOING, project = pn, why = "It sounded like a project you are working on."))
        // learning, plans, dates
        if (Regex("(?i)(seekh raha|seekh rahi|seekh rahe|learning|i am learning|i'm learning|study kar raha|padh raha|practice kar raha|course kar raha)").containsMatchIn(l))
            return listOf(c(BrainCategory.LEARNING, title(t), 0.65f, why = "It sounded like something you are learning."))
        if (Regex("(?i)(birthday|janamdin|anniversary|exam|interview|deadline|shaadi|wedding|meeting|event|appointment)").containsMatchIn(l) && due != null)
            return listOf(c(BrainCategory.DATE_EVENT, title(t), 0.75f, dueAt = due.at, why = "It had an important date."))
        if (Regex("(?i)(plan hai|plan kar raha|plan kar rahi|agle (hafte|mahine|saal)|next (week|month|year)|future mein|in future|someday|kabhi banana|want to build|goal hai|my goal|mera goal)").containsMatchIn(l))
            return listOf(c(BrainCategory.FUTURE_PLAN, title(t), 0.65f, dueAt = due?.at ?: 0, why = "It sounded like a future plan."))
        // likes, dislikes, preferences
        val likeRe = Regex("(?i)(pasand hai|pasand nahi|pasand aata|pasand aati|nafrat|love|hate|dislike|favou?rite|achha lagta|bura lagta|bekaar lagta|like (to|the|it)|\\bi like\\b|\\bi love\\b)")
        if (likeRe.containsMatchIn(l)) {
            val design = Regex("(?i)\\b(ui|design|theme|interface|style|colou?r|layout|font|glass|dark mode|light mode)\\b").containsMatchIn(l)
            val obj = phraseBefore(t, Regex("(?i)(pasand|nafrat|achha lagta|bura lagta|bekaar lagta)")).ifBlank { title(t) }
            return listOf(c(if (design) BrainCategory.PREFERENCE else BrainCategory.LIKE_DISLIKE, obj, 0.7f, why = if (design) "It sounded like a design preference." else "It sounded like a like or dislike."))
        }
        if (Regex("(?i)(i prefer|prefer karta|prefer karti|short answer|chhota jawab|chota jawab|brief mein|detail mein samjhao|detailed answer|hinglish mein baat|reply in|please always|call me|mujhe .* chahiye hamesha|mujhe .{0,20} se bulao)").containsMatchIn(l))
            return listOf(c(BrainCategory.PREFERENCE, title(t), 0.75f, why = "It sounded like a preference about how you want answers."))
        // personal facts (device, name, work, location)
        if (Regex("(?i)(mera naam|my name is|main .{1,25} (me|mein) rehta|main .{1,25} rehti|i live in|i am from|i'm from|mera phone|my phone|mera mobile|mera laptop|mere phone|apne phone|my laptop|my device|i work (as|at|in)|i study|main .{1,20} (student|engineer|developer|designer) hoon|\\b(i am|i'm) a\\b|my (mother|father|sister|brother|wife|husband|friend)|meri (mummy|mom|behen|wife)|mere (papa|bhai|dost))").containsMatchIn(l))
            return listOf(c(BrainCategory.PERSONAL, title(t), 0.7f, why = "It sounded like a fact about you."))
        // explicit fallback
        if (explicit) return listOf(c(if (Regex("(?i)\\b(note|notes)\\b").containsMatchIn(original)) BrainCategory.NOTE else BrainCategory.CUSTOM, title(t), 0.7f, why = "You asked me to remember it."))
        return emptyList()
    }

    /** Categories that may be saved automatically without asking (everything else needs an explicit request or a yes). */
    val autoSavable = setOf(
        BrainCategory.PREFERENCE, BrainCategory.LIKE_DISLIKE, BrainCategory.PROJECT, BrainCategory.TASK, BrainCategory.DECISION,
        BrainCategory.INSTRUCTION, BrainCategory.LEARNING, BrainCategory.FUTURE_PLAN, BrainCategory.DATE_EVENT, BrainCategory.PERSONAL
    )
}
