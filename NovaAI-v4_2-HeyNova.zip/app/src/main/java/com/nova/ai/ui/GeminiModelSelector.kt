package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.ai.ModelCatalog
import com.nova.ai.ai.model.GeminiModel
import com.nova.ai.ai.model.ModelManager
import com.nova.ai.ai.model.ModelRouter
import com.nova.ai.ai.model.VoiceRoute
import com.nova.ai.security.Prefs
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private enum class ModelFilter(val label: String) {
    CHAT("Chat"), LIVE("Live"), FLASH("Flash"), PRO("Pro"), ALL("All")
}

/**
 * Settings → Gemini → Model. The list comes from Google's own model list (refreshable), never from a hardcoded set.
 * Choosing a model here changes it for typed chat, voice (native Live or the fallback pipeline), follow-ups and summaries at once:
 * they all read the same selected model through [ModelManager]. Nothing ever switches the model behind the user's back.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun GeminiModelSelector(prefs: Prefs, onChanged: (String) -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val registry = remember { ModelManager.registry(ctx) }
    val models by registry.models.collectAsState()
    val refreshing by registry.refreshing.collectAsState()
    val lastError by registry.lastError.collectAsState()
    val updated by registry.lastUpdated.collectAsState()
    val activeId by ModelManager.activeFlow(ctx).collectAsState()

    var defaultId by remember { mutableStateOf(prefs.defaultModel) }
    var preferNative by remember { mutableStateOf(ModelManager.preferNative(ctx)) }
    var open by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf(ModelFilter.CHAT) }
    var query by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }

    val active = models.firstOrNull { it.id == activeId }
    val noNative = ModelManager.learnedNoNative(ctx, activeId)
    val route = ModelRouter.route(activeId, active, noNative, preferNative)
    val listed = if (models.isEmpty()) registry.offlineSeed() else models

    fun pick(id: String) {
        if (ModelManager.select(ctx, prefs, id)) onChanged(ModelCatalog.clean(id, activeId))
    }

    GlassListItem("Active model", (active?.label ?: activeId) + "\n" + activeId)
    GlassListItem("Default model", if (defaultId.isBlank()) "Not set" else defaultId)
    GText(
        when (route) {
            is VoiceRoute.NativeLive -> "Voice: native Gemini Live with this model (real-time two-way audio)."
            is VoiceRoute.Fallback -> "Voice: Speech-to-Text → ${route.modelId} → Text-to-Speech. ${route.reason} Answers still come from this exact model."
            is VoiceRoute.Unavailable -> "Voice and chat: ${route.reason}"
        },
        size = 12.sp, color = g.subtext
    )
    if (active != null && !active.caps.chatCapable && active.caps.nativeLive)
        GText("This is a Live-voice-only model: voice works, but typed chat needs a model that supports generateContent. Nova will not switch models for you.", size = 12.sp, color = g.accent)
    ToggleRow("Use native Live when the model supports it", "Off = always use Speech-to-Text → model → Text-to-Speech", preferNative) {
        preferNative = it; ModelManager.setPreferNative(ctx, it)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Choose model", { open = true }, Modifier.weight(1f), primary = true)
        GlassButton(if (refreshing) "Refreshing…" else "Refresh list", { scope.launch { ModelManager.refresh(ctx, prefs) } }, Modifier.weight(1f), enabled = !refreshing)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassButton("Set active as default", { prefs.defaultModel = activeId; defaultId = prefs.defaultModel }, Modifier.weight(1f))
        GlassButton("Use default", { pick(defaultId) }, Modifier.weight(1f), enabled = defaultId.isNotBlank() && defaultId != activeId)
    }
    if (noNative) GlassButton("Allow native Live for this model again", { ModelManager.forgetLearned(ctx, activeId); preferNative = ModelManager.preferNative(ctx) }, Modifier.fillMaxWidth())
    GText(
        when {
            lastError.isNotBlank() -> "Model list: $lastError"
            models.isEmpty() -> "Showing Nova's offline list. Tap Refresh list to load every model your API key can use."
            else -> "${models.size} models from Google · updated " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(updated))
        },
        size = 12.sp, color = if (lastError.isNotBlank()) g.accent else g.subtext
    )

    if (open) GlassDialog({ open = false }, "Choose Gemini model") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModelFilter.values().forEach { f -> GlassChip(f.label, filter == f, { filter = f }) }
        }
        GlassTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = "Search models")
        val shown = listed.filter { m ->
            val c = m.caps
            val okFilter = when (filter) {
                ModelFilter.CHAT -> c.chatCapable
                ModelFilter.LIVE -> c.nativeLive
                ModelFilter.FLASH -> m.family == "Flash" || m.family == "Flash-Lite"
                ModelFilter.PRO -> m.family == "Pro"
                ModelFilter.ALL -> true
            }
            okFilter && (query.isBlank() || m.id.contains(query.trim(), true) || m.label.contains(query.trim(), true))
        }
        Column(
            Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (shown.isEmpty()) GText("No models match. Try another filter, or Refresh list.", size = 12.sp, color = g.subtext)
            shown.forEach { m -> ModelRow(m, m.id == activeId, m.id == defaultId) { pick(m.id); open = false } }
            GText("Custom model id", size = 12.sp, color = g.subtext)
            GlassTextField(custom, { custom = it }, Modifier.fillMaxWidth(), placeholder = "for example gemini-flash-latest")
            GlassButton("Use custom", { if (custom.isNotBlank()) { pick(custom); open = false } }, Modifier.fillMaxWidth(), enabled = custom.isNotBlank())
        }
    }
}

@Composable
private fun ModelRow(m: GeminiModel, active: Boolean, isDefault: Boolean, onPick: () -> Unit) {
    val g = LocalGlass.current
    val c = m.caps
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        GlassButton(m.label + (if (active) "  ✓" else "") + (if (isDefault) "  ★" else ""), onPick, Modifier.fillMaxWidth(), primary = active, enabled = c.selectable)
        GText(m.id, size = 11.sp, color = g.subtext)
        GText((m.badges() + listOf(m.limitsText()).filter { it.isNotBlank() }).joinToString(" · "), size = 11.sp, color = g.subtext)
        if (!c.selectable) GText("Cannot be the active model: it does not produce answers.", size = 11.sp, color = g.subtext)
    }
}
