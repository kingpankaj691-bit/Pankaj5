package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.live.LiveSession

/** Voice Pipeline Debugger: connection state, personality, language, VAD, mic state, per-turn latency. */
@Composable
fun VoiceDebugScreen(onBack: () -> Unit) {
    val state by LiveSession.state.collectAsState()
    val active by LiveSession.isActive.collectAsState()
    val muted by LiveSession.muted.collectAsState()
    val vad by LiveSession.vadActive.collectAsState()
    val amp by LiveSession.amplitude.collectAsState()
    val err by LiveSession.lastError.collectAsState()
    val pers by LiveSession.currentPersonality.collectAsState()
    val lang by LiveSession.currentLanguage.collectAsState()
    val det by LiveSession.detectedLanguage.collectAsState()
    val reconnects by LiveSession.latency.reconnectCount.collectAsState()
    SubPage("Voice Pipeline Debugger", onBack) {
        GlassSettingSection("Connection") {
            Row2("Session", if (active) "active" else "stopped"); Row2("State", state.name.lowercase())
            Row2("Reconnects", reconnects.toString()); Row2("Last error", err.ifBlank { "none" })
        }
        GlassSettingSection("Language and personality") {
            Row2("Personality", pers.ifBlank { "—" }); Row2("Language setting", lang); Row2("Detected", det.ifBlank { "—" })
        }
        GlassSettingSection("Microphone") {
            Row2("Mic", if (muted) "muted by you" else "open"); Row2("Voice activity", if (vad) "speech detected" else "quiet")
            Row2("Output level", "%.2f".format(amp))
        }
        GlassSettingSection("Latency (last turn)") {
            Row2("You stopped → first audio", LiveSession.latency.firstAudioLatencyMs()?.let { "$it ms" } ?: "—")
            Row2("Reply duration", LiveSession.latency.turnDurationMs()?.let { "$it ms" } ?: "—")
        }
    }
}

@Composable
private fun Row2(k: String, v: String) {
    androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        GText(k, size = 13.sp, color = LocalGlass.current.subtext); GText(v, size = 13.sp)
    }
}
