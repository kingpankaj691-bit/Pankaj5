package com.nova.ai.files

data class SensitiveFinding(val label: String, val count: Int)

/** Spots things that should not leave the phone by accident, before the consent dialog. Pattern-based, so it can miss things: the user still sees the full text. */
object SensitiveScan {
    private class Rule(val label: String, val rx: Regex, val check: (String) -> Boolean = { true })

    fun luhn(digits: String): Boolean {
        var sum = 0; var alt = false
        for (c in digits.reversed()) { var d = c - '0'; if (alt) { d *= 2; if (d > 9) d -= 9 }; sum += d; alt = !alt }
        return digits.length in 13..19 && sum % 10 == 0
    }

    private val rules = listOf(
        Rule("card number", Regex("\\b(?:\\d[ -]?){12,18}\\d\\b")) { luhn(it.filter(Char::isDigit)) },
        Rule("Aadhaar-like number", Regex("(?<!\\d)(?<!\\d\\s)\\d{4}\\s\\d{4}\\s\\d{4}(?!\\s?\\d)")),
        Rule("PAN-like number", Regex("\\b[A-Z]{5}[0-9]{4}[A-Z]\\b")),
        Rule("password, PIN or OTP", Regex("(?i)\\b(password|passwd|pwd|pin|cvv|otp)\\b\\s*[:=]\\s*\\S+")),
        Rule("API key or secret", Regex("AIza[0-9A-Za-z_\\-]{35}|\\bsk-[A-Za-z0-9]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----"))
    )

    /** Rules run in order on a working copy; each match is blanked out so a card number isn't also reported as an Aadhaar-like number. */
    fun scan(text: String): List<SensitiveFinding> {
        var work = text; val out = ArrayList<SensitiveFinding>()
        for (r in rules) {
            var c = 0
            work = r.rx.replace(work) { m -> if (r.check(m.value)) { c++; " " } else m.value }
            if (c > 0) out.add(SensitiveFinding(r.label, c))
        }
        return out
    }

    fun redact(text: String): String {
        var s = text
        for (r in rules) s = r.rx.replace(s) { m -> if (r.check(m.value)) "[hidden ${r.label}]" else m.value }
        return s
    }
}
