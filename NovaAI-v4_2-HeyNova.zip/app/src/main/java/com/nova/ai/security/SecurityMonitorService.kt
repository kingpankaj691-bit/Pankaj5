package com.nova.ai.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.nova.ai.automation.Notifier
import com.nova.ai.ui.MainActivity

/**
 * Hosts Security Mode only while the user has it switched on. It owns the motion monitor and a partial wake lock (so the sensor keeps
 * reporting with the screen off), shows a permanent notification, and stops completely when Security Mode is turned off.
 * START_NOT_STICKY: if Android kills it, it does not restart itself or loop.
 */
class SecurityMonitorService : Service() {
    companion object {
        const val ACTION_START = "com.nova.ai.security.START"
        const val ACTION_STOP = "com.nova.ai.security.STOP"
        private const val CH = "nova_security"
        private const val ID = 6001
        private const val WAKE_LOCK_MAX_MS = 12L * 60 * 60 * 1000
        @Volatile var running = false
            private set
    }

    private var monitor: MotionSecurityMonitor? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val prefs = Prefs(this)
        startFg("Security Mode is on. Motion alert is arming…")
        if (monitor == null) {
            val m = MotionSecurityMonitor(this, prefs) { reason ->
                SecurityEvents.record(this, prefs, "Motion alert", reason)
                updateNotification("Motion detected. Open Nova to turn the alarm off.")
                SecurityAlarmManager.get(this).trigger(prefs)
            }
            if (!m.start()) {
                prefs.securityModeOn = false
                Notifier.post(this, 6102, "Security Mode could not start", "This phone has no accelerometer sensor.")
                stopSelf()
                return START_NOT_STICKY
            }
            monitor = m
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:security").also { it.acquire(WAKE_LOCK_MAX_MS) }
            updateNotification("Security Mode is on. Motion alert is armed.")
        }
        running = true
        return START_NOT_STICKY
    }

    private fun startFg(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, ID, build(text), type)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(ID, build(text))
    }

    private fun build(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Nova Security Mode", NotificationManager.IMPORTANCE_LOW))
        val off = PendingIntent.getActivity(this, 61, Intent(this, MainActivity::class.java).putExtra("disarm", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).setContentTitle("Nova Security Mode").setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true).setContentIntent(off).addAction(0, "Turn off", off)
            .setCategory(NotificationCompat.CATEGORY_SERVICE).build()
    }

    override fun onDestroy() {
        monitor?.stop(); monitor = null
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        wake = null
        SecurityAlarmManager.get(this).release()
        running = false
        super.onDestroy()
    }
}
