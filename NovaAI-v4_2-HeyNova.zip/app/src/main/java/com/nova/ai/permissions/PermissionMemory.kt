package com.nova.ai.permissions

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Remembers which permissions Android will no longer ask for, so "Grant" is not a silent no-op. Only the "asked / blocked" flags are kept;
 * whether a permission is GRANTED is always read live from Android.
 */
object PermissionMemory {
    private const val SP = "nova_perm_state"
    private fun sp(ctx: Context) = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE)
    private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun findActivity(ctx: Context): Activity? = generateSequence(ctx) { (it as? ContextWrapper)?.baseContext }.firstOrNull { it is Activity } as? Activity

    fun markAsked(ctx: Context, perms: List<String>) {
        val e = sp(ctx).edit(); perms.forEach { e.putBoolean("asked_$it", true) }; e.apply()
    }

    /** Call with the permissions from the system dialog's result. */
    fun afterResult(ctx: Context, activity: Activity?, perms: List<String>) {
        val e = sp(ctx).edit()
        for (p in perms) {
            if (granted(ctx, p)) { e.remove("blocked_$p"); continue }
            if (activity == null) continue
            val blocked = PermissionRules.permanentlyDenied(true, false, ActivityCompat.shouldShowRequestPermissionRationale(activity, p))
            e.putBoolean("blocked_$p", blocked)
        }
        e.apply()
    }

    /** True when at least one of [perms] is denied and Android will not show its dialog again. */
    fun isBlocked(ctx: Context, perms: List<String>): Boolean = perms.any { !granted(ctx, it) && sp(ctx).getBoolean("blocked_$it", false) }
}
