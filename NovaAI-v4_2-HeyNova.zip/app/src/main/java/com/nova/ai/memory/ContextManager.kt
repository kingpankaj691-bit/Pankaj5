package com.nova.ai.memory

import com.nova.ai.automation.RoutineManager

/**
 * Picks the few memories that matter for the message being answered, so the AI gets a short, relevant list rather than everything.
 * Low-confidence and expired items are skipped, and nothing is returned while memory is switched off.
 */
class ContextManager(private val repo: MemoryRepository) {

    private val stop = setOf("the", "and", "what", "when", "how", "you", "your", "that", "this", "with", "for", "are", "can", "did", "does",
        "kya", "hai", "hain", "mera", "meri", "mere", "aap", "ko", "ka", "ki", "ke", "se", "me", "mein", "nova", "normally", "usually")

    private fun live(): List<MemoryEntry> {
        val now = System.currentTimeMillis()
        return repo.all().filter { (it.expiresAt == 0L || it.expiresAt > now) && it.confidence != Confidence.LOW }
    }

    /** "- fact" lines for the AI prompt, most relevant first. */
    fun relevantFor(userText: String, limit: Int = 8): String {
        val words = userText.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 2 && it !in stop }.toSet()
        val days = RoutineManager.parseDays(userText)
        val scored = live().map { e ->
            val c = e.content.lowercase()
            var score = words.count { c.contains(it) } * 2.0
            if (days.isNotEmpty() && days.any { d -> RoutineManager.names.getValue(d).any { c.contains(it) } }) score += 4
            if (e.pinned) score += 1.5
            score += e.importance
            e to score
        }.filter { it.second >= 1.5 || it.first.pinned }.sortedByDescending { it.second }.take(limit)
        return scored.joinToString("\n") { "- " + it.first.content }
    }

    /** Everything saved that mentions the given day (code like "TUE"). */
    fun forDay(code: String): List<MemoryEntry> {
        val variants = RoutineManager.names.getValue(code)
        return live().filter { e -> val c = e.content.lowercase(); variants.any { Regex("\\b${Regex.escape(it)}\\b").containsMatchIn(c) } }
    }

    fun answerForDay(code: String): String {
        val day = RoutineManager.dayName(code)
        val found = forDay(code)
        if (!repo.enabled) return "Memory is switched off, so I'm not using saved routines."
        return if (found.isEmpty()) "I don't have anything saved for $day yet. Say \"remember that I ... every $day\" and I will."
        else "For $day you told me: " + found.take(4).joinToString("; ") { it.content }
    }
}
