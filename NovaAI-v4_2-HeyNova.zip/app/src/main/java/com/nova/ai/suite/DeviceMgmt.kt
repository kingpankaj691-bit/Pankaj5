package com.nova.ai.suite

import android.app.Activity
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings

/** Required for Device Owner / kiosk. It does nothing by itself and is removable (see "Release Device Owner"). */
class NovaDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) { SecurityWatch.log(context, "device-admin", "Nova became a device administrator") }
    override fun onDisabled(context: Context, intent: Intent) { SecurityWatch.log(context, "device-admin", "Nova is no longer a device administrator") }
}

data class AppRow(val pkg: String, val label: String, val version: String, val installedAt: Long, val system: Boolean)

/**
 * Legitimate device management: Device Owner status, kiosk (lock-task) mode, screen pinning, an installed-app inventory and the
 * restrictions YOU choose. Nothing is hidden: you can release Device Owner and unrestrict apps from the same screen, and Nova never
 * blocks the dialer, Settings, System UI or itself. App suspension needs Device Owner (Android rule); without it, restrictions only
 * make Nova's own launcher/agent refuse to open that app.
 */
object DeviceMgmt {
    private val protectedPkgs = setOf("com.android.settings", "com.android.systemui", "com.android.phone", "com.android.server.telecom",
        "com.google.android.dialer", "com.samsung.android.dialer", "com.android.dialer", "com.samsung.android.incallui", "com.android.emergency")

    fun admin(ctx: Context) = ComponentName(ctx, NovaDeviceAdminReceiver::class.java)
    private fun dpm(ctx: Context) = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isDeviceOwner(ctx: Context): Boolean = try { dpm(ctx).isDeviceOwnerApp(ctx.packageName) } catch (e: Exception) { false }
    fun adbCommand(ctx: Context) = "adb shell dpm set-device-owner ${ctx.packageName}/com.nova.ai.suite.NovaDeviceAdminReceiver"

    // ── kiosk / pinning ──
    fun enableKiosk(a: Activity): String {
        if (!isDeviceOwner(a)) return "Kiosk mode needs Device Owner. Run this once from a computer (phone must have no Google/Samsung account added): ${adbCommand(a)}"
        return try {
            dpm(a).setLockTaskPackages(admin(a), arrayOf(a.packageName))
            a.startLockTask()
            SecurityWatch.log(a, "kiosk", "Kiosk (lock task) turned on")
            "Kiosk is on: Nova is locked to the screen. To exit, use Device Management > Exit kiosk."
        } catch (e: Exception) { "Couldn't start kiosk: ${e.message}" }
    }

    fun exitKiosk(a: Activity): String = try {
        a.stopLockTask(); SecurityWatch.log(a, "kiosk", "Kiosk turned off"); "Kiosk is off."
    } catch (e: Exception) { "Nova wasn't pinned." }

    /** Screen pinning without Device Owner. Works only if "Pin windows" is on in Android settings. */
    fun pinScreen(a: Activity): String = try { a.startLockTask(); "Screen pinning requested. If nothing happened, turn on Settings > Biometrics and security > Other security settings > Pin windows." } catch (e: Exception) { "Screen pinning isn't available: ${e.message}" }

    fun openSecuritySettings(ctx: Context) = try { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }

    @Suppress("DEPRECATION")
    fun releaseOwner(ctx: Context): String {
        if (!isDeviceOwner(ctx)) return "Nova isn't Device Owner."
        return try {
            unsuspendAll(ctx)
            dpm(ctx).clearDeviceOwnerApp(ctx.packageName)
            SecurityWatch.log(ctx, "device-admin", "Device Owner released by you"); "Device Owner released. Nova is a normal app again."
        } catch (e: Exception) { "Couldn't release: ${e.message}" }
    }

    // ── battery optimisation ──
    fun batteryOptIgnored(ctx: Context) = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    fun requestBatteryExemption(ctx: Context) {
        try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { } }
    }

    // ── inventory ──
    fun inventory(ctx: Context): List<AppRow> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0).map { it.activityInfo.packageName }.distinct().mapNotNull { p ->
            try {
                val i = pm.getPackageInfo(p, 0)
                val ai = pm.getApplicationInfo(p, 0)
                AppRow(p, ai.loadLabel(pm).toString(), i.versionName ?: "?", i.firstInstallTime, (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
            } catch (e: Exception) { null }
        }.sortedBy { it.label.lowercase() }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (e: Exception) { false }
    }

    fun appInfo(ctx: Context, pkg: String) { try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }
    /** Opens Android's uninstall confirmation. Returns "" when it opened, otherwise why not (never silent, never protected apps). */
    fun uninstall(ctx: Context, pkg: String): String {
        val label = try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        (com.nova.ai.control.AppGuard.forUninstall(pkg, label, ctx.packageName, com.nova.ai.control.AppInstaller.isSystem(ctx, pkg)) as? com.nova.ai.control.AppVerdict.Refused)?.let { return it.reason }
        if (!com.nova.ai.control.AppInstaller.canUninstall(ctx)) return "This build doesn't hold the uninstall permission."
        return com.nova.ai.control.AppInstaller.openUninstallScreen(ctx, pkg)?.let { "Android's uninstall screen didn't open: $it" } ?: ""
    }

    // ── restrictions chosen by the user ──
    private fun sp(ctx: Context) = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)
    fun restricted(ctx: Context): Set<String> = sp(ctx).getStringSet("restricted_apps", emptySet()) ?: emptySet()
    fun isRestricted(ctx: Context, pkg: String) = restricted(ctx).contains(pkg)
    fun canRestrict(ctx: Context, pkg: String) = pkg != ctx.packageName && pkg !in protectedPkgs

    /** Adds or removes a restriction. With Device Owner the app is also suspended (greyed out system-wide); the result text says which. */
    fun setRestricted(ctx: Context, pkg: String, on: Boolean): String {
        if (on && !canRestrict(ctx, pkg)) return "Nova never restricts itself, Settings, System UI or the phone app."
        val cur = restricted(ctx).toMutableSet()
        if (on) cur.add(pkg) else cur.remove(pkg)
        sp(ctx).edit().putStringSet("restricted_apps", cur).apply()
        SecurityWatch.log(ctx, "restriction", (if (on) "Restricted " else "Unrestricted ") + pkg)
        if (isDeviceOwner(ctx)) {
            return try {
                val failed = dpm(ctx).setPackagesSuspended(admin(ctx), arrayOf(pkg), on)
                if (failed.isEmpty()) (if (on) "Suspended by Android (Device Owner). Open this screen to undo." else "Unsuspended.") else "Android refused to ${if (on) "suspend" else "unsuspend"} it."
            } catch (e: Exception) { "Saved, but suspension failed: ${e.message}" }
        }
        return if (on) "Restricted: Nova's voice launcher and agent won't open it. (Full blocking needs Device Owner.)" else "Restriction removed."
    }

    private fun unsuspendAll(ctx: Context) {
        val r = restricted(ctx).toTypedArray()
        if (r.isNotEmpty()) try { dpm(ctx).setPackagesSuspended(admin(ctx), r, false) } catch (e: Exception) { }
    }
}
