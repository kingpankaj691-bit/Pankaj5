package com.nova.ai.files

/** What the user asked for by voice or chat. Pure parsing (English / Hinglish); the UI decides what to show, and nothing here uploads or deletes. */
sealed class FileIntent {
    data class Read(val kinds: Set<FileKind>, val text: String) : FileIntent()
    data class Search(val query: SearchQuery, val label: String) : FileIntent()
    object LatestDownload : FileIntent()
    object SummarizeCurrent : FileIntent()
    object AnalyzeProject : FileIntent()
    object FindDuplicates : FileIntent()
    data class Organize(val folder: String) : FileIntent()
    object OpenManager : FileIntent()
}

/** The last file the user opened, read or selected, so "is document ka summary banao" knows what "this document" is. */
object FileContext { @Volatile var last: FileItem? = null }

object FileIntents {
    private val notFiles = listOf("message", "sms", "notification", "email", "mail", "news", "screen", "chat", "whatsapp", "contact", "weather", "book", "story", "kahani")
    private val fileWords = listOf("file", "files", "pdf", "docx", "document", "documents", "doc", "txt", "text file", "photo", "photos", "video", "videos", "apk", "zip", "folder", "download", "downloads", "dcim")
    private val chaff = setOf("nova", "hey", "please", "mera", "meri", "mere", "my", "the", "a", "an", "in", "on", "for", "of", "all", "mein", "me", "ka", "ki", "ke", "ko", "se", "karo", "kar", "do", "de", "dena",
        "file", "files", "folder", "wali", "wala", "wale", "search", "find", "dhundho", "dhoondo", "dhundo", "khojo", "dikhao", "show", "list", "locate", "padho", "padh", "read", "sunao", "kholo", "open", "ek", "koi", "mujhe", "i", "want", "to", "is", "hai", "and", "aur", "from", "with", "about", "any", "some", "that", "this")

    fun parse(raw: String, now: Long = System.currentTimeMillis()): FileIntent? {
        val t = raw.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim().removePrefix("hey nova ").removePrefix("nova ").trim()
        if (t.isEmpty()) return null
        val words = t.split(' ').toSet()
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun hasWord(vararg w: String) = w.any { it in words }
        if (notFiles.any { t.contains(it) } && !has("pdf", "docx", "apk", "file manager")) return null

        // 1. duplicates
        if (has("duplicate", "dublicate", "same files", "ek jaisi", "ek jaise") && has("file", "photo", "video", "document", "pdf", "download")) return FileIntent.FindDuplicates
        // 2. organize
        if (has("organize", "organise", "organiz", "sort my", "sort out") && has("document", "download", "file")) {
            val folder = when { has("download") -> "Download"; has("document") -> "Documents"; else -> "" }
            return FileIntent.Organize(folder)
        }
        // 3. coding project
        if (has("project") && hasWord("analyze", "analyse", "analysis", "explain", "samjhao", "scan", "check", "dekho", "review", "summary", "summarize")) return FileIntent.AnalyzeProject
        // 4. summary of the current document
        if (has("summary", "summarize", "summarise", "saransh", "khulasa", "summery") && has("document", "doc", "file", "pdf", "paper")) return FileIntent.SummarizeCurrent
        // 5. latest download
        if (has("latest", "newest", "last", "recent", "naya", "nayi", "sabse naya") && has("download") && has("open", "kholo", "khol", "dikhao", "show", "play")) return FileIntent.LatestDownload
        // 6. read a document aloud
        if (hasWord("padho", "padh", "read", "sunao", "parho") && has("pdf", "docx", "document", "doc ", "txt", "text file", "file")) {
            val kinds = when {
                has("pdf") -> FileTypes.kindsForWord("pdf")
                has("docx", "word") -> FileTypes.kindsForWord("docx")
                has("txt", "text file") -> FileTypes.kindsForWord("txt")
                else -> FileTypes.documentKinds
            }
            return FileIntent.Read(kinds, leftover(words))
        }
        // 7. search
        if (hasWord("search", "dhundho", "dhoondo", "dhundo", "khojo", "find", "locate", "dikhao", "show", "list")) {
            var folder = when {
                has("downloads", "download") -> "Download"
                has("dcim", "camera") -> "DCIM"
                has("pictures", "screenshots") -> "Pictures"
                has("movies") -> "Movies"
                has("documents folder", "documents mein", "documents me", "document folder") -> "Documents"
                else -> ""
            }
            val kinds = LinkedHashSet<FileKind>()
            for (w in words) { if (w == "documents" && folder == "Documents") continue; if (w == "download" || w == "downloads") continue; kinds.addAll(FileTypes.kindsForWord(w)) }
            if (kinds.isNotEmpty() || folder.isNotEmpty() || hasWord("file", "files")) {
                val days = when { has("today", "aaj") -> 1; has("yesterday", "kal") -> 2; has("this week", "is hafte", "week") -> 7; has("month", "mahine") -> 30; else -> 0 }
                val q = SearchQuery(text = leftover(words), kinds = kinds, folder = folder, sinceMs = if (days > 0) now - days * 86_400_000L else null)
                val label = listOfNotNull(kinds.firstOrNull()?.label?.let { "$it files" } ?: "files", if (folder.isNotEmpty()) "in $folder" else null).joinToString(" ")
                return FileIntent.Search(q, label)
            }
        }
        // 8. just open the manager
        if (has("file manager", "files manager", "file explorer")) return FileIntent.OpenManager
        return null
    }

    private fun leftover(words: Set<String>): String {
        val skip = HashSet<String>(chaff)
        for (w in words) if (FileTypes.kindsForWord(w).isNotEmpty() || w in setOf("download", "downloads", "dcim", "camera", "pictures", "movies", "today", "aaj", "kal", "yesterday", "week", "month", "word", "latest", "newest", "last")) skip.add(w)
        return words.filter { it !in skip && it.length > 2 }.joinToString(" ")
    }
}
