package com.nova.ai.brain

import org.json.JSONArray
import org.json.JSONObject

data class VerifyResult(val ok: Boolean, val message: String, val counts: Map<String, Int> = emptyMap())
data class RestoreResult(val added: Int, val merged: Int, val vault: Int)

/**
 * Export, import, verification and restore of the whole memory. The file is JSON; the encrypted form wraps it with AES-256-GCM
 * under a passphrase-derived key, so a wrong passphrase or a changed byte is detected. Pure Kotlin, no Android classes.
 */
object BackupManager {
    const val FORMAT = 1
    private val STATE_PREFIXES = listOf("profile.", "lang.", "cfg.")
    private const val MAX_TURNS = 300

    private fun itemJson(i: BrainItem) = JSONObject().put("id", i.id).put("cat", i.category.name).put("title", i.title).put("content", i.content)
        .put("project", i.project).put("topic", i.topicId).put("status", i.status).put("due", i.dueAt).put("imp", i.importance.toDouble())
        .put("created", i.createdAt).put("updated", i.updatedAt).put("used", i.lastUsedAt).put("src", i.source).put("pin", i.pinned).put("ver", i.version)

    fun export(store: BrainStore, now: Long, appVersion: String, vault: List<VaultPlain>? = null): String {
        val body = JSONObject()
        val items = store.items(); val topics = store.topics(); val projects = store.projects(); val files = store.files(); val reminders = store.reminders()
        val turns = store.turns(MAX_TURNS)
        val state = JSONObject()
        STATE_PREFIXES.forEach { p -> store.statePrefix(p).forEach { (k, v) -> if (v.isNotEmpty()) state.put(k, v) } }
        body.put("items", JSONArray(items.map { itemJson(it) }))
        body.put("topics", JSONArray(topics.map { JSONObject().put("id", it.id).put("title", it.title).put("keywords", it.keywords).put("summary", it.summary).put("last", it.lastStep).put("next", it.nextStep).put("un", it.unanswered).put("ins", it.instructions).put("project", it.project).put("status", it.status).put("created", it.createdAt).put("updated", it.updatedAt) }))
        body.put("projects", JSONArray(projects.map { JSONObject().put("id", it.id).put("name", it.name).put("status", it.status).put("desc", it.description).put("version", it.version).put("uri", it.rootUri).put("updated", it.updatedAt) }))
        body.put("files", JSONArray(files.map { JSONObject().put("project", it.projectId).put("uri", it.uri).put("name", it.name).put("rel", it.relPath).put("mime", it.mime).put("size", it.size).put("mod", it.modified).put("tokens", it.tokens) }))
        body.put("reminders", JSONArray(reminders.map { JSONObject().put("item", it.itemId).put("title", it.title).put("at", it.fireAt).put("rep", it.repeatMs).put("on", it.enabled) }))
        body.put("turns", JSONArray(turns.map { JSONObject().put("u", it.fromUser).put("t", it.text).put("ts", it.ts).put("topic", it.topicId) }))
        body.put("state", state)
        body.put("vault", JSONArray((vault ?: emptyList()).map { JSONObject().put("label", it.label).put("kind", it.kind.name).put("secret", it.secret) }))
        val bodyStr = body.toString()
        val counts = JSONObject().put("items", items.size).put("topics", topics.size).put("projects", projects.size).put("files", files.size)
            .put("reminders", reminders.size).put("turns", turns.size).put("vault", vault?.size ?: 0)
        return JSONObject().put("format", FORMAT).put("app", appVersion).put("createdAt", now).put("counts", counts)
            .put("sha256", Txt.sha256Hex(bodyStr.toByteArray(Charsets.UTF_8))).put("body", bodyStr).toString()
    }

    fun seal(json: String, pass: CharArray): ByteArray = VaultCrypto.seal(pass, json.toByteArray(Charsets.UTF_8))
    fun open(blob: ByteArray, pass: CharArray): String = String(VaultCrypto.open(pass, blob), Charsets.UTF_8)

    /** Checks structure, version, checksum and counts without touching the database. */
    fun verify(json: String): VerifyResult {
        return try {
            val root = JSONObject(json)
            if (root.optInt("format", 0) != FORMAT) return VerifyResult(false, "Unsupported backup version.")
            val bodyStr = root.getString("body")
            if (Txt.sha256Hex(bodyStr.toByteArray(Charsets.UTF_8)) != root.getString("sha256")) return VerifyResult(false, "The backup is damaged (checksum does not match).")
            val body = JSONObject(bodyStr); val c = root.getJSONObject("counts")
            val counts = LinkedHashMap<String, Int>()
            for (k in listOf("items", "topics", "projects", "files", "reminders", "turns", "vault")) {
                val n = body.getJSONArray(k).length()
                if (n != c.optInt(k, -1)) return VerifyResult(false, "The backup is incomplete ($k count differs).")
                counts[k] = n
            }
            VerifyResult(true, "Backup is valid.", counts)
        } catch (e: Exception) { VerifyResult(false, "This is not a valid NOVA backup.") }
    }

    /** [replace] = wipe current memory first (the vault is never wiped); otherwise merge and skip duplicates. */
    fun restore(store: BrainStore, json: String, replace: Boolean, importVault: (List<VaultPlain>) -> Int = { 0 }): RestoreResult {
        val v = verify(json)
        require(v.ok) { v.message }
        val body = JSONObject(JSONObject(json).getString("body"))
        var added = 0; var merged = 0
        val vaultPlain = ArrayList<VaultPlain>()
        store.tx {
            if (replace) store.wipeAll()
            val topicMap = HashMap<Long, Long>()
            val existingTopics = store.topics()
            val ta = body.getJSONArray("topics")
            for (i in 0 until ta.length()) {
                val o = ta.getJSONObject(i)
                val dup = existingTopics.firstOrNull { it.title == o.getString("title") && it.createdAt == o.getLong("created") }
                if (dup != null) { topicMap[o.getLong("id")] = dup.id; continue }
                val id = store.saveTopic(TopicRec(0, o.getString("title"), o.optString("keywords"), o.optString("summary"), o.optString("last"), o.optString("next"), o.optString("un"), o.optString("ins"), o.optString("project"), o.optString("status", "PAUSED").let { if (it == "ACTIVE") "PAUSED" else it }, o.getLong("created"), o.getLong("updated")))
                topicMap[o.getLong("id")] = id; added++
            }
            val itemMap = HashMap<Long, Long>()
            val ia = body.getJSONArray("items")
            val have = store.items().toMutableList()
            for (i in 0 until ia.length()) {
                val o = ia.getJSONObject(i)
                val cat = BrainCategory.parse(o.getString("cat")); val content = o.getString("content")
                val dup = have.firstOrNull { it.category == cat && Txt.similar(it.content, content) }
                if (dup != null) { itemMap[o.getLong("id")] = dup.id; merged++; continue }
                val item = BrainItem(0, cat, o.optString("title"), content, o.optString("project"), topicMap[o.optLong("topic")] ?: 0L, o.optString("status"), o.optLong("due"),
                    o.optDouble("imp", 0.6).toFloat(), o.optLong("created"), o.optLong("updated"), o.optLong("used"), o.optString("src", "backup"), o.optBoolean("pin"), Txt.hash(content), o.optInt("ver", 1))
                val id = store.saveItem(item)
                itemMap[o.getLong("id")] = id; have.add(item.copy(id = id)); added++
            }
            val pa = body.getJSONArray("projects")
            val projMap = HashMap<Long, Long>()
            val existingProj = store.projects()
            for (i in 0 until pa.length()) {
                val o = pa.getJSONObject(i)
                val dup = existingProj.firstOrNull { it.name.equals(o.getString("name"), true) }
                if (dup != null) { projMap[o.getLong("id")] = dup.id; continue }
                projMap[o.getLong("id")] = store.saveProject(ProjectRec(0, o.getString("name"), o.optString("status"), o.optString("desc"), o.optString("version"), o.optString("uri"), o.optLong("updated"))); added++
            }
            val fa = body.getJSONArray("files")
            val byProject = HashMap<Long, MutableList<FileRec>>()
            for (i in 0 until fa.length()) {
                val o = fa.getJSONObject(i)
                val pid = projMap[o.getLong("project")] ?: continue
                byProject.getOrPut(pid) { ArrayList() }.add(FileRec(0, pid, o.getString("uri"), o.getString("name"), o.optString("rel"), o.optString("mime"), o.optLong("size"), o.optLong("mod"), 0L, o.optString("tokens"), true))
            }
            // restored file records stay marked stale until the folder is indexed again, so nothing is claimed to exist without a check
            byProject.forEach { (pid, list) -> if (store.files(pid).isEmpty()) store.replaceFiles(pid, list) }
            val ra = body.getJSONArray("reminders")
            for (i in 0 until ra.length()) {
                val o = ra.getJSONObject(i)
                val item = itemMap[o.optLong("item")] ?: 0L
                if (store.reminders().none { it.title == o.getString("title") && it.fireAt == o.getLong("at") }) { store.saveReminder(ReminderRec(0, item, o.getString("title"), o.getLong("at"), o.optLong("rep"), o.optBoolean("on", true))); added++ }
            }
            val sa = body.getJSONObject("state")
            for (k in sa.keys()) if (STATE_PREFIXES.any { k.startsWith(it) } && (replace || store.getState(k).isNullOrEmpty())) store.putState(k, sa.getString(k))
            val va = body.getJSONArray("vault")
            for (i in 0 until va.length()) { val o = va.getJSONObject(i); vaultPlain.add(VaultPlain(o.getString("label"), try { VaultKind.valueOf(o.getString("kind")) } catch (e: Exception) { VaultKind.RECORD }, o.getString("secret"))) }
        }
        val vn = if (vaultPlain.isNotEmpty()) importVault(vaultPlain) else 0
        return RestoreResult(added, merged, vn)
    }
}
