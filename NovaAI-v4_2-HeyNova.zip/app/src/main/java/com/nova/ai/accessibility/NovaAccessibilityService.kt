package com.nova.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.nova.ai.screen.ScreenSnapshot
import com.nova.ai.screen.UiElement
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/**
 * Acts only when NOVA calls one of these functions after a user request. It listens to window-change events
 * just to know which app is in front (package name only, kept in memory) and never stores or uploads screen content.
 */
class NovaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        /** Last app seen by window events. Only a fallback: use [activePackage] for decisions. */
        @Volatile var foregroundPackage: String = ""
        /** Bumped on every window / content / text / focus event so callers can wait for "the screen changed". */
        val contentVersion = AtomicLong(0)
        private const val MAX_NODES = 600
        private const val MAX_DEPTH = 45
        private val ignoredPackages = setOf("com.android.systemui")

        /**
         * The app that is really in front right now. Prefers the live active window (immune to keyboard / overlay
         * events); falls back to the last window event only when the active window can't be read.
         */
        fun activePackage(): String {
            val svc = instance ?: return ""
            val live = try { svc.bestRoot()?.packageName?.toString().orEmpty() } catch (e: Exception) { "" }
            if (live.isNotBlank() && live !in ignoredPackages && live != svc.inputMethodPackage()) return live
            return foregroundPackage
        }
    }

    private var imePkg = ""
    private var imeCheckedAt = 0L

    /** Package of the user's current keyboard (cached for a few seconds). */
    internal fun inputMethodPackage(): String {
        val now = SystemClock.uptimeMillis()
        if (imeCheckedAt == 0L || now - imeCheckedAt > 15_000) {
            imeCheckedAt = now
            imePkg = try { Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD).orEmpty().substringBefore('/') } catch (e: Exception) { "" }
        }
        return imePkg
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        contentVersion.incrementAndGet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED, AccessibilityEvent.TYPE_VIEW_FOCUSED ->
                contentVersion.incrementAndGet()
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString().orEmpty()
            if (p.isBlank() || p in ignoredPackages || p == inputMethodPackage()) return
            // Keyboards, overlays (including NOVA's own orb) and system windows are not "the app in front".
            val wt = try { event.source?.window?.type } catch (e: Exception) { null }
            if (wt != null && wt != AccessibilityWindowInfo.TYPE_APPLICATION) return
            foregroundPackage = p
        }
    }

    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; foregroundPackage = ""; return super.onUnbind(intent) }
    override fun onDestroy() { if (instance === this) { instance = null; foregroundPackage = "" }; super.onDestroy() }

    /** Root of the window the user is looking at. Falls back to the top application window when Android reports no active one. */
    internal fun bestRoot(): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { return it }
        return try {
            windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .sortedByDescending { it.layer }
                .firstNotNullOfOrNull { it.root }
        } catch (e: Exception) { null }
    }

    /** True when a window tree can currently be read. */
    fun canReadScreen(): Boolean = try { bestRoot() != null } catch (e: Exception) { false }

    // ───────── reading ─────────
    fun snapshot(): ScreenSnapshot? {
        val root = bestRoot() ?: return null
        val out = ArrayList<UiElement>()
        val dm = resources.displayMetrics
        val screen = Rect(0, 0, dm.widthPixels, dm.heightPixels)
        try { walk(root, 0, out, screen) } catch (e: IllegalStateException) { /* node went stale mid-walk: return what we have */ }
        return ScreenSnapshot(root.packageName?.toString().orEmpty().ifBlank { foregroundPackage }, dm.widthPixels, dm.heightPixels, out)
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, out: MutableList<UiElement>, screen: Rect) {
        if (n == null || out.size >= MAX_NODES || depth > MAX_DEPTH) return
        if (n.isVisibleToUser) {
            val b = Rect(); n.getBoundsInScreen(b)
            val pw = n.isPassword
            val text = if (pw) "" else n.text?.toString().orEmpty()
            val desc = if (pw) "" else n.contentDescription?.toString().orEmpty()
            val hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString().orEmpty() else ""
            val interesting = text.isNotBlank() || desc.isNotBlank() || hint.isNotBlank() || n.isClickable || n.isEditable ||
                n.isScrollable || n.isCheckable || n.isLongClickable
            if (interesting && b.width() > 0 && b.height() > 0 && Rect.intersects(b, screen)) {
                out.add(UiElement(
                    index = out.size, text = text.take(300), desc = desc.take(300), hint = hint.take(100),
                    viewId = n.viewIdResourceName.orEmpty(), cls = n.className?.toString().orEmpty(),
                    pkg = n.packageName?.toString().orEmpty(), bounds = b,
                    clickable = n.isClickable, longClickable = n.isLongClickable, editable = n.isEditable,
                    scrollable = n.isScrollable, checkable = n.isCheckable, checked = n.isChecked,
                    selected = n.isSelected, focused = n.isFocused, enabled = n.isEnabled,
                    password = pw, depth = depth, node = n
                ))
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, out, screen)
    }

    /** Names of the tappable controls on the current screen (never password fields). */
    fun describeControls(max: Int = 12): String {
        val s = snapshot() ?: return "I can't see the screen right now."
        val names = s.clickable.filter { !it.password && it.label.isNotBlank() }.map { it.label.take(30) }.distinct().take(max)
        return if (names.isEmpty()) "I couldn't find tappable controls on this screen." else "You can tap: " + names.joinToString(", ") + "."
    }

    fun readScreen(): String {
        val s = snapshot() ?: return "I can't see the screen right now."
        val t = s.text()
        return if (t.isEmpty()) "I couldn't find readable text on this screen." else t
    }

    // ───────── node actions ─────────
    fun clickText(label: String): Boolean {
        val root = bestRoot() ?: return false
        for (node in root.findAccessibilityNodeInfosByText(label)) {
            var cur: AccessibilityNodeInfo? = node
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Click the element, or the nearest clickable ancestor, or fall back to a tap gesture on its centre. */
    fun clickElement(e: UiElement): Boolean {
        var cur: AccessibilityNodeInfo? = e.node
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; hops++
        }
        return gestureNow(tapPath(e.cx.toFloat(), e.cy.toFloat()), 0, 60)
    }

    fun longClickElement(e: UiElement): Boolean {
        var cur: AccessibilityNodeInfo? = e.node
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isLongClickable && cur.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
            cur = cur.parent; hops++
        }
        return gestureNow(tapPath(e.cx.toFloat(), e.cy.toFloat()), 0, 900)
    }

    fun focusElement(e: UiElement): Boolean =
        e.node?.let { it.performAction(AccessibilityNodeInfo.ACTION_FOCUS) || it.performAction(AccessibilityNodeInfo.ACTION_CLICK) } == true

    fun setTextOn(e: UiElement, text: String): Boolean {
        val n = e.node ?: return false
        try { n.refresh() } catch (ex: Exception) { return false }
        if (n.isPassword) return false
        if (!n.isFocused) n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Re-reads the element from the live screen and returns what it shows now (null if gone, unreadable or a password field). */
    fun freshText(e: UiElement): String? {
        val n = e.node ?: return null
        return try {
            if (!n.refresh() || n.isPassword) null
            else if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) ""
            else n.text?.toString().orEmpty()
        } catch (ex: Exception) { null }
    }

    /** Whether the element currently has input focus, read fresh from the screen. */
    fun isFocusedNow(e: UiElement): Boolean = try { e.node?.let { it.refresh() && it.isFocused } == true } catch (ex: Exception) { false }

    /** The text field that currently has input focus (accessibility focus lookup first, then a tree search). */
    internal fun focusedInput(): AccessibilityNodeInfo? {
        val root = bestRoot() ?: return null
        try { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let { return it } } catch (ex: Exception) { /* fall through */ }
        return findNode(root, 0) { it.isEditable && it.isFocused }
    }

    private fun findNode(n: AccessibilityNodeInfo?, depth: Int, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null || depth > MAX_DEPTH) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) findNode(n.getChild(i), depth + 1, pred)?.let { return it }
        return null
    }

    /**
     * Tap with proof of delivery: node click first, then a real gesture that we wait on. STALE = the element is gone
     * (screen changed since it was read), so nothing is tapped rather than hitting whatever moved there.
     */
    suspend fun tapElementDetailed(e: UiElement): TapMethod {
        val start = e.node
        if (start != null) {
            val fresh = try { start.refresh() } catch (ex: Exception) { false }
            if (!fresh) return TapMethod.STALE
        }
        var cur: AccessibilityNodeInfo? = start
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return TapMethod.NODE
            cur = cur.parent; hops++
        }
        val b = Rect()
        if (start != null) start.getBoundsInScreen(b) else b.set(e.bounds)
        if (b.width() <= 0 || b.height() <= 0) return TapMethod.NONE
        return if (gesture(listOf(Triple(tapPath(b.centerX().toFloat(), b.centerY().toFloat()), 0L, 60L)))) TapMethod.GESTURE else TapMethod.NONE
    }

    fun typeText(text: String): Boolean {
        val f = focusedInput() ?: return false
        if (f.isPassword) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /**
     * Types into the focused field and READS IT BACK. Returns null when the field really shows the text, otherwise the reason.
     * Refuses password, PIN, OTP and card fields. Used by every older "type this" path so none of them claims "typed" blindly.
     */
    fun typeTextChecked(text: String): String? {
        val f = focusedInput() ?: return "No text field has focus. Tap a text field first, then ask again."
        if (f.isPassword) return "That is a password field, so I won't type into it."
        val label = listOfNotNull(f.viewIdResourceName, if (Build.VERSION.SDK_INT >= 26) f.hintText?.toString() else null, f.contentDescription?.toString()).joinToString(" ")
        if (com.nova.ai.screen.ActionValidator.isSecretField(label)) return "That looks like a password, PIN or OTP field, so I won't type into it. Please enter it yourself."
        if (!typeText(text)) return "Android didn't accept text in that field."
        SystemClock.sleep(150)
        val shown = focusedFieldText()
        return if (TextVerify.matches(text, shown)) null else "I sent the text but the field shows \"${shown.orEmpty().take(40)}\" instead, so I won't call it typed."
    }

    /** Presses Enter/Search on the focused input (Android 11+). */
    fun imeEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = focusedInput() ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = bestRoot() ?: return false
        val target = findScrollable(root) ?: return false
        return target.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) { val c = n.getChild(i) ?: continue; findScrollable(c)?.let { return it } }
        return null
    }

    // ───────── gestures (official dispatchGesture) ─────────
    fun tapPath(x: Float, y: Float) = Path().apply { moveTo(x, y); lineTo(x + 0.5f, y + 0.5f) }

    private fun description(strokes: List<Triple<Path, Long, Long>>): GestureDescription {
        val b = GestureDescription.Builder()
        strokes.forEach { (p, start, dur) -> b.addStroke(GestureDescription.StrokeDescription(p, start, dur.coerceAtLeast(1))) }
        return b.build()
    }

    /** Fire-and-forget; returns whether Android accepted the gesture. */
    fun gestureNow(path: Path, start: Long, dur: Long): Boolean =
        try { dispatchGesture(description(listOf(Triple(path, start, dur))), null, null) } catch (e: Exception) { false }

    /** Suspends until the gesture completes or is cancelled. */
    suspend fun gesture(strokes: List<Triple<Path, Long, Long>>): Boolean = suspendCancellableCoroutine { c ->
        val ok = try {
            dispatchGesture(description(strokes), object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { if (c.isActive) c.resume(true) }
                override fun onCancelled(g: GestureDescription?) { if (c.isActive) c.resume(false) }
            }, null)
        } catch (e: Exception) { false }
        if (!ok && c.isActive) c.resume(false)
    }

    // ───────── global actions ─────────
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun screenSize(): Pair<Int, Int> = resources.displayMetrics.let { it.widthPixels to it.heightPixels }

    // ───────── text selection / copy ─────────
    /** Text currently selected in any visible field (Android reports selections of editable and, on many apps, selectable text). */
    fun selectedText(): String? {
        fun scan(n: AccessibilityNodeInfo?, depth: Int): String? {
            if (n == null || depth > 40) return null
            val t = n.text
            if (!n.isPassword && t != null && n.textSelectionStart >= 0 && n.textSelectionEnd > n.textSelectionStart && n.textSelectionEnd <= t.length)
                return t.subSequence(n.textSelectionStart, n.textSelectionEnd).toString()
            for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1)?.let { return it }
            return null
        }
        return scan(bestRoot(), 0)
    }

    /** Text of the focused input field, if any (never password fields). */
    fun focusedFieldText(): String? {
        val f = focusedInput() ?: return null
        return if (f.isPassword) null else f.text?.toString()
    }

    /** Selects all text in the focused input field. */
    fun selectAllInFocused(): Boolean {
        val f = focusedInput() ?: return false
        if (f.isPassword) return false
        val len = f.text?.length ?: return false
        val args = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
    }

    /** Asks the focused field to copy its current selection to the clipboard (the app decides if it allows it). */
    fun copySelectionAction(): Boolean = focusedInput()?.performAction(AccessibilityNodeInfo.ACTION_COPY) ?: false
}
