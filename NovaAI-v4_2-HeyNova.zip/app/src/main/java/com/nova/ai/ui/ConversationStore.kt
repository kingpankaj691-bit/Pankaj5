package com.nova.ai.ui

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Restores the last chat after the app is closed. Stored privately; can be turned off or deleted in Settings. */
class ConversationStore(ctx: Context) {
    private val file = File(ctx.filesDir, "conversation.json")
    fun save(list: List<ChatMsg>) {
        try { file.writeText(JSONArray(list.map { JSONObject().put("u", it.fromUser).put("t", it.text) }).toString()) } catch (e: Exception) { }
    }
    fun load(): List<ChatMsg> = try {
        if (!file.exists()) emptyList() else JSONArray(file.readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> ChatMsg(o.getBoolean("u"), o.getString("t")) } } }
    } catch (e: Exception) { emptyList() }
    fun delete() { try { file.delete() } catch (e: Exception) { } }
}
