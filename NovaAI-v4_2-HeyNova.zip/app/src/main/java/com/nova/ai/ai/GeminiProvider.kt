package com.nova.ai.ai

import com.nova.ai.ai.model.ModelManager
import com.nova.ai.ai.model.ModelRouter
import com.nova.ai.ai.net.ChatRequestBuilder
import com.nova.ai.ai.net.GeminiError
import com.nova.ai.ai.net.GeminiErrorKind
import com.nova.ai.ai.net.GeminiRestClient
import com.nova.ai.ai.net.GeminiTimeouts
import com.nova.ai.ai.net.GenerationConfigBuilder
import com.nova.ai.ai.net.ResponseParser
import com.nova.ai.ai.net.RetryPolicy
import com.nova.ai.core.AIProvider
import com.nova.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class AiResult {
    data class Ok(val text: String) : AiResult()
    /** [error] carries the classified cause when the failure came from Gemini; [msg] is always the text to show. */
    data class Err(val msg: String, val error: GeminiError? = null) : AiResult()
}

/**
 * Gemini chat through generateContent. It uses EXACTLY the model it is given (or the selected model when none is given):
 * if that model cannot answer or is unavailable the user is told why; it never falls back to a different model.
 */
class GeminiProvider(
    private val prefs: Prefs,
    private val client: GeminiRestClient = GeminiRestClient.shared
) : AIProvider {

    /** history: list of (isUser, text), oldest first. */
    override suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String?): AiResult =
        withContext(Dispatchers.IO) {
            if (prefs.localOnly) return@withContext AiResult.Err("Local-only mode is on. Gemini is not used.")
            val key = prefs.apiKey
            if (key.isBlank()) {
                val e = GeminiError(GeminiErrorKind.NO_KEY)
                return@withContext AiResult.Err(e.userMessage(), e)
            }
            val id = ModelCatalog.clean(model, prefs.model)
            val info = ModelManager.findCached(id)
            ModelRouter.chatProblem(id, info)?.let { return@withContext AiResult.Err(it.userMessage(id), it) }

            val body = ChatRequestBuilder.build(
                history, system,
                GenerationConfigBuilder.build(prefs.temperature.toDouble(), prefs.maxTokens, info)
            )
            val timeouts = GeminiRestClient.Timeouts(GeminiTimeouts.CONNECT_MS, GeminiTimeouts.responseMs(id, prefs.maxTokens))
            when (val r = client.generate(key, id, body, timeouts, RetryPolicy.chat())) {
                is GeminiRestClient.Result.Fail -> AiResult.Err(r.error.userMessage(id), r.error)
                is GeminiRestClient.Result.Ok -> {
                    val parsed = ResponseParser.parse(r.json, id)
                    val err = parsed.error
                    if (err != null) AiResult.Err(err.userMessage(id), err) else AiResult.Ok(parsed.text)
                }
            }
        }
}
