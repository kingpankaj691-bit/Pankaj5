package com.nova.ai.scanner

import android.Manifest
import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.storage.StorageManager
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.telephony.TelephonyManager
import android.view.Display
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.security.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import kotlin.coroutines.resume

/**
 * Everything the scanner knows about what this phone can do, in one place: deeper hardware facts (CPU, GPU API, thermal, speech,
 * biometrics) and the NOVA capability matrix. Uses only normal public APIs; anything Android hides is reported as Restricted.
 */
class HardwareCapabilityManager(private val ctx: Context, private val prefs: Prefs) {
    private val pm = ctx.packageManager
    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun has(f: String) = pm.hasSystemFeature(f)
    private fun yn(b: Boolean) = if (b) "Yes" else "No"

    // ───────── processor / graphics / thermal ─────────
    fun processor(): ScanSection {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until cores).mapNotNull { readLong("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq") }
        val maxMhz = freqs.maxOrNull()?.div(1000)
        val minMhz = (0 until cores).mapNotNull { readLong("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_min_freq") }.minOrNull()?.div(1000)
        val gl = am.deviceConfigurationInfo.glEsVersion
        val items = mutableListOf(
            ScanItem("Architecture (ABIs)", Build.SUPPORTED_ABIS.joinToString()),
            ScanItem("64-bit", yn(Build.SUPPORTED_64_BIT_ABIS.isNotEmpty())),
            ScanItem("Cores", cores.toString()),
            if (maxMhz != null) ScanItem("Max clock", "$maxMhz MHz") else ScanItem("Max clock", "Not exposed on this phone", "Restricted"),
            if (minMhz != null) ScanItem("Min clock", "$minMhz MHz") else ScanItem("Min clock", "Not exposed on this phone", "Restricted"),
            ScanItem("Board / chipset", "${Build.BOARD} / ${Build.HARDWARE}"),
            ScanItem("OpenGL ES", gl),
            ScanItem("Vulkan", if (has("android.hardware.vulkan.version")) "Supported" else "Not reported", if (has("android.hardware.vulkan.version")) "Available" else "Not available"),
            ScanItem("App memory class", "${am.memoryClass} MB (large: ${am.largeMemoryClass} MB)"),
            ScanItem("Low-RAM device", yn(am.isLowRamDevice)),
            ScanItem("Low-memory threshold", "${mi.threshold / 1048576} MB")
        )
        if (Build.VERSION.SDK_INT >= 31) items.add(ScanItem("SoC", "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"))
        if (Build.VERSION.SDK_INT >= 29) {
            val t = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
            val name = listOf("None", "Light", "Moderate", "Severe", "Critical", "Emergency", "Shutdown").getOrElse(t) { "Unknown" }
            items.add(ScanItem("Thermal status", name, if (t >= 3) "Restricted" else null))
        }
        return ScanSection("processor", "Processor & graphics", "${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"} • $cores cores" + (maxMhz?.let { " • up to $it MHz" } ?: ""), null, items)
    }

    private fun readLong(path: String): Long? = try { File(path).readText().trim().toLongOrNull() } catch (e: Exception) { null }

    // ───────── speech + languages ─────────
    suspend fun speech(): ScanSection {
        val rec = SpeechRecognizer.isRecognitionAvailable(ctx)
        val onDevice = if (Build.VERSION.SDK_INT >= 33) SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx) else null
        val engines = pm.queryIntentServices(Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0).map { it.loadLabel(pm).toString() }
        var voices = 0; var langs = emptyList<String>(); var offlineVoices = 0
        val tts = withTimeoutOrNull(2500) {
            suspendCancellableCoroutine<TextToSpeech?> { c ->
                var t: TextToSpeech? = null
                t = TextToSpeech(ctx) { st -> if (c.isActive) c.resume(if (st == TextToSpeech.SUCCESS) t else null) }
            }
        }
        if (tts != null) {
            try {
                val v = tts.voices ?: emptySet()
                voices = v.size; offlineVoices = v.count { !it.isNetworkConnectionRequired }
                langs = v.map { it.locale.displayLanguage }.filter { it.isNotBlank() }.distinct().sorted()
            } catch (e: Exception) {}
            tts.shutdown()
        }
        val device = ctx.resources.configuration.locales.let { l -> (0 until l.size()).map { l[it].toLanguageTag() } }
        val items = listOf(
            ScanItem("Speech recognition", if (rec) "Available" else "Not available", if (rec) "Available" else "Not available"),
            when (onDevice) {
                true -> ScanItem("Offline recognition (on-device)", "Available", "Available")
                false -> ScanItem("Offline recognition (on-device)", "Not available on this phone", "Not available")
                null -> ScanItem("Offline recognition (on-device)", "Android 13+ needed to check; NOVA asks the engine to prefer offline", "Restricted")
            },
            ScanItem("Microphone permission", if (granted(Manifest.permission.RECORD_AUDIO)) "Granted" else "Not granted", if (granted(Manifest.permission.RECORD_AUDIO)) "Available" else "Restricted"),
            ScanItem("Text-to-speech engines", "${engines.size}", null, engines.joinToString("\n")),
            ScanItem("TTS voices", "$voices ($offlineVoices work offline)"),
            ScanItem("TTS languages installed", "${langs.size}", null, langs.joinToString(", ")),
            ScanItem("Device languages", device.joinToString()),
            ScanItem("Wake word hardware", "No hotword hardware or engine is used; Background Voice streams microphone audio to speech-to-text", "Not available")
        )
        return ScanSection("speech", "Speech & language", "${engines.size} TTS engine(s) • $voices voices • recognition ${if (rec) "on" else "off"}", null, items)
    }

    // ───────── extra facts appended to existing sections ─────────
    fun extras(id: String): List<ScanItem> = try { when (id) {
        "display" -> displayExtras(); "battery" -> batteryExtras(); "network" -> networkExtras(); "wifi" -> wifiExtras()
        "bluetooth" -> bluetoothExtras(); "storage" -> storageExtras(); "sensors" -> sensorExtras(); "cameras" -> cameraExtras()
        "memory" -> memoryExtras(); else -> emptyList()
    } } catch (e: Exception) { emptyList() }

    private fun displayExtras(): List<ScanItem> {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY) ?: return emptyList()
        val dm = ctx.resources.displayMetrics
        val inches = Math.sqrt(Math.pow(dm.widthPixels / dm.xdpi.toDouble(), 2.0) + Math.pow(dm.heightPixels / dm.ydpi.toDouble(), 2.0))
        val out = mutableListOf(ScanItem("Physical size", "%.1f inches".format(inches)), ScanItem("Wide colour gamut", yn(d.isWideColorGamut)),
            ScanItem("Night mode (dark theme)", yn((ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)))
        if (Build.VERSION.SDK_INT >= 26) {
            val hdr = d.hdrCapabilities?.supportedHdrTypes?.map { when (it) { Display.HdrCapabilities.HDR_TYPE_HDR10 -> "HDR10"; Display.HdrCapabilities.HDR_TYPE_HLG -> "HLG"; Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> "Dolby Vision"; Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS -> "HDR10+"; else -> "Type $it" } } ?: emptyList()
            out.add(ScanItem("HDR", if (hdr.isEmpty()) "Not reported" else hdr.joinToString()))
        }
        if (Build.VERSION.SDK_INT >= 31) out.add(ScanItem("Round screen", yn(ctx.resources.configuration.isScreenRound)))
        return out
    }

    private fun batteryExtras(): List<ScanItem> {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val out = mutableListOf<ScanItem>()
        val cap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (cap > 0) out.add(ScanItem("Capacity reading", "$cap%"))
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (cc > 0 && cc != Long.MIN_VALUE) out.add(ScanItem("Charge counter", "${cc / 1000} mAh"))
        else out.add(ScanItem("Battery capacity (mAh)", "Not exposed by Android", "Restricted"))
        val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (cur != Int.MIN_VALUE && cur != 0) out.add(ScanItem("Current draw", "${cur / 1000} mA"))
        val b = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (Build.VERSION.SDK_INT >= 34) { val cyc = b?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1; out.add(if (cyc >= 0) ScanItem("Charge cycles", "$cyc") else ScanItem("Charge cycles", "Not exposed", "Restricted")) }
        else out.add(ScanItem("Charge cycles", "Needs Android 14", "Restricted"))
        out.add(ScanItem("Voltage", "${(b?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0)} mV"))
        return out
    }

    private fun networkExtras(): List<ScanItem> {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val out = mutableListOf<ScanItem>()
        if (caps != null) {
            val t = listOf(NetworkCapabilities.TRANSPORT_WIFI to "Wi-Fi", NetworkCapabilities.TRANSPORT_CELLULAR to "Cellular", NetworkCapabilities.TRANSPORT_BLUETOOTH to "Bluetooth", NetworkCapabilities.TRANSPORT_ETHERNET to "Ethernet", NetworkCapabilities.TRANSPORT_VPN to "VPN").filter { caps.hasTransport(it.first) }.map { it.second }
            out.add(ScanItem("Transports", t.joinToString().ifBlank { "None" }))
            out.add(ScanItem("Uplink estimate", "${caps.linkUpstreamBandwidthKbps / 1000} Mbps"))
            out.add(ScanItem("Roaming", yn(!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING))))
        }
        out.add(ScanItem("Data saver", when (cm.restrictBackgroundStatus) { ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED -> "On"; ConnectivityManager.RESTRICT_BACKGROUND_STATUS_WHITELISTED -> "On (NOVA allowed)"; else -> "Off" }))
        (ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.let { tm ->
            if (has("android.hardware.telephony")) {
                out.add(ScanItem("SIM state", when (tm.simState) { TelephonyManager.SIM_STATE_READY -> "Ready"; TelephonyManager.SIM_STATE_ABSENT -> "No SIM"; TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN required"; else -> "Other" }))
                tm.networkOperatorName?.takeIf { it.isNotBlank() }?.let { out.add(ScanItem("Carrier", it)) }
            }
        }
        out.add(ScanItem("Airplane mode", yn(android.provider.Settings.Global.getInt(ctx.contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1)))
        return out
    }

    private fun wifiExtras(): List<ScanItem> {
        val w = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val out = mutableListOf(ScanItem("5 GHz band", yn(w.is5GHzBandSupported)), ScanItem("Wi-Fi Direct", yn(has("android.hardware.wifi.direct"))))
        if (Build.VERSION.SDK_INT >= 30) {
            out.add(ScanItem("Wi-Fi 6 (802.11ax)", yn(w.isWifiStandardSupported(android.net.wifi.ScanResult.WIFI_STANDARD_11AX))))
            out.add(ScanItem("Wi-Fi 5 (802.11ac)", yn(w.isWifiStandardSupported(android.net.wifi.ScanResult.WIFI_STANDARD_11AC))))
        }
        if (Build.VERSION.SDK_INT >= 31) out.add(ScanItem("6 GHz band", yn(w.is6GHzBandSupported)))
        out.add(ScanItem("Add-network dialog (NOVA)", if (Build.VERSION.SDK_INT >= 30) "Available" else "Needs Android 11", if (Build.VERSION.SDK_INT >= 30) "Available" else "Not available"))
        return out
    }

    private fun bluetoothExtras(): List<ScanItem> {
        val a = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter ?: return emptyList()
        val out = mutableListOf(ScanItem("Bluetooth LE", yn(has("android.hardware.bluetooth_le"))))
        out.add(ScanItem("LE 2M PHY", yn(a.isLe2MPhySupported))); out.add(ScanItem("LE Coded PHY (long range)", yn(a.isLeCodedPhySupported)))
        out.add(ScanItem("LE extended advertising", yn(a.isLeExtendedAdvertisingSupported)))
        out.add(ScanItem("Nearby scan permission", if (Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_SCAN)) "Granted" else "Not granted", if (Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_SCAN)) "Available" else "Restricted"))
        return out
    }

    private fun storageExtras(): List<ScanItem> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val vols = sm.storageVolumes
        val out = mutableListOf(ScanItem("Storage volumes", "${vols.size}", null, vols.joinToString("\n") { it.getDescription(ctx) + if (it.isRemovable) " (removable)" else "" }))
        out.add(ScanItem("SD card / removable", yn(vols.any { it.isRemovable })))
        return out
    }

    private fun memoryExtras(): List<ScanItem> {
        val mi = ActivityManager.MemoryInfo().also { (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it) }
        return listOf(ScanItem("Low-memory state now", yn(mi.lowMemory)))
    }

    private fun sensorExtras(): List<ScanItem> {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val all = sm.getSensorList(Sensor.TYPE_ALL)
        val vendors = all.map { it.vendor }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5)
        return listOf(ScanItem("Total sensors", "${all.size}", null, all.joinToString("\n") { it.name }),
            ScanItem("Main vendors", vendors.joinToString { "${it.key} (${it.value})" }),
            ScanItem("Heart-rate sensor", yn(sm.getDefaultSensor(Sensor.TYPE_HEART_RATE) != null)),
            ScanItem("Significant motion / step detector", yn(sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null)))
    }

    private fun cameraExtras(): List<ScanItem> {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val out = mutableListOf<ScanItem>()
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString { "%.1f mm".format(it) } ?: "?"
            val ap = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString { "f/%.1f".format(it) } ?: "?"
            val ois = (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.any { it == CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON } == true)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
            val raw = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
            val zoom = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
            val mp = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let { "%.1f MP".format(it.width * it.height / 1_000_000.0) } ?: "?"
            val video = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(android.media.MediaRecorder::class.java)?.maxByOrNull { it.width * it.height }?.let { "${it.width}x${it.height}" } ?: "?"
            out.add(ScanItem("Camera $id details", "$mp • max video $video", null, "Focal: $focal\nAperture: $ap\nOptical stabilization: ${yn(ois)}\nRAW: ${yn(raw)}\nMax digital zoom: ${zoom ?: "?"}x"))
        }
        out.add(ScanItem("Camera permission", if (granted(Manifest.permission.CAMERA)) "Granted" else "Not granted", if (granted(Manifest.permission.CAMERA)) "Available" else "Restricted"))
        return out
    }

    // ───────── NOVA capability matrix ─────────
    suspend fun novaMatrix(): ScanSection {
        val items = mutableListOf<ScanItem>()
        fun add(label: String, ok: Boolean, why: String, needs: String? = null) {
            val st = if (ok) "Available" else if (needs != null) "Restricted" else "Not available"
            items.add(ScanItem(label, if (ok) "Ready" else (needs ?: "Not available on this phone"), st, why))
        }
        add("Flashlight control", has("android.hardware.camera.flash"), "Torch on/off by voice")
        add("Voice commands (speech-to-text)", SpeechRecognizer.isRecognitionAvailable(ctx) && granted(Manifest.permission.RECORD_AUDIO), "Mic permission and a speech engine",
            if (SpeechRecognizer.isRecognitionAvailable(ctx) && !granted(Manifest.permission.RECORD_AUDIO)) "Needs Microphone permission" else null)
        add("Spoken replies (text-to-speech)", pm.queryIntentServices(Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0).isNotEmpty(), "An installed TTS engine")
        val a11y = NovaAccessibilityService.instance != null
        add("Screen reading & actions", a11y && Build.VERSION.SDK_INT >= 24, "Accessibility service: tap, swipe, scroll, type", if (!a11y) "Needs Accessibility to be turned on" else null)
        add("Screen Vision (screenshot understanding)", true, "MediaProjection after your approval; Android 14+ asks every time")
        val bio = try { BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) } catch (e: Exception) { BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE }
        add("Biometric protection (Owner Mode)", bio == BiometricManager.BIOMETRIC_SUCCESS, "Fingerprint/face for sensitive actions",
            if (bio == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) "Needs a fingerprint or face enrolled in Android" else null)
        add("Notification assistant", androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName), "Read, summarize, dismiss, open", "Needs Notification access")
        add("Calls & contacts", has("android.hardware.telephony") && granted(Manifest.permission.READ_CONTACTS), "Open contacts, dial", if (has("android.hardware.telephony")) "Needs Contacts permission" else null)
        add("Bluetooth status & nearby scan", has("android.hardware.bluetooth") && (Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_SCAN)), "Status, discovery, settings",
            if (has("android.hardware.bluetooth")) "Needs Nearby devices permission" else null)
        add("Wi-Fi add-network dialog", Build.VERSION.SDK_INT >= 30, "Android 11+ system dialog; passwords never read")
        add("Background assistant (foreground service)", true, "Visible notification with Pause/Stop")
        add("Boot recovery", true, "Restores state after Android boots; cannot run while the phone is off")
        add("Calendar reading", granted(Manifest.permission.READ_CALENDAR), "Schedule questions", if (!granted(Manifest.permission.READ_CALENDAR)) "Needs Calendar permission" else null)
        add("Location-aware weather", granted(Manifest.permission.ACCESS_COARSE_LOCATION) || granted(Manifest.permission.ACCESS_FINE_LOCATION), "Optional; a home city works without it", "Optional: Location permission")
        add("Camera questions", has("android.hardware.camera.any"), "Take a photo and ask about it")
        add("Gemini cloud brain", prefs.apiKey.isNotBlank() && prefs.aiEnabled && !prefs.localOnly, "Needs API key, internet, local-only off",
            if (prefs.apiKey.isBlank()) "Needs an API key" else if (prefs.localOnly) "Local-only mode is on" else null)
        add("Offline brain (OfflineProvider)", true, "Device commands, notes, memory, calculator, timers")
        add("On-device language model", false, "Not built; OfflineProvider answers only local tasks")
        add("Low-power always-on wake word", false, "Not used. Background Voice captures audio continuously with AudioRecord")
        val ready = items.count { it.status == "Available" }
        return ScanSection("nova", "NOVA readiness", "$ready of ${items.size} abilities ready", ready / items.size.toFloat(), items)
    }
}
