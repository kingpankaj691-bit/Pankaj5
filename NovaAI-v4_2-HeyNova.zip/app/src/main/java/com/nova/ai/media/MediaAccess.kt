package com.nova.ai.media

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/** What Nova can really read right now. Never "assumed": derived from the permissions Android reports. */
enum class MediaAccessLevel { FULL, IMAGES_ONLY, VIDEOS_ONLY, SELECTED_ONLY, NONE }

object MediaAccess {
    /** Pure rule, unit-testable. */
    fun levelFor(sdk: Int, images: Boolean, videos: Boolean, selected: Boolean, legacy: Boolean): MediaAccessLevel = when {
        sdk >= 33 -> when {
            images && videos -> MediaAccessLevel.FULL
            images -> MediaAccessLevel.IMAGES_ONLY
            videos -> MediaAccessLevel.VIDEOS_ONLY
            sdk >= 34 && selected -> MediaAccessLevel.SELECTED_ONLY
            else -> MediaAccessLevel.NONE
        }
        else -> if (legacy) MediaAccessLevel.FULL else MediaAccessLevel.NONE
    }

    /** What to ask for. On Android 14+ all three go in ONE request so the system can offer "Select photos and videos". */
    fun permissionsToRequest(sdk: Int): List<String> = when {
        sdk >= 34 -> listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        sdk >= 33 -> listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun level(ctx: Context): MediaAccessLevel = levelFor(
        Build.VERSION.SDK_INT,
        granted(ctx, Manifest.permission.READ_MEDIA_IMAGES), granted(ctx, Manifest.permission.READ_MEDIA_VIDEO),
        Build.VERSION.SDK_INT >= 34 && granted(ctx, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED),
        granted(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)
    )

    fun describe(l: MediaAccessLevel) = when (l) {
        MediaAccessLevel.FULL -> "Full access to photos and videos"
        MediaAccessLevel.IMAGES_ONLY -> "Photos only (videos not allowed)"
        MediaAccessLevel.VIDEOS_ONLY -> "Videos only (photos not allowed)"
        MediaAccessLevel.SELECTED_ONLY -> "Only the photos and videos you selected"
        MediaAccessLevel.NONE -> "No access. Nova can't see any of your photos or videos."
    }
}
