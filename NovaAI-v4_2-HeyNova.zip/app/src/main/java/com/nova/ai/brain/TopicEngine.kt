package com.nova.ai.brain

sealed class TopicDecision {
    object None : TopicDecision()
    data class Started(val topic: TopicRec) : TopicDecision()
    data class Continued(val topic: TopicRec) : TopicDecision()
    /** The user explicitly changed topic, or asked a clearly unrelated question. The old topic is kept (paused) and can be resumed. */
    data class Switched(val topic: TopicRec, val from: TopicRec?, val reason: String) : TopicDecision()
    data class Resumed(val topic: TopicRec, val from: TopicRec?) : TopicDecision()
    /** Not sure whether the user changed topic. The current topic is kept and the AI is told to ask. */
    data class Uncertain(val topic: TopicRec) : TopicDecision()
}

/** What the user is asking about the conversation itself. */
enum class TopicQuery { RECAP, RESUME }

/**
 * Topic lock and recovery. The active topic changes only when the user explicitly says so or asks a clearly unrelated question;
 * short or incomplete sentences and references like "ye" or "usmein" always stay in the current topic. Pure logic over a [BrainStore].
 */
class TopicEngine(private val store: BrainStore) {
    companion object {
        private val hindiRef = Regex("(?i)\\b(ye|yeh|isme|ismein|isko|iska|iski|iske|isse|usmein|usme|usko|uska|uski|uske|usse|wahi|wohi|woh|wo|pichhli|pichli|previous|above|upar|same)\\b|\\b(is|us|iss|uss)\\s+(project|app|feature|kaam|file|code|baat|topic|task)\\b")
        private val engRef = Regex("(?i)\\b(it|this|that|those|these|them|there)\\b")
        private val newTopic = Regex("(?i)((naya|nayi|new|doosra|dusra|doosri|dusri|alag|different)\\s+(topic|sawal|question|baat|vishay|subject)|topic\\s+(change|badlo|badal)|change\\s+(the\\s+)?(topic|subject)|(let'?s|lets)\\s+(talk|discuss|switch|move)\\s+(about|to|on)|ab\\s+(.+?)\\s+(par|pe|ki|ke baare mein)\\s+(baat|chat|discuss)|chalo\\s+(ab\\s+)?(.+?)\\s+(par|pe|ki)\\s+(baat|chat|discuss)|ek\\s+aur\\s+(sawal|baat)|ek\\s+dusri\\s+baat|ab\\s+kuch\\s+(aur|naya)|chhodo\\s+(ye|isse|ise)|chodo\\s+ye)")
        private val recap = Regex("(?i)(hum\\s+(kya|kis)\\s+.{0,30}(rahe the|rahe thae)|kahan\\s+tak\\s+(pahunche|pahuche|aaye|pohche)|where\\s+(did|were)\\s+we|what\\s+(were|are)\\s+we\\s+(doing|working|building|discussing)|kis\\s+(baare|topic)\\s+mein\\s+baat|hum\\s+kya\\s+(bana|kar|discuss)|summary\\s+of\\s+(this|our)\\s+(conversation|discussion|chat)|abhi\\s+tak\\s+kya\\s+(hua|baat))")
        private val resume = Regex("(?i)((purani|pichhli|pichli|old|previous|pehle\\s+wali)\\s+(wali\\s+)?(baat|conversation|discussion|topic|chat)|continue\\s+(karte|karo|kar|karna)|wahi\\s+(project|kaam|baat|topic).{0,20}(continue|aage)|jo\\s+kaam\\s+(adhura|pending)|adhura\\s+(chhoda|kaam)|kal\\s+wali\\s+baat|\\bresume\\b|let'?s\\s+continue|we\\s+were\\s+talking\\s+about)")
        private val doneRe = Regex("(?i)(ho gaya|ho gayi|ho chuka|complete ho|khatam|\\bdone\\b|finished|completed)")
        private val nextRe = Regex("(?i)(\\bnext\\b|uske baad|iske baad|phir hum|ab hum|agla|\\bthen we\\b|ab .{0,30}karte hain|ab .{0,30}karenge)")
        private val interrogative = Regex("(?i)^(what|who|when|where|why|how|which|are|does|did|can|could|should|kya|kaun|kab|kahan|kyun|kyu|kaise|kaunsa|konsa|kitna|kitne|kitni|batao|bata)\\b")

        fun queryKind(text: String): TopicQuery? = when {
            recap.containsMatchIn(text) -> TopicQuery.RECAP
            resume.containsMatchIn(text) -> TopicQuery.RESUME
            else -> null
        }
        fun isQuestion(t: String): Boolean = t.trim().endsWith("?") || interrogative.containsMatchIn(t.trim())
    }

    fun activeId(): Long = store.getState("topic.active")?.toLongOrNull() ?: 0L
    fun active(): TopicRec? = store.topic(activeId())?.takeIf { it.status != "DONE" }
    fun history(): List<TopicRec> = store.topics().sortedByDescending { it.updatedAt }

    private fun setActive(id: Long) = store.putState("topic.active", id.toString())

    private fun logTransition(now: Long, from: Long, to: Long, why: String) {
        val old = store.getState("topic.log").orEmpty().lines().filter { it.isNotBlank() }.takeLast(49)
        store.putState("topic.log", (old + "$now|$from|$to|$why").joinToString("\n"))
    }

    fun transitions(): List<String> = store.getState("topic.log").orEmpty().lines().filter { it.isNotBlank() }

    private fun clean(s: String): String = s.trim().replace(Regex("(?i)^(hey |hi )?nova[ ,:!.-]*"), "").trim()

    private fun titleFrom(seed: String): String {
        val words = seed.replace(Regex("[,.!?]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() && it.lowercase() !in Txt.STOP }
        return words.take(6).joinToString(" ").ifBlank { Txt.clip(seed, 40) }
    }

    private fun addKeywords(old: String, toks: Collection<String>): String {
        val list = old.split(' ').filter { it.isNotEmpty() }.toMutableList()
        for (t in toks) { list.remove(t); list.add(t) }
        return list.takeLast(60).joinToString(" ")
    }

    private fun create(seed: String, now: Long, from: TopicRec?, reason: String): TopicRec {
        return store.tx {
            from?.let { store.saveTopic(it.copy(status = "PAUSED")) }
            val summaryLine = if (isQuestion(seed)) "" else Txt.clip(clean(seed), 140)
            val t = TopicRec(title = titleFrom(seed), keywords = addKeywords("", Txt.tokens(seed)), summary = summaryLine,
                lastStep = if (summaryLine.isNotEmpty()) Txt.clip(summaryLine, 100) else "", unanswered = if (isQuestion(seed)) "U:" + Txt.clip(clean(seed), 120) else "",
                createdAt = now, updatedAt = now)
            val id = store.saveTopic(t)
            setActive(id); logTransition(now, from?.id ?: 0, id, reason)
            t.copy(id = id)
        }
    }

    private fun hasReference(text: String): Boolean {
        if (hindiRef.containsMatchIn(text)) return true
        return text.trim().split(Regex("\\s+")).size <= 7 && engRef.containsMatchIn(text)
    }

    private fun topicTokens(t: TopicRec): Set<String> = Txt.expand(Txt.tokens(t.title) + t.keywords.split(' ').filter { it.isNotEmpty() })

    private fun overlap(toks: List<String>, t: TopicRec): Int {
        val set = topicTokens(t)
        return toks.count { tok -> tok in set || Txt.expand(listOf(tok)).any { it in set } }
    }

    private fun learn(cur: TopicRec, text: String, toks: List<String>, now: Long): TopicRec {
        val q = isQuestion(text)
        val summary = cur.summary.lines().filter { it.isNotBlank() }.toMutableList()
        if (!q && toks.size >= 2) {
            val line = Txt.clip(clean(text), 140)
            if (summary.lastOrNull() != line) summary.add(line)
        }
        var un = cur.unanswered.lines().filter { it.isNotBlank() }.toMutableList()
        if (!q) { val i = un.indexOfLast { it.startsWith("A:") }; if (i >= 0) un.removeAt(i) }
        else un.add("U:" + Txt.clip(clean(text), 120))
        val last = if (!q && toks.size >= 2) Txt.clip(clean(text), 100) else cur.lastStep
        val next = if (!q && nextRe.containsMatchIn(text)) Txt.clip(clean(text), 100) else if (!q && doneRe.containsMatchIn(text) && cur.nextStep.isNotBlank() && toks.isNotEmpty()) "" else cur.nextStep
        val updated = cur.copy(keywords = addKeywords(cur.keywords, toks), summary = summary.takeLast(12).joinToString("\n"),
            unanswered = un.takeLast(4).joinToString("\n"), lastStep = last, nextStep = next, updatedAt = now)
        store.saveTopic(updated)
        return updated
    }

    fun onUserTurn(text: String, now: Long): TopicDecision {
        val t = text.trim()
        if (t.isEmpty()) return TopicDecision.None
        val toks = Txt.tokens(t)
        val cur = active()

        val m = newTopic.find(t)
        if (m != null) {
            val seed = t.removeRange(m.range).trim().ifBlank { t }
            return TopicDecision.Switched(create(seed, now, cur, "explicit"), cur, "explicit")
        }
        if (cur == null) {
            if (toks.size >= 2 && queryKind(t) == null) return TopicDecision.Started(create(t, now, null, "first"))
            return TopicDecision.None
        }
        if (queryKind(t) != null) return TopicDecision.Continued(cur)       // asking about the conversation never changes it
        if (toks.size < 3 || hasReference(t)) return TopicDecision.Continued(learn(cur, t, toks, now))
        if (overlap(toks, cur) > 0) return TopicDecision.Continued(learn(cur, t, toks, now))

        // nothing in common with the current topic: maybe the user is returning to an older one
        val older = store.topics().filter { it.id != cur.id && it.status != "DONE" }
            .map { it to overlap(toks, it) }.filter { it.second >= 2 && it.second * 2 >= toks.size }.maxByOrNull { it.second }?.first
        if (older != null) {
            store.saveTopic(cur.copy(status = "PAUSED"))
            val back = older.copy(status = "ACTIVE")
            store.saveTopic(back); setActive(back.id); logTransition(now, cur.id, back.id, "returned")
            return TopicDecision.Resumed(learn(back, t, toks, now), cur)
        }
        if (isQuestion(t) && toks.size >= 4) return TopicDecision.Switched(create(t, now, cur, "unrelated question"), cur, "unrelated question")
        if (toks.size >= 5) return TopicDecision.Uncertain(cur)
        return TopicDecision.Continued(learn(cur, t, toks, now))
    }

    fun onAssistantTurn(text: String, now: Long) {
        val cur = active() ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        var un = cur.unanswered.lines().filter { it.isNotBlank() && !it.startsWith("U:") }.toMutableList()
        val lastSentence = t.split(Regex("(?<=[.!?।])\\s+")).lastOrNull { it.isNotBlank() }.orEmpty()
        if (lastSentence.endsWith("?")) un.add("A:" + Txt.clip(lastSentence.trim(), 120))
        store.saveTopic(cur.copy(keywords = addKeywords(cur.keywords, Txt.tokens(t).take(12)), unanswered = un.takeLast(4).joinToString("\n"), updatedAt = now))
    }

    /** Explicit "go back to that topic". Keeps the old one paused and restores the chosen one. */
    fun resume(id: Long, now: Long): TopicRec? {
        val target = store.topic(id) ?: return null
        val cur = active()
        if (cur != null && cur.id != id) store.saveTopic(cur.copy(status = "PAUSED"))
        val back = target.copy(status = "ACTIVE", updatedAt = now)
        store.saveTopic(back); setActive(id); logTransition(now, cur?.id ?: 0, id, "resumed by user")
        return back
    }

    fun markDone(id: Long, now: Long) {
        store.topic(id)?.let { store.saveTopic(it.copy(status = "DONE", updatedAt = now)) }
        if (activeId() == id) setActive(0)
    }

    fun setNextStep(next: String, now: Long) { active()?.let { store.saveTopic(it.copy(nextStep = next, updatedAt = now)) } }
    fun addInstruction(text: String, now: Long) {
        val cur = active() ?: return
        val l = cur.instructions.lines().filter { it.isNotBlank() }
        if (l.any { Txt.similar(it, text) }) return
        store.saveTopic(cur.copy(instructions = (l + Txt.clip(text, 140)).takeLast(8).joinToString("\n"), updatedAt = now))
    }
    fun attachProject(project: String, now: Long) { active()?.let { if (it.project != project) store.saveTopic(it.copy(project = project, updatedAt = now)) } }

    /** Topics matching words, ranked; [range] limits to topics touched in that period (for "kal wali baat"). */
    fun find(query: String, range: Pair<Long, Long>? = null): List<TopicRec> {
        val q = Txt.expand(Txt.tokens(query))
        return store.topics().filter { range == null || (it.updatedAt >= range.first && it.updatedAt < range.second) }
            .map { t -> t to (if (q.isEmpty()) 0 else topicTokens(t).count { it in q }) }
            .filter { q.isEmpty() || it.second > 0 }.sortedWith(compareByDescending<Pair<TopicRec, Int>> { it.second }.thenByDescending { it.first.updatedAt }).map { it.first }
    }

    /** Plain-language recap of one topic, built only from what was really said. */
    fun recap(t: TopicRec, english: Boolean): String {
        val points = t.summary.lines().filter { it.isNotBlank() }.takeLast(4)
        val pendingQ = t.unanswered.lines().firstOrNull { it.startsWith("A:") }?.removePrefix("A:")
        val userQ = t.unanswered.lines().firstOrNull { it.startsWith("U:") }?.removePrefix("U:")
        val sb = StringBuilder()
        if (english) {
            sb.append("We were talking about: ").append(t.title).append(".")
            if (points.isNotEmpty()) sb.append(" So far you said: ").append(points.joinToString("; ")).append(".")
            if (t.lastStep.isNotBlank()) sb.append(" Last step: ").append(t.lastStep).append(".")
            if (pendingQ != null) sb.append(" I asked: ").append(pendingQ)
            else if (t.nextStep.isNotBlank()) sb.append(" Next step: ").append(t.nextStep).append(".")
            if (userQ != null) sb.append(" Your question is still unanswered: ").append(userQ)
        } else {
            sb.append("Hum ").append(t.title).append(" ke baare mein baat kar rahe the.")
            if (points.isNotEmpty()) sb.append(" Ab tak tumne bataya: ").append(points.joinToString("; ")).append(".")
            if (t.lastStep.isNotBlank()) sb.append(" Aakhri step: ").append(t.lastStep).append(".")
            if (pendingQ != null) sb.append(" Maine tumse poocha tha: ").append(pendingQ)
            else if (t.nextStep.isNotBlank()) sb.append(" Agla step: ").append(t.nextStep).append(".")
            if (userQ != null) sb.append(" Tumhara ye sawal abhi bhi pending hai: ").append(userQ)
        }
        return sb.toString().trim()
    }
}
