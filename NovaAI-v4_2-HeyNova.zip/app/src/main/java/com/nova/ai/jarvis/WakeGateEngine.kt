package com.nova.ai.jarvis

import android.content.Context
import android.os.SystemClock
import com.nova.ai.suite.VoiceLevel
import com.nova.ai.voice.NovaSession
import com.nova.ai.voice.PcmFormat
import com.nova.ai.voice.SpeechProcessingEngine
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Offline wake word. A small on-device recognizer is limited to just the wake phrases (plus "unknown"), so it can be any phrase
 * the offline model knows, with no training. Until it hears a phrase, nothing is sent to Gemini or any other cloud service.
 *
 * Two modes:
 *  - [lazyInner] = false (older "offline wake word"): the real engine runs from the start and is fed the last 1.5 s plus the next
 *    12 s of audio after the name.
 *  - [lazyInner] = true (Hey Nova): the real engine (Gemini Live or speech-to-text) is not even started until the wake phrase is heard.
 *    Audio is forwarded while the conversation is open; the window stays open while Nova is thinking or speaking or you are talking,
 *    so follow-up sentences need no wake phrase. When it closes, the engine is stopped again and the recognizer waits for the phrase.
 *
 * There is exactly one microphone (AudioCapture in the foreground service); this class only consumes its audio.
 * Not a neural keyword spotter like Porcupine: unusual or very short names can be missed or falsely heard. Test your name.
 */
class WakeGateEngine(
    private val ctx: Context,
    private val jp: JarvisPrefs,
    private val inner: SpeechProcessingEngine,
    private val onProblem: (String) -> Unit,
    private val lazyInner: Boolean = false
) : SpeechProcessingEngine {
    private val lock = Any()
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var scope: CoroutineScope? = null
    private var format = PcmFormat(16000, 1)
    private var ring = ByteArray(0)
    private var ringPos = 0
    private var ringFilled = false
    private var phrases: List<String> = emptyList()          // old name-only gate
    /** Hey Nova: one recognizer per offline model that the enabled phrases need (English and/or Hindi). */
    private class Rec(val plan: WakePhrases.ModelPlan, val model: Model, val rec: Recognizer) { var lastPartial: String? = null }
    private val recs = ArrayList<Rec>()
    private var catalog: Map<String, WakePhrases.Phrase> = emptyMap()
    @Volatile private var holdInnerUntil = 0L
    private val window = ConversationWindow(
        initialMs = if (jp.batterySaver) 8_000L else 10_000L,
        followUpMs = if (jp.batterySaver) 6_000L else 8_000L
    )
    @Volatile private var openUntil = 0L            // legacy (non lazy) window
    @Volatile private var ready = false
    @Volatile private var innerRunning = false
    @Volatile private var cooldownUntil = 0L
    private var lastVoiceAt = 0L
    private var seenActivity = 0L

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        this.format = format
        this.scope = scope
        phrases = listOf(WakePhrases.cleanName(jp.wakeName))
        catalog = jp.enabledPhrases().associateBy { it.id }
        synchronized(lock) { ring = if (lazyInner) ByteArray(0) else ByteArray((format.sampleRate * 2 * 3) / 2); ringPos = 0; ringFilled = false }
        seenActivity = NovaSession.activityAt
        if (!lazyInner) { inner.start(format, scope); innerRunning = true }
        if (lazyInner) {
            VoiceState.wakeGated = true          // closed from the first instant: without a working phrase nothing is heard or sent
            scope.launch(Dispatchers.IO) {
                try {
                    val plan = WakeVocab.planFor(ctx, jp)
                    if (plan.isEmpty) {
                        onProblem("Hey Nova has no phrase it can recognize yet. Open Settings → Nova Floating Voice Assistant and download the offline model. Until then Nova hears nothing.")
                        return@launch
                    }
                    val built = ArrayList<Rec>()
                    for (mp in plan.models) {
                        val m = Model(VoskModelManager.dir(ctx, mp.model).absolutePath)
                        val r = Recognizer(m, format.sampleRate.toFloat(), mp.grammar)
                        r.setWords(true)
                        built.add(Rec(mp, m, r))
                    }
                    synchronized(lock) { recs.addAll(built) }
                    ready = true
                } catch (e: Throwable) {
                    onProblem("Wake word engine failed to start: ${e.message}")
                }
            }
            return
        }
        val id = jp.offlineLang
        if (!VoskModelManager.isInstalled(ctx, id)) {
            onProblem("Wake word needs the offline model. Download it in Jarvis settings. Until then everything is sent to Gemini.")
            return
        }
        VoiceState.wakeGated = true
        scope.launch(Dispatchers.IO) {
            try {
                val m = Model(VoskModelManager.dir(ctx, id).absolutePath)
                val r = Recognizer(m, format.sampleRate.toFloat(), WakePhrases.grammarJson(phrases))
                synchronized(lock) { model = m; rec = r }
                ready = true
            } catch (e: Throwable) {
                VoiceState.wakeGated = false
                onProblem("Wake word engine failed to start: ${e.message}")
            }
        }
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        if (lazyInner) { processLazy(audioData, length); return }
        if (!VoiceState.wakeGated || !ready) { inner.processAudio(audioData, length); return }   // no offline model: do not block the assistant
        val now = SystemClock.elapsedRealtime()
        var woke = false
        synchronized(lock) {
            // keep the last 1.5 s so the first words after the name are not lost
            var off = 0
            while (off < length) {
                val n = minOf(length - off, ring.size - ringPos)
                System.arraycopy(audioData, off, ring, ringPos, n)
                ringPos = (ringPos + n) % ring.size; off += n
                if (ringPos == 0) ringFilled = true
            }
            val r = rec
            if (r != null && !VoiceState.speaking.value) {
                val heard = if (r.acceptWaveForm(audioData, length)) text(r.result, "text") else text(r.partialResult, "partial")
                if (WakePhrases.match(heard, phrases) != null) { woke = true; r.reset() }
            }
        }
        if (woke) {
            val wasOpen = now < openUntil
            openUntil = now + 12_000
            NovaSession.onWake("legacy", phrases.firstOrNull() ?: "")
            if (!wasOpen) {
                // replay the buffered audio into the real engine, oldest first
                val snapshot = synchronized(lock) {
                    if (ringFilled) ring.copyOfRange(ringPos, ring.size) + ring.copyOfRange(0, ringPos) else ring.copyOfRange(0, ringPos)
                }
                var off = 0
                while (off < snapshot.size) { val n = minOf(snapshot.size - off, 3200); inner.processAudio(snapshot.copyOfRange(off, off + n), n); off += n }
                return
            }
        }
        if (now < openUntil) inner.processAudio(audioData, length)
    }

    // ───────── Hey Nova mode ─────────

    private suspend fun processLazy(audioData: ByteArray, length: Int) {
        val now = SystemClock.elapsedRealtime()
        if (window.isOpen(now)) {
            if (!NovaSession.awake.value) { endConversation(now); return }                 // dismissed from the orb
            val level = VoiceLevel.level.value
            val act = NovaSession.activityAt
            val activity = act != seenActivity
            seenActivity = act
            window.touch(now, NovaSession.isBusy() || level > LOUD || activity)
            if (!innerRunning) {
                // A phrase that is itself a question ("Jaan, kaisi ho?") is answered first; the live session starts afterwards,
                // so Nova's answer is not picked up by her own listening session.
                if (NovaSession.isBusy()) holdInnerUntil = maxOf(holdInnerUntil, now + 700L)
                if (now < holdInnerUntil) return
                startInner(now)
                if (!innerRunning) return
            }
            inner.processAudio(audioData, length)
            return
        }
        if (innerRunning) { endConversation(now); return }                                // window ran out
        if (!ready || now < cooldownUntil || VoiceState.speaking.value) return          // nothing leaves the phone, nothing is heard
        // Battery saver: do not run the recognizer over silence (keeps it fed for 1.2 s after the last voiced chunk so phrases finish).
        if (jp.batterySaver) {
            val level = VoiceLevel.level.value
            if (level > QUIET) lastVoiceAt = now
            else if (now - lastVoiceAt > 1_200L) return
        }
        var hitId: String? = null
        synchronized(lock) {
            for (r in recs) {
                val final = r.rec.acceptWaveForm(audioData, length)
                if (final) {
                    val json = r.rec.result
                    val id = r.plan.identify(text(json, "text"))
                    r.lastPartial = null
                    // a whole phrase, spoken as its own utterance, with reasonable word confidence
                    if (id != null && WakePhrases.confident(json, MIN_CONF)) hitId = id
                } else {
                    val id = r.plan.identify(text(r.rec.partialResult, "partial"))
                    // the same phrase must be seen in two consecutive updates: a one-off misrecognition does not wake Nova
                    if (id != null && id == r.lastPartial) hitId = id else r.lastPartial = id
                }
                if (hitId != null) break
            }
            if (hitId != null) for (r in recs) { r.lastPartial = null; try { r.rec.reset() } catch (e: Throwable) { } }
        }
        val id = hitId ?: return
        val phrase = catalog[id]
        window.open(now)
        holdInnerUntil = if (phrase?.reply != null) now + 1_500L else 0L
        NovaSession.onWake(id, phrase?.label ?: id, phrase?.hindi == true)
    }

    private fun startInner(now: Long) {
        val s = scope ?: return
        try { inner.start(format, s); innerRunning = true }
        catch (e: Exception) { onProblem("Could not start the voice conversation: ${e.message}"); window.close(); NovaSession.end() }
    }

    private fun endConversation(now: Long) {
        window.close()
        cooldownUntil = now + 1_500L
        NovaSession.awake.value = false
        if (innerRunning) { try { inner.stop() } catch (e: Exception) { }; innerRunning = false }
        synchronized(lock) { try { rec?.reset() } catch (e: Throwable) { }; recs.forEach { try { it.rec.reset() } catch (e: Throwable) { } } }
    }

    private fun text(json: String, key: String) = try { JSONObject(json).optString(key) } catch (e: Exception) { "" }

    override fun stop() {
        ready = false
        innerRunning = false
        window.close()
        openUntil = 0L
        VoiceState.wakeGated = false
        NovaSession.awake.value = false
        inner.stop()
        synchronized(lock) {
            try { rec?.close() } catch (e: Throwable) { }
            try { model?.close() } catch (e: Throwable) { }
            rec = null; model = null
            recs.forEach { try { it.rec.close() } catch (e: Throwable) { }; try { it.model.close() } catch (e: Throwable) { } }
            recs.clear()
        }
    }

    private companion object {
        /** Mic level (0..1, see VoiceLevel) above which the user counts as talking. */
        const val LOUD = 0.06f
        /** Below this the battery saver treats the room as silent. */
        const val QUIET = 0.015f
        /** Minimum average word confidence of a final result for it to wake Nova. */
        const val MIN_CONF = 0.55f
    }
}
