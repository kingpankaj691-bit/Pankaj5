package com.nova.ai.ai

import com.nova.ai.ai.net.GeminiError
import com.nova.ai.ai.net.GeminiErrorKind
import com.nova.ai.ai.net.GeminiRestClient
import com.nova.ai.ai.net.RetryPolicy
import com.nova.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Shared low-level Gemini REST call used by web search, vision, speech clips and Gemini voice. Chat has its own provider. */
object GeminiHttp {
    /** [kind] says why a call failed (null on success) so callers can back off for rate limits and stop on permanent errors. */
    class Out(val json: JSONObject?, val error: String?, val kind: GeminiErrorKind? = null)

    suspend fun post(prefs: Prefs, body: JSONObject, model: String? = null, readTimeoutMs: Int = 60000): Out = withContext(Dispatchers.IO) {
        if (prefs.localOnly) return@withContext Out(null, "Local-only mode is on, so nothing is sent to the internet.")
        if (!prefs.aiEnabled) return@withContext Out(null, "AI is disabled in Settings.")
        val key = prefs.apiKey
        if (key.isBlank()) { val e = GeminiError(GeminiErrorKind.NO_KEY); return@withContext Out(null, e.userMessage(), e.kind) }
        val id = ModelCatalog.clean(model, prefs.model)
        val timeouts = GeminiRestClient.Timeouts(responseMs = readTimeoutMs.toLong())
        when (val r = GeminiRestClient.shared.generate(key, id, body, timeouts, RetryPolicy.voice())) {
            is GeminiRestClient.Result.Ok -> Out(r.json, null)
            is GeminiRestClient.Result.Fail -> Out(null, r.error.userMessage(id), r.error.kind)
        }
    }

    fun textOf(j: JSONObject): String {
        val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (p.optBoolean("thought", false)) continue            // a thinking model's reasoning is not part of the answer
            sb.append(p.optString("text"))
        }
        return sb.toString().trim()
    }
}
