package com.nova.ai.jarvis

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nova.ai.security.Prefs
import com.nova.ai.voice.HeadlessAssistant
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Tasker (and any automation app) integration.
 *
 * Tasker -> Nova : Send Intent, Action  com.nova.ai.action.COMMAND, Target Broadcast Receiver, Extras:  command:open youtube   token:<your token>
 *                  (optional extra reply_package:net.dinglisch.android.tasker to get the answer back)
 * Nova -> Tasker : Profile > Event > Intent Received, Action  com.nova.ai.action.RESULT  (extras: command, result)
 *                  and  com.nova.ai.action.EVENT  (extras: event, text)  for heard commands, calls, SOS.
 * Nova runs a Tasker task by voice: "tasker chalao <task name>" (turn on "Allow External Access" in Tasker).
 */
object TaskerBridge {
    const val ACTION_COMMAND = "com.nova.ai.action.COMMAND"
    const val ACTION_RESULT = "com.nova.ai.action.RESULT"
    const val ACTION_EVENT = "com.nova.ai.action.EVENT"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var assistant: HeadlessAssistant? = null

    fun newToken(): String = UUID.randomUUID().toString().replace("-", "").take(20)

    /** Tells automation apps that something happened. Only when "Send events to Tasker" is on. */
    fun event(ctx: Context, name: String, text: String) {
        if (!JarvisPrefs(ctx).taskerEvents) return
        try { ctx.applicationContext.sendBroadcast(Intent(ACTION_EVENT).putExtra("event", name).putExtra("text", text)) } catch (e: Exception) { }
    }

    /** Starts a Tasker task by name through Tasker's documented intent. */
    fun runTask(ctx: Context, task: String): String {
        for (pkg in listOf("net.dinglisch.android.tasker", "net.dinglisch.android.taskerm")) {
            try { ctx.applicationContext.sendBroadcast(Intent("net.dinglisch.android.tasker.ACTION_TASK").setPackage(pkg).putExtra("task_name", task)) } catch (e: Exception) { }
        }
        return "Tasker ko '$task' chalane ko bol diya. (Tasker mein Allow External Access on hona chahiye.)"
    }

    /** Runs a command exactly like a spoken one, silently, and returns Nova's answer. */
    fun handle(app: Application, prefs: Prefs, command: String, replyPackage: String?, pending: BroadcastReceiver.PendingResult) {
        scope.launch {
            try {
                val a = assistant ?: HeadlessAssistant(app, prefs).also { assistant = it }
                val answer = a.handleSilently(command)
                val i = Intent(ACTION_RESULT).putExtra("command", command).putExtra("result", answer)
                if (!replyPackage.isNullOrBlank()) i.setPackage(replyPackage)
                app.sendBroadcast(i)
            } catch (e: Exception) { } finally { pending.finish() }
        }
    }
}

/** Entry point for Tasker. Off by default; needs the token from Jarvis settings, so other apps can't control the phone. */
class TaskerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TaskerBridge.ACTION_COMMAND) return
        val jp = JarvisPrefs(ctx)
        val cmd = intent.getStringExtra("command")?.trim().orEmpty()
        if (!jp.taskerIn || jp.taskerToken.isBlank() || intent.getStringExtra("token") != jp.taskerToken || cmd.isEmpty()) return
        val app = ctx.applicationContext as Application
        TaskerBridge.handle(app, Prefs(app), cmd, intent.getStringExtra("reply_package"), goAsync())
    }
}
