package com.nova.ai.control

import com.nova.ai.NovaApp
import com.nova.ai.commands.Cat
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Lets the engine talk back to the chat (and TTS) when an operation finishes after the command was accepted. Set by the ViewModel. */
object ControlBus {
    @Volatile var reply: ((String) -> Unit)? = null
    @Volatile var confirm: (suspend (String) -> Boolean)? = null
}

/**
 * Router hook for the unified control engine. It only claims a command when it adds something over the existing handlers:
 * brightness, screen timeout, rotation, force-stop, status questions always; Wi-Fi / Bluetooth toggles only when Shizuku is ready
 * (otherwise the existing handlers keep working exactly as before).
 */
class ControlCommands {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val hindi = Regex("\\b(kar|karo|do|dena|kam|zyada|badha|ghata|chalu|band|kholo|batao|kitni|kitna|hai|mera|meri|mere|ka|ki|ko|se|par)\\b")

    fun route(raw: String, t: String): CmdResult? {
        val op = OpParser.parse(raw) ?: return null
        val sz = ShizukuManager.refresh().status == ShizukuStatus.READY
        if ((op is ControlOp.Wifi || op is ControlOp.Bluetooth) && !sz) return null
        if (op is ControlOp.ForceStop && op.loose) {
            // Loose phrasing ("close X"): only claim it when X is exactly an installed app, so other "close/band kar do" commands keep working.
            val exact = try { com.nova.ai.device.DeviceController(NovaApp.instance).listApps().any { it.first.equals(op.query, ignoreCase = true) } } catch (e: Exception) { false }
            if (!exact) return null
        }
        val h = hindi.containsMatchIn(t)
        val prompt = when (op) { is ControlOp.ForceStop -> "Force-stop \"${op.query}\"?"; else -> ControlEngine.describe(op) + "?" }
        // Force-stop asks for its own, more specific confirmation inside the engine, so the router does not ask a second time.
        val level = when { op is ControlOp.Battery || op is ControlOp.Storage || op is ControlOp.DeviceInfo || op is ControlOp.ShizukuStatusOp || op is ControlOp.ControlStatus || op is ControlOp.Uninstall || op is ControlOp.InstallApk -> Level.Info; else -> Level.Action }
        return CmdResult(true, Cat.LOCAL_DEVICE_COMMAND, prompt, level, {
            scope.launch {
                val r = ControlEngine.run(op, h) { q -> ControlBus.confirm?.invoke(q) ?: false }
                ControlBus.reply?.invoke(r.message)
            }
            ""
        }, "basic")
    }
}
