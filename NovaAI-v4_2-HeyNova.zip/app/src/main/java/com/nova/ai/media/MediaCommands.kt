package com.nova.ai.media

import com.nova.ai.commands.Cat
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level
import com.nova.ai.commands.UiBridge
import com.nova.ai.ui.SettingsNav

/**
 * Voice/chat entry to the Gallery. It never reads or sends anything by itself: it opens Nova's Gallery, where the user chooses photos.
 * "open gallery" (the phone's own Gallery app) is left to the existing handler.
 */
class MediaCommands {
    private fun open(page: String, say: String) = CmdResult(true, Cat.APP_COMMAND, "", Level.Info, {
        if (UiBridge.navigate == null) "Open Nova's Settings → Photos & Videos." else { SettingsNav.request = page; UiBridge.navigate?.invoke(4); say }
    }, "basic")

    fun route(raw: String, t: String): CmdResult? {
        fun has(vararg w: String) = w.any { t.contains(it) }
        if (has("analyze photo", "analyse photo", "analyze my photo", "photo analyze", "photos analyze", "photo ko analyze", "photo dekh ke batao", "is photo me kya hai", "ye photo kya hai"))
            return open("gallery", "Gallery khol di. Jo photo analyze karni hai use chuno aur Analyze dabao. Main tumhari haan ke bina kuch bhi Gemini ko nahi bhejti.")
        if (has("nova gallery", "browse my photos", "browse photos", "photos dikhao", "photo dikhao", "videos dikhao", "meri photos dikhao", "show my photos", "show my videos"))
            return open("gallery", "Nova ki Gallery khol di. Jitni photos Android ne mujhe dikhane di hain, wahi dikhengi.")
        if (has("photo picker", "pick a photo", "photo chuno", "photo select kar"))
            return open("photos", "Photos & Videos page khol diya. Wahan Photo Picker se photo chun sakte ho, kisi permission ke bina.")
        if (has("photo access", "photos permission", "media permission", "storage access", "files access", "all files access", "storage permission"))
            return open("photos", "Photos & Videos page khol diya. Wahan dikhega ki main abhi kya dekh sakti hoon.")
        return null
    }
}
