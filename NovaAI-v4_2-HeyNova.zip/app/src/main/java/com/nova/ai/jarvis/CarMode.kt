package com.nova.ai.jarvis

import android.content.Context
import com.nova.ai.automation.Notifier

/** Car mode: very short spoken answers, incoming messages read aloud, call announcements on. Turns on by itself when your car's Bluetooth connects. */
object CarMode {
    const val PROMPT = "The user is driving. Answer in one very short sentence. Never ask them to look at the screen."

    fun enable(ctx: Context, fromBluetooth: Boolean = false) {
        val jp = JarvisPrefs(ctx)
        if (jp.carMode) return
        jp.carMode = true
        jp.callAnnounce = true
        if (fromBluetooth) Notifier.post(ctx, 4200, "Car mode on", "Your car's Bluetooth connected. Turn on Background Voice in Nova to talk hands-free.")
    }

    fun disable(ctx: Context) { JarvisPrefs(ctx).carMode = false }
}
