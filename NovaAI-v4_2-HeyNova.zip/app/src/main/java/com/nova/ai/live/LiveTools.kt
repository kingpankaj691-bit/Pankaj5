package com.nova.ai.live

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tools the Live model may call. All parameters are strings. Messages only open the composer: the user taps Send.
 * Nothing here sends an SMS silently.
 */
object LiveTools {
    val TOOL_INSTRUCTION: String get() = BASE_INSTRUCTION + FlavorTools.instruction
    private const val BASE_INSTRUCTION =
        "You can act on the phone with tools: open_app(app_name), call_contact(name_or_number), message_contact(name_or_number, text, app), build_website(prompt). " +
            "Call a tool as soon as the user asks, then tell them briefly what happened. Messages are only prepared; the user taps Send. When asked for a website, call build_website."

    fun decl(name: String, description: String, params: List<Pair<String, String>>, required: List<String>): JSONObject {
        val props = JSONObject()
        params.forEach { (p, d) -> props.put(p, JSONObject().put("type", "STRING").put("description", d)) }
        return JSONObject().put("name", name).put("description", description)
            .put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", JSONArray(required)))
    }

    fun declarations(): JSONArray = common().also { arr ->
        val f = FlavorTools.declarations(); for (i in 0 until f.length()) arr.put(f.get(i))
        val b = com.nova.ai.brain.Brain.declarations(); for (i in 0 until b.length()) arr.put(b.get(i))
    }

    private fun common(): JSONArray = JSONArray()
        .put(decl("open_app", "Open an installed app by its name.", listOf("app_name" to "App name, e.g. YouTube"), listOf("app_name")))
        .put(decl("call_contact", "Call a contact by name or a phone number.", listOf("name_or_number" to "Contact name or number"), listOf("name_or_number")))
        .put(decl("message_contact", "Open SMS or WhatsApp with the message already written. It is NEVER sent by this tool: tell the user the message is ready and that they must press Send themselves.",
            listOf("name_or_number" to "Contact name or number", "text" to "Message text", "app" to "sms or whatsapp"), listOf("name_or_number", "text")))
        .put(decl("build_website", "Build a website for the user from a description.", listOf("prompt" to "What the website is for"), listOf("prompt")))

    /** Lower-case label -> package for launchable apps. Rebuilt every 15 minutes. */
    private object Labels {
        @Volatile var map: Map<String, String> = emptyMap()
        @Volatile var at = 0L
        fun get(ctx: Context): Map<String, String> {
            val now = System.currentTimeMillis()
            if (map.isNotEmpty() && now - at < 15 * 60_000L) return map
            synchronized(this) {
                val pm = ctx.packageManager
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val m = HashMap<String, String>()
                for (r in pm.queryIntentActivities(i, 0)) m[r.loadLabel(pm).toString().lowercase()] = r.activityInfo.packageName
                map = m; at = now
                return m
            }
        }
    }

    /** Exact label first; else prefix matching with key length >= 3. Never loose substring matching. */
    fun findApp(labels: Map<String, String>, query: String): String? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        labels[q]?.let { return it }
        val qw = q.split(Regex("\\s+"))
        val best = labels.entries.filter { (k, _) ->
            k.length >= 3 && (k.startsWith(q) || q.startsWith(k) || qw.all { w -> k.split(Regex("\\s+")).any { it.startsWith(w) } })
        }.minByOrNull { Math.abs(it.key.length - q.length) }
        return best?.value
    }

    fun looksLikeNumber(q: String): Boolean = q.all { it.isDigit() || it in " +-()." } && q.count { it.isDigit() } >= 5

    fun rankContacts(query: String, rows: List<Pair<String, String>>): Pair<String, String>? {
        val q = query.trim().lowercase()
        fun score(n: String): Int { val l = n.lowercase(); return when { l == q -> 0; l.startsWith(q) -> 1; l.contains(q) -> 2; else -> 3 } }
        return rows.filter { score(it.first) < 3 }.minByOrNull { score(it.first) }
    }

    private fun resolveNumber(ctx: Context, q: String): Pair<String?, String> {
        if (looksLikeNumber(q)) return q.filter { it.isDigit() || it == '+' } to ""
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null to "no_contacts_permission"
        val rows = ArrayList<Pair<String, String>>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$q%"), null
            )?.use { c -> while (c.moveToNext() && rows.size < 5) rows.add(c.getString(0) to c.getString(1)) }
        } catch (e: Exception) { return null to "contact_lookup_failed" }
        val hit = rankContacts(q, rows) ?: return null to "contact_not_found"
        return hit.second to ""
    }

    private fun launch(ctx: Context, i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }

    /** (display name, number) rows whose name contains [q]; empty without READ_CONTACTS. */
    fun contactRows(ctx: Context, q: String): List<Pair<String, String>> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val rows = ArrayList<Pair<String, String>>()
        try {
            ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$q%"), null
            )?.use { c -> while (c.moveToNext() && rows.size < 5) rows.add(c.getString(0) to c.getString(1)) }
        } catch (e: Exception) { }
        return rows
    }

    fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        FlavorTools.gate(app)?.let { return JSONObject().put("result", it) }      // access key blocked (direct build only)
        return when (name) {
            "open_app" -> {
                val pkg = findApp(Labels.get(app), args.optString("app_name")) ?: return JSONObject().put("result", "app_not_found")
                val i = app.packageManager.getLaunchIntentForPackage(pkg)
                JSONObject().put("result", if (i != null && launch(app, i)) "opened" else "failed")
            }
            "call_contact" -> {
                val (num, err) = resolveNumber(app, args.optString("name_or_number"))
                if (num == null) return JSONObject().put("result", err)
                val granted = ContextCompat.checkSelfPermission(app, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
                JSONObject().put("result", if (!launch(app, i)) "failed" else if (granted) "calling" else "dialer_opened_no_permission")
            }
            "message_contact" -> {
                val (num, err) = resolveNumber(app, args.optString("name_or_number"))
                if (num == null) return JSONObject().put("result", err)
                val text = args.optString("text")
                val wa = args.optString("app").lowercase().contains("whats")
                val i = if (wa) {
                    val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { p -> try { app.packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false } }
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + num.filter { it.isDigit() } + "?text=" + Uri.encode(text))).also { if (pkg != null) it.setPackage(pkg) }
                } else Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", text)
                JSONObject().put("result", if (launch(app, i)) FlavorTools.prepareComposer(app, wa) else "failed")
            }
            "build_website" -> JSONObject().put("result", when (val r = com.nova.ai.forge.ForgeController.start(app, args.optString("prompt"))) {
                is com.nova.ai.forge.ForgeStart.Started -> "forge_started"
                else -> r.message
            })
            "save_memory", "recall_memory", "get_pending_tasks" -> com.nova.ai.brain.Brain.get(app).executeTool(name, args) ?: JSONObject().put("error", "memory_unavailable")
            else -> FlavorTools.execute(app, name, args) ?: JSONObject().put("error", "Unknown tool: $name")
        }
    }
}
