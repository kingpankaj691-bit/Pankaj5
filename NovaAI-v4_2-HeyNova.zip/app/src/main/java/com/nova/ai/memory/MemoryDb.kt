package com.nova.ai.memory

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.nova.ai.automation.Routine

/** Single local SQLite database (framework SQLite, no extra libraries). Never leaves the device. */
class MemoryDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "nova.db", null, 1) {
    companion object {
        @Volatile private var inst: MemoryDb? = null
        fun get(ctx: Context): MemoryDb = inst ?: synchronized(this) { inst ?: MemoryDb(ctx.applicationContext).also { inst = it } }
        private const val MEM_COLS = "id,category,content,importance,confidence,created,last_used,expires,source,confirmed,pinned,reason"
        private const val RT_COLS = "id,name,trig,trig_value,act,act_value,enabled,rep,fire_at,created,last_fired"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, content TEXT, importance REAL, confidence TEXT, created INTEGER, last_used INTEGER, expires INTEGER, source TEXT, confirmed INTEGER, pinned INTEGER, reason TEXT)")
        db.execSQL("CREATE TABLE ignored(id INTEGER PRIMARY KEY AUTOINCREMENT, reason TEXT, label TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE blocked(hash TEXT PRIMARY KEY)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE routines(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, trig TEXT, trig_value TEXT, act TEXT, act_value TEXT, enabled INTEGER, rep INTEGER, fire_at INTEGER, created INTEGER, last_fired INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ── memories ──
    private fun mem(c: Cursor) = MemoryEntry(
        c.getLong(0), MemCategory.valueOf(c.getString(1)), c.getString(2), c.getFloat(3), Confidence.valueOf(c.getString(4)),
        c.getLong(5), c.getLong(6), c.getLong(7), c.getString(8) ?: "", c.getInt(9) == 1, c.getInt(10) == 1, c.getString(11) ?: ""
    )

    fun insertMemory(e: MemoryEntry): Long {
        val v = ContentValues().apply {
            put("category", e.category.name); put("content", e.content); put("importance", e.importance)
            put("confidence", e.confidence.name); put("created", e.createdAt); put("last_used", e.lastUsedAt)
            put("expires", e.expiresAt); put("source", e.source); put("confirmed", if (e.userConfirmed) 1 else 0)
            put("pinned", if (e.pinned) 1 else 0); put("reason", e.reason)
        }
        return writableDatabase.insert("memories", null, v)
    }

    fun memories(): List<MemoryEntry> {
        val out = mutableListOf<MemoryEntry>()
        readableDatabase.rawQuery("SELECT $MEM_COLS FROM memories ORDER BY pinned DESC, created DESC", null).use { c ->
            while (c.moveToNext()) try { out.add(mem(c)) } catch (e: Exception) { }
        }
        return out
    }

    fun memory(id: Long): MemoryEntry? =
        readableDatabase.rawQuery("SELECT $MEM_COLS FROM memories WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) mem(c) else null }

    fun updateContent(id: Long, text: String) {
        writableDatabase.update("memories", ContentValues().apply { put("content", text); put("confirmed", 1); put("confidence", Confidence.HIGH.name) }, "id=?", arrayOf(id.toString()))
    }
    fun setPinned(id: Long, pinned: Boolean) {
        writableDatabase.update("memories", ContentValues().apply { put("pinned", if (pinned) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }
    fun touch(ids: List<Long>, now: Long) {
        ids.forEach { writableDatabase.update("memories", ContentValues().apply { put("last_used", now) }, "id=?", arrayOf(it.toString())) }
    }
    fun deleteMemory(id: Long) { writableDatabase.delete("memories", "id=?", arrayOf(id.toString())) }
    fun clearMemories() { writableDatabase.delete("memories", null, null); writableDatabase.delete("ignored", null, null); writableDatabase.delete("blocked", null, null) }
    fun countMemories(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM memories", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    /** Forgetting policy. Never deletes pinned or user-confirmed permanent memories. */
    fun purge(now: Long, staleDays: Int): Int {
        var n = writableDatabase.delete("memories",
            "pinned=0 AND expires>0 AND expires<? AND (confirmed=0 OR category IN ('TEMPORARY_CONTEXT','CONVERSATION_CONTEXT'))", arrayOf(now.toString()))
        if (staleDays > 0) n += writableDatabase.delete("memories", "pinned=0 AND confirmed=0 AND last_used<?", arrayOf((now - staleDays * 86400000L).toString()))
        return n
    }

    // ── ignored / blocked ──
    fun addIgnored(reason: String, label: String) {
        writableDatabase.insert("ignored", null, ContentValues().apply { put("reason", reason); put("label", label); put("ts", System.currentTimeMillis()) })
        writableDatabase.execSQL("DELETE FROM ignored WHERE id NOT IN (SELECT id FROM ignored ORDER BY id DESC LIMIT 50)")
    }
    fun ignored(): List<IgnoredInfo> {
        val out = mutableListOf<IgnoredInfo>()
        readableDatabase.rawQuery("SELECT id,reason,label,ts FROM ignored ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(IgnoredInfo(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)))
        }
        return out
    }
    fun block(hash: String) { writableDatabase.insertWithOnConflict("blocked", null, ContentValues().apply { put("hash", hash) }, SQLiteDatabase.CONFLICT_IGNORE) }
    fun isBlocked(hash: String) = readableDatabase.rawQuery("SELECT 1 FROM blocked WHERE hash=?", arrayOf(hash)).use { it.moveToFirst() }

    // ── notes ──
    fun addNote(text: String) { writableDatabase.insert("notes", null, ContentValues().apply { put("body", text); put("ts", System.currentTimeMillis()) }) }
    fun notes(): List<Triple<Long, String, Long>> {
        val out = mutableListOf<Triple<Long, String, Long>>()
        readableDatabase.rawQuery("SELECT id,body,ts FROM notes ORDER BY id DESC", null).use { c -> while (c.moveToNext()) out.add(Triple(c.getLong(0), c.getString(1), c.getLong(2))) }
        return out
    }
    fun deleteNote(id: Long) { writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) }
    fun clearNotes() { writableDatabase.delete("notes", null, null) }

    // ── routines ──
    private fun rt(c: Cursor) = Routine(c.getLong(0), c.getString(1), c.getString(2), c.getString(3) ?: "", c.getString(4), c.getString(5) ?: "",
        c.getInt(6) == 1, c.getInt(7) == 1, c.getLong(8), c.getLong(9), c.getLong(10))
    fun routines(): List<Routine> {
        val out = mutableListOf<Routine>()
        readableDatabase.rawQuery("SELECT $RT_COLS FROM routines ORDER BY id DESC", null).use { c -> while (c.moveToNext()) out.add(rt(c)) }
        return out
    }
    fun routine(id: Long): Routine? = readableDatabase.rawQuery("SELECT $RT_COLS FROM routines WHERE id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) rt(it) else null }
    fun insertRoutine(r: Routine): Long = writableDatabase.insert("routines", null, ContentValues().apply {
        put("name", r.name); put("trig", r.trigger); put("trig_value", r.trigValue); put("act", r.action); put("act_value", r.actValue)
        put("enabled", if (r.enabled) 1 else 0); put("rep", if (r.repeat) 1 else 0); put("fire_at", r.fireAt); put("created", r.createdAt); put("last_fired", r.lastFired)
    })
    fun setRoutineEnabled(id: Long, on: Boolean) { writableDatabase.update("routines", ContentValues().apply { put("enabled", if (on) 1 else 0) }, "id=?", arrayOf(id.toString())) }
    fun markFired(id: Long, now: Long) { writableDatabase.update("routines", ContentValues().apply { put("last_fired", now) }, "id=?", arrayOf(id.toString())) }
    fun deleteRoutine(id: Long) { writableDatabase.delete("routines", "id=?", arrayOf(id.toString())) }
}
