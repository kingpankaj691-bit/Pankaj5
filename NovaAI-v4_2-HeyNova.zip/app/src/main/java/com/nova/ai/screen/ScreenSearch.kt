package com.nova.ai.screen

enum class Kind { ANY, BUTTON, FIELD, SWITCH }

data class Match(val el: UiElement, val score: Int)

/** Finds elements in an accessibility snapshot. No network, no storage. */
object ScreenSearch {
    private val noise = setOf(
        "button", "option", "ka", "ki", "ke", "ko", "ek", "the", "a", "an", "on", "par", "pe", "mein", "me", "screen", "page",
        "dhoondo", "dhundo", "dhoondh", "find", "search", "tap", "click", "press", "dabao", "karo", "kar", "do", "select",
        "wala", "wali", "hai", "jo", "usko", "isko", "ise", "use", "open", "kholo", "icon", "link", "field"
    )
    private val alias = mapOf(
        "settings" to listOf("सेटिंग", "setting"), "setting" to listOf("सेटिंग", "settings"),
        "search" to listOf("खोज", "find", "search"), "back" to listOf("वापस", "navigate up", "back"),
        "share" to listOf("शेयर"), "home" to listOf("होम"), "privacy" to listOf("गोपनीयता"),
        "menu" to listOf("more options", "मेनू"), "more" to listOf("more options", "और"),
        "like" to listOf("लाइक"), "subscribe" to listOf("सब्सक्राइब"), "send" to listOf("भेजें"),
        "cancel" to listOf("रद्द", "रद्द करें"), "ok" to listOf("ठीक है"), "next" to listOf("आगे", "अगला")
    )

    fun clean(q: String): String {
        val words = q.lowercase().replace(Regex("[\"'“”.,!?]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }
        val kept = words.filter { it !in noise }
        return (if (kept.isEmpty()) words else kept).joinToString(" ").trim()
    }

    fun kindOf(q: String): Kind {
        val l = q.lowercase()
        return when {
            Regex("\\b(field|box|bar|edit|input|likhne)\\b").containsMatchIn(l) -> Kind.FIELD
            Regex("\\b(switch|toggle|checkbox)\\b").containsMatchIn(l) -> Kind.SWITCH
            Regex("\\b(button|btn)\\b").containsMatchIn(l) -> Kind.BUTTON
            else -> Kind.ANY
        }
    }

    fun find(snap: ScreenSnapshot, rawQuery: String, kind: Kind = kindOf(rawQuery)): List<Match> {
        val q = clean(rawQuery)
        if (q.isBlank()) return emptyList()
        val variants = listOf(q) + (alias[q] ?: emptyList())
        val out = ArrayList<Match>()
        for (e in snap.elements) {
            if (e.password) continue
            if (kind == Kind.FIELD && !e.editable) continue
            if (kind == Kind.SWITCH && !(e.checkable || e.kind == "switch")) continue
            if (kind == Kind.BUTTON && !(e.clickable || e.kind == "button")) continue
            val fields = listOf(e.text, e.desc, e.hint).map { it.lowercase() }
            val id = e.viewId.lowercase()
            var best = 0
            for (v in variants) {
                val vl = v.lowercase()
                for (f in fields) {
                    if (f.isEmpty()) continue
                    val s = when {
                        f == vl -> 100
                        f.startsWith(vl) -> 80
                        Regex("(^|\\W)" + Regex.escape(vl) + "($|\\W)").containsMatchIn(f) -> 65
                        f.contains(vl) -> 45
                        else -> 0
                    }
                    if (s > best) best = s
                }
                if (best < 40 && id.contains(vl.replace(' ', '_'))) best = maxOf(best, 25)
            }
            if (best == 0) continue
            if (e.clickable || e.editable) best += 8
            if (!e.enabled) best -= 15
            out.add(Match(e, best))
        }
        // Same on-screen rectangle = same thing (a label inside its own button).
        return out.sortedByDescending { it.score }.distinctBy { it.el.bounds.flattenToString() }
    }

    /** Elements that look like search inputs or search buttons. */
    fun searchTargets(snap: ScreenSnapshot): List<UiElement> {
        val keys = listOf("search", "खोज", "find", "query")
        val fields = snap.editable.filter { e -> keys.any { k -> (e.hint + e.desc + e.text + e.viewId).lowercase().contains(k) } }
        if (fields.isNotEmpty()) return fields
        val anyField = snap.editable.firstOrNull()
        val buttons = snap.elements.filter { e -> !e.password && (e.clickable || e.editable) && keys.any { k -> (e.desc + e.text + e.hint + e.viewId).lowercase().contains(k) } }
        return buttons.ifEmpty { listOfNotNull(anyField) }
    }

    /** Heuristic for "is result ko kholo": big clickable items below the top bar, in reading order. */
    fun results(snap: ScreenSnapshot): List<UiElement> {
        val top = snap.height * 0.14f
        val bottom = snap.height * 0.93f
        return snap.clickable.filter { e ->
            e.cy > top && e.cy < bottom && !e.editable && e.bounds.width() > snap.width * 0.4f &&
                (e.label.length >= 8 || e.area > snap.width * snap.height * 0.06f)
        }.sortedWith(compareBy({ it.bounds.top }, { it.bounds.left }))
    }
}
