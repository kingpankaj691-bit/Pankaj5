package com.nova.ai.search

import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.core.AIProvider
import com.nova.ai.security.Prefs
import com.nova.ai.web.WebIntent
import com.nova.ai.web.WebKind

/**
 * Web answers without Gemini grounding (for OpenAI users, or when there is no Gemini key):
 * User query -> [SearchProvider] -> public results -> summary by the selected AI (or the raw extract if no AI key) -> TTS/UI.
 */
class SearchFallback(
    private val prefs: Prefs,
    private val search: SearchProvider = PublicSearchProvider(),
    private val news: NewsProvider = RssNewsProvider(),
    private val ai: AIProvider = SwitchingProvider(prefs)
) {
    suspend fun run(intent: WebIntent, languageHint: String): String = when (intent.kind) {
        WebKind.NEWS -> news(intent.query)
        WebKind.PRICE -> "⚠ Live prices need Gemini web search. Pick Gemini and add its key in Settings, or open a shopping site."
        else -> answer(intent.query, languageHint)
    }

    private suspend fun news(topic: String): String {
        val items = news.headlines(topic, 5)
        if (items.isEmpty()) return "⚠ I couldn't load headlines right now. Check your internet."
        return "Headlines:\n" + items.mapIndexed { i, n -> "${i + 1}. ${n.title}" + if (n.source.isNotBlank()) " (${n.source})" else "" }.joinToString("\n")
    }

    private suspend fun answer(query: String, hint: String): String {
        val hits = search.search(query)
        if (hits.isEmpty()) return "⚠ I couldn't find a public answer for \"$query\". Gemini web search covers more; add a Gemini key to use it."
        val sources = hits.mapNotNull { h -> h.url.takeIf { it.isNotBlank() }?.substringAfter("://")?.substringBefore('/') }.distinct()
        val tail = if (sources.isEmpty()) "" else "\n\nSources: " + sources.joinToString(", ")
        if (!prefs.hasActiveKey() || prefs.localOnly || !prefs.aiEnabled) return hits.first().text + tail
        val material = hits.joinToString("\n\n") { "${it.title}: ${it.text}" }.take(4000)
        val sys = "Answer the user's question briefly using ONLY the public source text provided. If it does not answer the question, say so. " +
            "Write plain text without markdown, short enough to be read aloud. $hint"
        return when (val r = ai.chat(listOf(true to "Question: $query\n\nSources:\n$material"), sys, null)) {
            is AiResult.Ok -> r.text.trim() + tail
            is AiResult.Err -> hits.first().text + tail
        }
    }
}
