package com.nova.ai.voice

import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

/**
 * Amplitude/RMS voice activity detection over 16-bit little-endian PCM. It cuts the live microphone stream into one segment per
 * spoken phrase, so the recognizer gets "what you said" instead of blind fixed-length clips.
 *
 *  - The speech threshold follows the room: it sits [NOISE_MARGIN] times above a slowly learned noise floor (never below [MIN_THRESHOLD]).
 *  - A short pre-roll is kept so the first syllable is not cut off.
 *  - A phrase ends after [HANGOVER_MS] of quiet, or at [MAX_SEGMENT_MS] so memory stays bounded.
 *  - Segments with less than [MIN_SPEECH_MS] of loud audio (clicks, taps) are dropped.
 *
 * Not thread-safe by itself: [push] is called from the capture thread; [reset] may come from another, so both are synchronized.
 */
class AmplitudeVAD(
    private val sampleRate: Int,
    private val channels: Int,
    private val onSegment: (ByteArray) -> Unit
) {
    companion object {
        const val MIN_THRESHOLD = 450.0
        const val NOISE_MARGIN = 3.0
        const val MIN_SPEECH_MS = 250
        const val HANGOVER_MS = 800
        const val MAX_SEGMENT_MS = 15000
        const val PREROLL_MS = 300
        private const val MAX_NOISE_FLOOR = 2000.0
    }

    private val lock = Any()
    private val bytesPerMs = (sampleRate * 2 * channels / 1000.0).coerceAtLeast(1.0)
    private val preroll = ArrayDeque<ByteArray>()
    private var prerollMs = 0.0
    private var seg = ByteArrayOutputStream()
    private var inSpeech = false
    private var voicedMs = 0.0
    private var quietMs = 0.0
    private var segMs = 0.0
    private var noiseFloor = 150.0

    /** Current speech threshold, for debugging or a settings read-out. */
    val threshold: Double get() = synchronized(lock) { maxOf(MIN_THRESHOLD, noiseFloor * NOISE_MARGIN) }

    fun push(buf: ByteArray, len: Int) {
        if (len < 2) return
        var finished: ByteArray? = null
        synchronized(lock) {
            val chunk = buf.copyOf(len)
            val ms = len / bytesPerMs
            val loud = rms(chunk) > maxOf(MIN_THRESHOLD, noiseFloor * NOISE_MARGIN)
            if (!inSpeech) {
                if (!loud) {
                    noiseFloor = (noiseFloor * 0.95 + rms(chunk) * 0.05).coerceAtMost(MAX_NOISE_FLOOR)
                    preroll.addLast(chunk); prerollMs += ms
                    while (prerollMs > PREROLL_MS && preroll.size > 1) prerollMs -= preroll.removeFirst().size / bytesPerMs
                    return
                }
                inSpeech = true
                seg = ByteArrayOutputStream()
                preroll.forEach { seg.write(it, 0, it.size) }
                segMs = prerollMs; voicedMs = 0.0; quietMs = 0.0
                preroll.clear(); prerollMs = 0.0
            }
            seg.write(chunk, 0, chunk.size)
            segMs += ms
            if (loud) { voicedMs += ms; quietMs = 0.0 } else quietMs += ms
            if (quietMs >= HANGOVER_MS || segMs >= MAX_SEGMENT_MS) {
                if (voicedMs >= MIN_SPEECH_MS) finished = seg.toByteArray()
                inSpeech = false; seg = ByteArrayOutputStream(); voicedMs = 0.0; quietMs = 0.0; segMs = 0.0
            }
        }
        finished?.let(onSegment)
    }

    /** Drops any half-finished phrase (used while Nova is speaking, and on stop). */
    fun reset() = synchronized(lock) {
        inSpeech = false; seg = ByteArrayOutputStream(); voicedMs = 0.0; quietMs = 0.0; segMs = 0.0
        preroll.clear(); prerollMs = 0.0
    }

    private fun rms(b: ByteArray): Double {
        var sum = 0.0
        var n = 0
        var i = 0
        while (i + 1 < b.size) {
            val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s
            n++; i += 2
        }
        return if (n == 0) 0.0 else sqrt(sum / n)
    }
}
