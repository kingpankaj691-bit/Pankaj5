package com.nova.ai.brain

sealed class BrainIntent {
    data class Remember(val content: String) : BrainIntent()
    object DontSave : BrainIntent()
    object WhatDoYouRemember : BrainIntent()
    data class Recall(val query: String, val explicitTold: Boolean) : BrainIntent()
    data class Update(val hint: String, val newText: String) : BrainIntent()
    data class Delete(val hint: String) : BrainIntent()
    data class MarkDone(val hint: String) : BrainIntent()
    object PendingList : BrainIntent()
    object ProjectMemory : BrainIntent()
    data class FindFile(val query: String, val open: Boolean) : BrainIntent()
    object Recap : BrainIntent()
    data class ResumeTopic(val query: String) : BrainIntent()
    data class RemindTask(val hint: String) : BrainIntent()
    object PauseSaving : BrainIntent()
    object ResumeSaving : BrainIntent()
    object WipeAll : BrainIntent()
}

/** Hindi, Hinglish and English memory commands. Returns null for anything that is not a memory command, so the rest of Nova handles it. */
object BrainIntents {
    private fun clean(raw: String): String = raw.trim().replace(Regex("(?i)^(hey |hi |ok |okay )?nova[ ,:!.-]*"), "").trim().trim('.', '!', '?', ' ')

    private val wipe = Regex("(?i)(saari|sari|poori|puri|all|sab|meri saari)\\s+(memory|memories|yaadein|yaaddasht)\\s*(ko\\s+)?(delete|clear|saaf|mita|hata|erase)|(delete|clear|erase|wipe)\\s+(all|everything|my entire|my whole)\\s*(my\\s+)?(memory|memories)?|forget everything|sab kuch bhool jao|clear (my )?memory|delete all (my )?memor")
    private val pause = Regex("(?i)(memory|yaad|auto\\s*save|saving)\\s*(save\\s*)?(karna\\s*)?(band|pause|rok|off|stop)|pause\\s+(auto(matic)?\\s+)?(memory|saving)|stop\\s+saving|save\\s*karna\\s*band|automatic\\s+memory\\s+(band|off)")
    private val resumeSave = Regex("(?i)(memory|auto\\s*save|saving)\\s*(save\\s*)?(karna\\s*)?(chalu|on|start|resume|shuru)|resume\\s+(auto(matic)?\\s+)?(memory|saving)|memory\\s+save\\s+karna\\s+(chalu|shuru)")
    private val whatRemember = Regex("(?i)(meri|my)\\s+memory\\s+(mein|me|main|has|contains)?\\s*(kya|what)|kya\\s+kya\\s+(save|yaad)|what\\s+(do you|all do you|have you)\\s+(remember|saved|stored)|what('s| is)\\s+(saved|stored)\\s+in\\s+(my\\s+)?memory|memory\\s+(dikhao|dikha|batao|show)|show\\s+(me\\s+)?(my\\s+)?memor|mere\\s+baare\\s+mein\\s+kya\\s+(yaad|pata|save)|what\\s+do\\s+you\\s+know\\s+about\\s+me|meri\\s+memory\\s+mein\\s+kya")
    private val projectMem = Regex("(?i)(project|projects)\\s+(memory|list|yaad)|(purani|puraani|old|saved)\\s+project\\s+memory|(mere|my)\\s+(saare |all )?projects?\\b(?!\\s+(ka|ki|ke|mein|me)\\b.*(code|file))|(pichhla|pichla|pichhle|pichle|previous|last|purana|puraana)\\s+project|project\\s+memory\\s+dikhao")
    private val pending = Regex("(?i)((pending|adhura|adhure|baaki|unfinished|remaining|incomplete)\\s+.{0,25}(kaam|task|tasks|feature|features|items?|cheez|cheezein)|(kaam|task|tasks|features?)\\s+(abhi\\s+)?(pending|baaki|adhure)|kaun\\s*se\\s+(features?|kaam|tasks?)\\s+(abhi\\s+)?(pending|baaki|adhure)|what('s| is)\\s+pending|my\\s+(pending\\s+)?(tasks|todos?)|mere\\s+(pending\\s+)?(tasks|kaam)|kya\\s+kya\\s+(karna|baaki)\\s+(hai|hain))")
    private val doneRe = Regex("(?i)^(.{3,80}?)\\s+(complete\\s+ho\\s+gaya|ho\\s+gaya|ho\\s+gayi|khatam\\s+ho\\s+gaya|finish\\s+ho\\s+gaya|is\\s+done|are\\s+done|done|completed|finished)$")
    private val updateRe = Regex("(?i)^(?:meri\\s+|mera\\s+|ye\\s+|is\\s+|my\\s+)?(.*?)\\s*(?:information|info|detail|memory|baat)?\\s*(?:update\\s+karo|update\\s+kar\\s+do|update\\s+it|update\\s+my|badal\\s+do|badlo|change\\s+karo|please\\s+update)\\s*(?:to|ki|ko|:|,|-)?\\s*(.*)$")
    private val deleteRe = Regex("(?i)(delete|hatao|hata\\s+do|mita\\s+do|mitao|bhool\\s+jao|bhul\\s+jao|forget|remove)")
    private val memWord = Regex("(?i)\\b(information|info|memory|yaad|baat|detail|task|project|reminder|note|preference|plan|decision)\\b|bhool\\s+jao|bhul\\s+jao|\\bforget\\b")
    private val fileQ = Regex("(?i)((kahan|where)\\s+(hai|hain|is|are|did)|locate|dhoondo|dhundo|\\bfind\\b|search)\\b.*\\b(file|files|code|folder|document|class|screen|engine)\\b|\\b(code|file|files|folder|document)\\s+kahan\\s+(hai|hain)|(ka|ki|ke)\\s+(code|file|folder)\\s+kahan|where\\s+is\\s+(the\\s+|my\\s+)?(code|file)")
    private val openProject = Regex("(?i)^(mera|meri|mere|my)?\\s*(purana|purani|old|pichhla|pichla)?\\s*(.{2,40}?)\\s+project\\s+(kholo|open\\s+karo|open)$|^open\\s+(my\\s+)?(old\\s+|previous\\s+)?(.{2,40}?)\\s+project$")
    private val remindTask = Regex("(?i)((is|iss|us|uss)\\s+(task|kaam|feature|project)\\s+(ka|ke\\s+liye)\\s+reminder|reminder\\s+(laga|set|lagao|do).{0,20}(task|kaam|project)|set\\s+(a\\s+)?reminder\\s+for\\s+(this|that|the)\\s+(task|project))")
    private val told = Regex("(?i)(bataya|batayi|kaha\\s+tha|bola\\s+tha|told\\s+you|tell\\s+you|did\\s+i\\s+(tell|say|share|mention)|share\\s+kiya|mention\\s+kiya)")
    private val recall = Regex("(?i)((maine|maine\\s+tumhe|humne|mene)\\s+.{0,40}(bataya|kaha|bola|diya|share)|what\\s+did\\s+i\\s+(tell|say|share|mention)|did\\s+i\\s+(tell|mention)|(mera|meri|mere)\\s+.{1,50}\\s+(kya|kaun|kaunsa|konsa|kab|kahan)\\s+(tha|thi|the)|(kya|kaun)\\s+(tha|thi)\\s+(mera|meri|mere)|kya\\s+tumhe\\s+yaad\\s+hai|do\\s+you\\s+remember|yaad\\s+(hai|dilao|dila\\s+do)\\b|what\\s+was\\s+my)")

    fun parse(raw: String): BrainIntent? {
        val t = clean(raw)
        if (t.length < 4) return null
        val l = t.lowercase()
        if (wipe.containsMatchIn(l)) return BrainIntent.WipeAll
        if (resumeSave.containsMatchIn(l)) return BrainIntent.ResumeSaving
        if (pause.containsMatchIn(l)) return BrainIntent.PauseSaving
        if (MemoryExtractor.directive(t) == Directive.DONT_SAVE) return BrainIntent.DontSave
        if (remindTask.containsMatchIn(l)) return BrainIntent.RemindTask(t)
        TopicEngine.queryKind(t)?.let { return if (it == TopicQuery.RECAP) BrainIntent.Recap else BrainIntent.ResumeTopic(t) }
        if (pending.containsMatchIn(l)) return BrainIntent.PendingList
        if (projectMem.containsMatchIn(l)) return BrainIntent.ProjectMemory
        if (whatRemember.containsMatchIn(l)) return BrainIntent.WhatDoYouRemember
        updateRe.find(t)?.let { m -> if (m.groupValues[0].isNotBlank() && Regex("(?i)update|badal|badlo|change").containsMatchIn(t)) return BrainIntent.Update(m.groupValues[1].trim(), m.groupValues[2].trim()) }
        if (deleteRe.containsMatchIn(l) && memWord.containsMatchIn(l)) return BrainIntent.Delete(
            t.replace(Regex("(?i)(delete|hatao|hata do|mita do|mitao|bhool jao|bhul jao|forget|remove|karo|kar do|please|ko|ise|isko|ye|is|information|info)"), " ").replace(Regex("\\s+"), " ").trim())
        openProject.find(t)?.let { m -> val name = (m.groupValues[3].ifBlank { m.groupValues[6] }).trim(); if (name.isNotBlank()) return BrainIntent.FindFile(name, true) }
        if (fileQ.containsMatchIn(l)) return BrainIntent.FindFile(t, false)
        if (recall.containsMatchIn(l)) return BrainIntent.Recall(t, told.containsMatchIn(l))
        doneRe.find(t)?.let { return BrainIntent.MarkDone(it.groupValues[1].trim()) }
        if (MemoryExtractor.directive(t) == Directive.REMEMBER) return BrainIntent.Remember(MemoryExtractor.stripWrapper(t))
        return null
    }

    fun isYes(t: String) = Regex("(?i)^(haan|han|haa|ha|yes|yeah|yep|ok|okay|sure|theek hai|thik hai|kar do|kardo|save kar do|save karo|zaroor|bilkul|y)\\b").containsMatchIn(t.trim())
    fun isNo(t: String) = Regex("(?i)^(nahi|nahin|na|no|nope|mat|cancel|rehne do|ruko|don'?t|n)\\b").containsMatchIn(t.trim())

    /** 0-based index of a spoken or typed choice, or -1. */
    fun choiceIndex(t: String, options: List<String>): Int {
        val l = t.trim().lowercase().trim('.', '!', '?')
        val ord = listOf(listOf("1", "pehla", "pehle", "first", "ek", "one"), listOf("2", "doosra", "dusra", "second", "do", "two"), listOf("3", "teesra", "third", "teen", "three"))
        ord.forEachIndexed { i, w -> if (l in w && i < options.size) return i }
        if (l.length >= 3) { val hits = options.withIndex().filter { Txt.tokenSet(l).isNotEmpty() && Txt.tokenSet(l).all { w -> w in Txt.tokenSet(it.value) } }; if (hits.size == 1) return hits[0].index }
        return -1
    }
}
