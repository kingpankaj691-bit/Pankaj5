package com.nova.ai.planner

import com.nova.ai.accessibility.TextVerify
import com.nova.ai.device.DeviceController
import com.nova.ai.screen.ActionResult
import com.nova.ai.screen.ContactRow
import com.nova.ai.screen.FailureKind
import com.nova.ai.screen.Failures
import com.nova.ai.screen.ScreenActionExecutor
import com.nova.ai.screen.SendOutcome
import com.nova.ai.screen.SensitiveText
import com.nova.ai.screen.WhatsAppUi
import com.nova.ai.screen.byId
import com.nova.ai.screen.cands
import com.nova.ai.screen.texts
import com.nova.ai.security.Prefs
import kotlinx.coroutines.delay

/**
 * WhatsApp through the Accessibility tree, with the user in control:
 *  - a message is ONLY sent after [PlanHost.confirm] showed the recipient and the exact text and got a yes;
 *  - after that yes the chat and the draft are checked again (the screen may have changed while waiting);
 *  - "Send" is pressed at most once (never retried: a retry could send twice);
 *  - "sent" is reported only when the box is empty AND a new bubble with the text appeared;
 *  - registration / verification screens, passwords, OTPs and codes are never read or typed;
 *  - text read from chats has codes and card numbers hidden.
 */
class WhatsAppFlow(
    private val prefs: Prefs,
    private val device: DeviceController,
    private val exec: ScreenActionExecutor,
    private val host: PlanHost
) {
    private fun t(h: Boolean, hi: String, en: String) = if (h) hi else en
    private fun fail(msg: String) = ActionResult(false, msg)
    private fun clip(s: String, n: Int) = if (s.length <= n) s else s.take(n - 1) + "…"
    private class Chat(val result: ActionResult, val name: String = "", val byNumber: Boolean = false, val pkg: String = "")

    private fun onboardingMsg(h: Boolean) = t(h,
        "WhatsApp registration/verification screen par hai. Main codes ya phone number kabhi nahi padhti/bharti. Ye khud pura karo.",
        "WhatsApp is on a registration or verification screen. I never read or enter codes or phone numbers. Please finish that yourself.")

    /** Brings WhatsApp back to the front if the user went elsewhere (for example to answer a confirmation). */
    private suspend fun ensureFront(pkg: String, h: Boolean): ActionResult? {
        if (exec.foreground() == pkg) return null
        val r = device.openPackage(pkg, device.appLabel(pkg))
        if (!r.startsWith("Opening")) return fail(r)
        if (!exec.waitForPackage(setOf(pkg), 6500)) return fail(Failures.message(FailureKind.APP_NOT_IN_FRONT, "WhatsApp", h))
        delay(500)
        return null
    }

    private suspend fun enterChat(contact: String, h: Boolean, prefill: String?): Chat {
        val pkg = exec.foreground()
        if (!WhatsAppUi.isWhatsApp(pkg)) return Chat(fail(Failures.message(FailureKind.APP_NOT_IN_FRONT, "WhatsApp", h)))
        var snap = exec.waitFor(4000) { it.elements.isNotEmpty() } ?: return Chat(fail(Failures.message(FailureKind.SCREEN_UNREADABLE, "WhatsApp", h)))
        if (WhatsAppUi.isOnboarding(snap.texts())) return Chat(fail(onboardingMsg(h)))

        val byNumber = WhatsAppUi.looksLikeNumber(contact)
        if (!byNumber) WhatsAppUi.openChatTitle(snap.cands())?.let { title ->
            if (WhatsAppUi.sameContact(title, contact)) return Chat(ActionResult(true, t(h, "$title ki chat khuli hai", "Chat with $title is open")), title, false, pkg)
        }
        if (byNumber) return openByNumber(pkg, contact, prefill, h)

        // 1. get to the search field
        var field = WhatsAppUi.searchField(snap.cands())
        if (field == null) {
            var entry = WhatsAppUi.searchEntry(snap.cands())
            if (entry == null && WhatsAppUi.openChatTitle(snap.cands()) != null && exec.back().ok) {   // inside another chat: one Back reaches the list
                delay(600)
                exec.waitFor(2500) { it.pkg == pkg && it.elements.isNotEmpty() }?.let { snap = it; entry = WhatsAppUi.searchEntry(it.cands()) }
            }
            val e = entry?.let { snap.byId(it.id) } ?: return Chat(fail(Failures.message(FailureKind.SEARCH_FIELD_NOT_FOUND, "WhatsApp search", h)))
            val r = exec.tapElement(e)
            if (!r.ok) return Chat(r)
            snap = exec.waitFor(3500) { WhatsAppUi.searchField(it.cands()) != null } ?: return Chat(fail(Failures.message(FailureKind.FIELD_NOT_OPENED, "", h)))
            field = WhatsAppUi.searchField(snap.cands())
        }
        val fieldEl = field?.let { snap.byId(it.id) } ?: return Chat(fail(Failures.message(FailureKind.FIELD_NOT_OPENED, "", h)))

        // 2. type the name (read back inside typeText), wait for matching rows
        val typed = exec.typeText(contact, fieldEl)
        if (!typed.ok) return Chat(typed)
        delay(600)
        val found = exec.waitFor(6000) { WhatsAppUi.contactRows(it.cands(), contact).isNotEmpty() }
            ?: return Chat(fail(t(h, "WhatsApp me \"$contact\" naam ka chat ya contact nahi mila.", "I couldn't find a chat or contact named \"$contact\" in WhatsApp.")))
        val rows = WhatsAppUi.closeMatches(WhatsAppUi.contactRows(found.cands(), contact))

        // 3. never guess between different people
        val chosen: ContactRow = if (rows.size == 1) rows[0] else {
            val labels = rows.take(5).mapIndexed { i, r -> "${i + 1}. ${r.name}" }
            val idx = host.choose(t(h, "\"$contact\" ke ${rows.size} match mile. Kisko?", "I found ${rows.size} matches for \"$contact\". Which one?"), labels)
            if (idx < 0 || idx >= labels.size) return Chat(fail(t(h, "Theek hai, kisi ko select nahi kiya.", "Okay, I didn't pick anyone.")))
            rows[idx]
        }
        ensureFront(pkg, h)?.let { return Chat(it) }
        val again = exec.waitFor(4000) { s -> WhatsAppUi.contactRows(s.cands(), contact).any { WhatsAppUi.norm(it.name) == WhatsAppUi.norm(chosen.name) } }
            ?: return Chat(fail(t(h, "Search result badal gaya. Kuch nahi bheja.", "The search results changed. Nothing was done.")))
        val row = WhatsAppUi.contactRows(again.cands(), contact).first { WhatsAppUi.norm(it.name) == WhatsAppUi.norm(chosen.name) }
        val rowEl = again.byId(row.cand.id) ?: return Chat(fail(t(h, "Chat row nahi mili.", "I couldn't find that chat row.")))
        val tap = exec.tapContent(rowEl)
        if (!tap.ok) return Chat(tap)

        // 4. prove the right chat is open
        val open = exec.waitFor(7000) { s ->
            val title = WhatsAppUi.openChatTitle(s.cands())
            title != null && WhatsAppUi.sameContact(title, chosen.name) && WhatsAppUi.messageField(s.cands()) != null
        } ?: return Chat(fail(Failures.message(FailureKind.PAGE_NOT_LOADED, "", h) + t(h, " Chat ${chosen.name} nahi khuli.", " The chat with ${chosen.name} didn't open.")))
        val title = WhatsAppUi.openChatTitle(open.cands()) ?: chosen.name
        return Chat(ActionResult(true, t(h, "$title ki chat khuli", "Opened the chat with $title")), title, false, pkg)
    }

    private suspend fun openByNumber(pkg: String, phone: String, prefill: String?, h: Boolean): Chat {
        if (!device.openWhatsAppChat(pkg, phone, prefill.orEmpty())) return Chat(fail(t(h, "Is number ki chat nahi khul payi.", "I couldn't open a chat for that number.")))
        if (!exec.waitForPackage(setOf(pkg), 6500)) return Chat(fail(Failures.message(FailureKind.APP_NOT_IN_FRONT, "WhatsApp", h)))
        val s = exec.waitFor(8000) { WhatsAppUi.messageField(it.cands()) != null }
            ?: return Chat(fail(t(h, "WhatsApp ne chat nahi kholi (number WhatsApp par na ho).", "WhatsApp didn't open a chat (that number may not be on WhatsApp).")))
        val title = WhatsAppUi.openChatTitle(s.cands()) ?: phone
        return Chat(ActionResult(true, t(h, "$title ki chat khuli", "Opened the chat with $title")), title, true, pkg)
    }

    suspend fun openChat(contact: String, h: Boolean): ActionResult = enterChat(contact, h, null).result

    suspend fun send(contact: String, message: String, h: Boolean): ActionResult {
        if (message.isBlank()) return fail(t(h, "Message khali hai.", "The message is empty."))
        val chat = enterChat(contact, h, message)
        if (!chat.result.ok) return chat.result
        val name = chat.name
        val pkg = chat.pkg

        // type the draft (skipped if the deep link already filled it), read back
        var snap = exec.waitFor(4000) { WhatsAppUi.messageField(it.cands()) != null } ?: return fail(t(h, "Message box nahi mila.", "I couldn't find the message box."))
        var field = WhatsAppUi.messageField(snap.cands())?.let { snap.byId(it.id) } ?: return fail(t(h, "Message box nahi mila.", "I couldn't find the message box."))
        if (!TextVerify.matches(message, exec.readField(field))) {
            val r = exec.typeText(message, field)
            if (!r.ok) return r
        }

        // EXPLICIT confirmation: recipient and exact text. Nothing is sent without a yes.
        val warn = if (SensitiveText.looksSensitive(message))
            t(h, "\n⚠ Is message me password/OTP/PIN/card jaisa kuch lag raha hai.", "\n⚠ This message looks like it contains a password, OTP, PIN or card number.") else ""
        val yes = host.confirm(t(h,
            "WhatsApp message bhejun?\nKisko: $name\nMessage: \"$message\"$warn",
            "Send this WhatsApp message?\nTo: $name\nMessage: \"$message\"$warn"))
        if (!yes) {
            ensureFront(pkg, h)
            exec.snapshot()?.let { s -> WhatsAppUi.messageField(s.cands())?.let { c -> s.byId(c.id) }?.let { exec.typeText("", it) } }   // clear the draft
            return fail(t(h, "Cancel kiya. Kuch nahi bheja, draft hata diya.", "Cancelled. Nothing was sent and I cleared the draft."))
        }

        // the screen may have changed while waiting: bring WhatsApp back and re-check chat + draft
        ensureFront(pkg, h)?.let { return it }
        snap = exec.waitFor(5000) { s ->
            WhatsAppUi.messageField(s.cands()) != null &&
                (chat.byNumber || WhatsAppUi.openChatTitle(s.cands())?.let { WhatsAppUi.sameContact(it, name) } == true)
        } ?: return fail(t(h, "Chat ab khuli nahi hai (screen badal gayi). Kuch nahi bheja.", "The chat isn't open any more (the screen changed). Nothing was sent."))
        field = WhatsAppUi.messageField(snap.cands())?.let { snap.byId(it.id) } ?: return fail(t(h, "Message box nahi mila. Kuch nahi bheja.", "I couldn't find the message box. Nothing was sent."))
        if (!TextVerify.matches(message, exec.readField(field))) {
            val r = exec.typeText(message, field)
            if (!r.ok) return r
        }
        val ready = exec.waitFor(3000) { WhatsAppUi.sendButton(it.cands()) != null }
            ?: return fail(t(h, "Send button nahi dikha. Kuch nahi bheja.", "The Send button isn't visible. Nothing was sent."))
        val btn = WhatsAppUi.sendButton(ready.cands())?.let { ready.byId(it.id) } ?: return fail(t(h, "Send button nahi mila.", "I couldn't find the Send button."))
        val wanted = WhatsAppUi.norm(message)
        val before = WhatsAppUi.messageTexts(ready.cands()).count { WhatsAppUi.norm(it).contains(wanted) }

        // Press Send ONCE. It is never retried: a retry could send the message twice.
        val tap = exec.tapElement(btn, verify = false)
        if (!tap.ok) return fail(t(h, "Send press nahi ho paya: ", "I couldn't press Send: ") + tap.message)

        var outcome = SendOutcome.NOT_SENT
        var i = 0
        while (i < 12 && outcome != SendOutcome.CONFIRMED) {
            delay(500); i++
            val s = exec.snapshot() ?: continue
            val f = WhatsAppUi.messageField(s.cands())?.let { s.byId(it.id) }
            val fieldEmpty = f != null && exec.readField(f).isNullOrBlank()
            val now = WhatsAppUi.messageTexts(s.cands()).count { WhatsAppUi.norm(it).contains(wanted) }
            outcome = WhatsAppUi.sendOutcome(fieldEmpty, now > before)
        }
        return when (outcome) {
            SendOutcome.CONFIRMED -> ActionResult(true, t(h, "$name ko bhej diya: \"${clip(message, 60)}\"", "Sent to $name: \"${clip(message, 60)}\""))
            SendOutcome.UNCONFIRMED -> fail(t(h,
                "Send dabaya aur message box khali ho gaya, par chat me message dikha nahi. Ek baar chat khud check kar lo.",
                "I pressed Send and the message box is empty, but I can't see the message in the chat. Please check the chat yourself."))
            SendOutcome.NOT_SENT -> fail(t(h, "Send dabaya par message abhi box me hi hai, isliye nahi gaya.", "I pressed Send but the message is still in the box, so it was not sent."))
        }
    }

    /** Reads what is visible on a WhatsApp chat list or chat, with codes hidden. Only runs when the user asks. */
    suspend fun readVisible(h: Boolean): ActionResult {
        if (!WhatsAppUi.isWhatsApp(exec.foreground())) return fail(Failures.message(FailureKind.APP_NOT_IN_FRONT, "WhatsApp", h))
        val snap = exec.waitFor(4000) { it.elements.isNotEmpty() } ?: return fail(Failures.message(FailureKind.SCREEN_UNREADABLE, "WhatsApp", h))
        if (WhatsAppUi.isOnboarding(snap.texts())) return fail(onboardingMsg(h))
        val cs = snap.cands()
        val title = WhatsAppUi.openChatTitle(cs)
        if (title != null) {
            val msgs = WhatsAppUi.messageTexts(cs).takeLast(8).map { SensitiveText.redact(it) }
            if (msgs.isEmpty()) return fail(t(h, "Is chat me koi message dikh nahi raha.", "I can't see any messages in this chat."))
            return ActionResult(true, clip(t(h, "$title ki chat: ", "Chat with $title: ") + msgs.joinToString(" | "), 900))
        }
        val entries = WhatsAppUi.chatListEntries(cs).take(8)
        if (entries.isEmpty()) return fail(t(h, "Is screen par chat ke naam padh nahi pa rahi.", "I can't read chat names on this screen."))
        val body = entries.joinToString(" | ") { e ->
            e.name + (if (e.preview.isNotBlank()) ": " + SensitiveText.redact(e.preview) else "") + (if (e.unread.isNotBlank()) " (${e.unread} unread)" else "")
        }
        return ActionResult(true, clip(t(h, "Chats: ", "Chats: ") + body, 900))
    }
}
