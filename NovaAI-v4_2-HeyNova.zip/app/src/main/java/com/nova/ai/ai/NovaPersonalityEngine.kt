package com.nova.ai.ai

import com.nova.ai.core.PersonalityEngine

class NovaPersonalityEngine : PersonalityEngine {
    override fun prompt(p: Personality, custom: String): String =
        if (p == Personality.Custom) custom.ifBlank { "Talk like a calm futuristic assistant." } else p.prompt
    override fun emotion(p: Personality, mood: Mood, override: String, text: String, developer: Boolean): Emotion =
        MoodEngine.derive(p, mood, override, text, developer)
}
