package com.nova.ai.jarvis

import android.content.Context
import com.nova.ai.voice.PcmFormat
import com.nova.ai.voice.SpeechProcessingEngine
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * On-device speech recognition with Vosk: no internet, no Gemini quota. It decides on its own where a sentence ends.
 * Accuracy is lower than Gemini's, especially for Hindi and Hinglish.
 */
class OfflineSpeechEngine(
    private val ctx: Context,
    private val jp: JarvisPrefs,
    private val onText: (String) -> Unit,
    private val onProblem: (String) -> Unit
) : SpeechProcessingEngine {
    private val lock = Any()
    private var model: Model? = null
    private var rec: Recognizer? = null

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        val id = jp.offlineLang
        if (!VoskModelManager.isInstalled(ctx, id)) { onProblem("Offline model not installed. Download it in Jarvis settings."); return }
        scope.launch(Dispatchers.IO) {
            try {
                val m = Model(VoskModelManager.dir(ctx, id).absolutePath)
                val r = Recognizer(m, format.sampleRate.toFloat())
                synchronized(lock) { model = m; rec = r }
            } catch (e: Throwable) { onProblem("Offline speech engine failed to start: ${e.message}") }
        }
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        if (VoiceState.speaking.value) return
        synchronized(lock) {
            val r = rec ?: return
            if (r.acceptWaveForm(audioData, length)) {
                val t = try { JSONObject(r.result).optString("text") } catch (e: Exception) { "" }
                if (t.isNotBlank()) onText(t.trim())
            }
        }
    }

    override fun stop() {
        synchronized(lock) {
            try { rec?.close() } catch (e: Throwable) { }
            try { model?.close() } catch (e: Throwable) { }
            rec = null; model = null
        }
    }
}
