package com.nova.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.files.AnalysisLedger
import com.nova.ai.files.DocReader
import com.nova.ai.files.DocText
import com.nova.ai.files.FileContext
import com.nova.ai.files.FileHistory
import com.nova.ai.files.FileItem
import com.nova.ai.files.FileOp
import com.nova.ai.files.FileReader
import com.nova.ai.files.FileStatus
import com.nova.ai.files.LocalSummary
import com.nova.ai.files.PathRules
import com.nova.ai.files.ProjectAnalyzer
import com.nova.ai.files.SensitiveScan
import com.nova.ai.files.StorageVolumes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** What to read: one file, or a folder (analyzed as a coding project). */
data class AnalyzeTarget(val item: FileItem? = null, val folder: String? = null, val summary: Boolean = false)

/**
 * Read / summarize / ask-Gemini sheet.
 * Everything up to the consent step happens on the phone (text extraction, OCR, local summary, read aloud).
 * Gemini is reachable ONLY through the consent section below, which shows the exact text, needs the master switch, and sends once.
 */
@Composable
internal fun FileAnalysisHost(vm: NovaViewModel, target: AnalyzeTarget, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val isProject = target.folder != null
    val name = target.item?.name ?: (File(target.folder.orEmpty()).name + " (project)")

    var loading by remember(target) { mutableStateOf(true) }
    var doc by remember(target) { mutableStateOf<DocText?>(null) }
    var aiText by remember(target) { mutableStateOf("") }
    var showSummary by remember(target) { mutableStateOf(target.summary) }
    var consent by remember(target) { mutableStateOf(false) }
    var question by remember(target) { mutableStateOf("") }
    var hide by remember(target) { mutableStateOf(true) }
    var busy by remember(target) { mutableStateOf(false) }
    var answer by remember(target) { mutableStateOf("") }
    var aiOn by remember { mutableStateOf(vm.prefs.fileAnalysisToGemini) }

    LaunchedEffect(target) {
        loading = true
        withContext(Dispatchers.IO) {
            val folder = target.folder; val item = target.item
            if (folder != null) {
                val canon = try { File(folder).canonicalPath } catch (e: Exception) { folder }
                if (!PathRules.isWithinAny(StorageVolumes.roots(ctx), canon) || PathRules.blockedReason(canon) != null) {
                    doc = DocText(false, "", "Nova can't analyze that folder.")
                } else {
                    val root = File(canon); val rep = ProjectAnalyzer.analyze(root)
                    doc = DocText(true, rep.toText(), "Counted on this phone.", rep.capped, "Project scan")
                    aiText = ProjectAnalyzer.excerptForAi(root, rep)
                }
            } else if (item != null) {
                FileContext.last = item
                val d = FileReader.read(ctx, item); doc = d; aiText = d.text
            }
        }
        loading = false
        FileHistory.record(ctx, FileOp.ANALYZE, name, "on this phone", if (doc?.ok == true) FileStatus.OK else FileStatus.FAILED, doc?.method ?: doc?.note.orEmpty())
    }

    GlassSheet(onClose, name) {
        if (loading) GText("Reading on this phone…", size = 14.sp, color = g.accent)
        val d = doc
        if (!loading && d != null) {
            if (!d.ok) GText(d.note.ifBlank { "Nothing to show." }, size = 14.sp)
            else {
                GText(d.method + (if (d.note.isNotBlank()) " · " + d.note else "") + " · read on this phone, nothing uploaded", size = 12.sp, color = g.subtext)
                Box(Modifier.fillMaxWidth().height(if (isProject) 200.dp else 150.dp).clip(RoundedCornerShape(16.dp)).background(g.text.a(0.06f)).verticalScroll(rememberScrollState()).padding(12.dp)) {
                    GText(if (isProject) d.text else d.text.take(DocReader.PREVIEW_CHARS) + if (d.text.length > DocReader.PREVIEW_CHARS) "\n…" else "", size = 13.sp)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Read aloud", { vm.voice.speak(if (isProject) d.text.take(900) else d.text.take(1200), vm.emotion) })
                    GlassButton("Stop", { vm.voice.stopSpeaking() })
                    if (!isProject) GlassButton(if (showSummary) "Hide summary" else "Local summary", { showSummary = !showSummary })
                }
                if (showSummary && !isProject) GText(LocalSummary.of(d.text), size = 14.sp)
                if (!consent) GlassButton("Ask Gemini about this…", { consent = true }, Modifier.fillMaxWidth(), primary = true)
            }
        }

        // ── the ONLY path that can send document text to Gemini ──
        if (consent && doc?.ok == true) {
            val findings = remember(aiText) { SensitiveScan.scan(aiText) }
            val payload = if (hide && findings.isNotEmpty()) SensitiveScan.redact(aiText) else aiText
            val blocker = when {
                vm.prefs.localOnly -> "Local-only mode is on. Nothing can be sent."
                !aiOn -> "Gemini document analysis is switched off."
                else -> null
            }
            GlassSettingSection("Send to Google Gemini?") {
                if (blocker != null) {
                    GText(blocker + " Nothing was sent.", size = 14.sp)
                    if (!aiOn && !vm.prefs.localOnly) GlassButton("Turn on Gemini document analysis", { vm.prefs.fileAnalysisToGemini = true; aiOn = true }, Modifier.fillMaxWidth())
                    GlassButton("Cancel", { consent = false }, Modifier.fillMaxWidth())
                } else {
                    GText("You are about to send the text below (${payload.length} characters) to Google's Gemini. Scroll to read all of it. Not sent: the file name, its location, or anything else from your phone.${if (isProject) " This text includes file and folder names of the project." else ""}", size = 13.sp)
                    if (findings.isNotEmpty()) {
                        GText("⚠ This looks like it contains: " + findings.joinToString { "${it.label} (${it.count})" } + ".", size = 13.sp, color = g.accent)
                        GlassListItem("Hide them before sending", "Replaces them with [hidden …]. Recommended.", trailing = { GlassSwitch(hide) { hide = it } })
                    }
                    Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)).background(g.text.a(0.06f)).verticalScroll(rememberScrollState()).padding(12.dp)) { GText(payload, size = 12.sp) }
                    GlassTextField(question, { question = it }, Modifier.fillMaxWidth(), placeholder = "What should Gemini do? (e.g. summarize in 5 points)")
                    GText("This permission covers this one request only. Nova keeps a receipt (time and size, never the text).", size = 12.sp, color = g.subtext)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Send once", {
                            consent = false; busy = true; answer = ""
                            val text = payload; val q = question; val kind = if (isProject) "project" else "file"
                            scope.launch {
                                answer = vm.analyzeFileText(text, q, kind)
                                FileHistory.record(ctx, FileOp.ANALYZE, name, "Gemini", if (answer.startsWith("⚠") || answer.contains("Nothing was sent")) FileStatus.FAILED else FileStatus.OK, "${text.length} chars")
                                busy = false
                            }
                        }, primary = true, enabled = payload.isNotBlank())
                        GlassButton("Cancel", { consent = false })
                    }
                }
            }
        }
        if (busy) GText("Asking Gemini…", size = 13.sp, color = g.accent)
        if (answer.isNotBlank()) GlassSettingSection("Gemini's answer") {
            GText(answer, size = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Read aloud", { vm.voice.speak(answer.take(1500), vm.emotion) })
                GlassButton("Dismiss", { answer = "" })
            }
        }
    }
}

/** Dashboard box: the master switch and the receipt. */
@Composable
internal fun AiFileAnalysisSection(vm: NovaViewModel, bump: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var on by remember { mutableStateOf(vm.prefs.fileAnalysisToGemini) }
    val log = remember(bump, on) { AnalysisLedger.list(ctx) }
    GlassSettingSection("AI file analysis (Gemini)") {
        ToggleRow("Allow Gemini document analysis", "OFF by default. Even when ON, Nova shows the exact text and asks every single time.", on) { on = it; vm.prefs.fileAnalysisToGemini = it }
        GText("Reading, previews, OCR of PDFs, local summaries and project scans all happen on your phone and never need this switch. Local-only mode blocks Gemini completely.", size = 12.sp, color = g.subtext)
        if (log.isEmpty()) GText("Nothing has been sent to Gemini.", size = 12.sp, color = g.subtext)
        else {
            GText("Sent to Gemini ${log.size} time${if (log.size == 1) "" else "s"} (most recent: ${com.nova.ai.files.FileFormat.date(log.first().time)}, ${log.first().chars} characters, ${log.first().kind}).", size = 12.sp, color = g.subtext)
            GlassButton("Clear this receipt", { AnalysisLedger.clear(ctx); onChanged() })
        }
    }
}
