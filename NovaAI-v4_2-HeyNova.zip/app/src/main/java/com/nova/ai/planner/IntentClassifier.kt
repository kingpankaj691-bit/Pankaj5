package com.nova.ai.planner

import com.nova.ai.language.Detected
import com.nova.ai.language.LanguageDetector
import com.nova.ai.security.Prefs
import com.nova.ai.web.WebIntentParser

enum class IntentType { LOCAL_COMMAND, DEVICE_COMMAND, SCREEN_ACTION, MEMORY_OPERATION, WEB_SEARCH, GEMINI_REASONING, OFFLINE_RESPONSE }

data class Classified(val type: IntentType, val language: Detected, val reason: String)

/**
 * First stage of the pipeline: Voice/Text → Language Detection → Intent Detection. This only decides *where* a request goes;
 * the actual routers still do the work. Gemini receives only the conversation plus the minimum context that the chosen
 * route needs (see [ContextPolicy]).
 */
object IntentClassifier {
    private val memoryWords = Regex("(?i)\\b(yaad rakh|yaad hai|remember|forget|bhool|mera naam|memory|memories|mummy|papa|dost|bhai|behen)\\b")
    private val deviceWords = Regex("(?i)\\b(flashlight|torch|volume|brightness|battery|wifi|wi-fi|bluetooth|settings|camera|gallery|call|dial|alarm|timer|storage|ram)\\b")

    fun classify(text: String, online: Boolean, prefs: Prefs, plan: Plan?): Classified {
        val lang = LanguageDetector.detect(text)
        val t = text.lowercase()
        return when {
            plan != null -> Classified(IntentType.SCREEN_ACTION, lang, "screen steps: ${plan.summary()}")
            WebIntentParser.parse(text) != null -> Classified(IntentType.WEB_SEARCH, lang, "web wording")
            memoryWords.containsMatchIn(t) -> Classified(IntentType.MEMORY_OPERATION, lang, "memory wording")
            deviceWords.containsMatchIn(t) && t.split(' ').size <= 6 -> Classified(IntentType.DEVICE_COMMAND, lang, "short device command")
            online && prefs.aiEnabled && !prefs.localOnly && prefs.apiKey.isNotBlank() -> Classified(IntentType.GEMINI_REASONING, lang, "open conversation")
            else -> Classified(IntentType.OFFLINE_RESPONSE, lang, "no cloud brain available")
        }
    }
}

/** What may leave the phone for each route. Nothing else is ever attached to a Gemini request. */
data class ContextPolicy(val conversation: Boolean, val relevantMemory: Boolean, val deviceSummary: Boolean, val people: Boolean, val screenText: Boolean) {
    companion object {
        fun forIntent(t: IntentType) = when (t) {
            IntentType.GEMINI_REASONING -> ContextPolicy(true, true, false, false, false)
            IntentType.WEB_SEARCH -> ContextPolicy(false, false, false, false, false)
            IntentType.SCREEN_ACTION -> ContextPolicy(false, false, false, false, false)
            else -> ContextPolicy(false, false, false, false, false)
        }
    }
}
