package com.nova.ai.people

import com.nova.ai.commands.Cat
import com.nova.ai.commands.Clarification
import com.nova.ai.commands.CmdResult
import com.nova.ai.commands.Level
import com.nova.ai.commands.RouterHooks
import com.nova.ai.core.MemoryManager
import com.nova.ai.device.DeviceController
import com.nova.ai.security.Prefs
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Hinglish + English commands about saved people. Everything runs locally (works offline).
 * Only what the user clearly states is saved. Ambiguous names always lead to a question.
 */
class PeopleCommands(
    private val pm: PeopleMemoryManager, private val device: DeviceController, private val prefs: Prefs,
    private val textMemory: MemoryManager, private val hooks: RouterHooks
) {
    private fun tr(hi: String, en: String) = if (prefs.language == "english") en else hi

    private val REL = RelationshipType.alternation()
    private val NAME = "([\\p{L}]+(?: [\\p{L}]+)?)"
    private val MY = "(?:meri|mera|mere|my)"
    private val intro1 = Regex("$MY ($REL)\\b.*?\\b(?:naam|name) (?:is )?$NAME(?: (?:hai|hain|is))?")
    private val intro2 = Regex("$MY ($REL) $NAME (?:hai|hain|is)\\b")
    private val intro3 = Regex("^(?:ye |yeh |this is )?$NAME (?:is )?$MY ($REL)(?: (?:hai|hain))?$")
    private val nick1 = Regex("([\\p{L}]+) ko (?:main|mai|mein) ([\\p{L}]+) (?:bulata|bulati|bolta|bolti|kehta|kehti|pukarta|pukarti) (?:hoon|hu|hun)")
    private val nick2 = Regex("(?:i call|i address) ([\\p{L}]+) ([\\p{L}]+)")
    private val qName = Regex("(?:what is )?$MY ($REL)(?:'s| ka| ki| ke)? (?:name|naam)\\b")
    private val qMem1 = Regex("^$NAME ke (?:baare|bare) (?:mein|me)\\b")
    private val qMem2 = Regex("what do you (?:remember|know) about $NAME")
    private val qForget1 = Regex("^$NAME ko (?:bhool jao|bhul jao|bhool jaao|bhula do|bhool jaiye)$")
    private val qForget2 = Regex("^forget (?:about )?$NAME$")
    private val qMsg1 = Regex("^$NAME ko (?:message|msg|sms|text) (?:karna|karo|bhejna|karni|bhejo)(?: hai)?$")
    private val qMsg2 = Regex("^(?:message|text|sms) $NAME$")
    private val qCall1 = Regex("^$NAME ko (?:call|phone) (?:karo|karna|lagao|lagana|kar do)(?: hai)?$")
    private val qCall2 = Regex("^(?:call|dial|phone) $NAME$")
    private val qTalk = Regex("^$NAME se baat (?:karwao|karao|karni hai|karna hai|karwa do)$")
    private val qCtx1 = Regex("^$NAME (?:ke saath|ke sath|ke sang) (?:main |mai |mein )?(.+?) (?:karta hoon|karti hoon|karta hu|karti hu|khelta hoon|khelti hoon|khelta hu|khelti hu|dekhta hoon|dekhti hoon|karte hain|khelte hain)$")
    private val qCtx2 = Regex("^i (play|watch|study|talk|work) (.+?) with $NAME$")
    private val qMood1 = Regex("^$NAME (?:ka|ki) mood (?:kya|kaisa|kaisi)")
    private val qMood2 = Regex("^(?:is )?$NAME (?:sad|upset|angry|naraz|udaas|happy|khush|gussa)(?: hai| hain)?$")

    private val common = setOf("hai", "hain", "is", "ka", "ki", "ke", "ko", "se", "aur", "and", "main", "mai", "mein", "mera", "meri", "mere", "my", "ye", "yeh", "this",
        "that", "wo", "woh", "vo", "he", "she", "kal", "aaj", "abhi", "bahut", "bohot", "accha", "achha", "theek", "thik", "naam", "name", "called", "named", "the", "a", "an",
        "to", "aa", "raha", "rahi", "rahe", "kar", "karta", "karti", "ho", "hoon", "hu", "tha", "thi", "bhi", "nahi", "nhi", "kya", "kaun", "koi", "kuch", "mujhe", "tumhe",
        "aap", "tum", "hum", "lekin", "par", "toh", "phir", "jo", "that", "it", "this", "everything", "all", "saare", "saari", "isko", "ise", "nova")

    private fun cleanName(raw: String): String? {
        val t = raw.split(" ").filter { it.isNotBlank() }.toMutableList()
        while (t.isNotEmpty() && t.last() in common) t.removeAt(t.lastIndex)
        while (t.isNotEmpty() && t.first() in common) t.removeAt(0)
        if (t.isEmpty() || t.size > 2 || t.any { it.length < 2 || it in common || RelationshipType.find(it) != null }) return null
        return capName(t.joinToString(" "))
    }

    private fun poss(rt: String) = if (rt.lowercase() in setOf("mummy", "behen", "dadi", "nani", "bua")) "aapki" else "aapke"
    private fun label(p: PersonWithData) = "${p.person.name} (${p.person.relLabel})"
    private fun rel(p: PersonWithData) = p.person.relLabel.lowercase()
    private fun r(cat: Cat, prompt: String = "", level: Level = Level.Info, tag: String = "", priv: Boolean = false, run: () -> String) =
        CmdResult(true, cat, prompt, level, run, tag, priv)

    /** Resolves a name/relation and builds the command. Many matches -> clarification question. None -> notFound text (or null to fall through). */
    private fun personFlow(query: String, cat: Cat, level: Level, priv: Boolean, notFound: String?, promptFor: (PersonWithData) -> String, act: (PersonWithData) -> String): CmdResult? =
        when (val res = pm.resolver.resolve(query)) {
            is Resolution.None -> if (notFound == null) null else r(cat, tag = "basic", priv = priv) { notFound }
            is Resolution.One -> r(cat, if (level == Level.Info) "" else promptFor(res.p), level, "", priv) { act(res.p) }
            is Resolution.Many -> r(cat, priv = priv) {
                hooks.clarify(Clarification(tr("Kaunse $query?", "Which $query?"), res.list.map { p ->
                    label(p) to { if (level == Level.Info) act(p) else { hooks.confirm(promptFor(p)) { act(p) }; "" } }
                }))
                tr("Kaunse $query? ", "Which $query? ") + res.list.joinToString(" / ") { label(it) }
            }
        }

    private fun parseIntro(n: String): Pair<String, RelationshipType>? {
        intro1.find(n)?.let { m -> val rt = RelationshipType.find(m.groupValues[1]); val nm = cleanName(m.groupValues[2]); if (rt != null && nm != null) return nm to rt }
        intro2.find(n)?.let { m -> val rt = RelationshipType.find(m.groupValues[1]); val nm = cleanName(m.groupValues[2]); if (rt != null && nm != null) return nm to rt }
        intro3.find(n)?.let { m -> val rt = RelationshipType.find(m.groupValues[2]); val nm = cleanName(m.groupValues[1]); if (rt != null && nm != null) return nm to rt }
        return null
    }

    private fun describe(pw: PersonWithData): String {
        val p = pw.person
        val now = System.currentTimeMillis()
        val bits = mutableListOf(tr("${poss(p.relLabel)} ${rel(pw)}", "your ${rel(pw)}"))
        if (p.nickname.isNotBlank()) bits.add(tr("aap unhe \"${p.nickname}\" bulate hain", "you call them \"${p.nickname}\""))
        if (p.lastContext.isNotBlank()) bits.add(tr("context: ${p.lastContext}", "context: ${p.lastContext}"))
        val mems = pw.memories.filter { it.kind != "RELATION" && (it.expiresAt == 0L || it.expiresAt > now) }.take(4).map { it.content }.toMutableList()
        if (p.notes.isNotBlank()) mems.add(p.notes)
        return "${p.name}: ${bits.joinToString(", ")}." + if (mems.isNotEmpty()) tr(" Yaad: ", " Remembered: ") + mems.joinToString("; ") else ""
    }

    private fun moodAnswer(pw: PersonWithData): String {
        val p = pw.person
        val recent = p.contextUpdatedAt > 0 && System.currentTimeMillis() - p.contextUpdatedAt < 86400000L
        val upset = p.lastTone in setOf("Sad", "Angry", "Frustrated", "Tired", "Confused")
        return if (recent && upset) tr("Lagta hai conversation ke tone se ${p.name} thoda upset ho sakte hain, lekin main sure nahi hoon.", "From the tone of our conversation ${p.name} might be a bit upset, but I'm not sure.")
        else tr("Mere paas ${p.name} ke current mood ki reliable information nahi hai.", "I don't have reliable information about ${p.name}'s current mood.")
    }

    private fun notFoundMsg(q: String) = tr("\"$q\" naam ka koi saved profile nahi hai. Batana chahein to bol dijiye: \"Ye mera dost $q hai\".", "I don't have a saved profile for \"$q\". You can tell me, for example: \"$q is my friend\".")

    fun route(raw: String, t0: String): CmdResult? {
        val n = t0.replace(Regex("[,.;!?]"), " ").replace(Regex("\\s+"), " ").trim()
        if (n.isEmpty()) return null

        // delete everything about people
        if (listOf("saare people", "saari people", "all people memories", "delete all people", "people memories delete").any { n.contains(it) })
            return r(Cat.SETTINGS_COMMAND, tr("Saari people memories delete kar du? Ye wapas nahi aayega.", "Delete all people memories? This can't be undone."), Level.Sensitive) {
                pm.blocking { pm.deleteAll() }; tr("Ho gaya. Saari people memories delete ho gayi.", "Done. All people memories are deleted.")
            }

        // "don't remember this" / "remember this"
        if (Regex("\\b(?:mat yaad rakh|yaad mat rakh|yaad nahi rakh|don't remember|do not remember|dont remember)").containsMatchIn(n))
            return r(Cat.SETTINGS_COMMAND, tag = "basic") {
                val prev = hooks.lastUserMessage()
                if (prev == null) tr("Kis baat ko? Pehle wo bata dijiye.", "Which message? Tell me first.")
                else { textMemory.neverRemember(prev); pm.blocking { pm.blockText(prev) }; tr("Theek hai, is baat ko yaad nahi rakhungi.", "Okay, I won't remember that.") }
            }
        if (Regex("^(?:isko|ise|is baat ko|ye|yeh|isse|isko bhi) yaad rakh(?:na|o|iye|na hai)?$").containsMatchIn(n))
            return r(Cat.SETTINGS_COMMAND, tag = "basic") {
                val prev = hooks.lastUserMessage()
                if (prev == null) tr("Kya yaad rakhna hai? Pehle wo bata dijiye.", "What should I remember? Tell me first.")
                else {
                    val who = pm.resolver.mentionedIn(prev)
                    if (who.size == 1) {
                        val res = pm.blocking { pm.addNote(who[0].person.personId, prev, true) }
                        if (res == "OK") tr("Theek hai, ${who[0].person.name} ke baare mein ye yaad rakh liya.", "Okay, I saved that about ${who[0].person.name}.") else res
                    } else textMemory.remember(null, prev)
                }
            }

        // lookups
        qName.find(n)?.let { m ->
            val relWord = m.groupValues[1]
            return personFlow("my $relWord", Cat.GENERAL_QUERY, Level.Info, true,
                tr("Mere paas aapki $relWord ka profile saved nahi hai. Bol dijiye: \"Ye meri $relWord hain, naam ... hai\".", "I don't have your $relWord saved. Say: \"This is my $relWord, name is ...\"."),
                { "" }) { p -> tr("Aapne bataya tha ki ${poss(RelationshipType.find(relWord)?.label ?: relWord)} $relWord ka naam ${p.person.name} hai.", "You told me your $relWord's name is ${p.person.name}.") }
        }
        (qMem1.find(n)?.takeIf { listOf("yaad", "batao", "bata", "btao").any { w -> n.contains(w) } } ?: qMem2.find(n))?.let { m ->
            val q = cleanName(m.groupValues[1]) ?: m.groupValues[1]
            return personFlow(q, Cat.SETTINGS_COMMAND, Level.Info, true, notFoundMsg(q), { "" }) { p -> describe(p) }
        }
        (qMood1.find(n) ?: qMood2.find(n))?.let { m ->
            val q = cleanName(m.groupValues[1]) ?: return@let
            personFlow(q, Cat.GENERAL_QUERY, Level.Info, true, null, { "" }) { p -> moodAnswer(p) }?.let { return it }
        }

        // forget a person
        (qForget1.find(n) ?: qForget2.find(n))?.let { m ->
            val q = m.groupValues[1].trim().removePrefix("meri ").removePrefix("mera ").removePrefix("mere ")
            if (q !in setOf("that", "this", "it", "everything", "all") && cleanName(q.replace(Regex("^(?:meri|mera|mere|my) "), "")) != null || RelationshipType.find(q) != null) {
                val notFound = if (qForget1.containsMatchIn(n)) notFoundMsg(q) else null
                personFlow(q, Cat.SETTINGS_COMMAND, Level.Sensitive, false, notFound,
                    { p -> tr("${p.person.name} ki saari yaad delete kar du?", "Delete everything I remember about ${p.person.name}?") }) { p ->
                    pm.blocking { pm.forgetPerson(p.person.personId) }
                    tr("Ho gaya. ${p.person.name} ke baare mein ab kuch yaad nahi hai.", "Done. I no longer remember anything about ${p.person.name}.")
                }?.let { return it }
            }
        }

        // actions on people (message / call / talk)
        (qMsg1.find(n) ?: qMsg2.find(n))?.let { m ->
            personFlow(m.groupValues[1].trim(), Cat.LOCAL_DEVICE_COMMAND, Level.Sensitive, false, null,
                { p -> tr("${p.person.name} ko message likhne ke liye message app khol dun?", "Open the message composer for ${p.person.name}?") }) { p ->
                val num = device.findNumber(p.person.name)
                (if (num == null) tr("Contacts mein ${p.person.name} ka number nahi mila. ", "I couldn't find ${p.person.name}'s number in Contacts. ") else "") + device.openSms(num)
            }?.let { return it }
        }
        (qCall1.find(n) ?: qCall2.find(n))?.let { m ->
            personFlow(m.groupValues[1].trim(), Cat.LOCAL_DEVICE_COMMAND, Level.Sensitive, false, null,
                { p -> tr("${p.person.name} ko call lagau?", "Should I call ${p.person.name}?") }) { p ->
                val num = device.findNumber(p.person.name)
                if (num != null) device.openDialer(num) else tr("Contacts mein ${p.person.name} ka number nahi mila. ", "I couldn't find ${p.person.name}'s number in Contacts. ") + device.openDialer(null)
            }?.let { return it }
        }
        qTalk.find(n)?.let { m ->
            personFlow(m.groupValues[1].trim(), Cat.SETTINGS_COMMAND, Level.Info, true, null, { "" }) { p ->
                val ctx = if (p.person.lastContext.isNotBlank()) tr(" Pichli baar ${p.person.lastContext} ke baare mein baat hui thi.", " Last time we talked about ${p.person.lastContext}.") else ""
                tr("${p.person.name} ${poss(p.person.relLabel)} ${rel(p)} hain.$ctx Call karun ya message?", "${p.person.name} is your ${rel(p)}.$ctx Call or message?")
            }?.let { return it }
        }

        // context: "Rahul ke saath main gaming karta hoon"
        val ctx = qCtx1.find(n)?.let { it.groupValues[1] to it.groupValues[2] } ?: qCtx2.find(n)?.let { it.groupValues[3] to (it.groupValues[1] + " " + it.groupValues[2]) }
        if (ctx != null) {
            val q = cleanName(ctx.first)
            if (q != null && pm.resolver.resolve(q) !is Resolution.None) {
                val topic = ctx.second.trim()
                personFlow(q, Cat.SETTINGS_COMMAND, Level.Info, false, null, { "" }) { p ->
                    if (!prefs.peopleLearn || !prefs.memoryEnabled) tr("People learning band hai, isliye ye save nahi kiya.", "People learning is off, so I didn't save that.")
                    else { pm.blocking { pm.addContext(p.person.personId, topic, today = false) }
                        tr("Samajh gayi. ${p.person.name} ke context mein $topic ko conversation context ke roop mein use kar sakti hoon.", "Got it. I can use $topic as conversation context for ${p.person.name}.") }
                }?.let { return it }
            }
        }

        // nicknames: "Rahul ko main Rahu bulata hoon"
        (nick1.find(n) ?: nick2.find(n))?.let { m ->
            val q = m.groupValues[1]; val nick = m.groupValues[2]
            if (nick !in common && q !in common) personFlow(q, Cat.SETTINGS_COMMAND, Level.Info, false, null, { "" }) { p ->
                if (!prefs.peopleLearn) tr("People learning band hai, isliye ye save nahi kiya.", "People learning is off, so I didn't save that.")
                else { pm.blocking { pm.setNickname(p.person.personId, nick) }
                    tr("Theek hai, ${p.person.name} ko ab \"${capName(nick)}\" naam se bhi samjhungi.", "Okay, I'll now understand \"${capName(nick)}\" as ${p.person.name}.") }
            }?.let { return it }
        }

        // introductions: "Ye mera dost Rahul hai"
        parseIntro(n)?.let { (name, rt) ->
            return r(Cat.SETTINGS_COMMAND, tag = "basic") {
                if (!prefs.peopleLearn || !prefs.memoryEnabled) tr("People auto-save band hai. People & Memory screen se add kar sakte hain.", "Auto-save for people is off. You can add them in People & Memory.")
                else when (val o = pm.blocking { pm.introduce(name, rt) }) {
                    is IntroOutcome.Created -> tr("Okay, $name ${poss(rt.label)} ${rt.label.lowercase()} hain. Maine ye yaad rakh liya. Galat ho to \"$name ko bhool jao\" bol dena.",
                        "Okay, $name is your ${rt.label.lowercase()}. I saved that. If it's wrong, say \"forget $name\".")
                    is IntroOutcome.Duplicate -> tr("$name pehle se ${poss(rt.label)} ${rt.label.lowercase()} ke roop mein saved hain. Duplicate nahi banaya.", "$name is already saved as your ${rt.label.lowercase()}. I didn't create a duplicate.")
                    is IntroOutcome.Updated -> tr("$name ko ab ${rt.label.lowercase()} ke roop mein update kar diya.", "I updated $name to ${rt.label.lowercase()}.")
                    is IntroOutcome.NeedsMerge -> {
                        val ex = o.existing
                        hooks.clarify(Clarification(tr("$name pehle se saved hai (${ex.person.relLabel}). Kya ye wahi hai?", "$name is already saved (${ex.person.relLabel}). Is this the same person?"), listOf(
                            tr("Haan, wahi hai (relation update karo)", "Yes, same person (update relationship)") to {
                                pm.blocking { pm.setRelationship(ex.person.personId, rt) }; tr("Theek hai, $name ab ${rt.label}.", "Okay, $name is now ${rt.label}.") },
                            tr("Nahi, alag $name hai", "No, a different $name") to {
                                pm.blocking { pm.introduce(name, rt, force = true) }; tr("Okay, naya $name (${rt.label}) alag se save kiya.", "Okay, saved a separate $name (${rt.label}).") },
                            tr("Cancel", "Cancel") to { tr("Theek hai, kuch nahi badla.", "Okay, nothing changed.") }
                        )))
                        tr("$name pehle se saved hai (${ex.person.relLabel}). Kya ye wahi hai, ya alag?", "$name is already saved (${ex.person.relLabel}). Same person or a different one?")
                    }
                }
            }
        }
        return null
    }

    fun dateText(ms: Long): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(ms)
}
