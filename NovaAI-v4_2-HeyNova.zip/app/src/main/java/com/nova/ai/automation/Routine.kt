package com.nova.ai.automation

/** trigger: TIME_DAILY (trigValue "HH:mm") | TIME_ONCE (fireAt) | BATTERY_LOW (trigValue threshold %) | BT_CONNECTED (trigValue device-name part or blank)
 *  action: NOTIFY (actValue = text) | OFFER_APP (actValue = package; user taps the notification to open it). Nothing runs silently. */
data class Routine(
    val id: Long, val name: String, val trigger: String, val trigValue: String, val action: String, val actValue: String,
    val enabled: Boolean, val repeat: Boolean, val fireAt: Long, val createdAt: Long, val lastFired: Long
)
