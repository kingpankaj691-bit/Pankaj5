package com.nova.ai.suite

import android.content.Context
import android.os.PowerManager
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Live OCR: starts when you say so ("live OCR on", optionally "... Hindi mein") and then keeps itself running until you say stop.
 * It reads the screen every few seconds (accessibility text first, on-device OCR frames when Screen Vision is on), updates the
 * overlay sheet only when the text actually changed, slows down while nothing changes and pauses while the screen is off.
 * With a language it also translates changed text with the selected model, at most once every 4 seconds.
 * Plain Live OCR never uploads anything. The choice is remembered, so it resumes when Nova's voice service starts again.
 */
object LiveOcr {
    private const val PREF_ON = "live_ocr_on"
    private const val PREF_LANG = "live_ocr_lang"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    @Volatile var running = false
        private set
    @Volatile var target: String? = null
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)

    /** Lines of [raw] that are not already in [skip] (our own sheet text seen again by OCR). Pure, unit-tested. */
    fun freshText(raw: String, skip: Set<String>): String =
        raw.lines().map { it.trim() }.filter { it.isNotBlank() && it.lowercase() !in skip }.joinToString("\n")

    fun lineSet(text: String): Set<String> = text.lines().map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()

    fun start(ctx: Context, lang: String?): String {
        val app = ctx.applicationContext
        if (!Features.enabled(app, Features.VISION)) return Features.off("Vision & OCR")
        if (!NovaSheet.canShow(app)) return SystemControls.openOverlay(app)
        cancelLoop()
        prefs(app).edit().putBoolean(PREF_ON, true).putString(PREF_LANG, lang ?: "").apply()
        running = true; target = lang
        NovaSheet.show(app, if (lang == null) "Live OCR" else "Live OCR → $lang", "Waiting for text on the screen…", true,
            listOf(SheetAction("Stop Live OCR", true) { stop(app) }))
        job = scope.launch { loop(app) }
        FloatingOrb.current?.refresh()
        return "Live OCR chalu. Screen ka text badalte hi yahan dikhega" + (if (lang != null) " aur $lang mein translate hoga" else "") +
            ". Band karne ke liye bolein: live OCR band karo."
    }

    /** Stops the loop. [forget] = false keeps the saved "on" choice (used when the voice service shuts down). */
    fun stop(ctx: Context, forget: Boolean = true): String {
        val app = ctx.applicationContext
        cancelLoop()
        if (forget) prefs(app).edit().putBoolean(PREF_ON, false).apply()
        running = false; target = null
        NovaSheet.hide()
        FloatingOrb.current?.refresh()
        return "Live OCR band."
    }

    /** Called when Nova's voice service starts: continues Live OCR if you left it on and overlay access is still allowed. */
    fun resumeIfEnabled(ctx: Context) {
        val p = prefs(ctx)
        if (running || !p.getBoolean(PREF_ON, false) || !NovaSheet.canShow(ctx)) return
        start(ctx, p.getString(PREF_LANG, "")?.ifBlank { null })
    }

    /** Called by NovaSheet when the sheet goes away. If Live OCR is still running (sheet closed from outside), stop the loop but keep the saved choice. */
    fun onSheetClosed() {
        if (!running) return
        cancelLoop()
        running = false; target = null
        FloatingOrb.current?.refresh()
    }

    private fun cancelLoop() { job?.cancel(); job = null }

    private suspend fun loop(ctx: Context) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        var lastNorm = ""
        var skip: Set<String> = emptySet()
        var lastAi = 0L
        var warnedNoAi = false
        val base = PerfProfile.ocrBaseMs(ctx); val maxWait = PerfProfile.ocrMaxMs(ctx)
        var wait = base
        while (currentCoroutineContext().isActive) {
            if (!pm.isInteractive) { delay(4000); continue }
            val read = try { ScreenTools.readNow() } catch (e: Exception) { "" to "" }
            val text = freshText(read.second, skip)
            val norm = text.lowercase().filter { it.isLetterOrDigit() }
            if (norm.isNotBlank() && norm != lastNorm) {
                val lang = target
                if (lang == null) {
                    lastNorm = norm; wait = base
                    skip = lineSet(text)
                    NovaSheet.update(text.take(6000), false)
                } else {
                    val since = System.currentTimeMillis() - lastAi
                    if (since < 4000) { delay(4000 - since); continue }
                    val p = Prefs(ctx)
                    if (!ScreenTools.aiReady(p)) {
                        lastNorm = norm
                        skip = lineSet(text)
                        NovaSheet.update((if (!warnedNoAi) "Translation needs an API key, AI on and local-only off. Showing the text instead.\n\n" else "") + text.take(6000), false)
                        warnedNoAi = true
                    } else {
                        lastAi = System.currentTimeMillis()
                        NovaSheet.update(text.take(300) + "\n…", true)
                        val sys = "Detect the source language automatically and translate the text into $lang. Keep it short and natural. Ignore UI noise (time, battery, icons). Output only the translation."
                        val r = SwitchingProvider(p).chat(listOf(true to AppContext.buildPrompt(read.first, "Translate to $lang", text.take(3000))), sys, null)
                        val out = when (r) { is AiResult.Ok -> r.text.trim(); is AiResult.Err -> "⚠ " + r.msg }
                        lastNorm = norm
                        skip = lineSet(text) + lineSet(out)
                        NovaSheet.update(out, false)
                    }
                    wait = base
                }
            } else wait = minOf(wait + 500L, maxWait)
            delay(wait)
        }
    }
}
