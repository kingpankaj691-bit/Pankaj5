package com.nova.ai.control

/** A device operation Nova can perform through the unified control engine. */
sealed class ControlOp(val key: String) {
    data class Brightness(val pct: Int?, val delta: Int?) : ControlOp("brightness")
    data class Volume(val pct: Int?, val delta: Int?) : ControlOp("volume")
    data class Torch(val on: Boolean) : ControlOp("torch")
    data class Wifi(val on: Boolean) : ControlOp("wifi")
    data class Bluetooth(val on: Boolean) : ControlOp("bluetooth")
    data class Dnd(val on: Boolean) : ControlOp("dnd")
    data class AutoRotate(val on: Boolean) : ControlOp("rotation")
    data class ScreenTimeout(val seconds: Int) : ControlOp("screen_timeout")
    /** loose = phrased like "close X" / "X band kar do"; only claimed when X is exactly an installed app name. */
    data class ForceStop(val query: String, val loose: Boolean = false) : ControlOp("force_stop")
    /** Uninstall through Android's own confirmation screen only. */
    data class Uninstall(val query: String) : ControlOp("uninstall")
    /** Install an APK from the phone's files through Android's own installer screen. Blank query = the newest APK. */
    data class InstallApk(val query: String) : ControlOp("install_apk")
    data class Key(val name: String) : ControlOp("key")
    object Battery : ControlOp("battery")
    object Storage : ControlOp("storage")
    object DeviceInfo : ControlOp("device_info")
    object ShizukuStatusOp : ControlOp("shizuku_status")
    object ControlStatus : ControlOp("control_status")
}

/** Understands English, Hindi (Roman) and Hinglish phrasing for system operations. Pure Kotlin so it is unit-testable. */
object OpParser {
    private val up = listOf("badha", "badhao", "badhaa", "zyada", "jyada", "increase", "raise", "higher", "up", "more", "tez", "full", "max", "maximum", "high")
    private val down = listOf("kam", "ghata", "ghatao", "decrease", "lower", "reduce", "down", "less", "dim", "dheema", "min", "minimum", "low", "dhima")
    private val onW = listOf(" on", "chalu", "start", "enable", "jala", "kholo", "khol do", "activate", "laga")
    private val offW = listOf(" off", "band", "bandh", "disable", "bujha", "hata", "stop", "deactivate", "kar do band")

    private fun any(t: String, w: List<String>) = w.any { x -> Regex("(^|[^a-z])${Regex.escape(x.trim())}([^a-z]|$)").containsMatchIn(t) }
    /** "how do I uninstall apps?" is a question, not a command. */
    private val question = Regex("\\b(how|kaise|kya|can|cant|why|what|kyun)\\b")
    private fun wantsOff(t: String) = any(t, offW)
    private fun wantsOn(t: String) = any(t, onW)

    private fun pct(t: String): Int? = Regex("(\\d{1,3})\\s*(%|percent|pratishat|prtshat)").find(t)?.groupValues?.get(1)?.toIntOrNull()
        ?: Regex("(?:to|par|pe|set|kar do)\\s+(\\d{1,3})\\b").find(t)?.groupValues?.get(1)?.toIntOrNull()

    fun parse(raw: String): ControlOp? {
        val t = " " + raw.lowercase().trim().removePrefix("hey nova").removePrefix("nova").trim(' ', ',', '.', '!', '?') + " "
        fun has(vararg w: String) = w.any { t.contains(it) }

        Regex("^\\s*(?:please\\s+)?(?:uninstall|delete the app|remove the app|app uninstall|app delete)\\s+(?:the\\s+)?(?:app\\s+)?(.{2,40}?)(?:\\s+app)?\\s*$").find(t)?.let { m ->
            val q = m.groupValues[1].trim()
            if (q.isNotBlank() && !question.containsMatchIn(q)) return ControlOp.Uninstall(q)
        }
        Regex("^\\s*(.{2,40}?)\\s+(?:app\\s+)?(?:ko\\s+)?uninstall\\s*(?:kar|karo|kar do|kardo)?\\s*$").find(t)?.let { m ->
            val q = m.groupValues[1].trim().removeSuffix(" app").trim()
            if (q.isNotBlank() && q != "please" && !question.containsMatchIn(q)) return ControlOp.Uninstall(q)
        }
        Regex("^\\s*install\\s+(?:the\\s+)?apk\\b(?:\\s+file)?(?:\\s+(?:named|called))?\\s*(.{0,40}?)\\s*$").find(t)?.let { m -> return ControlOp.InstallApk(m.groupValues[1].trim().removePrefix("of ").trim()) }
        Regex("^\\s*(?:(.{2,40}?)\\s+)?apk\\s+install\\s*(?:kar|karo|kar do|kardo)?\\s*$").find(t)?.let { m -> return ControlOp.InstallApk(m.groupValues[1].trim()) }
        if (has("shizuku") && has("status", "check", "connected", "chal raha", "kaisa", "hai kya", "working")) return ControlOp.ShizukuStatusOp
        if (has("advanced control", "system control status", "control dashboard", "kya kya control", "what can you control")) return ControlOp.ControlStatus

        if (has("brightness", "brightnes", "chamak", "screen light")) {
            val p = pct(t)
            if (p != null) return ControlOp.Brightness(p.coerceIn(1, 100), null)
            if (has("full", "max", "maximum")) return ControlOp.Brightness(100, null)
            if (any(t, listOf("min", "minimum", "lowest"))) return ControlOp.Brightness(5, null)
            if (any(t, down)) return ControlOp.Brightness(null, -20)
            if (any(t, up)) return ControlOp.Brightness(null, 20)
            return null
        }
        if (has("wifi", "wi-fi", "wai fai") && !has("settings", "status", "connect to", "password", "network name")) {
            if (wantsOff(t)) return ControlOp.Wifi(false)
            if (wantsOn(t)) return ControlOp.Wifi(true)
        }
        if (has("bluetooth", "blutooth", "bluetoth") && !has("settings", "scan", "devices", "connected", "nearby", "dhoondo")) {
            if (wantsOff(t)) return ControlOp.Bluetooth(false)
            if (wantsOn(t)) return ControlOp.Bluetooth(true)
        }
        if (has("auto rotate", "auto-rotate", "autorotate", "rotation", "screen rotate", "rotate lock")) {
            if (wantsOff(t) || has("lock")) return ControlOp.AutoRotate(false)
            if (wantsOn(t) || has("unlock")) return ControlOp.AutoRotate(true)
        }
        if (has("screen timeout", "screen off time", "screen band hone", "sleep time", "display timeout", "screen timer")) {
            val m = Regex("(\\d+)\\s*(second|sec|minute|min|mins|minutes|seconds|ghante|hour)").find(t)
            if (m != null) {
                val n = m.groupValues[1].toInt()
                val s = when { m.groupValues[2].startsWith("s") -> n; m.groupValues[2].startsWith("m") -> n * 60; else -> n * 3600 }
                return ControlOp.ScreenTimeout(s.coerceIn(5, 1800))
            }
            return null
        }
        if (has("battery", "charge kitna", "charging kitni") && has("kitni", "kitna", "status", "level", "percent", "how much", "check", "info", "?")) return ControlOp.Battery
        if (has("storage", "memory kitni", "space kitna", "jagah kitni") && has("kitni", "kitna", "status", "left", "free", "how much", "check", "info", "?")) return ControlOp.Storage
        if (has("device info", "phone info", "phone ki jankari", "about my phone", "mere phone ke baare")) return ControlOp.DeviceInfo

        Regex("(?:force stop|force-stop|kill|band kar|close|kill kar)\\s+(?:the\\s+)?(?:app\\s+)?([a-z0-9 .]{2,40}?)(?:\\s+app)?\\s*$").find(t.trim())?.let { m ->
            val q = m.groupValues[1].trim()
            if (q.isNotBlank() && has("force stop", "force-stop", "kill")) return ControlOp.ForceStop(q)
        }
        Regex("^\\s*(?:close|band kar do|band karo)\\s+(.{2,30}?)\\s*(?:app)?\\s*$").find(t)?.let { m ->
            val q = m.groupValues[1].trim()
            if (q.isNotBlank() && !has("wifi", "bluetooth", "screen", "flashlight", "torch", "brightness", "dnd", "rotation")) return ControlOp.ForceStop(q, loose = true)
        }
        Regex("^\\s*(.{2,30}?)\\s+(?:ko\\s+)?band\\s+(?:kar|karo)\\s*(?:do|dijiye|de)?\\s*$").find(t.trim())?.let { m ->
            val q = m.groupValues[1].trim().removeSuffix(" app").trim()
            if (q.isNotBlank() && !has("wifi", "bluetooth", "screen", "flashlight", "torch", "brightness", "dnd", "rotation", "music", "gaana", "song")) return ControlOp.ForceStop(q, loose = true)
        }
        return null
    }
}
