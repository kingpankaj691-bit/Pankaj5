package com.nova.ai.ai.model

import com.nova.ai.ai.net.GeminiError
import com.nova.ai.ai.net.GeminiErrorKind

/** How Nova's voice works for the model the user selected. Decided from the model's capabilities, never assumed. */
sealed class VoiceRoute {
    abstract val modelId: String

    /** The selected model itself holds the conversation over the Gemini Live API. */
    data class NativeLive(override val modelId: String, val modality: LiveModality = LiveModality.AUDIO) : VoiceRoute()

    /** Microphone -> speech-to-text -> the selected model (generateContent) -> text-to-speech. The model is still the one selected. */
    data class Fallback(override val modelId: String, val reason: String) : VoiceRoute()

    /** The selected model cannot produce answers at all (for example a text-to-speech or embedding model). */
    data class Unavailable(override val modelId: String, val reason: String) : VoiceRoute()

    fun describe(): String = when (this) {
        is NativeLive -> "Native Gemini Live · $modelId"
        is Fallback -> "Speech-to-Text → $modelId → Text-to-Speech"
        is Unavailable -> "Unavailable: $reason"
    }
}

object ModelRouter {

    /**
     * @param model the model-list entry, or null when it is not in the list (offline, or a custom id): the id alone is used then.
     * @param learnedNoNative the Live API already refused this model's audio output once (error 1007).
     * @param preferNative when false, a model that supports both generateContent and Live still uses the fallback pipeline.
     */
    fun route(modelId: String, model: GeminiModel?, learnedNoNative: Boolean = false, preferNative: Boolean = true): VoiceRoute {
        val caps = model?.caps ?: ModelClassifier.classify(modelId, emptySet(), known = false)
        val native = caps.nativeLive && !learnedNoNative
        return when {
            native && (preferNative || !caps.chatCapable) -> VoiceRoute.NativeLive(modelId, LiveModality.AUDIO)
            caps.chatCapable -> VoiceRoute.Fallback(
                modelId,
                when {
                    caps.nativeLive && learnedNoNative -> "The Live API refused this model's audio output."
                    caps.nativeLive -> "Native Live is switched off in Settings."
                    else -> "This model does not support the Gemini Live API."
                }
            )
            caps.transcription -> VoiceRoute.Unavailable(modelId, "$modelId only transcribes speech. It is used for speech recognition automatically; it cannot answer.")
            caps.tts -> VoiceRoute.Unavailable(modelId, "$modelId only turns text into speech. It cannot answer questions.")
            caps.nativeLive -> VoiceRoute.Unavailable(modelId, "$modelId is a Live-only model and the Live API refused it.")
            else -> VoiceRoute.Unavailable(modelId, "$modelId cannot generate text answers.")
        }
    }

    /** Null when [modelId] may be used for typed chat; otherwise the reason (never a silent switch to another model). */
    fun chatProblem(modelId: String, model: GeminiModel?): GeminiError? {
        val caps = model?.caps ?: return null            // unknown ids are tried; the API answers 404 if they do not exist
        if (caps.chatCapable) return null
        val why = when {
            caps.nativeLive -> "it is a Live-voice-only model (it has no text generateContent method)"
            caps.transcription -> "it only transcribes speech"
            caps.tts -> "it only turns text into speech"
            caps.kind == ModelKind.IMAGE -> "it generates images"
            caps.kind == ModelKind.EMBEDDING -> "it creates embeddings"
            else -> "it does not support generateContent"
        }
        return GeminiError(GeminiErrorKind.MODEL_UNSUPPORTED, detail = "it can't answer chat messages because $why", model = modelId)
    }

    /** Which Live model does speech recognition. Prefers the user's choice when it really is a transcription model. */
    fun pickTranscription(preferred: String, models: List<GeminiModel>, defaultId: String): String? {
        val p = preferred.lowercase().removePrefix("models/")
        if (p.contains("transcribe")) return p
        val fromList = models.firstOrNull { it.caps.transcription }?.id
        if (fromList != null) return fromList
        return if (models.isEmpty()) defaultId else null
    }
}

/** What a Live error message means for the modality. */
object LiveModalityPolicy {
    /** Modality to request: a previously learned one wins, then the model's capability, then AUDIO. */
    fun modalityFor(modelId: String, model: GeminiModel?, learned: LiveModality?): LiveModality =
        learned ?: (model?.caps ?: ModelClassifier.classify(modelId, emptySet(), known = false)).liveModality ?: LiveModality.AUDIO

    /** The server closes the socket with 1007 and "The requested combination of response modalities (TEXT) is not supported...". */
    fun isModalityRejection(closeCode: Int?, reason: String): Boolean {
        val r = reason.lowercase()
        if (!r.contains("modalit")) return false
        return closeCode == 1007 || closeCode == 400 || r.contains("not supported") || r.contains("unsupported") || r.contains("invalid")
    }

    /** The modality named in the server's message, e.g. "(TEXT)" -> TEXT. */
    fun triedModality(reason: String): LiveModality? {
        val m = Regex("\\((TEXT|AUDIO)[^)]*\\)", RegexOption.IGNORE_CASE).find(reason) ?: return null
        return if (m.groupValues[1].equals("TEXT", true)) LiveModality.TEXT else LiveModality.AUDIO
    }
}
