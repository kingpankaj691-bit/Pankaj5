package com.nova.ai.plugins

import android.content.Context

data class PluginInfo(val id: String, val name: String, val description: String, val implemented: Boolean)

/** Independently switchable feature modules. Unimplemented ones are listed but disabled until a real module exists. */
class PluginRegistry(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova_plugins", Context.MODE_PRIVATE)
    val all = listOf(
        PluginInfo("reminders", "Reminders", "Timed reminders and routines via WorkManager notifications.", true),
        PluginInfo("notes", "Notes", "Quick local notes. Say \"note: ...\".", true),
        PluginInfo("study_mode", "Study mode", "\"Switch to study mode\" selects the Study personality.", true),
        PluginInfo("gaming_mode", "Gaming mode", "\"Switch to gaming mode\" selects the Gaming personality.", true),
        PluginInfo("calendar", "Calendar", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("weather", "Weather", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("music", "Music control", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("smart_home", "Smart home", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("pc_control", "PC control", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("translation", "Translation", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("image_understanding", "Image understanding", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("camera_assistant", "Camera assistant", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("document_assistant", "Document assistant", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("travel_mode", "Travel mode", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("productivity_mode", "Productivity mode", "Ready. Voice commands and the Tools screen use it.", true),
        PluginInfo("multi_device", "Multi-device assistant", "Ready. Voice commands and the Tools screen use it.", true)
    )
    fun isEnabled(id: String): Boolean = all.firstOrNull { it.id == id }?.let { it.implemented && sp.getBoolean(id, true) } ?: false
    fun setEnabled(id: String, on: Boolean) { sp.edit().putBoolean(id, on).apply() }
}
