package com.nova.ai.commands

import com.nova.ai.NovaApp
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.security.Prefs
import com.nova.ai.security.SecurityAlarmManager
import com.nova.ai.security.SecurityEvents
import com.nova.ai.security.SecurityModeManager
import com.nova.ai.vision.VisionRequest
import com.nova.ai.vision.VisionRequests
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Part 3 commands: Security Mode, the alarm, camera vision, gesture mode and "what can I tap".
 * Turning Security Mode off or silencing the alarm are Sensitive, so Owner Mode can require fingerprint or screen lock for them.
 * Camera requests only open Nova's Camera screen; the camera starts there, in view, never in the background.
 */
class SecurityVisionCommands(private val prefs: Prefs) {
    private val ctx get() = NovaApp.instance
    private val onRe = Regex("\\b(on|chalu|enable|activate|start|shuru)\\b")
    private val offRe = Regex("\\b(off|band|disable|deactivate|stop|khatam)\\b")

    private fun cmd(cat: Cat, level: Level = Level.Info, prompt: String = "", tag: String = "", sensitive: Boolean = false, run: () -> String) =
        CmdResult(true, cat, prompt, level, run, tag, sensitive)

    private fun openCamera(req: VisionRequest, say: String): String {
        val nav = UiBridge.navigate ?: return "Open Nova and ask again. The camera only runs while Nova's Camera screen is open."
        VisionRequests.set(req)
        nav(UiBridge.TAB_VISION)
        return say
    }

    fun route(raw: String, t: String): CmdResult? {
        fun has(vararg w: String) = w.any { t.contains(it) }
        val on = onRe.containsMatchIn(t)
        val off = offRe.containsMatchIn(t)
        val toggle: Boolean? = if (on == off) null else on

        // ── security ──
        if (has("test alarm", "alarm test", "security alarm test"))
            return cmd(Cat.SETTINGS_COMMAND, Level.Action, "Play the security alarm for a few seconds?") {
                SecurityAlarmManager.get(ctx).trigger(prefs, test = true); "Testing the alarm for 5 seconds."
            }
        if (has("stop alarm", "stop the alarm", "alarm band karo", "alarm stop", "silence alarm"))
            return cmd(Cat.SETTINGS_COMMAND, Level.Sensitive, "Stop the security alarm?", tag = "security") {
                SecurityAlarmManager.get(ctx).stop(); "Alarm stopped."
            }
        if (has("security event", "security log", "security history"))
            return cmd(Cat.GENERAL_QUERY, tag = "security", sensitive = true) {
                val list = SecurityEvents.list(prefs).take(5)
                if (list.isEmpty()) "No security events recorded."
                else "Recent security events: " + list.joinToString("; ") { SimpleDateFormat("d MMM h:mm a", Locale.getDefault()).format(Date(it.at)) + " " + it.kind + ", " + it.detail }
            }
        if (has("security mode", "motion alert", "pickup alert", "pick-up alert", "pick up alert", "anti theft", "anti-theft", "chor alarm")) {
            if (toggle == null) return cmd(Cat.GENERAL_QUERY, tag = "status") { SecurityModeManager.status(prefs) }
            return if (toggle) cmd(Cat.SETTINGS_COMMAND, Level.Action, "Turn on Security Mode? Nova will watch for movement and sound an alarm if the phone is moved.") {
                SecurityModeManager.arm(ctx, prefs)
            } else cmd(Cat.SETTINGS_COMMAND, Level.Sensitive, "Turn off Security Mode?", tag = "security") { SecurityModeManager.disarm(ctx, prefs) }
        }

        // ── camera vision ──
        if (has("camera mein kya", "camera me kya", "camera mai kya", "camera main kya", "kya dikh raha", "what is in front of", "what's in front of",
                "what do you see", "what is in the camera", "what's in the camera", "object batao", "kya hai saamne"))
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Open Nova's camera screen? The camera is on while that screen is open.", tag = "camera") {
                openCamera(VisionRequest.DESCRIBE, "Camera khol rahi hoon. Ek second, phir bataungi.")
            }
        if (has("text read", "read this text", "read the text", "is text ko", "text padho", "camera text", "ye text padho"))
            return cmd(Cat.SCREEN_COMMAND, Level.Action, "Open Nova's camera screen to read text? The camera is on while it is open.", tag = "camera") {
                openCamera(VisionRequest.READ_TEXT, "Camera khol rahi hoon. Text ke saamne phone steady rakhiye.")
            }
        if (has("gesture mode")) {
            if (toggle == null) return cmd(Cat.GENERAL_QUERY, tag = "status") { "Gesture mode is controlled on the Camera screen. Say \"gesture mode on\" to open it." }
            return if (toggle) cmd(Cat.SCREEN_COMMAND, Level.Action, "Open the camera screen and turn on gesture mode? The camera is on while it is open.", tag = "camera") {
                openCamera(VisionRequest.GESTURE_ON, "Gesture mode shuru. Haath dayen swipe karo: next, bayen: previous, dono taraf: play ya pause.")
            } else cmd(Cat.SETTINGS_COMMAND, tag = "basic") { "Gesture mode stops as soon as you leave Nova's Camera screen or tap Stop camera." }
        }

        // ── screen assistant ──
        if (has("what can i tap", "screen controls", "tappable", "kya kya click", "what can i click", "kya tap kar sakta"))
            return cmd(Cat.SCREEN_COMMAND, tag = "screen", sensitive = true) {
                NovaAccessibilityService.instance?.describeControls()
                    ?: "Screen access is off. Turn on Nova under Android Accessibility settings, then ask again."
            }
        return null
    }
}
