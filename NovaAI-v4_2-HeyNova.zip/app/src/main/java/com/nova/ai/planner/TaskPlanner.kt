package com.nova.ai.planner

import com.nova.ai.language.LanguageDetector
import com.nova.ai.screen.Dir

/**
 * Turns Hindi / Hinglish / English requests into ordered screen steps. Returns null for anything that is not a screen
 * task so the normal local router / Gemini path handles it.
 */
object TaskPlanner {
    private val verbLead = "open|kholo|khol|search|tap|click|press|scroll|swipe|type|likho|back|home|dhoondo|dhundo|play|chalao|neeche|niche|upar|first|pehla|pehle|double|long|select|is result|iss result|result|screen|recent|peeche"
    private val splitter = Regex("\\s*(?:,|;)\\s*|\\s+(?:aur|and|phir|fir|then|uske baad|uske bad|after that)\\s+(?=(?:$verbLead)\\b)", RegexOption.IGNORE_CASE)
    private val fillers = Regex("(?i)\\b(please|nova|hey nova|zara|jara|bas|ek baar|jaldi)\\b")

    private fun clean(s: String) = s.replace(fillers, " ").replace(Regex("\\s+"), " ").trim(' ', ',', '.', '!', '?', '"', '\'')
    private fun ordinal(s: String): Int = when {
        Regex("(?i)\\b(1|1st|first|pehla|pehle|pahla|ek)\\b").containsMatchIn(s) -> 1
        Regex("(?i)\\b(2|2nd|second|doosra|dusra|do)\\b").containsMatchIn(s) -> 2
        Regex("(?i)\\b(3|3rd|third|teesra|tisra|teen)\\b").containsMatchIn(s) -> 3
        Regex("(?i)\\b(4|4th|fourth|chautha|char)\\b").containsMatchIn(s) -> 4
        Regex("(?i)\\b(5|5th|fifth|paanchwa|panchva|paanch)\\b").containsMatchIn(s) -> 5
        else -> 0
    }

    fun plan(raw: String): Plan? {
        val text = clean(raw)
        if (text.isBlank()) return null
        val hinglish = LanguageDetector.detect(text).let { it.hinglish || it.tag == "hi-IN" }
        wholeSentence(text)?.let { return Plan(it, hinglish) }
        val clauses = text.split(splitter).map { clean(it) }.filter { it.isNotEmpty() }
        val steps = ArrayList<Step>()
        var appOpened = false
        var openedName = ""
        for (c in clauses) {
            val ss = expand(c, appOpened, openedName) ?: return null   // an unknown clause means this is not a pure screen task
            for (s in ss) {
                if (s is Step.OpenApp) { appOpened = true; openedName = s.name.lowercase() }
                if (s is Step.OpenBrowser) { appOpened = true; openedName = "browser" }
            }
            steps.addAll(ss)
        }
        if (steps.isEmpty()) return null
        // A lone "open <app>" is left to the normal app launcher so behaviour stays the same.
        if (steps.size == 1 && (steps[0] is Step.OpenApp || steps[0] is Step.OpenBrowser)) return null
        return Plan(steps, hinglish)
    }

    private const val YT = "(?:youtube|you tube|yt)"
    private const val BR = "(browser|google chrome|chrome|firefox|brave|edge|opera|samsung internet)"
    private const val PLAYV = "(?:play karo|play kar do|play kar|play|chalao|chala do|chalu karo|dekho)"
    private const val SEARCHV = "(?:search karo|search kar do|search kar|search|dhoondo|dhundo|dikhao)"
    private val playWords = Regex("^(?:play karo|play kar do|play kar|play|chalao|chala do|chalu karo|dekho)$")
    private val openFirst = Regex("\\s+(?:and|aur|phir|then)\\s+(?:open|kholo|khol)\\s+(?:the\\s+)?(?:first|pehla|1st)\\s+(?:result|link)(?:\\s+kholo)?$")

    private fun ytSteps(q: String, play: Boolean): List<Step> {
        val query = q.trim()
        if (query.isBlank()) return emptyList()
        val base = listOf<Step>(Step.OpenApp("youtube"), Step.SearchInApp(query))
        return if (play) base + listOf(Step.OpenResult(0), Step.VerifyPlayback) else base
    }

    private fun browserSteps(browser: String, q0: String): List<Step> {
        var q = q0.trim()
        var openFirstResult = false
        if (openFirst.containsMatchIn(q.lowercase())) { q = q.replace(openFirst, "").trim(); openFirstResult = true }
        if (q.isBlank()) return emptyList()
        val b = browser.lowercase()
        val name = if (b == "browser") null else browser
        val core = listOf<Step>(Step.OpenBrowser(name), Step.SearchInApp(q), Step.ReadResults)
        return if (openFirstResult) core.dropLast(1) + Step.OpenResult(1) else core
    }

    /**
     * Whole requests that name YouTube or a browser in one breath ("YouTube par X chalao", "play X on youtube",
     * "chrome me X search karo"). Returns the full open → search → (open result → verify playback) plan.
     */
    private fun wholeSentence(text: String): List<Step>? {
        val l = text.lowercase().trim()
        val o = IGNORE
        // YouTube: "open youtube and play/search X"
        Regex("^(?:open|launch|start)\\s+$YT\\s+(?:and|aur|phir|then)\\s+(play|search)(?:\\s+for)?\\s+(.+)$", o).find(l)?.let {
            return ytSteps(original(text, it.groupValues[2]), it.groupValues[1] == "play").ifEmpty { null }
        }
        // YouTube: "youtube kholo aur X chalao"
        Regex("^$YT\\s+(?:kholo|khol do|open karo|chalu karo)\\s+(?:aur|and|phir)\\s+(.+?)\\s+($PLAYV|$SEARCHV)$", o).find(l)?.let {
            return ytSteps(original(text, it.groupValues[1]), playWords.matches(it.groupValues[2])).ifEmpty { null }
        }
        // YouTube: "play X on youtube" / "search X on youtube"
        Regex("^(play|search)\\s+(.+?)\\s+(?:on|in|par|pe|me|mein)\\s+$YT$", o).find(l)?.let {
            return ytSteps(original(text, it.groupValues[2]), it.groupValues[1] == "play").ifEmpty { null }
        }
        // YouTube: "youtube par X search karo / play karo / chalao"
        Regex("^$YT\\s*(?:par|pe|me|mein|on)?\\s+(.+?)\\s+($PLAYV|$SEARCHV)$", o).find(l)?.let {
            return ytSteps(original(text, it.groupValues[1]), playWords.matches(it.groupValues[2])).ifEmpty { null }
        }
        // YouTube: "X ko youtube par chalao"
        Regex("^(.+?)\\s+(?:ko\\s+)?$YT\\s+(?:par|pe|me|mein)\\s+($PLAYV|$SEARCHV)$", o).find(l)?.let {
            return ytSteps(original(text, it.groupValues[1]), playWords.matches(it.groupValues[2])).ifEmpty { null }
        }
        // Browser: "open chrome and search X"
        Regex("^(?:open|launch|start)\\s+$BR\\s+(?:and|aur|phir|then)\\s+search(?:\\s+for)?\\s+(.+)$", o).find(l)?.let {
            return browserSteps(it.groupValues[1], original(text, it.groupValues[2])).ifEmpty { null }
        }
        // Browser: "chrome me X search karo"
        Regex("^$BR\\s*(?:me|mein|par|pe|on|in)\\s+(.+?)\\s+$SEARCHV$", o).find(l)?.let {
            return browserSteps(it.groupValues[1], original(text, it.groupValues[2])).ifEmpty { null }
        }
        // Browser: "search X on chrome"
        Regex("^search(?:\\s+for)?\\s+(.+?)\\s+(?:on|in|using|with)\\s+(?:the\\s+)?$BR$", o).find(l)?.let {
            return browserSteps(it.groupValues[2], original(text, it.groupValues[1])).ifEmpty { null }
        }
        // Browser: "X ko chrome me search karo"
        Regex("^(.+?)\\s+(?:ko\\s+)?$BR\\s+(?:me|mein|par|pe)\\s+$SEARCHV$", o).find(l)?.let {
            return browserSteps(it.groupValues[2], original(text, it.groupValues[1])).ifEmpty { null }
        }
        whatsappSteps(text, l)?.let { return it }
        return null
    }

    private val vagueMessage = setOf("message", "msg", "a message", "text", "kuch", "something", "ek message")
    private fun waClean(s: String) = s.trim().trim('"', '\'', '\u201c', '\u201d', '\u2018', '\u2019', ' ', ',', '.')

    private fun waSend(text: String, contact: String, message: String): List<Step>? {
        val c = waClean(contact).removeSuffix(" ko").removeSuffix(" to").trim()
        val m = waClean(message)
        if (c.isBlank() || m.isBlank() || m.lowercase() in vagueMessage) return null
        return listOf(Step.OpenApp("whatsapp"), Step.WhatsAppSend(original(text, c), original(text, m)))
    }

    private fun waOpen(text: String, contact: String): List<Step>? {
        val c = waClean(contact)
        return if (c.isBlank()) null else listOf(Step.OpenApp("whatsapp"), Step.WhatsAppOpenChat(original(text, c)))
    }

    /** WhatsApp requests. Sending is only ever PLANNED here; the runner shows recipient + text and asks before pressing Send. */
    private fun whatsappSteps(text: String, l: String): List<Step>? {
        if (!l.contains("whatsapp")) return null
        val o = IGNORE
        val sendVerbs = "(?:bhejo|bhej do|bhej dena|bhejna|send karo|send kar do|likho|likh do)"
        Regex("^(?:read|show|check)\\s+(?:my\\s+)?whatsapp\\s+(?:chats|messages)$", o).find(l)?.let { return listOf(Step.OpenApp("whatsapp"), Step.ReadWhatsApp) }
        Regex("^whatsapp\\s*(?:par|pe|me|mein)?\\s+(?:kaun se\\s+)?(?:chats|messages)\\s+(?:dikhao|batao|padho|read)$", o).find(l)?.let { return listOf(Step.OpenApp("whatsapp"), Step.ReadWhatsApp) }
        Regex("^(?:open|show)\\s+(.+?)(?:'s)?\\s+(?:chat|conversation)\\s+(?:on|in)\\s+whatsapp$", o).find(l)?.let { return waOpen(text, it.groupValues[1]) }
        Regex("^whatsapp\\s*(?:par|pe|me|mein)?\\s+(.+?)\\s+(?:ki|ka)\\s+chat\\s+(?:kholo|khol do|open karo|dikhao)$", o).find(l)?.let { return waOpen(text, it.groupValues[1]) }
        Regex("^open\\s+whatsapp\\s+(?:chat\\s+)?(?:with|of)\\s+(.+)$", o).find(l)?.let { return waOpen(text, it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:ki|ka)\\s+whatsapp\\s+chat\\s+(?:kholo|khol do|dikhao)$", o).find(l)?.let { return waOpen(text, it.groupValues[1]) }
        Regex("^(?:send|write)\\s+(?:a\\s+)?(?:whatsapp\\s+)?(?:message|msg|text)\\s+to\\s+(.+?)\\s+(?:on|via|in)\\s+whatsapp\\s*(?:saying|that says|that|:|-)?\\s*(.+)$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        Regex("^(?:send|write)\\s+(?:a\\s+)?whatsapp\\s+(?:message\\s+|msg\\s+)?to\\s+(.+?)\\s+(?:saying|that says|that|:|-)\\s*(.+)$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        Regex("^whatsapp\\s*(?:par|pe|me|mein|on)?\\s+(.+?)\\s+ko\\s+(.+?)\\s+$sendVerbs$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        Regex("^(.+?)\\s+ko\\s+whatsapp\\s*(?:par|pe|me|mein)?\\s+(?:message\\s+|msg\\s+)?(.+?)\\s+$sendVerbs$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        Regex("^(.+?)\\s+ko\\s+whatsapp\\s*(?:par|pe|me|mein)?\\s+(?:message|msg)\\s+bhejo\\s+(?:ki\\s+)?(.+)$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        Regex("^whatsapp\\s+(.+?)\\s+(?:saying|:)\\s+(.+)$", o).find(l)?.let { return waSend(text, it.groupValues[1], it.groupValues[2]) }
        return null
    }

    private val IGNORE = RegexOption.IGNORE_CASE
    private val browserWord = Regex("^(?:the |my )?(browser|google chrome|chrome|firefox|brave|edge|opera|samsung internet)$")

    /** One clause, possibly several steps (a YouTube "play" is search + open result + verify playback). */
    private fun expand(c: String, appOpened: Boolean, openedName: String): List<Step>? {
        val l = c.lowercase()
        if (appOpened && openedName.contains("youtube")) {
            Regex("^(?:play karo|play|chalao|chala do)\\s+(.+)$").find(l)?.let { return ytTail(original(c, it.groupValues[1])) }
            Regex("^(.+?)\\s+(?:play karo|play kar do|play kar|chalao|chala do)$").find(l)?.let { return ytTail(original(c, it.groupValues[1])) }
        }
        val s = parseClause(c, appOpened) ?: return null
        if (s is Step.OpenApp) {
            browserWord.find(s.name.lowercase())?.let { m ->
                val w = m.groupValues[1]
                return listOf(Step.OpenBrowser(if (w == "browser") null else w))
            }
        }
        return listOf(s)
    }

    private fun ytTail(q: String): List<Step>? =
        if (q.isBlank()) null else listOf(Step.SearchInApp(q.trim()), Step.OpenResult(0), Step.VerifyPlayback)

    private fun parseClause(c: String, appOpened: Boolean): Step? {
        val l = c.lowercase()

        // system navigation
        if (Regex("^(?:go back|back|peeche jao|peeche|wapas jao|back jao|back karo)$").matches(l)) return Step.Back
        if (Regex("^(?:go home|home|home screen|home par jao|home jao|home karo)$").matches(l)) return Step.Home
        if (Regex("^(?:recent apps?|recents?|open recent apps?|recent apps? kholo|recent apps? dikhao)$").matches(l)) return Step.Recents
        if (Regex("^(?:open |show )?(?:notification shade|notifications? panel|notification bar)(?: kholo)?$").matches(l)) return Step.Notifications

        // describe the screen is handled by the screen-question path, not here
        // scrolling
        if (Regex("(?:scroll down|scroll neeche|neeche scroll|niche scroll|neeche jao|niche jao|neeche karo|scroll karo neeche|page neeche)").containsMatchIn(l)) return Step.Scroll(true)
        if (Regex("(?:scroll up|scroll upar|upar scroll|upar jao|upar karo|page upar)").containsMatchIn(l)) return Step.Scroll(false)
        Regex("^(?:swipe|swipe karo)\\s+(left|right|up|down|upar|neeche|niche|baayen|daayen)").find(l)?.let { return Step.Swipe(dir(it.groupValues[1])) }
        Regex("^(left|right|up|down|upar|neeche|niche|baayen|daayen)\\s+(?:ki taraf\\s+)?swipe(?: karo)?$").find(l)?.let { return Step.Swipe(dir(it.groupValues[1])) }

        // results
        if (Regex("(?:result|video|link|item)").containsMatchIn(l) && Regex("(?:kholo|khol do|open|tap|play|chalao|click)").containsMatchIn(l)) {
            val first = Regex("(?:pehla|pehle|first|1st|doosra|dusra|second|2nd|teesra|third|3rd|chautha|fourth|4th|paanchwa|fifth|5th)").containsMatchIn(l)
            val num = Regex("(?:number|no\\.?|#)\\s*(\\d)").find(l)?.groupValues?.get(1)?.toIntOrNull()
            return Step.OpenResult(num ?: if (first) ordinal(l) else 0)
        }

        // long press / double tap
        Regex("^(?:long press|long-press|longpress|hold)\\s+(?:on\\s+)?(.+)$").find(l)?.let { return Step.LongPress(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:ko|par|pe|on)?\\s*(?:long press|long-press|dabaye rakho|dabake rakho|hold)(?: karo)?$").find(l)?.let { return Step.LongPress(it.groupValues[1]) }
        Regex("^(?:double tap|double-tap|doubletap)\\s+(?:on\\s+)?(.+)$").find(l)?.let { return Step.DoubleTap(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:ko|par|pe|on)?\\s*(?:double tap|double-tap|do baar tap)(?: karo)?$").find(l)?.let { return Step.DoubleTap(it.groupValues[1]) }

        // search in the open app
        Regex("^(?:search|find)\\s+(?:bar|box|field)?\\s*(?:mein|me|main|in|box mein|bar mein)\\s+(.+?)\\s+(?:likho|type karo|type kar|dalo|daalo|search karo|search kar|dekho|dhoondo|dhundo|likh do)$", RegexOption.IGNORE_CASE).find(c, 0)?.let { return Step.SearchInApp(it.groupValues[1].trim()) }
        Regex("^(?:search|find)\\s+(?:mein|me|main|in)\\s+(.+)$").find(l)?.let { return Step.SearchInApp(original(c, it.groupValues[1])) }
        Regex("^(?:search karo|search kar|search for|search)\\s+(.+)$").find(l)?.let { if (appOpened) return Step.SearchInApp(original(c, it.groupValues[1])) }
        Regex("^(.+?)\\s+(?:search karo|search kar do|search kar)$").find(l)?.let { if (appOpened) return Step.SearchInApp(original(c, it.groupValues[1])) }
        Regex("^(?:latest|new|top)?\\s*(.+?)\\s+(?:dekho|dikhao|chalao|play karo)$").find(l)?.let { if (appOpened && !l.contains("screen")) return Step.SearchInApp(original(c, it.groupValues[0].replace(Regex("(?i)\\s+(dekho|dikhao|chalao|play karo)$"), ""))) }

        // typing into a field
        Regex("^(?:type|likho)\\s+(.+)$").find(l)?.let { return Step.TypeInto(original(c, it.groupValues[1]), null) }
        Regex("^(?:isme|is mein|yahan|yaha|is field mein|field mein|box mein|message box mein|text box mein)\\s+(.+?)\\s+(?:likho|type karo|dalo|daalo|likh do)$").find(l)?.let { return Step.TypeInto(original(c, it.groupValues[1]), null) }

        // tapping
        Regex("^(?:tap|click|press|select|choose)\\s+(?:on\\s+)?(.+)$").find(l)?.let { return Step.Tap(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:ko|par|pe|on)?\\s*(?:tap|click|press|select|dabao|dabana|chuo|select karo|tap karo|click karo|press karo|dabao jee)(?: karo)?$").find(l)?.let { return Step.Tap(it.groupValues[1].replace(Regex("^(?:jo|woh|wo)\\s+"), "").replace(Regex("\\s+(?:hai|wala|wali)\\s*(?:usko|isko|use|ise)?$"), "").trim()) }
        Regex("^(?:jo|woh|wo)\\s+(.+?)\\s+hai\\s+(?:usko|isko|use|ise)\\s+(?:tap|click|dabao|press)(?: karo)?$").find(l)?.let { return Step.Tap(it.groupValues[1]) }

        // finding things on the screen
        Regex("^(?:screen|page|is page|iss page|is screen)\\s*(?:par|pe|mein|me|main|on|in)?\\s+(.+?)\\s+(?:dhoondo|dhundo|dhoondh|dikhao|find|batao|dekho)$").find(l)?.let { return Step.Find(it.groupValues[1]) }
        Regex("^(?:is page mein|iss page mein|is screen par|screen par|find on screen|find)\\s+(.+?)(?:\\s+(?:dhoondo|dhundo|dhoondh))?$").find(l)?.let { if (!it.groupValues[1].contains("internet")) return Step.Find(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:dhoondo|dhundo|dhoondh)(?:\\s+(?:is page mein|screen par|yahan))?$").find(l)?.let {
            val q = it.groupValues[1]
            if (Regex("(?i)\\b(button|option|icon|menu|tab|link|setting|settings|privacy|search|field|toggle|switch|checkbox)\\b").containsMatchIn(q) || l.contains("screen") || l.contains("is page") || l.contains("yahan")) return Step.Find(q)
        }

        // opening an app
        Regex("^(?:open|launch|start)\\s+(.+)$").find(l)?.let { return Step.OpenApp(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s+(?:kholo|khol do|kholiye|chalu karo|launch karo|open karo|khol)$").find(l)?.let { return Step.OpenApp(it.groupValues[1].trim()) }
        return null
    }

    private fun dir(w: String): Dir = when (w) {
        "left", "baayen" -> Dir.LEFT; "right", "daayen" -> Dir.RIGHT
        "up", "upar" -> Dir.UP; else -> Dir.DOWN
    }

    /** Take the text from the user's original casing (names, queries) instead of the lowercased copy. */
    private fun original(c: String, lowered: String): String {
        val i = c.lowercase().indexOf(lowered.lowercase())
        return if (i >= 0) c.substring(i, i + lowered.length).trim() else lowered.trim()
    }
}
