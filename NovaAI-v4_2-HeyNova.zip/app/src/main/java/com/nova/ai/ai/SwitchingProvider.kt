package com.nova.ai.ai

import com.nova.ai.core.AIProvider
import com.nova.ai.security.Prefs

/**
 * The one cloud provider the rest of Nova talks to. It re-reads Settings on every call, so switching Gemini <-> OpenAI
 * takes effect immediately without restarting the app or the voice service.
 */
class SwitchingProvider(
    private val prefs: Prefs,
    private val gemini: AIProvider = GeminiProvider(prefs),
    private val openai: AIProvider = OpenAIProvider(prefs)
) : AIProvider {

    override suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String?): AiResult =
        if (prefs.aiProvider == Prefs.PROVIDER_OPENAI) {
            if (!prefs.openAiEnabled) AiResult.Err("OpenAI is switched off in Settings.")
            else openai.chat(history, system, null)          // the Gemini model name is never sent to OpenAI
        } else {
            if (!prefs.geminiEnabled) AiResult.Err("Gemini is switched off in Settings.")
            else gemini.chat(history, system, model)
        }
}
