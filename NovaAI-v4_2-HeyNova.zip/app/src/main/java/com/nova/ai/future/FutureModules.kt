package com.nova.ai.future

/** Contracts for modules that are NOT built yet. No fake implementations: until one is registered, NOVA says it is unavailable. */
interface NovaModule { val id: String; val title: String }
interface ImageUnderstandingModule : NovaModule { suspend fun describe(image: ByteArray, question: String): String }
interface CameraAssistantModule : NovaModule { suspend fun analyze(photo: ByteArray, question: String): String }
interface DocumentModule : NovaModule { suspend fun summarize(uri: String, question: String): String }
interface PdfModule : NovaModule { suspend fun ask(uri: String, question: String): String }
interface TranslationModule : NovaModule { suspend fun translate(text: String, from: String?, to: String): String }
interface WeatherModule : NovaModule { suspend fun forecast(place: String?): String }
interface CalendarModule : NovaModule { suspend fun upcoming(days: Int): String }
interface ReminderModule : NovaModule { fun schedule(text: String, atMillis: Long): Boolean }
interface NotesModule : NovaModule { fun add(text: String); fun all(): List<String> }
interface MusicModule : NovaModule { fun play(query: String): Boolean; fun pause(): Boolean }
interface SmartHomeModule : NovaModule { suspend fun command(device: String, action: String): String }
interface PcControlModule : NovaModule { suspend fun send(command: String): String }
interface MultiDeviceModule : NovaModule { suspend fun forward(deviceName: String, command: String): String }
interface StudyAssistantModule : NovaModule { suspend fun quiz(topic: String): String }
interface GamingAssistantModule : NovaModule { suspend fun tip(game: String, question: String): String }
interface TravelAssistantModule : NovaModule { suspend fun plan(destination: String, days: Int): String }
interface ProductivityModule : NovaModule { suspend fun plan(goals: List<String>): String }

data class FutureModuleInfo(val id: String, val title: String)

object FutureModules {
    val all = listOf(
        FutureModuleInfo("image_understanding", "Image understanding"), FutureModuleInfo("camera_assistant", "Camera assistant"),
        FutureModuleInfo("document", "Document understanding"), FutureModuleInfo("pdf", "PDF assistant"),
        FutureModuleInfo("translation", "Translation"), FutureModuleInfo("weather", "Weather"), FutureModuleInfo("calendar", "Calendar"),
        FutureModuleInfo("reminders", "Reminders (advanced)"), FutureModuleInfo("music", "Music"), FutureModuleInfo("smart_home", "Smart home"),
        FutureModuleInfo("pc_control", "PC control"), FutureModuleInfo("multi_device", "Multi-device control"),
        FutureModuleInfo("study", "Study assistant"), FutureModuleInfo("gaming", "Gaming assistant"),
        FutureModuleInfo("travel", "Travel assistant"), FutureModuleInfo("productivity", "Productivity assistant")
    )
}

/** Register a real implementation here and look it up by id; absent = not available. */
object ModuleRegistry {
    private val map = HashMap<String, NovaModule>()
    fun register(m: NovaModule) { map[m.id] = m }
    @Suppress("UNCHECKED_CAST") fun <T : NovaModule> get(id: String): T? = map[id] as? T
    fun has(id: String) = map.containsKey(id)
}
