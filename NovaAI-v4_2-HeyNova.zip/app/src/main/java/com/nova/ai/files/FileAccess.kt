package com.nova.ai.files

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.nova.ai.control.ShizukuManager
import com.nova.ai.control.ShizukuStatus
import com.nova.ai.media.AllFiles

/** Version-specific rules, pure so they can be unit-tested. */
object FileAccessRules {
    /** What to ask in the runtime-permission dialog. On Android 14+ everything goes in ONE request so the system can offer "Select photos and videos". */
    fun permissionsToRequest(sdk: Int): List<String> = when {
        sdk >= 34 -> listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        sdk >= 33 -> listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    /**
     * Can Nova list ordinary folders by path (browse Download, Documents...)?
     * Android 11+: only with "All files access". Android 8-9: the old storage permission is enough. Android 10 enforces scoped storage
     * for apps built for newer Android, so there is no path access there; media comes through MediaStore and other folders through the folder picker.
     */
    fun pathAccess(sdk: Int, allFilesGranted: Boolean, readStorageGranted: Boolean): Boolean = when {
        sdk >= 30 -> allFilesGranted
        sdk <= 28 -> readStorageGranted
        else -> false
    }

    /** Can Nova change files by path? Android 11+: only with All files access. Android 8-9: the old write permission. */
    fun canWrite(sdk: Int, allFilesGranted: Boolean, writeStorageGranted: Boolean): Boolean = when {
        sdk >= 30 -> allFilesGranted
        sdk <= 28 -> writeStorageGranted
        else -> false
    }

    fun writePermissionsToRequest(sdk: Int): List<String> = if (sdk <= 28) listOf(Manifest.permission.WRITE_EXTERNAL_STORAGE) else emptyList()
}

data class FileAccessState(
    val sdk: Int,
    val allFilesAvailable: Boolean,
    val allFilesGranted: Boolean,
    val images: Boolean,
    val videos: Boolean,
    val audio: Boolean,
    val selectedOnly: Boolean,
    val legacyRead: Boolean,
    val safFolders: Int,
    val shizukuReady: Boolean,
    val writeStorage: Boolean = false
) {
    val canWrite: Boolean get() = FileAccessRules.canWrite(sdk, allFilesGranted, writeStorage)
    val pathAccess: Boolean get() = FileAccessRules.pathAccess(sdk, allFilesGranted, legacyRead)
    val anyMedia: Boolean get() = images || videos || audio || selectedOnly
    val canSeeAnything: Boolean get() = pathAccess || anyMedia || safFolders > 0

    /** Plain-language status. Never claims more than Android actually granted. */
    fun lines(): List<String> {
        val l = ArrayList<String>()
        l.add(if (pathAccess) "Folders: Nova can browse shared storage by path." else "Folders: not available by path (see below for how to open them).")
        l.add(when {
            images && videos && audio -> "Media: photos, videos and audio allowed."
            selectedOnly -> "Media: only the photos and videos you selected."
            anyMedia -> "Media: partly allowed (" + listOfNotNull(if (images) "photos" else null, if (videos) "videos" else null, if (audio) "audio" else null).joinToString(", ") + ")."
            else -> "Media: not allowed yet."
        })
        l.add(if (canWrite) "Changes: Nova can copy, move, rename and zip by path, and only deletes after you confirm." else "Changes: not by path yet (needs All files access).")
        l.add(if (safFolders > 0) "Chosen folders: $safFolders." else "Chosen folders: none yet.")
        l.add(if (allFilesGranted) "All files access: on." else if (allFilesAvailable) "All files access: off." else "All files access: not offered here.")
        l.add(if (shizukuReady) "Shizuku: ready." else "Shizuku: not connected.")
        return l
    }
}

object FileAccess {
    fun state(ctx: Context, safFolders: Int): FileAccessState {
        val sdk = Build.VERSION.SDK_INT
        fun g(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
        val legacy = g(Manifest.permission.READ_EXTERNAL_STORAGE)          // declared with maxSdkVersion 32
        val imgs = if (sdk >= 33) g(Manifest.permission.READ_MEDIA_IMAGES) else legacy
        val vids = if (sdk >= 33) g(Manifest.permission.READ_MEDIA_VIDEO) else legacy
        val aud = if (sdk >= 33) g(Manifest.permission.READ_MEDIA_AUDIO) else legacy
        val selected = sdk >= 34 && g(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) && !imgs && !vids
        val shizuku = try { ShizukuManager.state.value.status == ShizukuStatus.READY } catch (e: Throwable) { false }
        return FileAccessState(sdk, AllFiles.available(), AllFiles.granted(), imgs, vids, aud, selected, legacy, safFolders, shizuku, g(Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }
}
