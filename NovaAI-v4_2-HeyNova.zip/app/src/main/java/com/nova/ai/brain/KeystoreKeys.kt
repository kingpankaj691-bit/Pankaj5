package com.nova.ai.brain

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** AES-256 keys held by the Android Keystore (hardware backed where the phone has it). The key material never leaves the Keystore. */
object KeystoreKeys {
    const val VAULT_ALIAS = "nova_vault_key_v1"
    const val SNAPSHOT_ALIAS = "nova_snapshot_key_v1"

    @Synchronized
    fun get(alias: String): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    fun vaultKey(): SecretKey = get(VAULT_ALIAS)
    fun snapshotKey(): SecretKey = get(SNAPSHOT_ALIAS)
}
