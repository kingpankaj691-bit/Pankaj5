package com.nova.ai.screen

/**
 * Android-free copy of one on-screen element, so the matching rules below can be unit-tested on the JVM.
 * [id] is the UiElement.index it came from.
 */
data class Cand(
    val id: Int,
    val text: String = "", val desc: String = "", val hint: String = "", val viewId: String = "", val cls: String = "",
    val clickable: Boolean = false, val editable: Boolean = false, val focused: Boolean = false, val enabled: Boolean = true,
    val left: Int = 0, val top: Int = 0, val right: Int = 0, val bottom: Int = 0
) {
    val label: String get() = text.ifBlank { desc }.ifBlank { hint }
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val idName: String get() = viewId.substringAfterLast('/').lowercase()
    val all: String get() = "$text $desc $hint".lowercase()
}

enum class AppKind { YOUTUBE, BROWSER, OTHER }
enum class UiPlayback { PLAYING, PAUSED, UNKNOWN }
enum class PlaybackOutcome { CONFIRMED, PAUSED, UNCONFIRMED }
enum class PageProblem { OFFLINE, SITE_UNREACHABLE, LOAD_FAILED, CONSENT }

/** Where on screen things are and what they mean, per app family. Heuristics: confirm on a real device (see checklist). */
object AppUi {
    val youtubePackages = setOf("com.google.android.youtube")
    val browserPackages = setOf(
        "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "org.chromium.chrome", "org.mozilla.firefox", "org.mozilla.firefox_beta",
        "org.mozilla.fenix", "com.brave.browser", "com.microsoft.emmx", "com.sec.android.app.sbrowser", "com.opera.browser",
        "com.opera.mini.native", "com.duckduckgo.mobile.android", "com.kiwibrowser.browser", "com.vivaldi.browser", "com.android.browser"
    )

    fun kindOf(pkg: String): AppKind = when (pkg) {
        in youtubePackages -> AppKind.YOUTUBE
        in browserPackages -> AppKind.BROWSER
        else -> AppKind.OTHER
    }

    private val searchKeys = listOf("search", "खोज", "find", "query", "type web address", "enter address", "type url", "address")
    private val ytFieldIds = listOf("search_edit_text", "search_query", "search_box")
    private val browserFieldIds = listOf(
        "url_bar", "search_box_text", "omnibox", "url_edit_text", "mozac_browser_toolbar_edit_url_view", "urlbar", "url_field",
        "address_bar", "location_bar_edit_text", "toolbar_edit"
    )
    private val voiceLike = Regex("(?i)\\b(voice|mic|microphone|lens|camera|speak)\\b|आवाज")

    /** The text input a search should go into, or null when none is on screen yet. */
    fun searchField(cands: List<Cand>, pkg: String): Cand? {
        val kind = kindOf(pkg)
        val ids = when (kind) { AppKind.YOUTUBE -> ytFieldIds; AppKind.BROWSER -> browserFieldIds; else -> emptyList() }
        val fields = cands.filter { it.editable && it.enabled }
        if (fields.isEmpty()) return null
        fun score(c: Cand): Int {
            var s = 0
            if (c.focused) s += 30
            if (ids.any { c.viewId.lowercase().contains(it) }) s += 50
            if (searchKeys.any { c.all.contains(it) || c.viewId.lowercase().contains(it) }) s += 40
            return s
        }
        val best = fields.maxByOrNull { score(it) } ?: return null
        return when {
            score(best) > 0 -> best
            kind == AppKind.OTHER -> fields.firstOrNull { it.focused } ?: fields.first()
            else -> null
        }
    }

    /** The thing to tap so that a search field opens (search icon, or the fake search box of a browser start page). */
    fun searchEntry(cands: List<Cand>, pkg: String): Cand? {
        val kind = kindOf(pkg)
        if (kind == AppKind.OTHER) return null
        val boxWords = listOf("search or type", "type web address", "type url", "search google", "search or enter", "enter address", "address bar")
        fun score(c: Cand): Int {
            if (!c.clickable || !c.enabled || c.editable) return 0
            if (voiceLike.containsMatchIn(c.all)) return 0
            val d = c.desc.lowercase().trim(); val t = c.text.lowercase().trim()
            return when (kind) {
                AppKind.YOUTUBE -> when {
                    d == "search" || t == "search" -> 100
                    d.startsWith("search") || t.startsWith("search") -> 70
                    d == "खोजें" || d == "खोज" || t == "खोजें" -> 90
                    else -> 0
                }
                else -> when {
                    boxWords.any { c.all.contains(it) } -> 100
                    c.idName.contains("search_box") || c.idName.contains("url_bar") || c.idName.contains("omnibox") -> 80
                    else -> 0
                }
            }
        }
        return cands.map { it to score(it) }.filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Cand, Int>> { it.second }.thenBy { it.first.top }).firstOrNull()?.first
    }

    private val durationOrViews = Regex("(?i)(\\d+\\s*(?:hours?|hrs?|minutes?|mins?|seconds?|secs?|views?|watching|मिनट|सेकंड|घंटे|व्यू)|\\bviews\\b|\\blive\\b|\\d+:\\d{2})")
    private val adOrShort = Regex("(?i)(^|\\W)(sponsored|विज्ञापन)(\\W|$)|^ads?\\b|\\bplay short\\b|^shorts\\b")

    /**
     * Video rows of a YouTube results page in reading order. [strict] = only rows that look like real videos
     * (duration / views in their description), which is what tells results apart from suggestion rows.
     */
    fun youtubeResults(cands: List<Cand>, screenW: Int, screenH: Int, strict: Boolean = true): List<Cand> {
        val rows = cands.filter { c ->
            c.clickable && c.enabled && !c.editable && c.width > screenW * 0.5f && c.top > screenH * 0.12f &&
                c.label.length >= 12 && !adOrShort.containsMatchIn(c.label)
        }
        val videos = rows.filter { durationOrViews.containsMatchIn(it.label) }
        val chosen = if (videos.isNotEmpty() || strict) videos else rows
        return chosen.sortedWith(compareBy({ it.top }, { it.left }))
    }

    /** Picks the row that best matches [query] (word overlap); the first row when nothing overlaps. */
    fun bestForQuery(rows: List<Cand>, query: String): Cand? {
        if (rows.isEmpty()) return null
        val words = query.lowercase().split(Regex("\\s+")).filter { it.length > 2 }
        if (words.isEmpty()) return rows.first()
        val scored = rows.map { r -> r to words.count { r.label.lowercase().contains(it) } }
        val best = scored.maxByOrNull { it.second }!!
        return if (best.second > 0) best.first else rows.first()
    }

    private val strongPlayerIds = listOf("watch_player", "player_view", "watch_while", "time_bar", "player_fragment", "watch_panel")
    private val weakPlayerDesc = Regex("(?i)(pause video|play video|enter fullscreen|exit fullscreen|minimize|video player|seek bar|autoplay)")

    /** True when a YouTube video (watch) page is showing. */
    fun onYoutubeVideoPage(cands: List<Cand>, pkg: String): Boolean {
        if (kindOf(pkg) != AppKind.YOUTUBE) return false
        val strong = cands.any { c -> c.idName.let { id -> !id.contains("mini") && strongPlayerIds.any { id.contains(it) } } }
        val weak = cands.count { weakPlayerDesc.containsMatchIn(it.desc) || weakPlayerDesc.containsMatchIn(it.text) }
        return strong || weak >= 2
    }

    /** What the on-screen player controls say. A "Pause" control means it is playing; "Play" means it is paused. */
    fun playbackUi(cands: List<Cand>): UiPlayback {
        val labels = cands.map { (it.desc + " " + it.text).lowercase() }
        if (labels.any { it.contains("pause video") || it.contains("वीडियो रोकें") }) return UiPlayback.PLAYING
        if (labels.any { it.contains("play video") || it.contains("replay") || it.contains("वीडियो चलाएं") }) return UiPlayback.PAUSED
        return UiPlayback.UNKNOWN
    }

    /** The play/pause control, for a single safe retry when the video is paused. */
    fun playControl(cands: List<Cand>): Cand? =
        cands.firstOrNull { it.clickable && it.enabled && (it.desc.lowercase().contains("play video") || it.desc.lowercase().contains("replay")) }

    /** The player surface (tapping it only shows the controls). */
    fun playerSurface(cands: List<Cand>): Cand? =
        cands.firstOrNull { c -> c.clickable && c.idName.let { id -> !id.contains("mini") && (id.contains("watch_player") || id.contains("player_view")) } }

    private val browserNoise = Regex(
        "(?i)^(all|images|videos|news|maps|shopping|more|tools|sign in|settings|privacy|terms|sponsored|people also ask|related searches|" +
            "accept all|reject all|more options|filters|short videos|web|books|flights|finance)$"
    )

    /** Result links of a search-engine page in a browser, top to bottom. Prefers real links over plain text. */
    fun browserResults(cands: List<Cand>, screenH: Int): List<Cand> {
        val rows = cands.filter { c ->
            !c.editable && c.enabled && c.top > screenH * 0.16f && c.top < screenH * 0.97f &&
                c.label.length >= 15 && !browserNoise.matches(c.label.trim())
        }
        val links = rows.filter { it.clickable }
        return (if (links.isNotEmpty()) links else rows).sortedWith(compareBy({ it.top }, { it.left }))
    }

    private val urlIds = listOf("url_bar", "mozac_browser_toolbar_url_view", "url_edit_text", "urlbar", "location_bar", "toolbar_url")

    /** The address currently shown in the browser's address bar ("" if it can't be read). */
    fun urlText(cands: List<Cand>): String =
        cands.firstOrNull { c -> urlIds.any { c.viewId.lowercase().contains(it) } && c.text.isNotBlank() }?.text.orEmpty()

    /** Error / consent pages, from the visible text. Null = nothing wrong seen. */
    fun pageProblem(texts: List<String>): PageProblem? {
        val t = texts.joinToString(" | ").lowercase()
        return when {
            Regex("(no internet|you're offline|you are offline|err_internet_disconnected|check your connection|no connection|internet nahi|इंटरनेट कनेक्शन नहीं|कनेक्शन नहीं)").containsMatchIn(t) -> PageProblem.OFFLINE
            Regex("(this site can.t be reached|err_name_not_resolved|dns_probe|server not found|webpage not available|err_connection|took too long to respond)").containsMatchIn(t) -> PageProblem.SITE_UNREACHABLE
            Regex("(something went wrong|tap to retry|couldn.t load|can.t play this video)").containsMatchIn(t) -> PageProblem.LOAD_FAILED
            Regex("(before you continue|reject all|accept all cookies|we use cookies)").containsMatchIn(t) -> PageProblem.CONSENT
            else -> null
        }
    }
}

/** Decides whether a video is really playing. Audio alone is not proof if something else was already playing. */
object PlaybackVerdict {
    fun decide(audioActive: Boolean, audioWasActive: Boolean, ui: UiPlayback): PlaybackOutcome = when {
        ui == UiPlayback.PLAYING -> PlaybackOutcome.CONFIRMED
        ui == UiPlayback.PAUSED -> PlaybackOutcome.PAUSED
        audioActive && !audioWasActive -> PlaybackOutcome.CONFIRMED
        else -> PlaybackOutcome.UNCONFIRMED
    }
}

/** Why a task stopped. Every failure message names ONE cause so the user knows what to fix. */
enum class FailureKind {
    NO_INTERNET, APP_NOT_INSTALLED, BROWSER_NOT_INSTALLED, APP_NOT_IN_FRONT, SCREEN_UNREADABLE, SEARCH_FIELD_NOT_FOUND,
    FIELD_NOT_OPENED, SEARCH_NOT_SUBMITTED, NO_RESULTS, RESULT_NOT_FOUND, PAGE_NOT_LOADED, SITE_UNREACHABLE, PLAYBACK_UNCONFIRMED, PAUSED, CONSENT_PAGE
}

object Failures {
    fun message(kind: FailureKind, detail: String = "", hinglish: Boolean = false): String {
        val d = detail
        return if (hinglish) when (kind) {
            FailureKind.NO_INTERNET -> "Internet nahi hai. Wi-Fi ya mobile data connect karo."
            FailureKind.APP_NOT_INSTALLED -> "$d app is phone me nahi mila."
            FailureKind.BROWSER_NOT_INSTALLED -> "Browser \"$d\" install nahi hai."
            FailureKind.APP_NOT_IN_FRONT -> "$d screen ke aage nahi aaya. Android ne background se app kholne se roka ho sakta hai: Nova ko \"Display over other apps\" allow karo ya Nova ko pehle khol lo."
            FailureKind.SCREEN_UNREADABLE -> "$d khula hai par uski screen padh nahi pa rahi (app accessibility info nahi deta ya screen badal rahi hai)."
            FailureKind.SEARCH_FIELD_NOT_FOUND -> "Search box ya search button nahi mila. Screen par ye dikh raha tha: $d"
            FailureKind.FIELD_NOT_OPENED -> "Search icon dabaya par type karne wala box nahi khula."
            FailureKind.SEARCH_NOT_SUBMITTED -> "Text likh diya par search press nahi ho paya. $d"
            FailureKind.NO_RESULTS -> "Search bheja par results nahi dikhe. $d"
            FailureKind.RESULT_NOT_FOUND -> "Screen par koi result nahi mila. $d"
            FailureKind.PAGE_NOT_LOADED -> "Result dabaya par page load nahi hua. $d"
            FailureKind.SITE_UNREACHABLE -> "Website khul nahi rahi (site ya DNS ki dikkat)."
            FailureKind.PLAYBACK_UNCONFIRMED -> "Video page khula hai par main confirm nahi kar pa rahi ki video chal raha hai (audio active nahi hai). Ho sakta hai paused, buffering ya mute ho."
            FailureKind.PAUSED -> "Video page khula hai par video paused hai."
            FailureKind.CONSENT_PAGE -> "Cookies/consent page beech me aa gaya. Use khud accept ya reject kar do, main nahi karungi."
        } else when (kind) {
            FailureKind.NO_INTERNET -> "There is no internet connection. Connect to Wi-Fi or mobile data."
            FailureKind.APP_NOT_INSTALLED -> "I couldn't find the $d app on this phone."
            FailureKind.BROWSER_NOT_INSTALLED -> "The browser \"$d\" isn't installed."
            FailureKind.APP_NOT_IN_FRONT -> "$d didn't come to the front. Android may have blocked opening it from the background: allow \"Display over other apps\" for Nova, or open Nova first."
            FailureKind.SCREEN_UNREADABLE -> "$d is open but I can't read its screen (the app hides its UI from accessibility, or the screen is still changing)."
            FailureKind.SEARCH_FIELD_NOT_FOUND -> "I couldn't find a search box or search button. This is what I could see: $d"
            FailureKind.FIELD_NOT_OPENED -> "I tapped search but no text box opened for typing."
            FailureKind.SEARCH_NOT_SUBMITTED -> "I typed the text but couldn't submit the search. $d"
            FailureKind.NO_RESULTS -> "I submitted the search but no results appeared. $d"
            FailureKind.RESULT_NOT_FOUND -> "I couldn't find a result on screen to open. $d"
            FailureKind.PAGE_NOT_LOADED -> "I tapped the result but the page didn't load. $d"
            FailureKind.SITE_UNREACHABLE -> "The website can't be reached (site or DNS problem)."
            FailureKind.PLAYBACK_UNCONFIRMED -> "The video page is open but I can't confirm the video is playing (no audio detected). It may be paused, buffering or muted."
            FailureKind.PAUSED -> "The video page is open but the video is paused."
            FailureKind.CONSENT_PAGE -> "A cookie/consent page is in the way. Please accept or decline it yourself; I won't."
        }
    }
}
