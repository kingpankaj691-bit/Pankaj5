package com.nova.ai.jarvis

import android.content.Context
import com.nova.ai.modules.WebhookImpl
import com.nova.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Smart bulbs and plugs, controlled directly where possible:
 *  tasmota, shelly1, shelly2, wled, kasa  = your own Wi-Fi network, no cloud
 *  ha      = Home Assistant REST (this also reaches Tuya / Zigbee / Hue through Home Assistant)
 *  tuya    = Tuya Cloud OpenAPI (needs a free Tuya IoT project: Access ID + Secret)
 *  webhook = the generic endpoint already in Tools > Connections
 */
object SmartHome {
    class Dev(val id: String, val name: String, val aliases: String, val kind: String, val type: String, val host: String, val extra: String, val confirm: Boolean)

    @Volatile var cache: List<Dev> = emptyList()

    val types = listOf("tasmota", "shelly1", "shelly2", "wled", "kasa", "ha", "tuya", "webhook")

    fun load(ctx: Context) { cache = parse(JarvisPrefs(ctx).devicesJson) }

    fun parse(json: String): List<Dev> = try {
        val a = JSONArray(json)
        (0 until a.length()).map { a.getJSONObject(it).let { o ->
            Dev(o.optString("id"), o.optString("name"), o.optString("aliases"), o.optString("kind", "light"), o.optString("type", "tasmota"),
                o.optString("host"), o.optString("extra"), o.optBoolean("confirm", false))
        } }
    } catch (e: Exception) { emptyList() }

    fun save(ctx: Context, list: List<Dev>) {
        JarvisPrefs(ctx).devicesJson = JSONArray(list.map {
            JSONObject().put("id", it.id).put("name", it.name).put("aliases", it.aliases).put("kind", it.kind).put("type", it.type)
                .put("host", it.host).put("extra", it.extra).put("confirm", it.confirm)
        }).toString()
        cache = list
    }

    // ───────── which devices did the user mean ─────────

    private val allWords = Regex("\\b(sab|sabhi|saari|saare|sari|all|every|everything)\\b")
    private val lightWords = Regex("\\b(lights?|batti|battiyan|bulbs?|lamps?|led)\\b")
    private val plugWords = Regex("\\b(plugs?|sockets?|switch(?:es)?)\\b")

    /** Devices named in the sentence (by name, alias or room word); "sab lights" selects every light. Empty = not a smart-home sentence. */
    fun match(l: String): List<Dev> {
        val devs = cache
        if (devs.isEmpty()) return emptyList()
        val named = devs.filter { d ->
            (d.name + "," + d.aliases).split(',').map { it.trim().lowercase() }.filter { it.length >= 2 }
                .any { Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(it) + "(?![\\p{L}\\p{N}])").containsMatchIn(l) }
        }
        val kindFilter: (Dev) -> Boolean = when {
            lightWords.containsMatchIn(l) && !plugWords.containsMatchIn(l) -> { d -> d.kind == "light" }
            plugWords.containsMatchIn(l) && !lightWords.containsMatchIn(l) -> { d -> d.kind == "plug" }
            else -> { _ -> true }
        }
        if (allWords.containsMatchIn(l) && (lightWords.containsMatchIn(l) || plugWords.containsMatchIn(l))) return devs.filter(kindFilter)
        if (named.isNotEmpty()) {
            val byKind = named.filter(kindFilter)
            return if (byKind.isNotEmpty()) byKind else named
        }
        // "lights off karo" with exactly one light registered
        if (lightWords.containsMatchIn(l)) devs.filter { it.kind == "light" }.takeIf { it.size == 1 }?.let { return it }
        if (plugWords.containsMatchIn(l)) devs.filter { it.kind == "plug" }.takeIf { it.size == 1 }?.let { return it }
        return emptyList()
    }

    fun needsConfirm(ids: List<String>): Boolean = cache.any { it.id in ids && it.confirm }

    // ───────── control ─────────

    suspend fun control(ctx: Context, prefs: Prefs, ids: List<String>, on: Boolean?, level: Int?): String {
        val devs = cache.filter { it.id in ids }
        if (devs.isEmpty()) return "Wo device ab list mein nahi hai."
        val results = devs.map { d ->
            val r = try { withContext(Dispatchers.IO) { one(ctx, prefs, d, on, level) } } catch (e: Exception) { "failed: ${e.message}" }
            d to r
        }
        val ok = results.filter { it.second == "ok" }
        val bad = results.filter { it.second != "ok" }
        val what = when { level != null -> "$level% brightness"; on == true -> "on"; on == false -> "off"; else -> "" }
        return buildString {
            if (ok.isNotEmpty()) append(ok.joinToString(", ") { it.first.name }).append(" ").append(what).append(" kar diya. ")
            bad.forEach { append("${it.first.name}: ${it.second}. ") }
        }.trim()
    }

    private fun one(ctx: Context, prefs: Prefs, d: Dev, on: Boolean?, level: Int?): String {
        val jp = JarvisPrefs(ctx)
        val state = on ?: true            // setting a brightness also turns the light on
        return when (d.type) {
            "tasmota" -> {
                val idx = d.extra.ifBlank { "" }
                if (level != null) get("http://${d.host}/cm?cmnd=Dimmer%20$level")
                else get("http://${d.host}/cm?cmnd=Power$idx%20${if (state) "On" else "Off"}")
            }
            "shelly1" -> if (level != null) get("http://${d.host}/light/0?turn=on&brightness=$level") else get("http://${d.host}/relay/${d.extra.ifBlank { "0" }}?turn=${if (state) "on" else "off"}")
            "shelly2" -> if (level != null) get("http://${d.host}/rpc/Light.Set?id=${d.extra.ifBlank { "0" }}&on=true&brightness=$level")
                else get("http://${d.host}/rpc/Switch.Set?id=${d.extra.ifBlank { "0" }}&on=$state")
            "wled" -> {
                val b = JSONObject().put("on", state)
                if (level != null) b.put("bri", (level * 255 / 100).coerceIn(1, 255))
                send("POST", "http://${d.host}/json/state", b.toString(), emptyMap())
            }
            "kasa" -> kasa(d, state, level)
            "ha" -> {
                val base = jp.haUrl
                val token = prefs.secret("ha_token")
                if (base.isBlank() || token.isBlank()) return "Home Assistant URL ya token set nahi hai"
                val domain = d.host.substringBefore('.', "homeassistant").let { if (it in setOf("light", "switch", "fan", "input_boolean", "cover", "scene", "script")) it else "homeassistant" }
                val body = JSONObject().put("entity_id", d.host)
                if (level != null && domain == "light") body.put("brightness_pct", level)
                send("POST", "$base/api/services/$domain/${if (state) "turn_on" else "turn_off"}", body.toString(), mapOf("Authorization" to "Bearer $token"))
            }
            "tuya" -> tuya(prefs, jp, d, state, level)
            "webhook" -> kotlinx.coroutines.runBlocking { WebhookImpl(prefs, "smart_home").command(d.name, if (state) "on" else "off") }.let { if (it.startsWith("Done")) "ok" else it }
            else -> "unknown device type"
        }
    }

    // ───────── HTTP ─────────

    private fun get(url: String) = send("GET", url, null, emptyMap())

    /** Returns "ok" or a short error. Local devices answer in milliseconds, so timeouts are short. */
    private fun send(method: String, url: String, body: String?, headers: Map<String, String>): String {
        var c: HttpURLConnection? = null
        return try {
            c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method; connectTimeout = 4000; readTimeout = 6000
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
                if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json"); outputStream.use { it.write(body.toByteArray()) } }
            }
            val code = c.responseCode
            if (code in 200..299) "ok" else "HTTP $code"
        } catch (e: Exception) { "device not reachable (${e.message?.take(40)})" } finally { c?.disconnect() }
    }

    // ───────── TP-Link Kasa (local TCP 9999, simple XOR autokey) ─────────

    private fun kasaCrypt(s: String): ByteArray {
        var key = 171
        val raw = s.toByteArray()
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0, 0, ((raw.size shr 8) and 0xFF).toByte(), (raw.size and 0xFF).toByte()))
        for (b in raw) { val c = key xor (b.toInt() and 0xFF); key = c; out.write(c) }
        return out.toByteArray()
    }

    private fun kasa(d: Dev, on: Boolean, level: Int?): String {
        val cmd = if (d.kind == "light") {
            val st = JSONObject().put("on_off", if (on) 1 else 0)
            if (level != null) st.put("on_off", 1).put("brightness", level)
            JSONObject().put("smartlife.iot.smartbulb.lightingservice", JSONObject().put("transition_light_state", st))
        } else JSONObject().put("system", JSONObject().put("set_relay_state", JSONObject().put("state", if (on) 1 else 0)))
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(d.host, 9999), 4000); s.soTimeout = 4000
                s.getOutputStream().apply { write(kasaCrypt(cmd.toString())); flush() }
                val inp = DataInputStream(s.getInputStream())
                val len = inp.readInt().coerceIn(0, 4096)
                val buf = ByteArray(len); inp.readFully(buf)
                var key = 171; val sb = StringBuilder()
                for (b in buf) { val c = b.toInt() and 0xFF; sb.append((key xor c).toChar()); key = c }
                if (sb.contains("\"err_code\":0")) "ok" else "device error"
            }
        } catch (e: Exception) { "device not reachable (${e.message?.take(40)})" }
    }

    // ───────── Tuya Cloud OpenAPI ─────────

    @Volatile private var tuyaToken = ""
    @Volatile private var tuyaExpires = 0L

    private fun host(region: String) = "https://openapi.tuya" + when (region) { "us" -> "us"; "eu" -> "eu"; "cn" -> "cn"; else -> "in" } + ".com"
    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun hmac(key: String, msg: String): String {
        val m = Mac.getInstance("HmacSHA256"); m.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
        return m.doFinal(msg.toByteArray()).joinToString("") { "%02X".format(it) }
    }

    private fun tuyaCall(prefs: Prefs, jp: JarvisPrefs, method: String, path: String, body: String, withToken: Boolean): JSONObject? {
        val id = jp.tuyaClientId; val secret = prefs.secret("tuya_secret")
        if (id.isBlank() || secret.isBlank()) return null
        val t = System.currentTimeMillis().toString()
        val stringToSign = "$method\n${sha256(body)}\n\n$path"
        val sign = hmac(secret, id + (if (withToken) tuyaToken else "") + t + stringToSign)
        var c: HttpURLConnection? = null
        return try {
            c = (URL(host(jp.tuyaRegion) + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method; connectTimeout = 8000; readTimeout = 10000
                setRequestProperty("client_id", id); setRequestProperty("sign", sign); setRequestProperty("t", t); setRequestProperty("sign_method", "HMAC-SHA256")
                if (withToken) setRequestProperty("access_token", tuyaToken)
                if (body.isNotEmpty()) { doOutput = true; setRequestProperty("Content-Type", "application/json"); outputStream.use { it.write(body.toByteArray()) } }
            }
            val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            JSONObject(txt)
        } catch (e: Exception) { null } finally { c?.disconnect() }
    }

    private fun tuya(prefs: Prefs, jp: JarvisPrefs, d: Dev, on: Boolean, level: Int?): String {
        if (jp.tuyaClientId.isBlank() || prefs.secret("tuya_secret").isBlank()) return "Tuya Access ID / Secret set nahi hai"
        if (System.currentTimeMillis() > tuyaExpires - 60_000) {
            val r = tuyaCall(prefs, jp, "GET", "/v1.0/token?grant_type=1", "", false) ?: return "Tuya cloud not reachable"
            val res = r.optJSONObject("result") ?: return "Tuya login failed: " + r.optString("msg").take(60)
            tuyaToken = res.optString("access_token"); tuyaExpires = System.currentTimeMillis() + res.optLong("expire_time", 7000) * 1000
        }
        val cmds = JSONArray()
        val switchCode = d.extra.ifBlank { if (d.kind == "light") "switch_led" else "switch_1" }
        cmds.put(JSONObject().put("code", switchCode).put("value", on))
        if (level != null && d.kind == "light") cmds.put(JSONObject().put("code", "bright_value_v2").put("value", (level * 10).coerceIn(10, 1000)))
        val body = JSONObject().put("commands", cmds).toString()
        val r = tuyaCall(prefs, jp, "POST", "/v1.0/devices/${d.host}/commands", body, true) ?: return "Tuya cloud not reachable"
        return if (r.optBoolean("success")) "ok" else "Tuya: " + r.optString("msg").take(60)
    }
}
