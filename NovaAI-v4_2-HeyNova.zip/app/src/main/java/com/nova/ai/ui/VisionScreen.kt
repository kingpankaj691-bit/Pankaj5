package com.nova.ai.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nova.ai.ai.Emotion
import com.nova.ai.vision.CameraAssistant
import com.nova.ai.vision.Gesture
import com.nova.ai.vision.GestureManager
import com.nova.ai.vision.VisionRequest
import com.nova.ai.vision.VisionRequests
import com.nova.ai.vision.VisionTask
import kotlinx.coroutines.delay

/**
 * Camera Vision. The camera is on ONLY while this screen is open and you have started it (or you asked by voice).
 * It is released when you tap Stop, leave the screen, or the app goes to the background. Images are analysed on the phone,
 * never saved and never uploaded.
 */
@Composable
fun VisionScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val cam = remember { CameraAssistant(ctx.applicationContext) }
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var cameraOn by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(false) }
    var gestureOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var lastGesture by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<PreviewView?>(null) }
    var req by remember { mutableStateOf(VisionRequests.take()) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (!ok) { error = "Camera permission was not allowed. You can allow it in Android settings > Apps > NOVA > Permissions."; req = null }
    }

    // Always release the camera when the app goes to the background or this screen closes.
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) { cameraOn = false; gestureOn = false } }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); cam.shutdown() }
    }

    LaunchedEffect(cameraOn, front, preview) {
        val pv = preview
        if (cameraOn && pv != null) {
            ready = false; error = ""
            cam.start(owner, pv.surfaceProvider, front) { ok, msg -> ready = ok; if (!ok) { error = msg; cameraOn = false } }
        } else { cam.stop(); ready = false }
    }

    LaunchedEffect(gestureOn, front, ready) {
        if (gestureOn && ready) {
            val main = Handler(Looper.getMainLooper())
            cam.analyzer.gesture = GestureManager(mirrored = front) { gs ->
                main.post {
                    lastGesture = when (gs) { Gesture.SWIPE_RIGHT -> "Swipe right: next"; Gesture.SWIPE_LEFT -> "Swipe left: previous"; Gesture.WAVE -> "Wave: play / pause" }
                    dispatchMedia(ctx, gs)
                }
            }
        } else cam.analyzer.gesture = null
    }

    fun ask(task: VisionTask) {
        if (!ready || busy) return
        busy = true; result = ""
        cam.analyzer.request(task) { r ->
            busy = false; result = r
            if (vm.prefs.speakReplies) vm.voice.speak(r, Emotion.Normal)
        }
    }

    // A voice request ("camera mein kya hai") starts the camera here, in view.
    LaunchedEffect(req, granted) {
        val r = req ?: return@LaunchedEffect
        if (!granted) { launcher.launch(Manifest.permission.CAMERA); return@LaunchedEffect }
        if (r == VisionRequest.GESTURE_ON) front = true
        cameraOn = true
    }
    LaunchedEffect(ready) {
        val r = req
        if (ready && r != null) {
            delay(1200)
            when (r) {
                VisionRequest.DESCRIBE -> ask(VisionTask.DESCRIBE)
                VisionRequest.READ_TEXT -> ask(VisionTask.READ_TEXT)
                VisionRequest.GESTURE_ON -> gestureOn = true
            }
            req = null
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            GText("Camera Vision", size = 22.sp, weight = FontWeight.SemiBold)
        }
        GText("The camera is on only while this screen is open and started. Pictures are analysed on your phone and are never saved or uploaded.", size = 12.sp, color = g.subtext)
        if (error.isNotBlank()) GText(error, size = 13.sp, color = g.accent)
        if (!granted) {
            GlassButton("Allow camera", { launcher.launch(Manifest.permission.CAMERA) }, Modifier.fillMaxWidth(), primary = true)
        } else {
            if (cameraOn) {
                AndroidView(
                    factory = { c -> PreviewView(c).also { preview = it } },
                    update = { it.keepScreenOn = gestureOn },
                    modifier = Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(22.dp))
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(if (cameraOn) "Stop camera" else "Start camera", { if (cameraOn) { cameraOn = false; gestureOn = false } else { error = ""; cameraOn = true } }, primary = !cameraOn)
                GlassButton(if (front) "Front camera" else "Back camera", { front = !front })
            }
            if (cameraOn && ready) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("What's in view?", { ask(VisionTask.DESCRIBE) }, primary = true, enabled = !busy)
                    GlassButton("Read text", { ask(VisionTask.READ_TEXT) }, enabled = !busy)
                }
                ToggleRow("Gesture mode", "Swipe right: next · swipe left: previous · wave: play/pause", gestureOn) { gestureOn = it; if (it) front = true }
                if (gestureOn) GText("Hold your hand in front of the front camera and swipe across it. Works only while this screen stays open; it uses the screen's keep-awake while on.", size = 12.sp, color = g.subtext)
                if (lastGesture.isNotBlank()) GText("Last gesture: $lastGesture", size = 13.sp, color = g.accent)
            }
            if (busy) GText("Looking…", size = 13.sp, color = g.subtext)
            if (result.isNotBlank()) GlassSettingSection("Result") {
                GText(result, size = 14.sp)
                GlassButton("Speak it", { vm.voice.speak(result, Emotion.Normal) })
            }
        }
    }
}

private fun dispatchMedia(ctx: Context, gesture: Gesture) {
    val code = when (gesture) {
        Gesture.SWIPE_RIGHT -> KeyEvent.KEYCODE_MEDIA_NEXT
        Gesture.SWIPE_LEFT -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
        Gesture.WAVE -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
    }
    try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    } catch (e: Exception) { }
}
