package com.nova.ai.device

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.nova.ai.security.Prefs

enum class Heat { UNKNOWN, OK, WARM, HOT }

data class TempReading(val batteryC: Float?, val thermalStatus: Int?, val heat: Heat)

/**
 * Temperature safety using only what Android officially gives a normal app: the battery temperature from the battery broadcast
 * and, on Android 10+, PowerManager's thermal status. Exact CPU/GPU temperatures are NOT available to normal apps on most phones,
 * and which readings exist varies by device, so Nova never states a CPU/GPU number.
 */
class TemperatureMonitor(private val ctx: Context, private val prefs: Prefs) {

    fun read(): TempReading {
        val bat = BatteryMonitor(ctx).snapshot()?.tempC
        val thermal: Int? = if (Build.VERSION.SDK_INT >= 29) {
            try { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus } catch (e: Exception) { null }
        } else null
        if (bat == null && thermal == null) return TempReading(null, null, Heat.UNKNOWN)
        val hot = (bat != null && bat >= prefs.tempCritC) || (thermal != null && thermal >= PowerManager.THERMAL_STATUS_SEVERE)
        val warm = (bat != null && bat >= prefs.tempWarnC) || (thermal != null && thermal >= PowerManager.THERMAL_STATUS_MODERATE)
        return TempReading(bat, thermal, if (hot) Heat.HOT else if (warm) Heat.WARM else Heat.OK)
    }

    fun describe(r: TempReading = read()): String {
        if (r.heat == Heat.UNKNOWN) return "This phone doesn't expose any temperature reading to apps, so I can't check it."
        val parts = ArrayList<String>()
        r.batteryC?.let { parts.add("battery temperature is %.1f°C".format(it)) }
        r.thermalStatus?.let { parts.add("Android's thermal status is ${thermalName(it)}") }
        val head = parts.joinToString(" and ").replaceFirstChar { it.uppercase() } + "."
        val tail = when (r.heat) {
            Heat.HOT -> " System temperature is high. Consider reducing workload and letting the phone cool."
            Heat.WARM -> " It is running warm. Consider closing heavy apps."
            else -> " That looks normal."
        }
        return head + tail + " CPU and GPU temperatures aren't available to apps on most phones, and what is available varies by device."
    }

    private fun thermalName(s: Int) = when (s) {
        0 -> "normal"; 1 -> "light"; 2 -> "moderate"; 3 -> "severe"; 4 -> "critical"; 5 -> "emergency"; 6 -> "shutdown"; else -> "unknown"
    }
}
