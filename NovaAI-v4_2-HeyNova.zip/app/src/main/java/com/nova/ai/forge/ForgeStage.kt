package com.nova.ai.forge

/** Six build stages, in order. The stage is read from the HTML that has streamed in so far. */
enum class ForgeStage(val label: String) {
    PLANNING("Planning"), STRUCTURE("Structure"), STYLING("Styling"), CONTENT("Content"), MOTION("Motion"), FINISHING("Finishing")
}

object ForgeStageDetector {
    private val sectionRx = Regex("<section\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val classRx = Regex("class\\s*=\\s*\"", RegexOption.IGNORE_CASE)

    private fun bodyOf(l: String): String? { val i = l.indexOf("<body"); return if (i < 0) null else l.substring(i) }

    /** A page that is only a <head> (even with big style/tailwind tags) stays at PLANNING. */
    fun detect(partialHtml: String): ForgeStage {
        val l = partialHtml.lowercase()
        if (l.contains("</html>")) return ForgeStage.FINISHING
        val body = bodyOf(l) ?: return ForgeStage.PLANNING
        var stage = ForgeStage.STRUCTURE
        if (classRx.findAll(body).count() >= 15 || body.contains("<style")) stage = ForgeStage.STYLING
        val sections = sectionRx.findAll(body).count()
        if (sections >= 2) stage = ForgeStage.CONTENT
        val motion = body.contains("gsap") || body.contains("three") || body.contains("<canvas") || body.contains("@keyframes") || body.contains("requestanimationframe")
        if (motion && sections >= 2) stage = ForgeStage.MOTION
        else if (body.contains("<canvas") && stage.ordinal < ForgeStage.STYLING.ordinal) stage = ForgeStage.STYLING   // canvas counts as visuals
        return stage
    }

    /** Overall progress 0..1: the stage sets a floor, characters written move it within the stage. Never reaches 1 before the page ends. */
    fun progress(stage: ForgeStage, chars: Int, expectedChars: Int = 36000, done: Boolean = false): Float {
        if (done) return 1f
        val base = stage.ordinal / 6f
        val byChars = (chars.toFloat() / expectedChars).coerceIn(0f, 1f)
        return maxOf(base, byChars * 0.97f).coerceAtMost(0.97f)
    }

    /** Human names of the sections found so far: from id, else the first heading, else "Section N". */
    fun sections(partialHtml: String): List<String> {
        val out = ArrayList<String>()
        val rx = Regex("<section\\b([^>]*)>", RegexOption.IGNORE_CASE)
        for ((n, m) in rx.findAll(partialHtml).withIndex()) {
            val id = Regex("id\\s*=\\s*\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(m.groupValues[1])?.groupValues?.get(1)
            var name = id?.replace('-', ' ')?.replace('_', ' ')?.trim()?.replaceFirstChar { it.uppercase() }
            if (name.isNullOrBlank()) {
                val after = partialHtml.substring(m.range.last + 1, minOf(partialHtml.length, m.range.last + 600))
                val h = Regex("<h[12][^>]*>(.*?)</h[12]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(after)?.groupValues?.get(1)
                name = h?.replace(Regex("<[^>]+>"), "")?.trim()?.take(28)
            }
            out.add(if (name.isNullOrBlank()) "Section ${n + 1}" else name)
        }
        return out
    }
}
