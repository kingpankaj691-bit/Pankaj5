package com.nova.ai.vision

enum class VisionRequest { DESCRIBE, READ_TEXT, GESTURE_ON }

/** Hands a voice/text request ("camera mein kya hai") to the Camera screen. The screen takes it once, and the camera starts only then. */
object VisionRequests {
    @Volatile private var pending: VisionRequest? = null
    fun set(r: VisionRequest) { pending = r }
    fun take(): VisionRequest? { val r = pending; pending = null; return r }
}
