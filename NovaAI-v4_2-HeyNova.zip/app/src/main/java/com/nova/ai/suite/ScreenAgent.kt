package com.nova.ai.suite

import android.content.Context
import android.content.Intent
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.screen.ActionValidator
import com.nova.ai.screen.ScreenSnapshot
import com.nova.ai.screen.Verdict
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

data class AgentAct(val action: String, val index: Int, val text: String, val app: String, val say: String)

/**
 * Universal "do it for me" agent. You give a goal ("Instagram par ye video reel upload karo", "Wi-Fi settings mein jakar ... "), and Nova loops:
 * read the screen through accessibility -> the selected Gemini model chooses ONE next action -> Nova checks it -> performs it -> repeat (max 10-30 steps, you choose in Control Center).
 * Rules enforced in code, not left to the model: never acts in payment/banking/password apps (ActionValidator), never touches password fields,
 * always asks before paying, buying, deleting, installing, granting permissions or signing out, and asks before send/post/publish
 * unless you chose "send/post automatically" for this run. Stop any time from the orb menu > Stop workflow.
 * Honest limits: needs Accessibility; apps that hide their UI (secure windows, games, video players) can't be read; each step costs one model call.
 */
object ScreenAgent {
    private const val DEFAULT_STEPS = 30
    private fun maxSteps(ctx: Context) = Features.getInt(ctx, "agent_steps", DEFAULT_STEPS)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    val active: Boolean get() = job?.isActive == true

    private val hard = Regex("\\b(pay|payment|transfer|buy|purchase|order|checkout|subscribe|delete|remove|uninstall|erase|factory|reset|format|install|allow|grant|permit|turn off|disable|sign out|log out|logout|clear data|clear all)\\b", RegexOption.IGNORE_CASE)
    private val soft = Regex("\\b(send|post|publish|share|upload|confirm|submit|accept|agree|done)\\b", RegexOption.IGNORE_CASE)
    private val secret = Regex("(password|passcode|\\botp\\b|\\bcvv\\b|card number|\\b\\d{12,19}\\b)", RegexOption.IGNORE_CASE)

    private const val SYS = "You control an Android phone to achieve the user's goal, one action at a time. Reply with ONLY a JSON object " +
        "{\"action\":string,\"index\":number,\"text\":string,\"app\":string,\"say\":string}. Actions: click (index of an element), type (index of a text field, text), " +
        "scroll_down, scroll_up, back, home, open_app (app = app name), wait, ask_user (say = what you need from the user, e.g. choose a file or enter a code), " +
        "done (say = result), fail (say = why it is impossible). Use only indices from the list; never invent them. Never type passwords, OTPs or card numbers. " +
        "Prefer the most specific label. If the screen did not change after your last action, try something different. \"say\" is a short reason in the user's language."

    fun cancel() { job?.cancel(); job = null; FloatingOrb.processing = false; FloatingOrb.current?.refresh() }

    fun parseAct(raw: String): AgentAct? {
        val a = raw.indexOf('{'); val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try {
            val o = JSONObject(raw.substring(a, b + 1))
            val act = o.optString("action").trim().lowercase()
            if (act.isBlank()) null else AgentAct(act, o.optInt("index", -1), o.optString("text"), o.optString("app"), o.optString("say"))
        } catch (e: Exception) { null }
    }

    fun describe(s: ScreenSnapshot?, max: Int = 70): String {
        if (s == null || s.elements.isEmpty()) return "(no readable elements)"
        return s.elements.take(max).joinToString("\n") { e ->
            val l = if (e.password) "password field - never touch" else e.label.take(60)
            "[${e.index}] ${e.kind}: \"$l\"" + (if (e.checkable) (if (e.checked) " (on)" else " (off)") else "")
        }
    }

    /** Risk of pressing something labelled [text]: 2 = always ask, 1 = ask unless auto-send was chosen, 0 = fine. */
    fun risk(text: String): Int = if (hard.containsMatchIn(text)) 2 else if (soft.containsMatchIn(text)) 1 else 0

    fun start(ctx: Context, goal: String): String {
        val app = ctx.applicationContext
        if (!Features.enabled(app, Features.AUTOMATION)) return Features.off("Accessibility Automation")
        if (goal.isBlank()) return "Batao kya karna hai, jaise: khud karo Instagram par latest video reel upload karo."
        if (!NovaSheet.canShow(app)) return SystemControls.openOverlay(app)
        Workflows.cancel()
        job = scope.launch { execute(app, goal.trim()) }
        return "Agent mode: pehle aapse approval loongi."
    }

    private fun launchApp(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(main, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .firstOrNull { it.second.equals(name, true) } ?: pm.queryIntentActivities(main, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .firstOrNull { it.second.lowercase().contains(name.lowercase()) && name.length >= 3 }
            ?: return null
        if (ActionValidator.packageBlocked(hit.first) || DeviceMgmt.isRestricted(ctx, hit.first)) return null
        val i = pm.getLaunchIntentForPackage(hit.first) ?: return null
        return try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); hit.second } catch (e: Exception) { null }
    }

    private suspend fun execute(ctx: Context, goal: String) {
        val title = "Agent"
        val prefs = Prefs(ctx)
        val svc0 = NovaAccessibilityService.instance
        if (svc0 == null) { Workflows.fail(ctx, title, "Accessibility is off. Turn on Nova AI in Accessibility first."); return }
        (ActionValidator.base(prefs) as? Verdict.Denied)?.let { Workflows.fail(ctx, title, it.reason); return }
        if (!prefs.hasActiveKey() || !prefs.aiEnabled || prefs.localOnly) { Workflows.fail(ctx, title, "The agent needs an API key, AI on and local-only off."); return }

        val c = Workflows.ask(ctx, "$title — goal",
            "Goal: $goal\n\nI will read your screen, ask the selected model for one step at a time (about 1 model call per step, max ${maxSteps(ctx)}) and tap/type for you.\n" +
                "I always ask before paying, buying, deleting, installing, permissions and sign-out. I never act in payment, banking or password apps.",
            listOf("Start (ask before send/post)" to 1, "Start (send/post automatically)" to 2, "Cancel" to 0))
        if (c == 0) { NovaSheet.hide(); return }
        val autoSoft = c == 2

        NovaSheet.hide()
        FloatingOrb.processing = true; FloatingOrb.current?.refresh()
        val log = ArrayList<String>()
        var lastKey = 0; var same = 0
        var outcome = "Stopped: step limit reached."
        try {
            val limit = maxSteps(ctx)
            for (step in 1..limit) {
                val svc = NovaAccessibilityService.instance
                if (svc == null) { outcome = "Accessibility turned off."; break }
                val snap = svc.snapshot()
                val pkg = snap?.pkg ?: NovaAccessibilityService.activePackage()
                if (ActionValidator.packageBlocked(pkg)) { outcome = "Stopped: I don't act in payment, banking or password apps. Please do this part yourself."; break }
                val screen = describe(snap)
                val key = screen.hashCode()
                same = if (key == lastKey) same + 1 else 0; lastKey = key
                if (same >= 3) { outcome = "Stopped: the screen stopped changing (stuck)."; break }

                val prompt = "Goal: $goal\nStep $step of $limit\nForeground app: $pkg\nPrevious actions:\n" + (log.takeLast(8).joinToString("\n").ifBlank { "(none)" }) + "\nScreen elements:\n" + screen
                val r = SwitchingProvider(prefs).chat(listOf(true to prompt), SYS, null)
                val act = when (r) { is AiResult.Ok -> parseAct(r.text); is AiResult.Err -> { outcome = "Stopped: " + r.msg; null } }
                if (act == null) { if (outcome.startsWith("Stopped")) break; outcome = "Stopped: the model's answer wasn't a valid action."; break }
                val el = snap?.elements?.getOrNull(act.index)
                val labelNow = el?.label.orEmpty()

                when (act.action) {
                    "click" -> {
                        if (el == null) { log.add("$step. invalid index ${act.index}"); delay(600); continue }
                        val rk = risk(labelNow + " " + act.say)
                        if (rk == 2 || (rk == 1 && !autoSoft)) {
                            val a = Workflows.ask(ctx, "$title — approval", "I want to press \"$labelNow\" in $pkg.\n${act.say}", listOf("Allow" to 1, "Skip" to 2, "Stop" to 0))
                            NovaSheet.hide()
                            if (a == 0) { outcome = "Stopped by you."; break }
                            if (a == 2) { log.add("$step. skipped \"$labelNow\""); continue }
                        }
                        val ok = svc.clickElement(el)
                        log.add("$step. click \"$labelNow\"" + if (ok) "" else " (failed)")
                    }
                    "type" -> {
                        if (el == null || !el.editable || el.password || secret.containsMatchIn(act.text)) { log.add("$step. refused to type there"); delay(600); continue }
                        val ok = svc.setTextOn(el, act.text)
                        log.add("$step. typed into \"$labelNow\"" + if (ok) "" else " (failed)")
                    }
                    "scroll_down" -> { svc.scroll(true); log.add("$step. scroll down") }
                    "scroll_up" -> { svc.scroll(false); log.add("$step. scroll up") }
                    "back" -> { svc.back(); log.add("$step. back") }
                    "home" -> { svc.home(); log.add("$step. home") }
                    "wait" -> { delay(1500); log.add("$step. wait") }
                    "open_app" -> { val n = launchApp(ctx, act.app); log.add("$step. open ${act.app}" + if (n == null) " (not found or not allowed)" else ""); delay(1200) }
                    "ask_user" -> {
                        val a = Workflows.ask(ctx, "$title — need you", act.say.ifBlank { "I need your help on the screen." } + "\n\nDo it on the screen, then tap Continue.", listOf("Continue" to 1, "Stop" to 0))
                        NovaSheet.hide()
                        if (a == 0) { outcome = "Stopped by you."; break }
                        log.add("$step. waited for you")
                    }
                    "done" -> { outcome = "✓ " + act.say.ifBlank { "Done." }; break }
                    "fail" -> { outcome = "✗ " + act.say.ifBlank { "I couldn't do that." }; break }
                    else -> log.add("$step. unknown action ${act.action}")
                }
                delay(PerfProfile.agentStepDelayMs(ctx))
            }
        } finally {
            FloatingOrb.processing = false; FloatingOrb.current?.refresh()
        }
        NovaSheet.show(ctx, "$title — result", outcome + "\n\n" + log.takeLast(12).joinToString("\n"), false, listOf(SheetAction("Close", true) { NovaSheet.hide() }))
        Workflows.History.add(ctx, "Agent: " + goal.take(40), outcome.take(60))
    }
}
