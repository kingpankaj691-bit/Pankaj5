package com.nova.ai.ui

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// ───────────────────────── Design tokens (single source of truth) ─────────────────────────

fun Color.a(x: Float): Color = copy(alpha = x.coerceIn(0f, 1f))

@Immutable
data class GlassTheme(
    val dark: Boolean,
    val accent: Color,
    val blur: Int,
    val transparency: Int,
    val reduced: Boolean,
    val material: Int = 0
) {
    val accent2: Color get() = Color(0xFF8E7CFF)
    val text: Color get() = if (dark) Color(0xFFF2F5FF) else Color(0xFF0B1020)
    val subtext: Color get() = text.a(0.72f)
    val fillAlpha: Float
        get() = if (dark) listOf(0.16f, 0.10f, 0.06f)[transparency.coerceIn(0, 2)]
        else listOf(0.70f, 0.52f, 0.36f)[transparency.coerceIn(0, 2)]
    fun borderBrush(): Brush = when (material) {
        1 -> Brush.linearGradient(listOf(Color.White.a(0.70f), Color.White.a(0.10f), Color.White.a(0.45f)))
        3 -> Brush.linearGradient(listOf(accent.a(0.80f), Color.White.a(0.10f), accent.a(0.55f)))
        else ->
            if (dark) Brush.linearGradient(listOf(Color.White.a(0.42f), Color.White.a(0.06f), accent.a(0.30f)))
            else Brush.linearGradient(listOf(Color.White.a(0.95f), Color.Black.a(0.05f), accent.a(0.35f)))
    }
    fun fillBrush(boost: Float = 1f): Brush = when (material) {
        1 -> Brush.verticalGradient(listOf(Color.White.a(fillAlpha * 0.9f * boost), Color.White.a(fillAlpha * 0.4f * boost)))
        2 -> Brush.linearGradient(listOf(
            Color(0xFFDDE3F0).a(fillAlpha * 2.0f * boost), Color(0xFF7C8AA5).a(fillAlpha * 1.4f * boost), Color(0xFFDDE3F0).a(fillAlpha * 1.6f * boost)))
        3 -> Brush.verticalGradient(listOf(accent.a(fillAlpha * 1.6f * boost), Color.White.a(fillAlpha * 0.6f * boost)))
        else -> Brush.verticalGradient(listOf(Color.White.a(fillAlpha * 1.5f * boost), Color.White.a(fillAlpha * 0.7f * boost)))
    }
}

val LocalGlass = staticCompositionLocalOf { GlassTheme(true, Color(0xFF4FC3F7), 1, 1, false) }

/** Spring motion, or an instant snap when Reduced Motion is on. */
fun <T> GlassTheme.motion(): AnimationSpec<T> =
    if (reduced) snap() else spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)

// ───────────────────────── Background ─────────────────────────

@Composable
fun GlassBackground(tint: Color = Color(0xFF00E5FF), content: @Composable BoxScope.() -> Unit) {
    val g = LocalGlass.current
    val base = if (g.dark) listOf(Color(0xFF04060D), Color(0xFF0A0F26)) else listOf(Color(0xFFE9EFFF), Color(0xFFF4ECFF))
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(base))) {
        val a = if (g.dark) 0.55f else 0.45f
        if (Build.VERSION.SDK_INT >= 31) {
            // Real RenderEffect blur on one static layer (cheap: it never re-renders).
            val radius: Dp = listOf(28, 56, 90)[g.blur.coerceIn(0, 2)].dp
            Canvas(Modifier.fillMaxSize().blur(radius)) { orbs(g, a, true, tint) }
        } else {
            // Fallback: soft radial gradients look blurred without any RenderEffect.
            Canvas(Modifier.fillMaxSize()) { orbs(g, a, false, tint) }
        }
        content()
    }
}

private fun DrawScope.orbs(g: GlassTheme, a: Float, solid: Boolean, tint: Color) {
    val w = size.width
    val h = size.height
    fun orb(c: Color, cx: Float, cy: Float, r: Float) {
        if (solid) drawCircle(c.a(a), r, Offset(cx, cy))
        else drawCircle(Brush.radialGradient(listOf(c.a(a), Color.Transparent), Offset(cx, cy), r * 1.5f), r * 1.5f, Offset(cx, cy))
    }
    orb(g.accent, w * 0.15f, h * 0.18f, w * 0.38f)
    orb(g.accent2, w * 0.90f, h * 0.45f, w * 0.40f)
    orb(tint, w * 0.30f, h * 0.88f, w * 0.34f)
}

// ───────────────────────── Primitives ─────────────────────────

@Composable
fun GText(
    text: String, modifier: Modifier = Modifier, size: TextUnit = 15.sp,
    weight: FontWeight = FontWeight.Normal, color: Color = LocalGlass.current.text,
    maxLines: Int = Int.MAX_VALUE, align: TextAlign? = null
) {
    Text(text, modifier, color = color, fontSize = size, fontWeight = weight, maxLines = maxLines, textAlign = align)
}

@Composable
fun Modifier.pressable(onClick: () -> Unit, enabled: Boolean = true, role: Role? = Role.Button): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val g = LocalGlass.current
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, g.motion(), label = "press")
    return this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClick = onClick)
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    glow: Boolean = false,
    tint: Color = Color.Transparent,
    strong: Boolean = false,
    borderBrush: Brush? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val g = LocalGlass.current
    val sheen = Brush.verticalGradient(0f to Color.White.a(if (g.dark) 0.10f else 0.35f), 0.35f to Color.Transparent)
    val strongBase = if (g.dark) Color(0xFF0B1030).a(0.72f) else Color.White.a(0.80f)
    Box(
        modifier
            .shadow(8.dp, shape, clip = false, ambientColor = Color.Black.a(0.35f), spotColor = if (glow) g.accent else Color.Black.a(0.35f))
            .clip(shape)
            .background(if (strong) strongBase else Color.Transparent)
            .background(g.fillBrush())
            .background(tint)
            .background(sheen)
            .border(1.dp, borderBrush ?: g.borderBrush(), shape),
        content = content
    )
}

@Composable
fun GlassButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    primary: Boolean = false, enabled: Boolean = true, glyph: String? = null
) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(50)
    val bg = if (primary) Brush.verticalGradient(listOf(g.accent.a(0.60f), g.accent.a(0.30f))) else g.fillBrush(1.2f)
    Row(
        modifier.alpha(if (enabled) 1f else 0.4f).pressable(onClick, enabled)
            .heightIn(min = 48.dp).clip(shape).background(bg).border(1.dp, g.borderBrush(), shape)
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph != null) GText("$glyph  ")
        GText(text, weight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun GlassIconButton(glyph: String, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, active: Boolean = false) {
    val g = LocalGlass.current
    Box(
        modifier.size(48.dp).pressable(onClick).clip(CircleShape)
            .background(if (active) SolidColor(g.accent.a(0.35f)) else g.fillBrush(1.2f))
            .border(1.dp, g.borderBrush(), CircleShape).semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { GText(glyph, size = 18.sp) }
}

@Composable
fun GlassTextField(
    value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier,
    placeholder: String = "", singleLine: Boolean = true, minLines: Int = 1,
    visual: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    trailing: (@Composable () -> Unit)? = null
) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(20.dp)
    BasicTextField(
        value = value, onValueChange = onValueChange,
        modifier = modifier.clip(shape).background(g.fillBrush(1.1f)).border(1.dp, g.borderBrush(), shape),
        textStyle = TextStyle(color = g.text, fontSize = 15.sp),
        cursorBrush = SolidColor(g.accent),
        singleLine = singleLine, minLines = minLines,
        visualTransformation = visual, keyboardOptions = keyboardOptions, keyboardActions = keyboardActions,
        decorationBox = { inner ->
            Row(Modifier.heightIn(min = 52.dp).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) GText(placeholder, color = g.subtext.a(0.6f))
                    inner()
                }
                trailing?.invoke()
            }
        }
    )
}

@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    val x by animateDpAsState(if (checked) 22.dp else 0.dp, g.motion(), label = "thumb")
    Box(
        Modifier.sizeIn(minWidth = 56.dp, minHeight = 48.dp).toggleable(
            value = checked, interactionSource = remember { MutableInteractionSource() }, indication = null,
            role = Role.Switch, onValueChange = onChange
        ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(52.dp, 30.dp).clip(CircleShape)
                .background(if (checked) g.accent.a(0.55f) else Color.White.a(0.16f))
                .border(1.dp, g.borderBrush(), CircleShape).padding(3.dp)
        ) {
            Box(Modifier.offset(x = x).size(24.dp).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color.White, Color.White.a(0.75f)))))
        }
    }
}

@Composable
fun GlassSlider(label: String, valueText: String, value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>) {
    val g = LocalGlass.current
    Column {
        Row(Modifier.fillMaxWidth()) {
            GText(label, Modifier.weight(1f))
            GText(valueText, color = g.accent)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            modifier = Modifier.semantics { contentDescription = "$label $valueText" },
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = g.accent,
                inactiveTrackColor = g.text.a(0.18f)
            )
        )
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(50)
    Box(modifier.heightIn(min = 48.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.pressable(onClick, role = Role.RadioButton).clip(shape)
                .background(if (selected) SolidColor(g.accent.a(0.38f)) else g.fillBrush(1.1f))
                .border(1.dp, if (selected) Brush.linearGradient(listOf(g.accent, g.accent2)) else g.borderBrush(), shape)
                .semantics { this.selected = selected }
                .padding(horizontal = 16.dp, vertical = 9.dp)
        ) { GText(text, size = 14.sp, weight = if (selected) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1) }
    }
}

@Composable
fun GlassListItem(
    title: String, subtitle: String? = null, glyph: String? = null,
    onClick: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null
) {
    val m = if (onClick != null) Modifier.pressable(onClick) else Modifier
    Row(m.fillMaxWidth().heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
        if (glyph != null) { GText(glyph, size = 20.sp); Box(Modifier.size(12.dp)) }
        Column(Modifier.weight(1f)) {
            GText(title, weight = FontWeight.Medium)
            if (subtitle != null) GText(subtitle, size = 12.sp, color = LocalGlass.current.subtext)
        }
        if (trailing != null) trailing()
    }
}

@Composable
fun GlassSettingSection(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val g = LocalGlass.current
    Column(modifier.fillMaxWidth()) {
        GText(title.uppercase(), size = 12.sp, weight = FontWeight.SemiBold, color = g.subtext, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
fun GlassPermissionCard(
    name: String, enabled: Boolean, required: Boolean, why: String,
    actions: @Composable RowScope.() -> Unit
) {
    val g = LocalGlass.current
    GlassCard(Modifier.fillMaxWidth(), glow = enabled, tint = if (enabled) g.accent.a(0.06f) else Color.Transparent) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GText(name, Modifier.weight(1f), weight = FontWeight.SemiBold)
                GText(if (required) "Required" else "Optional", size = 11.sp, color = g.subtext)
                Box(Modifier.size(8.dp))
                GText(if (enabled) "● Enabled" else "● Disabled", size = 12.sp,
                    color = if (enabled) Color(0xFF69F0AE) else Color(0xFFFF8A80))
            }
            GText(why, size = 12.sp, color = g.subtext)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
        }
    }
}

// ───────────────────────── Dialog & sheet ─────────────────────────

@Composable
fun GlassDialog(
    onDismiss: () -> Unit, title: String,
    confirmText: String? = null, onConfirm: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        GlassCard(Modifier.fillMaxWidth(0.9f).widthIn(max = 440.dp), shape = RoundedCornerShape(28.dp), strong = true, glow = true) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                GText(title, size = 19.sp, weight = FontWeight.SemiBold)
                content()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                    GlassButton(if (confirmText == null) "Close" else "Cancel", onDismiss)
                    if (confirmText != null && onConfirm != null) GlassButton(confirmText, { onConfirm(); onDismiss() }, primary = true)
                }
            }
        }
    }
}

@Composable
fun GlassSheet(onDismiss: () -> Unit, title: String, content: @Composable ColumnScope.() -> Unit) {
    val g = LocalGlass.current
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visibleState = state,
                enter = if (g.reduced) fadeIn(snap()) else slideInVertically(animationSpec = spring(0.8f, Spring.StiffnessLow), initialOffsetY = { it }) + fadeIn()
            ) {
                GlassCard(
                    Modifier.fillMaxWidth().widthIn(max = 640.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {}),
                    shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp), strong = true
                ) {
                    Column(
                        Modifier.heightIn(max = 600.dp).navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.align(Alignment.CenterHorizontally).size(40.dp, 4.dp).clip(CircleShape).background(g.text.a(0.3f)))
                        GText(title, size = 19.sp, weight = FontWeight.SemiBold)
                        content()
                        GlassButton("Done", onDismiss, Modifier.fillMaxWidth(), primary = true)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Navigation ─────────────────────────

@Composable
fun GlassBottomBar(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    GlassCard(modifier.fillMaxWidth().widthIn(max = 520.dp), shape = RoundedCornerShape(32.dp), strong = true) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

@Composable
fun GlassNavigationBar(items: List<Pair<String, String>>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    GlassBottomBar(modifier) {
        items.forEachIndexed { i, (glyph, label) ->
            val sel = i == selected
            val k by animateFloatAsState(if (sel) 1f else 0f, g.motion(), label = "tab")
            Column(
                Modifier.weight(1f).heightIn(min = 56.dp).clip(RoundedCornerShape(24.dp))
                    .drawBehind { drawRoundRect(g.accent.a(0.30f * k), cornerRadius = androidx.compose.ui.geometry.CornerRadius(24.dp.toPx())) }
                    .pressable({ onSelect(i) }, role = Role.Tab)
                    .semantics { contentDescription = label; this.selected = sel },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                GText(glyph, size = 19.sp, modifier = Modifier.alpha(0.65f + 0.35f * k).graphicsLayer { scaleX = 1f + 0.12f * k; scaleY = 1f + 0.12f * k })
                GText(label, size = 11.sp, weight = if (sel) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}
