package com.nova.ai.forge

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.nova.ai.ui.GText
import com.nova.ai.ui.GlassButton
import com.nova.ai.ui.GlassCard
import com.nova.ai.ui.GlassDialog
import com.nova.ai.ui.GlassIconButton
import com.nova.ai.ui.GlassListItem
import com.nova.ai.ui.GlassSheet
import com.nova.ai.ui.GlassTextField
import com.nova.ai.ui.LocalGlass
import com.nova.ai.ui.a
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

/** Full-screen Forge: live build scene while BUILDING, the finished site when DONE. Uses the app's liquid glass components. */
@Composable
fun ForgeOverlay(onClose: () -> Unit) {
    val s by ForgeController.state.collectAsState()
    val g = LocalGlass.current
    val ctx = LocalContext.current
    DisposableEffect(Unit) { ForgeController.screenVisible = true; onDispose { ForgeController.screenVisible = false } }
    BackHandler { if (s.phase == ForgePhase.BUILDING) ForgeController.cancel() else onClose() }
    val low = remember { (ctx.getSystemService(android.app.ActivityManager::class.java)?.isLowRamDevice) == true }
    Box(Modifier.fillMaxSize().background(if (g.dark) Color(0xFF050816) else Color(0xFFEFF3FF))) {
        when (s.phase) {
            ForgePhase.DONE -> ResultView(s, low, onClose)
            else -> BuildView(s, low, onClose)
        }
    }
}

// ───────────────────────── build view ─────────────────────────

@Composable
private fun BuildView(s: ForgeUiState, low: Boolean, onClose: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(s.stage) { if (s.phase == ForgePhase.BUILDING && s.stage != ForgeStage.PLANNING) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    // partial preview: at most every 1.5 s after >= 4 KB of growth (skipped on low-RAM phones)
    var preview by remember { mutableStateOf("") }
    LaunchedEffect(s.buildId, s.phase) {
        var lastLen = 0
        while (!low && s.phase == ForgePhase.BUILDING) {
            val p = ForgeController.partialHtml()
            if (p.length - lastLen >= 4096 && ForgeHtml.looksLikeHtml(p)) { preview = ForgeHtml.repairTruncated(p); lastLen = p.length }
            delay(1500)
        }
    }
    Box(Modifier.fillMaxSize()) {
        ForgeFallbackScene(s)
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
                GText(s.prompt, Modifier.padding(horizontal = 18.dp, vertical = 12.dp), size = 13.sp, maxLines = 2, color = g.subtext)
            }
            if (preview.isNotEmpty() && s.phase == ForgePhase.BUILDING) {
                Box(Modifier.fillMaxWidth().height(180.dp).border(1.dp, g.borderBrush(), RoundedCornerShape(20.dp))) { GeneratedSiteView(preview, Modifier.fillMaxSize()) }
            }
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), glow = true, strong = true) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when (s.phase) {
                        ForgePhase.FAILED -> {
                            GText("The build stopped", weight = FontWeight.SemiBold, size = 18.sp)
                            GText(s.error ?: "Something went wrong.", color = g.subtext)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton("Retry", { ForgeController.retry(ctx) }, primary = true)
                                GlassButton("Close", { ForgeController.reset(); onClose() })
                            }
                        }
                        ForgePhase.CANCELLED -> {
                            GText("Build cancelled", weight = FontWeight.SemiBold, size = 18.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton("Start again", { ForgeController.retry(ctx) }, primary = true)
                                GlassButton("Close", { ForgeController.reset(); onClose() })
                            }
                        }
                        else -> {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                GText(s.stage.label, Modifier.semantics { liveRegion = LiveRegionMode.Polite }, size = 20.sp, weight = FontWeight.SemiBold)
                                GText("${(s.progress * 100).toInt()}%", size = 34.sp, weight = FontWeight.Bold, color = g.accent)
                            }
                            StageTrack(s.stage)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Stat("${s.metrics.chars / 1024} KB"); Stat("${s.metrics.sections} sections")
                                Stat("${s.metrics.tokensPerSec} tok/s"); Stat("${s.metrics.elapsedSec}s")
                            }
                            s.log.lastOrNull()?.let { GText(it, size = 12.sp, color = g.subtext, maxLines = 1) }
                            GlassButton("Cancel", { ForgeController.cancel() }, Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Stat(t: String) = GText(t, size = 12.sp, color = LocalGlass.current.subtext)

@Composable
private fun StageTrack(stage: ForgeStage) {
    val g = LocalGlass.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ForgeStage.values().forEach { st ->
            Box(Modifier.weight(1f).height(6.dp).background(if (st.ordinal <= stage.ordinal) g.accent else g.text.a(0.18f), RoundedCornerShape(50)))
        }
    }
}

/** The Compose Canvas build scene: a glowing core, orbiting glyphs, and a ring of stage nodes. Driven by the same state; also the WebGL fallback. */
@Composable
fun ForgeFallbackScene(s: ForgeUiState) {
    val g = LocalGlass.current
    val t = if (g.reduced) 0f else {
        val inf = rememberInfiniteTransition(label = "forge")
        val v by inf.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "spin")
        v
    }
    val accent = g.accent; val accent2 = g.accent2
    Canvas(Modifier.fillMaxSize()) {
        val c = Offset(size.width / 2f, size.height * 0.36f)
        val r = size.minDimension * 0.16f
        val pulse = 1f + 0.06f * sin(t * 2)
        drawCircle(accent.a(0.10f), r * 3.2f * pulse, c)
        drawCircle(accent.a(0.22f), r * 1.9f * pulse, c)
        drawCircle(accent.a(0.85f), r * pulse, c)
        drawCircle(Color.White.a(0.35f), r * 0.45f, c - Offset(r * 0.25f, r * 0.25f))
        for (i in 0 until 24) {
            val a = t + i * 0.2618f
            val rr = r * (1.7f + 0.9f * ((i * 7) % 5) / 5f)
            drawCircle(accent2.a(0.6f), 3.5f + (i % 3), Offset(c.x + cos(a) * rr, c.y + sin(a) * rr * 0.55f))
        }
        val ringR = size.minDimension * 0.36f
        ForgeStage.values().forEach { st ->
            val a = -1.5708f + st.ordinal * 1.0471976f
            val on = st.ordinal <= s.stage.ordinal && s.phase == ForgePhase.BUILDING
            drawCircle(if (on) accent else Color.White.a(0.25f), if (on) 9f else 6f, Offset(c.x + cos(a) * ringR, c.y + sin(a) * ringR * 0.55f))
        }
    }
}

// ───────────────────────── generated site ─────────────────────────

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GeneratedSiteView(html: String, modifier: Modifier = Modifier, onPainted: () -> Unit = {}) {
    val ctx = LocalContext.current
    AndroidView(modifier = modifier, factory = { c ->
        WebView(c).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true                  // the generated page needs JS; NO JavascriptInterface is ever added
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            settings.setGeolocationEnabled(false)
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val u = r.url.toString()
                    if (u.startsWith("https://localhost/")) return false
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, r.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                    return true
                }
                override fun onPageFinished(v: WebView, url: String?) { onPainted() }
            }
        }
    }, update = { w ->
        if (w.tag != html.hashCode()) { w.tag = html.hashCode(); w.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null) }
    }, onRelease = { w -> w.stopLoading(); w.destroy() })
}

// ───────────────────────── result ─────────────────────────

@Composable
private fun ResultView(s: ForgeUiState, low: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val html = remember(s.buildId, s.file) { s.file?.let { try { it.readText() } catch (e: Exception) { null } } ?: ForgeController.partialHtml() }
    var painted by remember(s.buildId) { mutableStateOf(false) }
    var toolbar by remember { mutableStateOf(true) }
    var tick by remember { mutableStateOf(0) }
    var showEdit by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var editText by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(s.buildId) { delay(2500); painted = true }          // reveal after it has painted, at most 2.5 s
    LaunchedEffect(toolbar, tick) { if (toolbar) { delay(4000); toolbar = false } }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray()) }; msg = "Saved." } catch (e: Exception) { msg = "Couldn't save." }
    }
    fun uriFor(f: File) = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    Box(Modifier.fillMaxSize()) {
        GeneratedSiteView(html, Modifier.fillMaxSize(), onPainted = { painted = true })
        if (!painted) ForgeFallbackScene(s)                                // plain overlay (no graphicsLayer around the WebView)
        Box(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp)) {
            GlassIconButton("⋯", "Show website menu", { toolbar = true; tick++ })
        }
        if (toolbar) {
            GlassCard(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp), shape = RoundedCornerShape(50), strong = true) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton("←", "Back", { ForgeController.reset(); onClose() })
                    GlassIconButton("⤴", "Share", {
                        s.file?.let { f -> ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/html").putExtra(Intent.EXTRA_STREAM, uriFor(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share website")) }
                        tick++ })
                    GlassIconButton("💾", "Save to device", { save.launch("website.html"); tick++ })
                    GlassIconButton("🌐", "Open in browser", {
                        s.file?.let { f -> try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(f), "text/html").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (e: Exception) { msg = "No browser can open this file." } }
                        tick++ })
                    GlassIconButton("✎", "Edit with text", { showEdit = true })
                    GlassIconButton("↻", "Rebuild", { ForgeController.retry(ctx); tick++ })
                    GlassIconButton("📁", "My websites", { showList = true })
                    GlassIconButton("🗑", "Delete", { showDelete = true })
                }
            }
        }
        if (msg.isNotBlank()) GText(msg, Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(20.dp), size = 13.sp, color = g.accent)
    }
    if (showEdit) GlassDialog({ showEdit = false }, "Edit this website", "Apply", { val r = ForgeController.edit(ctx, editText); if (r !is ForgeStart.Started) msg = r.message; editText = "" }) {
        GText("Describe the change, e.g. \"make the hero darker and add a pricing section\".", size = 13.sp, color = g.subtext)
        GlassTextField(editText, { editText = it }, Modifier.fillMaxWidth(), placeholder = "What should change?", singleLine = false, minLines = 3)
    }
    if (showDelete) GlassDialog({ showDelete = false }, "Delete this website?", "Delete", { s.file?.let { ForgeController.delete(it) }; onClose() }) {
        GText("The saved file will be removed from this phone.")
    }
    if (showList) {
        val files = remember(showList, s.buildId) { ForgeController.saved(ctx) }
        GlassSheet({ showList = false }, "My websites") {
            if (files.isEmpty()) GText("No saved websites yet.", color = g.subtext)
            files.forEach { f ->
                GlassListItem(f.nameWithoutExtension, "${f.length() / 1024} KB", "🌐", onClick = { ForgeController.openSaved(f); showList = false },
                    trailing = { GlassIconButton("🗑", "Delete ${f.nameWithoutExtension}", { ForgeController.delete(f); showList = false }) })
            }
        }
    }
}
