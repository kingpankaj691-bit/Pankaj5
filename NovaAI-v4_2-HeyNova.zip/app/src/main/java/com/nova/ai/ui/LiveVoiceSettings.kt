package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.live.LivePrefs
import com.nova.ai.live.LiveSession

/** Settings for the two-way (Gemini Live) voice: assistant name, voice, mute, 3D effects, and the access key (direct build only). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveVoiceSettings() {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var name by remember { mutableStateOf(LivePrefs.assistantName(ctx)) }
    var voice by remember { mutableStateOf(LivePrefs.voiceName(ctx)) }
    var fx by remember { mutableStateOf(LivePrefs.fx3d(ctx)) }
    var lite by remember { mutableStateOf(LivePrefs.orbLite(ctx)) }
    val muted by LiveSession.muted.collectAsState()
    val active by LiveSession.isActive.collectAsState()
    GlassSettingSection("Two-way voice (Gemini Live)") {
        GText("Select \"Two-way voice\" in Speech recognition below. Changes apply to a running conversation right away.", size = 12.sp, color = g.subtext)
        GText("Assistant name", size = 13.sp)
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Nova")
        GlassButton("Save name", { LivePrefs.setAssistantName(ctx, name) }, Modifier.fillMaxWidth())
        GText("Voice", size = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LivePrefs.VOICES.forEach { v -> GlassChip(v, voice == v, { voice = v; LivePrefs.setVoiceName(ctx, v) }) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            GText("Mute microphone" + if (!active) " (when a session is running)" else "", Modifier.weight(1f), size = 14.sp)
            GlassSwitch(muted, { LiveSession.toggleMute() })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            GText("3D orb, 3D intro and edge glow (restart the app to apply)", Modifier.weight(1f), size = 14.sp)
            GlassSwitch(fx, { fx = it; LivePrefs.setFx3d(ctx, it) })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            GText("Galaxy Orb: reduced effects (fewer particles, 20 fps, saves battery; reopen Home to apply)", Modifier.weight(1f), size = 14.sp)
            GlassSwitch(lite, { lite = it; LivePrefs.setOrbLite(ctx, it) })
        }
    }
    com.nova.ai.license.AccessKeySection()
}
