package com.nova.ai.security

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** The real authentication for sensitive actions: Android BiometricPrompt (fingerprint/face or screen lock). */
object SecurityGate {
    private fun authenticators() =
        if (Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        else BiometricManager.Authenticators.BIOMETRIC_WEAK

    fun canBiometric(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(authenticators()) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(activity: FragmentActivity, title: String, onResult: (Boolean) -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val bp = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true) }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode == BiometricPrompt.ERROR_LOCKOUT || errorCode == BiometricPrompt.ERROR_LOCKOUT_PERMANENT)
                    SecurityEvents.recordFailedAuth(activity.applicationContext, "Too many wrong attempts, Android locked the prompt.")
                onResult(false)
            }
            override fun onAuthenticationFailed() { SecurityEvents.recordFailedAuth(activity.applicationContext, "A fingerprint or face was not recognised.") }
        })
        val b = BiometricPrompt.PromptInfo.Builder().setTitle("NOVA").setSubtitle(title).setAllowedAuthenticators(authenticators())
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancel")
        bp.authenticate(b.build())
    }
}
