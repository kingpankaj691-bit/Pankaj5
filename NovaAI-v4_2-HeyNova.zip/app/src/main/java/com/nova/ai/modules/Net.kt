package com.nova.ai.modules

import android.util.Base64
import com.nova.ai.ai.GeminiHttp
import com.nova.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Net {
    suspend fun getJson(url: String): JSONObject? = withContext(Dispatchers.IO) {
        var c: HttpURLConnection? = null
        try {
            c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 12000; readTimeout = 15000 }
            if (c.responseCode !in 200..299) null else JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } catch (e: Exception) { null } finally { c?.disconnect() }
    }

    /** POSTs JSON to a user-configured endpoint. Returns (ok, text). */
    suspend fun postJson(url: String, token: String, body: JSONObject): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        var c: HttpURLConnection? = null
        try {
            if (!url.startsWith("https://") && !url.startsWith("http://")) return@withContext false to "The endpoint address must start with http:// or https://."
            c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 8000; readTimeout = 15000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
            }
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            (code in 200..299) to (if (txt.isBlank()) "HTTP $code" else txt.take(300))
        } catch (e: Exception) { false to "Couldn't reach the endpoint: ${e.message}" } finally { c?.disconnect() }
    }
}

/** One-shot Gemini text/multimodal task used by Study, Travel, Translation, Image, PDF modules. */
class GeminiTask(private val prefs: Prefs) {
    suspend fun run(system: String, user: String, data: ByteArray? = null, mime: String = "image/jpeg", maxTokens: Int = 0): String {
        val parts = JSONArray().put(JSONObject().put("text", user))
        if (data != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", mime).put("data", Base64.encodeToString(data, Base64.NO_WRAP))))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", if (maxTokens > 0) maxTokens else prefs.maxTokens.coerceAtLeast(700)))
        val out = GeminiHttp.post(prefs, body, readTimeoutMs = 90000)
        val j = out.json ?: return "⚠ " + (out.error ?: "Request failed.")
        return GeminiHttp.textOf(j).ifBlank { "⚠ The AI returned an empty answer." }
    }
}
