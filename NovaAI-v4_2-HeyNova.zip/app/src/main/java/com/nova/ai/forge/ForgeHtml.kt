package com.nova.ai.forge

/** Helpers for the HTML the model streams back. Pure Kotlin. */
object ForgeHtml {
    const val SAFETY_MARK = "data-forge-safety"

    fun stripFences(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) {
            val nl = t.indexOf('\n')
            t = if (nl >= 0) t.substring(nl + 1) else t.removePrefix("```")
        }
        if (t.trimEnd().endsWith("```")) t = t.trimEnd().removeSuffix("```")
        return t.trim()
    }

    fun looksLikeHtml(s: String): Boolean {
        val l = s.lowercase()
        return l.contains("<html") || l.contains("<!doctype html") || (l.contains("<body") && l.contains("<"))
    }

    /** Closes whatever a cut-off page left open: script, style, body, html. A complete page is returned unchanged. */
    fun repairTruncated(s: String): String {
        if (s.contains("</html>", ignoreCase = true)) return s
        val sb = StringBuilder(s)
        val l = s.lowercase()
        if (l.lastIndexOf("<script") > l.lastIndexOf("</script>")) sb.append("\n</script>")
        if (l.lastIndexOf("<style") > l.lastIndexOf("</style>")) sb.append("\n</style>")
        if (!l.contains("</body>")) sb.append("\n</body>")
        sb.append("\n</html>")
        return sb.toString()
    }

    private const val NET = """<script $SAFETY_MARK>(function(){setTimeout(function(){try{var vh=window.innerHeight,vw=window.innerWidth;
var all=document.body?document.body.querySelectorAll('*'):[];
for(var i=0;i<all.length;i++){var e=all[i],t=e.tagName;
if(t==='CANVAS'||t==='SCRIPT'||t==='STYLE'||t==='svg'||e.getAttribute('aria-hidden')==='true')continue;
var cs=getComputedStyle(e);
if(cs.position==='fixed'||cs.pointerEvents==='none')continue;
if(parseFloat(cs.opacity)>0.01)continue;
var r=e.getBoundingClientRect();
if(r.bottom<0||r.top>vh||r.right<0||r.left>vw||r.width===0||r.height===0)continue;
e.style.transition='opacity .5s ease';e.style.opacity='1';if(cs.transform&&cs.transform!=='none'){e.style.transform='none';}}
}catch(x){}},1400);})();</script>"""

    /** Adds a script that fades in content stuck at opacity 0 inside the viewport. Idempotent. */
    fun withSafetyNet(html: String): String {
        if (html.contains(SAFETY_MARK)) return html
        val i = html.lastIndexOf("</body>", ignoreCase = true)
        return if (i >= 0) html.substring(0, i) + NET + "\n" + html.substring(i) else html + "\n" + NET
    }
}
