package com.nova.ai.jarvis

import android.content.Context
import android.util.Base64
import com.nova.ai.ai.model.LiveModality
import com.nova.ai.ai.model.LiveModalityPolicy
import com.nova.ai.ai.model.ModelManager
import com.nova.ai.live.LiveErrors
import com.nova.ai.live.transcriptionSetupMessage
import com.nova.ai.security.Prefs
import com.nova.ai.voice.PcmFormat
import com.nova.ai.voice.SpeechProcessingEngine
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Real-time speech-to-text over the Gemini Live API (dedicated transcription model, WebSocket).
 * Raw 16-bit PCM is streamed in 100 ms chunks as it is captured and finished sentences come back within a moment,
 * so there are no 5-second clips. Segmentation of speech into sentences is done by Google's server, not on the phone.
 *
 * A Live transcription session lasts at most 10 minutes, so the connection is renewed every 9 minutes (and after any drop).
 */
class LiveSpeechEngine(
    private val prefs: Prefs,
    private val jp: JarvisPrefs,
    private val onText: (String) -> Unit,
    private val onProblem: (String) -> Unit,
    private val ctx: Context? = null
) : SpeechProcessingEngine {

    private companion object {
        const val MAX_RECONNECTS = 8
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var ws: WebSocket? = null
    @Volatile private var ready = false
    @Volatile private var stopped = true
    @Volatile private var generation = 0
    private var format = PcmFormat(16000, 1)
    private var scope: CoroutineScope? = null
    private var timer: Job? = null
    private var retry = 0
    /** Set by errors that reconnecting cannot fix (bad key, unknown model, refused modality). Cleared by start(). */
    @Volatile private var permanent = false
    /** The transcription model and response modality of the CURRENT connection (so error messages name the real model). */
    @Volatile private var activeModel = ""
    @Volatile private var activeModality = LiveModality.TEXT
    private var modalityFlipTried = false

    /**
     * Live speech recognition needs a *transcription* Live model (responseModalities TEXT). A conversational Live model such as
     * gemini-3.8-live only accepts AUDIO, so using it here is exactly what produced "error 1007 ... response modalities (TEXT)".
     * The answering model is never involved in speech recognition.
     */
    private fun transcriptionModel(): String? {
        val c = ctx
        return if (c != null) ModelManager.transcriptionModel(c, jp.liveModel)
        else jp.liveModel.takeIf { it.contains("transcribe", ignoreCase = true) }
    }

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        this.format = format
        this.scope = scope
        stopped = false
        permanent = false
        modalityFlipTried = false
        retry = 0
        connect()
    }

    private fun connect() {
        if (stopped) return
        val key = prefs.apiKey
        if (prefs.localOnly) { onProblem("Local-only mode is on, so live speech recognition is off."); return }
        if (!prefs.aiEnabled) { onProblem("AI is disabled in Settings."); return }
        if (key.isBlank()) { onProblem("No Gemini API key set. Add one in Settings."); return }
        val model = transcriptionModel()
        if (model == null) {
            permanent = true
            onProblem("No Gemini speech-recognition (transcribe) model is available for your key. Use Offline or 5-second clips in Jarvis settings, or refresh the model list.")
            return
        }
        val modality = ctx?.let { ModelManager.learnedTranscribeModality(it, model) } ?: LiveModality.TEXT
        activeModel = model
        activeModality = modality
        val gen = ++generation
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ready = false
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(transcriptionSetupMessage(model, modality).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) { if (gen == generation) handle(text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { if (gen == generation) handle(bytes.utf8()) }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen != generation) return
                ready = false
                if (code == 1000) { reconnect(); return }                       // planned renewal
                if (LiveModalityPolicy.isModalityRejection(code, reason)) { onModalityRefused(reason); return }
                val c = LiveErrors.classify(null, code, reason)
                onProblem("Live speech recognition closed ($code). ${c.message}")
                if (c.fatal) permanent = true else reconnect()
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen != generation) return
                ready = false
                val http = response?.code
                if (http != null) {
                    val c = LiveErrors.classify(http, null, "")
                    onProblem("Live speech recognition could not start (HTTP $http). ${c.message}")
                    if (c.fatal) { permanent = true; return }
                } else {
                    val why = t.message ?: "network error"
                    onProblem(if (t is java.net.UnknownHostException) "No internet connection for live speech recognition." else "Live speech recognition lost connection: $why")
                }
                reconnect()
            }
        })
    }

    /**
     * 1007: the server refuses the response modality. For an unknown model the other single modality is tried ONCE and remembered;
     * if that is refused too, recognition stops with a clear message instead of retrying forever.
     */
    private fun onModalityRefused(reason: String) {
        val c = ctx
        val tried = LiveModalityPolicy.triedModality(reason) ?: activeModality
        if (c != null && !modalityFlipTried) {
            modalityFlipTried = true
            ModelManager.learnTranscribeModality(c, activeModel, tried.flipped())
            onProblem("$activeModel refused $tried responses; trying ${tried.flipped()} once.")
            reconnectNow()
            return
        }
        permanent = true
        onProblem("$activeModel does not accept the response type Nova needs for speech recognition (error 1007). " +
            "Choose a different speech-recognition model in Jarvis settings, or use Offline / 5-second clips.")
    }

    private fun handle(raw: String) {
        val j = try { JSONObject(raw) } catch (e: Exception) { return }
        if (j.has("setupComplete")) {
            ready = true; retry = 0
            onProblem("")
            val s = scope ?: return
            timer?.cancel()
            timer = s.launch { delay(9 * 60_000L); if (isActive) { ws?.close(1000, "renew"); } }   // 10-minute session limit
            return
        }
        if (j.has("goAway")) { try { ws?.close(1000, "renew") } catch (e: Exception) { }; return }     // server is about to end the session
        j.optJSONObject("error")?.let { onProblem("Live speech recognition error: " + it.optString("message").take(120)); return }
        val sc = j.optJSONObject("serverContent") ?: return
        sc.optJSONObject("interimInputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { VoiceState.heard.value = "… " + it.trim() }
        val fin = sc.optJSONObject("inputTranscription")?.optString("text")?.trim().orEmpty()
        if (fin.isNotEmpty()) {
            if (VoiceState.speaking.value && jp.interrupt && !isEcho(fin)) VoiceState.interruptSpeech()
            if (!(VoiceState.speaking.value && isEcho(fin))) onText(fin)
        }
    }

    /** True when the heard text is just Nova's own last sentence coming back through the microphone. */
    private fun isEcho(t: String): Boolean {
        val said = VoiceState.lastSpoken
        val h = t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), "").trim()
        return said.isNotEmpty() && h.length > 3 && said.replace(Regex("[^\\p{L}\\p{N} ]"), "").contains(h)
    }

    private fun reconnect() {
        if (stopped || permanent) return
        val s = scope ?: return
        retry++
        if (retry > MAX_RECONNECTS) {
            permanent = true
            onProblem("Live speech recognition could not reconnect after $MAX_RECONNECTS tries. Check your internet connection, then turn the microphone off and on.")
            return
        }
        val exp = minOf(30_000L, 1_000L shl (retry - 1).coerceIn(0, 5))
        val wait = exp / 2 + kotlin.random.Random.nextLong(exp / 2 + 1)        // exponential back-off with jitter
        s.launch { delay(wait); if (!stopped && !permanent) connect() }
    }

    private fun reconnectNow() {
        val s = scope ?: return
        s.launch { if (!stopped) connect() }
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        if (!ready) return
        if (VoiceState.speaking.value && !jp.interrupt) return          // do not transcribe Nova's own voice
        val socket = ws ?: return
        if (socket.queueSize() > 1_000_000L) return                      // network is behind: drop instead of piling up RAM
        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("data", Base64.encodeToString(audioData, 0, length, Base64.NO_WRAP))
            .put("mimeType", "audio/pcm;rate=${format.sampleRate}")))
        socket.send(msg.toString())
    }

    override fun stop() {
        stopped = true
        generation++
        ready = false
        timer?.cancel(); timer = null
        try { ws?.close(1000, "bye") } catch (e: Exception) { }
        ws = null
        scope = null
    }
}
