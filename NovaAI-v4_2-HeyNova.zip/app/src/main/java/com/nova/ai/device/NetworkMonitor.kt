package com.nova.ai.device

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class NetStatus(val online: Boolean, val type: String, val validated: Boolean, val downKbps: Int)

/**
 * Online/offline, connection type and an on-demand latency check. Latency is measured with three small HTTPS requests,
 * only when asked, and never in a loop. It tells you how fast the internet is, not how any particular game server is doing.
 */
class NetworkMonitor(ctx: Context) {
    private val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var callback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var measuring = false
    @Volatile var lastLatencyMs: Int? = null
        private set

    companion object {
        @Volatile private var inst: NetworkMonitor? = null
        /** One shared instance so the last latency result survives between commands. */
        fun shared(ctx: Context): NetworkMonitor = inst ?: synchronized(this) { inst ?: NetworkMonitor(ctx).also { inst = it } }

        /** The connectivity-check address Android itself uses; it returns an empty 204 response. */
        const val PROBE_URL = "https://connectivitycheck.gstatic.com/generate_204"
        private val client by lazy {
            OkHttpClient.Builder().callTimeout(5, TimeUnit.SECONDS).connectTimeout(4, TimeUnit.SECONDS).build()
        }
    }

    fun status(): NetStatus {
        val n = cm.activeNetwork ?: return NetStatus(false, "none", false, 0)
        val c = cm.getNetworkCapabilities(n) ?: return NetStatus(false, "none", false, 0)
        val type = when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "unknown"
        }
        return NetStatus(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET), type,
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED), c.linkDownstreamBandwidthKbps)
    }

    /** Calls [onChange] with true/false whenever the default network appears or disappears. */
    fun start(onChange: (Boolean) -> Unit) {
        if (callback != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { onChange(true) }
            override fun onLost(network: Network) { onChange(false) }
        }
        try { cm.registerDefaultNetworkCallback(cb); callback = cb } catch (e: Exception) { }
    }

    fun stop() {
        callback?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) { } }
        callback = null
    }

    /** Starts one background measurement (3 requests, averaged). Returns immediately; read [lastLatencyMs] a few seconds later. */
    fun measureAsync() {
        if (measuring) return
        measuring = true
        Thread {
            try {
                val times = ArrayList<Long>()
                repeat(3) {
                    val t0 = System.nanoTime()
                    try {
                        client.newCall(Request.Builder().url(PROBE_URL).head().build()).execute().use { }
                        times.add((System.nanoTime() - t0) / 1_000_000)
                    } catch (e: Exception) { }
                }
                lastLatencyMs = if (times.isEmpty()) null else times.average().toInt()
            } finally { measuring = false }
        }.start()
    }

    fun isMeasuring() = measuring

    fun describe(): String {
        val s = status()
        if (!s.online) return "You're offline right now. Local commands still work."
        val lat = lastLatencyMs
        val q = when {
            !s.validated -> "Connected, but Android could not confirm real internet access."
            lat == null -> "Connection looks fine."
            lat < 100 -> "Connection stable hai. Latency approximately $lat ms."
            lat < 300 -> "Connection is okay. Latency approximately $lat ms."
            else -> "Connection is slow. Latency approximately $lat ms."
        }
        return "Online on ${s.type}. $q"
    }
}
