package com.nova.ai.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.nova.ai.people.IntroOutcome
import com.nova.ai.people.PersonMemoryEntity
import com.nova.ai.people.PersonWithData
import com.nova.ai.people.RelationshipType
import com.nova.ai.security.SecurityGate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(ms: Long) = if (ms <= 0) "never" else SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))

@Composable
fun PeopleScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val list by vm.people.people.collectAsState()
    var unlocked by remember { mutableStateOf(!vm.prefs.ownerMode) }
    var detailId by rememberSaveable { mutableStateOf(-1L) }
    var addSheet by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var deleteAll by remember { mutableStateOf(false) }
    var forgetTarget by remember { mutableStateOf<PersonWithData?>(null) }
    var mergePair by remember { mutableStateOf<Pair<PersonWithData, PersonWithData>?>(null) }
    var needsMerge by remember { mutableStateOf<IntroOutcome.NeedsMerge?>(null) }
    var dismissed by remember { mutableStateOf(setOf<String>()) }
    var exportText by remember { mutableStateOf("") }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            msg = try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(exportText.toByteArray()) }; "Exported to the file you chose." } catch (e: Exception) { "Export failed." }
        }
        exportText = ""
    }
    BackHandler(enabled = detailId >= 0) { detailId = -1 }
    val detail = list.firstOrNull { it.person.personId == detailId }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", { if (detail != null) detailId = -1 else onBack() })
            Column {
                GText("People & Memory", size = 22.sp, weight = FontWeight.SemiBold)
                GText("Only people you introduce. Stored on this phone.", size = 11.sp, color = g.subtext)
            }
        }
        if (!unlocked) {
            val act = ctx as? FragmentActivity
            val bio = act != null && SecurityGate.canBiometric(ctx)
            GlassCard(Modifier.fillMaxWidth(), glow = true) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GText("Protected by Owner Mode", weight = FontWeight.SemiBold)
                    GText("People details are private. Unlock to continue.", size = 12.sp, color = g.subtext)
                    if (bio && act != null) GlassButton("Unlock with fingerprint / screen lock", { SecurityGate.prompt(act, "Open People & Memory") { ok -> if (ok) unlocked = true } }, Modifier.fillMaxWidth(), primary = true)
                    else GlassButton("Confirm and open", { unlocked = true }, Modifier.fillMaxWidth(), primary = true)
                }
            }
        } else if (detail != null) {
            PersonDetail(vm, detail) { detailId = -1 }
        } else {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    GText("${list.size} ${if (list.size == 1) "person" else "people"} saved", weight = FontWeight.SemiBold)
                    GText("Tell Nova things like \"Ye meri mummy hain, naam Sunita hai\" or add people here. Nova never guesses who someone is.", size = 12.sp, color = g.subtext)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Add person", { addSheet = true }, primary = true, glyph = "＋")
                        GlassButton("Export local data", { exportText = vm.people.exportJson(); exporter.launch("nova-people.json") })
                        GlassButton("Delete all people memory", { deleteAll = true })
                    }
                    if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.accent)
                }
            }
            val dups = remember(list) { vm.people.resolver.duplicates(list) }.filter { "${it.first.person.personId}-${it.second.person.personId}" !in dismissed }
            dups.forEach { (a, b) ->
                GlassCard(Modifier.fillMaxWidth(), tint = g.accent.a(0.08f)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GText("Possible duplicate", weight = FontWeight.SemiBold)
                        GText("${a.person.name} (${a.person.relLabel}) and ${b.person.name} (${b.person.relLabel}) may be the same person. Nothing is merged unless you say so.", size = 12.sp, color = g.subtext)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Merge", { mergePair = a to b }, primary = true)
                            GlassButton("Keep separate", { dismissed = dismissed + "${a.person.personId}-${b.person.personId}" })
                        }
                    }
                }
            }
            GlassSettingSection("Relationship graph") {
                GText(vm.people.graph.render(list), size = 13.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
            }
            if (list.isEmpty()) GText("No people yet.", size = 13.sp, color = g.subtext)
            list.forEach { pw ->
                val p = pw.person
                GlassCard(Modifier.fillMaxWidth().pressable({ detailId = p.personId }), shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(g.accent.a(0.30f)), contentAlignment = Alignment.Center) {
                            GText(p.name.take(1).uppercase(), size = 20.sp, weight = FontWeight.Bold)
                        }
                        Column(Modifier.weight(1f)) {
                            GText("👤 ${p.name}", weight = FontWeight.SemiBold)
                            GText("${p.relLabel} • ${p.category}", size = 12.sp, color = g.subtext)
                            GText("Last used ${fmt(p.lastInteraction)} • ${vm.people.confidence.effective(p.confidence, p.userConfirmed, p.createdAt, p.lastInteraction).name.lowercase()} confidence", size = 11.sp, color = g.subtext)
                        }
                        Column {
                            SmallAction("Edit", "Edit ${p.name}") { detailId = p.personId }
                            SmallAction("Forget", "Forget ${p.name}") { forgetTarget = pw }
                        }
                    }
                }
            }
        }
    }

    if (addSheet) AddPersonSheet(vm, { addSheet = false }, { m -> msg = m }, { needsMerge = it })
    forgetTarget?.let { t ->
        GlassDialog({ forgetTarget = null }, "Forget ${t.person.name}?", "Forget", { vm.peopleCall({ vm.people.forgetPerson(t.person.personId) }) { msg = "${t.person.name} forgotten." } }) {
            GText("Everything NOVA remembers about ${t.person.name} will be deleted.")
        }
    }
    if (deleteAll) GlassDialog({ deleteAll = false }, "Delete all people memory?", "Delete", { vm.peopleCall({ vm.people.deleteAll() }) { msg = "All people memory deleted." } }) {
        GText("Every saved person, nickname and note is removed. This cannot be undone.")
    }
    mergePair?.let { (a, b) ->
        GlassDialog({ mergePair = null }, "Merge ${b.person.name} into ${a.person.name}?", "Merge", { vm.peopleCall({ vm.people.merge(a.person.personId, b.person.personId) }) { msg = "Merged into ${a.person.name}." } }) {
            GText("Names, nicknames and memories are combined under ${a.person.name}. ${b.person.name}'s profile is removed.")
        }
    }
    needsMerge?.let { o ->
        GlassDialog({ needsMerge = null }, "${o.name} is already saved") {
            GText("${o.name} is saved as ${o.existing.person.relLabel}. Is this the same person?")
            GlassButton("Same person: update relationship", { vm.peopleCall({ vm.people.setRelationship(o.existing.person.personId, o.rt, o.label) }) { msg = "Updated ${o.name}." }; needsMerge = null }, Modifier.fillMaxWidth(), primary = true)
            GlassButton("Different person: add new", { vm.peopleCall({ vm.people.introduce(o.name, o.rt, o.label, force = true) }) { msg = "Added a separate ${o.name}." }; needsMerge = null }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun AddPersonSheet(vm: NovaViewModel, onDismiss: () -> Unit, onMsg: (String) -> Unit, onNeedsMerge: (IntroOutcome.NeedsMerge) -> Unit) {
    val g = LocalGlass.current
    var name by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    var rt by remember { mutableStateOf(RelationshipType.DOST) }
    var err by remember { mutableStateOf("") }
    GlassSheet(onDismiss, "Add person") {
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Name")
        GText("Relationship", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RelationshipType.values().forEach { r -> GlassChip(r.label, rt == r, { rt = r }) }
        }
        if (rt == RelationshipType.OTHER) GlassTextField(label, { label = it }, Modifier.fillMaxWidth(), placeholder = "Relationship (e.g. Neighbour)")
        GlassTextField(nick, { nick = it }, Modifier.fillMaxWidth(), placeholder = "Nickname (optional)")
        if (err.isNotBlank()) GText(err, size = 13.sp, color = g.accent)
        GlassButton("Save", {
            val n = name.trim()
            when {
                n.length < 2 -> err = "Enter a name."
                vm.memory.isSensitiveText(n) -> err = "That looks like private information."
                rt == RelationshipType.OTHER && label.isBlank() -> err = "Enter the relationship."
                else -> vm.peopleCall({ vm.people.introduce(n, rt, label.takeIf { rt == RelationshipType.OTHER }, nick.trim()) }) { o ->
                    when (o) {
                        is IntroOutcome.Created -> { onMsg("Saved ${o.p.person.name} as ${o.p.person.relLabel}."); onDismiss() }
                        is IntroOutcome.Updated -> { onMsg("${o.p.person.name}: ${o.note}."); onDismiss() }
                        is IntroOutcome.Duplicate -> err = "${o.p.person.name} is already saved as ${o.p.person.relLabel}."
                        is IntroOutcome.NeedsMerge -> { onNeedsMerge(o); onDismiss() }
                    }
                }
            }
        }, Modifier.fillMaxWidth(), primary = true)
    }
}

@Composable
private fun PersonDetail(vm: NovaViewModel, pw: PersonWithData, onClose: () -> Unit) {
    val g = LocalGlass.current
    val p = pw.person
    val id = p.personId
    var name by remember(id) { mutableStateOf(p.name) }
    var nick by remember(id) { mutableStateOf(p.nickname) }
    var addr by remember(id) { mutableStateOf(p.preferredAddress) }
    var notes by remember(id) { mutableStateOf(p.notes) }
    var msg by remember { mutableStateOf("") }
    var customRel by remember { mutableStateOf("") }
    var newNote by remember { mutableStateOf("") }
    var why by remember { mutableStateOf<PersonMemoryEntity?>(null) }
    var edit by remember { mutableStateOf<PersonMemoryEntity?>(null) }
    var editText by remember { mutableStateOf("") }
    var confirmForget by remember { mutableStateOf(false) }

    GlassCard(Modifier.fillMaxWidth(), glow = true) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            GText("👤 ${p.name}", size = 20.sp, weight = FontWeight.SemiBold)
            GText("${p.relLabel} • ${p.category} • ${if (p.userConfirmed) "you confirmed this" else "unconfirmed"}", size = 12.sp, color = g.subtext)
            GText(p.reason.ifBlank { "Saved from something you told NOVA." }, size = 12.sp, color = g.subtext)
        }
    }
    GlassSettingSection("Basic information") {
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Name")
        GlassTextField(nick, { nick = it }, Modifier.fillMaxWidth(), placeholder = "Nickname (e.g. Rahu)")
        GlassTextField(addr, { addr = it }, Modifier.fillMaxWidth(), placeholder = "How Nova should address them (e.g. Rahul bhai)")
        GlassTextField(notes, { notes = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 2, placeholder = "Notes (only what you type)")
        GlassButton("Save changes", { vm.peopleCall({ vm.people.saveBasics(id, name, nick, addr, notes) }) { err -> msg = err ?: "Saved." } }, primary = true)
        if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.accent)
    }
    GlassSettingSection("Relationship") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RelationshipType.values().filter { it != RelationshipType.OTHER }.forEach { r ->
                GlassChip(r.label, p.relType == r.key, { vm.peopleCall({ vm.people.setRelationship(id, r) }) { msg = "Relationship changed to ${r.label}." } })
            }
        }
        GlassTextField(customRel, { customRel = it }, Modifier.fillMaxWidth(), placeholder = "Or a custom relationship")
        if (customRel.isNotBlank()) GlassButton("Use \"${customRel.trim()}\"", { vm.peopleCall({ vm.people.setRelationship(id, RelationshipType.OTHER, customRel.trim()) }) { msg = "Relationship changed."; customRel = "" } })
    }
    GlassSettingSection("Conversation preferences") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("" to "Auto", "friendly" to "Friendly", "formal" to "Formal", "casual" to "Casual", "funny" to "Funny", "respectful" to "Respectful", "short" to "Short replies", "detailed" to "Detailed replies")
                .forEach { (k, l) -> GlassChip(l, p.style == k, { vm.peopleCall({ vm.people.setStyle(id, k) }) }) }
        }
        GText("Used when a request mentions ${p.name}. An explicit request from you always wins.", size = 11.sp, color = g.subtext)
    }
    GlassSettingSection("Memory") {
        if (pw.memories.isEmpty()) GText("Nothing saved yet.", size = 12.sp, color = g.subtext)
        pw.memories.forEach { m ->
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                GText(m.content)
                GText("${m.kind.lowercase()} • ${vm.people.confidence.effective(m.confidence, m.userConfirmed, m.createdAt, m.lastUsedAt).name.lowercase()} confidence • ${if (m.expiresAt > 0) "expires ${fmt(m.expiresAt)}" else "no expiry"}", size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    SmallAction("Why?", "Why was this remembered") { why = m }
                    SmallAction("Edit", "Edit memory") { edit = m; editText = m.content }
                    SmallAction("Forget", "Forget this memory") { vm.peopleCall({ vm.people.deleteMemory(m.memoryId) }) }
                    SmallAction("Never remember similar", "Never remember similar information") { vm.peopleCall({ vm.people.neverRemember(m) }) }
                }
            }
        }
        GlassTextField(newNote, { newNote = it }, Modifier.fillMaxWidth(), placeholder = "Add something for Nova to remember")
        GlassButton("Remember this", { if (newNote.isNotBlank()) vm.peopleCall({ vm.people.addNote(id, newNote, true) }) { r -> msg = if (r == "OK") "Saved." else r; if (r == "OK") newNote = "" } })
    }
    GlassSettingSection("Recent context") {
        GlassListItem("Last interaction", fmt(p.lastInteraction))
        GlassListItem("Last context", p.lastContext.ifBlank { "None" })
        GlassListItem("Recent conversation tone", if (p.lastTone.isBlank()) "Unknown" else p.lastTone.lowercase())
        GText("The tone comes from your own messages about ${p.name}. NOVA does not know their real mood.", size = 11.sp, color = g.subtext)
        GlassButton("Clear recent context", { vm.peopleCall({ vm.people.clearContext(id) }) { msg = "Context cleared." } })
    }
    GlassSettingSection("Privacy controls") {
        GlassListItem("Use in AI answers", "Only one short line, only when ${p.name} is named in a request", trailing = {
            GlassSwitch(p.aiContextAllowed) { on -> vm.peopleCall({ vm.people.setAiAllowed(id, on) }) }
        })
        GlassButton("Delete this person's memories", { vm.peopleCall({ vm.people.deleteMemoriesFor(id) }) { msg = "Memories deleted." } }, Modifier.fillMaxWidth())
        GlassButton("Forget ${p.name}", { confirmForget = true }, Modifier.fillMaxWidth())
    }
    why?.let { m ->
        GlassDialog({ why = null }, "Why was this remembered?") {
            GText(m.reason.ifBlank { "Saved from something you told NOVA." })
            GText("Source: ${m.source}. Importance ${"%.2f".format(m.importance)}. Saved ${fmt(m.createdAt)}.", size = 12.sp, color = g.subtext)
            GlassButton("Keep", { why = null }, Modifier.fillMaxWidth(), primary = true)
            GlassButton("Edit", { edit = m; editText = m.content; why = null }, Modifier.fillMaxWidth())
            GlassButton("Forget", { vm.peopleCall({ vm.people.deleteMemory(m.memoryId) }); why = null }, Modifier.fillMaxWidth())
            GlassButton("Never remember similar", { vm.peopleCall({ vm.people.neverRemember(m) }); why = null }, Modifier.fillMaxWidth())
        }
    }
    edit?.let { m ->
        GlassSheet({ edit = null }, "Edit memory") {
            GlassTextField(editText, { editText = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
            GlassButton("Save memory", { vm.peopleCall({ vm.people.editMemory(m, editText) }) { err -> msg = err ?: "Memory updated."; if (err == null) edit = null } }, Modifier.fillMaxWidth(), primary = true)
        }
    }
    if (confirmForget) GlassDialog({ confirmForget = false }, "Forget ${p.name}?", "Forget", { vm.peopleCall({ vm.people.forgetPerson(id) }) { onClose() } }) {
        GText("Everything NOVA remembers about ${p.name} will be deleted.")
    }
}
