package com.nova.ai.live

import android.content.Context
import android.os.SystemClock
import com.nova.ai.ai.ModelCatalog
import com.nova.ai.ai.Personality
import com.nova.ai.ai.model.LiveModality
import com.nova.ai.language.LanguageDetector
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.security.Prefs
import com.nova.ai.voice.PcmFormat
import com.nova.ai.voice.SpeechProcessingEngine
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Real-time two-way voice (barge-in allowed): the mic PCM from AudioCapture goes straight to Gemini Live and the model's
 * voice is played back here. Runs inside the Background Voice foreground service, so it keeps going with the screen off.
 * It is the default speech mode. One engine = one AudioRecord (owned by AudioCapture) + one WebSocket (epoch-tagged, old
 * callbacks are dropped). On a dropped connection it reconnects with a bounded back-off and continues from a short recap;
 * errors retrying cannot fix (bad key, unknown model, quota) stop immediately and are shown to the user.
 */
class GeminiLiveDuplexEngine(
    private val ctx: Context,
    private val prefs: Prefs,
    private val jp: JarvisPrefs,
    private val onProblem: (String) -> Unit,
    private val memory: ConversationMemory = ConversationMemory(),
    val latency: VoiceLatencyTracker = LiveSession.latency,
    /** The model chosen by Settings → Gemini (via ModelManager's voice route). Null only for old callers; then the legacy Jarvis choice is used. */
    private val modelId: String? = null,
    private val modality: LiveModality = LiveModality.AUDIO,
    /** Called when the Live API refuses the model's audio output. The router then switches to the speech-to-text fallback. Null = show an error. */
    private val onNativeRejected: ((String) -> Unit)? = null
) : SpeechProcessingEngine, GeminiLiveClient.Listener {

    companion object {
        /** While Nova talks with barge-in on, mic audio quieter than this is replaced by silence so her own voice is not sent back to her. */
        const val BARGE_IN_RMS = 0.05f
        private const val SETUP_TIMEOUT_MS = 15_000L
        private const val THINKING_TIMEOUT_MS = 10_000L
        private const val END_OF_SPEECH_MS = 700L
    }

    private val speaker = LiveSpeaker()
    @Volatile private var client: GeminiLiveClient? = null
    @Volatile private var epoch = 0
    @Volatile private var stopped = true
    @Volatile private var fatal = false
    @Volatile private var playing = false
    @Volatile private var detected: String? = null
    @Volatile private var inRate = 16000
    @Volatile private var lastChunkAt = 0L
    /** When the audio received so far should have finished playing (arithmetic from the chunk sizes). Safety net for the drain watch. */
    @Volatile private var expectedEndAt = 0L
    private var scope: CoroutineScope? = null
    private var drainJob: Job? = null
    private var levelJob: Job? = null
    private var reconnectJob: Job? = null
    private var setupJob: Job? = null
    private val policy = ReconnectPolicy()
    private var resuming = false
    // microphone-side bookkeeping (touched only from the capture coroutine)
    private var micSmooth = 0f
    private var voicedRun = 0
    private var userSpoke = false
    private var lastVoiceAt = 0L
    private var thinkingSince = 0L
    private var silence = ByteArray(0)

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        FlavorTools.gate(ctx)?.let {
            onProblem(it); LiveSession.lastError.value = it
            LiveSession.isActive.value = true; LiveSession.state.value = LiveOrbState.ERROR; LiveSession.statusText.value = "Error"
            return
        }
        this.scope = scope
        inRate = format.sampleRate
        LiveSession.refreshHook = { fatal = false; resuming = true; policy.reset(); reconnectJob?.cancel(); scheduleReconnect() }
        LiveSession.isActive.value = true; LiveSession.state.value = LiveOrbState.CONNECTING; LiveSession.statusText.value = "Connecting…"
        LiveSession.currentPersonality.value = persona().label; LiveSession.currentLanguage.value = prefs.language
        stopped = false
        fatal = false
        policy.reset()
        resuming = false
        memory.clear()
        latency.resetReconnects()
        connect()
    }

    private fun persona(): Personality = Personality.fromName(prefs.personality)

    /**
     * The model that holds the conversation: exactly the one selected in Settings → Gemini (passed in by the voice router).
     * It is never replaced by a default. (Only a legacy caller without a model id uses the old Jarvis "Live model" value.)
     */
    private fun liveModel(): String {
        modelId?.let { return it }
        val m = jp.liveModel
        return if (m.contains("transcribe", ignoreCase = true)) ModelCatalog.DEFAULT_LIVE else m
    }

    private fun connect() {
        if (stopped || fatal) return
        if (prefs.localOnly) { onFatalError("Local-only mode is on, so live voice is off."); return }
        if (!prefs.aiEnabled) { onFatalError("AI is disabled in Settings."); return }
        val my = ++epoch
        client?.disconnect()
        val lang = prefs.language
        val brain = com.nova.ai.brain.Brain.get(ctx)
        val recap = (if (resuming) memory.recap() else null) ?: brain.recapIfRecent()
        val instruction = PersonalityPromptBuilder.build(
            persona(), prefs.customPersonality, lang, prefs.manualTag, detected,
            recap,
            LivePrefs.assistantName(ctx),
            lockedLanguage = brain.livePolicy(), brainContext = brain.liveContext(liveModel())
        )
        val c = GeminiLiveClient({ prefs.apiKey }, Scoped(my), GeminiLiveClient.modelPath(liveModel()), modality)
        c.inputRate = inRate
        client = c
        setupJob?.cancel()
        setupJob = scope?.launch {
            delay(SETUP_TIMEOUT_MS)
            if (my == epoch && !stopped && client?.isReady() != true) onError("Gemini did not answer. Check your internet connection.")
        }
        c.connect(instruction, LivePrefs.voiceName(ctx))
    }

    /** Every callback is tagged with the connection it belongs to; callbacks from an old connection are dropped. */
    private inner class Scoped(private val my: Int) : GeminiLiveClient.Listener {
        private fun cur() = my == epoch && !stopped
        override fun onSetupComplete() { if (cur()) this@GeminiLiveDuplexEngine.onSetupComplete() }
        override fun onAudioChunk(pcm24k: ByteArray) { if (cur()) this@GeminiLiveDuplexEngine.onAudioChunk(pcm24k) }
        override fun onInputTranscript(text: String) { if (cur()) this@GeminiLiveDuplexEngine.onInputTranscript(text) }
        override fun onOutputTranscript(text: String) { if (cur()) this@GeminiLiveDuplexEngine.onOutputTranscript(text) }
        override fun onToolCall(id: String, name: String, args: JSONObject) { if (cur()) this@GeminiLiveDuplexEngine.runTool(my, id, name, args) }
        override fun onTurnComplete() { if (cur()) this@GeminiLiveDuplexEngine.onTurnComplete() }
        override fun onInterrupted() { if (cur()) this@GeminiLiveDuplexEngine.onInterrupted() }
        override fun onError(message: String) { if (cur()) this@GeminiLiveDuplexEngine.onError(message) }
        override fun onClosed() { if (cur()) this@GeminiLiveDuplexEngine.scheduleReconnect() }
        override fun onClosedWithReason(code: Int, reason: String) { if (cur()) this@GeminiLiveDuplexEngine.onClosedWithReason(code, reason) }
        override fun onFatalError(message: String) { if (cur()) this@GeminiLiveDuplexEngine.onFatalError(message) }
        override fun onModalityRejected(tried: LiveModality, reason: String) { if (cur()) this@GeminiLiveDuplexEngine.onModalityRejected(tried, reason) }
    }

    override fun onSetupComplete() {
        setupJob?.cancel()
        policy.reset()
        LiveSession.reconnecting.value = false
        onProblem(""); LiveSession.lastError.value = ""
        LiveSession.state.value = LiveOrbState.LISTENING; LiveSession.statusText.value = "Listening"
    }

    // ───────── model audio -> speaker ─────────

    override fun onAudioChunk(pcm24k: ByteArray) {
        val now = SystemClock.elapsedRealtime()
        lastChunkAt = now
        expectedEndAt = maxOf(expectedEndAt, now) + pcm24k.size / 2 * 1000L / LiveSpeaker.RATE
        if (!playing) {
            playing = true
            EchoGuard.notifyPlaybackStarted()
            VoiceState.speaking.value = true
            latency.mark(VoiceLatencyTracker.Mark.FIRST_MODEL_AUDIO)
            startLevelTicker()
        }
        LiveSession.state.value = LiveOrbState.SPEAKING
        LiveSession.statusText.value = "Speaking"
        speaker.play(pcm24k)                       // only queues: the WebSocket thread is never blocked by the speaker
        startDrainWatch()
    }

    /** Playback has ended only when the queue and the AudioTrack are really empty (not when the last chunk arrived). */
    private fun startDrainWatch() {
        if (drainJob?.isActive == true) return
        drainJob = scope?.launch {
            while (isActive) {
                delay(50)
                val t = SystemClock.elapsedRealtime()
                if (speaker.pendingMs() <= 0L && t - lastChunkAt > 150L) break
                if (t > expectedEndAt + 1500L) break                    // the speaker should long be done: never stay "speaking" forever
            }
            endPlayback()
        }
    }

    /** The orb follows the loudness of the audio that is being heard right now. */
    private fun startLevelTicker() {
        levelJob?.cancel()
        levelJob = scope?.launch {
            var smooth = 0f
            while (isActive) {
                val target = (speaker.levelNow() * 3.2f).coerceIn(0f, 1f)
                smooth = if (target > smooth) smooth * 0.4f + target * 0.6f else smooth * 0.8f + target * 0.2f
                LiveSession.amplitude.value = smooth
                delay(40)
            }
        }
    }

    private fun endPlayback() {
        expectedEndAt = 0L
        levelJob?.cancel(); levelJob = null
        if (!playing) return
        playing = false
        EchoGuard.notifyPlaybackStopped()
        VoiceState.speaking.value = false
        LiveSession.amplitude.value = 0f
        if (LiveSession.isActive.value && LiveSession.state.value == LiveOrbState.SPEAKING) {
            LiveSession.state.value = LiveOrbState.LISTENING; LiveSession.statusText.value = "Listening"
        }
    }

    // ───────── transcripts and turn events ─────────

    // Transcripts arrive in fragments. They are joined here and handed to the memory engine once per turn.
    private val userBuf = StringBuilder()
    private val aiBuf = StringBuilder()
    private fun flushUser() { val s = userBuf.toString().trim(); userBuf.setLength(0); if (s.isNotEmpty()) try { com.nova.ai.brain.Brain.get(ctx).observeVoiceUser(s) } catch (e: Exception) { } }
    private fun flushAi() { val s = aiBuf.toString().trim(); aiBuf.setLength(0); if (s.isNotEmpty()) try { com.nova.ai.brain.Brain.get(ctx).onAssistantTurn(s) } catch (e: Exception) { } }

    override fun onInputTranscript(text: String) {
        synchronized(userBuf) { if (aiBuf.isNotEmpty()) flushAi(); userBuf.append(text) }
        memory.add(ConversationMemory.Role.USER, text)
        val d = LanguageDetector.detect(text)
        if (d.confident) { detected = d.name; LiveSession.detectedLanguage.value = d.name }
        if (!playing) { enterThinking(); }
        VoiceState.heard.value = text.trim()
        LiveTranscripts.events.tryEmit(LiveTranscripts.Event(true, text))
        latency.startTurn()
        latency.mark(VoiceLatencyTracker.Mark.USER_SPEECH_END)
    }

    override fun onOutputTranscript(text: String) {
        synchronized(userBuf) { if (userBuf.isNotEmpty()) flushUser(); aiBuf.append(text) }
        memory.add(ConversationMemory.Role.ASSISTANT, text)
        VoiceState.lastSpoken = text.lowercase()
        LiveTranscripts.events.tryEmit(LiveTranscripts.Event(false, text))
    }

    override fun onTurnComplete() {
        synchronized(userBuf) { flushUser(); flushAi() }
        latency.mark(VoiceLatencyTracker.Mark.TURN_COMPLETE)
        LiveTranscripts.turnEnd.tryEmit(Unit)
        if (!playing && LiveSession.state.value == LiveOrbState.THINKING) {   // a turn that produced no audio (tool only)
            LiveSession.state.value = LiveOrbState.LISTENING; LiveSession.statusText.value = "Listening"
        }
    }

    /** Barge-in: the user spoke over Nova. Everything queued or still in the speaker's buffer is dropped at once. */
    override fun onInterrupted() {
        speaker.flush()
        drainJob?.cancel(); drainJob = null
        endPlayback()
        LiveTranscripts.turnEnd.tryEmit(Unit)
        if (LiveSession.state.value == LiveOrbState.SPEAKING || LiveSession.state.value == LiveOrbState.THINKING) {
            LiveSession.state.value = LiveOrbState.LISTENING; LiveSession.statusText.value = "Listening"
        }
    }

    private fun enterThinking() {
        thinkingSince = SystemClock.elapsedRealtime()
        LiveSession.state.value = LiveOrbState.THINKING; LiveSession.statusText.value = "Thinking"
    }

    override fun onToolCall(id: String, name: String, args: JSONObject) { }

    private fun runTool(my: Int, id: String, name: String, args: JSONObject) {
        if (!playing) enterThinking()
        scope?.launch(kotlinx.coroutines.Dispatchers.IO) {
            val r = try { LiveTools.execute(ctx, name, args) } catch (e: Exception) { JSONObject().put("result", "failed") }
            if (my == epoch && !stopped) client?.sendToolResponse(id, name, r)
        }
    }

    // ───────── errors and reconnect ─────────

    /** A problem that may pass: the connection is retried with back-off. */
    override fun onError(message: String) {
        onProblem(message); LiveSession.lastError.value = message
        scheduleReconnect()
    }

    override fun onClosedWithReason(code: Int, reason: String) {
        val c = LiveErrors.classify(null, code, reason)
        if (c.fatal) { onFatalError(c.message); return }
        onProblem(c.message); LiveSession.lastError.value = c.message
        scheduleReconnect()
    }

    /**
     * Error 1007: this model does not accept the requested response modality. Reconnecting cannot help, so the session stops at once
     * and the voice router (if any) continues with Speech-to-Text -> the SAME selected model -> Text-to-Speech.
     */
    override fun onModalityRejected(tried: LiveModality, reason: String) {
        val msg = "${liveModel()} does not support $tried output on the Live API."
        val cb = onNativeRejected
        if (cb == null) { onFatalError(msg); return }
        fatal = true
        setupJob?.cancel(); reconnectJob?.cancel()
        speaker.flush(); drainJob?.cancel(); drainJob = null; endPlayback()
        client?.disconnect(); client = null
        LiveSession.lastError.value = msg
        cb(msg)
    }

    /** A problem retrying cannot fix: stop, show it, do not loop. Tapping the mic again starts a fresh session. */
    override fun onFatalError(message: String) {
        fatal = true
        setupJob?.cancel(); reconnectJob?.cancel()
        speaker.flush(); drainJob?.cancel(); drainJob = null; endPlayback()
        client?.disconnect(); client = null
        onProblem(message)
        LiveSession.lastError.value = message
        LiveSession.reconnecting.value = false
        LiveSession.state.value = LiveOrbState.ERROR; LiveSession.statusText.value = "Error"
    }

    override fun onClosed() { }

    private fun scheduleReconnect() {
        if (stopped || fatal || reconnectJob?.isActive == true) return
        val s = scope ?: return
        speaker.flush(); drainJob?.cancel(); drainJob = null; endPlayback()
        val wait = policy.next()
        if (wait == null) {
            fatal = true
            client?.disconnect(); client = null
            val m = "Connection lost. Tap the microphone to try again."
            onProblem(m); LiveSession.lastError.value = m
            LiveSession.reconnecting.value = false
            LiveSession.state.value = LiveOrbState.ERROR; LiveSession.statusText.value = "Error"
            return
        }
        LiveSession.reconnecting.value = true
        LiveSession.state.value = LiveOrbState.CONNECTING; LiveSession.statusText.value = "Reconnecting…"
        reconnectJob = s.launch {
            delay(wait)
            if (stopped || fatal) return@launch
            latency.onReconnect()
            resuming = true
            connect()
        }
    }

    // ───────── microphone -> model ─────────

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        if (stopped) return
        val level = LiveSpeaker.rms(audioData, length)
        val vad = level > 0.02f
        val muted = LiveSession.muted.value
        LiveSession.vadActive.value = vad && !muted
        val target = if (muted) 0f else (level * 4f).coerceIn(0f, 1f)
        micSmooth = if (target > micSmooth) micSmooth * 0.4f + target * 0.6f else micSmooth * 0.85f + target * 0.15f
        LiveSession.micLevel.value = micSmooth
        if (muted) return
        trackTurnTaking(vad)
        val c = client ?: return
        if (!c.isReady()) return
        if (!jp.interrupt) {
            if (EchoGuard.isMicMuted()) return                                  // half-duplex: no mic while Nova talks
            c.sendAudio(audioData, length)
            return
        }
        // Barge-in mode: the mic stays open while Nova talks (VOICE_COMMUNICATION source + echo canceller). Audio that is not
        // clearly louder than her own leaked voice is replaced by silence, so she cannot interrupt herself.
        if (playing && level < BARGE_IN_RMS) {
            if (silence.size < length) silence = ByteArray(length)
            c.sendAudio(silence, length)
        } else c.sendAudio(audioData, length)
    }

    /** Shows THINKING after you stop talking even when no transcript arrives, and never leaves it stuck. */
    private fun trackTurnTaking(vad: Boolean) {
        val now = SystemClock.elapsedRealtime()
        val st = LiveSession.state.value
        if (vad && !playing) { voicedRun++; if (voicedRun >= 3) { userSpoke = true; lastVoiceAt = now } } else if (!vad) voicedRun = 0
        if (st == LiveOrbState.LISTENING && userSpoke && !playing && now - lastVoiceAt > END_OF_SPEECH_MS) {
            userSpoke = false
            enterThinking()
        } else if (st == LiveOrbState.THINKING && !playing && now - thinkingSince > THINKING_TIMEOUT_MS) {
            userSpoke = false
            LiveSession.state.value = LiveOrbState.LISTENING; LiveSession.statusText.value = "Listening"
        }
    }

    override fun stop() {
        stopped = true
        epoch++
        setupJob?.cancel(); reconnectJob?.cancel(); drainJob?.cancel(); levelJob?.cancel()
        setupJob = null; reconnectJob = null; drainJob = null; levelJob = null
        client?.disconnect(); client = null
        speaker.release()
        playing = false
        EchoGuard.reset()
        VoiceState.speaking.value = false
        memory.clear()
        policy.reset(); fatal = false
        micSmooth = 0f; voicedRun = 0; userSpoke = false
        LiveSession.refreshHook = null; LiveSession.reset()
        scope = null
    }
}
