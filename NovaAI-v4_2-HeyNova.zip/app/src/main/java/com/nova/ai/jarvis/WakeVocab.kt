package com.nova.ai.jarvis

import android.content.Context
import java.io.File

/**
 * Reads the word list of the installed offline models (graph/words.txt) so a wake phrase is only used when the model can really
 * produce every word of it. Cached per model; call [forget] after a model is deleted or downloaded.
 */
object WakeVocab {
    private val cache = HashMap<String, Set<String>?>()

    fun forget() { synchronized(cache) { cache.clear() } }

    /** Model id -> vocabulary, for installed models only. A null vocabulary means the file could not be read (assume valid). */
    fun installed(ctx: Context): Map<String, Set<String>?> {
        val out = LinkedHashMap<String, Set<String>?>()
        for (id in listOf(WakePhrases.EN, WakePhrases.HI)) if (VoskModelManager.isInstalled(ctx, id)) out[id] = words(ctx, id)
        return out
    }

    private fun words(ctx: Context, id: String): Set<String>? = synchronized(cache) {
        if (cache.containsKey(id)) return@synchronized cache[id]
        val f = File(VoskModelManager.dir(ctx, id), "graph/words.txt")
        val w: Set<String>? = try {
            if (!f.exists()) null else HashSet<String>(60_000).also { s -> f.bufferedReader(Charsets.UTF_8).useLines { ls -> ls.forEach { l -> val k = l.substringBefore(' ').trim(); if (k.isNotEmpty()) s.add(k.lowercase()) } } }
        } catch (e: Exception) { null }
        cache[id] = w
        w
    }

    /** The recognition plan for the phrases that are switched on in settings (reads files: call off the main thread). */
    fun planFor(ctx: Context, jp: JarvisPrefs): WakePhrases.Plan = WakePhrases.plan(jp.enabledPhrases(), installed(ctx))
}
