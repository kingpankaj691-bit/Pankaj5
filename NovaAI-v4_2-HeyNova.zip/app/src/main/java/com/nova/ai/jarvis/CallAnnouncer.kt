package com.nova.ai.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Says who is calling and (if you allow it) lets you answer or reject by voice.
 * Nova only answers or rejects when you say so while the phone is ringing; she never touches a call by herself.
 */
object CallAnnouncer {
    @Volatile var ringing = false
        private set
    private val main = Handler(Looper.getMainLooper())
    private var receiver: BroadcastReceiver? = null
    private var announceTask: Runnable? = null
    private var number: String? = null

    fun register(ctx: Context) {
        if (receiver != null) return
        val app = ctx.applicationContext
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
                @Suppress("DEPRECATION")
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                if (!num.isNullOrBlank()) number = num
                when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                    TelephonyManager.EXTRA_STATE_RINGING -> if (!ringing) {
                        ringing = true
                        val t = Runnable { announce(app) }
                        announceTask = t
                        main.postDelayed(t, 900)                 // the number often arrives in a second broadcast
                    }
                    else -> { ringing = false; number = null; announceTask?.let { main.removeCallbacks(it) } }
                }
            }
        }
        try {
            ContextCompat.registerReceiver(app, r, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
            receiver = r
        } catch (e: Exception) { }
    }

    fun unregister(ctx: Context) {
        receiver?.let { try { ctx.applicationContext.unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null; ringing = false
        announceTask?.let { main.removeCallbacks(it) }
    }

    private fun announce(ctx: Context) {
        if (!ringing) return
        val jp = JarvisPrefs(ctx)
        val who = nameFor(ctx, number)
        val ask = if (jp.callVoiceControl && Build.VERSION.SDK_INT >= 26) " Uthaoon ya kaatoon?" else ""
        Announcer.speak(ctx, (if (who == null) "Koi call aa raha hai." else "$who ka call aa raha hai.") + ask)
    }

    private fun nameFor(ctx: Context, num: String?): String? {
        if (num.isNullOrBlank()) return null
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return num.takeLast(10).toList().joinToString(" ")
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
                ?: num.takeLast(10).toList().joinToString(" ")
        } catch (e: Exception) { null }
    }

    private fun canControl(ctx: Context) =
        Build.VERSION.SDK_INT >= 26 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun answer(ctx: Context): String {
        if (!ringing) return "No call is ringing."
        if (!JarvisPrefs(ctx).callVoiceControl) return "Answering calls by voice is off in Jarvis settings."
        if (!canControl(ctx)) return "I need the Answer calls permission. Allow it in Jarvis settings."
        return try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); "Call uthaya."
        } catch (e: Exception) { "Android didn't let me answer that call." }
    }

    @SuppressLint("MissingPermission")
    fun reject(ctx: Context): String {
        if (!ringing) return "No call is ringing."
        if (!JarvisPrefs(ctx).callVoiceControl) return "Rejecting calls by voice is off in Jarvis settings."
        if (!canControl(ctx) || Build.VERSION.SDK_INT < 28) return "I can't reject calls on this phone, or the Answer calls permission is missing."
        return try {
            @Suppress("DEPRECATION")
            val ok = (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
            if (ok) "Call kaat diya." else "Android didn't let me end that call."
        } catch (e: Exception) { "Android didn't let me end that call." }
    }
}
