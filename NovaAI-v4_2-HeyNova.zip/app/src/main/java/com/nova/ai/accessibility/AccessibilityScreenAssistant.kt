package com.nova.ai.accessibility

import com.nova.ai.core.ScreenAssistant

/** Thin facade over the user-enabled AccessibilityService. Every call is a no-op/false when the service is off. */
class AccessibilityScreenAssistant : ScreenAssistant {
    private val s get() = NovaAccessibilityService.instance
    override fun isEnabled() = s != null
    override fun readScreen(): String? = s?.readScreen()
    override fun click(label: String) = s?.clickText(label) == true
    override fun scroll(forward: Boolean) = s?.scroll(forward) == true
    override fun back() = s?.back() == true
    override fun home() = s?.home() == true
    override fun type(text: String) = s?.typeText(text) == true
}
