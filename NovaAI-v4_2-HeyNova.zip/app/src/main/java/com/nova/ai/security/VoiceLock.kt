package com.nova.ai.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * EXPERIMENTAL owner voice check: compares the long-term average spectrum of a short recording against your enrolled
 * sample. It is a convenience layer only, easy to fool (recordings, similar voices), and is NOT biometric authentication.
 * Recording happens only while you tap Enroll/Verify, and Android shows its microphone indicator. The voiceprint is a small
 * list of numbers kept in app-private storage; no audio is saved.
 */
class VoiceLock(private val ctx: Context) {
    private val file = File(ctx.filesDir, "voiceprint.json")
    private val rate = 16000
    private val bands = 24

    fun hasProfile() = file.exists()
    fun delete() { try { file.delete() } catch (e: Exception) { } }
    private fun micOk() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private suspend fun capture(seconds: Int): ShortArray? = withContext(Dispatchers.IO) {
        if (!micOk()) return@withContext null
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return@withContext null
        val rec = try { AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2) } catch (e: SecurityException) { return@withContext null }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext null }
        val out = ShortArray(rate * seconds)
        var n = 0
        try {
            rec.startRecording()
            while (n < out.size) { val r = rec.read(out, n, minOf(1024, out.size - n)); if (r <= 0) break; n += r }
        } finally { try { rec.stop() } catch (e: Exception) { }; rec.release() }
        if (n < out.size / 2) null else out.copyOf(n)
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f; var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = i + k + len / 2
                    val vr = re[b] * cr - im[b] * ci; val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi; re[a] += vr; im[a] += vi
                    val nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun features(pcm: ShortArray): FloatArray? {
        val size = 512
        val edges = IntArray(bands + 1) { b ->
            val mel = 1127.0 * ln(1 + 100.0 / 700) + (1127.0 * ln(1 + 6000.0 / 700) - 1127.0 * ln(1 + 100.0 / 700)) * b / bands
            val hz = 700 * (Math.exp(mel / 1127.0) - 1)
            ((hz / rate * size).toInt()).coerceIn(1, size / 2 - 1)
        }
        val sum = FloatArray(bands); var frames = 0
        var pos = 0
        while (pos + size <= pcm.size) {
            val re = FloatArray(size) { (pcm[pos + it] / 32768f) * (0.5f - 0.5f * cos(2f * PI.toFloat() * it / size)) }
            val energy = re.sumOf { (it * it).toDouble() } / size
            if (energy > 1e-5) {
                val im = FloatArray(size); fft(re, im)
                for (b in 0 until bands) {
                    var p = 0.0
                    for (k in edges[b]..maxOf(edges[b], edges[b + 1])) p += (re[k] * re[k] + im[k] * im[k]).toDouble()
                    sum[b] += ln(p + 1e-9).toFloat()
                }
                frames++
            }
            pos += size / 2
        }
        if (frames < 10) return null
        val v = FloatArray(bands) { sum[it] / frames }
        val mean = v.average().toFloat()
        for (i in v.indices) v[i] -= mean
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        if (norm < 1e-6f) return null
        for (i in v.indices) v[i] /= norm
        return v
    }

    private fun similarity(a: FloatArray, b: FloatArray): Float { var d = 0f; for (i in a.indices) d += a[i] * b[i]; return d }

    suspend fun enroll(samples: Int = 3, onSample: (Int) -> Unit): Boolean {
        val vs = mutableListOf<FloatArray>()
        for (i in 1..samples) {
            onSample(i); delay(500)
            val pcm = capture(3) ?: return false
            vs.add(features(pcm) ?: return false)
        }
        val avg = FloatArray(bands) { b -> vs.map { it[b] }.average().toFloat() }
        val sims = vs.map { similarity(it, avg) }
        val threshold = maxOf(0.85f, (sims.average().toFloat() - 0.04f))
        file.writeText(JSONObject().put("v", JSONArray(avg.map { it.toDouble() })).put("t", threshold.toDouble()).toString())
        return true
    }

    /** Returns (matched, similarity). Similarity is -1 when it couldn't record. */
    suspend fun verify(): Pair<Boolean, Float> {
        if (!hasProfile()) return false to -1f
        val o = try { JSONObject(file.readText()) } catch (e: Exception) { return false to -1f }
        val arr = o.getJSONArray("v")
        val enrolled = FloatArray(arr.length()) { arr.getDouble(it).toFloat() }
        val pcm = capture(3) ?: return false to -1f
        val f = features(pcm) ?: return false to -1f
        val sim = similarity(f, enrolled)
        return (sim >= o.optDouble("t", 0.9).toFloat()) to sim
    }
}
