package com.nova.ai.planner

import com.nova.ai.screen.Dir

sealed class Step {
    data class OpenApp(val name: String) : Step()
    data class Tap(val query: String) : Step()
    data class DoubleTap(val query: String) : Step()
    data class LongPress(val query: String) : Step()
    /** Finds the search box (or search button), types the query and presses Search. */
    data class SearchInApp(val query: String) : Step()
    data class TypeInto(val text: String, val field: String?) : Step()
    data class Scroll(val down: Boolean) : Step()
    data class Swipe(val dir: Dir) : Step()
    /** ordinal 0 = "this result": the visible result that best matches the last search. */
    data class OpenResult(val ordinal: Int) : Step()
    data class Find(val query: String) : Step()
    /** Opens a browser: the spoken one, else the user's chosen browser, else the system default. null = "the browser". */
    data class OpenBrowser(val name: String?) : Step()
    /** Opens the chat with [contact] in WhatsApp (search, pick, verify the chat title). Never sends anything. */
    data class WhatsAppOpenChat(val contact: String) : Step()
    /** Types [message] in the chat with [contact], shows recipient + text, asks for an explicit yes, presses Send, verifies. */
    data class WhatsAppSend(val contact: String, val message: String) : Step()
    /** Reads visible chat names / previews / messages (codes are hidden). */
    object ReadWhatsApp : Step()
    /** Reads the visible result titles back (YouTube or a browser search page). */
    object ReadResults : Step()
    /** Checks that the video on screen is really playing (UI state and audio), never assumes it. */
    object VerifyPlayback : Step()
    object Back : Step()
    object Home : Step()
    object Recents : Step()
    object Notifications : Step()
    object Describe : Step()
}

data class Plan(val steps: List<Step>, val hinglish: Boolean) {
    val touchesScreen get() = steps.any { it !is Step.OpenApp && it !is Step.OpenBrowser }
    /** True when a step needs the internet (search / results). */
    val needsInternet get() = steps.any { it is Step.SearchInApp }
    fun summary(): String = steps.joinToString(" → ") { s ->
        when (s) {
            is Step.OpenApp -> "open ${s.name}"
            is Step.OpenBrowser -> "open ${s.name ?: "the browser"}"
            is Step.WhatsAppOpenChat -> "open the WhatsApp chat with ${s.contact}"
            is Step.WhatsAppSend -> "send WhatsApp to ${s.contact}: \"${s.message.take(60)}\" (I will ask before sending)"
            Step.ReadWhatsApp -> "read the WhatsApp screen"
            Step.ReadResults -> "read the results"
            Step.VerifyPlayback -> "check that it is playing"
            is Step.Tap -> "tap ${s.query}"
            is Step.DoubleTap -> "double-tap ${s.query}"
            is Step.LongPress -> "long-press ${s.query}"
            is Step.SearchInApp -> "search \"${s.query}\""
            is Step.TypeInto -> "type \"${s.text.take(30)}\""
            is Step.Scroll -> if (s.down) "scroll down" else "scroll up"
            is Step.Swipe -> "swipe ${s.dir.name.lowercase()}"
            is Step.OpenResult -> if (s.ordinal == 0) "open the matching result" else "open result ${s.ordinal}"
            is Step.Find -> "find ${s.query}"
            Step.Back -> "go back"; Step.Home -> "go home"; Step.Recents -> "recent apps"
            Step.Notifications -> "notifications"; Step.Describe -> "look at the screen"
        }
    }
}

/** Everything the runner needs from the app that is not a pure Android API. Implemented by the ViewModel. */
interface PlanHost {
    suspend fun confirm(prompt: String): Boolean
    /** Returns the chosen index or -1 when the user cancels. */
    suspend fun choose(title: String, options: List<String>): Int
    fun progress(text: String)
}
