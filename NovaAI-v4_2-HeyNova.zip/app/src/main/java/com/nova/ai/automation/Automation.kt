package com.nova.ai.automation

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.nova.ai.device.DeviceChangeDetector
import com.nova.ai.memory.MemoryDb
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ParsedReminder(val routine: Routine, val say: String)

/**
 * Safe automation: time and event triggers that only post a notification (or offer to open an app).
 * Uses WorkManager (Doze-aware, survives reboot). Times can be a few minutes late under Doze.
 */
class AutomationEngine(private val ctx: Context, private val db: MemoryDb) {
    fun list() = db.routines()

    fun create(r: Routine): Long {
        val id = db.insertRoutine(r)
        db.routine(id)?.let { schedule(it) }
        syncBackground()
        return id
    }

    fun setEnabled(id: Long, on: Boolean) {
        db.setRoutineEnabled(id, on)
        val r = db.routine(id)
        if (on && r != null) schedule(r) else cancel(id)
        syncBackground()
    }

    fun delete(id: Long) { cancel(id); db.deleteRoutine(id); syncBackground() }

    fun rescheduleAll() { db.routines().filter { it.enabled }.forEach { schedule(it) }; syncBackground(); RoutineManager.syncAll(ctx) }

    private fun cancel(id: Long) { WorkManager.getInstance(ctx).cancelUniqueWork("routine_$id") }

    fun schedule(r: Routine) {
        val delay = when (r.trigger) {
            "TIME_DAILY" -> nextDelay(r.trigValue)
            "TIME_ONCE" -> maxOf(5000L, r.fireAt - System.currentTimeMillis())
            "TIME_WEEKLY" -> RoutineManager.weeklyDelay(r.trigValue)
            else -> return
        }
        val req = OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS).setInputData(workDataOf("id" to r.id)).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("routine_${r.id}", ExistingWorkPolicy.REPLACE, req)
    }

    /** Battery-low routines need a light 15-minute check; it's only scheduled while such a routine exists. */
    fun syncBackground() {
        val wm = WorkManager.getInstance(ctx)
        if (db.routines().any { it.enabled && it.trigger == "BATTERY_LOW" })
            wm.enqueueUniquePeriodicWork("battery_watch", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<BatteryWatchWorker>(15, TimeUnit.MINUTES).build())
        else wm.cancelUniqueWork("battery_watch")
    }

    private val inRe = Regex("remind me in (\\d+)\\s*(second|sec|minute|min|hour|hr)s?\\s*(?:to|about)?\\s*(.*)")
    private val atRe = Regex("remind me at (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?\\s*(every day|daily|everyday)?\\s*(?:to|about)?\\s*(.*)")
    private val atFirstRe = Regex("at (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?,?\\s*(every day|daily|everyday)?,?\\s*remind me\\s*(?:to|about)?\\s*(.*)")

    fun parse(raw: String): ParsedReminder? {
        val t = raw.lowercase().trim().replace(Regex("^(hey )?nova[ ,]*"), "").trimEnd('.', '!')
        val now = System.currentTimeMillis()
        Regex("when (?:my )?(?:wired |bluetooth )?(?:headphones|earphones|earbuds|headset) (?:connect|connected|plug|plugged)(?: in)?,?\\s*(?:open|remind me(?: to)?|tell me|notify me(?: to)?)?\\s*(.*)").find(t)?.let { m ->
            val what = m.groupValues[1].trim().ifBlank { "Headphones connected" }
            return ParsedReminder(Routine(0, "Headphones", "HEADPHONES", "", "NOTIFY", what.replaceFirstChar { it.uppercase() }, true, true, 0, now, 0),
                "Okay. When headphones connect I'll notify you: $what. I can't open apps by myself, so the notification will let you tap to continue.")
        }
        inRe.find(t)?.let { m ->
            val n = m.groupValues[1].toLong()
            val ms = when (m.groupValues[2]) { "second", "sec" -> n * 1000; "minute", "min" -> n * 60000; else -> n * 3600000 }
            val task = m.groupValues[3].trim().ifBlank { "Reminder" }
            return ParsedReminder(Routine(0, "Reminder", "TIME_ONCE", "", "NOTIFY", task.replaceFirstChar { it.uppercase() }, true, false, now + ms, now, 0),
                "I'll remind you in $n ${m.groupValues[2]}${if (n > 1) "s" else ""}.")
        }
        val m = atRe.find(t) ?: atFirstRe.find(t) ?: return null
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifBlank { "0" }.toInt()
        val ap = m.groupValues[3]
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        if (h > 23 || min > 59) return null
        val daily = m.groupValues[4].isNotBlank() || t.contains("every day") || t.contains("daily")
        val task = m.groupValues[5].trim().ifBlank { "Reminder" }.replaceFirstChar { it.uppercase() }
        val hhmm = "%02d:%02d".format(h, min)
        val say = "I'll remind you at $hhmm${if (daily) " every day" else ""}. It may arrive a few minutes late if the phone is in deep sleep."
        return ParsedReminder(
            if (daily) Routine(0, "Reminder", "TIME_DAILY", hhmm, "NOTIFY", task, true, true, 0, now, 0)
            else Routine(0, "Reminder", "TIME_ONCE", "", "NOTIFY", task, true, false, now + nextDelay(hhmm), now, 0), say)
    }

    companion object {
        fun nextDelay(hhmm: String): Long {
            val p = hhmm.split(":")
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, p.getOrNull(0)?.toIntOrNull() ?: 8); set(Calendar.MINUTE, p.getOrNull(1)?.toIntOrNull() ?: 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis - System.currentTimeMillis()
        }
    }
}

fun fireRoutine(ctx: Context, r: Routine) {
    val offer = r.action == "OFFER_APP"
    val label = if (offer) try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(r.actValue, 0)).toString() } catch (e: Exception) { r.actValue } else ""
    val tap = (if (offer) Notifier.launchPackage(ctx, r.actValue) else null) ?: Notifier.openApp(ctx)
    Notifier.post(ctx, (3000 + r.id).toInt(), r.name, if (offer) "Tap to open $label" else r.actValue, tap)
}

class ReminderWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val app = applicationContext
        val db = MemoryDb.get(app)
        val id = inputData.getLong("id", -1)
        val r = db.routine(id) ?: return Result.success()
        if (!r.enabled) return Result.success()
        fireRoutine(app, r)
        db.markFired(id, System.currentTimeMillis())
        if (r.trigger == "TIME_DAILY" || r.trigger == "TIME_WEEKLY") AutomationEngine(app, db).schedule(r) else db.setRoutineEnabled(id, false)
        return Result.success()
    }
}

class BatteryWatchWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val app = applicationContext
        val db = MemoryDb.get(app)
        val b = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0 || charging) return Result.success()
        val pct = level * 100 / scale
        val now = System.currentTimeMillis()
        db.routines().filter { it.enabled && it.trigger == "BATTERY_LOW" }.forEach { r ->
            if (pct <= (r.trigValue.toIntOrNull() ?: 15) && now - r.lastFired > 6 * 3600000L) { fireRoutine(app, r); db.markFired(r.id, now) }
        }
        return Result.success()
    }
}

class MaintenanceWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val app = applicationContext
        val days = app.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getInt("mem_expiry_days", 180)
        MemoryDb.get(app).purge(System.currentTimeMillis(), days)
        DeviceChangeDetector(app).detect()
        try { com.nova.ai.suite.Retention.purge(app); com.nova.ai.suite.SecurityWatch.check(app) } catch (e: Exception) { }
        return Result.success()
    }
}

object Maintenance {
    fun schedule(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "nova_maintenance", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MaintenanceWorker>(12, TimeUnit.HOURS).build()
        )
    }
}
