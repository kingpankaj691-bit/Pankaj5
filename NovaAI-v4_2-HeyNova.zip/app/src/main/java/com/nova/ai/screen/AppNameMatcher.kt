package com.nova.ai.screen

/**
 * Picks the right installed app for a spoken name. Plain "label contains name" opens the wrong app
 * ("YouTube" can match "YouTube Music" or "YouTube Kids" first), so names people use by voice map to exact packages first.
 * Pure Kotlin (no Android classes) so it is unit-tested.
 */
object AppNameMatcher {
    val known: Map<String, String> = mapOf(
        "youtube" to "com.google.android.youtube",
        "you tube" to "com.google.android.youtube",
        "youtube music" to "com.google.android.apps.youtube.music",
        "whatsapp" to "com.whatsapp",
        "whats app" to "com.whatsapp",
        "whatsapp business" to "com.whatsapp.w4b",
        "chrome" to "com.android.chrome",
        "google chrome" to "com.android.chrome",
        "firefox" to "org.mozilla.firefox",
        "brave" to "com.brave.browser",
        "edge" to "com.microsoft.emmx",
        "samsung internet" to "com.sec.android.app.sbrowser",
        "opera" to "com.opera.browser",
        "instagram" to "com.instagram.android",
        "telegram" to "org.telegram.messenger",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "play store" to "com.android.vending",
        "spotify" to "com.spotify.music"
    )

    fun norm(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    fun exactPackageFor(query: String): String? = known[norm(query)]

    /** Packages that are acceptable for a name, in order of preference ("WhatsApp" may be the Business app if that is all there is). */
    fun exactPackagesFor(query: String): List<String> {
        val first = exactPackageFor(query) ?: return emptyList()
        return if (first == "com.whatsapp") listOf("com.whatsapp", "com.whatsapp.w4b") else listOf(first)
    }

    /** 0 = no match. Higher = better. */
    fun score(label: String, query: String): Int {
        val l = norm(label)
        val q = norm(query)
        if (q.isBlank() || l.isBlank()) return 0
        if (l == q) return 100
        val lw = l.split(' ')
        val qw = q.split(' ')
        val extra = (lw.size - qw.size).coerceAtLeast(0)
        val wholeWords = lw.size >= qw.size && (0..(lw.size - qw.size)).any { i -> lw.subList(i, i + qw.size) == qw }
        return when {
            wholeWords -> (70 - extra * 5).coerceAtLeast(41)
            l.startsWith(q) -> 40
            l.contains(q) -> 35
            else -> 0
        }
    }

    /** [candidates] = (label, packageName). Returns the best package or null. */
    fun pickBest(candidates: List<Pair<String, String>>, query: String): String? {
        // A well-known name maps to ONE package. If that app isn't installed, do not guess a lookalike
        // (opening "YouTube Kids" when the user said "YouTube" is wrong); the caller reports "not installed".
        exactPackagesFor(query).takeIf { it.isNotEmpty() }?.let { wanted -> return wanted.firstOrNull { w -> candidates.any { it.second == w } } }
        return candidates
            .map { Triple(it.first, it.second, score(it.first, query)) }
            .filter { it.third > 0 }
            .sortedWith(compareByDescending<Triple<String, String, Int>> { it.third }.thenBy { it.first.length })
            .firstOrNull()?.second
    }
}
