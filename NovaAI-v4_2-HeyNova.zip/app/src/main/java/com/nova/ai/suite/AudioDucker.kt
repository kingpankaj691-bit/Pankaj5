package com.nova.ai.suite

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build

/**
 * Smart audio ducking. Asks Android for transient audio focus with "may duck" so compatible music apps lower their own volume
 * while Nova talks or listens, and gives focus back afterwards (the music app restores its own volume). It never changes the
 * media stream volume itself and does nothing during a phone call. The user can turn it off (pref "duck_audio").
 */
object AudioDucker {
    private var request: AudioFocusRequest? = null
    @Volatile var active = false
        private set

    fun enabled(ctx: Context) = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getBoolean("duck_audio", true)
    fun duckOnUser(ctx: Context) = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getBoolean("duck_user", true)
    fun setDuckOnUser(ctx: Context, on: Boolean) { ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).edit().putBoolean("duck_user", on).apply() }
    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).edit().putBoolean("duck_audio", on).apply()
        if (!on) release(ctx)
    }

    private fun inCall(am: AudioManager) = am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION || am.mode == AudioManager.MODE_RINGTONE

    /** Call when the user starts speaking or Nova starts answering. Safe to call repeatedly. */
    fun acquire(ctx: Context): Boolean {
        if (!enabled(ctx) || active) return active
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (inCall(am)) return false
        return try {
            val r = if (Build.VERSION.SDK_INT >= 26) {
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                val fr = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).setWillPauseWhenDucked(false).setOnAudioFocusChangeListener { }.build()
                request = fr
                am.requestAudioFocus(fr)
            } else {
                @Suppress("DEPRECATION") am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
            active = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            active
        } catch (e: Exception) { false }
    }

    /** Call after the conversation turn ends. Other apps then restore their own volume. */
    fun release(ctx: Context) {
        if (!active && request == null) return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (Build.VERSION.SDK_INT >= 26) request?.let { am.abandonAudioFocusRequest(it) }
            else @Suppress("DEPRECATION") am.abandonAudioFocus(null)
        } catch (e: Exception) { }
        request = null; active = false
    }
}
