package com.nova.ai.files

import java.util.Locale

/** Pure safety and planning rules for file operations (Part 2). No Android types, so they run in unit tests. */

data class OpResult(val ok: Boolean, val message: String, val done: Int = 0, val failed: Int = 0)

object NameRules {
    private val bad = Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]")

    /** Null when the name is fine, otherwise the reason it isn't. */
    fun validate(name: String): String? {
        val n = name.trim()
        return when {
            n.isEmpty() -> "The name can't be empty."
            n.length > 200 -> "That name is too long."
            n == "." || n == ".." -> "That name isn't allowed."
            bad.containsMatchIn(n) -> "Names can't contain / \\ : * ? \" < > |"
            else -> null
        }
    }

    /** "report.pdf" → "report (1).pdf" → "report (2).pdf" … until [exists] says the name is free. Never overwrites. */
    fun uniqueName(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        for (i in 1..999) { val c = "$base ($i)$ext"; if (!exists(c)) return c }
        return "$base (${System.currentTimeMillis()})$ext"
    }
}

object ZipRules {
    const val MAX_ENTRIES = 20_000
    const val MAX_TOTAL_BYTES = 4L * 1024 * 1024 * 1024

    /** A safe relative path for a ZIP entry, or null for absolute paths, "..", drive letters and empty names (zip-slip). */
    fun safeEntryName(raw: String): String? {
        val n = raw.replace('\\', '/').trim()
        if (n.isEmpty() || n.startsWith("/") || n.contains(':')) return null
        val segs = n.split('/').filter { it.isNotEmpty() }
        if (segs.isEmpty() || segs.any { it == ".." || it == "." }) return null
        return segs.joinToString("/")
    }
}

object DeleteGuard {
    private val protectedTop = setOf("Download", "Documents", "DCIM", "Pictures", "Movies", "Music", "Recordings", "Podcasts", "Audiobooks", "Ringtones", "Alarms", "Notifications", "Android")

    /** Null when deleting [path] is allowed (after the user's confirmation), otherwise why not. */
    fun refusal(path: String, roots: List<String>): String? {
        val p = PathRules.normalize(path)
        if (!PathRules.isWithinAny(roots, p)) return "That's outside your phone's storage."
        if (roots.any { PathRules.normalize(it) == p }) return "I won't delete a whole storage volume."
        PathRules.blockedReason(p)?.let { return it }
        val root = roots.first { PathRules.isWithin(it, p) }
        if (PathRules.parent(p, root) == PathRules.normalize(root) && PathRules.leaf(p) in protectedTop) return "${PathRules.leaf(p)} is a standard system folder. I won't delete it."
        return null
    }
}

object OrganizePlanner {
    data class Move(val from: String, val name: String, val toFolder: String)

    fun folderFor(kind: FileKind): String = when (kind) {
        FileKind.PDF, FileKind.WORD, FileKind.SHEET, FileKind.SLIDES, FileKind.TEXT, FileKind.DATA, FileKind.WEB -> "Documents"
        FileKind.IMAGE -> "Images"
        FileKind.VIDEO -> "Videos"
        FileKind.AUDIO -> "Audio"
        FileKind.ARCHIVE -> "Archives"
        FileKind.APK -> "APKs"
        FileKind.CODE -> "Code"
        else -> "Other"
    }

    /** Sorts the loose files directly inside one folder into type sub-folders. Folders and hidden files are left alone. */
    fun plan(files: List<FileItem>): List<Move> =
        files.filter { !it.isDir && !it.name.startsWith(".") }.map { Move(it.path, it.name, folderFor(it.kind)) }

    fun summary(plan: List<Move>): List<Pair<String, Int>> =
        plan.groupingBy { it.toFolder }.eachCount().toList().sortedByDescending { it.second }
}

object DuplicateRules {
    /** Only files of identical, non-zero size can be duplicates; hashing is only needed for these. */
    fun sizeCandidates(files: List<FileItem>): List<List<FileItem>> =
        files.filter { !it.isDir && it.size > 0 }.groupBy { it.size }.values.filter { it.size >= 2 }

    private fun key(f: FileItem) = f.path.ifBlank { f.uri ?: f.name }

    /** A selection is only safe if every group keeps at least one copy. */
    fun safeSelection(groups: List<List<FileItem>>, selectedKeys: Set<String>): Boolean =
        groups.all { g -> g.any { key(it) !in selectedKeys } }

    /** Keeps the oldest copy of every group, selects the rest. */
    fun extras(groups: List<List<FileItem>>): Set<String> =
        groups.flatMap { g -> g.sortedBy { if (it.modified <= 0) Long.MAX_VALUE else it.modified }.drop(1).map { key(it) } }.toSet()

    fun wasted(groups: List<List<FileItem>>): Long = groups.sumOf { g -> (g.size - 1) * (g.firstOrNull()?.size ?: 0L) }
}

object ItemKey { fun of(f: FileItem): String = f.path.ifBlank { f.uri ?: f.name } }

fun String.lc(): String = lowercase(Locale.ROOT)
