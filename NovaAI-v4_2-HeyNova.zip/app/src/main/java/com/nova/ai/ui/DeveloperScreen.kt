package com.nova.ai.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DeveloperScreen(vm: NovaViewModel) {
    var mode by rememberSaveable { mutableStateOf("chat") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Assistant", mode == "chat", { mode = "chat" })
            GlassChip("Editor", mode == "edit", { mode = "edit" })
        }
        if (mode == "chat") ChatPane(vm, dev = true, modifier = Modifier.weight(1f))
        else CodeEditor(vm, { mode = "chat" }, Modifier.weight(1f))
    }
}

@Composable
fun CodeEditor(vm: NovaViewModel, toChat: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val clip = LocalClipboardManager.current
    var code by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("snippet.kt") }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray()) } } catch (e: Exception) { }
    }
    val highlighter = remember {
        object : VisualTransformation {
            override fun filter(text: AnnotatedString) = TransformedText(highlight(text.text, Color(0xFFB9A8FF)), OffsetMapping.Identity)
        }
    }
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "File name (e.g. Main.kt)")
        Box(Modifier.weight(1f).fillMaxWidth().clip(shape).background(Color(0xFF05070F).a(0.74f)).border(1.dp, Color.White.a(0.12f), shape)) {
            Box(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
                BasicTextField(
                    code, { code = it }, Modifier.fillMaxWidth().heightIn(min = 240.dp),
                    textStyle = TextStyle(color = Color(0xFFE6EDF7), fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    cursorBrush = SolidColor(g.accent), visualTransformation = highlighter,
                    decorationBox = { inner -> if (code.isEmpty()) GText("Paste or write code here…", color = Color.White.a(0.4f)); inner() }
                )
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Copy", { clip.setText(AnnotatedString(code)) })
            GlassButton("Save", { saver.launch(name.ifBlank { "snippet.txt" }) })
            GlassButton("Share", {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Share code")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            GlassButton("Explain", { if (code.isNotBlank()) { vm.send("Explain this code:\n```\n$code\n```", true); toChat() } }, primary = true)
            GlassButton("Fix", { if (code.isNotBlank()) { vm.send("Find and fix the bugs in this code, then show the corrected version:\n```\n$code\n```", true); toChat() } }, primary = true)
        }
        GText("Nova never runs your code. Explain and Fix send the code to Gemini only when you tap them.", size = 11.sp, color = g.subtext)
    }
}
