package com.nova.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nova.ai.ai.Emotion
import com.nova.ai.core.TTSManager
import com.nova.ai.core.VoiceProvider
import com.nova.ai.language.LanguageCatalog
import com.nova.ai.jarvis.NeuralTts
import com.nova.ai.language.LanguageDetector
import com.nova.ai.security.Prefs
import java.util.Locale

class VoiceManager(private val ctx: Context, private val prefs: Prefs) : VoiceProvider, TTSManager {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private var queue: List<String> = emptyList()
    private var current = 0
    private var finished = true
    private var emotion = Emotion.Normal
    var preferOffline = false
    private val neural = NeuralTts(ctx, prefs)
    private val stopper: () -> Unit = { stopSpeaking() }
    var lastSpoken = ""
    var onSpeaking: ((Boolean) -> Unit)? = null
    /** Microphone loudness 0..1 while listening (from SpeechRecognizer RMS). */
    var level by mutableFloatStateOf(0f)

    init {
        VoiceState.speechStoppers.add(stopper)
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        if (id != null && id.startsWith("nova_")) {
                            current = id.removePrefix("nova_").toIntOrNull() ?: current
                            finished = false
                            onSpeaking?.invoke(true)
                        }
                    }
                    override fun onDone(id: String?) {
                        if (id == "nova_${queue.size - 1}") { finished = true; onSpeaking?.invoke(false) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { onSpeaking?.invoke(false) }
                })
            }
        }
    }

    override fun ttsAvailable() = ttsReady

    /** Roman-script Hinglish is read by the en-IN voice (it pronounces Latin letters reliably); Devanagari uses hi-IN. */
    fun localeFor(text: String): Locale = when (prefs.language) {
        "english" -> Locale("en", "IN")
        "hindi" -> Locale("hi", "IN")
        "hinglish" -> Locale("en", "IN")
        "manual" -> Locale.forLanguageTag(prefs.manualTag)
        else -> {
            val d = LanguageDetector.detect(text)
            if (d.confident || text.any { it.code > 0x7F }) { lastTag = d.tag; if (d.hinglish) Locale("en", "IN") else Locale.forLanguageTag(d.tag) }
            else Locale("en", "IN")
        }
    }

    /** Language of the user's most recent speech/text. Speech recognition starts with this in Auto mode. */
    @Volatile var lastTag = "hi-IN"
    /** Set when the chosen language has no installed TTS voice and NOVA fell back to another one. */
    var ttsNote by mutableStateOf("")

    fun noteUserText(text: String) { val d = LanguageDetector.detect(text); if (d.confident) lastTag = d.tag }

    private fun recLocale(): Locale = when (prefs.language) {
        "english" -> Locale("en", "IN")
        "manual" -> Locale.forLanguageTag(prefs.manualTag)
        "hindi", "hinglish" -> Locale("hi", "IN")
        else -> Locale.forLanguageTag(lastTag)
    }

    private fun configure(text: String) {
        val t = tts ?: return
        var loc = localeFor(text)
        val avail = t.isLanguageAvailable(loc)
        if (avail < TextToSpeech.LANG_AVAILABLE) {
            ttsNote = "No ${loc.displayLanguage} voice is installed, so NOVA used another voice. Install one in Android text-to-speech settings."
            loc = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        } else ttsNote = ""
        t.language = loc
        if (prefs.ttsVoice.isNotBlank()) {
            t.voices?.firstOrNull { it.name == prefs.ttsVoice }?.let { v -> if (v.locale.language == loc.language) t.voice = v }
        }
        t.setSpeechRate((prefs.speed * emotion.rate).coerceIn(0.4f, 2.5f))
        t.setPitch((prefs.pitch * emotion.pitch).coerceIn(0.5f, 2f))
    }

    /** Voices for the selected language (all voices in Auto mode). */
    fun voices(): List<Pair<String, String>> =
        tts?.voices?.filter { v -> prefs.language != "manual" && prefs.language != "english" && prefs.language != "hindi" || v.locale.language == (when (prefs.language) { "manual" -> Locale.forLanguageTag(prefs.manualTag).language; "english" -> "en"; else -> "hi" }) }
            ?.sortedBy { it.name }
            ?.map { it.name to (it.locale.displayName + if (it.isNetworkConnectionRequired) " (online)" else "") }
            ?: emptyList()

    override fun speak(text: String, emo: Emotion) {
        VoiceState.lastSpoken = text.lowercase()
        if (neural.enabled() && text.length <= 700) {
            lastSpoken = text
            emotion = emo
            finished = false
            neural.speak(text,
                onStarted = { onSpeaking?.invoke(true) },
                onFinished = { ok ->
                    if (ok) { finished = true; onSpeaking?.invoke(false) } else speakLocal(text, emo)   // fall back to Android TTS
                })
            return
        }
        speakLocal(text, emo)
    }

    private fun speakLocal(text: String, emo: Emotion) {
        if (!ttsReady) { onSpeaking?.invoke(false); return }
        lastSpoken = text
        emotion = emo
        val parts = text.split(Regex("(?<=[.!?।\\n])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        queue = if (parts.isEmpty()) listOf(text) else parts
        current = 0
        finished = false
        configure(text)
        playFrom(0)
    }

    private fun playFrom(i: Int) {
        val t = tts ?: return
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, prefs.ttsVolume) }
        t.stop()
        for (k in i until queue.size) {
            t.speak(queue[k], if (k == i) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, "nova_$k")
            if (k < queue.size - 1) t.playSilentUtterance(220, TextToSpeech.QUEUE_ADD, "gap_$k")
        }
    }

    override fun repeat() { if (lastSpoken.isNotBlank()) speak(lastSpoken, emotion) }

    /** Continues from the sentence that was interrupted. Returns false when there is nothing to continue. */
    override fun resume(): Boolean {
        if (!ttsReady || queue.isEmpty() || finished) return false
        configure(lastSpoken)
        playFrom(current)
        return true
    }

    override fun stopSpeaking() { neural.stop(); tts?.stop(); onSpeaking?.invoke(false) }

    /** Must be called on the main thread. */
    override fun listen(onText: (String) -> Unit, onFail: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("Speech recognition isn't available on this device."); return
        }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { level = 0f }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onResults(res: Bundle?) {
                level = 0f
                val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) onFail("I didn't catch that.") else { noteUserText(text); onText(text) }
            }
            override fun onError(code: Int) {
                level = 0f
                onFail(when (code) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs internet on this device."
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer is busy. Try again."
                    else -> "Speech recognition failed (code $code)."
                })
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, recLocale().toLanguageTag())
            if (prefs.language == "auto" && prefs.autoLangDetect) {
                putStringArrayListExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", ArrayList(listOf("hi-IN", "en-IN", lastTag).distinct()))
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
                    putStringArrayListExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, ArrayList(LanguageCatalog.all.map { it.tag }))
                }
            }
            if (preferOffline) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    override fun shutdown() { VoiceState.speechStoppers.remove(stopper); neural.shutdown(); rec?.destroy(); tts?.stop(); tts?.shutdown() }
}
