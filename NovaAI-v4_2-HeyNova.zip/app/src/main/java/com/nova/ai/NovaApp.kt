package com.nova.ai

import android.app.Application
import android.content.ComponentCallbacks2
import com.nova.ai.automation.Maintenance
import com.nova.ai.automation.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NovaApp : Application() {
    companion object { lateinit var instance: NovaApp private set }

    override fun onCreate() {
        super.onCreate()
        instance = this
        com.nova.ai.developer.DiagnosticsManager.install(this)
        Notifier.ensureChannel(this)
        Maintenance.schedule(this)
        // Model registry: load the cached model list now, and refresh it from Google in the background when it is missing or older than 12 h.
        com.nova.ai.ai.model.ModelManager.init(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try { com.nova.ai.ai.model.ModelManager.refreshIfStale(this@NovaApp, com.nova.ai.security.Prefs(this@NovaApp)) } catch (e: Exception) { }
            try { com.nova.ai.suite.Retention.purge(this@NovaApp); com.nova.ai.suite.SecurityWatch.check(this@NovaApp) } catch (e: Exception) { }
        }
    }

    /** Low-memory behaviour for 4 GB phones: stop the screen-reading loop and close the overlay sheet when Android is short on RAM. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            try { com.nova.ai.suite.LiveOcr.stop(this, forget = false); com.nova.ai.suite.NovaSheet.hide() } catch (e: Exception) { }
        }
    }
}
