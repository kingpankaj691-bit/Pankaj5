package com.nova.ai.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.nova.ai.ai.model.ModelManager
import com.nova.ai.automation.Notifier

/** The persistent, visible notification that goes with the microphone foreground service. */
object VoiceNotificationManager {
    const val CHANNEL_ID = "nova_voice_bg"
    const val NOTIFICATION_ID = 77
    private const val STOPPED_ID = 78

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        // LOW importance: no sound, no vibration. Nova never makes a microphone-start sound.
        val ch = NotificationChannel(CHANNEL_ID, "Nova Background Voice", NotificationManager.IMPORTANCE_LOW)
        ch.description = "Shown while Nova is using the microphone."
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
    }

    private fun serviceIntent(ctx: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getService(
            ctx, req,
            Intent(ctx, NovaVoiceForegroundService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun build(ctx: Context, status: VoiceStatus, detail: String = ""): Notification {
        ensureChannel(ctx)
        val micOn = status == VoiceStatus.Listening || status == VoiceStatus.Starting
        val headline = if (micOn) "Background Voice Active" else "Background Voice Paused"
        val mic = if (micOn) "Microphone: ON" else "Microphone: OFF"
        val text = "$headline · $mic"
        // Never contains the API key: only the model name, the voice mode and the (already key-free) status/problem lines.
        val lines = ArrayList<String>()
        lines.add(headline)
        lines.add(mic)
        lines.add("Active Gemini Model: " + ModelManager.activeLabel(ctx))
        VoiceState.voiceMode.value.takeIf { it.isNotBlank() }?.let { lines.add(it) }
        if (detail.isNotBlank()) lines.add(detail)
        val sub = lines.joinToString("\n")
        val b = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("NOVA AI")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(sub))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(Notifier.openApp(ctx))
        if (status == VoiceStatus.Paused) b.addAction(0, "Resume", serviceIntent(ctx, NovaVoiceForegroundService.ACTION_RESUME, 2))
        else b.addAction(0, "Pause", serviceIntent(ctx, NovaVoiceForegroundService.ACTION_PAUSE, 1))
        b.addAction(0, "Stop", serviceIntent(ctx, NovaVoiceForegroundService.ACTION_STOP, 3))
        return b.build()
    }

    /** Refreshes the existing notification text (same id as the foreground notification). */
    fun update(ctx: Context, status: VoiceStatus, detail: String = "") {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, build(ctx, status, detail))
        } catch (e: SecurityException) {
            // Notification permission was revoked; the UI shows the state instead.
        }
    }

    /** One-time, dismissible message when Background Voice had to stop by itself. */
    fun postStopped(ctx: Context, reason: String) {
        try {
            ensureChannel(ctx)
            val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Nova AI: Background Voice stopped")
                .setContentText(reason)
                .setStyle(NotificationCompat.BigTextStyle().bigText(reason))
                .setAutoCancel(true)
                .setContentIntent(Notifier.openApp(ctx))
                .build()
            ctx.getSystemService(NotificationManager::class.java)?.notify(STOPPED_ID, n)
        } catch (e: SecurityException) {
            // Nothing else to do.
        }
    }

    fun clearStopped(ctx: Context) {
        try { ctx.getSystemService(NotificationManager::class.java)?.cancel(STOPPED_ID) } catch (e: Exception) { }
    }
}
