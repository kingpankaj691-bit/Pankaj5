package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import com.nova.ai.R
import androidx.compose.ui.graphics.Color
import com.nova.ai.live.LiveSession
import com.nova.ai.live.LiveStatus
import com.nova.ai.live.LiveStatusMapper
import com.nova.ai.voice.VoicePermissionManager
import com.nova.ai.voice.VoiceState
import com.nova.ai.voice.VoiceStatus
import com.nova.ai.device.DeviceController
import java.util.Calendar

@Composable
fun QuickCard(glyph: String, label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    GlassCard(
        modifier.aspectRatio(0.92f).pressable(onClick).semantics { contentDescription = label + if (active) ", on" else "" },
        shape = RoundedCornerShape(20.dp), glow = active, tint = if (active) g.accent.a(0.28f) else androidx.compose.ui.graphics.Color.Transparent
    ) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            GText(glyph, size = 24.sp)
            GText(label, size = 11.sp, maxLines = 1, align = TextAlign.Center)
        }
    }
}

@Composable
fun AppsSheet(vm: NovaViewModel, onDismiss: () -> Unit) {
    val apps = remember { vm.device.listApps() }
    GlassSheet(onDismiss, "Apps") {
        if (apps.isEmpty()) GText("No launchable apps visible to Nova.")
        apps.forEach { (label, pkg) ->
            GlassListItem(label, onClick = { vm.device.openPackage(pkg); onDismiss() })
        }
    }
}

@Composable
fun ScanSheet(vm: NovaViewModel, onDismiss: () -> Unit) {
    val g = LocalGlass.current
    val info = remember { vm.device.deviceInfo() }
    GlassSheet(onDismiss, "Device Scan") {
        GText("Reads only standard system info (model, Android version, battery, storage, RAM, network, Wi-Fi/Bluetooth state, display). No files or personal data are accessed and nothing is uploaded.", size = 12.sp, color = g.subtext)
        GText(info)
    }
}

@Composable
fun HomeScreen(vm: NovaViewModel, goTab: (Int) -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf("") }
    val tick = rememberResumeTick()
    val wifi = remember(tick) { vm.device.wifiOn() }
    val bt = remember(tick) { vm.device.btOn() }
    val battery = remember(tick) { vm.device.batteryPct() }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = if (hour < 12) "Good morning" else if (hour < 17) "Good afternoon" else "Good evening"
    val last = vm.messages.lastOrNull { !it.fromUser }?.text ?: ""

    // Real voice state (service + two-way engine). Nothing here is animated on its own.
    val running by VoiceState.running.collectAsState()
    val paused by VoiceState.paused.collectAsState()
    val micStatus by VoiceState.status.collectAsState()
    val problem by VoiceState.problem.collectAsState()
    val engineActive by LiveSession.isActive.collectAsState()
    val liveState by LiveSession.state.collectAsState()
    val reconnecting by LiveSession.reconnecting.collectAsState()
    val liveError by LiveSession.lastError.collectAsState()
    val micLevel by LiveSession.micLevel.collectAsState()
    val outLevel by LiveSession.amplitude.collectAsState()
    val status = LiveStatusMapper.map(running, paused, engineActive, liveState, reconnecting, micStatus == VoiceStatus.Listening, vm.displayStatus)
    val sessionOn = running && !paused
    val orbMode = when (status) {
        LiveStatus.LISTENING -> OrbMode.LISTENING
        LiveStatus.THINKING, LiveStatus.CONNECTING, LiveStatus.RECONNECTING -> OrbMode.THINKING
        LiveStatus.SPEAKING -> OrbMode.SPEAKING
        LiveStatus.ERROR -> OrbMode.ERROR
        LiveStatus.READY -> OrbMode.IDLE
    }
    // Microphone loudness while listening, speaker loudness while speaking (two-way engine); older speech modes use the recognizer's level.
    val orbLevel: () -> Float = {
        when (status) {
            LiveStatus.LISTENING -> if (engineActive) micLevel else vm.voice.level
            LiveStatus.SPEAKING -> if (engineActive) outLevel else vm.voice.level
            else -> 0f
        }
    }
    val statusColor = when (status) {
        LiveStatus.READY -> g.subtext
        LiveStatus.LISTENING -> Color(0xFF22D3EE)
        LiveStatus.THINKING, LiveStatus.CONNECTING, LiveStatus.RECONNECTING -> Color(0xFFB794F6)
        LiveStatus.SPEAKING -> Color(0xFFFF6FAE)
        LiveStatus.ERROR -> Color(0xFFFF5A6E)
    }
    val hint = when (status) {
        LiveStatus.READY -> "Tap the microphone to talk to Nova"
        LiveStatus.CONNECTING -> "Connecting to Gemini Live…"
        LiveStatus.LISTENING -> "Listening — just speak"
        LiveStatus.THINKING -> "Nova is thinking…"
        LiveStatus.SPEAKING -> "Nova is speaking — talk to interrupt"
        LiveStatus.RECONNECTING -> "Connection dropped — reconnecting…"
        LiveStatus.ERROR -> liveError.ifBlank { problem }.ifBlank { "Voice error. Tap the microphone to try again." }
    }
    val line = when (status) {
        LiveStatus.LISTENING -> "NOVA is listening"; LiveStatus.THINKING -> "NOVA is thinking"; LiveStatus.SPEAKING -> "NOVA is speaking"
        LiveStatus.CONNECTING, LiveStatus.RECONNECTING -> "NOVA is connecting"; LiveStatus.ERROR -> "NOVA needs attention"
        else -> if (vm.displayStatus == "Offline") "NOVA is offline — local commands still work" else "NOVA is ready"
    }

    // Microphone button: explain first, then ask; never start twice from quick repeated taps.
    var lastTap by remember { mutableStateOf(0L) }
    var showWhy by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf("") }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        val missing = VoicePermissionManager.missingExplanation(ctx)
        if (missing == null) startMic(ctx) else denied = missing
    }
    val onMic: () -> Unit = {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTap > 800L) {
            lastTap = now
            when {
                !VoicePermissionManager.canStart(ctx) -> showWhy = true
                !running -> startMic(ctx)
                paused -> resumeMic(ctx)
                status == LiveStatus.ERROR -> startMic(ctx)      // restarts a fresh session (the service replaces the old one)
                else -> stopMic(ctx)
            }
        }
    }

    val emblem = ImageBitmap.imageResource(R.drawable.nova_emblem)
    val lite = remember { com.nova.ai.live.LivePrefs.orbLite(ctx) }
    val muted by LiveSession.muted.collectAsState()
    var name by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            com.nova.ai.license.AccessKeyBanner()
            // 1. Branding (logo emblem + wordmark + tagline) and Settings
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.nova_emblem), "Nova logo", Modifier.width(58.dp).aspectRatio(690f / 517f), contentScale = ContentScale.Fit)
                Column(Modifier.padding(start = 10.dp).weight(1f)) {
                    GText("Nova", size = 24.sp, weight = FontWeight.Bold, color = Color(0xFF8FB8FF))
                    GText("Your Voice. My World.", size = 11.sp, color = g.subtext, maxLines = 1)
                }
                GlassIconButton("⚙", "Settings", { goTab(4) })
            }
            if (vm.changes.isNotEmpty()) {
                GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(20.dp), tint = g.accent.a(0.10f)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        GText("Your phone changed", weight = FontWeight.SemiBold)
                        GText(vm.changes.take(3).joinToString(" • "), size = 12.sp, color = g.subtext)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassButton("Rescan device", { vm.startScan(announce = false) }, primary = true)
                            GlassButton("Dismiss", { vm.dismissChanges() })
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("🔋 " + (if (battery >= 0) "$battery%" else "—"), Modifier.weight(1f))
                StatChip(if (!vm.online) "📴 Offline" else if (wifi) "📶 Wi-Fi" else "📶 Online", Modifier.weight(1f))
                StatChip("🎭 " + vm.personality.label, Modifier.weight(1f))
            }

            // 2. Central 3D Nova orb (emblem + particles + orbital rings), driven by the real voice state
            GalaxyOrb(
                orbMode, orbLevel, Modifier.widthIn(max = 300.dp).fillMaxWidth(0.80f).aspectRatio(1f).padding(top = 4.dp),
                lite = lite, description = "Nova is " + status.label.lowercase(), emblem = emblem
            )

            // 3. Greeting + live status
            GText("Hello! How can I help you today?", Modifier.padding(horizontal = 8.dp), size = 20.sp, weight = FontWeight.SemiBold, align = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(9.dp).background(statusColor, CircleShape))
                GText(status.label, size = 13.sp, weight = FontWeight.SemiBold, color = statusColor)
            }
            GText(hint, Modifier.padding(horizontal = 12.dp), size = 12.sp, color = g.subtext, align = TextAlign.Center, maxLines = 3)
            GText("$line • Mood: ${vm.mood.name.lowercase()} • ${vm.emotion.label}", Modifier.padding(horizontal = 12.dp), size = 11.sp, color = g.subtext, align = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(14.dp))

            // 4. Quick action cards (each one is wired to existing functionality)
            val primary = listOf(
                Triple("🎙", "Voice Mode", sessionOn) to onMic,
                Triple("📱", "Open App", false) to { sheet = "apps" },
                Triple("▶", "Play YouTube", false) to { vm.send("open youtube") },
                Triple("📞", "Call Someone", false) to { name = ""; sheet = "call" },
                Triple("✉", "Send Message", false) to { name = ""; sheet = "msg" },
                Triple("💻", "Help with Code", false) to { goTab(3) }
            )
            primary.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (t, click) -> QuickCard(t.first, t.second, t.third, click, Modifier.weight(1f)) }
                }
            }
            if (last.isNotBlank()) {
                GlassCard(Modifier.fillMaxWidth().padding(top = 4.dp), shape = RoundedCornerShape(22.dp), tint = g.accent.a(0.08f)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val lastUser = vm.messages.lastOrNull { it.fromUser }?.text ?: ""
                        if (lastUser.isNotBlank()) GText("You: $lastUser", size = 12.sp, color = g.subtext, maxLines = 2)
                        GText(last, size = 14.sp, maxLines = 5)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            // The earlier Home shortcuts are all still here.
            GText("Shortcuts", Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp), size = 12.sp, color = g.subtext)
            val extra = listOf(
                Triple("🔦", "Flashlight", vm.device.torchOn) to { vm.toggleTorch() },
                Triple("📶", "Wi-Fi", wifi) to { openSystem(ctx, Settings.ACTION_WIFI_SETTINGS) },
                Triple("🔵", "Bluetooth", bt) to { openSystem(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) },
                Triple("👥", "People", false) to { goTab(7) },
                Triple("🛰", "Scan Phone", false) to { vm.startScan() },
                Triple("🧭", "Commands", false) to { goTab(6) },
                Triple("📁", "File Manager", false) to { SettingsNav.request = "filemgr"; goTab(4) },
                Triple("🔎", "Find Files", false) to { SettingsNav.request = "filemgr"; FileManagerNav.request = "search"; goTab(4) }
            )
            extra.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (t, click) -> QuickCard(t.first, t.second, t.third, click, Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(190.dp))          // room for the pinned microphone + waveform
        }

        // 5. Waveform + large microphone button, pinned at the bottom centre
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE605070F))))
                .padding(top = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NovaWaveform(orbMode, orbLevel, Modifier.fillMaxWidth(0.72f).height(30.dp), lite)
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) { GlassIconButton("⌨", "Type to Nova", { name = ""; sheet = "type" }) }
                GalaxyMicButton(
                    sessionOn, orbLevelForMic(sessionOn, engineActive, micLevel, vm.voice.level), onMic, Modifier,
                    diameter = 84.dp, halo = 36.dp, label = if (sessionOn) "Stop listening" else "Talk to Nova"
                )
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    if (sessionOn && engineActive) GlassIconButton(if (muted) "🔇" else "🔈", if (muted) "Unmute microphone" else "Mute microphone", { LiveSession.toggleMute() }, active = muted)
                }
            }
        }
    }
    if (sheet == "apps") AppsSheet(vm) { sheet = "" }
    if (sheet == "scan") ScanSheet(vm) { sheet = "" }
    if (sheet == "type") GlassSheet({ sheet = "" }, "Type to Nova") {
        GlassTextField(
            input, { input = it }, Modifier.fillMaxWidth(), placeholder = "Type to Nova…",
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { vm.send(input); input = ""; sheet = ""; goTab(1) })
        )
        GlassButton("Send", { vm.send(input); input = ""; sheet = ""; goTab(1) }, Modifier.fillMaxWidth(), primary = true, enabled = input.isNotBlank())
    }
    if (sheet == "call" || sheet == "msg") GlassSheet({ sheet = "" }, if (sheet == "call") "Call someone" else "Send a message") {
        GText(if (sheet == "call") "Name (from your Contacts) or phone number. Nova asks before dialling." else "Contact name. Nova opens the message composer; you tap Send.", size = 12.sp, color = g.subtext)
        GlassTextField(
            name, { name = it }, Modifier.fillMaxWidth(), placeholder = if (sheet == "call") "Who do you want to call?" else "Who do you want to message?",
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { if (name.isNotBlank()) { vm.send((if (sheet == "call") "call " else "message ") + name.trim()); sheet = "" } })
        )
        GlassButton(if (sheet == "call") "Call" else "Message", { vm.send((if (sheet == "call") "call " else "message ") + name.trim()); sheet = "" },
            Modifier.fillMaxWidth(), primary = true, enabled = name.isNotBlank())
    }
    if (showWhy) GlassSheet({ showWhy = false }, "Allow microphone access") {
        GText(
            "Nova needs the Microphone to hear you, and Notifications to show the \"microphone is on\" notice while a voice session runs. " +
                "While the session is on, your voice is streamed to Google Gemini (with your own API key) so Nova can answer; Nova does not save the audio on your phone. " +
                "Tap the microphone again at any time to stop.",
            size = 13.sp, color = g.subtext
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Not now", { showWhy = false }, Modifier.weight(1f))
            GlassButton("Allow", { showWhy = false; permLauncher.launch(VoicePermissionManager.runtimePermissions()) }, Modifier.weight(1f), primary = true)
        }
    }
    if (denied.isNotBlank()) GlassSheet({ denied = "" }, "Permission needed") {
        GText(denied, size = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Close", { denied = "" }, Modifier.weight(1f))
            GlassButton("Open Settings", { denied = ""; openAppSettings(ctx) }, Modifier.weight(1f), primary = true)
        }
    }
}

/** Level used by the microphone button's ripple: the real microphone loudness while a session is on. */
private fun orbLevelForMic(on: Boolean, engineActive: Boolean, micLevel: Float, legacy: Float): () -> Float =
    { if (!on) 0f else if (engineActive) micLevel else legacy }

@Composable
fun StatChip(text: String, modifier: Modifier = Modifier) {
    GlassCard(modifier, shape = RoundedCornerShape(50)) {
        GText(text, Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth(), size = 12.sp, maxLines = 1, align = TextAlign.Center)
    }
}
