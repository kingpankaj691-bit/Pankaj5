package com.nova.ai.suite

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.CompletableDeferred

/**
 * Invisible helper that shows Android's system document picker so overlay workflows (which have no screen of their own) can let you
 * choose any file. The result is returned to the waiting workflow; cancelling returns null.
 */
class PickerActivity : ComponentActivity() {
    companion object {
        @Volatile private var pending: CompletableDeferred<Uri?>? = null

        fun pick(ctx: Context, mime: String): CompletableDeferred<Uri?> {
            pending?.complete(null)
            val d = CompletableDeferred<Uri?>()
            pending = d
            try { ctx.startActivity(Intent(ctx, PickerActivity::class.java).putExtra("mime", mime).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { d.complete(null) }
            return d
        }

        /** Builds a MediaItem for any picked content URI (name, size, duration where it is a video). */
        fun itemFrom(ctx: Context, uri: Uri): MediaItem {
            var name = uri.lastPathSegment ?: "video"; var size = 0L
            try { ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) { c.getString(0)?.let { name = it }; size = c.getLong(1) } } } catch (e: Exception) { }
            var dur = 0L
            try { val r = MediaMetadataRetriever(); r.setDataSource(ctx, uri); dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L; r.release() } catch (e: Exception) { }
            return MediaItem(uri, name, "Picked with the document picker", size, dur, System.currentTimeMillis() / 1000)
        }
    }

    private val launcher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        pending?.complete(uri); pending = null
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) launcher.launch(arrayOf(intent.getStringExtra("mime") ?: "*/*"))
    }
}
