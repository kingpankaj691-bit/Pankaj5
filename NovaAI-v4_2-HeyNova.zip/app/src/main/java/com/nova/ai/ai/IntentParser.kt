package com.nova.ai.ai

import org.json.JSONObject

/**
 * Every action the LLM is allowed to ask for. [phrase] turns it into a sentence Nova's existing LocalCommandRouter already
 * understands (null = needs its own handler, added by a later part). The LLM never gets to run Android code.
 */
enum class NovaAction(val takesArg: Boolean = false, val sensitive: Boolean = false) {
    GET_BATTERY_STATUS, GET_TIME, TORCH_ON, TORCH_OFF, OPEN_APP(takesArg = true), OPEN_SETTINGS(takesArg = true),
    GET_NETWORK_STATUS, GET_TEMPERATURE_STATUS,
    ENABLE_SECURITY_MODE(sensitive = true), DISABLE_SECURITY_MODE(sensitive = true),
    ENABLE_EDITING_MODE, DISABLE_EDITING_MODE, ENABLE_NIGHT_MODE, DISABLE_NIGHT_MODE,
    REMEMBER(takesArg = true), SEARCH_WEB(takesArg = true), GET_WEATHER, GET_NEWS, CAMERA_DESCRIBE, CAMERA_READ_TEXT,
    READ_SCREEN;

    /** Sentence for the existing local router, or null when no handler exists yet. */
    fun phrase(arg: String): String? = when (this) {
        GET_BATTERY_STATUS -> "what is the battery level"
        GET_TIME -> "what time is it"
        TORCH_ON -> "flashlight on"
        TORCH_OFF -> "flashlight off"
        OPEN_APP -> if (arg.isBlank()) null else "open $arg"
        OPEN_SETTINGS -> if (arg.isBlank()) "open settings" else "open $arg settings"
        REMEMBER -> if (arg.isBlank()) null else "remember $arg"
        GET_NETWORK_STATUS -> "network status"
        GET_TEMPERATURE_STATUS -> "phone temperature"
        ENABLE_SECURITY_MODE -> "security mode on"
        DISABLE_SECURITY_MODE -> "security mode off"
        ENABLE_EDITING_MODE -> "editing mode on"
        DISABLE_EDITING_MODE -> "editing mode off"
        ENABLE_NIGHT_MODE -> "night mode on"
        DISABLE_NIGHT_MODE -> "night mode off"
        SEARCH_WEB -> if (arg.isBlank()) null else "web search for $arg"
        GET_WEATHER -> "weather"
        GET_NEWS -> "latest news batao"
        CAMERA_DESCRIBE -> "camera mein kya hai"
        CAMERA_READ_TEXT -> "read this text"
        READ_SCREEN -> "describe my screen"
    }
}

data class NovaIntent(val action: NovaAction, val arg: String = "")

sealed class ParsedReply {
    data class Plain(val text: String) : ParsedReply()
    data class Action(val intent: NovaIntent) : ParsedReply()
}

/** Reads the LLM answer. Anything that is not a clean, known action is treated as plain text, never executed. */
object IntentParser {
    fun parse(reply: String): ParsedReply {
        val t = reply.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (!t.startsWith("{") || !t.endsWith("}")) return ParsedReply.Plain(reply.trim())
        return try {
            val o = JSONObject(t)
            val name = o.optString("action").trim().uppercase()
            val action = NovaAction.values().firstOrNull { it.name == name } ?: return ParsedReply.Plain(reply.trim())
            ParsedReply.Action(NovaIntent(action, o.optString("arg").trim().take(200)))
        } catch (e: Exception) {
            ParsedReply.Plain(reply.trim())
        }
    }
}
