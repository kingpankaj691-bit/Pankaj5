package com.nova.ai.language

import java.util.Locale

data class Lang(val tag: String, val english: String, val native: String)

/** Languages NOVA offers. Whether speech recognition / TTS really supports one depends on the phone's installed engines. */
object LanguageCatalog {
    val all: List<Lang> = listOf(
        Lang("en-IN", "English", "English"), Lang("hi-IN", "Hindi", "हिन्दी"), Lang("ur-PK", "Urdu", "اردو"),
        Lang("bn-IN", "Bengali", "বাংলা"), Lang("ta-IN", "Tamil", "தமிழ்"), Lang("te-IN", "Telugu", "తెలుగు"),
        Lang("mr-IN", "Marathi", "मराठी"), Lang("gu-IN", "Gujarati", "ગુજરાતી"), Lang("kn-IN", "Kannada", "ಕನ್ನಡ"),
        Lang("ml-IN", "Malayalam", "മലയാളം"), Lang("pa-IN", "Punjabi", "ਪੰਜਾਬੀ"), Lang("or-IN", "Odia", "ଓଡ଼ିଆ"),
        Lang("as-IN", "Assamese", "অসমীয়া"), Lang("ne-NP", "Nepali", "नेपाली"), Lang("sa-IN", "Sanskrit", "संस्कृतम्"),
        Lang("ar-SA", "Arabic", "العربية"), Lang("fa-IR", "Persian", "فارسی"), Lang("fr-FR", "French", "Français"),
        Lang("de-DE", "German", "Deutsch"), Lang("es-ES", "Spanish", "Español"), Lang("pt-BR", "Portuguese", "Português"),
        Lang("it-IT", "Italian", "Italiano"), Lang("ru-RU", "Russian", "Русский"), Lang("ja-JP", "Japanese", "日本語"),
        Lang("ko-KR", "Korean", "한국어"), Lang("zh-CN", "Chinese", "中文"), Lang("tr-TR", "Turkish", "Türkçe"),
        Lang("id-ID", "Indonesian", "Bahasa Indonesia"), Lang("ms-MY", "Malay", "Bahasa Melayu"), Lang("th-TH", "Thai", "ไทย"),
        Lang("vi-VN", "Vietnamese", "Tiếng Việt"), Lang("nl-NL", "Dutch", "Nederlands"), Lang("pl-PL", "Polish", "Polski"),
        Lang("uk-UA", "Ukrainian", "Українська"), Lang("el-GR", "Greek", "Ελληνικά"), Lang("he-IL", "Hebrew", "עברית"),
        Lang("sv-SE", "Swedish", "Svenska"), Lang("ro-RO", "Romanian", "Română"), Lang("cs-CZ", "Czech", "Čeština"),
        Lang("hu-HU", "Hungarian", "Magyar"), Lang("da-DK", "Danish", "Dansk"), Lang("fi-FI", "Finnish", "Suomi"),
        Lang("nb-NO", "Norwegian", "Norsk"), Lang("fil-PH", "Filipino", "Filipino"), Lang("sw-KE", "Swahili", "Kiswahili"),
        Lang("si-LK", "Sinhala", "සිංහල"), Lang("my-MM", "Burmese", "မြန်မာ"), Lang("km-KH", "Khmer", "ខ្មែរ"),
        Lang("bg-BG", "Bulgarian", "Български"), Lang("hr-HR", "Croatian", "Hrvatski"), Lang("sk-SK", "Slovak", "Slovenčina")
    )
    fun byTag(tag: String): Lang? = all.firstOrNull { it.tag.equals(tag, true) } ?: all.firstOrNull { it.tag.substringBefore('-').equals(tag.substringBefore('-'), true) }
    fun locale(tag: String): Locale = Locale.forLanguageTag(tag)
}

/** What the user is writing in right now. [hinglish] means Hindi in Roman letters mixed with English. */
data class Detected(val tag: String, val name: String, val hinglish: Boolean, val confident: Boolean)

/**
 * Lightweight on-device language detector (Unicode script + common-word checks). It is a heuristic: short or mixed text
 * can be misjudged, which is why a manual language mode exists. Nothing is sent anywhere.
 */
object LanguageDetector {
    private val hindiRoman = setOf(
        "hai", "hain", "kya", "kaise", "kaisa", "kaun", "kahan", "kab", "kyun", "kyu", "karo", "kar", "kholo", "batao", "bata", "dikhao", "sunao",
        "mujhe", "mera", "meri", "mere", "tum", "tumhe", "aap", "apna", "nahi", "nahin", "haan", "ji", "bhai", "yaar", "accha", "achha", "thik",
        "abhi", "aaj", "kal", "phir", "aur", "ya", "se", "ko", "ka", "ki", "ke", "mein", "me", "par", "pe", "hoon", "ho", "tha", "thi", "raha",
        "rahi", "chahiye", "dena", "do", "lo", "likho", "dhoondo", "dhundo", "chalao", "band", "chalu", "bolo", "suno", "dekho", "samjhao", "naam"
    )
    private val french = setOf("le", "la", "les", "est", "je", "vous", "nous", "bonjour", "merci", "pas", "une", "des", "et", "avec", "pour", "ouvre", "quel")
    private val german = setOf("der", "die", "das", "und", "ich", "nicht", "ist", "ein", "eine", "bitte", "danke", "hallo", "wie", "mit", "öffne")
    private val spanish = setOf("el", "los", "las", "que", "por", "hola", "gracias", "está", "una", "con", "para", "abre", "cómo", "qué", "puedes")
    private val portuguese = setOf("não", "você", "obrigado", "olá", "uma", "com", "para", "abra", "como", "está", "porque", "isso")
    private val italian = setOf("che", "non", "ciao", "grazie", "una", "con", "per", "apri", "come", "sono", "perché", "questo")
    private val turkish = setOf("ve", "bir", "bu", "merhaba", "nasıl", "değil", "için", "aç", "evet", "hayır", "teşekkürler")
    private val indonesian = setOf("yang", "dan", "saya", "tidak", "apa", "terima", "kasih", "buka", "tolong", "bagaimana", "ini", "itu", "bisa")
    private val dutch = setOf("het", "een", "niet", "ik", "je", "dank", "hallo", "open", "hoe", "wat", "alsjeblieft")
    private val polish = setOf("nie", "tak", "dzień", "dobry", "dziękuję", "proszę", "jak", "co", "jest", "otwórz")
    private val english = setOf("the", "is", "are", "what", "how", "open", "please", "and", "you", "me", "my", "can", "this", "that", "to", "of", "in", "it", "for", "with")

    private fun count(words: List<String>, set: Set<String>) = words.count { it in set }

    fun detect(text: String): Detected {
        val t = text.trim()
        if (t.length < 2) return Detected("en-IN", "English", false, false)
        val c = IntArray(20)
        for (ch in t) when (ch.code) {
            in 0x0900..0x097F -> c[0]++; in 0x0980..0x09FF -> c[1]++; in 0x0A00..0x0A7F -> c[2]++; in 0x0A80..0x0AFF -> c[3]++
            in 0x0B00..0x0B7F -> c[4]++; in 0x0B80..0x0BFF -> c[5]++; in 0x0C00..0x0C7F -> c[6]++; in 0x0C80..0x0CFF -> c[7]++
            in 0x0D00..0x0D7F -> c[8]++; in 0x0600..0x06FF, in 0x0750..0x077F -> c[9]++; in 0x0E00..0x0E7F -> c[10]++
            in 0xAC00..0xD7AF, in 0x1100..0x11FF -> c[11]++; in 0x3040..0x30FF -> c[12]++; in 0x4E00..0x9FFF -> c[13]++
            in 0x0400..0x04FF -> c[14]++; in 0x0370..0x03FF -> c[15]++; in 0x0590..0x05FF -> c[16]++; in 0x0D80..0x0DFF -> c[17]++
            in 0x1000..0x109F -> c[18]++; in 0x1780..0x17FF -> c[19]++
        }
        val letters = t.count { it.isLetter() }.coerceAtLeast(1)
        val top = c.indices.maxByOrNull { c[it] } ?: 0
        if (c[top] * 3 >= letters) {
            fun d(tag: String, name: String) = Detected(tag, name, false, true)
            return when (top) {
                0 -> when {
                    Regex("(आहे|नाही|मला|तुम्ही|काय|करा)").containsMatchIn(t) -> d("mr-IN", "Marathi")
                    Regex("(छ\\b|तपाईं|हुन्छ|गर्नुहोस्|मलाई)").containsMatchIn(t) -> d("ne-NP", "Nepali")
                    Regex("(अस्ति|भवति|कृपया|नमः)").containsMatchIn(t) -> d("sa-IN", "Sanskrit")
                    else -> d("hi-IN", "Hindi")
                }
                1 -> if (t.contains('ৰ') || t.contains('ৱ')) d("as-IN", "Assamese") else d("bn-IN", "Bengali")
                2 -> d("pa-IN", "Punjabi"); 3 -> d("gu-IN", "Gujarati"); 4 -> d("or-IN", "Odia"); 5 -> d("ta-IN", "Tamil")
                6 -> d("te-IN", "Telugu"); 7 -> d("kn-IN", "Kannada"); 8 -> d("ml-IN", "Malayalam")
                9 -> when {
                    t.any { it == 'ے' || it == 'ں' || it == 'ہ' || it == 'ٹ' || it == 'ڈ' || it == 'ڑ' } -> d("ur-PK", "Urdu")
                    t.contains("است") || t.contains("می") || t.contains('گ') || t.contains('پ') || t.contains('چ') || t.contains('ژ') -> d("fa-IR", "Persian")
                    else -> d("ar-SA", "Arabic")
                }
                10 -> d("th-TH", "Thai"); 11 -> d("ko-KR", "Korean"); 12 -> d("ja-JP", "Japanese")
                13 -> if (c[12] > 0) d("ja-JP", "Japanese") else d("zh-CN", "Chinese")
                14 -> if (t.any { it == 'і' || it == 'ї' || it == 'є' || it == 'ґ' }) d("uk-UA", "Ukrainian") else d("ru-RU", "Russian")
                15 -> d("el-GR", "Greek"); 16 -> d("he-IL", "Hebrew"); 17 -> d("si-LK", "Sinhala"); 18 -> d("my-MM", "Burmese")
                else -> d("km-KH", "Khmer")
            }
        }
        // Latin script
        if (t.any { it in "ăơưđạệịộụ" || it in "ẹẻẽềếểễ" }) return Detected("vi-VN", "Vietnamese", false, true)
        val w = t.lowercase().split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        val hi = count(w, hindiRoman); val en = count(w, english)
        val scores = mapOf(
            "fr-FR" to count(w, french), "de-DE" to count(w, german), "es-ES" to count(w, spanish), "pt-BR" to count(w, portuguese),
            "it-IT" to count(w, italian), "tr-TR" to count(w, turkish), "id-ID" to count(w, indonesian), "nl-NL" to count(w, dutch), "pl-PL" to count(w, polish)
        )
        val bestOther = scores.maxByOrNull { it.value }
        if (hi >= 1 && hi >= (bestOther?.value ?: 0) && (hi * 2 >= w.size || hi >= en || hi >= 2)) return Detected("hi-IN", "Hinglish", true, hi >= 2)
        if (bestOther != null && bestOther.value >= 2 && bestOther.value > en) {
            val l = LanguageCatalog.byTag(bestOther.key)
            return Detected(bestOther.key, l?.english ?: "Other", false, true)
        }
        return Detected("en-IN", "English", false, en >= 1)
    }

    /** Instruction for Gemini about which language to answer in. */
    fun instruction(mode: String, manualTag: String, lastUserText: String): String = when (mode) {
        "english" -> "Reply in English."
        "hindi" -> "Reply in Hindi (Devanagari)."
        "hinglish" -> "Reply in Hinglish (Hindi in Roman letters)."
        "manual" -> LanguageCatalog.byTag(manualTag)?.let { "Reply in ${it.english} (${it.native}), whatever language the user writes in." } ?: "Reply in English."
        else -> {
            val d = detect(lastUserText)
            val base = "Reply in the language the user is using now and switch naturally when they switch. If they mix languages, answer in the same dominant mixed style."
            when {
                d.hinglish -> "$base The user is writing Hinglish (Hindi in Roman letters), so reply in Hinglish."
                d.confident && d.tag != "en-IN" -> "$base The user is writing ${d.name}, so reply in ${d.name} using the same script."
                else -> base
            }
        }
    }
}
