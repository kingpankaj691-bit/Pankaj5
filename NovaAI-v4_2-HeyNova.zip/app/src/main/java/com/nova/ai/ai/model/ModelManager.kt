package com.nova.ai.ai.model

import android.content.Context
import com.nova.ai.ai.ModelCatalog
import com.nova.ai.security.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * THE one place that knows which Gemini model Nova uses.
 *
 * - The selected ("active") model is stored under the existing "model" preference, so an upgrade keeps the user's choice.
 * - Typed chat, the voice fallback pipeline, follow-ups, summaries, web search and vision all read that same value.
 * - Nothing here ever substitutes another model. If the selected model cannot do something, the reason is reported.
 * - Capabilities come from Google's model list ([ModelRegistry]); [ModelRouter] turns them into a voice route.
 */
object ModelManager {
    private const val PREFS_APP = "nova_prefs"
    private const val PREFS_MODELS = "nova_models"

    @Volatile private var reg: ModelRegistry? = null
    private val _active = MutableStateFlow("")
    private val _route = MutableStateFlow("")

    fun registry(ctx: Context): ModelRegistry =
        reg ?: synchronized(this) { reg ?: ModelRegistry(ctx.applicationContext).also { reg = it } }

    /** Call once at start-up so providers that only have a [Prefs] can still see capabilities. */
    fun init(ctx: Context) { registry(ctx); activeFlow(ctx) }

    // ───────── the selected model ─────────

    /** The selected model id, read straight from preferences (no encrypted storage needed, so the service can call it). */
    fun activeModelId(ctx: Context): String =
        ModelCatalog.clean(ctx.applicationContext.getSharedPreferences(PREFS_APP, Context.MODE_PRIVATE).getString("model", null), ModelCatalog.DEFAULT_CHAT)

    fun activeFlow(ctx: Context): StateFlow<String> {
        if (_active.value.isEmpty()) _active.value = activeModelId(ctx)
        return _active
    }

    /** Display name of the selected model for notifications and status lines. */
    fun activeLabel(ctx: Context): String {
        val id = activeModelId(ctx)
        return registry(ctx).find(id)?.label ?: id
    }

    /** Persists a user choice. Returns false for an id that is not a valid model name. */
    fun select(ctx: Context, prefs: Prefs, rawId: String): Boolean {
        val id = ModelCatalog.clean(rawId, "")
        if (id.isBlank()) return false
        prefs.model = id
        _active.value = id
        return true
    }

    fun defaultModelId(prefs: Prefs): String = prefs.defaultModel

    fun setDefault(prefs: Prefs, id: String) { prefs.defaultModel = id }

    // ───────── capabilities and routing ─────────

    /** In-memory lookup for code that has no Context (providers). Null when the list is not loaded or lacks the model. */
    fun findCached(id: String): GeminiModel? = reg?.find(id)

    fun capabilities(ctx: Context, id: String): ModelCapabilities =
        registry(ctx).find(id)?.caps ?: ModelClassifier.classify(id, emptySet(), known = false)

    fun preferNative(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).getBoolean("prefer_native", true)

    fun setPreferNative(ctx: Context, on: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).edit().putBoolean("prefer_native", on).apply()
    }

    /** Native Live or the Speech-to-Text -> selected model -> Text-to-Speech pipeline, for the model selected right now. */
    fun voiceRoute(ctx: Context): VoiceRoute {
        val id = activeModelId(ctx)
        val route = ModelRouter.route(id, registry(ctx).find(id), learnedNoNative(ctx, id), preferNative(ctx))
        _route.value = route.describe()
        return route
    }

    // ───────── what Live taught us about a model ─────────

    fun learnedNoNative(ctx: Context, id: String): Boolean =
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).getString("live_$id", null) == "NONE"

    /** The Live API refused this model's audio output: from now on the voice fallback is used for it (until the user resets). */
    fun learnNoNative(ctx: Context, id: String) {
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).edit().putString("live_$id", "NONE").apply()
    }

    fun forgetLearned(ctx: Context, id: String) {
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).edit().remove("live_$id").remove("tx_$id").apply()
    }

    /** A modality that worked or was demanded for a transcription model, learned from error 1007. */
    fun learnedTranscribeModality(ctx: Context, id: String): LiveModality? =
        when (ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).getString("tx_$id", null)) {
            "AUDIO" -> LiveModality.AUDIO
            "TEXT" -> LiveModality.TEXT
            else -> null
        }

    fun learnTranscribeModality(ctx: Context, id: String, m: LiveModality) {
        ctx.applicationContext.getSharedPreferences(PREFS_MODELS, Context.MODE_PRIVATE).edit().putString("tx_$id", m.name).apply()
    }

    /** Model that does live speech recognition (never the answering model). */
    fun transcriptionModel(ctx: Context, preferred: String): String? =
        ModelRouter.pickTranscription(preferred, registry(ctx).models.value, ModelCatalog.DEFAULT_TRANSCRIBE)

    /** Transcription models for the Jarvis settings picker. */
    fun transcriptionEntries(ctx: Context): List<ModelCatalog.Entry> {
        val fromList = registry(ctx).models.value.filter { it.caps.transcription }.map { ModelCatalog.Entry(it.id, it.label) }
        return fromList.ifEmpty { ModelCatalog.live.filter { it.id.contains("transcribe", true) } }
    }

    // ───────── refresh ─────────

    /** Refreshes the model list when it is missing or older than 12 hours. Safe to call from any background coroutine. */
    suspend fun refreshIfStale(ctx: Context, prefs: Prefs) {
        val r = registry(ctx)
        if (!r.isStale() || prefs.localOnly || !prefs.aiEnabled || prefs.apiKey.isBlank()) return
        r.refresh(prefs.apiKey)
    }

    suspend fun refresh(ctx: Context, prefs: Prefs): Boolean = registry(ctx).refresh(prefs.apiKey)
}
