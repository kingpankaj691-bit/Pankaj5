package com.nova.ai.jarvis

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Settings of the Jarvis features. Plain SharedPreferences (same file as Prefs); no secrets are kept here. */
class JarvisPrefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)

    /**
     * duplex = two-way Gemini Live voice (default: you talk, Nova answers with her voice, you can interrupt her)
     * auto = Gemini Live speech-to-text, with the offline recognizer as backup | live | clips | offline
     */
    var sttMode: String
        get() {
            // v2.9: the microphone button used to start the one-way "auto" recognizer, so Nova never answered by voice.
            // The untouched old default is moved to two-way voice once; an explicit choice (offline, clips...) is kept.
            if (!sp.getBoolean("j_duplex_default_v29", false)) {
                val e = sp.edit().putBoolean("j_duplex_default_v29", true)
                if (sp.getString("j_stt", "auto") == "auto") e.putString("j_stt", "duplex")
                e.apply()
            }
            return sp.getString("j_stt", "duplex") ?: "duplex"
        }
        set(v) = sp.edit().putString("j_stt", v).apply()
    var liveModel: String
        get() = com.nova.ai.ai.ModelCatalog.clean(sp.getString("j_live_model", null), com.nova.ai.ai.ModelCatalog.DEFAULT_LIVE)
        set(v) = sp.edit().putString("j_live_model", com.nova.ai.ai.ModelCatalog.clean(v, com.nova.ai.ai.ModelCatalog.DEFAULT_LIVE)).apply()
    /** en-in | hi */
    var offlineLang: String
        get() = sp.getString("j_off_lang", "en-in") ?: "en-in"
        set(v) = sp.edit().putString("j_off_lang", v).apply()
    /** Keep listening while Nova speaks so you can interrupt her (barge-in). On by default; uses the echo-cancelling microphone. */
    var interrupt: Boolean
        get() = sp.getBoolean("j_interrupt", true)
        set(v) = sp.edit().putBoolean("j_interrupt", v).apply()

    var neuralTts: Boolean
        get() = sp.getBoolean("j_neural", false)
        set(v) = sp.edit().putBoolean("j_neural", v).apply()
    var ttsModel: String
        get() = com.nova.ai.ai.ModelCatalog.clean(sp.getString("j_tts_model", null), com.nova.ai.ai.ModelCatalog.DEFAULT_TTS)
        set(v) = sp.edit().putString("j_tts_model", com.nova.ai.ai.ModelCatalog.clean(v, com.nova.ai.ai.ModelCatalog.DEFAULT_TTS)).apply()
    var ttsVoiceName: String
        get() = sp.getString("j_tts_voice", "Kore") ?: "Kore"
        set(v) = sp.edit().putString("j_tts_voice", v.trim()).apply()

    var orb: Boolean
        get() = sp.getBoolean("j_orb", false)
        set(v) = sp.edit().putBoolean("j_orb", v).apply()

    var callAnnounce: Boolean
        get() = sp.getBoolean("j_call_announce", false)
        set(v) = sp.edit().putBoolean("j_call_announce", v).apply()
    var callVoiceControl: Boolean
        get() = sp.getBoolean("j_call_voice", true)
        set(v) = sp.edit().putBoolean("j_call_voice", v).apply()

    /** Minutes after midnight for the spoken morning briefing, or -1 for off. */
    var briefingMinute: Int
        get() = sp.getInt("j_brief_min", -1)
        set(v) = sp.edit().putInt("j_brief_min", v).apply()
    var lastBriefingDay: Int
        get() = sp.getInt("j_brief_day", -1)
        set(v) = sp.edit().putInt("j_brief_day", v).apply()
    var proactive: Boolean
        get() = sp.getBoolean("j_proactive", true)
        set(v) = sp.edit().putBoolean("j_proactive", v).apply()

    var locationReminders: Boolean
        get() = sp.getBoolean("j_loc", false)
        set(v) = sp.edit().putBoolean("j_loc", v).apply()

    var carMode: Boolean
        get() = sp.getBoolean("j_car", false)
        set(v) = sp.edit().putBoolean("j_car", v).apply()
    var carBtName: String
        get() = sp.getString("j_car_bt", "") ?: ""
        set(v) = sp.edit().putString("j_car_bt", v.trim()).apply()

    var agent: Boolean
        get() = sp.getBoolean("j_agent", false)
        set(v) = sp.edit().putBoolean("j_agent", v).apply()

    /** The name you call Nova by. Matched in what the recognizer hears. */
    var wakeName: String
        get() = (sp.getString("j_wake_name", "nova") ?: "nova").ifBlank { "nova" }
        set(v) = sp.edit().putString("j_wake_name", v.trim().lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), "")).apply()
    /** Offline wake gate: nothing is sent to Gemini until the offline recognizer hears the name. */
    var wakeGate: Boolean
        get() = sp.getBoolean("j_wake_gate", false)
        set(v) = sp.edit().putBoolean("j_wake_gate", v).apply()

    // ── "Hey Nova" floating voice assistant ──
    /** Hey Nova: the offline gate listens for whole wake phrases and Gemini Live only connects after one is heard. */
    var heyNova: Boolean
        get() = sp.getBoolean("j_hey", false)
        set(v) = sp.edit().putBoolean("j_hey", v).apply()
    /** Comma separated built-in phrase ids that are on (default: the twelve Hey/Hello/Hi Nova and Jaan phrases). "-" = none. */
    var wakePhraseIds: String
        get() = sp.getString("j_wake_ids", null) ?: WakePhrases.joinIds(WakePhrases.DEFAULT_IDS)
        set(v) = sp.edit().putString("j_wake_ids", WakePhrases.joinIds(v.split(',').map { it.trim() }.filter { it.isNotEmpty() && it != WakePhrases.NONE })).apply()
    /** Your own wake phrases, one per line (English or Devanagari). */
    var customPhrases: String
        get() = sp.getString("j_wake_custom", "") ?: ""
        set(v) = sp.edit().putString("j_wake_custom", v).apply()
    /** The default activation phrase (id). Always on; shown first and used for the tests. */
    var defaultPhraseId: String
        get() = sp.getString("j_wake_default", "hey_nova") ?: "hey_nova"
        set(v) = sp.edit().putString("j_wake_default", v).apply()
    fun wakeCatalog(): List<WakePhrases.Phrase> = WakePhrases.catalog(wakeName, customPhrases) { Deva.variants(it) }
    /** The phrases that are switched on (built-in ones that are ticked, plus all custom ones). */
    fun enabledPhrases(): List<WakePhrases.Phrase> = WakePhrases.enabled(wakeCatalog(), WakePhrases.parseIds(wakePhraseIds), defaultPhraseId)
    /**
     * Every spelling of the active phrases, for removing the wake phrase from a transcript. Hey Nova on: all enabled forms
     * (Devanagari forms also in Roman letters, because the dispatcher works on transliterated text). Old name-only gate: just the name.
     */
    fun activeWakePhrases(): List<String> =
        if (heyNova) enabledPhrases().flatMap { p -> p.forms.map { it.text } }.flatMap { t -> if (Roman.hasIndic(t)) listOf(t, Roman.latin(t)) else listOf(t) }.distinct()
        else listOf(WakePhrases.cleanName(wakeName))
    /** Any offline gating at all (Hey Nova or the older name-only gate). */
    val gateOn: Boolean get() = heyNova || wakeGate
    /** Keep a small orb on screen while idle. Default: yes for the old always-on orb, no once Hey Nova is on. */
    var orbIdleMinimized: Boolean
        get() = if (sp.contains("j_orb_idle")) sp.getBoolean("j_orb_idle", true) else !heyNova
        set(v) = sp.edit().putBoolean("j_orb_idle", v).apply()
    /** Fewer particles, ~20 fps. */
    var orbReduced: Boolean
        get() = sp.getBoolean("j_orb_reduced", false)
        set(v) = sp.edit().putBoolean("j_orb_reduced", v).apply()
    /** Saves battery: reduced effects, the wake recognizer skips silence, shorter follow-up window. */
    var batterySaver: Boolean
        get() = sp.getBoolean("j_batt", false)
        set(v) = sp.edit().putBoolean("j_batt", v).apply()
    var orbHaptics: Boolean
        get() = sp.getBoolean("j_orb_haptic", true)
        set(v) = sp.edit().putBoolean("j_orb_haptic", v).apply()
    /** Orb position (px, centre of the orb), or -1 for the default. */
    var orbX: Int
        get() = sp.getInt("j_orb_x", -1)
        set(v) = sp.edit().putInt("j_orb_x", v).apply()
    var orbY: Int
        get() = sp.getInt("j_orb_y", -1)
        set(v) = sp.edit().putInt("j_orb_y", v).apply()

    /** One "Name:number" per line. */
    var sosContacts: String
        get() = sp.getString("j_sos_contacts", "") ?: ""
        set(v) = sp.edit().putString("j_sos_contacts", v).apply()
    var sosCall: Boolean
        get() = sp.getBoolean("j_sos_call", true)
        set(v) = sp.edit().putBoolean("j_sos_call", v).apply()

    var taskerIn: Boolean
        get() = sp.getBoolean("j_tasker_in", false)
        set(v) = sp.edit().putBoolean("j_tasker_in", v).apply()
    var taskerToken: String
        get() = sp.getString("j_tasker_token", "") ?: ""
        set(v) = sp.edit().putString("j_tasker_token", v.trim()).apply()
    var taskerEvents: Boolean
        get() = sp.getBoolean("j_tasker_events", false)
        set(v) = sp.edit().putBoolean("j_tasker_events", v).apply()

    var clipboard: Boolean
        get() = sp.getBoolean("j_clip", false)
        set(v) = sp.edit().putBoolean("j_clip", v).apply()
    var clipMinChars: Int
        get() = sp.getInt("j_clip_min", 300)
        set(v) = sp.edit().putInt("j_clip_min", v).apply()

    var tuyaRegion: String
        get() = sp.getString("j_tuya_region", "in") ?: "in"
        set(v) = sp.edit().putString("j_tuya_region", v).apply()
    var tuyaClientId: String
        get() = sp.getString("j_tuya_id", "") ?: ""
        set(v) = sp.edit().putString("j_tuya_id", v.trim()).apply()
    var haUrl: String
        get() = sp.getString("j_ha_url", "") ?: ""
        set(v) = sp.edit().putString("j_ha_url", v.trim().trimEnd('/')).apply()

    /** Smart-home devices as JSON (see SmartHome.Dev). */
    var devicesJson: String
        get() = sp.getString("j_devices", "[]") ?: "[]"
        set(v) = sp.edit().putString("j_devices", v).apply()

    // ── saved places and location reminders (JSON) ──
    data class Place(val name: String, val lat: Double, val lon: Double)
    data class LocReminder(val id: Long, val place: String, val what: String, val lat: Double, val lon: Double, val radius: Float)

    fun places(): List<Place> = try {
        val a = JSONArray(sp.getString("j_places", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Place(o.getString("n"), o.getDouble("a"), o.getDouble("o")) } }
    } catch (e: Exception) { emptyList() }

    fun savePlace(p: Place) {
        val rest = places().filter { !it.name.equals(p.name, true) } + p
        sp.edit().putString("j_places", JSONArray(rest.map { JSONObject().put("n", it.name).put("a", it.lat).put("o", it.lon) }).toString()).apply()
    }

    fun reminders(): List<LocReminder> = try {
        val a = JSONArray(sp.getString("j_locrem", "[]"))
        (0 until a.length()).map {
            a.getJSONObject(it).let { o -> LocReminder(o.getLong("i"), o.getString("p"), o.getString("w"), o.getDouble("a"), o.getDouble("o"), o.getDouble("r").toFloat()) }
        }
    } catch (e: Exception) { emptyList() }

    fun saveReminders(list: List<LocReminder>) {
        sp.edit().putString("j_locrem", JSONArray(list.map {
            JSONObject().put("i", it.id).put("p", it.place).put("w", it.what).put("a", it.lat).put("o", it.lon).put("r", it.radius.toDouble())
        }).toString()).apply()
    }
}

/** Hindi (Devanagari) speech comes back in Devanagari; Nova's local command router understands Roman Hinglish. */
object Roman {
    private val tr: android.icu.text.Transliterator? by lazy {
        try { android.icu.text.Transliterator.getInstance("Any-Latin; Latin-ASCII") } catch (e: Exception) { null }
    }

    fun hasIndic(s: String): Boolean = s.any { it in '\u0900'..'\u0DFF' }

    fun latin(s: String): String {
        if (!hasIndic(s)) return s
        return try { tr?.transliterate(s) ?: s } catch (e: Exception) { s }
    }
}

/** Hinglish typed in Roman letters -> Devanagari spellings for the Hindi model ("meri jaan" -> "मेरी जान"). Best effort: the model's vocabulary decides. */
object Deva {
    private val tr: android.icu.text.Transliterator? by lazy {
        try { android.icu.text.Transliterator.getInstance("Latin-Devanagari") } catch (e: Exception) { null }
    }

    fun variants(latin: String): List<String> {
        val t = tr ?: return emptyList()
        val l = latin.lowercase()
        val spellings = listOf(l, l.replace(Regex("i\\b"), "ee"), l.replace("oo", "u"))
        return spellings.distinct().mapNotNull { try { t.transliterate(it) } catch (e: Exception) { null } }.filter { Roman.hasIndic(it) }.distinct()
    }
}
