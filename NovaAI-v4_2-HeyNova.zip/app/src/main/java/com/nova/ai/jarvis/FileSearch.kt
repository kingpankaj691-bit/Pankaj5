package com.nova.ai.jarvis

import android.Manifest
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Finds files and songs on the phone itself (no internet), and opens or plays them. */
object FileSearch {
    class Hit(val uri: Uri, val name: String, val mime: String, val folder: String, val modified: Long)
    class Spec(val mimes: List<String>, val sinceMs: Long?, val untilMs: Long?, val keyword: String, val label: String)

    @Volatile var last: List<Hit> = emptyList()

    /** Why the last search returned nothing because of an error (empty = it really found nothing). */
    @Volatile var lastError: String = ""

    /** Null when the search can run; otherwise the exact missing permission, from the REAL Android state. */
    fun accessProblem(ctx: Context, s: Spec): String? =
        com.nova.ai.files.FileAccessPolicy.searchProblem(com.nova.ai.files.FileAccess.state(ctx, 0), s.mimes, hinglish = true)

    /** True only for "All files access". Photos/videos/audio searches do not need it: use [accessProblem]. */
    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private val stop = Regex("\\b(mere|mera|meri|phone|se|mein|me|ka|ki|ke|wali|wala|wale|dhundho|dhoondo|dhundh|dhoond|khojo|do|karo|find|search|my|the|a|an|for|from|on|in|of|file|files|pdf|document|documents|doc|docx|word|excel|sheet|ppt|presentation|photo|photos|image|images|video|videos|kal|aaj|parso|yesterday|today|is|hafte|pichle|last|week|month|mahine|din|days|offline|gaane|gaana|song|songs|music|play|bajao|chalao|sunao|please|kholo|open|batao|dikhao|show|local|storage)\\b|\\d+")

    fun keywordOf(l: String) = l.replace(stop, " ").replace(Regex("\\s+"), " ").trim()

    fun spec(l: String): Spec {
        val mimes = ArrayList<String>(); var label = "files"
        fun add(vararg m: String) { mimes.addAll(m) }
        when {
            Regex("\\bpdf\\b").containsMatchIn(l) -> { add("application/pdf"); label = "PDF" }
            Regex("\\b(word|docx?)\\b").containsMatchIn(l) -> { add("application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"); label = "Word documents" }
            Regex("\\b(excel|sheet|xlsx?)\\b").containsMatchIn(l) -> { add("application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); label = "spreadsheets" }
            Regex("\\b(ppt|presentation)\\b").containsMatchIn(l) -> { add("application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"); label = "presentations" }
            Regex("\\b(photos?|images?|pictures?|tasveer)\\b").containsMatchIn(l) -> { add("image/%"); label = "photos" }
            Regex("\\bvideos?\\b").containsMatchIn(l) -> { add("video/%"); label = "videos" }
            Regex("\\b(songs?|gaane|gaana|audio|music)\\b").containsMatchIn(l) -> { add("audio/%"); label = "audio files" }
            Regex("\\bdocuments?\\b").containsMatchIn(l) -> { add("application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain"); label = "documents" }
        }
        val cal = Calendar.getInstance()
        fun midnight(daysAgo: Int): Long { val c = cal.clone() as Calendar; c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); c.add(Calendar.DAY_OF_YEAR, -daysAgo); return c.timeInMillis }
        var since: Long? = null; var until: Long? = null
        Regex("(?:last|pichle)\\s+(\\d+)\\s+(?:days?|din)").find(l)?.let { since = midnight(it.groupValues[1].toInt()) }
        if (since == null) when {
            Regex("\\b(kal|yesterday)\\b").containsMatchIn(l) -> { since = midnight(1); until = midnight(0) }
            Regex("\\bparso\\b").containsMatchIn(l) -> { since = midnight(2); until = midnight(1) }
            Regex("\\b(aaj|today)\\b").containsMatchIn(l) -> since = midnight(0)
            Regex("(is hafte|this week|pichle hafte|last week|hafte)").containsMatchIn(l) -> since = midnight(7)
            Regex("(is mahine|this month|pichle mahine|last month)").containsMatchIn(l) -> since = midnight(30)
        }
        return Spec(mimes, since, until, keywordOf(l), label)
    }

    fun search(ctx: Context, s: Spec, limit: Int = 8): List<Hit> {
        val uri = MediaStore.Files.getContentUri("external")
        val sel = ArrayList<String>(); val args = ArrayList<String>()
        if (s.mimes.isNotEmpty()) { sel.add(s.mimes.joinToString(" OR ", "(", ")") { "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE ?" }); args.addAll(s.mimes) }
        s.sinceMs?.let { sel.add("${MediaStore.Files.FileColumns.DATE_MODIFIED} >= ?"); args.add((it / 1000).toString()) }
        s.untilMs?.let { sel.add("${MediaStore.Files.FileColumns.DATE_MODIFIED} < ?"); args.add((it / 1000).toString()) }
        if (s.keyword.isNotBlank()) { sel.add("${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?"); args.add("%" + s.keyword.replace(' ', '%') + "%") }
        sel.add("${MediaStore.Files.FileColumns.SIZE} > 0")
        val q = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel.joinToString(" AND "))
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toTypedArray())
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val out = ArrayList<Hit>()
        lastError = ""
        try {
            val cols = mutableListOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.DATE_MODIFIED)
            if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.Files.FileColumns.RELATIVE_PATH)     // folder name exists only on Android 10+
            ctx.contentResolver.query(uri, cols.toTypedArray(), q, null)?.use { c ->
                while (c.moveToNext()) out.add(Hit(ContentUris.withAppendedId(uri, c.getLong(0)), c.getString(1).orEmpty(), c.getString(2).orEmpty(),
                    if (c.columnCount > 4) c.getString(4).orEmpty() else "", c.getLong(3) * 1000))
            }
        } catch (e: Exception) { lastError = e.javaClass.simpleName + (e.message?.let { ": " + it.take(80) } ?: "") }
        last = out
        return out
    }

    fun describe(hits: List<Hit>, label: String): String {
        if (hits.isEmpty()) return "Koi $label nahi mili."
        val f = SimpleDateFormat("d MMM", Locale.getDefault())
        return "${hits.size} $label mili: " + hits.take(3).mapIndexed { i, h -> "${i + 1}. ${h.name}, ${f.format(Date(h.modified))}${if (h.folder.isNotBlank()) ", ${h.folder.trimEnd('/')}" else ""}" }.joinToString(". ") +
            (if (hits.size > 3) ". Aur ${hits.size - 3} aur." else "") + " Kholne ke liye bolo: pehli wali kholo."
    }

    fun open(ctx: Context, index: Int): String {
        val h = last.getOrNull(index) ?: return "Pehle koi file dhundho."
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(h.uri, h.mime.ifBlank { "*/*" }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            "${h.name} khol rahi hoon."
        } catch (e: Exception) { "Is file ko kholne wala koi app nahi mila." }
    }

    /** Offline songs: query by title, artist or album; empty query = everything, shuffled. */
    fun playSongs(ctx: Context, query: String): String {
        val audio = com.nova.ai.files.FileAccessPolicy.decide(com.nova.ai.files.FileAccess.state(ctx, 0), com.nova.ai.files.FileNeed.AUDIO, hinglish = true)
        if (audio is com.nova.ai.files.Access.Denied) return audio.reason
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val q = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${MediaStore.Audio.Media.IS_MUSIC} != 0" +
                if (query.isNotBlank()) " AND (${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ? OR ${MediaStore.Audio.Media.ALBUM} LIKE ?)" else "")
            if (query.isNotBlank()) { val p = "%$query%"; putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf(p, p, p)) }
            putInt(ContentResolver.QUERY_ARG_LIMIT, 300)
        }
        val tracks = ArrayList<Pair<Uri, String>>()
        try {
            ctx.contentResolver.query(uri, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE), q, null)?.use { c ->
                while (c.moveToNext()) tracks.add(ContentUris.withAppendedId(uri, c.getLong(0)) to c.getString(1).orEmpty())
            }
        } catch (e: Exception) { }
        if (tracks.isEmpty()) return if (query.isBlank()) "Phone mein koi gaana nahi mila." else "'$query' naam ka koi gaana phone mein nahi mila."
        if (query.isBlank()) tracks.shuffle()
        LocalPlayer.play(ctx, tracks)
        return "Phone se chala rahi hoon: ${tracks.first().second}" + if (tracks.size > 1) " aur ${tracks.size - 1} aur gaane." else "."
    }
}

/** Plays offline songs inside Nova. It has a MediaSession, so "next song", "pause music" and headset buttons control it. */
object LocalPlayer {
    private var player: MediaPlayer? = null
    private var session: MediaSession? = null
    private var queue: List<Pair<Uri, String>> = emptyList()
    private var index = 0
    private var appCtx: Context? = null
    private var focus: AudioFocusRequest? = null

    @Synchronized fun play(ctx: Context, tracks: List<Pair<Uri, String>>) {
        appCtx = ctx.applicationContext
        queue = tracks; index = 0
        ensureSession()
        startCurrent()
    }

    private fun ensureSession() {
        if (session != null) return
        val s = MediaSession(appCtx!!, "NovaLocalPlayer")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { resume() }
            override fun onPause() { pause() }
            override fun onSkipToNext() { next() }
            override fun onSkipToPrevious() { previous() }
            override fun onStop() { stop() }
        })
        session = s
    }

    private fun audioFocus(): Boolean {
        val am = appCtx!!.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener { c -> if (c == AudioManager.AUDIOFOCUS_LOSS || c == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause() }.build()
        focus = req
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    @Synchronized private fun startCurrent() {
        val ctx = appCtx ?: return
        val t = queue.getOrNull(index) ?: return
        try { player?.release() } catch (e: Exception) { }
        val p = MediaPlayer()
        player = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setDataSource(ctx, t.first)
            p.setOnCompletionListener { next() }
            p.setOnErrorListener { _, _, _ -> next(); true }
            p.prepare()
            if (audioFocus()) { p.start(); state(PlaybackState.STATE_PLAYING) }
        } catch (e: Exception) { next() }
    }

    private fun state(st: Int) {
        val s = session ?: return
        s.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP)
            .setState(st, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build())
        s.isActive = st != PlaybackState.STATE_STOPPED
    }

    @Synchronized fun pause() { try { player?.pause() } catch (e: Exception) { }; state(PlaybackState.STATE_PAUSED) }
    @Synchronized fun resume() { try { player?.start() } catch (e: Exception) { }; state(PlaybackState.STATE_PLAYING) }
    @Synchronized fun next() { if (queue.isEmpty()) return; index = (index + 1) % queue.size; startCurrent() }
    @Synchronized fun previous() { if (queue.isEmpty()) return; index = (index - 1 + queue.size) % queue.size; startCurrent() }
    @Synchronized fun stop() {
        try { player?.release() } catch (e: Exception) { }
        player = null; queue = emptyList()
        state(PlaybackState.STATE_STOPPED)
        try { session?.release() } catch (e: Exception) { }
        session = null
        focus?.let { try { (appCtx?.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it) } catch (e: Exception) { } }
    }
}
