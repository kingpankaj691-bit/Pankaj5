package com.nova.ai.voice

import kotlinx.coroutines.CoroutineScope

/** Raw capture format: signed 16-bit little-endian PCM. */
data class PcmFormat(val sampleRate: Int, val channels: Int)

/**
 * Receives PCM chunks straight from AudioRecord and turns them into recognized text.
 * AudioCapture knows nothing about Gemini or any other recognizer; it only talks to this interface.
 */
interface SpeechProcessingEngine {

    /** Called once the real AudioRecord format is known (and again if it changes after a reopen). */
    fun start(format: PcmFormat, scope: CoroutineScope)

    /**
     * Called for every captured chunk, on the capture thread. The array is reused by the caller, so copy what you keep.
     * Must return quickly: blocking here makes AudioRecord overrun and lose audio.
     */
    suspend fun processAudio(audioData: ByteArray, length: Int)

    /** Stops workers and drops any buffered audio. Safe to call more than once. */
    fun stop()
}
