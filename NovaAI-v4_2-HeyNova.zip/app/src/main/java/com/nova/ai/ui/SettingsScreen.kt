package com.nova.ai.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.nova.ai.R
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.ai.Personality
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.compose.runtime.collectAsState
import androidx.core.content.ContextCompat
import com.nova.ai.automation.BootReceiver
import com.nova.ai.memory.MemoryEntry
import com.nova.ai.voice.VoiceState
import com.nova.ai.voice.VoiceStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.nova.ai.permissions.NovaPermissions
import com.nova.ai.permissions.PermItem
import androidx.core.app.NotificationManagerCompat

private val PAGES = listOf(
    Triple("dash", "✅", "Permission Dashboard"), Triple("gemini", "🧠", "AI & Gemini"), Triple("persona", "🎭", "Personality"), Triple("voice", "🎙", "Voice"),
    Triple("look", "🎨", "Appearance"), Triple("glass", "🪟", "Liquid Glass"), Triple("scan", "🛰", "Device Intelligence"),
    Triple("perms", "🔐", "Permissions"), Triple("screen", "🖥", "Screen Assistant"), Triple("bg", "📡", "Background Assistant"),
    Triple("reliability", "🔋", "Background Reliability"), Triple("notif", "🔔", "Notifications"), Triple("memory", "💾", "Memory"),
    Triple("dev", "💻", "Developer"), Triple("security", "🔏", "Security & Voice Lock"), Triple("lock", "📵", "Lock Screen Assistant"),
    Triple("people", "👥", "People & Relationships"), Triple("offline", "📴", "Offline Mode"), Triple("plugins", "🧩", "Plugins"), Triple("privacy", "🛡", "Privacy & Security"),
    Triple("lang", "🌐", "Language"), Triple("web", "🔎", "Web Search"), Triple("automation", "⏱", "Automations"),
    Triple("jarvis", "⚡", "Jarvis Pack"),
    Triple("photos", "🖼", "Photos & Videos"), Triple("gallery", "🌄", "Gallery"), Triple("filemgr", "📁", "File Manager"), Triple("files", "🗂", "Files & Storage"),
    Triple("advctl", "🛠", "Advanced System Control"), Triple("shizuku", "🔌", "Shizuku"),
    Triple("future", "🧬", "Future Modules"),
    Triple("about", "✦", "About NOVA")
)
private val KEYWORDS = mapOf(
    "gemini" to "api key model temperature system prompt context provider test openai chatgpt gpt switch",
    "persona" to "personality mood override gf jarvis custom nakhra",
    "voice" to "speech speed pitch volume language hindi hinglish tts wake listening auto speak",
    "look" to "theme dark light accent color avatar orb",
    "glass" to "blur transparency material animation reduced motion frosted metallic",
    "scan" to "device info battery storage ram installed apps rescan",
    "bg" to "microphone foreground service notification wake hey nova pause resume stop",
    "reliability" to "boot restart battery optimization auto-start doze recents background",
    "dash" to "permission dashboard status accessibility shizuku all files saf microphone notifications screen capture internet",
    "perms" to "permission microphone contacts phone camera bluetooth location media",
    "screen" to "accessibility click scroll read screen",
    "memory" to "remember delete forget pin expire ignored temporary",
    "notif" to "notification listener apps summarize",
    "dev" to "developer code model debug formatting",
    "security" to "voice lock owner mode biometric fingerprint protect sensitive",
    "lock" to "lock screen locked flashlight timer unlock",
    "offline" to "offline internet no network local",
    "people" to "people relationships mummy bhai dost nickname merge family friends contacts",
    "plugins" to "modules calendar weather music notes reminders study gaming",
    "privacy" to "confirm confirmation clear data api key security proactive chat history",
    "about" to "version license privacy policy terms update",
    "lang" to "language auto manual hindi english urdu bengali tamil telugu arabic french german spanish japanese korean chinese tts stt voice",
    "web" to "internet search news price research official website youtube sources",
    "automation" to "routine trigger battery headphones reminder schedule log",
    "jarvis" to "live streaming offline vosk natural voice orb assistant briefing reply call answer location reminder car mode interpreter agent function calling proactive",
    "photos" to "photos videos media permission photo picker selected gemini analyze privacy consent",
    "gallery" to "gallery photos videos thumbnails albums delete trash copy organize analyze",
    "filemgr" to "file manager files folders browse search recent documents images videos audio downloads apk zip storage usage sd card internal history duplicates organize",
    "files" to "files storage saf folder document all files manage external storage",
    "advctl" to "advanced system control dashboard automation history failed tasks capabilities compatibility services",
    "shizuku" to "shizuku adb shell wireless debugging permission binder reconnect system control",
    "future" to "weather calendar translation pdf camera smart home pc interfaces modules"
)

/** Lets a command open a specific Settings page (for example the Gallery). Consumed once by SettingsScreen. */
object SettingsNav { var request by mutableStateOf<String?>(null) }

@Composable
fun SettingsScreen(vm: NovaViewModel) {
    var page by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(SettingsNav.request) { SettingsNav.request?.let { page = it; SettingsNav.request = null } }
    var q by rememberSaveable { mutableStateOf("") }
    BackHandler(enabled = page.isNotEmpty()) { page = "" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (page.isEmpty()) {
            GText("Settings", size = 24.sp, weight = FontWeight.SemiBold)
            GlassTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = "Search settings")
            PAGES.filter { q.isBlank() || (it.third + " " + (KEYWORDS[it.first] ?: "")).contains(q.trim(), true) }.forEach { (id, glyph, title) ->
                GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        GlassListItem(title, glyph = glyph, onClick = { page = id }, trailing = { GText("›", size = 22.sp) })
                    }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassIconButton("‹", "Back", { page = "" })
                GText(PAGES.first { it.first == page }.third, size = 22.sp, weight = FontWeight.SemiBold)
            }
            when (page) {
                "gemini" -> GeminiPage(vm)
                "persona" -> PersonaPage(vm)
                "voice" -> VoicePage(vm)
                "look" -> AppearancePage(vm)
                "glass" -> GlassPage(vm)
                "notif" -> NotificationsPage(vm)
                "scan" -> ScanPage(vm)
                "reliability" -> ReliabilityPage(vm)
                "security" -> SecurityPage(vm)
                "lock" -> LockPage(vm)
                "offline" -> OfflinePage(vm)
                "people" -> PeoplePage(vm)
                "plugins" -> PluginsPage(vm)
                "dash" -> PermissionDashboardPage(vm)
                "perms" -> PermissionsPage()
                "screen" -> ScreenPage(vm)
                "bg" -> BackgroundPage(vm)
                "memory" -> MemoryPage(vm)
                "dev" -> DevPage(vm)
                "privacy" -> PrivacyPage(vm)
                "lang" -> LanguagePage(vm)
                "web" -> WebPage(vm)
                "automation" -> AutomationPage(vm)
                "jarvis" -> JarvisPage(vm)
                "photos" -> PhotosPage(vm) { page = "gallery" }
                "gallery" -> GalleryScreen(vm)
                "filemgr" -> FileManagerPage(vm)
                "files" -> FilesPage(vm)
                "advctl" -> AdvancedControlPage(vm) { page = "shizuku" }
                "shizuku" -> ShizukuPage(vm)
                "future" -> FuturePage()
                else -> AboutPage()
            }
        }
    }
}

@Composable
internal fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) =
    GlassListItem(title, sub, trailing = { GlassSwitch(checked, onChange) })

@Composable
internal fun GeminiPage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var key by remember { mutableStateOf(p.apiKey) }
    var show by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(p.model) }
    var temp by remember { mutableFloatStateOf(p.temperature) }
    var aiOn by remember { mutableStateOf(p.aiEnabled) }
    var sys by remember { mutableStateOf(p.systemPromptExtra) }
    var turns by remember { mutableFloatStateOf(p.contextTurns.toFloat()) }
    var maxTok by remember { mutableFloatStateOf(p.maxTokens.toFloat()) }
    var result by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var provider by remember { mutableStateOf(p.aiProvider) }
    var gemOn by remember { mutableStateOf(p.geminiEnabled) }
    var openOn by remember { mutableStateOf(p.openAiEnabled) }
    var openKey by remember { mutableStateOf(p.openAiKey) }
    var showOpen by remember { mutableStateOf(false) }
    var openModel by remember { mutableStateOf(p.openAiModel) }
    var confirmClearOpen by remember { mutableStateOf(false) }
    val activeKeyMissing = if (provider == "openai") openKey.isBlank() else key.isBlank()
    val activeOn = if (provider == "openai") openOn else gemOn
    val state = if (!aiOn) "Disabled" else if (!activeOn) "Provider switched off" else if (activeKeyMissing) "No API key" else if (!vm.online) "Offline" else "Ready"
    GlassSettingSection("AI provider") {
        GText("Nova talks to one cloud AI at a time. Switching applies immediately.", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Gemini", provider == "gemini", { provider = "gemini"; p.aiProvider = "gemini"; result = "" })
            GlassChip("OpenAI", provider == "openai", { provider = "openai"; p.aiProvider = "openai"; result = "" })
        }
        ToggleRow("Enable Gemini", "Turn this provider off without deleting its key", gemOn) { gemOn = it; p.geminiEnabled = it }
        ToggleRow("Enable OpenAI", "Turn this provider off without deleting its key", openOn) { openOn = it; p.openAiEnabled = it }
        GlassListItem("Active provider", if (provider == "openai") "OpenAI · $openModel" else "Gemini · $model")
        GText("Speech-to-text, web search and screen/camera vision still use Gemini for now, so keep a Gemini key if you use those. Chat, voice, follow-ups and summaries all use the one model chosen under Gemini → Model.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("OpenAI") {
        GText("API key (stored encrypted on this device)", size = 12.sp, color = g.subtext)
        GlassTextField(openKey, { openKey = it; p.openAiKey = it.trim() }, Modifier.fillMaxWidth(), placeholder = "Paste OpenAI API key",
            visual = if (showOpen) VisualTransformation.None else PasswordVisualTransformation(),
            trailing = { SmallAction(if (showOpen) "Hide" else "Show", if (showOpen) "Hide API key" else "Show API key") { showOpen = !showOpen } })
        GText("Model", size = 12.sp, color = g.subtext)
        GlassTextField(openModel, { openModel = it; p.openAiModel = it }, Modifier.fillMaxWidth(), placeholder = "gpt-4o-mini")
        GlassButton("Clear OpenAI key", { confirmClearOpen = true })
    }
    GlassSettingSection("Gemini") {
        GText("API key (stored encrypted on this device)", size = 12.sp, color = g.subtext)
        GlassTextField(key, { key = it; p.apiKey = it.trim() }, Modifier.fillMaxWidth(), placeholder = "Paste Gemini API key",
            visual = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailing = { SmallAction(if (show) "Hide" else "Show", if (show) "Hide API key" else "Show API key") { show = !show } })
        GText("Model", size = 12.sp, color = g.subtext)
        GeminiModelSelector(p) { model = p.model }
        GlassListItem("Offline fallback", "OfflineProvider answers local commands when there is no internet")
        GlassSlider("Temperature", "%.1f".format(temp), temp, { temp = it; p.temperature = it }, 0f..2f)
        GlassSlider("Max output tokens", "${maxTok.toInt()}", maxTok, { maxTok = it; p.maxTokens = it.toInt() }, 128f..4096f)
        GText("System prompt (added to Nova's own instructions)", size = 12.sp, color = g.subtext)
        GlassTextField(sys, { sys = it; p.systemPromptExtra = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 3, placeholder = "Optional extra instructions")
        GlassSlider("Conversation context", "${turns.toInt()} messages", turns, { turns = it; p.contextTurns = it.toInt() }, 4f..30f)
        ToggleRow("Enable AI", "Local commands work even when off", aiOn) { aiOn = it; p.aiEnabled = it }
        GlassListItem("AI status", state)
        GlassButton("Test connection (active provider)", { result = "Testing…"; vm.testConnection { result = it } }, primary = true)
        if (result.isNotBlank()) GText(result, size = 13.sp, color = g.accent)
        GlassButton("Clear Gemini key", { confirmClear = true })
    }
    if (confirmClearOpen) GlassDialog({ confirmClearOpen = false }, "Clear the OpenAI key?", "Clear", { openKey = ""; p.openAiKey = ""; confirmClearOpen = false }) {
        GText("The key is removed from this phone. OpenAI stops working until you add one again.")
    }
    if (confirmClear) GlassDialog({ confirmClear = false }, "Clear the API key?", "Clear", { key = ""; p.apiKey = ""; confirmClear = false }) {
        GText("The key is removed from this phone. Gemini stops working until you add one again; local commands still work.")
    }
}

@Composable
internal fun PersonaPage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var editor by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(p.customPersonality) }
    var mood by remember { mutableStateOf(p.moodOverride) }
    if (vm.personality == Personality.GFMode || vm.personality == Personality.Companion) {
        var cs by remember { mutableStateOf(p.companionStyle) }
        GlassSettingSection("Companion style") {
            GText("How warm or playful the caring-friend style should be. Always non-explicit.", size = 12.sp, color = g.subtext)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("caring", "playful", "teasing", "funny", "mock-annoyed", "nakhra", "supportive").forEach { k -> GlassChip(k.replaceFirstChar { it.uppercase() }, cs == k, { cs = k; p.companionStyle = k }) }
            }
        }
    }
    GlassSettingSection("Mood") {
        GText("Nova reads your tone from your messages. This only changes how she talks, never a diagnosis. Override it here.", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Auto", "Calm", "Happy", "Funny", "Serious", "Professional", "Playful").forEach { m ->
                GlassChip(m, mood == m, { mood = m; p.moodOverride = m })
            }
        }
        GlassListItem("Detected now", "${vm.mood.name} → ${vm.emotion.label}")
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Personality.values().toList().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { m ->
                    val sel = vm.personality == m
                    GlassCard(
                        Modifier.weight(1f).pressable({ vm.updatePersonality(m); if (m == Personality.Custom) editor = true }, role = androidx.compose.ui.semantics.Role.RadioButton)
                            .semantics { contentDescription = m.label + if (sel) ", selected" else "" },
                        shape = RoundedCornerShape(20.dp), glow = sel, tint = if (sel) g.accent.a(0.22f) else Color.Transparent,
                        borderBrush = if (sel) androidx.compose.ui.graphics.Brush.linearGradient(listOf(g.accent, g.accent2, g.accent)) else null
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            GText(m.label, weight = FontWeight.SemiBold)
                            GText(if (m == Personality.Custom) "Write your own" else m.prompt, size = 11.sp, color = g.subtext, maxLines = 2)
                        }
                    }
                }
                if (row.size == 1) Box(Modifier.weight(1f))
            }
        }
    }
    if (editor) GlassSheet({ editor = false }, "Custom personality") {
        GlassTextField(custom, { custom = it; p.customPersonality = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 8,
            placeholder = "e.g. Talk like a calm futuristic assistant.")
    }
}

@Composable
internal fun VoicePage(vm: NovaViewModel) {
    val p = vm.prefs
    var lang by remember { mutableStateOf(p.language) }
    var speed by remember { mutableFloatStateOf(p.speed) }
    var pitch by remember { mutableFloatStateOf(p.pitch) }
    var vol by remember { mutableFloatStateOf(p.ttsVolume) }
    var speak by remember { mutableStateOf(p.speakReplies) }
    var voiceSheet by remember { mutableStateOf(false) }
    val (listening, setListening) = rememberListenToggle()
    GlassSettingSection("Voice") {
        GlassListItem("Voice", if (p.ttsVoice.isBlank()) "System default" else p.ttsVoice, onClick = { voiceSheet = true }, trailing = { GText("›", size = 22.sp) })
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "Auto", "hinglish" to "Hinglish", "hindi" to "Hindi", "english" to "English").forEach { (k, label) ->
                GlassChip(label, lang == k, { lang = k; p.language = k })
            }
        }
        GlassSlider("Speech speed", "%.1f".format(speed), speed, { speed = it; p.speed = it }, 0.5f..2f)
        GlassSlider("Pitch", "%.1f".format(pitch), pitch, { pitch = it; p.pitch = it }, 0.5f..2f)
        GlassSlider("Volume", "${(vol * 100).toInt()}%", vol, { vol = it; p.ttsVolume = it }, 0f..1f)
        ToggleRow("Auto speak", "Read replies aloud", speak) { speak = it; p.speakReplies = it }
        ToggleRow("Wake & background listening", if (listening) "Microphone ON (see notification)" else "Microphone OFF", listening, setListening)
        GlassButton("Test voice", { vm.voice.speak("Hi, I'm Nova. This is how I sound.", vm.emotion) })
        GText("Mood changes speaking speed and pitch only. Other voice qualities depend on the TTS voice you pick.", size = 11.sp, color = LocalGlass.current.subtext)
    }
    if (voiceSheet) GlassSheet({ voiceSheet = false }, "Choose voice") {
        val list = remember { vm.voice.voices() }
        GlassListItem("System default", onClick = { p.ttsVoice = ""; voiceSheet = false })
        list.forEach { (name, label) -> GlassListItem(name, label, onClick = { p.ttsVoice = name; voiceSheet = false }) }
        if (list.isEmpty()) GText("No Hindi/English voices reported yet. Install voices in Android text-to-speech settings.", size = 12.sp)
    }
}

@Composable
private fun AppearancePage(vm: NovaViewModel) {
    val g = LocalGlass.current
    var customDialog by remember { mutableStateOf(false) }
    var hex by remember { mutableStateOf("#") }
    val accents = listOf("Blue" to 0xFF4D8DFF, "Purple" to 0xFF9B7BFF, "Cyan" to 0xFF22D3EE, "Pink" to 0xFFFF6FB5, "Green" to 0xFF3DDC97)
    GlassSettingSection("Theme") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("dark" to "Dark Glass", "light" to "Light Glass", "auto" to "Auto").forEach { (k, l) -> GlassChip(l, vm.themeMode == k, { vm.setTheme(k) }) }
        }
    }
    GlassSettingSection("Accent color") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            accents.forEach { (name, c) ->
                val col = Color(c)
                Box(Modifier.size(48.dp).pressable({ vm.updateAccent(col) }, role = androidx.compose.ui.semantics.Role.RadioButton)
                    .semantics { contentDescription = "$name accent" }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(col)
                        .border(if (vm.accent == col) 3.dp else 1.dp, if (vm.accent == col) g.text else Color.White.a(0.4f), CircleShape))
                }
            }
            GlassChip("Custom", false, { customDialog = true })
        }
    }
    GlassSettingSection("Nova visual") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Avatar", vm.avatarStyle == "avatar", { vm.updateAvatarStyle("avatar") })
            GlassChip("Orb", vm.avatarStyle == "orb", { vm.updateAvatarStyle("orb") })
        }
        GText("The avatar is an original stylized illustration. It reacts to Nova's emotion and state.", size = 11.sp, color = g.subtext)
    }
    if (customDialog) GlassDialog({ customDialog = false }, "Custom accent", "Apply", {
        try { vm.updateAccent(Color(android.graphics.Color.parseColor(hex.trim()))) } catch (e: Exception) { }
    }) {
        GText("Enter a hex color like #FF8A00", size = 13.sp, color = g.subtext)
        GlassTextField(hex, { hex = it }, Modifier.fillMaxWidth(), placeholder = "#RRGGBB")
    }
}

@Composable
private fun GlassPage(vm: NovaViewModel) {
    val g = LocalGlass.current
    GlassSettingSection("Material") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Frosted", "Clear", "Metallic", "Soft glow").forEachIndexed { i, l -> GlassChip(l, vm.material == i, { vm.updateMaterial(i) }) }
        }
    }
    GlassSettingSection("Glass") {
        GText("Blur", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Low", "Medium", "High").forEachIndexed { i, l -> GlassChip(l, vm.blurLevel == i, { vm.setBlur(i) }) } }
        GText("Transparency", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Low", "Medium", "High").forEachIndexed { i, l -> GlassChip(l, vm.transparency == i, { vm.updateTransparency(i) }) } }
        GText("Animation", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Full", !vm.reduced, { vm.updateReduced(false) }); GlassChip("Reduced", vm.reduced, { vm.updateReduced(true) })
        }
        GText("Blur uses RenderEffect on Android 12+ and a soft-gradient fallback on older versions. Animations pause automatically when the app is in the background.", size = 11.sp, color = g.subtext)
    }
    GlassSettingSection("Live preview") {
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), glow = true, tint = g.accent.a(0.10f)) {
            GText("Hello, I'm Nova. This is how replies look.", Modifier.padding(14.dp))
        }
        var demo by remember { mutableStateOf(true) }
        ToggleRow("Sample switch", null, demo) { demo = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { GlassButton("Primary", {}, primary = true); GlassButton("Secondary", {}) }
    }
}

@Composable
internal fun NotificationsPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val lis = tick >= 0 && NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val apps = remember { vm.device.listApps() }
    var allowed by remember { mutableStateOf(vm.prefs.notifAllowed) }
    var q by remember { mutableStateOf("") }
    GlassSettingSection("Notification assistant") {
        GlassListItem("Notification access", if (lis) "Enabled" else "Disabled")
        GlassButton("Open Notification access", { openSystem(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, primary = !lis)
        GText("Only apps you include below are read. Notifications stay in memory and are never uploaded unless you ask Nova to summarize them with Gemini. Say \"read notifications\" or \"summarize notifications\".", size = 12.sp, color = LocalGlass.current.subtext)
    }
    GlassSettingSection("Included apps") {
        GlassTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = "Search apps")
        apps.filter { q.isBlank() || it.first.contains(q, true) }.forEach { (label, pkg) ->
            GlassListItem(label, trailing = {
                GlassSwitch(pkg in allowed) { on -> allowed = if (on) allowed + pkg else allowed - pkg; vm.prefs.notifAllowed = allowed }
            })
        }
    }
}

@Composable
internal fun ScanPage(vm: NovaViewModel) {
    val g = LocalGlass.current
    var confirm by remember { mutableStateOf(false) }
    GlassSettingSection("Device Intelligence") {
        GText("Scans only what Android exposes to a normal app: hardware, display, battery, storage totals, memory, network state, sensors, cameras, audio, visible apps and permission status. No files, messages, passwords or other apps' private data. The report stays on this phone; only a short summary is shared with Gemini when you ask a question about your device.", size = 12.sp, color = g.subtext)
        GlassListItem("Last scan", vm.profile?.let { java.text.SimpleDateFormat("d MMM yyyy, h:mm a", java.util.Locale.getDefault()).format(java.util.Date(it.time)) } ?: "None")
        GlassButton("Open Device Intelligence", { vm.navigateTo = 5 }, Modifier.fillMaxWidth(), primary = true)
        GlassButton("Scan my phone now", { vm.startScan() }, Modifier.fillMaxWidth())
        if (vm.profile != null) GlassButton("Delete scan data", { confirm = true }, Modifier.fillMaxWidth())
    }
    if (confirm) GlassDialog({ confirm = false }, "Delete scan data?", "Delete", { vm.deleteScan() }) { GText("The stored device report will be removed.") }
}

@Composable
fun PermissionsPage() {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var explain by remember { mutableStateOf<PermItem?>(null) }
    var bump by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        com.nova.ai.permissions.PermissionMemory.afterResult(ctx, com.nova.ai.permissions.PermissionMemory.findActivity(ctx), res.keys.toList()); bump++
    }
    GText("Nothing is requested until you tap Grant. Denying never crashes Nova. For the full picture (Accessibility, Shizuku, files, internet) open Permission Dashboard.", size = 12.sp, color = LocalGlass.current.subtext)
    NovaPermissions.all().forEach { p ->
        val ok = tick >= 0 && bump >= 0 && p.granted(ctx)
        val blocked = !ok && com.nova.ai.permissions.PermissionMemory.isBlocked(ctx, p.perms)
        GlassPermissionCard(p.name, ok, p.required, if (blocked) p.why + "  Android won't ask again: allow it in app settings." else p.why) {
            if (!ok && !blocked) GlassButton("Grant", { explain = p }, primary = true)
            GlassButton("Open Settings", { openAppSettings(ctx) }, primary = blocked)
        }
    }
    val a11y = tick >= 0 && com.nova.ai.accessibility.NovaAccessibilityService.instance != null
    val lis = tick >= 0 && NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    GlassPermissionCard("Accessibility", a11y, false, if (a11y) "Screen assistant is connected: read visible text, tap, scroll, Back, Home, only on your request." else "Screen assistant is not connected. If Accessibility already shows ON for Nova AI, switch it off and on once.") {
        GlassButton("Open Settings", { openSystem(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }, primary = !a11y)
    }
    GlassPermissionCard("Notification Access", lis, false, "Lets Nova summarize notifications. Kept in memory only.") {
        GlassButton("Open Settings", { openSystem(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, primary = !lis)
    }
    explain?.let { p ->
        GlassDialog({ explain = null }, "Allow ${p.name}?", "Continue", {
            // Only what is still missing is requested; already granted permissions are never asked for again.
            val missing = p.perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
            com.nova.ai.permissions.PermissionMemory.markAsked(ctx, missing)
            if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
        }) {
            GText(p.why)
            GText("Android will ask you next. You can change this anytime in Settings.", size = 12.sp, color = LocalGlass.current.subtext)
        }
    }
}

@Composable
internal fun ScreenPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val g = LocalGlass.current
    val p = vm.prefs
    val on = tick >= 0 && NovaAccessibilityService.instance != null
    var actions by remember { mutableStateOf(p.screenActionsOn) }
    var vis by remember { mutableStateOf(p.visionOn) }
    var test by remember { mutableStateOf("") }
    LaunchedEffect(tick) { vm.refreshVision() }
    GlassSettingSection("Screen Assistant Engine") {
        GlassListItem("Accessibility service", remember(tick, actions) { com.nova.ai.accessibility.AccessibilitySettings.status(ctx, p).explain() })
        ToggleRow("Allow screen actions", "Tap, long-press, double-tap, swipe, scroll, type, Back, Home, Recents. Off = NOVA can only read.", actions) { actions = it; p.screenActionsOn = it }
        GlassButton("Open Accessibility settings", { openSystem(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }, primary = !on)
        GlassButton("Test: read my screen", { test = NovaAccessibilityService.instance?.snapshot()?.outline(700) ?: "Accessibility is off, or the screen can't be read." }, enabled = on)
        if (test.isNotBlank()) GText(test, size = 12.sp, color = g.accent)
        GText("If Android shows “Restricted setting”: App info → ⋮ menu → Allow restricted settings, then try again.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("What NOVA can do") {
        GlassListItem("Read & understand", "Visible text, buttons, labels, fields, scrollable lists, which app is open. Passwords are never read.")
        GlassListItem("Screen search", "\"Screen par Settings dhoondo\", \"Search button dhoondo\". If several match, NOVA asks which one.")
        GlassListItem("Actions", "tap · double tap · long press · swipe · scroll · type · select · Back · Home · Recents")
        GlassListItem("Multi-step", "\"YouTube kholo aur search mein Arijit Singh likho\" → open, find search, type, press Search, open a result.")
        GlassListItem("Safety", "Asks before pay / delete / install / send style actions. Refuses payment, banking and password apps. Never types into password fields.")
        GlassListItem("Limits", "Apps that hide their UI from accessibility (some games, secure screens) can't be read; Android may block gestures there. NOVA says so instead of pretending.")
    }
    GlassSettingSection("Screen Vision (optional screenshot understanding)") {
        GlassListItem("Status", if (vm.visionActive) "ON — notification is showing" else "Off")
        ToggleRow("Allow sending a screenshot to Gemini", "Only when you ask a visual question while Screen Vision is on.", vis) { vis = it; p.visionOn = it }
        if (vm.visionActive) GlassButton("Stop Screen Vision", { vm.stopVision() }, primary = true)
        else GlassButton("Start Screen Vision", { vm.requestVision() }, primary = true)
        GText("Uses Android's own screen-capture approval. NOVA keeps only the newest frame in memory, never saves it, and prefers the accessibility tree whenever it has the answer. Android 14+ asks for approval each time you start it.", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun BackgroundPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val (listening, setListening) = rememberListenToggle()
    val paused by VoiceState.paused.collectAsState()
    val status by VoiceState.status.collectAsState()
    val detail by VoiceState.detail.collectAsState()
    val problem by VoiceState.problem.collectAsState()
    val heard by VoiceState.heard.collectAsState()
    val tick = rememberResumeTick()
    var nameOnly by remember { mutableStateOf(vm.prefs.wakeEnabled) }
    val micOn = listening && status == VoiceStatus.Listening
    val interrupted = remember(tick, listening) { vm.prefs.bgEnabled && !listening }
    GlassCard(Modifier.fillMaxWidth(), glow = micOn, tint = if (micOn) Color(0xFF69F0AE).a(0.12f) else Color.Transparent) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GText(if (micOn) "● MICROPHONE IS ON" else if (listening) "◐ Microphone is off for now" else "○ Microphone is off", size = 18.sp, weight = FontWeight.Bold,
                color = if (micOn) Color(0xFF69F0AE) else g.text)
            ToggleRow("Background Voice", "Nova listens continuously, also with the screen off. A notification stays visible the whole time.", listening) { setListening(it) }
            ToggleRow("Only answer when I say \"Nova\"", "On: a sentence needs the word Nova to be treated as a command. Off: Nova answers everything it hears.", nameOnly) {
                nameOnly = it; vm.prefs.wakeEnabled = it
            }
            if (listening) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (paused) GlassButton("Resume", { resumeMic(ctx) }, primary = true) else GlassButton("Pause", { pauseMic(ctx) })
                GlassButton("Stop", { stopMic(ctx) })
            }
            if (interrupted) GText("Background Voice was on, but Android stopped it (for example the phone restarted or the app was killed). Turn it on again above.", size = 12.sp, color = g.accent)
            GlassListItem("Foreground service", if (listening) (if (paused) "Running, microphone off" else "Running") else "Stopped")
            GlassListItem("Persistent notification", if (listening) "Showing: Nova AI, Background Voice is ${if (paused) "paused" else "active"} (Pause / Resume / Stop)" else "Not shown")
            if (detail.isNotBlank()) GlassListItem("Microphone", detail)
            if (problem.isNotBlank()) GText("⚠ $problem", size = 12.sp, color = g.accent)
            if (listening && heard.isNotBlank()) GlassListItem("Last heard", heard)
            GText("Nova captures audio with AudioRecord and sends short clips to Gemini for speech-to-text, so it needs internet and a Gemini key, and it can use your Gemini quota quickly. Android also shows its own microphone indicator, which Nova never hides. Force-stopping Nova stops the microphone.", size = 12.sp, color = g.subtext)
        }
    }
}

@Composable
internal fun MemoryPage(vm: NovaViewModel) {
    val m = vm.memory
    val p = vm.prefs
    val g = LocalGlass.current
    val rev = m.rev
    var on by remember { mutableStateOf(p.memoryEnabled) }
    var tab by remember { mutableStateOf("saved") }
    var edit by remember { mutableStateOf<MemoryEntry?>(null) }
    var editText by remember { mutableStateOf("") }
    var why by remember { mutableStateOf<MemoryEntry?>(null) }
    var confirmAll by remember { mutableStateOf(false) }
    var days by remember { mutableStateOf(p.memoryExpiryDays) }
    val saved = remember(rev) { m.saved() }
    val recent = remember(rev) { m.recent() }
    val temp = remember(rev) { m.temporary() }
    val ignored = remember(rev) { m.ignored() }
    val df = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    GlassSettingSection("Memory Dashboard") {
        GlassButton("Open Memory Dashboard", { vm.navigateTo = 25 }, Modifier.fillMaxWidth(), primary = true)
        GText("The new permanent memory: topics, projects, files, reminders, Secure Vault and backups. The switch below turns all memory on or off.", size = 11.sp, color = g.subtext)
    }
    GlassSettingSection("Memory") {
        ToggleRow("Enable memory", "Nova decides what is worth keeping. Everything stays on this phone.", on) { on = it; p.memoryEnabled = it }
        GlassListItem("Stored", "${m.count()} memories")
        GText("Forget unused, unconfirmed memories after", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Never", 30 to "30 days", 90 to "90 days", 180 to "180 days", 365 to "1 year").forEach { (d, l) ->
                GlassChip(l, days == d, { days = d; p.memoryExpiryDays = d })
            }
        }
        GText("Memories you asked for, pinned memories and confirmed permanent facts are never deleted automatically. Temporary context expires by itself.", size = 11.sp, color = g.subtext)
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassChip("Saved (${saved.size})", tab == "saved", { tab = "saved" })
        GlassChip("Recently used", tab == "recent", { tab = "recent" })
        GlassChip("Temporary (${temp.size})", tab == "temp", { tab = "temp" })
        GlassChip("Ignored", tab == "ignored", { tab = "ignored" })
    }
    if (tab == "ignored") {
        if (ignored.isEmpty()) GText("Nothing ignored yet. Private-looking text is never saved and shows up here without its content.", size = 12.sp, color = g.subtext)
        ignored.forEach { i ->
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    GText(i.label, weight = FontWeight.SemiBold)
                    GText(i.reason, size = 12.sp, color = g.subtext)
                    GText(df.format(Date(i.at)), size = 11.sp, color = g.subtext)
                }
            }
        }
    } else {
        val list = when (tab) { "saved" -> saved; "recent" -> recent; else -> temp }
        if (list.isEmpty()) GText("Nothing here yet.", size = 12.sp, color = g.subtext)
        list.forEach { e ->
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), glow = e.pinned) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row {
                        GText(e.category.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }, Modifier.weight(1f), size = 11.sp, color = g.accent)
                        GText((if (e.pinned) "📌 " else "") + e.confidence.name.lowercase() + " confidence", size = 11.sp, color = g.subtext)
                    }
                    GText(e.content)
                    GText("Saved ${df.format(Date(e.createdAt))}" + (if (e.expiresAt > 0) " • expires ${df.format(Date(e.expiresAt))}" else ""), size = 11.sp, color = g.subtext)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        SmallAction("Edit", "Edit memory") { edit = e; editText = e.content }
                        SmallAction("Why?", "Why did Nova remember this") { why = e }
                        SmallAction(if (e.pinned) "Unpin" else "Pin", "Pin memory") { m.pin(e.id, !e.pinned) }
                        SmallAction("Forget", "Forget and never save again") { m.forget(e.id) }
                        SmallAction("Delete", "Delete memory") { m.delete(e.id) }
                    }
                }
            }
        }
    }
    GlassButton("Delete all memories", { confirmAll = true }, Modifier.fillMaxWidth())
    GText("Forget = delete and never auto-save it again. Delete = remove only.", size = 11.sp, color = g.subtext)
    edit?.let { e ->
        GlassSheet({ if (editText.isNotBlank() && editText != e.content) m.update(e.id, editText); edit = null }, "Edit memory") {
            GlassTextField(editText, { editText = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
            GText("Passwords, PINs and card numbers can't be saved.", size = 12.sp, color = g.subtext)
        }
    }
    why?.let { e -> GlassDialog({ why = null }, "Why did NOVA remember this?") { GText(m.why(e)) } }
    if (confirmAll) GlassDialog({ confirmAll = false }, "Delete all memories?", "Delete", { m.clear() }) { GText("Saved, temporary and ignored items are all removed. This cannot be undone.") }
}

@Composable
internal fun DevPage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var dm by remember { mutableStateOf(p.devMode) }
    var fmt by remember { mutableStateOf(p.codeFormatting) }
    var ex by remember { mutableStateOf(p.autoExplain) }
    var dbg by remember { mutableStateOf(p.debugMode) }
    var model by remember { mutableStateOf(p.devModel) }
    var sa by remember { mutableStateOf(p.structuredActions) }
    GlassSettingSection("Developer") {
        ToggleRow("Developer mode", "Use the coding prompt for every chat reply", dm) { dm = it; p.devMode = it }
        GlassListItem("Code assistant", "Open the Developer tab: generate, explain, debug, convert code. Nova shows code; it never runs it")
        GlassListItem("Diagnostics, patch review, updates", "More > Developer Tools")
        ToggleRow("Structured actions (beta)", "The AI may propose a device action; Nova validates it and still asks you to confirm where needed", sa) { sa = it; p.structuredActions = it }
        GText("Developer model (blank = same as AI model)", size = 12.sp, color = g.subtext)
        ModelPicker(model, com.nova.ai.ai.ModelCatalog.chat, { model = if (it.isBlank()) "" else com.nova.ai.ai.ModelCatalog.clean(it, ""); p.devModel = model }, blankLabel = "Same as AI model")
        ToggleRow("Code formatting", "Ask for clean, consistent formatting", fmt) { fmt = it; p.codeFormatting = it }
        ToggleRow("Auto explain", "Add a short explanation after code", ex) { ex = it; p.autoExplain = it }
        ToggleRow("Debug mode", "Show model and response time in the Developer tab", dbg) { dbg = it; p.debugMode = it }
    }
}

@Composable
internal fun PrivacyPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val p = vm.prefs
    var confirm by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(p.confirmLevel) }
    var pro by remember { mutableStateOf(p.proactive) }
    var chats by remember { mutableStateOf(p.saveChats) }
    var compress by remember { mutableStateOf(p.smartCompression) }
    val mic = rememberListenToggle().first
    val a11y = tick >= 0 && NovaAccessibilityService.instance != null
    val lis = tick >= 0 && NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    GlassSettingSection("Confirmations") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("always" to "Always confirm", "sensitive" to "Sensitive only", "minimal" to "Minimal").forEach { (k, l) ->
                GlassChip(l, level == k, { level = k; p.confirmLevel = k })
            }
        }
        ToggleRow("Proactive suggestions", "Occasional tips such as low battery. Never acts on its own.", pro) { pro = it; p.proactive = it }
        ToggleRow("Save chat history", "Restores your last conversation after the app closes. Stored only on this phone.", chats) { chats = it; p.saveChats = it }
        ToggleRow("Smart context compression", "Long chats are summarized (Gemini when online, local rules offline). Passwords are redacted first.", compress) { compress = it; p.smartCompression = it }
        GlassButton("Delete chat history", { vm.deleteChatHistory() })
    }
    var localOnly by remember { mutableStateOf(p.localOnly) }
    var vision by remember { mutableStateOf(p.visionOn) }
    var web by remember { mutableStateOf(p.webSearchOn) }
    var pplAi by remember { mutableStateOf(p.peopleAi) }
    GlassSettingSection("Gemini data sharing") {
        ToggleRow("Local-only mode", "Nothing leaves the phone: no Gemini, no web search, no screenshots. Local commands and offline replies still work.", localOnly) { localOnly = it; p.localOnly = it }
        ToggleRow("Web search", "Sends your search words to Gemini/Google Search when you ask to search the web.", web) { web = it; p.webSearchOn = it }
        ToggleRow("Screenshots to Gemini", "Only after you start Screen Vision and ask a visual question.", vision) { vision = it; p.visionOn = it }
        ToggleRow("People hints in AI answers", "At most one short line per person you name.", pplAi) { pplAi = it; p.peopleAi = it }
        GlassListItem("Sent to Gemini", "Your message, a short conversation history, only memories relevant to it, and context you explicitly asked to share (screen text, notifications). Never your full memory, people list, device profile or contacts.")
    }
    GlassSettingSection("Privacy dashboard") {
        GlassListItem("Microphone", if (mic) "ON right now" else "Off")
        GlassListItem("Screen access", if (a11y) "Accessibility enabled" else "Off")
        GlassListItem("Notification access", if (lis) "Enabled" else "Off")
        GlassListItem("API key security", if (p.apiKey.isBlank() && p.openAiKey.isBlank()) "No key saved" else "Stored encrypted on this device; each key is sent only to its own provider (Google Gemini or OpenAI)")
        GlassListItem("Data controls", "Chats, memories and settings stay on this device. Nothing is uploaded automatically.")
    }
    GlassButton("Clear local data", { confirm = true })
    if (confirm) GlassDialog({ confirm = false }, "Clear all local data?", "Clear", { vm.clearAllData() }) {
        GText("Deletes your API key, memories, chats and settings from this device.")
    }
}

@Composable
internal fun AboutPage() {
    val ctx = LocalContext.current
    var sheet by remember { mutableStateOf("") }
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0" } catch (e: Exception) { "1.0" } }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Image(
            painterResource(R.drawable.nova_logo_ring), "Nova. Your Voice. My World.",
            Modifier.fillMaxWidth(0.64f).widthIn(max = 280.dp).aspectRatio(1f), contentScale = ContentScale.Fit     // square artwork, never stretched
        )
    }
    GlassSettingSection("NOVA AI") {
        GlassListItem("Version", version)
        GlassListItem("Gemini-powered AI", "Your Voice. My World.")
        GlassListItem("Open source licenses", onClick = { sheet = "lic" }, trailing = { GText("›", size = 22.sp) })
        GlassListItem("Privacy policy", onClick = { sheet = "priv" }, trailing = { GText("›", size = 22.sp) })
        GlassListItem("Terms", onClick = { sheet = "terms" }, trailing = { GText("›", size = 22.sp) })
        GlassListItem("Check for updates", onClick = { sheet = "upd" }, trailing = { GText("›", size = 22.sp) })
    }
    when (sheet) {
        "lic" -> GlassSheet({ sheet = "" }, "Open source licenses") { GText("AndroidX, Jetpack Compose and Kotlin are licensed under the Apache License 2.0.") }
        "priv" -> GlassSheet({ sheet = "" }, "Privacy policy (summary)") {
            GText("Nova stores settings, chats and memories only on this device. Your API key is encrypted locally. Text you send to Nova's AI is sent to Google's Gemini API using your key. Microphone, screen and notification access only work after you enable them.")
        }
        "terms" -> GlassSheet({ sheet = "" }, "Terms") { GText("This is a personal build provided as is, without warranty.") }
        "upd" -> GlassSheet({ sheet = "" }, "Updates") { GText("No update server is configured. Install new builds manually.") }
    }
}

@Composable
internal fun ReliabilityPage(vm: NovaViewModel) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val tick = rememberResumeTick()
    val running by VoiceState.running.collectAsState()
    val paused by VoiceState.paused.collectAsState()
    val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
    val ignoring = remember(tick) { pm.isIgnoringBatteryOptimizations(ctx.packageName) }
    val notif = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val mic = remember(tick) { ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
    val boot = remember(tick) { vm.prefs.lastBootInit }
    val bootOn = remember(tick) { ctx.packageManager.getComponentEnabledSetting(ComponentName(ctx, BootReceiver::class.java)) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED }
    var note by remember { mutableStateOf("") }
    GlassSettingSection("Status") {
        GlassListItem("Background service", if (running) (if (paused) "Paused, microphone off" else "Running, microphone on") else "Stopped")
        GlassListItem("Battery optimization", if (ignoring) "Unrestricted" else "Optimized: Android may stop Nova in the background")
        GlassListItem("Auto-start", "Unknown. Android doesn't tell apps; check your ${Build.MANUFACTURER} auto-start page")
        GlassListItem("Notifications", if (notif) "Allowed" else "Blocked: reminders and the boot message can't show")
        GlassListItem("Microphone permission", if (mic) "Granted" else "Not granted")
        GlassListItem("Boot", (if (bootOn) "Boot receiver active. " else "Boot receiver disabled. ") + if (boot > 0) "Last initialized " + SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(boot)) else "Not initialized since install")
    }
    GlassSettingSection("Make background use reliable") {
        GlassButton("Battery optimization settings", { openSystem(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }, Modifier.fillMaxWidth(), primary = !ignoring)
        GlassButton("Auto-start settings", { note = if (openAutoStart(ctx)) "" else "I don't know this phone's auto-start page, so I opened app settings. Look for Auto-start, Background activity or Battery."; if (note.isNotBlank()) openAppSettings(ctx) }, Modifier.fillMaxWidth())
        GlassButton("App settings", { openAppSettings(ctx) }, Modifier.fillMaxWidth())
        if (note.isNotBlank()) GText(note, size = 12.sp, color = g.accent)
    }
    GlassSettingSection("What Android allows") {
        GText("A phone that is powered off can't run NOVA. After Android boots, NOVA initializes itself (restores memory, settings, personality and device profile, then posts \"NOVA initialized\"). Listening does not restart on its own: Android blocks microphone services from starting at boot, so tap Resume listening in that notification.", size = 12.sp, color = g.subtext)
        GText("Swiping NOVA away from Recents stops the app. Only features you turned on (the background assistant, reminders, routines) keep working through Android services. Some phone makers kill background apps anyway; the buttons above are the supported fix.", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun SecurityPage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var vlOn by remember { mutableStateOf(p.voiceLockOn) }
    var owner by remember { mutableStateOf(p.ownerMode) }
    var mode by remember { mutableStateOf(p.protectMode) }
    var enrolled by remember { mutableStateOf(vm.voiceLock.hasProfile()) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun guarded(prompt: String, action: () -> Unit) {
        if (p.ownerMode && p.protectMode != "confirm") vm.auth = AuthRequest(prompt) { action(); "" }
        else if (p.ownerMode) vm.pending = Pending(prompt) { action(); "" }
        else action()
    }
    SecurityModeSection(vm)
    GlassSettingSection("Voice Lock (experimental)") {
        GText("Compares a short recording with your enrolled sample. It is a convenience layer only: recordings or similar voices can fool it, and it is not biometric security. Sensitive actions should use fingerprint or screen lock.", size = 12.sp, color = g.subtext)
        ToggleRow("Voice Lock", if (enrolled) "Profile saved on this phone" else "Enroll your voice first", vlOn) {
            if (it && !enrolled) msg = "Enroll your voice first." else { vlOn = it; p.voiceLockOn = it }
        }
        GlassButton(if (enrolled) "Re-enroll voice" else "Enroll voice", {
            busy = true; msg = "Starting…"
            vm.enrollVoice({ msg = it }, { ok ->
                busy = false; enrolled = vm.voiceLock.hasProfile()
                msg = if (ok) "Voice profile saved on this phone." else "Couldn't enroll. Check the microphone permission and speak clearly."
            })
        }, Modifier.fillMaxWidth(), primary = true, enabled = !busy)
        if (enrolled) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Test", { msg = "Listening for 3 seconds…"; vm.verifyVoice { _, m -> msg = m } }, enabled = !busy)
            GlassButton("Delete voice profile", { guarded("Delete the voice profile?") { vm.voiceLock.delete(); enrolled = false; vlOn = false; p.voiceLockOn = false } })
        }
        if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)
    }
    GlassSettingSection("Owner Mode") {
        ToggleRow("Owner Mode", "Sensitive commands need confirmation, voice or biometric", owner) {
            if (it) { owner = true; p.ownerMode = true } else guarded("Turn off Owner Mode?") { owner = false; p.ownerMode = false }
        }
        GText("Protection level", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("confirm" to "Confirm only", "voice_or_bio" to "Voice or biometric", "biometric" to "Biometric required").forEach { (k, l) ->
                GlassChip(l, mode == k, { guarded("Change protection level?") { mode = k; p.protectMode = k } })
            }
        }
        GText("Protected: calls, deleting memories, notes or scan data, reading notifications or screen text, and changing these security settings.", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun LockPage(vm: NovaViewModel) {
    val p = vm.prefs
    var basic by remember { mutableStateOf(p.lockBasic) }
    var flash by remember { mutableStateOf(p.lockFlashlight) }
    var timer by remember { mutableStateOf(p.lockTimer) }
    var status by remember { mutableStateOf(p.lockStatus) }
    var unlock by remember { mutableStateOf(p.lockRequireUnlock) }
    GlassSettingSection("Lock Screen Assistant") {
        GText("What Nova may do while the phone is locked. Notifications, screen text, memories and notes are never revealed while locked, and Android decides whether apps can open.", size = 12.sp, color = LocalGlass.current.subtext)
        ToggleRow("Allow basic commands", "Time, date, volume, voice controls, simple questions", basic) { basic = it; p.lockBasic = it }
        ToggleRow("Allow flashlight", null, flash) { flash = it; p.lockFlashlight = it }
        ToggleRow("Allow timer and alarm", null, timer) { timer = it; p.lockTimer = it }
        ToggleRow("Allow basic device status", "Battery, Wi-Fi, Bluetooth, device info", status) { status = it; p.lockStatus = it }
        ToggleRow("Require unlock for sensitive actions", "Calls, deleting data and anything private", unlock) { unlock = it; p.lockRequireUnlock = it }
    }
}

@Composable
internal fun OfflinePage(vm: NovaViewModel) {
    val g = LocalGlass.current
    GlassSettingSection("Offline mode") {
        GlassListItem("Status", if (vm.online) "Online" else "OFFLINE")
        GlassListItem("AI provider now", if (vm.online) "Gemini" else "Local provider (deterministic answers only)")
        GlassListItem("On-device AI model", "Not installed. A future model plugs in by implementing AIProvider.")
    }
    GlassSettingSection("Works offline") {
        listOf("Flashlight, volume, open apps and settings", "Battery, device, storage, Wi-Fi and Bluetooth status", "Time, date and calculator", "Timers and alarms through the clock app",
            "Notes, reminders and routines", "Local memory", "Device scan and change detection").forEach { GText("✓  $it", size = 13.sp) }
    }
    GlassSettingSection("Needs internet or extra data") {
        GText("Open-ended answers, Gemini summaries and AI context compression need internet; Nova says \"Internet is required for this answer.\"", size = 12.sp, color = g.subtext)
        GText("Speech recognition works offline only if your phone has offline speech data. Nova asks Android to prefer offline when there's no network.", size = 12.sp, color = g.subtext)
        GText("Speech output works offline only if an offline voice is installed (Android Settings, Text-to-speech).", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun PluginsPage(vm: NovaViewModel) {
    val g = LocalGlass.current
    GlassSettingSection("Plugins") {
        GText("Each module can be switched on or off. Modules that need APIs or permissions that aren't built yet are listed but unavailable.", size = 12.sp, color = g.subtext)
        vm.plugins.all.forEach { pl ->
            var on by remember(pl.id) { mutableStateOf(vm.plugins.isEnabled(pl.id)) }
            GlassListItem(pl.name, pl.description, trailing = {
                if (pl.implemented) GlassSwitch(on) { on = it; vm.plugins.setEnabled(pl.id, it) } else GText("Not built", size = 11.sp, color = g.subtext)
            })
        }
    }
}

@Composable
internal fun PeoplePage(vm: NovaViewModel) {
    val g = LocalGlass.current
    val p = vm.prefs
    val list by vm.people.people.collectAsState()
    var learn by remember { mutableStateOf(p.peopleLearn) }
    var ai by remember { mutableStateOf(p.peopleAi) }
    GlassSettingSection("People & Relationships") {
        GText("NOVA remembers only people you introduce, like \"Ye mera dost Rahul hai\". It never guesses who someone is, never records or identifies anyone secretly, and everything stays on this phone.", size = 12.sp, color = g.subtext)
        GlassListItem("Saved people", "${list.size}")
        GlassButton("Open People & Memory", { vm.navigateTo = 7 }, Modifier.fillMaxWidth(), primary = true)
        ToggleRow("Learn people from what I tell Nova", "Only clear statements. Turn off to add people by hand.", learn) { learn = it; p.peopleLearn = it }
        ToggleRow("Use people context in AI answers", "Only people named in a request, one short line each. Works with Gemini online; local people features also work offline.", ai) { ai = it; p.peopleAi = it }
        GlassListItem("Speaker identification", "Not installed. Voice never decides who someone is, and it never authorizes anything.")
        GlassListItem("Owner security", "Separate from people. Owner Mode, biometric and Voice Lock are in Security & Voice Lock.")
    }
}


@Composable
internal fun LanguagePage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var mode by remember { mutableStateOf(if (p.language == "manual") "manual" else if (p.language == "auto") "auto" else "legacy") }
    var tag by remember { mutableStateOf(p.manualTag) }
    var detect by remember { mutableStateOf(p.autoLangDetect) }
    var legacy by remember { mutableStateOf(p.language) }
    GlassSettingSection("Language mode") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Auto", mode == "auto", { mode = "auto"; p.language = "auto" })
            GlassChip("Manual", mode == "manual", { mode = "manual"; p.language = "manual" })
        }
        if (mode == "auto") {
            GlassListItem("Auto", "NOVA answers in the language you speak or write, including Hinglish and mixed speech, and switches when you switch. Detection runs on this phone.")
            ToggleRow("Speech recognition language detection", "Android 13+ can detect the language while you speak. Older phones use your last language.", detect) { detect = it; p.autoLangDetect = it }
            GText("Quick presets (Hindi/English/Hinglish only):", size = 12.sp, color = g.subtext)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "hinglish" to "Hinglish", "hindi" to "Hindi", "english" to "English").forEach { (k, l) ->
                    GlassChip(l, legacy == k, { legacy = k; p.language = k; mode = if (k == "auto") "auto" else "legacy" })
                }
            }
        }
        if (mode == "legacy") GlassListItem("Fixed preset", "Language is fixed to \"${p.language}\". Choose Auto to follow the user again.")
    }
    if (mode == "manual") GlassSettingSection("Choose a language") {
        GText("This language is used for speech recognition, Gemini replies and the voice.", size = 12.sp, color = g.subtext)
        com.nova.ai.language.LanguageCatalog.all.forEach { l ->
            GlassListItem(l.english + "  ·  " + l.native, l.tag, onClick = { tag = l.tag; p.manualTag = l.tag }, trailing = { if (tag == l.tag) GText("✓", size = 18.sp, color = g.accent) })
        }
    }
    GlassSettingSection("Voice for this language") {
        if (vm.voice.ttsNote.isNotBlank()) GText(vm.voice.ttsNote, size = 12.sp, color = g.accent)
        GlassButton("Test voice", { vm.voice.speak(if (p.language == "manual") (com.nova.ai.language.LanguageCatalog.byTag(p.manualTag)?.native ?: "Hello") else "Namaste, main Nova hoon.", vm.emotion) })
        GText("Speech recognition and text-to-speech use the voices installed on your phone. If a language is missing, install it in Android's Speech services / Text-to-speech settings. Offline recognition works only for languages with an installed offline pack.", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun WebPage(vm: NovaViewModel) {
    val p = vm.prefs
    val g = LocalGlass.current
    var web by remember { mutableStateOf(p.webSearchOn) }
    GlassSettingSection("Web Search") {
        ToggleRow("Enable web search", "Search → verify sources → summarize → answer. Needs internet and a Gemini key.", web) { web = it; p.webSearchOn = it }
        GlassListItem("Provider", "Gemini with Google Search grounding")
        GlassListItem("Try saying", "\"Internet par search karo …\", \"Latest news batao\", \"iPhone price search karo\", \"Kotlin coroutines research karo\", \"YouTube par search karo …\", \"X ki official website dhoondo\"")
        GlassListItem("Source checks", "Only https sources, duplicates removed, official/government/educational and well-known sources listed first and marked ✓.")
        GText("If the internet is unavailable or local-only mode is on, NOVA says so. It never invents results.", size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun AutomationPage(vm: NovaViewModel) {
    val g = LocalGlass.current
    val list = remember { vm.automation.list() }
    GlassSettingSection("Routines") {
        if (list.isEmpty()) GText("No routines yet. Say: \"Remind me at 7 pm to …\", \"When battery is low, notify me\", \"When headphones connect, remind me …\".", size = 12.sp, color = g.subtext)
        list.forEach { r -> GlassListItem(r.name.ifBlank { r.trigger }, "${r.trigger} · ${if (r.enabled) "on" else "off"}") }
        GText("Routines only notify or offer to open an app. Sensitive actions always need your tap.", size = 12.sp, color = g.subtext)
    }
    GlassSettingSection("Routine log") {
        val log = vm.prefs.routinesLog
        GText(if (log.isBlank()) "Nothing has run yet." else log, size = 12.sp, color = g.subtext)
    }
}

@Composable
internal fun FuturePage() {
    GlassSettingSection("Future modules (interfaces only)") {
        com.nova.ai.future.FutureModules.all.forEach { m -> GlassListItem(m.title, "Interface ready: ${m.id}. Not implemented, so NOVA will say so if asked.") }
    }
}
