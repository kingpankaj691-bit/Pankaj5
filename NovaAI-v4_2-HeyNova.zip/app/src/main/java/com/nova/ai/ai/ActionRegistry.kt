package com.nova.ai.ai

import com.nova.ai.commands.Level
import com.nova.ai.core.CommandExecutor
import com.nova.ai.screen.ActionValidator

/** Result of one validated action. */
sealed class ActionOutcome {
    data class Done(val say: String) : ActionOutcome()
    data class NeedsConfirm(val prompt: String, val run: () -> String) : ActionOutcome()
    data class Refused(val reason: String) : ActionOutcome()
}

/**
 * Capability check -> ActionValidator -> execute. Later parts register handlers for security, vision, search and so on with
 * [register]; until then those actions answer honestly that they are not available yet.
 */
class ActionRegistry(private val local: CommandExecutor) {
    private val handlers = HashMap<NovaAction, (NovaIntent) -> String>()

    fun register(action: NovaAction, handler: (NovaIntent) -> String) { handlers[action] = handler }

    fun execute(intent: NovaIntent): ActionOutcome {
        val verdict = ActionValidator.forIntent(intent)
        if (verdict != null) return ActionOutcome.Refused(verdict)
        handlers[intent.action]?.let { h ->
            return if (intent.action.sensitive) ActionOutcome.NeedsConfirm("Do you want me to ${intent.action.name.lowercase().replace('_', ' ')}?") { h(intent) }
            else ActionOutcome.Done(h(intent))
        }
        val phrase = intent.action.phrase(intent.arg)
            ?: return ActionOutcome.Refused("That action is not available in this version of Nova yet.")
        val r = local.route(phrase)
        if (!r.handled) return ActionOutcome.Refused("Nova could not do that on this phone.")
        return if (r.level == Level.Info) ActionOutcome.Done(r.exec())
        else ActionOutcome.NeedsConfirm(r.prompt.ifBlank { "Go ahead?" }, r.exec)
    }
}
