package com.nova.ai.files

import android.content.Context
import java.io.File

/** Folder browsing by path. Only works where Android grants path access, and never outside the storage volumes. */
object FileBrowser {
    sealed class Listing {
        data class Ok(val dir: String, val items: List<FileItem>, val truncated: Boolean) : Listing()
        /** Android (or Nova's own safety rules) won't allow this folder. [reason] says why, instead of showing a misleading empty list. */
        data class Blocked(val reason: String) : Listing()
        data class NoAccess(val reason: String) : Listing()
    }

    fun fromFile(f: File): FileItem {
        val dir = try { f.isDirectory } catch (e: Exception) { false }
        val name = f.name.ifBlank { f.path }
        return FileItem(
            path = f.path, name = name, isDir = dir,
            size = if (dir) 0L else try { f.length() } catch (e: Exception) { 0L },
            modified = try { f.lastModified() } catch (e: Exception) { 0L },
            kind = if (dir) FileKind.FOLDER else FileTypes.kindOf(name),
            uri = null, mime = "", folder = f.parent.orEmpty()
        )
    }

    fun list(ctx: Context, path: String, sort: SortMode = SortMode.NAME, showHidden: Boolean = false, cap: Int = 2000): Listing {
        val access = FileAccess.state(ctx, 0)
        if (!access.pathAccess) return Listing.NoAccess(
            "Browsing folders by path needs “All files access” (Android 11+) or the storage permission (Android 8-9). " +
                "You can also pick a folder with the folder picker; Nova then sees only inside it."
        )
        val roots = StorageVolumes.roots(ctx)
        val canonical = try { File(path).canonicalPath } catch (e: Exception) { return Listing.Blocked("That path isn't valid.") }
        if (!PathRules.isWithinAny(roots, canonical)) return Listing.Blocked("That folder is outside your phone's storage volumes.")
        PathRules.blockedReason(canonical)?.let { return Listing.Blocked(it) }
        val dir = File(canonical)
        val kids = try { dir.listFiles() } catch (e: SecurityException) { null }
            ?: return Listing.Blocked("Android didn't let Nova read this folder.")
        val visible = kids.filter { showHidden || !it.name.startsWith(".") }
        val items = visible.take(cap).map { fromFile(it) }
        return Listing.Ok(canonical, FileSort.sort(items, sort), visible.size > cap)
    }
}
