package com.nova.ai.suite

import android.app.ActivityManager
import android.content.Context

/** One real on/off switch per Control Center section. Entry points check these before doing anything (default: on). */
object Features {
    const val SCREEN = "feat_screen"
    const val VISION = "feat_vision"
    const val AUTOMATION = "feat_automation"
    const val WORKFLOWS = "feat_workflows"
    const val TERMUX = "feat_termux"
    const val GITHUB = "feat_github"
    const val WATCH = "feat_watch"

    private fun sp(ctx: Context) = ctx.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)
    fun enabled(ctx: Context, key: String) = sp(ctx).getBoolean(key, true)
    fun set(ctx: Context, key: String, on: Boolean) { sp(ctx).edit().putBoolean(key, on).apply() }
    fun off(name: String) = "$name is turned off. Turn it on in Nova > More > Control Center."

    fun getInt(ctx: Context, key: String, def: Int) = sp(ctx).getInt(key, def)
    fun putInt(ctx: Context, key: String, v: Int) { sp(ctx).edit().putInt(key, v).apply() }
    fun getString(ctx: Context, key: String, def: String) = sp(ctx).getString(key, def) ?: def
    fun putString(ctx: Context, key: String, v: String) { sp(ctx).edit().putString(key, v).apply() }
    fun getBool(ctx: Context, key: String, def: Boolean) = sp(ctx).getBoolean(key, def)
    fun putBool(ctx: Context, key: String, v: Boolean) { sp(ctx).edit().putBoolean(key, v).apply() }
}

/** Decides how gently Nova should behave on weak hardware (Galaxy A12: 4 GB RAM). Cached per process. */
object PerfProfile {
    @Volatile private var cached: Boolean? = null

    fun lowMemory(ctx: Context): Boolean {
        cached?.let { return it }
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val low = am.isLowRamDevice || mi.totalMem <= 4_600_000_000L
        cached = low
        return low
    }

    fun ocrBaseMs(ctx: Context) = if (lowMemory(ctx)) 3500L else 2500L
    fun ocrMaxMs(ctx: Context) = if (lowMemory(ctx)) 8000L else 5000L
    fun agentStepDelayMs(ctx: Context) = if (lowMemory(ctx)) 1500L else 1100L
    fun orbTickMs(ctx: Context) = if (lowMemory(ctx)) 80L else 50L
    fun ocrMaxSide(ctx: Context) = if (lowMemory(ctx)) 1280 else 2000
}
