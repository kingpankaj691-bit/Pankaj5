package com.nova.ai.ai

import com.nova.ai.commands.Calc
import com.nova.ai.core.AIProvider

/**
 * Deterministic local provider used when there is no internet. It answers only what it can compute locally
 * and otherwise says so. A future on-device model can implement AIProvider and replace this class.
 */
class OfflineProvider : AIProvider {
    companion object { const val NEEDS_INTERNET = "Internet is required for this answer." }

    override suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String?): AiResult {
        val q = history.lastOrNull { it.first }?.second ?: return AiResult.Err(NEEDS_INTERNET)
        Calc.fromText(q)?.let { return AiResult.Ok("[emo:calm] $it") }
        return AiResult.Err(NEEDS_INTERNET)
    }
}
