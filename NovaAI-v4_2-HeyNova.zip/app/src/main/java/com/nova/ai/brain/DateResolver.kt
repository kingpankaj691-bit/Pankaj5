package com.nova.ai.brain

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Turns "kal", "tomorrow 5 baje", "next monday", "2 ghante mein" into a real date using the phone's local date and time. */
object DateResolver {
    data class Result(val at: Long, val hasTime: Boolean, val phrase: String)

    private val weekdays: Map<String, DayOfWeek> = mapOf(
        "monday" to DayOfWeek.MONDAY, "somvar" to DayOfWeek.MONDAY, "somwar" to DayOfWeek.MONDAY,
        "tuesday" to DayOfWeek.TUESDAY, "mangalvar" to DayOfWeek.TUESDAY, "mangalwar" to DayOfWeek.TUESDAY,
        "wednesday" to DayOfWeek.WEDNESDAY, "budhvar" to DayOfWeek.WEDNESDAY, "budhwar" to DayOfWeek.WEDNESDAY,
        "thursday" to DayOfWeek.THURSDAY, "guruvar" to DayOfWeek.THURSDAY, "veervar" to DayOfWeek.THURSDAY,
        "friday" to DayOfWeek.FRIDAY, "shukravar" to DayOfWeek.FRIDAY, "shukrawar" to DayOfWeek.FRIDAY,
        "saturday" to DayOfWeek.SATURDAY, "shanivar" to DayOfWeek.SATURDAY, "shaniwar" to DayOfWeek.SATURDAY,
        "sunday" to DayOfWeek.SUNDAY, "ravivar" to DayOfWeek.SUNDAY, "itwar" to DayOfWeek.SUNDAY, "ravivaar" to DayOfWeek.SUNDAY
    )
    private val pastWords = Regex("\\b(tha|thi|the|gaya|gayi|gaye|yesterday|beeta|pichhle|pichle|pichhla|pichla|last|previous|purani|purana)\\b")
    private val timeRe = Regex("\\b(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje|bje|o'?clock)?\\b")

    fun resolve(text: String, nowMs: Long, zone: ZoneId = ZoneId.systemDefault()): Result? {
        val l = text.lowercase()
        val now = LocalDateTime.ofInstant(Instant.ofEpochMilli(nowMs), zone)
        var date: LocalDate? = null
        var phrase = ""
        var relative: LocalDateTime? = null

        Regex("(?:in|after)\\s+(\\d{1,3})\\s*(minutes?|mins?|hours?|hrs?|days?)").find(l)?.let {
            val n = it.groupValues[1].toLong()
            relative = when {
                it.groupValues[2].startsWith("min") -> now.plusMinutes(n)
                it.groupValues[2].startsWith("h") -> now.plusHours(n)
                else -> now.plusDays(n)
            }; phrase = it.value
        }
        if (relative == null) Regex("(\\d{1,3})\\s*(minute|min|ghante|ghanta|ghanta|din)\\s*(?:mein|me|baad|ke baad)").find(l)?.let {
            val n = it.groupValues[1].toLong()
            relative = when (it.groupValues[2]) {
                "minute", "min" -> now.plusMinutes(n)
                "din" -> now.plusDays(n)
                else -> now.plusHours(n)
            }; phrase = it.value
        }
        relative?.let { return Result(it.atZone(zone).toInstant().toEpochMilli(), true, phrase) }

        val pastTense = pastWords.containsMatchIn(l)
        when {
            Regex("\\b(parso|day after tomorrow)\\b").containsMatchIn(l) -> { date = now.toLocalDate().plusDays(2); phrase = "parso" }
            Regex("\\b(kal|tomorrow|tmrw|tomorow)\\b").containsMatchIn(l) && !pastTense -> { date = now.toLocalDate().plusDays(1); phrase = "kal" }
            Regex("\\b(aaj|aj|today|tonight|aaj raat)\\b").containsMatchIn(l) -> { date = now.toLocalDate(); phrase = "aaj" }
            Regex("\\b(agle hafte|next week|agle week)\\b").containsMatchIn(l) -> { date = now.toLocalDate().plusWeeks(1); phrase = "next week" }
            Regex("\\b(agle mahine|next month)\\b").containsMatchIn(l) -> { date = now.toLocalDate().plusMonths(1); phrase = "next month" }
        }
        if (date == null) {
            for ((name, dow) in weekdays) if (Regex("\\b$name\\b").containsMatchIn(l)) {
                date = now.toLocalDate().with(java.time.temporal.TemporalAdjusters.next(dow)); phrase = name; break
            }
        }
        if (date == null) {   // "5 march", "march 5", "5/3"
            val months = listOf("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december")
            for ((i, m) in months.withIndex()) {
                val a = Regex("\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+$m\\b").find(l) ?: Regex("\\b$m\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b").find(l)
                if (a != null) {
                    val day = a.groupValues[1].toInt().coerceIn(1, 31)
                    var d = try { LocalDate.of(now.year, i + 1, day) } catch (e: Exception) { null }
                    if (d != null && d.isBefore(now.toLocalDate())) d = d.plusYears(1)
                    if (d != null) { date = d; phrase = a.value; break }
                }
            }
        }
        val time = parseTime(l)
        if (date == null && time == null) return null
        val d = date ?: if (time != null && !LocalDateTime.of(now.toLocalDate(), time.first).isAfter(now)) now.toLocalDate().plusDays(1) else now.toLocalDate()
        val t = time?.first ?: LocalTime.of(9, 0)
        if (phrase.isEmpty()) phrase = "time"
        return Result(LocalDateTime.of(d, t).atZone(zone).toInstant().toEpochMilli(), time != null, phrase)
    }

    private fun parseTime(l: String): Pair<LocalTime, String>? {
        val word = when {
            Regex("\\b(subah|morning|savere|sawere)\\b").containsMatchIn(l) -> "am"
            Regex("\\b(shaam|sham|evening|raat|night|dopahar|afternoon)\\b").containsMatchIn(l) -> "pm"
            else -> ""
        }
        for (m in timeRe.findAll(l)) {
            val unit = m.groupValues[3]
            val hasColon = m.groupValues[2].isNotEmpty()
            if (unit.isEmpty() && !hasColon) continue
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            if (h > 24 || min > 59) continue
            val suffix = when { unit == "am" || unit == "pm" -> unit; word.isNotEmpty() -> word; (unit.startsWith("baje") || unit.startsWith("bje") || unit.startsWith("o")) && h in 1..6 -> "pm"; else -> "" }
            if (suffix == "pm" && h < 12) h += 12
            if (suffix == "am" && h == 12) h = 0
            if (h >= 24) continue
            return LocalTime.of(h, min) to m.value
        }
        return null
    }

    /** For recall questions: "kal wali baat", "pichhle hafte", "last month". Returns the [from, to) range in epoch ms. */
    fun pastRange(text: String, nowMs: Long, zone: ZoneId = ZoneId.systemDefault()): Pair<Long, Long>? {
        val l = text.lowercase()
        val today = LocalDateTime.ofInstant(Instant.ofEpochMilli(nowMs), zone).toLocalDate()
        fun ms(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()
        return when {
            Regex("\\b(parso wali|day before yesterday)\\b").containsMatchIn(l) -> ms(today.minusDays(2)) to ms(today.minusDays(1))
            Regex("\\b(kal wali|kal ki|kal ka|kal ke|yesterday)\\b").containsMatchIn(l) -> ms(today.minusDays(1)) to ms(today)
            Regex("\\b(aaj wali|aaj ki|aaj ka|earlier today|today's)\\b").containsMatchIn(l) -> ms(today) to ms(today.plusDays(1))
            Regex("\\b(pichhle hafte|pichle hafte|pichhle week|last week)\\b").containsMatchIn(l) -> ms(today.minusDays(7)) to ms(today.plusDays(1))
            Regex("\\b(pichhle mahine|pichle mahine|last month)\\b").containsMatchIn(l) -> ms(today.minusDays(31)) to ms(today.plusDays(1))
            else -> null
        }
    }
}
