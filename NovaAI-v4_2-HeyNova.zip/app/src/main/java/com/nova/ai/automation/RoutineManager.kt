package com.nova.ai.automation

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.nova.ai.device.DeviceAlerts
import com.nova.ai.security.Prefs
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Weekly routines (e.g. Tuesday and Saturday), Night Mode and Editing Mode.
 * Everything here only changes Nova's own settings, posts notifications, or opens an Android settings page for the user.
 * It never toggles protected system settings (Wi-Fi, Do Not Disturb, night light) by itself.
 */
object RoutineManager {
    val DAYS = listOf("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
    private val calDay = mapOf("SUN" to Calendar.SUNDAY, "MON" to Calendar.MONDAY, "TUE" to Calendar.TUESDAY, "WED" to Calendar.WEDNESDAY,
        "THU" to Calendar.THURSDAY, "FRI" to Calendar.FRIDAY, "SAT" to Calendar.SATURDAY)
    val names = mapOf(
        "MON" to listOf("monday", "mondays", "mon", "somvar", "somwar"), "TUE" to listOf("tuesday", "tuesdays", "tue", "tues", "mangalvar", "mangalwar"),
        "WED" to listOf("wednesday", "wednesdays", "wed", "budhvar", "budhwar"), "THU" to listOf("thursday", "thursdays", "thu", "thur", "thurs", "guruvar", "guruwar", "brihaspativar"),
        "FRI" to listOf("friday", "fridays", "fri", "shukravar", "shukrawar"), "SAT" to listOf("saturday", "saturdays", "sat", "shanivar", "shaniwar"),
        "SUN" to listOf("sunday", "sundays", "sun", "ravivar", "raviwar", "itwar"))

    /** "tuesday and saturday", "tue,sat", "mangalvar shanivar" -> {TUE, SAT} */
    fun parseDays(text: String): Set<String> {
        val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
        return DAYS.filter { d -> words.any { it in names.getValue(d) } }.toSet()
    }

    fun dayName(code: String) = code.lowercase().replaceFirstChar { it.uppercase() }.let {
        when (code) { "MON" -> "Monday"; "TUE" -> "Tuesday"; "WED" -> "Wednesday"; "THU" -> "Thursday"; "FRI" -> "Friday"; "SAT" -> "Saturday"; else -> "Sunday" }
    }

    fun encode(days: Set<String>, hhmm: String) = DAYS.filter { it in days }.joinToString(",") + "@" + hhmm
    fun decode(v: String): Pair<Set<String>, String>? {
        val p = v.split("@")
        if (p.size != 2) return null
        val d = p[0].split(",").filter { it in DAYS }.toSet()
        return if (d.isEmpty()) null else d to p[1]
    }

    /** UI/voice input like "tue,sat 18:00" or "tuesday saturday 6:30" -> trigValue, or null if it can't be read. */
    fun parseWeeklyInput(input: String, defaultTime: String = "18:00"): String? {
        val days = parseDays(input)
        if (days.isEmpty()) return null
        val m = Regex("(\\d{1,2}):(\\d{2})").find(input)
        val hhmm = if (m != null) {
            val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
            if (h !in 0..23 || mi !in 0..59) return null
            "%02d:%02d".format(h, mi)
        } else defaultTime
        return encode(days, hhmm)
    }

    fun describeWeekly(v: String): String {
        val (d, t) = decode(v) ?: return "Weekly"
        return "Every " + DAYS.filter { it in d }.joinToString(", ") { dayName(it) } + " at $t"
    }

    /** Milliseconds until the next matching day/time (at least a second away). */
    fun weeklyDelay(trigValue: String): Long {
        val (days, hhmm) = decode(trigValue) ?: return TimeUnit.HOURS.toMillis(24)
        val p = hhmm.split(":")
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, add)
                set(Calendar.HOUR_OF_DAY, p.getOrNull(0)?.toIntOrNull() ?: 18); set(Calendar.MINUTE, p.getOrNull(1)?.toIntOrNull() ?: 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val code = calDay.entries.first { it.value == c.get(Calendar.DAY_OF_WEEK) }.key
            if (code in days && c.timeInMillis > now + 1000) return c.timeInMillis - now
        }
        return TimeUnit.HOURS.toMillis(24)
    }

    /** Creates (or replaces) the "editing day" routine. Returns the routine id. */
    fun setEditingDays(engine: AutomationEngine, p: Prefs, days: Set<String>, hhmm: String): Long {
        if (p.editingRoutineId > 0) engine.delete(p.editingRoutineId)
        val msg = "Nova: Today is your editing day. Your editing template is ready in Nova."
        val id = engine.create(Routine(0, "Editing day", "TIME_WEEKLY", encode(days, hhmm), "NOTIFY", msg, true, true, 0, System.currentTimeMillis(), 0))
        p.editingRoutineId = id; p.editingDays = days.joinToString(","); p.editingTime = hhmm
        return id
    }

    // ───────── Night Mode ─────────

    fun nightOn(ctx: Context, p: Prefs): String {
        if (!p.nightActive) { p.nightPrevVolume = p.ttsVolume; p.nightPrevTheme = p.themeMode; p.ttsVolume = (p.ttsVolume * 0.5f).coerceAtLeast(0.2f) }
        p.nightActive = true
        p.themeMode = "dark"
        Notifier.post(ctx, 5100, "Night mode on", "Nova's voice is quieter and its theme is dark. Tap to open Android display settings for night light.",
            settingsTap(ctx, Settings.ACTION_DISPLAY_SETTINGS))
        return "Night mode on. I lowered my own voice volume and switched Nova to the dark theme. Android doesn't let apps switch night light directly, so I can open display settings for you."
    }

    fun nightOff(p: Prefs): String {
        if (!p.nightActive) return "Night mode isn't on."
        p.ttsVolume = p.nightPrevVolume
        p.themeMode = p.nightPrevTheme
        p.nightActive = false
        return "Night mode off. My volume and theme are back to how they were."
    }

    // ───────── Editing Mode ─────────

    fun editingOn(p: Prefs): String {
        if (!p.editingActive) p.editingPrevProactive = p.proactive
        p.editingActive = true
        p.proactive = false
        return "Editing mode on. I paused my own proactive notifications."
    }

    fun editingOff(p: Prefs): String {
        if (!p.editingActive) return "Editing mode isn't on."
        p.proactive = p.editingPrevProactive
        p.editingActive = false
        return "Editing mode off. My notifications are back to normal."
    }

    // ───────── scheduling ─────────

    /** Re-creates every scheduled piece after boot, app start or a settings change. Cheap and idempotent. */
    fun syncAll(ctx: Context, p: Prefs = Prefs(ctx)) {
        DeviceAlerts.schedule(ctx, p)
        val wm = WorkManager.getInstance(ctx)
        if (p.nightScheduleOn) {
            schedule(ctx, "night_on", p.nightStart)
            schedule(ctx, "night_off", p.nightEnd)
        } else { wm.cancelUniqueWork("mode_night_on"); wm.cancelUniqueWork("mode_night_off") }
    }

    fun schedule(ctx: Context, kind: String, hhmm: String) {
        val req = OneTimeWorkRequestBuilder<ModeWorker>()
            .setInitialDelay(AutomationEngine.nextDelay(hhmm), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("kind" to kind, "at" to hhmm)).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("mode_$kind", ExistingWorkPolicy.REPLACE, req)
    }

    private fun settingsTap(ctx: Context, action: String) = PendingIntent.getActivity(ctx, action.hashCode(),
        Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

class ModeWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val app = applicationContext
        val p = Prefs(app)
        val kind = inputData.getString("kind") ?: return Result.success()
        val at = inputData.getString("at") ?: return Result.success()
        if (!p.nightScheduleOn) return Result.success()
        if (kind == "night_on") RoutineManager.nightOn(app, p) else RoutineManager.nightOff(p)
        RoutineManager.schedule(app, kind, at)          // same time tomorrow
        return Result.success()
    }
}
