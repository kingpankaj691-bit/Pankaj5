package com.nova.ai.vision

import androidx.camera.core.ImageProxy
import android.os.SystemClock
import kotlin.math.abs

enum class Gesture { SWIPE_RIGHT, SWIPE_LEFT, WAVE }

/**
 * Optional hand-gesture control from camera frames, with no network and no stored images.
 * It looks at how a hand moves across the picture (frame-to-frame brightness change), so it recognises:
 *   swipe right -> next, swipe left -> previous, wave (two opposite swipes) -> play/pause.
 * It cannot recognise a still "open palm" shape: that needs a hand-landmark model, which Nova does not bundle.
 * Runs only while the Camera screen is open and gesture mode is on. Left/right match what you see on the (mirrored) front preview.
 */
class GestureManager(private val mirrored: Boolean, private val onGesture: (Gesture) -> Unit) {
    companion object {
        private const val GW = 24
        private const val GH = 32
        private const val FRAME_GAP_MS = 60L
        private const val DIFF = 22
        private const val SWIPE_MIN_DX = 0.35f
        private const val SWIPE_MIN_MS = 150L
        private const val SWIPE_MAX_MS = 750L
        private const val PAIR_MS = 1300L
        private const val SETTLE_MS = 700L
        private const val COOLDOWN_MS = 800L
    }

    private var prev: IntArray? = null
    private var lastFrame = 0L
    private val xs = ArrayList<Float>()
    private val ts = ArrayList<Long>()
    private var pendingDir = 0
    private var pendingAt = 0L
    private var cooldownUntil = 0L

    fun analyze(image: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        flushPending(now)
        if (now - lastFrame < FRAME_GAP_MS || now < cooldownUntil) return
        lastFrame = now
        val plane = image.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride; val ps = plane.pixelStride
        val w = image.width; val h = image.height
        val cur = IntArray(GW * GH)
        for (gy in 0 until GH) for (gx in 0 until GW) {
            val idx = ((gy + 0.5f) * h / GH).toInt().coerceIn(0, h - 1) * rs + ((gx + 0.5f) * w / GW).toInt().coerceIn(0, w - 1) * ps
            cur[gy * GW + gx] = if (idx < buf.limit()) buf.get(idx).toInt() and 0xFF else 0
        }
        val p = prev
        prev = cur
        if (p == null) return
        var n = 0; var sx = 0f; var sy = 0f
        for (gy in 0 until GH) for (gx in 0 until GW) if (abs(cur[gy * GW + gx] - p[gy * GW + gx]) > DIFF) { n++; sx += (gx + 0.5f) / GW; sy += (gy + 0.5f) / GH }
        val frac = n / (GW * GH).toFloat()
        if (frac < 0.02f || frac > 0.60f) { if (frac > 0.60f) reset(); else if (ts.isNotEmpty() && now - ts.last() > 250) reset(); return }
        val dx = displayX(sx / n, sy / n, image.imageInfo.rotationDegrees)
        xs.add(dx); ts.add(now)
        while (ts.isNotEmpty() && now - ts.first() > SWIPE_MAX_MS) { ts.removeAt(0); xs.removeAt(0) }
        evaluate(now)
    }

    /** Maps a point in the raw camera frame to the horizontal position on the upright preview (0 = left edge, 1 = right edge). */
    private fun displayX(cx: Float, cy: Float, rotation: Int): Float {
        val x = when (rotation) { 90 -> 1f - cy; 180 -> 1f - cx; 270 -> cy; else -> cx }
        return if (mirrored) 1f - x else x
    }

    private fun evaluate(now: Long) {
        if (xs.size < 4) return
        val dx = xs.last() - xs.first()
        val dur = ts.last() - ts.first()
        if (abs(dx) < SWIPE_MIN_DX || dur < SWIPE_MIN_MS) return
        var same = 0
        for (i in 1 until xs.size) if ((xs[i] - xs[i - 1]) * dx > 0) same++
        if (same < (xs.size - 1) * 0.7f) return
        val dir = if (dx > 0) 1 else -1
        reset()
        cooldownUntil = now + 250
        if (pendingDir != 0 && dir == -pendingDir && now - pendingAt < PAIR_MS) {
            pendingDir = 0
            cooldownUntil = now + COOLDOWN_MS
            onGesture(Gesture.WAVE)
        } else { pendingDir = dir; pendingAt = now }
    }

    /** A single swipe is only reported once no opposite swipe followed it (otherwise it was half of a wave). */
    private fun flushPending(now: Long) {
        if (pendingDir != 0 && now - pendingAt > SETTLE_MS) {
            val d = pendingDir
            pendingDir = 0
            cooldownUntil = now + COOLDOWN_MS
            onGesture(if (d > 0) Gesture.SWIPE_RIGHT else Gesture.SWIPE_LEFT)
        }
    }

    private fun reset() { xs.clear(); ts.clear() }
}
