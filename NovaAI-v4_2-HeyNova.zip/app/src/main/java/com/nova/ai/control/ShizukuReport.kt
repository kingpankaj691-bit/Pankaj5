package com.nova.ai.control

enum class ShizukuFix { NONE, INSTALL_SHIZUKU, OPEN_SHIZUKU_APP, REQUEST_PERMISSION, UPDATE_SHIZUKU, RECONNECT }

data class ShizukuLine(val label: String, val ok: Boolean, val detail: String, val fix: ShizukuFix = ShizukuFix.NONE)

/** One honest row per Shizuku component, from the real snapshot. Pure Kotlin (unit-tested). */
object ShizukuReport {
    const val NOTE = "Shizuku permission is separate from Accessibility and All files access: granting one never grants the others."

    fun lines(s: ShizukuSnapshot): List<ShizukuLine> {
        val installed = s.installed || s.running
        return listOf(
            ShizukuLine("Shizuku app installed", installed, if (installed) "Yes" else "No: install it from its official page", if (installed) ShizukuFix.NONE else ShizukuFix.INSTALL_SHIZUKU),
            ShizukuLine("Shizuku service running (binder connected)", s.running,
                if (s.running) "Running (${s.mode})" else if (installed) "Not running: open Shizuku and start it" else "Not running",
                if (!s.running && installed) ShizukuFix.OPEN_SHIZUKU_APP else ShizukuFix.NONE),
            ShizukuLine("Shizuku version supported", s.running && s.serverVersion >= 11,
                if (!s.running) "Unknown (service not running)" else if (s.serverVersion >= 11) "v${s.serverVersion}" else "v${s.serverVersion} is too old (needs 11+)",
                if (s.running && s.serverVersion < 11) ShizukuFix.UPDATE_SHIZUKU else ShizukuFix.NONE),
            ShizukuLine("Nova has Shizuku permission", s.granted,
                if (s.granted) "Granted" else if (s.permanentlyDenied) "Denied: allow Nova AI inside the Shizuku app" else "Not granted yet",
                if (s.granted || !s.running) ShizukuFix.NONE else if (s.permanentlyDenied) ShizukuFix.OPEN_SHIZUKU_APP else ShizukuFix.REQUEST_PERMISSION),
            ShizukuLine("Shell service connected", s.serviceBound,
                if (s.serviceBound) "Connected" else if (s.granted) "Permission granted but the shell service isn't connected" else "Needs the permission first",
                if (s.granted && !s.serviceBound) ShizukuFix.RECONNECT else ShizukuFix.NONE)
        )
    }

    /** Commands can run only when every line is OK. */
    fun usable(s: ShizukuSnapshot): Boolean = lines(s).all { it.ok }
}

/** Checks the real ANSWER of a test command. */
object ShizukuSelfTest {
    data class Result(val ok: Boolean, val message: String)

    fun evaluate(r: ShellResult, sdk: Int): Result = when {
        r.blocked -> Result(false, "Nova's own command policy blocked the test: ${r}")
        !r.ok -> Result(false, "The test command failed (exit ${r.exitCode}): ${r}")
        r.out.trim().toIntOrNull() == sdk -> Result(true, "Shizuku ran a command and returned the right answer (Android SDK $sdk).")
        else -> Result(false, "Shizuku ran the command but returned an unexpected answer: \"${r.out.trim().take(40)}\" (expected $sdk).")
    }
}
