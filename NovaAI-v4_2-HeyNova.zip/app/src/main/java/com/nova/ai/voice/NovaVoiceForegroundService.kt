package com.nova.ai.voice

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ServiceCompat
import android.os.Build
import androidx.core.content.ContextCompat
import com.nova.ai.ai.model.ModelManager
import com.nova.ai.jarvis.Announcer
import com.nova.ai.jarvis.CallAnnouncer
import com.nova.ai.jarvis.ClipboardWatcher
import com.nova.ai.jarvis.SmartHome
import com.nova.ai.jarvis.FloatingOrb
import com.nova.ai.jarvis.JarvisPrefs
import com.nova.ai.jarvis.LocationReminders
import com.nova.ai.jarvis.ProactiveEngine
import com.nova.ai.jarvis.SpeechEngines
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Background Voice: the microphone lives here, and only here.
 *
 * Start order : startForeground (visible notification, microphone type) -> permission check -> partial WakeLock -> AudioRecord.
 * Stop order  : AudioCapture -> speech engine -> AudioRecord released -> WakeLock released -> notification removed -> stopSelf.
 *
 * It is never restarted by the system (START_NOT_STICKY) and never restarts itself. If Android kills it, Background Voice is
 * simply off until the user turns it on again.
 */
class NovaVoiceForegroundService : Service(), AudioCapture.Events {

    companion object {
        const val ACTION_START = "com.nova.ai.voice.action.START"
        const val ACTION_STOP = "com.nova.ai.voice.action.STOP"
        const val ACTION_PAUSE = "com.nova.ai.voice.action.PAUSE"
        const val ACTION_RESUME = "com.nova.ai.voice.action.RESUME"
        /** Settings changed (Hey Nova, orb, wake phrases...): rebuild the orb and the speech engine without turning Background Voice off. */
        const val ACTION_APPLY = "com.nova.ai.voice.action.APPLY"

        private fun intent(ctx: Context, action: String) = Intent(ctx, NovaVoiceForegroundService::class.java).setAction(action)

        /** Call only after [VoicePermissionManager.canStart] is true and while Nova is on screen. */
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx, intent(ctx, ACTION_START)) }

        /** Turns Background Voice off for good (until the user turns it on again). */
        fun stop(ctx: Context) {
            VoiceState.setEnabled(ctx, false)
            ctx.stopService(Intent(ctx, NovaVoiceForegroundService::class.java))
        }

        /** Applies new Hey Nova / orb settings to a running service. Does nothing when Background Voice is off. */
        fun applySettings(ctx: Context) { if (VoiceState.running.value) ctx.startService(intent(ctx, ACTION_APPLY)) }

        fun pause(ctx: Context) { ctx.startService(intent(ctx, ACTION_PAUSE)) }
        fun resume(ctx: Context) { ctx.startService(intent(ctx, ACTION_RESUME)) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Prefs(applicationContext) }
    private val jp by lazy { JarvisPrefs(applicationContext) }
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var orb: FloatingOrb? = null
    private var proactive: ProactiveEngine? = null
    private var locations: LocationReminders? = null
    private var extrasOn = false
    private var clipboard: ClipboardWatcher? = null
    private lateinit var wakeLock: NovaWakeLockManager
    private var batteryRx: com.nova.ai.device.BatteryReceiver? = null
    private var capture: AudioCapture? = null
    private var engine: SpeechProcessingEngine? = null
    private var dispatcher: VoiceCommandDispatcher? = null
    private var lastNotified = ""
    private var modelWatch: kotlinx.coroutines.Job? = null
    private var modeWatch: kotlinx.coroutines.Job? = null
    private var wakeWatch: kotlinx.coroutines.Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wakeLock = NovaWakeLockManager(this)
        SmartHome.load(this)
        VoiceNotificationManager.ensureChannel(this)
        com.nova.ai.suite.SecurityWatch.serviceStarted(this)
        com.nova.ai.suite.LiveOcr.resumeIfEnabled(this)
        // Duck other audio while YOU speak too (not only while Nova talks). Released 2.5 s after the last loud sound.
        uiScope.launch {
            var releaseJob: kotlinx.coroutines.Job? = null
            com.nova.ai.suite.VoiceLevel.level.collect { l ->
                if (l > 0.12f && com.nova.ai.suite.AudioDucker.duckOnUser(this@NovaVoiceForegroundService)) {
                    com.nova.ai.suite.AudioDucker.acquire(this@NovaVoiceForegroundService)
                    releaseJob?.cancel()
                    releaseJob = launch { kotlinx.coroutines.delay(2500); if (!VoiceState.speaking.value) com.nova.ai.suite.AudioDucker.release(this@NovaVoiceForegroundService) }
                }
            }
        }
        // Smart audio ducking: other audio gets quieter only while Nova speaks. Off switch: Privacy Dashboard.
        uiScope.launch { VoiceState.speaking.collect { sp -> if (sp) com.nova.ai.suite.AudioDucker.acquire(this@NovaVoiceForegroundService) else com.nova.ai.suite.AudioDucker.release(this@NovaVoiceForegroundService) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {                 // system recreation after a kill: do nothing, never restart silently
            shutdown()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_STOP -> {
                VoiceState.setEnabled(this, false)
                shutdown()
            }
            ACTION_PAUSE -> {
                if (enterForeground(VoiceStatus.Paused)) pauseCapture()
            }
            ACTION_APPLY -> {
                // rebuild the orb for the new settings; the microphone and engine restart only when they are running (not paused)
                if (VoiceState.running.value && enterForeground(if (VoiceState.paused.value) VoiceStatus.Paused else VoiceStatus.Starting)) {
                    stopExtras(); startExtras()
                    if (!VoiceState.paused.value && permissionsOk()) beginCapture()
                } else if (!VoiceState.running.value) shutdown()
            }
            ACTION_RESUME, ACTION_START, null -> {
                VoiceNotificationManager.clearStopped(this)
                if (enterForeground(VoiceStatus.Starting) && permissionsOk()) beginCapture()
            }
            else -> shutdown()
        }
        return START_NOT_STICKY
    }

    // ───────── foreground + permissions ─────────

    /** Must happen within seconds of startForegroundService(). Fails (and stops the service) if Android refuses it. */
    private fun enterForeground(status: VoiceStatus): Boolean {
        return try {
            ServiceCompat.startForeground(
                this, VoiceNotificationManager.NOTIFICATION_ID,
                VoiceNotificationManager.build(this, status, VoiceState.detail.value),
                foregroundType()
            )
            VoiceState.running.value = true
            true
        } catch (e: Exception) {
            // SecurityException (no RECORD_AUDIO) or Android 12+ background-start restriction.
            giveUp(VoicePermissionManager.missingExplanation(this)
                ?: "Android did not allow the microphone service to start. Open Nova and turn Background Voice on again.")
            false
        }
    }

    /** Microphone always; location too when location reminders are on and Location is allowed (Android needs it declared to read location in the background). */
    private fun foregroundType(): Int {
        var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (Build.VERSION.SDK_INT >= 29 && jp.locationReminders && LocationReminders.hasPermission(this)) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        return t
    }

    private fun permissionsOk(): Boolean {
        val missing = VoicePermissionManager.missingExplanation(this) ?: return true
        giveUp(missing)
        return false
    }

    /** Stops everything, switches Background Voice off and tells the user why. Used for permission and fatal errors. */
    private fun giveUp(reason: String) {
        VoiceState.setEnabled(this, false)
        VoiceState.detail.value = reason
        VoiceNotificationManager.postStopped(this, reason)
        shutdown(keepDetail = true)
    }

    // ───────── capture lifecycle ─────────

    private fun beginCapture() {
        cleanupCapture()
        VoiceState.setEnabled(this, true)
        VoiceState.paused.value = false
        VoiceState.status.value = VoiceStatus.Starting
        VoiceState.detail.value = ""
        VoiceState.problem.value = ""
        wakeLock.acquire()
        com.nova.ai.live.OverlayEdgeGlowController.start(this)
        val d = dispatcher ?: VoiceCommandDispatcher(application, prefs).also { dispatcher = it }
        val eng = SpeechEngines.create(this, prefs, jp, onText = { d.onRecognized(it) }, onProblem = { onProblem(it) })
        engine = eng
        capture = AudioCapture(this, eng, this, preferCommunication = jp.interrupt).also { it.start() }
        startExtras()
        watchModel()
        watchWake()
        refreshNotification(VoiceStatus.Starting)
    }

    /**
     * What Nova says right after a wake phrase: "Nova, are you there?" / "Hello Jaan, suno" get an acknowledgement, and
     * "Jaan, kaisi ho?" / "Jaan, how are you?" are answered as the question they are. Other phrases only open the conversation.
     */
    private fun watchWake() {
        if (wakeWatch != null) return
        wakeWatch = uiScope.launch {
            NovaSession.wakeEvents.collect { id ->
                val reply = jp.wakeCatalog().firstOrNull { it.id == id }?.reply ?: return@collect
                if (reply.isEmpty()) dispatcher?.acknowledge() else dispatcher?.say(reply)
            }
        }
    }

    /**
     * The model can be changed in Settings while the microphone is on. The voice route (native Live or speech-to-text fallback)
     * depends on the model, so the capture engine is rebuilt for the newly selected model and the notification shows it.
     */
    private fun watchModel() {
        if (modelWatch == null) {
            var first = true
            modelWatch = uiScope.launch {
                ModelManager.activeFlow(applicationContext).collect {
                    if (first) { first = false; return@collect }
                    if (capture != null && !VoiceState.paused.value) beginCapture() else refreshNotification(VoiceState.status.value)
                }
            }
        }
        if (modeWatch == null) modeWatch = uiScope.launch { VoiceState.voiceMode.collect { refreshNotification(VoiceState.status.value) } }
    }

    private fun pauseCapture() {
        cleanupCapture()                      // AudioRecord, engine and WakeLock are released while paused
        VoiceState.paused.value = true
        VoiceState.status.value = VoiceStatus.Paused
        VoiceState.detail.value = "Paused. Microphone is off."
        VoiceState.problem.value = ""
        refreshNotification(VoiceStatus.Paused)
    }

    /** Features that live as long as Background Voice does (they don't need the microphone, so they keep running while paused). */
    private fun startExtras() {
        if (extrasOn) return
        extrasOn = true
        if (jp.callAnnounce || jp.carMode) CallAnnouncer.register(this)
        proactive = ProactiveEngine(applicationContext, prefs).also { it.start() }
        batteryRx = com.nova.ai.device.BatteryReceiver(prefs, null).also { it.register(applicationContext) }
        locations = LocationReminders(applicationContext).also { it.start() }
        if (jp.clipboard) clipboard = ClipboardWatcher(applicationContext).also { it.start() }
        if (jp.orb) {
            // The orb follows NovaSession / VoiceState by itself (see FloatingOrb.show); it appears on "Hey Nova" and hides afterwards.
            val o = FloatingOrb(applicationContext)
            orb = o
            o.show()
        }
    }

    private fun stopExtras() {
        if (!extrasOn) return
        extrasOn = false
        CallAnnouncer.unregister(this)
        proactive?.stop(); proactive = null
        batteryRx?.unregister(applicationContext); batteryRx = null
        locations?.stop(); locations = null
        clipboard?.stop(); clipboard = null
        orb?.hide(); orb = null
    }

    /** Idempotent: capture -> engine -> AudioRecord -> WakeLock. */
    private fun cleanupCapture() {
        capture?.stop()
        capture = null
        engine?.stop()
        engine = null
        wakeLock.release()
    }

    private fun shutdown(keepDetail: Boolean = false) {
        wakeWatch?.cancel(); wakeWatch = null
        NovaSession.reset()
        modelWatch?.cancel(); modelWatch = null
        modeWatch?.cancel(); modeWatch = null
        com.nova.ai.live.OverlayEdgeGlowController.stop(this)
        cleanupCapture()
        stopExtras()
        val keep = VoiceState.detail.value
        VoiceState.reset()
        if (keepDetail) VoiceState.detail.value = keep else VoiceState.detail.value = ""
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    private fun refreshNotification(status: VoiceStatus) {
        val detail = listOf(VoiceState.detail.value, VoiceState.problem.value).filter { it.isNotBlank() }.joinToString("\n")
        val key = "$status|$detail|${VoiceState.voiceMode.value}|${ModelManager.activeModelId(this)}"
        if (key == lastNotified) return
        lastNotified = key
        VoiceNotificationManager.update(this, status, detail)
    }

    private fun onProblem(msg: String) {
        if (VoiceState.problem.value == msg) return
        VoiceState.problem.value = msg
        refreshNotification(VoiceState.status.value)
    }

    // ───────── AudioCapture.Events (called from the capture thread) ─────────

    override fun onListening(info: String) {
        VoiceState.status.value = VoiceStatus.Listening
        VoiceState.detail.value = info
        refreshNotification(VoiceStatus.Listening)
    }

    override fun onWaiting(reason: String) {
        VoiceState.status.value = VoiceStatus.Interrupted
        VoiceState.detail.value = reason
        refreshNotification(VoiceStatus.Interrupted)
    }

    override fun onFatal(message: String) {
        handler.post { giveUp(message) }
    }

    // ───────── teardown ─────────

    override fun onDestroy() {
        NovaSession.reset()
        cleanupCapture()                      // 1. AudioCapture  2. speech engine  3. AudioRecord  4. WakeLock
        stopExtras()                          // orb, call announcer, reminders, proactive engine
        uiScope.cancel()
        com.nova.ai.suite.AudioDucker.release(this)
        com.nova.ai.suite.LiveOcr.stop(this, forget = false)
        com.nova.ai.suite.SecurityWatch.serviceStopped(this)
        com.nova.ai.suite.VoiceLevel.reset()
        Announcer.release()
        dispatcher?.close()                   // TTS and coroutines of the headless assistant
        dispatcher = null
        handler.removeCallbacksAndMessages(null)
        val keep = VoiceState.detail.value
        VoiceState.reset()
        VoiceState.detail.value = keep
        super.onDestroy()
    }
}
