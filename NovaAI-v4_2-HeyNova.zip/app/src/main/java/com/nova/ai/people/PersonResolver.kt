package com.nova.ai.people

/** Maps what the user says ("Rahul", "Rahu", "Rahul bhai", "meri mummy") to saved profiles. Never guesses when ambiguous. */
class PersonResolver(private val source: () -> List<PersonWithData>) {
    private val honorifics = setOf("bhai", "bhaiya", "ji", "sir", "madam", "didi", "uncle", "aunty", "bhabhi")

    fun stripHonorific(s: String): String {
        val t = s.split(" ").filter { it.isNotBlank() }
        return if (t.size >= 2 && t.last() in honorifics) t.dropLast(1).joinToString(" ") else s
    }

    fun namesOf(pw: PersonWithData): List<String> =
        (listOf(pw.person.name, pw.person.nickname, pw.person.preferredAddress) + pw.aliases.map { it.alias })
            .map { normName(it) }.filter { it.isNotBlank() }.distinct()

    fun exactName(name: String, list: List<PersonWithData> = source()): List<PersonWithData> {
        val q = stripHonorific(normName(name))
        if (q.isBlank()) return emptyList()
        return list.filter { pw -> namesOf(pw).any { stripHonorific(it) == q } }
    }

    private fun pick(l: List<PersonWithData>, query: String): Resolution =
        if (l.isEmpty()) Resolution.None else if (l.size == 1) Resolution.One(l[0]) else Resolution.Many(l, query)

    fun resolve(query: String): Resolution {
        var q = normName(query)
        for (pre in listOf("meri ", "mera ", "mere ", "my ")) if (q.startsWith(pre)) q = q.removePrefix(pre)
        q = q.trim()
        if (q.isEmpty()) return Resolution.None
        val list = source()
        val rel = RelationshipType.find(q)
        val byName = exactName(q, list)
        if (byName.isNotEmpty() && (rel == null || byName.any { namesOf(it).contains(q) })) return pick(byName, query)
        if (rel != null) return pick(list.filter { RelationshipType.matches(it.person.relType, rel) }, query)
        return Resolution.None
    }

    /** People named in a sentence (whole-word match) plus "meri mummy" style references that identify exactly one person. */
    fun mentionedIn(text: String): List<PersonWithData> {
        val n = " " + normName(text) + " "
        val list = source()
        val out = LinkedHashSet<PersonWithData>()
        for (pw in list) if (namesOf(pw).any { it.length >= 2 && n.contains(" $it ") }) out.add(pw)
        for (rt in RelationshipType.values()) for (w in rt.words) {
            if (Regex("\\b(?:meri|mera|mere|my) ${Regex.escape(w)}\\b").containsMatchIn(n)) {
                val c = list.filter { RelationshipType.matches(it.person.relType, rt) }
                if (c.size == 1) out.add(c[0])
            }
        }
        return out.toList()
    }

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    /** Possible duplicates for the user to review. Never merged automatically. */
    fun duplicates(list: List<PersonWithData> = source()): List<Pair<PersonWithData, PersonWithData>> {
        val out = mutableListOf<Pair<PersonWithData, PersonWithData>>()
        for (i in list.indices) for (j in i + 1 until list.size) {
            val a = list[i]; val b = list[j]
            if (!RelationshipType.sameGroup(a.person.relType, b.person.relType) && a.person.relType != "other" && b.person.relType != "other") continue
            val na = namesOf(a).map { stripHonorific(it) }; val nb = namesOf(b).map { stripHonorific(it) }
            val overlap = na.any { it in nb }
            val close = na.any { x -> nb.any { y -> x.length >= 4 && y.length >= 4 && 1.0 - lev(x, y).toDouble() / maxOf(x.length, y.length) >= 0.8 } }
            if (overlap || close) out.add(a to b)
        }
        return out
    }
}

class RelationshipGraph(private val source: () -> List<PersonWithData>) {
    fun grouped(list: List<PersonWithData> = source()): List<Pair<String, List<PersonWithData>>> =
        list.groupBy { it.person.relLabel }.toList().sortedWith(
            compareBy<Pair<String, List<PersonWithData>>> { g -> RelationshipType.values().indexOfFirst { it.label == g.first }.let { if (it < 0) 99 else it } }.thenBy { it.first })

    fun render(list: List<PersonWithData> = source()): String {
        val groups = grouped(list)
        if (groups.isEmpty()) return "User\n(no people saved yet)"
        val sb = StringBuilder("User")
        groups.forEachIndexed { gi, (label, ps) ->
            val lastG = gi == groups.lastIndex
            val branch = if (lastG) "└── " else "├── "
            if (ps.size == 1) sb.append("\n").append(branch).append(label).append(" → ").append(ps[0].person.name)
            else {
                sb.append("\n").append(branch).append(label)
                ps.forEachIndexed { pi, p ->
                    sb.append("\n").append(if (lastG) "    " else "│   ").append(if (pi == ps.lastIndex) "└── " else "├── ").append(p.person.name)
                }
            }
        }
        return sb.toString()
    }
}
