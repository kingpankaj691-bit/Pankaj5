package com.nova.ai.files

import com.nova.ai.control.ShizukuManager
import com.nova.ai.control.ShizukuStatus

/**
 * Shared-storage operations through Shizuku, for places Android keeps from normal apps (for example listing Android/data).
 * Every command goes through ShellPolicy, which only accepts shared-storage paths without spaces or wildcards, single files,
 * and never lets Nova write inside Android/. Private app data (/data/data) is not reachable this way and Nova never claims it is.
 */
object ShizukuFiles {
    fun ready(): Boolean = try { ShizukuManager.state.value.status == ShizukuStatus.READY } catch (e: Throwable) { false }

    private fun plain(path: String): String? =
        if (path.any { it.isWhitespace() }) "Shizuku can't handle spaces in paths, so I can't do this one that way." else null

    /** Names only (the shell policy has no `ls -l`), so size and date are unknown. */
    suspend fun list(path: String): Pair<List<FileItem>?, String> {
        plain(path)?.let { return null to it }
        val r = ShizukuManager.exec("ls -1p $path")
        if (!r.ok) return null to (r.toString().ifBlank { "Shizuku couldn't list that folder." })
        val base = PathRules.normalize(path)
        val items = r.out.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { n ->
            val dir = n.endsWith("/"); val name = n.trimEnd('/')
            FileItem("$base/$name", name, dir, 0L, 0L, if (dir) FileKind.FOLDER else FileTypes.kindOf(name), null, "", base)
        }
        return FileSort.sort(items, SortMode.NAME) to ""
    }

    suspend fun copy(src: String, destDir: String): OpResult {
        plain(src)?.let { return OpResult(false, it, 0, 1) }; plain(destDir)?.let { return OpResult(false, it, 0, 1) }
        val name = PathRules.leaf(src)
        val dst = "${PathRules.normalize(destDir)}/$name"
        val r = ShizukuManager.exec("cp $src $dst", 120_000)
        return if (r.ok) OpResult(true, "Copied $name with Shizuku.", 1) else OpResult(false, "Shizuku couldn't copy $name: ${r.toString().take(120)}", 0, 1)
    }

    suspend fun move(src: String, destDir: String): OpResult {
        plain(src)?.let { return OpResult(false, it, 0, 1) }; plain(destDir)?.let { return OpResult(false, it, 0, 1) }
        val name = PathRules.leaf(src)
        val r = ShizukuManager.exec("mv $src ${PathRules.normalize(destDir)}/$name", 120_000)
        return if (r.ok) OpResult(true, "Moved $name with Shizuku.", 1) else OpResult(false, "Shizuku couldn't move $name: ${r.toString().take(120)}", 0, 1)
    }

    suspend fun mkdir(parent: String, name: String): OpResult {
        NameRules.validate(name)?.let { return OpResult(false, it, 0, 1) }
        val path = "${PathRules.normalize(parent)}/${name.trim()}"
        plain(path)?.let { return OpResult(false, it, 0, 1) }
        val r = ShizukuManager.exec("mkdir $path")
        return if (r.ok) OpResult(true, "Created folder ${name.trim()} with Shizuku.", 1) else OpResult(false, "Shizuku couldn't create the folder: ${r.toString().take(120)}", 0, 1)
    }

    /** One file only (the policy has no recursive delete). Caller has the user's confirmation. */
    suspend fun delete(path: String): OpResult {
        plain(path)?.let { return OpResult(false, it, 0, 1) }
        val r = ShizukuManager.exec("rm $path")
        return if (r.ok) OpResult(true, "Deleted ${PathRules.leaf(path)} with Shizuku.", 1) else OpResult(false, "Shizuku couldn't delete ${PathRules.leaf(path)}: ${r.toString().take(120)}", 0, 1)
    }
}
