package com.nova.ai.search

import android.util.Xml
import com.nova.ai.future.WeatherModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class SearchHit(val title: String, val text: String, val url: String)
data class NewsItem(val title: String, val source: String, val link: String)

interface SearchProvider { suspend fun search(query: String): List<SearchHit> }
interface NewsProvider { suspend fun headlines(topic: String?, count: Int = 5): List<NewsItem> }

/** Weather already exists as [WeatherModule] (Open-Meteo, no key). This name is the provider interface for it. */
typealias WeatherProvider = WeatherModule

internal object PublicHttp {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).callTimeout(15, TimeUnit.SECONDS).build()
    }
    /** GET over HTTPS only, public pages and APIs only. Returns null on any failure. */
    suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext null
        try {
            client.newCall(Request.Builder().url(url).header("User-Agent", "NovaAI/2.5 (personal Android assistant)").build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (e: Exception) { null }
    }
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/**
 * Public, key-free search: DuckDuckGo's instant-answer API and Wikipedia's public API. It does not scrape result pages, log in
 * anywhere or get around any access control, so it can't answer everything; Gemini web search is richer when you have a key.
 */
class PublicSearchProvider : SearchProvider {
    override suspend fun search(query: String): List<SearchHit> {
        val out = ArrayList<SearchHit>()
        PublicHttp.get("https://api.duckduckgo.com/?q=${PublicHttp.enc(query)}&format=json&no_html=1&skip_disambig=1")?.let { raw ->
            try {
                val j = JSONObject(raw)
                val abs = j.optString("AbstractText")
                if (abs.isNotBlank()) out.add(SearchHit(j.optString("Heading").ifBlank { query }, abs.take(900), j.optString("AbstractURL")))
            } catch (e: Exception) { }
        }
        PublicHttp.get("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${PublicHttp.enc(query)}&srlimit=2&format=json&utf8=1")?.let { raw ->
            try {
                val arr = JSONObject(raw).getJSONObject("query").getJSONArray("search")
                for (i in 0 until arr.length()) {
                    val title = arr.getJSONObject(i).getString("title")
                    val ex = PublicHttp.get("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&exchars=700&redirects=1&format=json&titles=${PublicHttp.enc(title)}")
                    val pages = ex?.let { JSONObject(it).getJSONObject("query").getJSONObject("pages") }
                    val page = pages?.keys()?.asSequence()?.firstOrNull()?.let { pages.getJSONObject(it) }
                    val text = page?.optString("extract").orEmpty()
                    if (text.isNotBlank() && out.none { it.title.equals(title, true) })
                        out.add(SearchHit(title, text, "https://en.wikipedia.org/wiki/" + PublicHttp.enc(title.replace(' ', '_'))))
                }
            } catch (e: Exception) { }
        }
        return out
    }
}

/** Headlines from public RSS feeds (Google News and BBC). Only titles and links are used; articles are not fetched. */
class RssNewsProvider : NewsProvider {
    override suspend fun headlines(topic: String?, count: Int): List<NewsItem> {
        val t = topic?.trim().orEmpty()
        val feeds = ArrayList<String>()
        feeds.add(if (t.isBlank() || t == "top headlines") "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en"
                  else "https://news.google.com/rss/search?q=${PublicHttp.enc(t)}&hl=en-IN&gl=IN&ceid=IN:en")
        if (t.isBlank() || t == "top headlines") feeds.add("https://feeds.bbci.co.uk/news/rss.xml")
        for (url in feeds) {
            val items = parse(PublicHttp.get(url) ?: continue, count)
            if (items.isNotEmpty()) return items
        }
        return emptyList()
    }

    private fun parse(xml: String, max: Int): List<NewsItem> {
        val out = ArrayList<NewsItem>()
        try {
            val p = Xml.newPullParser()
            p.setInput(xml.reader())
            var inItem = false
            var title = ""; var link = ""; var src = ""
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && out.size < max) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "item" -> { inItem = true; title = ""; link = ""; src = "" }
                        "title" -> if (inItem) title = p.nextText().trim()
                        "link" -> if (inItem) link = p.nextText().trim()
                        "source" -> if (inItem) src = p.nextText().trim()
                    }
                    XmlPullParser.END_TAG -> if (p.name == "item") {
                        inItem = false
                        if (title.isNotBlank()) {
                            // Google News appends " - Publisher" to titles.
                            val cut = title.lastIndexOf(" - ")
                            val s = if (src.isNotBlank()) src else if (cut > 0) title.substring(cut + 3) else ""
                            out.add(NewsItem(if (cut > 0) title.substring(0, cut) else title, s, link))
                        }
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) { }
        return out
    }
}
