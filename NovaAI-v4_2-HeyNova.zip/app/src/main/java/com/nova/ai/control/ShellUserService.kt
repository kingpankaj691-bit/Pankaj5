package com.nova.ai.control

import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Runs inside the Shizuku-started process (shell or root uid, whichever Shizuku was started with).
 * Re-checks every command with [ShellPolicy]; refuses anything that is not allow-listed.
 */
class ShellUserService : IShellService.Stub() {
    override fun destroy() { System.exit(0) }

    override fun exec(command: String, timeoutMs: Int): String {
        val d = ShellPolicy.validate(command)
        if (d is ShellPolicy.Decision.Deny) return "126\u0001\u0001blocked: ${d.reason}"
        return try {
            val p = ProcessBuilder("sh", "-c", command).start()
            val out = StringBuilder(); val err = StringBuilder()
            val to = thread { p.inputStream.bufferedReader().useLines { l -> l.forEach { if (out.length < 65_536) out.append(it).append('\n') } } }
            val te = thread { p.errorStream.bufferedReader().useLines { l -> l.forEach { if (err.length < 8_192) err.append(it).append('\n') } } }
            val finished = p.waitFor(timeoutMs.toLong().coerceIn(500, 30_000), TimeUnit.MILLISECONDS)
            if (!finished) { p.destroyForcibly(); return "124\u0001\u0001timed out" }
            to.join(1000); te.join(1000)
            "${p.exitValue()}\u0001${out}\u0001${err}"
        } catch (e: Exception) { "127\u0001\u0001${e.message}" }
    }
}
