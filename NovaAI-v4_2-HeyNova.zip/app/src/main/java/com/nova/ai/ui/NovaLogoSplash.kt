package com.nova.ai.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nova.ai.R
import com.nova.ai.fx.SplashSession
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * In-app splash: the Nova logo (orbit version, black background like the artwork) fades and eases in once per process, then
 * fades out (~1.8 s, 0.5 s with Reduced Motion). Tap to skip. It continues the Android 12+ system splash seamlessly.
 */
@Composable
fun NovaLogoSplash(onFinished: () -> Unit) {
    if (SplashSession.played) { LaunchedEffect(Unit) { onFinished() }; return }
    val reduced = LocalGlass.current.reduced
    val bg = remember { Animatable(1f) }
    val logo = remember { Animatable(if (reduced) 1f else 0f) }
    val scale = remember { Animatable(if (reduced) 1f else 0.92f) }
    LaunchedEffect(Unit) {
        if (reduced) delay(500)
        else {
            coroutineScope {
                launch { logo.animateTo(1f, tween(700)) }
                launch { scale.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
            }
            delay(700)
        }
        bg.animateTo(0f, tween(if (reduced) 1 else 350))
        SplashSession.played = true
        onFinished()
    }
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = bg.value }
            .drawBehind { drawRect(Color.Black) }
            .pointerInput(Unit) { detectTapGestures { SplashSession.played = true; onFinished() } }
            .semantics { contentDescription = "Nova. Your Voice. My World. Tap to skip." },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painterResource(R.drawable.nova_logo_splash), contentDescription = null,
            modifier = Modifier.fillMaxWidth(0.84f).widthIn(max = 440.dp).aspectRatio(1f)          // square artwork: never stretched
                .graphicsLayer { alpha = logo.value; scaleX = scale.value; scaleY = scale.value },
            contentScale = ContentScale.Fit
        )
    }
}
