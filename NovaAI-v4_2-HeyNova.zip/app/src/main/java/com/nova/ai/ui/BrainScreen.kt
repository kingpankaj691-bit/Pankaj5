package com.nova.ai.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.FragmentActivity
import com.nova.ai.brain.BrainCategory
import com.nova.ai.brain.BrainItem
import com.nova.ai.brain.FileRec
import com.nova.ai.brain.ProjectFiles
import com.nova.ai.brain.ReminderRec
import com.nova.ai.brain.Status
import com.nova.ai.brain.TopicEngine
import com.nova.ai.brain.VaultKind
import com.nova.ai.security.SecurityGate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Memory Dashboard: everything the permanent memory holds, with full control. Eight tabs: Overview, Memories, Topics, Projects,
 * Tasks, Reminders, Vault, Backup. Slow work (folder indexing, backups) runs off the main thread.
 */
@Composable
fun BrainScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val brain = vm.brain
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    var tab by rememberSaveable { mutableStateOf("Overview") }
    var msg by remember { mutableStateOf("") }
    val df = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
    fun bump() { rev++ }
    fun fmt(ms: Long) = if (ms <= 0) "never" else df.format(Date(ms))

    SubPage("Memory Dashboard", onBack) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Overview", "Memories", "Topics", "Projects", "Tasks", "Reminders", "Vault", "Backup").forEach { GlassChip(it, tab == it, { tab = it; msg = "" }) }
        }
        if (msg.isNotBlank()) GText(msg, size = 12.sp, color = g.subtext)
        when (tab) {
            "Overview" -> OverviewTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Memories" -> MemoriesTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Topics" -> TopicsTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Projects" -> ProjectsTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Tasks" -> TasksTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Reminders" -> RemindersTab(vm, rev, ::bump, ::fmt) { msg = it }
            "Vault" -> VaultTab(vm, rev, ::bump) { msg = it }
            else -> BackupTab(vm, rev, ::bump) { msg = it }
        }
    }
}

// ───────────────────────── Overview ─────────────────────────
@Composable
private fun OverviewTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val g = LocalGlass.current
    val st = remember(rev) { brain.status() }
    val items = remember(rev) { brain.memory.all() }
    var on by remember(rev) { mutableStateOf(brain.enabled) }
    var wipe by remember { mutableStateOf(false) }
    val c = st.counts
    fun n(vararg cs: BrainCategory) = cs.sumOf { c[it] ?: 0 }
    GlassSettingSection("Memory") {
        ToggleRow("Enable memory", "Turns the whole memory (old and new) on or off. Nothing is sent anywhere by this switch.", on) { on = it; brain.setEnabled(it); bump() }
        ToggleRow("Save automatically", "Off = Nova saves only when you say \"ise yaad rakhna\" or add something here.", brain.autoSave) { brain.autoSave = it; bump() }
        ToggleRow("Show a note when something is saved", "A small \"saved\" line in the chat, so nothing is stored silently.", brain.showNotices) { brain.showNotices = it; bump() }
        ToggleRow("Ask before saving personal information", "Contact details, health, money, family and similar: Nova asks yes/no first.", brain.confirmSensitive) { brain.confirmSensitive = it; bump() }
    }
    GlassSettingSection("What is stored") {
        GlassListItem("Personal memories", "${n(BrainCategory.PERSONAL, BrainCategory.CUSTOM, BrainCategory.NOTE)}")
        GlassListItem("Conversation memories", "${n(BrainCategory.IMPORTANT_CONVERSATION)} saved · ${st.turns} messages in the log")
        GlassListItem("Topic memories", "${st.topics} topics")
        GlassListItem("Project memories", "${st.projects} projects · ${n(BrainCategory.PROJECT)} project entries")
        GlassListItem("File references", "${st.files} indexed files")
        GlassListItem("Preferences", "${n(BrainCategory.PREFERENCE, BrainCategory.LIKE_DISLIKE, BrainCategory.INSTRUCTION)}")
        GlassListItem("Pending tasks", "${items.count { it.category == BrainCategory.TASK && it.status != Status.DONE }}")
        GlassListItem("Reminders", "${st.reminders}")
        GlassListItem("Secure Vault", if (st.vault == 0) "empty · protected by the Android Keystore" else "${st.vault} encrypted records · protected by the Android Keystore")
        GlassListItem("Last memory write", fmt(st.lastWrite))
        GlassListItem("Last automatic snapshot", fmt(st.lastSnapshot))
        GlassListItem("Storage used", "%.1f KB".format(st.storageBytes / 1024.0))
        GlassListItem("Database integrity", if (st.integrityOk) "OK" else "Problem found")
        if (st.lastError.isNotBlank()) GText(st.lastError, size = 12.sp, color = g.subtext)
        if (brain.recoveryNote().isNotBlank()) GText(brain.recoveryNote(), size = 12.sp, color = g.subtext)
    }
    val sug = remember(rev) { brain.pendingSuggestions() }
    if (sug.isNotEmpty()) GlassSettingSection("Waiting for your OK") {
        GText("Heard in voice conversations. Nova needs your yes before saving personal information.", size = 12.sp, color = g.subtext)
        sug.forEachIndexed { i, s ->
            GText("• ${s.content}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Save", { say(brain.approveSuggestion(i) ?: "Saved"); bump() }, primary = true)
                GlassButton("Don't save", { brain.rejectSuggestion(i); bump() })
            }
        }
    }
    val prof = remember(rev) { brain.profile.fields() }
    GlassSettingSection("What Nova knows about how you like things") {
        if (prof.isEmpty()) GText("Nothing yet. Only things you say yourself are added here, never guesses.", size = 12.sp, color = g.subtext)
        prof.forEach { (k, v) -> GlassListItem(com.nova.ai.brain.ProfileService.LABELS[k] ?: k, v) }
        if (prof.isNotEmpty()) GlassButton("Clear profile", { brain.profile.clear(); bump() }, Modifier.fillMaxWidth())
    }
    GlassSettingSection("Danger zone") {
        GText("Deletes memories, topics, conversation log, projects, file index and reminders. The Secure Vault is not touched. A backup is not deleted.", size = 12.sp, color = g.subtext)
        GlassButton("Delete all memory", { wipe = true }, Modifier.fillMaxWidth())
    }
    if (wipe) GlassDialog({ wipe = false }, "Delete all memory?", "Delete everything", { brain.wipeMemory(); say("All memory deleted."); bump() }) { GText("This cannot be undone. Export a backup first if you may want it back.") }
}

// ───────────────────────── Memories ─────────────────────────
@Composable
private fun MemoriesTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val g = LocalGlass.current
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<BrainCategory?>(null) }
    var add by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<BrainItem?>(null) }
    var editText by remember { mutableStateOf("") }
    var clearCat by remember { mutableStateOf(false) }
    var hist by remember { mutableStateOf<BrainItem?>(null) }
    val all = remember(rev) { brain.memory.all() }
    val shown = remember(rev, q, cat) {
        val base = all.filter { cat == null || it.category == cat }
        if (q.isBlank()) base else com.nova.ai.brain.Retrieval.search(base, com.nova.ai.brain.RetrievalQuery(q), System.currentTimeMillis(), 50).map { it.item }
    }
    GlassSettingSection("Add a memory") {
        GlassTextField(add, { add = it }, Modifier.fillMaxWidth(), placeholder = "Something Nova should remember", singleLine = false, minLines = 2)
        GlassButton("Save memory", { if (add.isNotBlank()) { say(brain.addNote(add)); add = ""; bump() } }, Modifier.fillMaxWidth(), primary = true)
        GText("Passwords, PINs, OTPs, card numbers and keys are refused here. Use the Vault tab for those.", size = 11.sp, color = g.subtext)
    }
    GlassTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = "Search memory")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassChip("All (${all.size})", cat == null, { cat = null })
        BrainCategory.values().forEach { c -> GlassChip("${c.label} (${all.count { it.category == c }})", cat == c, { cat = c }) }
    }
    if (cat != null && shown.isNotEmpty()) GlassButton("Clear all in \"${cat!!.label}\"", { clearCat = true }, Modifier.fillMaxWidth())
    if (shown.isEmpty()) GText("Nothing here yet.", color = g.subtext)
    shown.take(80).forEach { it0 ->
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(it0.content, weight = FontWeight.Medium)
                GText(it0.category.label + (if (it0.project.isNotBlank()) " · ${it0.project}" else "") + (if (it0.status.isNotBlank()) " · ${it0.status.lowercase()}" else "") +
                    (if (it0.dueAt > 0) " · due ${fmt(it0.dueAt)}" else "") + " · v${it0.version} · ${fmt(it0.updatedAt)}", size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassButton("Edit", { edit = it0; editText = it0.content })
                    GlassButton(if (it0.pinned) "Unpin" else "Pin", { brain.memory.setPinned(it0.id, !it0.pinned); bump() })
                    if (it0.version > 1) GlassButton("History", { hist = it0 })
                    GlassButton("Delete", { brain.deleteItem(it0.id); bump() })
                }
            }
        }
    }
    edit?.let { e -> GlassDialog({ edit = null }, "Edit memory", "Save", { say(if (brain.memory.update(e.id, editText) != null) "Updated." else "Not saved (looks private)."); bump() }) {
        GlassTextField(editText, { editText = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
    } }
    hist?.let { h -> GlassDialog({ hist = null }, "Earlier versions") {
        val v = remember(h.id) { vm.brain.store.versions(h.id) }
        if (v.isEmpty()) GText("No earlier versions.")
        v.forEach { GText("v${it.first}: ${it.second}", size = 13.sp) }
    } }
    if (clearCat) GlassDialog({ clearCat = false }, "Clear \"${cat?.label}\"?", "Clear", { cat?.let { brain.clearCategory(it) }; bump() }) { GText("All memories in this category are deleted.") }
}

// ───────────────────────── Topics ─────────────────────────
@Composable
private fun TopicsTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val g = LocalGlass.current
    val topics = remember(rev) { brain.topics.history() }
    val active = remember(rev) { brain.topics.activeId() }
    val log = remember(rev) { brain.topics.transitions().takeLast(8).reversed() }
    GText("Nova keeps the current topic until you change it. Earlier topics stay saved so you can go back to them.", size = 12.sp, color = g.subtext)
    if (topics.isEmpty()) GText("No topics yet.", color = g.subtext)
    topics.take(40).forEach { t ->
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(t.title + if (t.id == active) "  ● current" else "", weight = FontWeight.SemiBold)
                GText(brain.topics.recap(t, true), size = 12.sp, color = g.subtext)
                GText("${t.status.lowercase()} · ${fmt(t.updatedAt)}", size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (t.id != active) GlassButton("Continue this", { brain.topics.resume(t.id, System.currentTimeMillis()); say("Back to: ${t.title}"); bump() }, primary = true)
                    GlassButton("Mark finished", { brain.topics.markDone(t.id, System.currentTimeMillis()); bump() })
                    GlassButton("Delete", { if (t.id == active) brain.topics.markDone(t.id, System.currentTimeMillis()); brain.store.deleteTopic(t.id); bump() })
                }
            }
        }
    }
    if (log.isNotEmpty()) GlassSettingSection("Recent topic changes") {
        log.forEach { line ->
            val p = line.split('|')
            if (p.size >= 4) GText("${fmt(p[0].toLongOrNull() ?: 0L)} · ${p[3]}", size = 12.sp, color = g.subtext)
        }
    }
}

// ───────────────────────── Projects and files ─────────────────────────
@Composable
private fun ProjectsTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var fq by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<Pair<FileRec, String>?>(null) }
    val projects = remember(rev) { brain.store.projects() }
    val files = remember(rev) { brain.store.files() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            val label = name.ifBlank { (uri.lastPathSegment ?: "Project").substringAfterLast(':').substringAfterLast('/').ifBlank { "Project" } }
            busy = true; say("Indexing…")
            scope.launch {
                val r = withContext(Dispatchers.IO) { brain.addProjectFolder(uri, label)?.let { brain.reindex(it.id) } }
                busy = false; name = ""
                say(if (r == null) "Could not add the folder." else if (r.error.isNotBlank()) r.error else "Indexed ${r.total} files (${r.added} new, ${r.changed} changed, ${r.removed} removed)" + if (r.truncated) ". Stopped at the size limit." else ".")
                bump()
            }
        }
    }
    GlassSettingSection("Add a project folder") {
        GText("Pick a folder with the Android folder picker. Nova reads only that folder: file names, sizes, dates and code words. Contents are read again from the phone only when needed.", size = 12.sp, color = g.subtext)
        GlassTextField(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Project name (optional)")
        GlassButton(if (busy) "Working…" else "Choose folder", { picker.launch(null) }, Modifier.fillMaxWidth(), primary = true, enabled = !busy)
    }
    if (projects.isEmpty()) GText("No projects yet. Say \"main ... project par kaam kar raha hoon\" or add a folder.", color = g.subtext)
    projects.forEach { p ->
        val pf = files.filter { it.projectId == p.id }
        val open = brain.memory.pendingTasks(p.name).size
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(p.name, weight = FontWeight.SemiBold)
                GText("${p.status.lowercase()}" + (if (p.version.isNotBlank()) " · latest known version ${p.version}" else "") + " · ${pf.size} files · $open pending · indexed ${fmt(p.lastIndexedAt)}", size = 12.sp, color = g.subtext)
                if (pf.isNotEmpty()) GText("Structure: " + ProjectFiles.structure(pf), size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Status.ONGOING to "Ongoing", Status.PENDING to "On hold", Status.DONE to "Done").forEach { (s, l) -> GlassChip(l, p.status == s, { brain.setProjectStatus(p.id, s); bump() }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (p.rootUri.isNotBlank()) GlassButton("Re-index", { busy = true; scope.launch { val r = withContext(Dispatchers.IO) { brain.reindex(p.id) }; busy = false; say(if (r.error.isNotBlank()) r.error else "Indexed ${r.total} files (${r.added} new, ${r.changed} changed, ${r.removed} removed)."); bump() } }, enabled = !busy)
                    GlassButton("Remove", { brain.deleteProject(p.id); bump() })
                }
            }
        }
    }
    if (files.isNotEmpty()) {
        GlassSettingSection("Find a file") {
            GlassTextField(fq, { fq = it }, Modifier.fillMaxWidth(), placeholder = "e.g. voice engine code")
            val hits = remember(fq, rev) { if (fq.isBlank()) emptyList() else ProjectFiles.search(files, fq, 10) }
            hits.forEach { (f, _) ->
                GlassListItem(f.relPath, projects.firstOrNull { it.id == f.projectId }?.name.orEmpty(), onClick = {
                    scope.launch { val t = withContext(Dispatchers.IO) { brain.readFile(f) }; preview = f to (t ?: "This file is no longer available or could not be read.") }
                })
            }
            if (fq.isNotBlank() && hits.isEmpty()) GText("No indexed file matches. Nova never guesses file names.", size = 12.sp, color = g.subtext)
        }
    }
    preview?.let { (f, t) -> GlassDialog({ preview = null }, f.name) { GText(t, size = 12.sp) } }
}

// ───────────────────────── Tasks ─────────────────────────
@Composable
private fun TasksTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val g = LocalGlass.current
    val tasks = remember(rev) { brain.memory.pendingTasks() }
    val done = remember(rev) { brain.memory.byCategory(BrainCategory.TASK).filter { it.status == Status.DONE }.take(10) }
    val asked = remember(rev) { brain.topics.active()?.unanswered?.lines()?.filter { it.isNotBlank() } ?: emptyList() }
    GText("A task is marked done only when you tell Nova or tap Done here. Nova never decides a task is finished.", size = 12.sp, color = g.subtext)
    if (tasks.isEmpty()) GText("No pending tasks.", color = g.subtext)
    tasks.forEach { t ->
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(t.content, weight = FontWeight.Medium)
                GText((if (t.project.isNotBlank()) "${t.project} · " else "") + t.status.lowercase().ifBlank { "pending" } + (if (t.dueAt > 0) " · due ${fmt(t.dueAt)}" else ""), size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GlassButton("Done", { brain.memory.setStatus(t.id, Status.DONE); bump() }, primary = true)
                    GlassButton("Postpone", { brain.memory.setStatus(t.id, Status.POSTPONED); bump() })
                    GlassButton("Remind me", { val at = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, 1); set(java.util.Calendar.HOUR_OF_DAY, brain.reminderHour); set(java.util.Calendar.MINUTE, 0) }.timeInMillis
                        brain.createReminder(t.title, if (t.dueAt > System.currentTimeMillis()) t.dueAt else at, 0, t.id); say("Reminder set."); bump() })
                }
            }
        }
    }
    if (asked.isNotEmpty()) GlassSettingSection("Open questions in the current topic") { asked.forEach { GText("• " + it.removePrefix("A:").removePrefix("U:"), size = 13.sp) } }
    if (done.isNotEmpty()) GlassSettingSection("Recently done") { done.forEach { GText("✓ " + it.content, size = 13.sp, color = g.subtext) } }
}

// ───────────────────────── Reminders ─────────────────────────
@Composable
private fun RemindersTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, fmt: (Long) -> String, say: (String) -> Unit) {
    val brain = vm.brain
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var text by remember { mutableStateOf("") }
    var when_ by remember { mutableStateOf("hour") }
    var repeat by remember { mutableStateOf(0L) }
    var hour by remember(rev) { mutableIntStateOf(brain.reminderHour) }
    val list = remember(rev) { brain.store.reminders() }
    if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) GText("Notifications are off for Nova, so reminders cannot be shown. Turn them on in Android settings.", size = 12.sp, color = g.subtext)
    GlassSettingSection("New reminder") {
        GlassTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = "Reminder text")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("hour" to "In 1 hour", "evening" to "This evening", "tomorrow" to "Tomorrow at $hour:00").forEach { (k, l) -> GlassChip(l, when_ == k, { when_ = k }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0L to "Once", 86_400_000L to "Daily", 7 * 86_400_000L to "Weekly").forEach { (k, l) -> GlassChip(l, repeat == k, { repeat = k }) }
        }
        GlassButton("Set reminder", {
            if (text.isNotBlank()) {
                val c = java.util.Calendar.getInstance()
                when (when_) { "hour" -> c.add(java.util.Calendar.HOUR_OF_DAY, 1); "evening" -> { c.set(java.util.Calendar.HOUR_OF_DAY, 19); c.set(java.util.Calendar.MINUTE, 0); if (c.timeInMillis < System.currentTimeMillis()) c.add(java.util.Calendar.DAY_OF_YEAR, 1) }
                    else -> { c.add(java.util.Calendar.DAY_OF_YEAR, 1); c.set(java.util.Calendar.HOUR_OF_DAY, hour); c.set(java.util.Calendar.MINUTE, 0) } }
                brain.createReminder(text.trim(), c.timeInMillis, repeat); say("Reminder set for ${fmt(c.timeInMillis)}. Android may deliver it a few minutes late."); text = ""; bump()
            }
        }, Modifier.fillMaxWidth(), primary = true)
    }
    GlassSettingSection("Reminder settings") {
        GText("Default time for \"tomorrow\" reminders", size = 12.sp, color = g.subtext)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 8, 9, 12, 18, 20).forEach { h -> GlassChip("$h:00", hour == h, { hour = h; brain.reminderHour = h }) }
        }
        ToggleRow("Remind me automatically about tasks with a date", "When you say a task is due tomorrow, Nova sets a reminder. Off by default.", brain.autoReminder) { brain.autoReminder = it; bump() }
    }
    if (list.isEmpty()) GText("No reminders.", color = g.subtext)
    list.forEach { r: ReminderRec ->
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GText(r.title, weight = FontWeight.Medium)
                GText(fmt(r.fireAt) + when (r.repeatMs) { 0L -> " · once"; 86_400_000L -> " · daily"; else -> " · weekly" } + if (r.enabled) "" else " · off", size = 11.sp, color = g.subtext)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton(if (r.enabled) "Turn off" else "Turn on", { brain.updateReminder(r.copy(enabled = !r.enabled, fireAt = if (!r.enabled && r.fireAt < System.currentTimeMillis()) System.currentTimeMillis() + 3_600_000L else r.fireAt)); bump() })
                    GlassButton("Delete", { brain.deleteReminder(r.id); bump() })
                }
            }
        }
    }
}

// ───────────────────────── Vault ─────────────────────────
@Composable
private fun VaultTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, say: (String) -> Unit) {
    val brain = vm.brain
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val act = ctx as? FragmentActivity
    var unlocked by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(VaultKind.NOTE) }
    var shown by remember { mutableStateOf<Pair<String, String>?>(null) }
    val canAuth = SecurityGate.canBiometric(ctx)
    val list = remember(rev, unlocked) { if (unlocked) brain.vault.list() else emptyList() }
    GlassSettingSection("Secure Personal Vault") {
        GText("For notes, documents and credentials you want kept safe. Everything is encrypted with a key held by the Android Keystore and shown only after fingerprint or screen lock. The vault is never sent to Gemini, never written to logs, and never shown in notifications. For real passwords a dedicated password manager is still the better choice.", size = 12.sp, color = g.subtext)
        GText("Records: ${brain.status().vault}", size = 13.sp)
        if (!unlocked) {
            if (!canAuth || act == null) GText("Set a fingerprint or screen lock on this phone to use the vault.", size = 12.sp, color = g.subtext)
            else GlassButton("Unlock with fingerprint / screen lock", { SecurityGate.prompt(act, "Open the Secure Vault") { ok -> unlocked = ok; if (!ok) say("Not unlocked.") } }, Modifier.fillMaxWidth(), primary = true)
        } else GlassButton("Lock the vault", { unlocked = false; shown = null }, Modifier.fillMaxWidth())
    }
    if (unlocked) {
        GlassSettingSection("Add a record") {
            GlassTextField(label, { label = it }, Modifier.fillMaxWidth(), placeholder = "Name (not the secret itself)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { VaultKind.values().forEach { k -> GlassChip(k.label, kind == k, { kind = k }) } }
            GlassTextField(secret, { secret = it }, Modifier.fillMaxWidth(), placeholder = "Secret or text to protect", singleLine = false, minLines = 3, visual = PasswordVisualTransformation())
            GlassButton("Encrypt and save", {
                try { brain.vault.add(label, kind, secret); label = ""; secret = ""; say("Saved in the vault."); bump() } catch (e: Exception) { say(e.message ?: "Could not save.") }
            }, Modifier.fillMaxWidth(), primary = true)
        }
        list.forEach { r ->
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GText(r.label, weight = FontWeight.Medium)
                    GText(r.kind.label, size = 11.sp, color = g.subtext)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Show", { try { shown = r.label to brain.vault.reveal(r.id) } catch (e: Exception) { say("Could not decrypt this record (the Keystore key may have changed).") } })
                        GlassButton("Delete", { brain.vault.delete(r.id); bump() })
                    }
                }
            }
        }
    }
    shown?.let { (l, s) -> GlassDialog({ shown = null }, l) { GText(s) } }
}

// ───────────────────────── Backup ─────────────────────────
@Composable
private fun BackupTab(vm: NovaViewModel, rev: Int, bump: () -> Unit, say: (String) -> Unit) {
    val brain = vm.brain
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    val act = ctx as? FragmentActivity
    var pass by remember { mutableStateOf("") }
    var withVault by remember { mutableStateOf(false) }
    var replace by remember { mutableStateOf(false) }
    var outBytes by remember { mutableStateOf<ByteArray?>(null) }
    var inBytes by remember { mutableStateOf<ByteArray?>(null) }
    var confirmImport by remember { mutableStateOf<String?>(null) }
    val stamp = remember { SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val bytes = outBytes
        if (uri != null && bytes != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }; true } catch (e: Exception) { false } }
            say(if (ok) "Backup saved." else "Could not write the file.")
        }
        outBytes = null
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { try { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } } catch (e: Exception) { null } }
            if (b == null) { say("Could not read the file."); return@launch }
            val v = withContext(Dispatchers.IO) { brain.verifyBytes(b, pass.toCharArray().takeIf { it.isNotEmpty() }) }
            if (v.ok) { inBytes = b; confirmImport = "Valid backup: " + v.counts.entries.joinToString(", ") { "${it.value} ${it.key}" } } else { inBytes = null; say(v.message) }
        }
    }

    GlassSettingSection("Export") {
        GText("An encrypted backup is protected by your passphrase (AES-256). Keep the passphrase safe: without it the backup cannot be opened, and Nova cannot recover it.", size = 12.sp, color = g.subtext)
        GlassTextField(pass, { pass = it }, Modifier.fillMaxWidth(), placeholder = "Passphrase (at least 8 characters)", visual = PasswordVisualTransformation())
        ToggleRow("Include the Secure Vault", "Needs a passphrase. Vault records are decrypted only inside the encrypted backup.", withVault) { withVault = it }
        GlassButton("Export encrypted backup", {
            if (pass.length < 8) { say("Use a passphrase of at least 8 characters.") }
            else if (withVault && act != null) SecurityGate.prompt(act, "Include the vault in a backup") { ok ->
                if (ok) scope.launch { outBytes = withContext(Dispatchers.IO) { brain.exportBytes(pass.toCharArray(), true) }; saver.launch("nova-memory-$stamp.nbk") } else say("Not authenticated.")
            } else scope.launch { outBytes = withContext(Dispatchers.IO) { brain.exportBytes(pass.toCharArray(), false) }; saver.launch("nova-memory-$stamp.nbk") }
        }, Modifier.fillMaxWidth(), primary = true)
        GlassButton("Export plain JSON (no vault, not encrypted)", { scope.launch { outBytes = withContext(Dispatchers.IO) { brain.exportBytes(null, false) }; saver.launch("nova-memory-$stamp.json") } }, Modifier.fillMaxWidth())
    }
    GlassSettingSection("Import") {
        GText("Enter the passphrase above first if the backup is encrypted. Nova checks the file before changing anything.", size = 12.sp, color = g.subtext)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Merge (keep what I have)", !replace, { replace = false })
            GlassChip("Replace", replace, { replace = true })
        }
        GlassButton("Choose backup file", { opener.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), primary = true)
    }
    GlassSettingSection("Safety copies") {
        val st = remember(rev) { brain.status() }
        GText("Nova keeps the three newest encrypted snapshots inside the app and uses them to repair a damaged database. Snapshots do not include the vault. They do not survive uninstalling Nova: use an exported backup for a new phone.", size = 12.sp, color = g.subtext)
        GlassListItem("Database integrity", if (st.integrityOk) "OK" else "Problem found")
        GlassButton("Create a snapshot now", { scope.launch { withContext(Dispatchers.IO) { brain.autoSnapshot() }; say("Snapshot created."); bump() } }, Modifier.fillMaxWidth())
    }
    confirmImport?.let { info ->
        GlassDialog({ confirmImport = null }, "Import this backup?", "Import", {
            val b = inBytes
            if (b != null) scope.launch {
                val r = withContext(Dispatchers.IO) { try { brain.importBytes(b, pass.toCharArray().takeIf { it.isNotEmpty() }, replace) } catch (e: Exception) { null } }
                say(if (r == null) "Import failed. Nothing was changed." else "Imported: ${r.added} added, ${r.merged} already present" + if (r.vault > 0) ", ${r.vault} vault records." else ".")
                bump()
            }
        }) { GText(info + "\n" + (if (replace) "Replace: current memory is deleted first (a safety snapshot is made)." else "Merge: duplicates are skipped.")) }
    }
}
