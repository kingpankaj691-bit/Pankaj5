package com.nova.ai.ai.net

import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import javax.net.ssl.SSLException

/**
 * Every way a Gemini call can fail, with whether trying again can possibly help.
 * Permanent configuration problems (bad key, unknown model, unsupported request) are never retried as if they were network errors.
 */
enum class GeminiErrorKind(val retryable: Boolean) {
    NO_KEY(false),
    INVALID_KEY(false),         // 401
    PERMISSION(false),          // 403
    MODEL_NOT_FOUND(false),     // 404
    MODEL_UNSUPPORTED(false),   // model cannot do what was asked (modality, method)
    BAD_REQUEST(false),         // 400
    RATE_LIMIT(true),           // 429 with a short wait
    QUOTA_EXHAUSTED(false),     // 429 daily/plan quota
    SERVER(true),               // 500 / 502 / 503 / 504
    CONNECT_TIMEOUT(true),      // could not open a connection
    RESPONSE_TIMEOUT(true),     // connected, but no answer in time
    NO_NETWORK(true),
    NETWORK(true),
    CANCELLED(false),
    BLOCKED(false),             // safety / policy block
    EMPTY(false),
    UNKNOWN(false)
}

data class GeminiError(
    val kind: GeminiErrorKind,
    val http: Int? = null,
    val detail: String = "",
    /** Server asked us to wait this long (Retry-After header or RetryInfo). */
    val retryAfterMs: Long? = null,
    val model: String? = null
) {
    val retryable: Boolean get() = kind.retryable

    fun userMessage(modelOverride: String? = null): String {
        val id = modelOverride ?: model
        val m = if (id.isNullOrBlank()) "the selected model" else "'$id'"
        val d = if (detail.isBlank()) "" else " ($detail)"
        val code = http?.let { " (HTTP $it)" } ?: ""
        return when (kind) {
            GeminiErrorKind.NO_KEY -> "No Gemini API key is set. Add one in Settings → Gemini."
            GeminiErrorKind.INVALID_KEY -> "Gemini rejected your API key$code. Check or replace it in Settings → Gemini."
            GeminiErrorKind.PERMISSION -> "Gemini denied access$code. Your key may not be allowed to use $m, or Gemini is not available for your project or region.$d"
            GeminiErrorKind.MODEL_NOT_FOUND -> "$m is not available for your API key$code. It may have been retired or renamed. " +
                "Open Settings → Gemini → Model, refresh the list and choose another model."
            GeminiErrorKind.MODEL_UNSUPPORTED -> "$m can't do this: ${detail.ifBlank { "the request is not supported by the model" }}. Choose another model in Settings → Gemini → Model."
            GeminiErrorKind.BAD_REQUEST -> "Gemini rejected the request$code.${if (detail.isBlank()) "" else " $detail"}"
            GeminiErrorKind.RATE_LIMIT -> "Gemini is rate-limiting requests$code." +
                (retryAfterMs?.let { " Try again in about ${(it + 999) / 1000} s." } ?: " Wait a moment and try again.")
            GeminiErrorKind.QUOTA_EXHAUSTED -> "Your Gemini quota for $m is used up$code. It resets later, or choose another model or API key in Settings → Gemini."
            GeminiErrorKind.SERVER -> "Gemini's servers had a problem$code. Nova already retried; try again shortly or choose another model."
            GeminiErrorKind.CONNECT_TIMEOUT -> "Could not connect to Google's Gemini servers (the connection timed out). Check your internet connection, VPN or firewall."
            GeminiErrorKind.RESPONSE_TIMEOUT -> "Connected to Gemini, but $m did not answer in time. The model may be busy or still thinking. " +
                "Try again, or choose a faster (Flash) model in Settings → Gemini → Model."
            GeminiErrorKind.NO_NETWORK -> "No internet connection. Local commands still work."
            GeminiErrorKind.NETWORK -> "Network problem while talking to Gemini.$d"
            GeminiErrorKind.CANCELLED -> "Cancelled."
            GeminiErrorKind.BLOCKED -> "Gemini blocked this answer$d. Try rephrasing."
            GeminiErrorKind.EMPTY -> "Gemini returned an empty answer$d."
            GeminiErrorKind.UNKNOWN -> "Unexpected Gemini error$code.${if (detail.isBlank()) "" else " $detail"}"
        }
    }
}

object GeminiErrors {
    private val keyLike = Regex("AIza[0-9A-Za-z_\\-]{20,}")

    /** Never lets an API key reach a message, a notification or a log. */
    fun redact(s: String): String = keyLike.replace(s, "[key]")

    /** Parses "Retry-After": whole seconds or an HTTP date. */
    fun parseRetryAfter(header: String?, nowMs: Long = System.currentTimeMillis()): Long? {
        val h = header?.trim().orEmpty()
        if (h.isEmpty()) return null
        h.toLongOrNull()?.let { return (it * 1000L).coerceAtLeast(0L) }
        return try {
            val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
            val t = f.parse(h)?.time ?: return null
            (t - nowMs).coerceAtLeast(0L)
        } catch (e: Exception) { null }
    }

    /** RetryInfo.retryDelay ("27s", "27.5s") from a Google error body. */
    fun retryDelayFromBody(body: String): Long? = try {
        val details = JSONObject(body).optJSONObject("error")?.optJSONArray("details")
        var out: Long? = null
        if (details != null) for (i in 0 until details.length()) {
            val d = details.optJSONObject(i) ?: continue
            if (d.optString("@type").endsWith("RetryInfo")) {
                val s = d.optString("retryDelay")
                val n = Regex("([0-9]+(?:\\.[0-9]+)?)s").find(s)?.groupValues?.get(1)?.toDoubleOrNull()
                if (n != null) out = (n * 1000).toLong()
            }
        }
        out
    } catch (e: Exception) { null }

    fun fromHttp(code: Int, body: String, retryAfterHeader: String?, model: String?, nowMs: Long = System.currentTimeMillis()): GeminiError {
        val err = try { JSONObject(body).optJSONObject("error") } catch (e: Exception) { null }
        val message = redact(err?.optString("message").orEmpty()).take(220)
        val lower = (message + " " + err?.optString("status").orEmpty()).lowercase()
        val retryAfter = parseRetryAfter(retryAfterHeader, nowMs) ?: retryDelayFromBody(body)
        return when {
            code == 401 -> GeminiError(GeminiErrorKind.INVALID_KEY, code, message, null, model)
            code == 403 -> GeminiError(GeminiErrorKind.PERMISSION, code, message, null, model)
            code == 404 -> GeminiError(GeminiErrorKind.MODEL_NOT_FOUND, code, message, null, model)
            code == 400 && ("api key not valid" in lower || "api_key_invalid" in lower || "api key expired" in lower) ->
                GeminiError(GeminiErrorKind.INVALID_KEY, code, message, null, model)
            code == 400 && ("modalit" in lower || "not supported" in lower || "unsupported" in lower) ->
                GeminiError(GeminiErrorKind.MODEL_UNSUPPORTED, code, message, null, model)
            code == 400 -> GeminiError(GeminiErrorKind.BAD_REQUEST, code, message, null, model)
            code == 429 -> {
                val daily = "perday" in lower.replace(" ", "") || "per day" in lower || body.contains("PerDay")
                if (daily) GeminiError(GeminiErrorKind.QUOTA_EXHAUSTED, code, message, retryAfter, model)
                else GeminiError(GeminiErrorKind.RATE_LIMIT, code, message, retryAfter, model)
            }
            code == 408 -> GeminiError(GeminiErrorKind.RESPONSE_TIMEOUT, code, message, retryAfter, model)
            code in 500..599 -> GeminiError(GeminiErrorKind.SERVER, code, message, retryAfter, model)
            else -> GeminiError(GeminiErrorKind.UNKNOWN, code, message, null, model)
        }
    }

    fun fromException(e: Throwable, model: String?, canceled: Boolean = false): GeminiError {
        val msg = redact(e.message.orEmpty())
        return when {
            canceled || (e is IOException && msg.equals("Canceled", true)) -> GeminiError(GeminiErrorKind.CANCELLED, null, "", null, model)
            e is SocketTimeoutException ->
                if (msg.contains("connect", true)) GeminiError(GeminiErrorKind.CONNECT_TIMEOUT, null, msg, null, model)
                else GeminiError(GeminiErrorKind.RESPONSE_TIMEOUT, null, msg, null, model)
            e is UnknownHostException -> GeminiError(GeminiErrorKind.NO_NETWORK, null, "DNS lookup failed", null, model)
            e is ConnectException || e is NoRouteToHostException ->
                GeminiError(GeminiErrorKind.CONNECT_TIMEOUT, null, "connection refused or unreachable", null, model)
            e is SSLException -> GeminiError(GeminiErrorKind.NETWORK, null, "secure connection failed: ${msg.take(80)}", null, model)
            e is IOException -> GeminiError(GeminiErrorKind.NETWORK, null, msg.take(100), null, model)
            else -> GeminiError(GeminiErrorKind.UNKNOWN, null, e.javaClass.simpleName, null, model)
        }
    }
}

/** Connect and response timeouts are separate so the user is told which one happened. */
object GeminiTimeouts {
    const val CONNECT_MS = 15_000L

    fun responseMs(modelId: String, maxTokens: Int): Long {
        val n = modelId.lowercase()
        var ms = when {
            n.contains("pro") -> 120_000L        // reasoning models can think for a long time before the first byte
            n.contains("lite") -> 40_000L
            else -> 60_000L
        }
        if (maxTokens > 4096) ms += 30_000L
        return ms
    }
}
