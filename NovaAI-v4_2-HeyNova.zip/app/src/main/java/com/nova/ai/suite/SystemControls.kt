package com.nova.ai.suite

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.provider.Settings

/**
 * Settings Android lets an app change (Do Not Disturb, with the user's "Do Not Disturb access" grant) and the closest legitimate
 * alternative for the rest (opens the exact system page). Nothing here changes Wi-Fi, Bluetooth, airplane mode or DNS silently.
 * Brightness and volume already live in DeviceController and are not duplicated.
 */
object SystemControls {
    private fun open(ctx: Context, action: String): String = try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
    } catch (e: Exception) { "" }

    fun dndAccessGranted(ctx: Context): Boolean =
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted

    fun dndOn(ctx: Context): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }

    /** Turns Do Not Disturb on (priority only) or off. If access isn't granted it opens the grant page and says so. */
    fun setDnd(ctx: Context, on: Boolean): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            open(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return "Do Not Disturb needs special access. I opened that page; switch on Nova AI, then ask again."
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Do Not Disturb is on (priority only)." else "Do Not Disturb is off."
    }

    /** Opens this app's "Display over other apps" page. */
    fun openOverlay(ctx: Context): String = try {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        "Allow Display over other apps for Nova AI, then ask again."
    } catch (e: Exception) { "Open Settings > Apps > Nova AI > Display over other apps." }

    fun openBluetooth(ctx: Context) = if (open(ctx, Settings.ACTION_BLUETOOTH_SETTINGS).isNotEmpty()) "Bluetooth settings khol di." else "I couldn't open Bluetooth settings."
    fun openWifi(ctx: Context) = if (open(ctx, Settings.ACTION_WIFI_SETTINGS).isNotEmpty()) "Wi-Fi settings khol di." else "I couldn't open Wi-Fi settings."
    fun openAirplane(ctx: Context) = if (open(ctx, Settings.ACTION_AIRPLANE_MODE_SETTINGS).isNotEmpty()) "Airplane mode settings khol di. Android doesn't let apps switch it themselves." else "I couldn't open airplane mode settings."
    fun openDisplay(ctx: Context) = if (open(ctx, Settings.ACTION_DISPLAY_SETTINGS).isNotEmpty()) "Display settings khol di." else "I couldn't open display settings."

    /** Android has no API or intent that jumps straight to Private DNS; this opens network settings (Network & internet > Private DNS). */
    fun openPrivateDns(ctx: Context): String {
        val ok = open(ctx, Settings.ACTION_WIRELESS_SETTINGS).isNotEmpty()
        return (if (ok) "Network settings khol di. " else "") +
            "Private DNS: Settings > Connections > More connection settings > Private DNS. Android only lets the user change it; Nova never changes it silently, " +
            "and a different DNS does not guarantee lower gaming ping."
    }

    fun networkInfo(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "No internet connection right now."
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "another network"
        }
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return "Connected over $kind, about ${caps.linkDownstreamBandwidthKbps / 1000} Mbps down / ${caps.linkUpstreamBandwidthKbps / 1000} Mbps up (Android's estimate), internet ${if (validated) "verified" else "not verified"}."
    }

    fun batteryInfo(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Battery $pct%" + if (charging) ", charging." else "."
    }
}
