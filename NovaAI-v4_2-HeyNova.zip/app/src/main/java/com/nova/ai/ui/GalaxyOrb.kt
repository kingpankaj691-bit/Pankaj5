package com.nova.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val ORB_TAU = (2.0 * PI).toFloat()
private const val RAD_TO_DEG = (180.0 / PI).toFloat()

/** What the Galaxy Orb is doing. Chosen from the real voice state in HomeScreen; never from a timer. */
enum class OrbMode { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

private val GalaxyCyan = Color(0xFF22D3EE)
private val GalaxyViolet = Color(0xFF8B5CF6)
private val GalaxyPurple = Color(0xFFC026D3)
private val GalaxyBlue = Color(0xFF2B4BFF)
private val GalaxyNavy = Color(0xFF0A1A4D)
private val GalaxyDeep = Color(0xFF050722)
private val GalaxyRed = Color(0xFFFF5A6E)

/** Fixed star field, built once. Position on a sphere (lon/lat), shell radius, dot size and colour mix. */
private class StarField(n: Int) {
    val lon = FloatArray(n); val lat = FloatArray(n); val shell = FloatArray(n); val size = FloatArray(n); val tone = FloatArray(n)
    init {
        val r = Random(20260209)
        for (i in 0 until n) {
            lon[i] = r.nextFloat() * ORB_TAU
            lat[i] = (r.nextFloat() * 2f - 1f) * 1.45f              // radians, slightly short of the poles
            shell[i] = 0.45f + r.nextFloat() * 0.52f
            size[i] = 0.7f + r.nextFloat() * 1.5f
            tone[i] = r.nextFloat()
        }
    }
}

/**
 * Premium 3D galaxy orb drawn with Compose Canvas (no bitmap): glass sphere, rotating particle sphere, drifting nebula,
 * glowing ring and energy core. [level] must return the REAL loudness 0..1 (microphone while listening, speaker while
 * speaking); the orb only reads it, it never invents motion. [lite] = reduced effects: fewer particles, no nebula layers, ~20 fps.
 * The animation loop only runs while the screen is visible (STARTED), so it costs nothing in the background.
 */
@Composable
fun GalaxyOrb(mode: OrbMode, level: () -> Float, modifier: Modifier = Modifier.size(256.dp), lite: Boolean = false, description: String = "Nova", emblem: ImageBitmap? = null) {
    val g = LocalGlass.current
    val slow = lite || g.reduced
    val stars = remember(slow) { StarField(if (slow) 28 else 84) }
    var angle by remember { mutableFloatStateOf(0f) }
    var ringAngle by remember { mutableFloatStateOf(0f) }
    var breath by remember { mutableFloatStateOf(0f) }
    var smooth by remember { mutableFloatStateOf(0f) }
    var core by remember { mutableFloatStateOf(0.25f) }
    val modeNow by rememberUpdatedState(mode)
    val levelNow by rememberUpdatedState(level)
    val owner = LocalLifecycleOwner.current

    LaunchedEffect(owner, slow) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            var last = 0L
            while (true) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                if (last == 0L) { last = now; continue }
                var dt = (now - last) / 1_000_000_000f
                if (slow && dt < 0.05f) continue                       // reduced effects: about 20 frames per second
                last = now
                dt = dt.coerceAtMost(0.1f)
                val m = modeNow
                val raw = if (m == OrbMode.LISTENING || m == OrbMode.SPEAKING) levelNow().coerceIn(0f, 1f) else 0f
                smooth += (raw - smooth) * (if (raw > smooth) 0.55f else 0.18f)
                val speed = when (m) {
                    OrbMode.IDLE -> 0.10f
                    OrbMode.LISTENING -> 0.20f + 0.55f * smooth
                    OrbMode.THINKING -> 0.95f
                    OrbMode.SPEAKING -> 0.28f + 0.45f * smooth
                    OrbMode.ERROR -> 0.04f
                }
                angle = (angle + dt * speed) % ORB_TAU
                ringAngle = (ringAngle + dt * (if (m == OrbMode.THINKING) 1.1f else 0.22f)) % ORB_TAU
                breath = (breath + dt * (if (m == OrbMode.THINKING) 3.0f else 1.05f)) % ORB_TAU
                val coreTarget = when (m) {
                    OrbMode.THINKING -> 0.80f + 0.20f * sin(breath)
                    OrbMode.SPEAKING -> 0.35f + 0.65f * smooth
                    OrbMode.LISTENING -> 0.25f + 0.45f * smooth
                    OrbMode.ERROR -> 0.08f
                    OrbMode.IDLE -> 0.22f + 0.06f * sin(breath)
                }
                core += (coreTarget - core) * 0.14f
            }
        }
    }

    Canvas(modifier.graphicsLayer { translationY = sin(breath * 0.7f) * 5.dp.toPx() }.semantics { contentDescription = description }) {   // slow floating
        drawGalaxy(modeNow, stars, angle, ringAngle, breath, smooth, core, slow, emblem)
    }
}

private fun DrawScope.drawGalaxy(m: OrbMode, stars: StarField, angle: Float, ringAngle: Float, breath: Float, lv: Float, core: Float, lite: Boolean, emblem: ImageBitmap?) {
    val px = density
    val c = center
    val br = sin(breath)
    val baseR = size.minDimension * 0.5f * 0.60f
    val scale = when (m) {
        OrbMode.LISTENING -> 1f + 0.12f * lv + 0.010f * br
        OrbMode.SPEAKING -> 1f + 0.10f * lv + 0.014f * br
        OrbMode.THINKING -> 1f + 0.022f * br
        OrbMode.ERROR -> 1f
        OrbMode.IDLE -> 1f + 0.018f * br
    }
    val r = baseR * scale
    val ringA = if (m == OrbMode.ERROR) GalaxyRed else GalaxyCyan
    val ringB = if (m == OrbMode.ERROR) Color(0xFFB0283C) else GalaxyViolet

    // 1. aura
    drawCircle(Brush.radialGradient(listOf(GalaxyViolet.a(0.30f + 0.28f * core), ringA.a(0.10f + 0.08f * core), Color.Transparent), c, r * 1.95f), r * 1.95f, c)

    // 1b. far half of the orbital rings (hidden behind the sphere)
    orbitRings(c, r, ringAngle, lv, core, px, lite, front = false, err = m == OrbMode.ERROR)

    // 2. sphere body
    drawCircle(Brush.radialGradient(listOf(GalaxyBlue.a(0.92f), GalaxyNavy, GalaxyDeep), c + Offset(-r * 0.25f, -r * 0.30f), r * 1.30f), r, c)

    val clip = Path().apply { addOval(Rect(c, r)) }
    clipPath(clip) {
        // 3. nebula (skipped in reduced-effects mode except two blobs)
        val blobs = if (lite) 2 else 4
        for (i in 0 until blobs) {
            val a = angle * (0.55f + i * 0.22f) + i * 1.7f
            val bc = c + Offset(cos(a) * r * 0.42f, sin(a) * r * 0.34f)
            val col = when (i % 4) { 0 -> GalaxyCyan; 1 -> GalaxyViolet; 2 -> GalaxyPurple; else -> GalaxyBlue }
            drawCircle(Brush.radialGradient(listOf(col.a(0.34f + 0.26f * lv), Color.Transparent), bc, r * 0.85f), r * 0.85f, bc)
        }
        // 4. galaxy disc: a tilted spiral band that turns with the particles
        if (!lite) {
            rotate(-22f, c) {
                rotate(angle * RAD_TO_DEG * 0.8f, c) {
                    drawOval(
                        Brush.sweepGradient(listOf(Color.Transparent, GalaxyCyan.a(0.32f), Color.Transparent, GalaxyPurple.a(0.34f), Color.Transparent), c),
                        topLeft = Offset(c.x - r * 0.98f, c.y - r * 0.30f), size = Size(r * 1.96f, r * 0.60f)
                    )
                }
            }
        }
        // 5. far side of the particle sphere, the core, then the near side (gives real depth)
        drawStars(stars, c, r, angle, lv, core, px, front = false)
        val coreR = r * (0.20f + 0.15f * core)
        drawCircle(Brush.radialGradient(listOf(Color.White.a(0.50f + 0.45f * core), ringA.a(0.55f * (0.4f + core)), GalaxyViolet.a(0.25f), Color.Transparent), c, coreR * 3.3f), coreR * 3.3f, c)
        drawCircle(Color.White.a(0.30f + 0.65f * core), coreR * 0.36f, c)
        drawStars(stars, c, r, angle, lv, core, px, front = true)

        // 6. glass: fresnel edge, inner shell, soft reflections
        drawCircle(Brush.radialGradient(0.60f to Color.Transparent, 0.90f to ringA.a(0.10f), 1f to Color.White.a(0.40f), center = c, radius = r), r, c)
        drawCircle(Brush.linearGradient(listOf(ringA.a(0.28f), Color.Transparent, GalaxyViolet.a(0.30f))), r * 0.90f, c, style = Stroke(1.2f * px))
        drawCircle(Color.White.a(0.05f), r * 0.80f, c, style = Stroke(r * 0.09f))
        drawOval(
            Brush.radialGradient(listOf(Color.White.a(0.55f), Color.Transparent), c + Offset(-r * 0.38f, -r * 0.55f), r * 0.60f),
            topLeft = c + Offset(-r * 0.78f, -r * 0.92f), size = Size(r * 0.90f, r * 0.50f)
        )
        drawArc(Color.White.a(0.18f), 20f, 50f, false, c - Offset(r * 0.90f, r * 0.90f), Size(r * 1.80f, r * 1.80f), style = Stroke(2f * px, cap = StrokeCap.Round))
    }

    // 6b. the Nova emblem floats in the middle of the orb
    emblem?.let { img ->
        val w = r * 1.30f * (1f + 0.05f * core)
        val h = w * img.height / img.width
        val bob = sin(breath * 0.7f) * r * 0.025f
        drawImage(
            img, dstOffset = IntOffset((c.x - w / 2f).toInt(), (c.y + bob - h / 2f).toInt()), dstSize = IntSize(w.toInt(), h.toInt()),
            alpha = if (m == OrbMode.ERROR) 0.55f else 0.97f, filterQuality = FilterQuality.Medium
        )
    }

    // 7. glowing outer ring (expands with the real audio level)
    val ringR = r * (1.13f + (if (m == OrbMode.LISTENING) 0.10f * lv else if (m == OrbMode.SPEAKING) 0.07f * lv else 0f))
    rotate(ringAngle * RAD_TO_DEG, c) {
        drawCircle(Brush.sweepGradient(listOf(ringA, GalaxyViolet.a(0.25f), ringB, GalaxyPurple.a(0.25f), ringA), c), ringR, c, style = Stroke(2.6f * px))
    }
    if (!lite) drawCircle(ringA.a(0.14f + 0.20f * core), ringR, c, style = Stroke(10f * px))

    // 7b. near half of the orbital rings
    orbitRings(c, r, ringAngle, lv, core, px, lite, front = true, err = m == OrbMode.ERROR)

    // 8. state accents
    when (m) {
        OrbMode.LISTENING -> if (!lite) for (i in 0..1) {
            val q = (ringAngle / ORB_TAU * 2f + i * 0.5f) % 1f
            drawCircle(GalaxyCyan.a((1f - q) * (0.18f + 0.40f * lv)), r * (1.22f + q * 0.38f), c, style = Stroke(2f * px))
        }
        OrbMode.THINKING -> rotate(-ringAngle * 0.6f * RAD_TO_DEG, c) {
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, Color.White.a(0.85f)), c), 0f, 140f, false,
                c - Offset(r * 1.30f, r * 1.30f), Size(r * 2.60f, r * 2.60f), style = Stroke(3f * px, cap = StrokeCap.Round)
            )
        }
        OrbMode.ERROR -> {
            val dot = c + Offset(r * 0.98f, -r * 0.98f)
            drawCircle(GalaxyRed.a(0.35f), 11f * px, dot)
            drawCircle(GalaxyRed, 5f * px, dot)
        }
        else -> Unit
    }
}

private fun DrawScope.drawStars(s: StarField, c: Offset, r: Float, angle: Float, lv: Float, core: Float, px: Float, front: Boolean) {
    val tilt = 0.45f
    val ct = cos(tilt); val st = sin(tilt)
    for (i in 0 until s.lon.size) {
        val lon = s.lon[i] + angle * (0.7f + s.shell[i] * 0.6f)
        val cl = cos(s.lat[i])
        val x = s.shell[i] * cl * sin(lon)
        val y0 = s.shell[i] * sin(s.lat[i])
        val z0 = s.shell[i] * cl * cos(lon)
        val y = y0 * ct - z0 * st
        val z = y0 * st + z0 * ct
        if ((z >= 0f) != front) continue
        val depth = (z + 1f) / 2f
        val alpha = ((0.16f + 0.84f * depth) * (0.62f + 0.38f * lv + 0.18f * core)).coerceIn(0f, 1f)
        val col = lerp(GalaxyViolet, GalaxyCyan, s.tone[i])
        drawCircle(col.a(alpha), s.size[i] * (0.6f + depth * 0.9f) * px, c + Offset(x * r * 0.97f, y * r * 0.97f))
    }
}

/**
 * The large centre microphone button: glass circle, glowing cyan/violet border, animated mic icon, ripple that follows the
 * real microphone level while a session is on. [active] = a voice session is running (tap again to stop).
 */
@Composable
fun GalaxyMicButton(active: Boolean, level: () -> Float, onClick: () -> Unit, modifier: Modifier = Modifier, diameter: Dp = 104.dp, label: String = "", halo: Dp = 60.dp) {
    val g = LocalGlass.current
    val phase = rememberPhase(1700)
    val haptic = LocalHapticFeedback.current
    val levelNow by rememberUpdatedState(level)
    val outer = diameter + halo
    Box(modifier.size(outer), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(outer)) {
            val base = diameter.toPx() / 2f
            val lv = if (active) levelNow().coerceIn(0f, 1f) else 0f
            drawCircle(Brush.radialGradient(listOf(GalaxyViolet.a(if (active) 0.34f + 0.2f * lv else 0.16f), Color.Transparent), center, base * 1.9f), base * 1.9f, center)
            if (active && !g.reduced) for (i in 0..1) {
                val q = (phase.value + i * 0.5f) % 1f
                drawCircle(GalaxyCyan.a((1f - q) * (0.30f + 0.35f * lv)), base * (1.06f + 0.28f * q + 0.22f * lv), center, style = Stroke(2.dp.toPx()))
            }
            // glowing cyan -> violet border
            drawCircle(GalaxyCyan.a(if (active) 0.28f else 0.16f), base + 3.dp.toPx(), center, style = Stroke(9.dp.toPx()))
            rotate(if (active && !g.reduced) phase.value * 360f else 0f, center) {
                drawCircle(Brush.sweepGradient(listOf(GalaxyCyan, GalaxyViolet, GalaxyPurple, GalaxyViolet, GalaxyCyan), center), base, center, style = Stroke(3.dp.toPx()))
            }
        }
        GlassCard(
            Modifier.size(diameter - 8.dp)
                .pressable({ haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() })
                .semantics { contentDescription = label.ifBlank { if (active) "Stop listening" else "Talk to Nova" } },
            shape = CircleShape, glow = true, tint = GalaxyViolet.a(if (active) 0.30f else 0.14f)
        ) {
            Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) {
                MicGlyph(active, level, phase.value)
            }
        }
    }
}

@Composable
private fun MicGlyph(active: Boolean, level: () -> Float, phase: Float) {
    val levelNow by rememberUpdatedState(level)
    Canvas(Modifier.size(46.dp).graphicsLayer {
        val s = 1f + (if (active) 0.14f * levelNow().coerceIn(0f, 1f) else 0f)
        scaleX = s; scaleY = s
    }) {
        val w = size.width; val h = size.height
        val col = if (active) Color.White else GalaxyCyan
        val sw = w * 0.075f
        val bodyW = w * 0.34f
        drawRoundRect(col, Offset((w - bodyW) / 2f, h * 0.04f), Size(bodyW, h * 0.52f), CornerRadius(bodyW / 2f))
        drawArc(col, 0f, 180f, false, Offset(w * 0.22f, h * 0.22f), Size(w * 0.56f, h * 0.50f), style = Stroke(sw, cap = StrokeCap.Round))
        drawLine(col, Offset(w / 2f, h * 0.72f), Offset(w / 2f, h * 0.90f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(col, Offset(w * 0.34f, h * 0.92f), Offset(w * 0.66f, h * 0.92f), strokeWidth = sw, cap = StrokeCap.Round)
        if (active) for (i in 0..1) {                                  // sound waves on both sides while listening
            val q = (phase + i * 0.5f) % 1f
            val rr = w * (0.50f + 0.08f * q)
            val tl = Offset(w / 2f - rr, h * 0.30f - rr)
            drawArc(GalaxyCyan.a((1f - q) * 0.8f), -35f, 70f, false, tl, Size(rr * 2f, rr * 2f), style = Stroke(sw * 0.7f, cap = StrokeCap.Round))
            drawArc(GalaxyCyan.a((1f - q) * 0.8f), 145f, 70f, false, tl, Size(rr * 2f, rr * 2f), style = Stroke(sw * 0.7f, cap = StrokeCap.Round))
        }
    }
}

/** Two tilted orbital rings with a comet that travels along them. [front] = the half nearest to the viewer (drawn after the sphere). */
private fun DrawScope.orbitRings(c: Offset, r: Float, ringAngle: Float, lv: Float, core: Float, px: Float, lite: Boolean, front: Boolean, err: Boolean) {
    val count = if (lite) 1 else 2
    for (k in 0 until count) {
        val a = r * (if (k == 0) 1.62f else 1.50f)
        val b = r * (if (k == 0) 0.44f else 0.38f)
        val tilt = if (k == 0) -18f else 26f
        val col = if (err) GalaxyRed else if (k == 0) GalaxyCyan else GalaxyPurple
        val head = (ringAngle * (if (k == 0) 1.0f else -0.75f) + k * 2.2f) * RAD_TO_DEG
        val tl = Offset(c.x - a, c.y - b)
        val sz = Size(a * 2f, b * 2f)
        rotate(tilt, c) {
            drawArc(col.a(if (front) 0.30f else 0.14f), if (front) 0f else 180f, 180f, false, tl, sz, style = Stroke(1.2f * px))
            val seg = 9
            val step = 7f
            for (i in 0 until seg) {
                val ang = head - (seg - 1 - i) * step
                if ((sin(ang / RAD_TO_DEG) > 0f) != front) continue
                val al = (0.12f + 0.88f * (i + 1f) / seg) * (0.55f + 0.45f * core + 0.3f * lv)
                drawArc(col.a(al), ang, step + 1f, false, tl, sz, style = Stroke((1.5f + 2.2f * (i + 1f) / seg) * px, cap = StrokeCap.Round))
            }
            val hr = head / RAD_TO_DEG
            if ((sin(hr) > 0f) == front) {
                val p = c + Offset(a * cos(hr), b * sin(hr))
                drawCircle(col.a(0.35f), 8f * px, p)
                drawCircle(Color.White.a(0.9f), 3f * px, p)
            }
        }
    }
}

/**
 * Audio waveform. Bars follow [level] (the real microphone level while listening, the real speaker level while speaking);
 * while thinking they ripple gently, otherwise they rest as a thin line. Reduced effects: fewer bars, ~20 fps.
 */
@Composable
fun NovaWaveform(mode: OrbMode, level: () -> Float, modifier: Modifier = Modifier.fillMaxWidth().height(34.dp), lite: Boolean = false) {
    val g = LocalGlass.current
    val slow = lite || g.reduced
    var phase by remember { mutableFloatStateOf(0f) }
    var amp by remember { mutableFloatStateOf(0f) }
    val modeNow by rememberUpdatedState(mode)
    val levelNow by rememberUpdatedState(level)
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner, slow) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            var last = 0L
            while (true) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                if (last == 0L) { last = now; continue }
                val dt = (now - last) / 1_000_000_000f
                if (dt < (if (slow) 0.05f else 0.033f)) continue
                last = now
                val m = modeNow
                val active = m == OrbMode.LISTENING || m == OrbMode.SPEAKING
                val target = if (active) levelNow().coerceIn(0f, 1f) else if (m == OrbMode.THINKING) 0.14f else 0f
                amp += (target - amp) * (if (target > amp) 0.5f else 0.15f)
                phase = (phase + dt.coerceAtMost(0.1f) * (if (active) 7f else 2.5f)) % ORB_TAU
            }
        }
    }
    Canvas(modifier.semantics { contentDescription = "Audio waveform" }) {
        val n = if (slow) 21 else 35
        val gap = size.width / n
        val bw = gap * 0.46f
        val mid = size.height / 2f
        for (i in 0 until n) {
            val x = gap * (i + 0.5f)
            val env = sin((PI * (i + 0.5) / n).toFloat())
            val wave = 0.5f + 0.5f * sin(phase + i * 0.55f)
            val h = (size.height * 0.08f + size.height * 0.90f * amp * env * (0.35f + 0.65f * wave)).coerceAtMost(size.height)
            val col = lerp(GalaxyCyan, GalaxyPurple, i / (n - 1f))
            drawRoundRect(col.a(0.30f + 0.70f * amp), Offset(x - bw / 2f, mid - h / 2f), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}
