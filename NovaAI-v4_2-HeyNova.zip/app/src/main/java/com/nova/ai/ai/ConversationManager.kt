package com.nova.ai.ai

import com.nova.ai.core.AIProvider
import com.nova.ai.security.Prefs

/** What the UI/voice layer shows or says after one turn. */
sealed class TurnResult {
    data class Reply(val text: String) : TurnResult()
    data class Confirm(val prompt: String, val run: () -> String) : TurnResult()
    data class Error(val message: String) : TurnResult()
}

/**
 * Voice/Text -> memory context -> LLM -> structured intent -> ActionValidator -> executor -> LLM wording -> UI/TTS.
 * Keeps its own short history. It never executes anything itself: [ActionRegistry] does, after validation.
 */
class ConversationManager(
    private val prefs: Prefs,
    private val provider: AIProvider,
    private val actions: ActionRegistry,
    /** Relevant long-term memory for this message (already filtered by the memory engine; empty when memory is off). */
    private val memoryFor: (String) -> String = { "" }
) {
    private val history = ArrayList<ChatMessage>()

    fun clear() { history.clear() }

    suspend fun handle(userText: String, basePrompt: String, planActions: Boolean = true): TurnResult {
        history.add(ChatMessage(true, userText))
        trim()
        val mem = if (prefs.memoryEnabled) memoryFor(userText) else ""
        val system = buildString {
            append(basePrompt)
            if (mem.isNotBlank()) append("\n\nThings the user asked Nova to remember:\n").append(mem)
            if (planActions) append("\n\n").append(PromptManager.actionPlanning())
        }
        val first = ask(system) ?: return TurnResult.Error(lastError)
        return when (val parsed = IntentParser.parse(first)) {
            is ParsedReply.Plain -> { history.add(ChatMessage(false, parsed.text)); TurnResult.Reply(parsed.text) }
            is ParsedReply.Action -> when (val out = actions.execute(parsed.intent)) {
                is ActionOutcome.Refused -> { history.add(ChatMessage(false, out.reason)); TurnResult.Reply(out.reason) }
                is ActionOutcome.NeedsConfirm -> TurnResult.Confirm(out.prompt) {
                    val said = out.run(); history.add(ChatMessage(false, said)); said
                }
                is ActionOutcome.Done -> {
                    // Let the LLM word the result naturally. This second call carries no action instructions, so no action loops.
                    val wording = ask(basePrompt, "Action result: ${out.say}\nTell the user this in one short sentence.")
                    val text = (wording ?: out.say).ifBlank { out.say }
                    history.add(ChatMessage(false, text)); TurnResult.Reply(text)
                }
            }
        }
    }

    private var lastError = ""

    private suspend fun ask(system: String, extraUser: String? = null): String? {
        val msgs = history.map { it.fromUser to it.text }.toMutableList()
        if (extraUser != null) msgs.add(true to extraUser)
        return when (val r = provider.chat(msgs, system, null)) {
            is AiResult.Ok -> r.text
            is AiResult.Err -> { lastError = r.msg; null }
        }
    }

    private fun trim() {
        val max = prefs.contextTurns.coerceIn(2, 40)
        while (history.size > max) history.removeAt(0)
        while (history.isNotEmpty() && !history.first().fromUser) history.removeAt(0)
    }
}
