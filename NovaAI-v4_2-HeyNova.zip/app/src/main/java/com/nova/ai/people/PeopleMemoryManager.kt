package com.nova.ai.people

import android.content.Context
import com.nova.ai.ai.Mood
import com.nova.ai.memory.MemoryEngine
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * People & relationship memory. Everything is local (Room). Only people the user introduced are stored; nothing is guessed.
 * Suspend functions are for the UI; blocking() lets the synchronous command router run quick local writes.
 */
class PeopleMemoryManager(ctx: Context, private val prefs: Prefs, private val textMemory: MemoryEngine) {
    private val repo = PersonRepository(PeopleDatabase.get(ctx))
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _people = MutableStateFlow<List<PersonWithData>>(emptyList())
    val people: StateFlow<List<PersonWithData>> = _people.asStateFlow()
    @Volatile private var loaded = false

    val resolver = PersonResolver { snapshot() }
    val graph = RelationshipGraph { snapshot() }
    val confidence = MemoryConfidenceEngine()
    val decisions = MemoryDecisionEngine { textMemory.isSensitiveText(it) }
    val contextEngine = ConversationContextEngine()
    val speaker = SpeakerIdentificationManager()
    val profileResolver = PersonProfileResolver()
    val privacy = PrivacyManager()

    init { scope.launch { repo.observe().collect { _people.value = it; loaded = true } } }

    fun snapshot(): List<PersonWithData> {
        if (!loaded) { try { runBlocking(Dispatchers.IO) { refresh() } } catch (e: Exception) { } }
        return _people.value
    }

    private suspend fun refresh() { _people.value = repo.all(); loaded = true }
    fun <T> blocking(block: suspend () -> T): T = runBlocking(Dispatchers.IO) { block() }
    fun launch(block: suspend () -> Unit) { scope.launch { try { block() } catch (e: Exception) { } } }

    private fun hash(s: String) = normName(s).hashCode().toString()
    private suspend fun fresh(id: Long): PersonWithData { refresh(); return _people.value.first { it.person.personId == id } }
    private suspend fun find(id: Long) = repo.all().firstOrNull { it.person.personId == id }

    // ───────── introducing / editing people ─────────
    suspend fun introduce(name: String, rt: RelationshipType, label: String? = null, nickname: String = "", force: Boolean = false): IntroOutcome {
        val nm = capName(name)
        val relLabel = label?.takeIf { it.isNotBlank() } ?: rt.label
        if (!force) {
            val cands = resolver.exactName(nm, repo.all())
            val same = cands.firstOrNull { it.person.relType == rt.key && (rt != RelationshipType.OTHER || it.person.relLabel.equals(relLabel, true)) }
            if (same != null) { touch(same.person.personId); return IntroOutcome.Duplicate(fresh(same.person.personId)) }
            val swap = cands.firstOrNull { RelationshipType.sameGroup(it.person.relType, rt.key) }
            if (swap != null) { setRelationship(swap.person.personId, rt, label); return IntroOutcome.Updated(fresh(swap.person.personId), "Relationship updated to $relLabel") }
            if (cands.isNotEmpty()) return IntroOutcome.NeedsMerge(cands.first(), nm, rt, label)
        }
        val now = System.currentTimeMillis()
        val d = decisions.relationship()
        val id = repo.createPerson(
            PersonEntity(name = nm, nickname = nickname, relType = rt.key, relLabel = relLabel, category = rt.category, createdAt = now, lastInteraction = now,
                source = "user introduced", reason = "Saved because you told NOVA that $nm is your ${relLabel.lowercase()}."),
            listOf(nm, nickname),
            PersonMemoryEntity(personId = 0, kind = "RELATION", content = "$nm is the user's ${relLabel.lowercase()}.", confidence = d.confidence.name,
                source = "user statement", importance = d.importance, createdAt = now, lastUsedAt = now, expiresAt = 0, userConfirmed = true, reason = d.reason)
        )
        return IntroOutcome.Created(fresh(id))
    }

    private suspend fun touch(id: Long) { find(id)?.let { repo.update(it.person.copy(lastInteraction = System.currentTimeMillis())) } }

    suspend fun setRelationship(id: Long, rt: RelationshipType, label: String? = null) {
        val pw = find(id) ?: return
        val lab = label?.takeIf { it.isNotBlank() } ?: rt.label
        repo.update(pw.person.copy(relType = rt.key, relLabel = lab, category = rt.category, lastInteraction = System.currentTimeMillis()))
        pw.memories.firstOrNull { it.kind == "RELATION" }?.let {
            repo.updateMemory(it.copy(content = "${pw.person.name} is the user's ${lab.lowercase()}.", userConfirmed = true, confidence = "HIGH", reason = "Updated because you changed the relationship."))
        }
        refresh()
    }

    suspend fun setNickname(id: Long, nick: String) {
        val pw = find(id) ?: return
        val n = capName(nick)
        repo.addAlias(id, n)
        repo.update(pw.person.copy(nickname = n, lastInteraction = System.currentTimeMillis()))
        refresh()
    }

    /** Returns an error message or null. Notes must be text the user typed; sensitive-looking text is refused. */
    suspend fun saveBasics(id: Long, name: String, nickname: String, address: String, notes: String): String? {
        val pw = find(id) ?: return "Person not found."
        if (name.isBlank()) return "Name can't be empty."
        if (notes.isNotBlank() && textMemory.isSensitiveText(notes)) return "Notes can't contain passwords, PINs or card numbers."
        repo.update(pw.person.copy(name = capName(name), nickname = capName(nickname), preferredAddress = address.trim(), notes = notes.trim()))
        repo.addAlias(id, name); if (nickname.isNotBlank()) repo.addAlias(id, nickname); if (address.isNotBlank()) repo.addAlias(id, address)
        refresh(); return null
    }

    suspend fun setStyle(id: Long, style: String) { find(id)?.let { repo.update(it.person.copy(style = style)); refresh() } }
    suspend fun setAiAllowed(id: Long, on: Boolean) { find(id)?.let { repo.update(it.person.copy(aiContextAllowed = on)); refresh() } }
    suspend fun clearContext(id: Long) { find(id)?.let { repo.update(it.person.copy(lastContext = "", lastTone = "", contextUpdatedAt = 0)); refresh() } }

    suspend fun addNote(id: Long, text: String, explicit: Boolean): String {
        val d = decisions.note(text, explicit)
        if (d.verdict != Verdict.REMEMBER) return d.reason
        if (repo.isBlocked(hash(text))) return "You told NOVA never to remember this."
        val now = System.currentTimeMillis()
        repo.addMemory(PersonMemoryEntity(personId = id, kind = "NOTE", content = text.trim(), confidence = d.confidence.name, source = "explicit request",
            importance = d.importance, createdAt = now, lastUsedAt = now, expiresAt = 0, userConfirmed = true, reason = d.reason))
        refresh(); return "OK"
    }

    suspend fun addContext(id: Long, topic: String, today: Boolean) {
        val pw = find(id) ?: return
        val d = decisions.context(today)
        val now = System.currentTimeMillis()
        repo.addMemory(PersonMemoryEntity(personId = id, kind = "CONTEXT", content = topic.trim(), confidence = d.confidence.name, source = "user statement",
            importance = d.importance, createdAt = now, lastUsedAt = now, expiresAt = d.expiresAt, userConfirmed = false, reason = d.reason))
        repo.update(pw.person.copy(lastContext = topic.trim(), contextUpdatedAt = now, lastInteraction = now))
        refresh()
    }

    suspend fun editMemory(m: PersonMemoryEntity, text: String): String? {
        if (text.isBlank()) return "Text can't be empty."
        if (textMemory.isSensitiveText(text)) return "Memories can't contain passwords, PINs or card numbers."
        repo.updateMemory(m.copy(content = text.trim(), userConfirmed = true, confidence = "HIGH", reason = "Edited by you, so NOVA treats it as confirmed."))
        refresh(); return null
    }

    suspend fun deleteMemory(id: Long) { repo.deleteMemory(id); refresh() }
    suspend fun neverRemember(m: PersonMemoryEntity) { repo.block(hash(m.content), m.kind); repo.deleteMemory(m.memoryId); refresh() }
    suspend fun blockText(text: String) { repo.block(hash(text), "text") }
    suspend fun deleteMemoriesFor(id: Long) { repo.deleteMemoriesFor(id); refresh() }
    suspend fun forgetPerson(id: Long) { repo.deletePerson(id); refresh() }
    suspend fun deleteAll() { repo.deleteEverything(); refresh() }
    suspend fun merge(keepId: Long, removeId: Long) { repo.merge(keepId, removeId); refresh() }
    suspend fun purgeExpired() { if (repo.purgeExpired(System.currentTimeMillis()) > 0) refresh() }
    fun exportJson(): String = privacy.export(snapshot())

    // ───────── conversation integration ─────────
    /** Updates last interaction and the tone of the USER's recent messages about each mentioned person. */
    fun noteMention(text: String, mood: Mood) {
        if (!prefs.memoryEnabled) return
        val mentioned = resolver.mentionedIn(text)
        if (mentioned.isEmpty()) return
        launch {
            val now = System.currentTimeMillis()
            mentioned.forEach { pw ->
                find(pw.person.personId)?.let { repo.update(it.person.copy(lastInteraction = now, lastTone = if (mood != Mood.Neutral) mood.name else it.person.lastTone, contextUpdatedAt = now)) }
            }
            refresh()
        }
    }

    /** Short-lived context for ordinary messages that mention a saved person (e.g. "aaj Rahul ke saath cricket"). */
    fun observe(text: String) {
        if (!prefs.memoryEnabled || !prefs.peopleLearn || textMemory.isSensitiveText(text) || text.trim().endsWith("?")) return
        val mentioned = resolver.mentionedIn(text)
        if (contextEngine.classify(text, mentioned.isNotEmpty()) != Verdict.TEMPORARY) return
        launch { if (!repo.isBlocked(hash(text))) mentioned.forEach { addContext(it.person.personId, text.take(100), today = true) } }
    }

    private fun styleText(s: String) = when (s) {
        "friendly" -> "friendly and warm"; "formal" -> "formal and polite"; "casual" -> "casual"; "funny" -> "light and funny"
        "respectful" -> "extra respectful"; "short" -> "short replies"; "detailed" -> "detailed replies"; else -> ""
    }

    /**
     * Minimum context for ONE AI request: only people named in the request, one short line each. The full people list is never sent.
     * Low-confidence items are skipped, and nothing is sent for people whose "use in AI answers" switch is off.
     */
    fun contextFor(text: String): String {
        if (!prefs.peopleAi) return ""
        val mentioned = resolver.mentionedIn(text).filter { it.person.aiContextAllowed }
        if (mentioned.isEmpty()) return ""
        val now = System.currentTimeMillis()
        val lines = mentioned.map { pw ->
            val p = pw.person
            val sb = StringBuilder(privacy.minimalLine(pw))
            if (!p.userConfirmed) sb.append(" (unconfirmed)")
            styleText(p.style).takeIf { it.isNotBlank() }?.let { sb.append(" The user wants a $it style for anything about ${p.name}.") }
            if (p.lastContext.isNotBlank() && now - p.contextUpdatedAt < 30L * 86400000L) sb.append(" Known context: ${p.lastContext}.")
            if (p.notes.isNotBlank()) sb.append(" User note: ${p.notes}.")
            pw.memories.filter { it.kind != "RELATION" && (it.expiresAt == 0L || it.expiresAt > now) &&
                confidence.effective(it.confidence, it.userConfirmed, it.createdAt, it.lastUsedAt, now).name != "LOW" }
                .take(3).forEach { sb.append(" ").append(it.content).append(".") }
            sb.toString()
        }
        return "People context (only people named in this request; never state anyone's current mood as fact, you only know the tone of the user's messages):\n" + lines.joinToString("\n")
    }
}
