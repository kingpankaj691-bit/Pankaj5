package com.nova.ai.core

import com.nova.ai.ai.AiException
import com.nova.ai.ai.AiResult
import com.nova.ai.ai.ChatMessage
import com.nova.ai.ai.Emotion
import com.nova.ai.ai.Mood
import com.nova.ai.ai.Personality
import com.nova.ai.commands.CmdResult
import com.nova.ai.memory.IgnoredInfo
import com.nova.ai.memory.MemoryEntry
import com.nova.ai.permissions.PermItem
import com.nova.ai.scanner.AppInfo
import com.nova.ai.scanner.Capability
import com.nova.ai.scanner.DeviceProfile
import com.nova.ai.scanner.ScanSection

/** Module contracts. Future features (reminders, weather, smart home...) plug in behind these. */
interface AIProvider {
    suspend fun chat(history: List<Pair<Boolean, String>>, system: String, model: String? = null): AiResult

    /** Plain-text entry point for callers that only want the answer. Throws [AiException] on any provider error. */
    suspend fun generateResponse(conversation: List<ChatMessage>, systemPrompt: String): String =
        when (val r = chat(conversation.map { it.fromUser to it.text }, systemPrompt, null)) {
            is AiResult.Ok -> r.text
            is AiResult.Err -> throw AiException(r.msg)
        }
}

interface VoiceProvider {
    fun listen(onText: (String) -> Unit, onFail: (String) -> Unit)
    fun stopSpeaking()
    fun shutdown()
}

interface TTSManager {
    fun ttsAvailable(): Boolean
    fun speak(text: String, emo: Emotion = Emotion.Normal)
    fun repeat()
    fun resume(): Boolean
    fun stopSpeaking()
}

interface CommandExecutor { fun route(raw: String): CmdResult }

interface DeviceScanner {
    /** (id, title) in scan order. */
    val steps: List<Pair<String, String>>
    suspend fun build(id: String): ScanSection
    suspend fun scan(onStep: (Int, String) -> Unit, paced: Boolean = true): DeviceProfile
}

interface AppManager {
    fun inventory(): List<AppInfo>
    fun launch(pkg: String): Boolean
    fun capabilityMap(): List<Capability>
}

interface ScreenAssistant {
    fun isEnabled(): Boolean
    fun readScreen(): String?
    fun click(label: String): Boolean
    fun scroll(forward: Boolean): Boolean
    fun back(): Boolean
    fun home(): Boolean
    fun type(text: String): Boolean
}

interface MemoryManager {
    fun saved(): List<MemoryEntry>
    fun recent(): List<MemoryEntry>
    fun temporary(): List<MemoryEntry>
    fun ignored(): List<IgnoredInfo>
    fun remember(text: String?, previous: String?): String
    fun observe(text: String)
    fun forgetLast(): String
    fun neverRemember(text: String?)
    fun update(id: Long, content: String)
    fun delete(id: Long)
    fun forget(id: Long)
    fun pin(id: Long, pinned: Boolean)
    fun promptContext(): String
    fun summaryText(): String
    fun purgeExpired(): Int
    fun count(): Int
    fun clear()
}

interface NotificationManager {
    fun isAccessEnabled(): Boolean
    fun allowedApps(): Set<String>
    fun setAllowedApps(s: Set<String>)
    fun summary(): String
}

interface PermissionManager {
    fun novaPermissions(): List<PermItem>
    fun isGranted(p: PermItem): Boolean
}

interface PersonalityEngine {
    fun prompt(p: Personality, custom: String): String
    fun emotion(p: Personality, mood: Mood, override: String, text: String, developer: Boolean): Emotion
}
