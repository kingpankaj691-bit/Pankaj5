package com.nova.ai.ai

/** One turn of a conversation. [fromUser] true = the person, false = Nova. */
data class ChatMessage(val fromUser: Boolean, val text: String)

/** Thrown by [com.nova.ai.core.AIProvider.generateResponse] when a provider reports an error. */
class AiException(message: String) : Exception(message)
