package com.nova.ai.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.net.Uri
import androidx.core.content.ContextCompat
import com.nova.ai.automation.Notifier
import com.nova.ai.modules.Net

/** "Remind me when I reach home": saved places plus a location watcher that lives inside the Background Voice service. */
class LocationReminders(private val ctx: Context) {
    private val jp = JarvisPrefs(ctx)
    private var lm: LocationManager? = null
    private var listener: LocationListener? = null

    companion object {
        fun hasPermission(ctx: Context) =
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        @SuppressLint("MissingPermission")
        fun lastKnown(ctx: Context): Location? {
            if (!hasPermission(ctx)) return null
            return try {
                val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                m.getProviders(true).mapNotNull { m.getLastKnownLocation(it) }.maxByOrNull { it.time }
            } catch (e: Exception) { null }
        }
    }

    fun savePlaceHere(name: String): String {
        if (!hasPermission(ctx)) return "I need the Location permission to save this place. Allow it in Jarvis settings."
        val l = lastKnown(ctx) ?: return "I couldn't get your location yet. Turn on location and try again in a moment."
        jp.savePlace(JarvisPrefs.Place(name.trim(), l.latitude, l.longitude))
        return "Saved this place as ${name.trim()}."
    }

    suspend fun add(placeName: String, what: String): String {
        val name = placeName.trim()
        val saved = jp.places().firstOrNull { it.name.equals(name, true) }
        val lat: Double; val lon: Double; val radius: Float
        if (saved != null) { lat = saved.lat; lon = saved.lon; radius = 200f }
        else {
            val g = Net.getJson("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + Uri.encode(name))
            val r = g?.optJSONArray("results")?.optJSONObject(0)
                ?: return "I don't know a place called $name. Say \"ye mera $name hai\" while you are there, or name a city."
            lat = r.getDouble("latitude"); lon = r.getDouble("longitude"); radius = 1500f
        }
        jp.saveReminders(jp.reminders() + JarvisPrefs.LocReminder(System.currentTimeMillis(), name, what.trim(), lat, lon, radius))
        jp.locationReminders = true
        return "Okay. Jab aap $name pahunchenge, main yaad dilaungi: ${what.trim()}." +
            if (!hasPermission(ctx)) " Allow Location in Jarvis settings so I can notice when you arrive." else ""
    }

    /** Called for every location update. Triggered reminders are removed (they fire once). */
    fun check(loc: Location) {
        val all = jp.reminders()
        if (all.isEmpty()) return
        val hit = all.filter { r ->
            val out = FloatArray(1)
            Location.distanceBetween(loc.latitude, loc.longitude, r.lat, r.lon, out)
            out[0] <= r.radius
        }
        if (hit.isEmpty()) return
        jp.saveReminders(all - hit.toSet())
        hit.forEach {
            Notifier.post(ctx, (4100 + it.id % 800).toInt(), "Reminder: ${it.place}", it.what)
            Announcer.speak(ctx, "Aap ${it.place} pahunch gaye. Yaad dilana tha: ${it.what}")
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (listener != null || !jp.locationReminders || !hasPermission(ctx)) return
        val m = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) { check(location) }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
            override fun onProviderEnabled(provider: String) { }
            override fun onProviderDisabled(provider: String) { }
        }
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER))
                if (m.isProviderEnabled(p)) m.requestLocationUpdates(p, 60_000L, 50f, l, Looper.getMainLooper())
            lm = m; listener = l
        } catch (e: Exception) { }
    }

    fun stop() {
        val l = listener ?: return
        try { lm?.removeUpdates(l) } catch (e: Exception) { }
        listener = null; lm = null
    }
}
