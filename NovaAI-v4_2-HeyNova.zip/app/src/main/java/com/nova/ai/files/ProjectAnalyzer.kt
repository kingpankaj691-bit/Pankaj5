package com.nova.ai.files

import java.io.File

data class LangStat(val name: String, val files: Int, val lines: Long)

data class ProjectReport(
    val name: String, val files: Int, val dirs: Int, val bytes: Long, val langs: List<LangStat>,
    val types: List<String>, val keyFiles: List<String>, val largest: List<Pair<String, Long>>, val capped: Boolean
) {
    /** Plain text, readable aloud. Everything here was computed on the phone. */
    fun toText(): String = buildString {
        append("Project: $name\n")
        append("${files} files in ${dirs} folders · ${FileFormat.size(bytes)}${if (capped) " (stopped counting at the limit)" else ""}\n")
        if (types.isNotEmpty()) append("Looks like: ${types.joinToString(", ")}\n")
        if (langs.isNotEmpty()) { append("\nLanguages (by lines):\n"); langs.take(8).forEach { append("• ${it.name}: ${it.files} files, ${it.lines} lines\n") } }
        if (keyFiles.isNotEmpty()) { append("\nKey files:\n"); keyFiles.forEach { append("• $it\n") } }
        if (largest.isNotEmpty()) { append("\nBiggest files:\n"); largest.forEach { append("• ${it.first} (${FileFormat.size(it.second)})\n") } }
    }.trim()
}

object ProjectAnalyzer {
    private val skipDirs = setOf(".git", ".gradle", ".idea", "build", "node_modules", "__pycache__", "dist", "out", ".venv", "venv", "Pods", ".dart_tool", "target", ".svn", ".cxx")
    private val langOf = mapOf(
        "kt" to "Kotlin", "kts" to "Kotlin", "java" to "Java", "js" to "JavaScript", "jsx" to "JavaScript", "ts" to "TypeScript", "tsx" to "TypeScript",
        "py" to "Python", "c" to "C/C++", "cpp" to "C/C++", "h" to "C/C++", "cs" to "C#", "go" to "Go", "rs" to "Rust", "php" to "PHP", "rb" to "Ruby",
        "swift" to "Swift", "dart" to "Dart", "html" to "HTML", "htm" to "HTML", "css" to "CSS", "xml" to "XML", "json" to "JSON", "md" to "Markdown",
        "gradle" to "Gradle", "sql" to "SQL", "sh" to "Shell", "yml" to "YAML", "yaml" to "YAML", "aidl" to "AIDL", "lua" to "Lua"
    )
    private val keyNames = listOf("README.md", "README", "readme.md", "build.gradle.kts", "build.gradle", "settings.gradle.kts", "settings.gradle", "AndroidManifest.xml",
        "package.json", "pubspec.yaml", "requirements.txt", "pyproject.toml", "pom.xml", "Cargo.toml", "go.mod", "CMakeLists.txt", "Makefile", "index.html", ".gitignore")
    val markerFiles = setOf("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json", "pubspec.yaml", "pom.xml", "Cargo.toml", "go.mod", "pyproject.toml", "requirements.txt", "CMakeLists.txt", "AndroidManifest.xml")

    private fun countLines(f: File): Long {
        var n = 0L; var any = false; var last = 0
        f.inputStream().buffered(64 * 1024).use { i -> val buf = ByteArray(64 * 1024); var r: Int
            while (i.read(buf).also { r = it } > 0) { any = true; last = buf[r - 1].toInt(); for (k in 0 until r) if (buf[k] == '\n'.code.toByte()) n++ } }
        return if (any && last != '\n'.code) n + 1 else n
    }

    fun analyze(root: File, maxFiles: Int = 20_000, alive: () -> Boolean = { true }): ProjectReport {
        val stats = HashMap<String, LongArray>()     // lang -> [files, lines]
        val names = HashSet<String>(); val keys = ArrayList<String>(); val big = ArrayList<Pair<String, Long>>()
        var files = 0; var dirs = 0; var bytes = 0L; var capped = false
        val q = ArrayDeque<File>(); q.add(root)
        while (q.isNotEmpty() && alive()) {
            val d = q.removeFirst()
            for (k in (try { d.listFiles() } catch (e: Exception) { null } ?: continue)) {
                if (k.isDirectory) { if (k.name !in skipDirs) { dirs++; q.add(k) }; continue }
                if (files >= maxFiles) { capped = true; q.clear(); break }
                files++; val size = k.length(); bytes += size
                val rel = k.relativeTo(root).path.replace('\\', '/')
                names.add(k.name)
                if (k.name in keyNames && keys.size < 14) keys.add(rel)
                big.add(rel to size); if (big.size > 200) { big.sortByDescending { it.second }; while (big.size > 5) big.removeAt(big.size - 1) }
                val lang = langOf[FileTypes.extOf(k.name)]
                if (lang != null && size <= 2L * 1024 * 1024) { val a = stats.getOrPut(lang) { LongArray(2) }; a[0]++; a[1] += try { countLines(k) } catch (e: Exception) { 0L } }
            }
        }
        big.sortByDescending { it.second }
        val types = ArrayList<String>()
        if (("build.gradle" in names || "build.gradle.kts" in names) && "AndroidManifest.xml" in names) types.add("Android app (Gradle)")
        else if ("build.gradle" in names || "build.gradle.kts" in names) types.add("Gradle project")
        if ("pubspec.yaml" in names) types.add("Flutter / Dart")
        if ("package.json" in names) types.add("Node / JavaScript")
        if ("requirements.txt" in names || "pyproject.toml" in names) types.add("Python")
        if ("pom.xml" in names) types.add("Maven (Java)")
        if ("Cargo.toml" in names) types.add("Rust (Cargo)")
        if ("go.mod" in names) types.add("Go module")
        if ("CMakeLists.txt" in names) types.add("C/C++ (CMake)")
        if (types.isEmpty() && "index.html" in names) types.add("Website")
        val langs = stats.map { LangStat(it.key, it.value[0].toInt(), it.value[1]) }.sortedByDescending { it.lines }
        return ProjectReport(root.name.ifBlank { root.path }, files, dirs, bytes, langs, types, keys, big.take(5), capped)
    }

    /**
     * The exact text offered to Gemini for a project: a folder outline, the language table and the first lines of a few key files.
     * Never the rest of the source code. The consent dialog shows this whole text before anything is sent.
     */
    fun excerptForAi(root: File, report: ProjectReport, maxChars: Int = DocReader.MAX_CHARS): String {
        val sb = StringBuilder(report.toText()).append("\n\nTop-level layout:\n")
        (root.listFiles() ?: emptyArray()).filter { it.name !in skipDirs && !it.name.startsWith(".") }.sortedBy { it.name.lowercase() }.take(50)
            .forEach { sb.append(if (it.isDirectory) "📁 " else "• ").append(it.name).append('\n') }
        for (rel in report.keyFiles.filter { it.substringAfterLast('/') in setOf("README.md", "README", "readme.md", "build.gradle.kts", "build.gradle", "AndroidManifest.xml", "package.json", "pubspec.yaml") }.take(4)) {
            val r = DocReader.read(File(root, rel), 2500)
            if (r.ok) sb.append("\n--- ").append(rel).append(" (first part) ---\n").append(r.text.take(2000)).append('\n')
        }
        return sb.toString().take(maxChars)
    }

    /** Folders that look like coding projects (contain a build/manifest file), searched a few levels deep under [roots]. */
    fun findProjects(roots: List<File>, maxResults: Int = 30, alive: () -> Boolean = { true }): List<File> {
        val out = ArrayList<File>(); val q = ArrayDeque<Pair<File, Int>>(); roots.forEach { q.add(it to 0) }
        while (q.isNotEmpty() && alive() && out.size < maxResults) {
            val (d, depth) = q.removeFirst()
            if (PathRules.blockedReason(d.path) != null) continue
            val kids = try { d.listFiles() } catch (e: Exception) { null } ?: continue
            if (kids.any { it.isFile && it.name in markerFiles } && (depth > 0)) { out.add(d); continue }       // don't descend into a project
            if (depth < 3) kids.filter { it.isDirectory && it.name !in skipDirs && !it.name.startsWith(".") && it.name != "Android" }.forEach { q.add(it to depth + 1) }
        }
        return out
    }
}
