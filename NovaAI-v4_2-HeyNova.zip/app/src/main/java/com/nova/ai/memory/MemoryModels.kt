package com.nova.ai.memory

enum class MemCategory {
    USER_PREFERENCE, IMPORTANT_FACT, LONG_TERM_GOAL, ROUTINE, DEVICE_PREFERENCE,
    PERSONALITY_PREFERENCE, CONVERSATION_CONTEXT, TEMPORARY_CONTEXT, COMMAND_PREFERENCE
}

enum class Confidence { LOW, MEDIUM, HIGH }

data class MemoryEntry(
    val id: Long, val category: MemCategory, val content: String, val importance: Float,
    val confidence: Confidence, val createdAt: Long, val lastUsedAt: Long, val expiresAt: Long,
    val source: String, val userConfirmed: Boolean, val pinned: Boolean, val reason: String
)

data class IgnoredInfo(val id: Long, val reason: String, val label: String, val at: Long)

data class MemoryDecision(
    val save: Boolean, val category: MemCategory?, val importance: Float, val confidence: Confidence,
    val expiresAt: Long, val reason: String, val sensitive: Boolean
)
