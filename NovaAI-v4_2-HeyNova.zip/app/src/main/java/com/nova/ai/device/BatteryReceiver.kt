package com.nova.ai.device

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import com.nova.ai.security.Prefs

/**
 * Listens to Android's battery broadcasts while a Nova component (the app screen or Background Voice) is alive.
 * It does nothing unless the user switched battery or temperature alerts on. [speak] is optional (null = notification only).
 */
class BatteryReceiver(private val prefs: Prefs, private val speak: ((String) -> Unit)?) : BroadcastReceiver() {
    private var registered = false

    fun register(ctx: Context) {
        if (registered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED); addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        try { ContextCompat.registerReceiver(ctx.applicationContext, this, f, ContextCompat.RECEIVER_NOT_EXPORTED); registered = true } catch (e: Exception) { }
    }

    fun unregister(ctx: Context) {
        if (!registered) return
        try { ctx.applicationContext.unregisterReceiver(this) } catch (e: Exception) { }
        registered = false
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (!DeviceAlerts.anyEnabled(prefs)) return
        DeviceAlerts.evaluate(ctx.applicationContext, prefs, speak)
    }
}
