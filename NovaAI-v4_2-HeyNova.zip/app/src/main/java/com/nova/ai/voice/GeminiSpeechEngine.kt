package com.nova.ai.voice

import android.os.SystemClock
import android.util.Base64
import com.nova.ai.ai.GeminiHttp
import com.nova.ai.security.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Speech-to-text through Gemini's audio input. Gemini takes finite audio clips, so the live PCM stream is first cut into one
 * clip per spoken phrase by [AmplitudeVAD] (amplitude/RMS voice activity detection). Silence is never sent, and a phrase is sent
 * as soon as you stop talking instead of waiting for a fixed 5-second window.
 *
 * This class only produces TEXT. Routing and the chat reply happen later in the pipeline.
 *
 * Memory is bounded: one phrase being collected (max 15 s) plus at most two finished phrases waiting; older ones are dropped.
 */
class GeminiSpeechEngine(
    private val prefs: Prefs,
    private val onText: (String) -> Unit,
    private val onProblem: (String) -> Unit
) : SpeechProcessingEngine {

    companion object {
        private const val QUIET_AFTER_TTS_MS = 700L
        private const val PROMPT =
            "Transcribe the speech in this audio clip exactly as spoken. The speaker may use Hindi, English or Hinglish: " +
                "write Hindi words in Roman letters (Hinglish) and keep English words in English. " +
                "Return only the transcript, no quotes, no commentary. " +
                "If there is no clear human speech, return exactly: NO_SPEECH"
    }

    private var format = PcmFormat(16000, 1)
    @Volatile private var queue: Channel<ByteArray>? = null
    @Volatile private var vad: AmplitudeVAD? = null
    private var worker: Job? = null
    @Volatile private var quietUntil = 0L

    override fun start(format: PcmFormat, scope: CoroutineScope) {
        stop()
        this.format = format
        val ch = Channel<ByteArray>(2, BufferOverflow.DROP_OLDEST)
        queue = ch
        vad = AmplitudeVAD(format.sampleRate, format.channels) { segment -> ch.trySend(segment) }
        worker = scope.launch(Dispatchers.IO) {
            for (pcm in ch) transcribe(pcm)
        }
    }

    override suspend fun processAudio(audioData: ByteArray, length: Int) {
        val now = SystemClock.elapsedRealtime()
        if (VoiceState.speaking.value) {
            // Nova is talking. Do not transcribe our own voice.
            quietUntil = now + QUIET_AFTER_TTS_MS
            vad?.reset()
            return
        }
        if (now < quietUntil) return
        vad?.push(audioData, length)
    }

    override fun stop() {
        vad?.reset()
        vad = null
        queue?.close()
        queue = null
        worker?.cancel()
        worker = null
    }

    // ───────── Gemini call ─────────

    private suspend fun transcribe(pcm: ByteArray) {
        val fmt = format
        val wav = toWav(pcm, fmt)
        val parts = JSONArray()
            .put(JSONObject().put("text", PROMPT))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0).put("maxOutputTokens", 256))
        val out = GeminiHttp.post(prefs, body, prefs.model, readTimeoutMs = 25000)
        val err = out.error
        if (err != null) {
            onProblem("Speech recognition unavailable: $err")
            val k = out.kind
            if (k == com.nova.ai.ai.net.GeminiErrorKind.RATE_LIMIT || k == com.nova.ai.ai.net.GeminiErrorKind.QUOTA_EXHAUSTED ||
                k == com.nova.ai.ai.net.GeminiErrorKind.SERVER) delay(30000)   // back off instead of hammering the API
            return
        }
        onProblem("")
        val text = clean(out.json?.let { GeminiHttp.textOf(it) } ?: "")
        if (text.isNotEmpty()) onText(text)
    }

    private fun clean(raw: String): String {
        val t = raw.trim().trim('"', '`').trim()
        if (t.isEmpty()) return ""
        if (t.contains("NO_SPEECH", ignoreCase = true)) return ""
        if (Regex("^[\\[(<].*[\\])>]$", RegexOption.DOT_MATCHES_ALL).matches(t)) return ""   // "[Music]", "(silence)"
        return t.replace(Regex("\\s+"), " ")
    }

    private fun toWav(pcm: ByteArray, f: PcmFormat): ByteArray {
        val out = ByteArray(44 + pcm.size)
        val bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(f.channels.toShort())
        bb.putInt(f.sampleRate); bb.putInt(f.sampleRate * f.channels * 2); bb.putShort((f.channels * 2).toShort()); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return out
    }
}
