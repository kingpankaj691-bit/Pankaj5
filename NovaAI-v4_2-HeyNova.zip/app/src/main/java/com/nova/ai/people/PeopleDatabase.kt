package com.nova.ai.people

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.SkipQueryVerification
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PeopleDao {
    @Transaction @Query("SELECT * FROM persons ORDER BY lastInteraction DESC")
    fun observeAll(): Flow<List<PersonWithData>>

    @Transaction @Query("SELECT * FROM persons ORDER BY lastInteraction DESC")
    suspend fun all(): List<PersonWithData>

    @Insert suspend fun insertPerson(p: PersonEntity): Long
    @Update suspend fun updatePerson(p: PersonEntity)
    @Query("DELETE FROM persons WHERE personId = :id") suspend fun deletePerson(id: Long)
    @Query("DELETE FROM persons") suspend fun deleteAllPersons()

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAlias(a: AliasEntity): Long
    @Query("UPDATE OR IGNORE aliases SET personId = :to WHERE personId = :from") suspend fun moveAliases(from: Long, to: Long)

    @Insert suspend fun insertMemory(m: PersonMemoryEntity): Long
    @Update suspend fun updateMemory(m: PersonMemoryEntity)
    @Query("DELETE FROM person_memories WHERE memoryId = :id") suspend fun deleteMemory(id: Long)
    @Query("DELETE FROM person_memories WHERE personId = :id") suspend fun deleteMemoriesFor(id: Long)
    @Query("UPDATE person_memories SET personId = :to WHERE personId = :from") suspend fun moveMemories(from: Long, to: Long)
    @Query("DELETE FROM person_memories WHERE expiresAt > 0 AND expiresAt < :now") suspend fun purgeExpired(now: Long): Int

    @Query("SELECT COUNT(*) FROM blocked_patterns WHERE hash = :h") suspend fun blockedCount(h: String): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun block(b: BlockedEntity)
    @Query("DELETE FROM blocked_patterns") suspend fun clearBlocked()
}

/** SkipQueryVerification avoids Room's build-time SQLite JDBC check, which fails on some ARM/Termux setups. Queries are simple and runtime-checked. */
@SkipQueryVerification
@Database(entities = [PersonEntity::class, AliasEntity::class, PersonMemoryEntity::class, BlockedEntity::class], version = 1, exportSchema = false)
abstract class PeopleDatabase : RoomDatabase() {
    abstract fun dao(): PeopleDao

    companion object {
        @Volatile private var inst: PeopleDatabase? = null
        fun get(ctx: Context): PeopleDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, PeopleDatabase::class.java, "nova_people.db").build().also { inst = it }
        }
    }
}
