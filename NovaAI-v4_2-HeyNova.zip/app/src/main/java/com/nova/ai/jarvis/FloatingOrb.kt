package com.nova.ai.jarvis

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import com.nova.ai.live.LiveSession
import com.nova.ai.suite.NovaSheet
import com.nova.ai.suite.ScreenTools
import com.nova.ai.voice.NovaSession
import com.nova.ai.voice.NovaVoiceForegroundService
import com.nova.ai.voice.OrbPhase
import com.nova.ai.voice.OrbPhases
import com.nova.ai.voice.VoiceState
import com.nova.ai.voice.VoiceStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

/**
 * The Galaxy Orb: the one floating overlay of Nova (there is no second overlay controller). A draggable circle over other apps.
 *
 * Its look follows [NovaSession.current]: IDLE = small still orb (or hidden), LISTENING / THINKING / SPEAKING = expanded orb with a
 * status label. With Hey Nova the orb appears when the wake phrase is heard and shrinks or hides when the conversation ends.
 * Tap: while Nova speaks it interrupts her, while listening or thinking it ends the conversation, when idle it opens Nova.
 * Long press: quick menu. Double tap (idle): optional quick action. Drag: move it; it snaps to the nearest screen edge and
 * stays inside the status bar, navigation bar and display cutout. The window is only as big as the orb, so taps everywhere else
 * go to the app underneath. Needs "Display over other apps" (you grant it in Android settings).
 */
class FloatingOrb(private val ctx: Context) {
    companion object {
        @Volatile var current: FloatingOrb? = null
        /** An on-screen task (screen agent, OCR, translate) is running: the orb shows "thinking". */
        @Volatile var processing = false
        const val PREF_DOUBLE = "orb_double_tap"
        val doubleChoices = listOf("none", "translate", "summary", "extract", "pause")
        fun doubleLabel(v: String) = when (v) { "translate" -> "Translate screen"; "summary" -> "Summarize screen"; "extract" -> "Extract text"; "pause" -> "Pause / resume mic"; else -> "Off (tap opens Nova immediately)" }

        /**
         * Settings test: plays listening, thinking and speaking on the real overlay (3 s each), then returns to normal.
         * Returns false when the overlay permission is missing.
         */
        fun demo(ctx: Context): Boolean {
            val app = ctx.applicationContext
            if (!Settings.canDrawOverlays(app)) return false
            val live = current
            val orb = live ?: FloatingOrb(app).also { it.temporary = true; it.show() }
            CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
                try {
                    for (p in listOf(OrbPhase.LISTENING, OrbPhase.THINKING, OrbPhase.SPEAKING)) { NovaSession.forced.value = p; delay(3000) }
                } finally {
                    NovaSession.forced.value = null
                    if (orb.temporary) { delay(350); orb.hide() }
                }
            }
            return true
        }
    }

    private val app = ctx.applicationContext
    private val jp = JarvisPrefs(app)
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val dm = app.resources.displayMetrics
    private var view: GalaxyOrbView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var scope: CoroutineScope? = null
    private var lastPhase = OrbPhase.IDLE
    private var frac = 0f                        // 0 = small orb, 1 = expanded orb with label
    private var sizeAnim: ValueAnimator? = null
    @Volatile private var temporary = false

    // sizes follow the screen: ~52 dp small, ~132 dp expanded on a 360 dp wide phone
    private val scale = (min(dm.widthPixels, dm.heightPixels) / dm.density / 360f).coerceIn(0.85f, 1.35f)
    private val smallPx = (52 * dm.density * scale).toInt()
    private val bigPx = (132 * dm.density * scale).toInt()
    private val labelPx = (30 * dm.density * scale).toInt()
    private val margin = (6 * dm.density).toInt()

    fun canShow() = Settings.canDrawOverlays(app)

    private fun doubleAction(): String = app.getSharedPreferences("nova_prefs", Context.MODE_PRIVATE).getString(PREF_DOUBLE, "none") ?: "none"

    private fun runQuick(action: String) {
        when (action) {
            "translate" -> ScreenTools.translate(ctx, "Hindi")
            "summary" -> ScreenTools.summarize(ctx)
            "extract" -> ScreenTools.extract(ctx)
            "pause" -> try { if (VoiceState.paused.value) NovaVoiceForegroundService.resume(ctx) else NovaVoiceForegroundService.pause(ctx) } catch (x: Exception) { }
        }
    }

    // ───────── lifecycle ─────────

    /** Starts following the voice state. The window itself appears only when the phase (or the "keep a small orb" setting) asks for it. */
    fun show() {
        if (scope != null) return
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        scope = s
        current = this
        com.nova.ai.suite.NetState.start(app) { refresh() }
        s.launch { NovaSession.awake.collect { recompute() } }
        s.launch { NovaSession.busy.collect { recompute() } }
        s.launch { NovaSession.forced.collect { recompute() } }
        s.launch { VoiceState.running.collect { recompute() } }
        s.launch { VoiceState.paused.collect { recompute() } }
        s.launch { VoiceState.speaking.collect { recompute() } }
        s.launch { VoiceState.status.collect { recompute() } }
        s.launch { VoiceState.problem.collect { recompute() } }
        s.launch { LiveSession.state.collect { recompute() } }
        recompute()
    }

    /** Called whenever Nova's state changes (also by ScreenAgent / OCR through [processing]). */
    fun refresh() { main.post { recompute() } }

    fun hide() {
        scope?.cancel(); scope = null
        sizeAnim?.cancel(); sizeAnim = null
        view?.let { v -> v.setPhase(OrbPhase.IDLE); try { wm.removeView(v) } catch (e: Exception) { } }
        view = null; lp = null; frac = 0f; lastPhase = OrbPhase.IDLE
        com.nova.ai.suite.NetState.stop(app)
        if (current === this) current = null
    }

    private fun reducedNow(): Boolean {
        if (jp.orbReduced || jp.batterySaver || com.nova.ai.live.LivePrefs.orbLite(app)) return true
        return try { (app.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
    }

    private fun recompute() {
        if (scope == null) return
        val p = NovaSession.current()
        val wanted = p != OrbPhase.IDLE || jp.orbIdleMinimized
        if (!wanted) { detach(); lastPhase = p; return }
        if (!canShow()) return
        val v = view ?: attach(p != OrbPhase.IDLE) ?: return
        v.reduced = reducedNow()
        v.problem = VoiceState.problem.value.isNotBlank()
        v.micOn = VoiceState.running.value && !VoiceState.paused.value && VoiceState.status.value != VoiceStatus.Interrupted
        v.online = com.nova.ai.suite.NetState.online
        v.label = OrbPhases.label(p)
        if (p != lastPhase) {
            if (lastPhase == OrbPhase.IDLE && p == OrbPhase.LISTENING && jp.orbHaptics) buzz(v)
            animateTo(if (p == OrbPhase.IDLE) 0f else 1f)
        }
        lastPhase = p
        v.setPhase(p)
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31) (app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    private fun buzz(v: View) {
        try {
            val vib = vibrator()
            if (vib.hasVibrator()) vib.vibrate(VibrationEffect.createOneShot(28, 110)) else v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        } catch (e: Exception) { }
    }

    // ───────── window ─────────

    private fun widthFor(f: Float) = (smallPx + (bigPx - smallPx) * f).toInt()
    private fun heightFor(f: Float) = widthFor(f) + (labelPx * f).toInt()

    /** Status bar, navigation bar and display cutout, so the orb never hides behind them. Order: left, top, right, bottom. */
    @Suppress("DEPRECATION")
    private fun insets(v: View?): IntArray {
        val wi = v?.rootWindowInsets
        if (wi != null) {
            if (Build.VERSION.SDK_INT >= 30) {
                val i = wi.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                return intArrayOf(i.left, i.top, i.right, i.bottom)
            }
            return intArrayOf(wi.systemWindowInsetLeft, wi.systemWindowInsetTop, wi.systemWindowInsetRight, wi.systemWindowInsetBottom)
        }
        val id = app.resources.getIdentifier("status_bar_height", "dimen", "android")
        return intArrayOf(0, if (id > 0) app.resources.getDimensionPixelSize(id) else (24 * dm.density).toInt(), 0, 0)
    }

    private fun clamp(p: WindowManager.LayoutParams, v: View?) {
        val ins = insets(v)
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val minX = ins[0] + margin; val maxX = max(minX, sw - ins[2] - p.width - margin)
        val minY = ins[1] + margin; val maxY = max(minY, sh - ins[3] - p.height - margin)
        p.x = p.x.coerceIn(minX, maxX); p.y = p.y.coerceIn(minY, maxY)
    }

    private fun save(p: WindowManager.LayoutParams) { jp.orbX = p.x + widthFor(frac) / 2; jp.orbY = p.y + widthFor(frac) / 2 }

    @SuppressLint("ClickableViewAccessibility")
    private fun attach(expanded: Boolean): GalaxyOrbView? {
        if (view != null) return view
        frac = if (expanded) 1f else 0f
        val w = widthFor(frac); val h = heightFor(frac)
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            // saved orb centre, or the right edge about a third of the way down
            val cx = if (jp.orbX >= 0) jp.orbX else dm.widthPixels - smallPx / 2 - margin
            val cy = if (jp.orbY >= 0) jp.orbY else dm.heightPixels / 3
            x = cx - w / 2; y = cy - w / 2
        }
        val v = GalaxyOrbView(app)
        v.onConfig = { main.post { lp?.let { clampAndApply(it) } } }
        installTouch(v, p)
        clamp(p, null)
        v.alpha = 0f
        return try {
            wm.addView(v, p)
            view = v; lp = p
            v.post { lp?.let { clampAndApply(it) } }          // real insets are known once attached
            v.animate().alpha(1f).setDuration(180).start()
            v
        } catch (e: Exception) { null }
    }

    private fun clampAndApply(p: WindowManager.LayoutParams) {
        val v = view ?: return
        clamp(p, v)
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
    }

    private fun detach() {
        val v = view ?: return
        sizeAnim?.cancel(); sizeAnim = null
        view = null; lp = null; frac = 0f
        v.setPhase(OrbPhase.IDLE)
        v.animate().alpha(0f).setDuration(160).withEndAction { try { wm.removeView(v) } catch (e: Exception) { } }.start()
    }

    /** Grows or shrinks the window around the orb's centre. */
    private fun animateTo(target: Float) {
        val p = lp ?: return
        val v = view ?: return
        sizeAnim?.cancel()
        val from = frac
        if (from == target) return
        val a = ValueAnimator.ofFloat(from, target).setDuration(240)
        a.interpolator = DecelerateInterpolator(1.6f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            val oldW = p.width
            frac = f
            p.width = widthFor(f); p.height = heightFor(f)
            p.x -= (p.width - oldW) / 2; p.y -= (p.width - oldW) / 2        // keep the centre where it is
            clamp(p, v)
            try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
        }
        sizeAnim = a
        a.start()
    }

    private fun snap(p: WindowManager.LayoutParams, v: View) {
        val ins = insets(v)
        val sw = dm.widthPixels
        val left = ins[0] + margin
        val right = sw - ins[2] - p.width - margin
        val targetX = if (p.x + p.width / 2 < sw / 2) left else max(left, right)
        val a = ValueAnimator.ofInt(p.x, targetX).setDuration(180)
        a.addUpdateListener { p.x = it.animatedValue as Int; try { wm.updateViewLayout(v, p) } catch (x: Exception) { } }
        a.start()
        save(p.also { it.x = targetX })
    }

    // ───────── touch ─────────

    @SuppressLint("ClickableViewAccessibility")
    private fun installTouch(v: GalaxyOrbView, p: WindowManager.LayoutParams) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longFired = false; var lastTapAt = 0L
        val longRun = Runnable { longFired = true; v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); NovaSheet.showMenu(ctx) }
        val tapRun = Runnable { NovaSheet.openNova(ctx) }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; longFired = false
                    main.postDelayed(longRun, 550)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && (Math.abs(e.rawX - downX) > 12 || Math.abs(e.rawY - downY) > 12)) { moved = true; main.removeCallbacks(longRun) }
                    if (moved) {
                        p.x = startX + (e.rawX - downX).toInt(); p.y = startY + (e.rawY - downY).toInt()
                        clamp(p, v)
                        try { wm.updateViewLayout(v, p) } catch (x: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (moved) snap(p, v)
                    else if (!longFired) onTap(tapRun, { lastTapAt }, { lastTapAt = it })
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longRun)
            }
            true
        }
    }

    private fun onTap(tapRun: Runnable, lastTap: () -> Long, setLastTap: (Long) -> Unit) {
        when (lastPhase) {
            OrbPhase.SPEAKING -> VoiceState.interruptSpeech()          // interrupt Nova
            OrbPhase.LISTENING, OrbPhase.THINKING -> NovaSession.end() // dismiss: the conversation closes and the orb shrinks
            OrbPhase.IDLE -> {
                val dbl = doubleAction()
                if (dbl == "none") NovaSheet.openNova(ctx)
                else {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastTap() < 320) { main.removeCallbacks(tapRun); setLastTap(0L); runQuick(dbl) }
                    else { setLastTap(now); main.postDelayed(tapRun, 320) }
                }
            }
        }
    }
}
