package com.nova.ai.ai

/** Gemini model lists for the pickers, plus name cleaning so a bad name can never reach the API. */
object ModelCatalog {
    class Entry(val id: String, val label: String)

    const val DEFAULT_CHAT = "gemini-3.5-flash"
    const val DEFAULT_LIVE = "gemini-3.8-live"
    const val DEFAULT_TTS = "gemini-3.8-flash-tts"
    /** Dedicated live speech-to-text model (Live API, responseModalities TEXT). Used only for recognition, never for answers. */
    const val DEFAULT_TRANSCRIBE = "gemini-3.5-transcribe-live"

    /** Chat, speech-to-text clips, web search, vision (generateContent). */
    val chat = listOf(
        Entry("gemini-3.8-flash", "Gemini 3.8 Flash"),
        Entry("gemini-3.7-flash", "Gemini 3.7 Flash"),
        Entry("gemini-3.6-flash", "Gemini 3.6 Flash"),
        Entry("gemini-3.5-flash", "Gemini 3.5 Flash"),
        Entry("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite"),
        Entry("gemini-3.1-pro-preview", "Gemini 3.1 Pro (preview)"),
        Entry("gemini-3-flash-preview", "Gemini 3 Flash (preview)"),
        Entry("gemini-2.5-pro", "Gemini 2.5 Pro"),
        Entry("gemini-2.5-flash", "Gemini 2.5 Flash"),
        Entry("gemini-2.5-flash-lite", "Gemini 2.5 Flash-Lite")
    )

    /** Live (WebSocket) speech models. */
    val live = listOf(
        Entry("gemini-3.8-live", "Gemini 3.8 Live"),
        Entry("gemini-3.8-live-extended-thinking", "Gemini 3.8 Live (extended thinking)"),
        Entry("gemini-3.5-transcribe-live", "Gemini 3.5 Transcribe Live"),
        Entry("gemini-3.1-flash-live-preview", "Gemini 3.1 Flash Live (preview)"),
        Entry("gemini-2.5-flash-native-audio-preview-12-2025", "Gemini 2.5 Flash Live (native audio)")
    )

    /** Text-to-speech models. */
    val tts = listOf(
        Entry("gemini-3.8-flash-tts", "Gemini 3.8 Flash TTS"),
        Entry("gemini-3.8-flash-lite-tts", "Gemini 3.8 Flash-Lite TTS"),
        Entry("gemini-3.1-flash-tts-preview", "Gemini 3.1 Flash TTS (preview)"),
        Entry("gemini-2.5-flash-preview-tts", "Gemini 2.5 Flash TTS"),
        Entry("gemini-2.5-pro-preview-tts", "Gemini 2.5 Pro TTS")
    )

    /**
     * Models Google has shut down. A saved one is NO LONGER replaced silently: the call fails with a clear "model not available,
     * choose another" message so the user stays in control of which model answers. Used only for hints.
     */
    private val retired = setOf("gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-3.1-flash-lite-preview", "gemini-3-pro-preview")

    fun isKnownRetired(id: String): Boolean = id in retired

    private val valid = Regex("^[a-z0-9][a-z0-9._-]{1,80}$")

    /**
     * Turns whatever was stored or typed into a safe model id: trims, lower-cases, drops a leading "models/",
     * turns spaces into dashes. Returns [fallback] only when the result still is not a syntactically valid id
     * (a valid id is never swapped for another model).
     */
    fun clean(raw: String?, fallback: String): String {
        var s = (raw ?: "").trim().lowercase().removePrefix("models/").trim().replace(Regex("\\s+"), "-")
        s = s.trim('-', '.', '_')
        return if (valid.matches(s)) s else fallback
    }

    fun labelOf(list: List<Entry>, id: String): String = list.firstOrNull { it.id == id }?.label ?: id
}
