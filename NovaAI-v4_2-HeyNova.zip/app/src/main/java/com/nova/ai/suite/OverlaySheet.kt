package com.nova.ai.suite

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.nova.ai.ui.GText
import com.nova.ai.ui.GlassButton
import com.nova.ai.ui.GlassCard
import com.nova.ai.ui.LocalGlass
import com.nova.ai.ui.MainActivity
import com.nova.ai.voice.NovaVoiceForegroundService
import com.nova.ai.voice.VoiceState

data class SheetAction(val label: String, val primary: Boolean = false, val run: () -> Unit)

private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store
    fun start() { controller.performRestore(null); registry.currentState = Lifecycle.State.RESUMED }
    fun stop() { registry.currentState = Lifecycle.State.DESTROYED; store.clear() }
}

/**
 * A bottom sheet drawn over the current app (answers, extracted text, translations, previews, confirmations) without leaving it.
 * Needs "Display over other apps". It never takes keyboard focus, never reads the screen by itself and is closed with the ✕ button.
 */
object NovaSheet {
    private val main = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private var owner: OverlayOwner? = null
    private var wm: WindowManager? = null

    private var title by mutableStateOf("")
    private var body by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var actions by mutableStateOf<List<SheetAction>>(emptyList())
    private var wave by mutableStateOf(false)

    fun canShow(ctx: Context) = Settings.canDrawOverlays(ctx)

    /** Shows or updates the sheet. Safe to call from any thread. Returns false when the overlay permission is missing. */
    fun show(ctx: Context, title: String, body: String, busy: Boolean = false, actions: List<SheetAction> = emptyList(), wave: Boolean = false): Boolean {
        if (!canShow(ctx)) return false
        val app = ctx.applicationContext
        main.post {
            this.title = title; this.body = body; this.busy = busy; this.actions = actions; this.wave = wave
            if (view == null) attach(app)
        }
        return true
    }

    fun update(body: String, busy: Boolean = false, actions: List<SheetAction>? = null) {
        main.post { this.body = body; this.busy = busy; if (actions != null) this.actions = actions }
    }

    fun hide() { main.post { detach() } }

    private fun attach(ctx: Context) {
        val manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val o = OverlayOwner().also { it.start() }
        val v = ComposeView(ctx)
        v.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        v.setViewTreeLifecycleOwner(o)
        v.setViewTreeViewModelStoreOwner(o)
        v.setViewTreeSavedStateRegistryOwner(o)
        v.setContent { SheetContent(ctx) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        try { manager.addView(v, lp); view = v; owner = o; wm = manager } catch (e: Exception) { o.stop() }
    }

    private fun detach() {
        LiveOcr.onSheetClosed()
        try { view?.let { wm?.removeView(it) } } catch (e: Exception) { }
        owner?.stop()
        view = null; owner = null; wm = null; title = ""; body = ""; busy = false; actions = emptyList(); wave = false
    }

    private fun copy(ctx: Context, text: String) {
        try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Nova", text)) } catch (e: Exception) { }
    }

    private fun share(ctx: Context, text: String) {
        try {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    @Composable
    private fun SheetContent(ctx: Context) {
        val g = LocalGlass.current
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            GlassCard(Modifier.fillMaxWidth(), strong = true) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        GText(title, size = 16.sp)
                        GText("✕", size = 18.sp, modifier = Modifier.padding(start = 16.dp).clickableNoRipple { hide() })
                    }
                    if (busy) GText("Working…", size = 12.sp, color = g.subtext)
                    if (wave) Waveform()
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) { GText(body, size = 14.sp) }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        actions.forEach { a -> GlassButton(a.label, { a.run() }, primary = a.primary) }
                        if (body.isNotBlank() && !busy) {
                            GlassButton("Copy", { copy(ctx, body) })
                            GlassButton("Share", { share(ctx, body) })
                        }
                    }
                }
            }
        }
    }

    /** Voice meter: 28 bars of the microphone level, refreshed with the level (about 12 times a second) only while shown. */
    @Composable
    private fun Waveform() {
        val level by VoiceLevel.level.collectAsState()
        val hist = remember { mutableStateListOf<Float>() }
        androidx.compose.runtime.LaunchedEffect(level) { hist.add(level); while (hist.size > 28) hist.removeAt(0) }
        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            hist.forEach { v -> androidx.compose.foundation.layout.Box(Modifier.width(6.dp).height((4 + 36 * v).dp).background(LocalGlass.current.accent, androidx.compose.foundation.shape.RoundedCornerShape(3.dp))) }
        }
    }

    /** The quick menu opened by long-pressing the orb. */
    fun showMenu(ctx: Context) {
        val paused = VoiceState.paused.value
        val items = listOf(
            SheetAction("Talk to Nova", true) { hide(); openNova(ctx) },
            SheetAction("Translate screen") { ScreenTools.translate(ctx, "Hindi") },
            SheetAction("Extract text") { ScreenTools.extract(ctx) },
            SheetAction("Summarize screen") { ScreenTools.summarize(ctx) },
            SheetAction(if (LiveOcr.running) "Stop Live OCR" else "Start Live OCR") { if (LiveOcr.running) LiveOcr.stop(ctx) else LiveOcr.start(ctx, null) },
            SheetAction("Voice meter") { show(ctx, "Listening", "Speak: the bars follow your voice.", false, listOf(SheetAction("Close", true) { hide() }), wave = true) },
            SheetAction("Stop workflow", false) { Workflows.cancel(); hide() },
            SheetAction(if (paused) "Resume mic" else "Pause mic") {
                try { if (VoiceState.paused.value) NovaVoiceForegroundService.resume(ctx) else NovaVoiceForegroundService.pause(ctx) } catch (e: Exception) { }
                hide()
            }
        )
        show(ctx, "Nova", "Choose an action. Screen actions read only the screen you are looking at, only now.", false, items)
    }

    fun openNova(ctx: Context) {
        try { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("listen", true)) } catch (e: Exception) { }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = MutableInteractionSource(), indication = null, onClick = onClick)
