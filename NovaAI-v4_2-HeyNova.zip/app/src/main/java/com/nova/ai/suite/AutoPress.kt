package com.nova.ai.suite

import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.screen.UiElement
import kotlinx.coroutines.delay

enum class PressResult { CLICKED, NOT_FOUND, AMBIGUOUS, NO_SERVICE }

/**
 * Presses buttons in another app through the accessibility service, by visible label. Used only by a workflow whose preview you
 * approved with the explicit "upload"/"send" choice. It acts only while the expected app is in front, never touches password fields,
 * stops when a label matches more than one place (ambiguous), and ends when the workflow is cancelled (orb menu > Stop workflow).
 */
object AutoPress {
    fun norm(s: String) = s.lowercase().replace('’', '\'').replace(Regex("\\s+"), " ").trim()

    fun matches(e: UiElement, label: String, exact: Boolean): Boolean {
        val l = norm(label)
        return listOf(e.text, e.desc).map { norm(it) }.filter { it.isNotBlank() }.any { if (exact) it == l else it.contains(l) }
    }

    private fun candidates(els: List<UiElement>, labels: List<String>, exact: Boolean): List<UiElement> =
        els.filter { !it.password && it.enabled && labels.any { l -> matches(it, l, exact) } }
            .distinctBy { Triple(it.bounds.left, it.bounds.top, it.bounds.right) }

    /** Does any visible element carry this label right now? */
    fun visible(pkgPart: String, label: String, exact: Boolean = false): Boolean {
        val s = NovaAccessibilityService.instance?.snapshot() ?: return false
        return s.pkg.contains(pkgPart) && candidates(s.elements, listOf(label), exact).isNotEmpty()
    }

    /**
     * Finds an element by label (exact match first, then contains) in the app whose package contains [pkgPart] and clicks it.
     * Scrolls down a few times when it is not visible. If [unique] and several different elements match, nothing is clicked.
     */
    suspend fun click(pkgPart: String, labels: List<String>, unique: Boolean = false, timeoutMs: Long = 9000, scrolls: Int = 3): PressResult {
        val svc = NovaAccessibilityService.instance ?: return PressResult.NO_SERVICE
        val start = System.currentTimeMillis()
        var scrolled = 0; var round = 0
        while (System.currentTimeMillis() - start < timeoutMs) {
            val snap = svc.snapshot()
            if (snap != null && snap.pkg.contains(pkgPart)) {
                var found = candidates(snap.elements, labels, true)
                if (found.isEmpty()) found = candidates(snap.elements, labels, false)
                if (found.size > 1 && unique) return PressResult.AMBIGUOUS
                if (found.isNotEmpty()) {
                    val ok = svc.clickElement(found.first())
                    if (ok) return PressResult.CLICKED
                }
                round++
                if (round % 3 == 0 && scrolled < scrolls) { svc.scroll(true); scrolled++ }
            }
            delay(600)
        }
        return PressResult.NOT_FOUND
    }

    /** Types [text] into the first visible search field of the app. */
    suspend fun search(pkgPart: String, text: String): Boolean {
        val svc = NovaAccessibilityService.instance ?: return false
        val snap = svc.snapshot() ?: return false
        if (!snap.pkg.contains(pkgPart)) return false
        val field = snap.editable.firstOrNull { !it.password && norm(it.hint + " " + it.desc + " " + it.text).contains("search") } ?: return false
        return svc.setTextOn(field, text)
    }

    // ───────── YouTube: details -> next x3 -> visibility -> upload ─────────
    suspend fun youtubePublish(visibility: String, madeForKids: Boolean): String {
        val yt = "youtube"
        val kids = if (madeForKids) listOf("yes, it's made for kids") else listOf("no, it's not made for kids")
        fail(click(yt, kids, scrolls = 4))?.let { return "Couldn't set the audience question ($it). Nothing was uploaded." }
        delay(500)
        var tries = 0
        while (!visible(yt, "save or publish") && tries < 4) {
            fail(click(yt, listOf("next"), timeoutMs = 6000))?.let { return "Couldn't continue past the details page ($it). Nothing was uploaded." }
            delay(1300); tries++
        }
        fail(click(yt, listOf(visibility.lowercase()), timeoutMs = 6000))?.let { return "Couldn't choose $visibility ($it). Nothing was uploaded." }
        delay(500)
        for (label in listOf("upload", "publish", "save")) {
            val r = click(yt, listOf(label), timeoutMs = 3500, scrolls = 0)
            if (r == PressResult.CLICKED) return "Pressed \"$label\" with visibility $visibility. YouTube shows the upload progress in its notification."
        }
        return "I reached the last page but couldn't find the Upload button. Press it yourself."
    }

    // ───────── Instagram: (choose Reels/Feed) -> Next ... -> caption -> Share ─────────
    suspend fun instagramPublish(kind: String, caption: String, press: Boolean): String {
        val ig = "instagram"
        click("", listOf(kind), timeoutMs = 3500, scrolls = 0)          // Android's own chooser, if it appears; ignored otherwise
        delay(1500)
        for (i in 0 until 7) {
            val svc = NovaAccessibilityService.instance ?: return "Accessibility is off."
            val snap = svc.snapshot()
            if (snap != null && snap.pkg.contains(ig)) {
                val field = snap.editable.firstOrNull { !it.password && norm(it.hint + " " + it.desc + " " + it.text).contains("caption") }
                if (field != null) {
                    if (!svc.setTextOn(field, caption)) return "I found the caption box but couldn't type in it. The caption is on your clipboard."
                    delay(700)
                    if (!press) return "Caption filled. Check it and press Share yourself."
                    val r = click(ig, listOf("share"), timeoutMs = 5000, scrolls = 1)
                    return if (r == PressResult.CLICKED) "Caption filled and pressed Share. Instagram shows progress at the top of your feed/profile." else "Caption filled, but I couldn't find Share. Press it yourself."
                }
                val n = click(ig, listOf("next"), timeoutMs = 5000, scrolls = 0)
                if (n != PressResult.CLICKED) return "I couldn't get from the editor to the caption page. Continue yourself; the caption is on your clipboard."
                delay(1500)
            } else delay(1000)
        }
        return "I couldn't reach the caption page. Continue yourself; the caption is on your clipboard."
    }

    // ───────── WhatsApp (or any share target): pick recipient -> send ─────────
    suspend fun sendTo(pkgPart: String, recipient: String): String {
        var r = click(pkgPart, listOf(recipient), unique = true, timeoutMs = 5000, scrolls = 0)
        if (r == PressResult.NOT_FOUND) {
            if (search(pkgPart, recipient)) { delay(900); r = click(pkgPart, listOf(recipient), unique = true, timeoutMs = 5000, scrolls = 0) }
        }
        when (r) {
            PressResult.AMBIGUOUS -> return "More than one chat matches \"$recipient\", so I stopped. Pick the chat yourself and press Send."
            PressResult.CLICKED -> {}
            PressResult.NO_SERVICE -> return "Accessibility is off, so I can't press anything."
            PressResult.NOT_FOUND -> return "I couldn't find \"$recipient\". Pick the chat yourself and press Send."
        }
        delay(1000)
        var sent = 0
        for (i in 0 until 2) {                       // the preview page "Send", then a confirmation dialog if shown
            val s = click(pkgPart, listOf("send"), timeoutMs = 4000, scrolls = 0)
            if (s == PressResult.CLICKED) { sent++; delay(900) } else break
        }
        return if (sent > 0) "Pressed Send to $recipient." else "Opened the chat but couldn't find Send. Press it yourself."
    }

    private fun fail(r: PressResult): String? = when (r) {
        PressResult.CLICKED -> null
        PressResult.NOT_FOUND -> "button not found"
        PressResult.AMBIGUOUS -> "label matched several places"
        PressResult.NO_SERVICE -> "Accessibility is off"
    }

    /** Recipient named in a command: "Rahul ko latest video bhejo", "send the latest video to Rahul on WhatsApp". */
    fun recipientIn(t: String): String? {
        val low = t.lowercase().trim()
        val patterns = listOf(
            Regex("""(?:video|export|exported video)\s+(.+?)\s+ko\b"""),
            Regex("""^(.+?)\s+ko\s+(?:latest|last|recent)"""),
            Regex("""\bto\s+([a-z0-9 ]+?)(?:\s+(?:on|via|in|using)\s+\w+)?$""")
        )
        val stop = setOf("whatsapp", "telegram", "instagram", "youtube", "gmail", "me", "mujhe", "usko", "isko", "unko")
        for (p in patterns) {
            val m = p.find(low) ?: continue
            val name = m.groupValues[1].trim().split(" ").filter { it !in stop }.joinToString(" ")
            if (name.isNotBlank() && name.length in 2..30) return name.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
        }
        return null
    }
}
