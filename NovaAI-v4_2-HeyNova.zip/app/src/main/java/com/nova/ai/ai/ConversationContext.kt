package com.nova.ai.ai

/** Current conversation = recent messages; short-term context = temporary memories; this holds the compressed older part. */
class ConversationContext {
    var summary: String = ""
    var upTo: Int = 0
    var compressing: Boolean = false
    fun reset() { summary = ""; upTo = 0; compressing = false }
}

object ContextCompressor {
    private val keep = Regex("(?i)\\b(decid|let's|lets|will|prefer|want|need|must|task|project|error|fix|remember|goal|plan|deadline|use|chose|choose)")

    /** Local extractive summary: keeps decisions, preferences, tasks and unresolved questions; drops chatter. */
    fun local(old: String, userLines: List<String>): String {
        val kept = userLines.map { it.trim() }.filter { it.length > 8 && (keep.containsMatchIn(it) || it.endsWith("?")) }
            .map { "- " + it.take(140) }
        return (old + "\n" + kept.joinToString("\n")).trim().takeLast(1200)
    }

    const val SYSTEM = "Summarize this conversation for future context in under 120 words. Keep decisions, user preferences, the current task and unresolved questions. Drop repetition and small talk. Plain text, no markdown."
}
