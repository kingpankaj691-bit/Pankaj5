package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.ai.ModelCatalog

/**
 * Tap to open a list of models and pick one. A "Custom" box at the bottom accepts any other model id;
 * it is cleaned (spaces, "models/" prefix) before it is saved.
 * With [blankLabel] set, a first row lets the user clear the choice (used for "same as AI model").
 */
@Composable
internal fun ModelPicker(
    current: String,
    options: List<ModelCatalog.Entry>,
    onPick: (String) -> Unit,
    blankLabel: String? = null
) {
    val g = LocalGlass.current
    var open by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf("") }
    val shown = if (current.isBlank() && blankLabel != null) blankLabel else ModelCatalog.labelOf(options, current)

    GlassButton("$shown  ▾", { open = true }, Modifier.fillMaxWidth())
    if (current.isNotBlank() && shown != current) GText(current, size = 12.sp, color = g.subtext)

    if (open) GlassDialog({ open = false }, "Choose a model") {
        Column(
            Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (blankLabel != null) GlassButton(blankLabel, { onPick(""); open = false }, Modifier.fillMaxWidth(), primary = current.isBlank())
            options.forEach { e ->
                GlassButton(e.label, { onPick(e.id); open = false }, Modifier.fillMaxWidth(), primary = e.id == current)
            }
            GText("Custom model id", size = 12.sp, color = g.subtext)
            GlassTextField(custom, { custom = it }, Modifier.fillMaxWidth(), placeholder = "for example gemini-3.8-flash")
            GlassButton("Use custom", {
                if (custom.isNotBlank()) { onPick(custom); open = false }
            }, Modifier.fillMaxWidth(), enabled = custom.isNotBlank())
        }
    }
}
