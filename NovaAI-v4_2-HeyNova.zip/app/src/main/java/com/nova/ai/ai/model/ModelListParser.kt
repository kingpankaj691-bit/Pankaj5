package com.nova.ai.ai.model

import org.json.JSONArray
import org.json.JSONObject

/** Parses the response of GET /v1beta/models (and Nova's own cached copy, which is stored in the same shape). */
object ModelListParser {
    class Page(val models: List<GeminiModel>, val nextPageToken: String?)

    fun parsePage(raw: String): Page = parsePage(JSONObject(raw))

    fun parsePage(j: JSONObject): Page {
        val arr = j.optJSONArray("models") ?: JSONArray()
        val out = ArrayList<GeminiModel>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("name").removePrefix("models/").trim()
            if (id.isEmpty()) continue
            val methods = HashSet<String>()
            o.optJSONArray("supportedGenerationMethods")?.let { m -> for (k in 0 until m.length()) methods.add(m.optString(k)) }
            out.add(
                GeminiModel(
                    id = id,
                    displayName = o.optString("displayName"),
                    description = o.optString("description").take(240),
                    inputTokenLimit = o.optInt("inputTokenLimit", 0),
                    outputTokenLimit = o.optInt("outputTokenLimit", 0),
                    methods = methods,
                    version = o.optString("version"),
                    thinking = o.optBoolean("thinking", false),
                    maxTemperature = if (o.has("maxTemperature")) o.optDouble("maxTemperature") else null
                )
            )
        }
        val next = j.optString("nextPageToken").takeIf { it.isNotEmpty() }
        return Page(out, next)
    }

    fun toJson(list: List<GeminiModel>): String {
        val arr = JSONArray()
        list.forEach { m ->
            val o = JSONObject()
                .put("name", "models/" + m.id)
                .put("displayName", m.displayName)
                .put("description", m.description)
                .put("inputTokenLimit", m.inputTokenLimit)
                .put("outputTokenLimit", m.outputTokenLimit)
                .put("version", m.version)
                .put("thinking", m.thinking)
            if (m.maxTemperature != null) o.put("maxTemperature", m.maxTemperature)
            val methods = JSONArray()
            m.methods.forEach { methods.put(it) }
            o.put("supportedGenerationMethods", methods)
            arr.put(o)
        }
        return JSONObject().put("models", arr).toString()
    }
}
