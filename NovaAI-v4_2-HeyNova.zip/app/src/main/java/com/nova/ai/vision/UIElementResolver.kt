package com.nova.ai.vision

import com.nova.ai.screen.Kind
import com.nova.ai.screen.Match
import com.nova.ai.screen.ScreenSearch
import com.nova.ai.screen.ScreenSnapshot

sealed class Resolution {
    /** One or more accessibility matches (ranked). */
    data class Nodes(val matches: List<Match>) : Resolution()
    /** A point found visually in a screenshot. */
    data class Point(val label: String, val x: Int, val y: Int, val confidence: Float) : Resolution()
    data class None(val reason: String) : Resolution()
}

/**
 * ScreenCaptureManager → ScreenFrame → VisionAnalyzer → UIElementResolver → ScreenActionExecutor.
 * Accessibility first (exact, private, cheap); a screenshot is used only for visual descriptions (colour, icon, picture)
 * or when the accessibility tree has nothing, and only if a vision session is active.
 */
class UIElementResolver(private val vision: VisionAnalyzer) {
    private val visualWords = Regex("(?i)\\b(blue|red|green|yellow|orange|purple|pink|black|white|grey|gray|neela|laal|hara|peela|kala|safed|color|colour|rang|icon|logo|picture|photo|image|tasveer|emoji|arrow)\\b")

    fun needsVision(q: String) = visualWords.containsMatchIn(q)

    suspend fun resolve(query: String, snap: ScreenSnapshot?, kind: Kind = ScreenSearch.kindOf(query)): Resolution {
        val visual = needsVision(query)
        if (!visual && snap != null) {
            val m = ScreenSearch.find(snap, query, kind)
            if (m.isNotEmpty()) return Resolution.Nodes(m)
        }
        if (ScreenCaptureManager.active) {
            val frame = ScreenCaptureManager.capture()
            if (frame != null) {
                try {
                    val (loc, err) = vision.locate(frame, query)
                    if (loc != null) return Resolution.Point(loc.label, loc.x, loc.y, loc.confidence)
                    if (err != null) return Resolution.None(err)
                } finally { frame.recycle() }
            }
        }
        if (snap != null && visual) {
            val m = ScreenSearch.find(snap, query, kind)
            if (m.isNotEmpty()) return Resolution.Nodes(m)
        }
        return Resolution.None(
            if (visual && !ScreenCaptureManager.active) "That needs me to look at the screen visually. Start Screen Vision in Screen Assistant and ask again."
            else "I couldn't find \"$query\" on this screen."
        )
    }
}
