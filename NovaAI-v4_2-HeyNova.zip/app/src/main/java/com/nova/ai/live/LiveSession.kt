package com.nova.ai.live

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class LiveOrbState { IDLE, LISTENING, THINKING, SPEAKING, CONNECTING, ERROR }

/** Screen-independent live state of the two-way voice session, for every screen (orb, edge glow, debugger). */
object LiveSession {
    val state = MutableStateFlow(LiveOrbState.IDLE)
    val amplitude = MutableStateFlow(0f)
    val muted = MutableStateFlow(false)
    val statusText = MutableStateFlow("")
    val isActive = MutableStateFlow(false)
    val lastError = MutableStateFlow("")
    val currentPersonality = MutableStateFlow("")
    val currentLanguage = MutableStateFlow("auto")
    val detectedLanguage = MutableStateFlow("")
    val vadActive = MutableStateFlow(false)
    /** Loudness 0..1 of what the microphone is really capturing (drives the orb while you speak). */
    val micLevel = MutableStateFlow(0f)
    /** True while the engine is re-opening a dropped connection. */
    val reconnecting = MutableStateFlow(false)
    val latency = VoiceLatencyTracker()
    @Volatile internal var refreshHook: (() -> Unit)? = null

    fun toggleMute() { muted.value = !muted.value; statusText.value = if (muted.value) "Mic muted" else "Listening" }

    /** Live cannot change the system instruction mid-session: the engine reconnects with a recap. Call after settings change. */
    fun refreshInstructions() { refreshHook?.invoke() }

    internal fun reset() {
        state.value = LiveOrbState.IDLE; amplitude.value = 0f; isActive.value = false; vadActive.value = false; statusText.value = ""
        micLevel.value = 0f; reconnecting.value = false
    }
}

/** Settings of the two-way voice that are not part of Prefs. */
object LivePrefs {
    val VOICES = listOf("Aoede", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Zephyr")
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("nova_live", Context.MODE_PRIVATE)
    fun assistantName(c: Context) = sp(c).getString("assistant_name", "Nova")?.ifBlank { "Nova" } ?: "Nova"
    fun setAssistantName(c: Context, v: String) { sp(c).edit().putString("assistant_name", v.trim().take(24)).apply(); LiveSession.refreshInstructions() }
    fun voiceName(c: Context) = sp(c).getString("voice_name", "Aoede")?.takeIf { it in VOICES } ?: "Aoede"
    fun setVoiceName(c: Context, v: String) { sp(c).edit().putString("voice_name", v).apply(); LiveSession.refreshInstructions() }
    /** 3D orb, 3D splash and edge glow. Off by default so the liquid glass look stays exactly as it is. */
    fun fx3d(c: Context) = sp(c).getBoolean("fx3d", false)
    fun setFx3d(c: Context, v: Boolean) { sp(c).edit().putBoolean("fx3d", v).apply() }
    /** Reduced-effects Galaxy Orb (fewer particles, 20 fps, no nebula layers). On by default for low-RAM phones. */
    fun orbLite(c: Context): Boolean {
        val def = (c.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager)?.isLowRamDevice == true
        return sp(c).getBoolean("orb_lite", def)
    }
    fun setOrbLite(c: Context, v: Boolean) { sp(c).edit().putBoolean("orb_lite", v).apply() }
}

/** What was said in the two-way voice, for the chat list. Fragments of one turn arrive separately; [turnEnd] closes the turn. */
object LiveTranscripts {
    class Event(val fromUser: Boolean, val text: String)
    val events = MutableSharedFlow<Event>(extraBufferCapacity = 64)
    val turnEnd = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
}
