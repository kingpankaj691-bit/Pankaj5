package com.nova.ai.developer

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CrashLog(val name: String, val at: Long, val text: String)

/**
 * Keeps the last few crash reports on this phone, with secrets removed. Nothing is uploaded: you decide whether to copy a log,
 * ask the AI to explain it, or delete it. A crash report contains the error and the app/device version, not your messages.
 */
object DiagnosticsManager {
    private const val MAX = 5
    private val rules = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{20,}") to "[api-key]",
        Regex("sk-[A-Za-z0-9_\\-]{16,}") to "[api-key]",
        Regex("(?i)bearer\\s+[A-Za-z0-9._\\-]+") to "Bearer [token]",
        Regex("(?i)([?&](?:key|api_key|apikey|token|password|pass)=)[^&\\s]+") to "$1[hidden]",
        Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}") to "[email]",
        Regex("\\+?\\d[\\d\\s\\-]{8,}\\d") to "[number]"
    )

    fun sanitize(s: String): String = rules.fold(s) { acc, (re, rep) -> re.replace(acc, rep) }

    /** Chains in front of Android's normal crash handling, so the app still closes the usual way. */
    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try { write(app, thread, e) } catch (_: Throwable) { }
            previous?.uncaughtException(thread, e)
        }
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "diagnostics").also { it.mkdirs() }

    private fun write(ctx: Context, thread: Thread, e: Throwable) {
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (x: Exception) { "?" }
        val body = "Nova $v · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Thread: ${thread.name}\n\n" + sw.toString().take(12000)
        val f = File(dir(ctx), "crash-${System.currentTimeMillis()}.txt")
        f.writeText(sanitize(body))
        dir(ctx).listFiles()?.sortedByDescending { it.name }?.drop(MAX)?.forEach { it.delete() }
    }

    fun crashes(ctx: Context): List<CrashLog> =
        dir(ctx).listFiles()?.filter { it.name.startsWith("crash-") }?.sortedByDescending { it.name }?.map {
            CrashLog(it.name, it.name.removePrefix("crash-").removeSuffix(".txt").toLongOrNull() ?: it.lastModified(), it.readText())
        } ?: emptyList()

    fun clear(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() } }

    fun summary(ctx: Context): String {
        val c = crashes(ctx)
        if (c.isEmpty()) return "No crashes recorded."
        val first = c.first().text.lines().firstOrNull { it.contains("Exception") || it.contains("Error") }?.take(140) ?: "see Developer Tools"
        return "${c.size} crash report${if (c.size > 1) "s" else ""} saved. Latest: " +
            SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(c.first().at)) + " - $first"
    }
}
