package com.nova.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.ai.SwitchingProvider
import com.nova.ai.developer.CodeAssistant
import com.nova.ai.developer.CrashLog
import com.nova.ai.developer.DiagnosticsManager
import com.nova.ai.developer.PatchReviewManager
import com.nova.ai.developer.PatchStatus
import com.nova.ai.developer.UpdateInfo
import com.nova.ai.developer.UpdateManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Diagnostics, Patch Review and Updates. Everything here is read, copied or approved by you; nothing is applied automatically. */
@Composable
fun DevToolsScreen(vm: NovaViewModel, onBack: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current.applicationContext
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val p = vm.prefs
    val patches = remember { PatchReviewManager(ctx) }
    val updater = remember { UpdateManager(ctx) }
    var rev by remember { mutableIntStateOf(0) }
    val crashes = remember(rev) { DiagnosticsManager.crashes(ctx) }
    val patchList = remember(rev) { patches.list() }
    var open by remember { mutableStateOf<CrashLog?>(null) }
    var openPatch by remember { mutableStateOf<Long?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var url by remember { mutableStateOf(p.updateUrl) }
    var info by remember { mutableStateOf<UpdateInfo?>(null) }
    var verified by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIconButton("‹", "Back", onBack)
            GText("Developer Tools", size = 22.sp, weight = FontWeight.SemiBold)
        }
        GText("Nova shows, explains and stores things here for you to review. It never rewrites or runs its own code, and never uploads logs by itself.", size = 12.sp, color = g.subtext)

        GlassSettingSection("Diagnostics") {
            if (crashes.isEmpty()) GText("No crashes recorded. Reports appear here after Nova closes unexpectedly (secrets are removed).", size = 12.sp, color = g.subtext)
            crashes.forEach { c ->
                GlassListItem(fmt.format(Date(c.at)), c.text.lines().firstOrNull { it.contains("Exception") || it.contains("Error") }?.take(90) ?: "Crash report", onClick = { open = c })
            }
            open?.let { c ->
                GText(c.text.take(3000), size = 11.sp, color = g.subtext)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Copy log", { clip.setText(AnnotatedString(c.text)); msg = "Log copied." })
                    GlassButton(if (busy) "Analyzing…" else "Analyze with AI", {
                        if (!busy) {
                            if (!p.hasActiveKey() || p.localOnly || !p.aiEnabled) msg = "AI analysis needs an API key, AI on, and local-only off. This sends the sanitized log to your chosen AI provider."
                            else { busy = true; msg = "Analyzing…"
                                scope.launch {
                                    val text = CodeAssistant.analyze(SwitchingProvider(p), c.text)
                                    if (!text.startsWith("⚠")) { patches.add("Fix for crash " + fmt.format(Date(c.at)), text); msg = "Suggestion saved under Patch review." } else msg = text
                                    busy = false; rev++
                                } }
                        }
                    }, primary = true)
                }
            }
            if (crashes.isNotEmpty()) GlassButton("Delete all crash logs", { DiagnosticsManager.clear(ctx); open = null; rev++ })
        }

        GlassSettingSection("Patch review") {
            GText("AI suggestions are text only. \"Applied\" means you changed the code yourself in AndroidIDE.", size = 12.sp, color = g.subtext)
            if (patchList.isEmpty()) GText("Nothing to review.", size = 12.sp, color = g.subtext)
            patchList.forEach { pt ->
                GlassListItem(pt.title, pt.status.name.lowercase() + " · " + fmt.format(Date(pt.at)), onClick = { openPatch = if (openPatch == pt.id) null else pt.id })
                if (openPatch == pt.id) {
                    GText(pt.body.take(6000), size = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Copy", { clip.setText(AnnotatedString(pt.body)); msg = "Copied." })
                        GlassButton("Reviewed", { patches.setStatus(pt.id, PatchStatus.REVIEWED); rev++ })
                        GlassButton("I applied it", { patches.setStatus(pt.id, PatchStatus.APPLIED); rev++ })
                        GlassButton("Reject", { patches.setStatus(pt.id, PatchStatus.REJECTED); rev++ })
                        GlassButton("Delete", { patches.delete(pt.id); openPatch = null; rev++ })
                    }
                }
            }
        }

        GlassSettingSection("Updates") {
            GText("Nova checks a metadata file you host over HTTPS, downloads the APK only after you approve, checks its SHA-256 and that it is signed with the same key as this app, then hands it to Android's installer. It never installs silently.", size = 12.sp, color = g.subtext)
            GlassListItem("Installed version", "code ${updater.installedVersionCode()}")
            GlassTextField(url, { url = it; p.updateUrl = it.trim() }, Modifier.fillMaxWidth(), placeholder = "https://your-site/nova-update.json")
            GlassButton(if (busy) "Working…" else "Check for update", {
                if (!busy) {
                    busy = true; verified = false; info = null; msg = "Checking…"
                    scope.launch { val (i, m) = updater.check(p.updateUrl); info = i; msg = m; busy = false }
                }
            }, primary = true)
            info?.let { u ->
                if (u.notes.isNotBlank()) GText(u.notes.take(600), size = 12.sp)
                GlassButton(if (progress in 1..99) "Downloading $progress%" else "Download and verify", {
                    if (!busy) {
                        busy = true; progress = 0; msg = "Downloading…"
                        scope.launch {
                            val err = updater.downloadAndVerify(u) { progress = it }
                            verified = err == null; msg = err ?: "Verified: hash and signing key match. Tap Install."; busy = false
                        }
                    }
                })
                if (verified) GlassButton("Install (Android will ask you to confirm)", { msg = updater.install() }, primary = true)
            }
        }
        if (msg.isNotBlank()) GText(msg, size = 13.sp, color = g.accent)
    }
}
