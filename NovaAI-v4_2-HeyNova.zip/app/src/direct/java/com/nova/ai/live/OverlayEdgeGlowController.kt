package com.nova.ai.live

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.WindowManager

/** Direct build: draws the slim edge glow in an overlay window above every app. Does nothing when the overlay permission is missing or 3D effects are off. */
object OverlayEdgeGlowController {
    private var view: View? = null

    private class GlowView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        override fun onDraw(canvas: Canvas) {
            val w = (26 * resources.displayMetrics.density)
            val col = when (LiveSession.state.value) { LiveOrbState.ERROR -> 0xFFFF7A85.toInt(); LiveOrbState.SPEAKING -> 0xFFFF6FAE.toInt(); else -> 0xFF8B5CF6.toInt() }
            for (i in 0 until 4) {
                p.color = Color.argb(70 - i * 16, Color.red(col), Color.green(col), Color.blue(col))
                p.strokeWidth = w - i * w / 5f
                canvas.drawRect(RectF(p.strokeWidth / 2, p.strokeWidth / 2, width - p.strokeWidth / 2, height - p.strokeWidth / 2), p)
            }
            postInvalidateOnAnimation()
        }
    }

    @Synchronized fun start(ctx: Context) {
        val c = ctx.applicationContext
        if (view != null || !LivePrefs.fx3d(c) || !Settings.canDrawOverlays(c)) return
        try {
            val v = GlowView(c)
            val lp = WindowManager.LayoutParams(-1, -1,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            view = v
        } catch (e: Exception) { view = null }
    }

    @Synchronized fun stop(ctx: Context) {
        val v = view ?: return
        try { (ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        view = null
    }
}
