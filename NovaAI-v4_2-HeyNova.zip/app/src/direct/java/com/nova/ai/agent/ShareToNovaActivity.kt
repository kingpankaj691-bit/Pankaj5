package com.nova.ai.agent

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import com.nova.ai.agent.social.MediaResolver

/** Share a photo or video to Nova; only content:// URIs that arrive here can be used by the social agent. */
class ShareToNovaActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = ArrayList<Uri>()
        if (intent?.action == Intent.ACTION_SEND) (if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
        uris.forEach { MediaResolver.register(it.toString()) }
        android.widget.Toast.makeText(this, if (uris.isEmpty()) "Nothing to share." else "Shared to Nova. Now tell Nova what to post.", android.widget.Toast.LENGTH_LONG).show()
        finish()
    }
}
