package com.nova.ai.agent.whatsapp

import com.nova.ai.agent.core.*
import com.nova.ai.agent.social.ControlCommand
import com.nova.ai.screen.SensitiveText
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

enum class WhatsAppAction { READ_UNREAD, SEND_MESSAGE, READ_CHAT, SEARCH_CHAT, MUTE_CHAT, UNMUTE_CHAT, MARK_READ;
    companion object { fun parse(s: String?) = values().firstOrNull { it.name.equals(s?.trim(), true) } }
}

data class UnreadMessage(val sender: String, val text: String)

/** Device-facing pieces the agent needs; production is wired to the notification listener and the accessibility driver. */
interface WhatsAppEnv {
    fun unread(limit: Int): List<UnreadMessage>                       // from the notification listener, never opens the app
    fun contactsMatching(name: String): List<Pair<String, String>>    // (display name, phone)
    suspend fun openChat(phone: String, text: String?): Boolean       // straight to the chat by phone number
    suspend fun openApp(): Boolean
}

/** Runs WhatsApp actions. Ambiguity (two matching contacts) fails with "contact_ambiguous" instead of guessing. Sending needs a yes. */
class WhatsAppAgent(
    private val env: WhatsAppEnv, private val exec: UiActionExecutor, private val observer: ScreenObserver, private val driver: ScreenDriver
) {
    @Volatile private var gate: CompletableDeferred<Boolean>? = null
    @Volatile var waitingForConfirm = false
        private set
    @Volatile private var askedAt = 0L

    fun control(cmd: ControlCommand): String = when (cmd) {
        // A "yes" in the same instant the question was raised cannot come from a person who read it.
        ControlCommand.CONFIRM -> if (!waitingForConfirm) "nothing_to_confirm"
            else if (System.currentTimeMillis() - askedAt < 1500) "too_fast_ask_the_user_and_wait_for_their_answer"
            else { gate?.complete(true); "confirmed" }
        ControlCommand.REJECT -> if (waitingForConfirm) { gate?.complete(false); "rejected" } else "nothing_to_reject"
        ControlCommand.CANCEL -> { gate?.complete(false); "cancelled" }
        ControlCommand.STATUS -> if (waitingForConfirm) "waiting_for_confirmation" else "idle"
        ControlCommand.RESUME -> "not_paused"
    }

    private fun resolve(name: String): Pair<String?, String> {
        val m = env.contactsMatching(name)
        return when {
            m.isEmpty() -> null to "contact_not_found"
            m.map { it.first.lowercase() }.distinct().size > 1 && m.none { it.first.equals(name, true) } -> null to "contact_ambiguous"
            else -> (m.firstOrNull { it.first.equals(name, true) } ?: m.first()).second to ""
        }
    }

    suspend fun run(action: WhatsAppAction, contact: String, text: String): String {
        return when (action) {
            WhatsAppAction.READ_UNREAD -> env.unread(10).let { l -> if (l.isEmpty()) "no_unread_messages" else l.joinToString("; ") { "${it.sender}: ${SensitiveText.redact(it.text)}" } }
            WhatsAppAction.SEND_MESSAGE -> {
                if (text.isBlank()) return "text_missing"
                val (phone, err) = resolve(contact); if (phone == null) return err
                if (!env.openChat(phone, text)) return "failed_to_open_chat"
                val g = CompletableDeferred<Boolean>(); gate = g; askedAt = System.currentTimeMillis(); waitingForConfirm = true
                val yes = withTimeoutOrNull(60_000) { g.await() } ?: false   // no answer = not sent
                waitingForConfirm = false
                if (!yes) return "not_sent"
                when (val r = exec.click(TargetSpec(listOf("Send")))) {
                    is ActionResult.Success -> {
                        // Never reported as sent without looking: the message must have left the box.
                        delay(1200)
                        val still = observer.observe()?.elements?.any { it.editable && it.text.trim() == text.trim() } == true
                        if (still) "send_pressed_but_message_still_in_box_not_sent" else "send_pressed_message_box_cleared"
                    }
                    is ActionResult.Blocked -> "blocked_" + r.blocker.name.lowercase()
                    else -> "composer_opened_send_not_found"
                }
            }
            WhatsAppAction.READ_CHAT -> { val (p, e) = resolve(contact); if (p == null) e else if (!env.openChat(p, null)) "failed_to_open_chat" else readVisible() }
            WhatsAppAction.SEARCH_CHAT -> { if (!env.openApp()) "failed_to_open_app" else when (exec.click(TargetSpec(listOf("Search")))) { is ActionResult.Success -> if (driver.setText(contact) == DriverResult.OK) "searched" else "no_focused_field"; else -> "search_not_found" } }
            WhatsAppAction.MUTE_CHAT, WhatsAppAction.UNMUTE_CHAT -> {
                val (p, e) = resolve(contact); if (p == null) return e
                if (!env.openChat(p, null)) return "failed_to_open_chat"
                val mute = action == WhatsAppAction.MUTE_CHAT
                val more = exec.click(TargetSpec(listOf("More options")))
                if (more !is ActionResult.Success) return "menu_not_found"
                val item = exec.click(TargetSpec(if (mute) listOf("Mute notifications", "Mute") else listOf("Unmute notifications", "Unmute")))
                if (item !is ActionResult.Success) return "menu_item_not_found"
                if (mute) exec.click(TargetSpec(listOf("Always", "OK")))
                if (mute) "muted" else "unmuted"
            }
            WhatsAppAction.MARK_READ -> { val (p, e) = resolve(contact); if (p == null) e else if (env.openChat(p, null)) { driver.back(); "marked_read" } else "failed_to_open_chat" }
        }
    }

    private fun readVisible(): String {
        val o = observer.observe() ?: return "no_screen"
        val lines = o.elements.filter { !it.editable && it.text.length > 1 && it.bounds.t > o.screenH / 8 }.map { it.text }.distinct().takeLast(12)
        return if (lines.isEmpty()) "chat_empty" else SensitiveText.redact(lines.joinToString(" | "))
    }
}
