package com.nova.ai.agent.core

import com.nova.ai.agent.core.TaskState.*

enum class TaskState {
    IDLE, OPENING_APP, OBSERVING, RESOLVING_TARGET, VALIDATING_TARGET, EXECUTING_ACTION, WAITING_FOR_UI, VERIFYING, NEXT_STEP,
    RETRY, REOBSERVE, WAITING_FOR_CONFIRMATION, WAITING_FOR_USER, COMPLETED, FAILED, CANCELLED;
    val terminal get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

/** moveTo() throws on an illegal transition. FAILED and CANCELLED are reachable from every non-terminal state; terminal states never exit. */
class TaskStateMachine {
    companion object {
        private val allowed: Map<TaskState, Set<TaskState>> = run {
            mapOf(
                IDLE to setOf(OPENING_APP),
                OPENING_APP to setOf(OBSERVING, WAITING_FOR_USER),
                OBSERVING to setOf(RESOLVING_TARGET, NEXT_STEP, WAITING_FOR_USER),
                RESOLVING_TARGET to setOf(VALIDATING_TARGET, RETRY, REOBSERVE, WAITING_FOR_USER),
                VALIDATING_TARGET to setOf(EXECUTING_ACTION, WAITING_FOR_CONFIRMATION, REOBSERVE, RETRY, COMPLETED),
                EXECUTING_ACTION to setOf(WAITING_FOR_UI, VERIFYING, RETRY, WAITING_FOR_USER),
                WAITING_FOR_UI to setOf(VERIFYING, REOBSERVE),
                VERIFYING to setOf(NEXT_STEP, RETRY, REOBSERVE, COMPLETED, WAITING_FOR_USER),
                NEXT_STEP to setOf(OBSERVING, RESOLVING_TARGET, COMPLETED),
                RETRY to setOf(REOBSERVE, RESOLVING_TARGET),
                REOBSERVE to setOf(OBSERVING, RESOLVING_TARGET),
                WAITING_FOR_CONFIRMATION to setOf(EXECUTING_ACTION, WAITING_FOR_USER),
                WAITING_FOR_USER to setOf(OBSERVING, REOBSERVE),
                COMPLETED to emptySet(), FAILED to emptySet(), CANCELLED to emptySet()
            )
        }
        fun isLegal(from: TaskState, to: TaskState): Boolean =
            if (from.terminal) false else (to == TaskState.FAILED || to == TaskState.CANCELLED || to in (allowed[from] ?: emptySet()))
    }

    @Volatile var state: TaskState = TaskState.IDLE
        private set
    private val _history = ArrayList<TaskState>().apply { add(TaskState.IDLE) }
    val history: List<TaskState> @Synchronized get() = _history.toList()

    @Synchronized
    fun moveTo(next: TaskState) {
        if (!isLegal(state, next)) throw IllegalStateException("Illegal transition $state -> $next")
        state = next
        _history.add(next)
    }
}
