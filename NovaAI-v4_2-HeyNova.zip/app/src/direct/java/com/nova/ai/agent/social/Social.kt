package com.nova.ai.agent.social

import com.nova.ai.agent.core.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay

enum class Platform(val label: String, val packages: List<String>) {
    INSTAGRAM("Instagram", listOf("com.instagram.android")),
    FACEBOOK("Facebook", listOf("com.facebook.katana", "com.facebook.lite"))
}
enum class SocialAction { CREATE_POST, CREATE_REEL, CREATE_STORY, TEXT_POST }
enum class TaskMode { PUBLISH, DRAFT }
enum class TaskStatus { QUEUED, RUNNING, WAITING_FOR_CONFIRMATION, WAITING_FOR_USER, COMPLETED, SUBMITTED_UNVERIFIED, DRAFT_SAVED, FAILED, CANCELLED }
enum class ControlCommand { CONFIRM, REJECT, RESUME, CANCEL, STATUS;
    companion object { fun parse(s: String) = values().firstOrNull { it.name.equals(s.trim(), true) } }
}

data class SocialTaskRequest(val platform: Platform, val action: SocialAction, val mediaUri: String?, val caption: String, val mode: TaskMode, val targetAccount: String?) {
    sealed class Parsed { data class Ok(val request: SocialTaskRequest) : Parsed(); data class Invalid(val message: String) : Parsed() }
    companion object {
        /** Validates the model's arguments BEFORE a task exists. [mediaKnown] says whether a content:// URI was shared to Nova. */
        fun parse(args: Map<String, String>, mediaKnown: (String) -> Boolean): Parsed {
            val platform = Platform.values().firstOrNull { it.name.equals(args["platform"]?.trim(), true) } ?: return Parsed.Invalid("platform must be instagram or facebook")
            val action = SocialAction.values().firstOrNull { it.name.equals(args["action"]?.trim(), true) } ?: return Parsed.Invalid("action must be create_post, create_reel, create_story or text_post")
            val mode = when (args["mode"]?.trim()?.lowercase().orEmpty()) { "", "publish" -> TaskMode.PUBLISH; "draft" -> TaskMode.DRAFT; else -> return Parsed.Invalid("mode must be publish or draft") }
            val caption = args["caption"].orEmpty().trim()
            if (caption.length > 2200) return Parsed.Invalid("caption is too long (max 2200 characters)")
            val media = args["media_uri"]?.trim().takeUnless { it.isNullOrEmpty() }
            if (action == SocialAction.TEXT_POST) {
                if (platform != Platform.FACEBOOK) return Parsed.Invalid("text posts are only supported on Facebook")
                if (caption.isEmpty()) return Parsed.Invalid("a text post needs a caption")
            } else {
                if (media == null) return Parsed.Invalid("this action needs media shared to Nova first")
                if (!media.startsWith("content://")) return Parsed.Invalid("media_uri must be a content:// URI shared to Nova")
                if (!mediaKnown(media)) return Parsed.Invalid("that media was not shared to Nova")
                if (action == SocialAction.CREATE_REEL && platform == Platform.FACEBOOK && false) return Parsed.Invalid("unsupported")
            }
            return Parsed.Ok(SocialTaskRequest(platform, action, media, caption, mode, args["target_account"]?.trim().takeUnless { it.isNullOrEmpty() }))
        }
    }
}

/** Only content:// URIs that the user shared to Nova through ShareToNovaActivity are usable. Kept in RAM. */
object MediaResolver {
    private val shared = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
    fun register(uri: String) { if (uri.startsWith("content://")) { shared.add(uri); while (shared.size > 20) shared.remove(shared.first()) } }
    fun isKnown(uri: String) = uri in shared
    fun latest(): String? = synchronized(shared) { shared.lastOrNull() }
}

enum class StepKind { TAP, TYPE, PUBLISH }
data class PlanStep(val name: String, val kind: StepKind, val spec: TargetSpec? = null, val text: String = "", val irreversible: Boolean = false)

/** Per-platform selectors (visible labels). Best effort: apps change their screens. */
object SocialSelectors {
    val next = TargetSpec(listOf("Next", "Continue"))
    val share = TargetSpec(listOf("Share", "Post", "Publish"))
    val caption = TargetSpec(listOf("Write a caption", "Add a caption", "What's on your mind", "Say something", "Write something"), editable = true)
    val saveDraft = TargetSpec(listOf("Save draft", "Save as draft", "Save Draft"))

    fun plan(r: SocialTaskRequest): List<PlanStep> {
        val steps = ArrayList<PlanStep>()
        when (r.action) {
            SocialAction.CREATE_POST -> if (r.platform == Platform.INSTAGRAM) { steps.add(PlanStep("Choose New post", StepKind.TAP, TargetSpec(listOf("New post", "Post")))); steps.add(PlanStep("Next", StepKind.TAP, next)) }
            SocialAction.CREATE_REEL -> steps.add(PlanStep("Choose Reel", StepKind.TAP, TargetSpec(listOf("Reel", "New reel", "Reels"))))
            SocialAction.CREATE_STORY -> steps.add(PlanStep("Choose Story", StepKind.TAP, TargetSpec(listOf("Story", "Your story", "New story"))))
            SocialAction.TEXT_POST -> steps.add(PlanStep("Open composer", StepKind.TAP, TargetSpec(listOf("What's on your mind", "Create post", "Write something"))))
        }
        if (r.action != SocialAction.CREATE_STORY || r.platform == Platform.FACEBOOK) steps.add(PlanStep("Next", StepKind.TAP, next))
        if (r.caption.isNotEmpty() && r.action != SocialAction.CREATE_STORY) steps.add(PlanStep("Type caption", StepKind.TYPE, caption, r.caption))
        steps.add(PlanStep("Publish", StepKind.PUBLISH, share, irreversible = true))
        return steps
    }
}

data class TaskReport(val taskId: String, val status: TaskStatus, val message: String, val state: TaskState, val history: List<TaskState>)

/**
 * Runs a plan. PUBLISH mode pauses at WAITING_FOR_CONFIRMATION before the irreversible tap; DRAFT never publishes.
 * A blocker pauses at WAITING_FOR_USER. If success cannot be verified the task ends as SUBMITTED_UNVERIFIED and says so.
 */
class SocialTaskRunner(
    val taskId: String, private val request: SocialTaskRequest, private val steps: List<PlanStep>,
    private val exec: UiActionExecutor, private val input: TextInputExecutor, private val observer: ScreenObserver,
    private val openApp: suspend () -> Boolean,
    private val publishedCheck: (ScreenObservation) -> Boolean = { o -> o.elements.none { it.label.equals("Share", true) } },
    private val pause: suspend (Long) -> Unit = { delay(it) }
) {
    val machine = TaskStateMachine()
    @Volatile var status = TaskStatus.QUEUED
        private set
    private var confirmGate: CompletableDeferred<Boolean>? = null
    private var resumeGate: CompletableDeferred<Unit>? = null
    @Volatile private var cancelled = false
    @Volatile private var awaitingConfirm = false
    @Volatile private var confirmedOnce = false

    /** Returns a short result word the model can speak. CONFIRM is refused unless the task is actually waiting for a yes. */
    @Synchronized
    fun control(cmd: ControlCommand): String = when (cmd) {
        ControlCommand.STATUS -> status.name.lowercase()
        ControlCommand.CANCEL -> { cancelled = true; confirmGate?.complete(false); resumeGate?.complete(Unit); "cancelled" }
        ControlCommand.CONFIRM -> if (awaitingConfirm && confirmGate?.isActive == true) { confirmGate!!.complete(true); "confirmed" } else "nothing_to_confirm"
        ControlCommand.REJECT -> if (awaitingConfirm && confirmGate?.isActive == true) { confirmGate!!.complete(false); "rejected" } else "nothing_to_reject"
        ControlCommand.RESUME -> if (resumeGate?.isActive == true) { resumeGate!!.complete(Unit); "resumed" } else "not_paused"
    }

    private fun report(msg: String) = TaskReport(taskId, status, msg, machine.state, machine.history)
    private fun finish(st: TaskStatus, ts: TaskState, msg: String): TaskReport {
        status = st
        if (!machine.state.terminal) machine.moveTo(ts)
        return report(msg)
    }

    suspend fun run(): TaskReport {
        status = TaskStatus.RUNNING
        machine.moveTo(TaskState.OPENING_APP)
        if (!openApp()) return finish(TaskStatus.FAILED, TaskState.FAILED, "${request.platform.label} could not be opened.")
        machine.moveTo(TaskState.OBSERVING)
        var first = true
        for (step in steps) {
            if (cancelled) return finish(TaskStatus.CANCELLED, TaskState.CANCELLED, "Cancelled.")
            var attempts = 0
            while (true) {
                if (cancelled) return finish(TaskStatus.CANCELLED, TaskState.CANCELLED, "Cancelled.")
                machine.moveTo(TaskState.RESOLVING_TARGET)
                machine.moveTo(TaskState.VALIDATING_TARGET)
                if (step.irreversible) {
                    if (request.mode == TaskMode.DRAFT) return saveDraft()
                    if (!confirmedOnce) {
                        machine.moveTo(TaskState.WAITING_FOR_CONFIRMATION)
                        status = TaskStatus.WAITING_FOR_CONFIRMATION
                        val gate = CompletableDeferred<Boolean>()
                        synchronized(this) { confirmGate = gate; awaitingConfirm = true }
                        val yes = gate.await()
                        synchronized(this) { awaitingConfirm = false }
                        if (cancelled || !yes) return finish(TaskStatus.CANCELLED, TaskState.CANCELLED, "Not published. You said no.")
                        confirmedOnce = true
                        status = TaskStatus.RUNNING
                    }
                }
                machine.moveTo(TaskState.EXECUTING_ACTION)
                val res = when (step.kind) {
                    StepKind.TYPE -> input.type(step.text, step.spec)
                    else -> exec.click(step.spec!!)
                }
                when (res) {
                    is ActionResult.Success -> {
                        machine.moveTo(TaskState.WAITING_FOR_UI); machine.moveTo(TaskState.VERIFYING)
                        if (step.irreversible) {
                            val o = observer.observe()
                            val verified = o != null && publishedCheck(o)
                            return if (verified) finish(TaskStatus.COMPLETED, TaskState.COMPLETED, "Posted on ${request.platform.label}.")
                            else finish(TaskStatus.SUBMITTED_UNVERIFIED, TaskState.COMPLETED, "I tapped Share but could not confirm it was posted. Please check ${request.platform.label}.")
                        }
                        machine.moveTo(TaskState.NEXT_STEP)
                        first = false
                        break
                    }
                    is ActionResult.Blocked -> {
                        machine.moveTo(TaskState.WAITING_FOR_USER)
                        status = TaskStatus.WAITING_FOR_USER
                        val gate = CompletableDeferred<Unit>()
                        synchronized(this) { resumeGate = gate }
                        gate.await()
                        if (cancelled) return finish(TaskStatus.CANCELLED, TaskState.CANCELLED, "Cancelled.")
                        status = TaskStatus.RUNNING
                        machine.moveTo(TaskState.REOBSERVE)
                        continue
                    }
                    is ActionResult.Failed -> {
                        if (++attempts > 2) return finish(TaskStatus.FAILED, TaskState.FAILED, "Step '${step.name}' failed (${res.reason.name.lowercase()}).")
                        machine.moveTo(TaskState.RETRY); machine.moveTo(TaskState.REOBSERVE)
                        pause(600)
                        continue
                    }
                }
            }
        }
        return finish(TaskStatus.COMPLETED, TaskState.COMPLETED, "Done.")
    }

    private suspend fun saveDraft(): TaskReport {
        machine.moveTo(TaskState.EXECUTING_ACTION)
        val r = exec.click(SocialSelectors.saveDraft)
        machine.moveTo(TaskState.WAITING_FOR_UI); machine.moveTo(TaskState.VERIFYING)
        return if (r is ActionResult.Success) finish(TaskStatus.DRAFT_SAVED, TaskState.COMPLETED, "Saved as a draft. Nothing was published.")
        else finish(TaskStatus.DRAFT_SAVED, TaskState.COMPLETED, "Stopped before publishing. Nothing was posted; the draft may still be open in ${request.platform.label}.")
    }
}
