package com.nova.ai.agent.core

data class Bounds(val l: Int, val t: Int, val r: Int, val b: Int) {
    val cx get() = (l + r) / 2
    val cy get() = (t + b) / 2
    val area get() = maxOf(0, r - l) * maxOf(0, b - t)
}

data class UiElement(
    val id: Int, val text: String, val desc: String, val clickable: Boolean, val editable: Boolean, val bounds: Bounds, val hint: String = ""
) { val label: String get() = text.ifBlank { desc }.ifBlank { hint } }

/** Raw capture from the driver. */
data class CapturedScreen(val pkg: String, val windowClass: String, val elements: List<UiElement>, val screenW: Int, val screenH: Int)

data class ScreenObservation(
    val observationId: Long, val pkg: String, val windowClass: String, val elements: List<UiElement>,
    val screenW: Int, val screenH: Int, val windowStamp: Long
) { fun hasText(t: String) = elements.any { it.label.contains(t, true) } }

enum class DriverResult { OK, FAILED, STALE, NOT_FOUND, UNSUPPORTED }

/** The ONLY boundary with the device. Production: AccessibilityScreenDriver. Tests: FakeScreenDriver. */
interface ScreenDriver {
    fun capture(): CapturedScreen?
    fun clickElement(obs: ScreenObservation, e: UiElement): DriverResult
    fun gestureTap(x: Int, y: Int): DriverResult
    fun setText(text: String): DriverResult
    fun scroll(forward: Boolean): DriverResult
    fun back(): DriverResult
    fun home(): DriverResult
}

enum class ExecPhase { RESOLVE, VALIDATE, EXECUTE, VERIFY }
enum class ActionMethod { ACCESSIBILITY_CLICK, GESTURE_ON_ELEMENT_BOUNDS, VISION_TAP, SET_TEXT }
enum class Blocker { LOGIN, CAPTCHA, TWO_FACTOR, SECURITY_CHECK, PERMISSION_PROMPT }
enum class FailureReason { NO_SCREEN, TARGET_NOT_FOUND, STALE_OBSERVATION, ACTION_FAILED, VERIFY_FAILED, NO_FOCUSED_FIELD, UNSUPPORTED }

sealed class ActionResult {
    data class Success(val method: ActionMethod) : ActionResult()
    data class Failed(val reason: FailureReason, val phase: ExecPhase) : ActionResult()
    data class Blocked(val blocker: Blocker) : ActionResult()
}

/** Turns captures into observations and remembers which one is the latest. */
class ScreenObserver(private val driver: ScreenDriver, private val clock: () -> Long = { System.currentTimeMillis() }) {
    @Volatile private var latest = 0L
    private var counter = 0L
    fun observe(): ScreenObservation? {
        val c = driver.capture() ?: return null
        val id = ++counter
        latest = id
        return ScreenObservation(id, c.pkg, c.windowClass, c.elements, c.screenW, c.screenH, clock())
    }
    fun isLatest(o: ScreenObservation) = o.observationId == latest
}

/** What to look for. Matches on text, content description or hint. */
data class TargetSpec(val labels: List<String>, val needClickable: Boolean = true, val exact: Boolean = false, val editable: Boolean = false)

object TargetResolver {
    fun resolve(obs: ScreenObservation, spec: TargetSpec): UiElement? {
        var best: UiElement? = null
        var bestScore = 0
        for (e in obs.elements) {
            if (spec.editable && !e.editable) continue
            if (spec.needClickable && !spec.editable && !e.clickable) continue
            val l = e.label.trim()
            if (l.isEmpty()) continue
            var s = 0
            for (want in spec.labels) {
                val w = want.trim()
                s = maxOf(s, when {
                    l.equals(w, true) -> 100
                    spec.exact -> 0
                    l.startsWith(w, true) -> 60
                    l.contains(w, true) -> 30
                    else -> 0
                })
            }
            if (s == 0) continue
            if (e.clickable) s += 5
            if (s > bestScore || (s == bestScore && best != null && e.bounds.area in 1 until best.bounds.area)) { best = e; bestScore = s }
        }
        return best
    }
}

/** Looks for login walls, CAPTCHAs, 2FA and permission prompts on the current screen. */
object BlockerDetector {
    private val login = listOf("log in", "login", "sign in", "forgot password", "create new account")
    private val captcha = listOf("captcha", "i'm not a robot", "verify you're human", "select all images")
    private val twoFactor = listOf("security code", "two-factor", "2-step", "enter the code", "confirmation code")
    private val security = listOf("suspicious", "confirm it's you", "unusual activity", "we've temporarily", "checkpoint")
    private val permission = listOf("allow access", "wants to access", "allow photos", "allow notifications")
    fun detect(o: ScreenObservation): Blocker? {
        val all = o.elements.joinToString("\n") { it.label.lowercase() }
        val hasPassword = o.elements.any { it.hint.contains("password", true) || it.label.contains("password", true) }
        return when {
            captcha.any { all.contains(it) } -> Blocker.CAPTCHA
            twoFactor.any { all.contains(it) } -> Blocker.TWO_FACTOR
            security.any { all.contains(it) } -> Blocker.SECURITY_CHECK
            hasPassword && login.any { all.contains(it) } -> Blocker.LOGIN
            o.pkg.contains("permissioncontroller") || permission.any { all.contains(it) } && o.pkg.contains("packageinstaller") -> Blocker.PERMISSION_PROMPT
            else -> null
        }
    }
}

/** Resolve -> validate -> act -> verify. Verifies an expectation after the action and reports Success / Failed / Blocked. */
class UiActionExecutor(
    private val driver: ScreenDriver, private val observer: ScreenObserver,
    private val settle: suspend () -> Unit = { kotlinx.coroutines.delay(400) },
    private val detect: (ScreenObservation) -> Blocker? = BlockerDetector::detect
) {
    /** [expect] defaults to "the target is gone or the window changed". */
    suspend fun click(spec: TargetSpec, expect: ((ScreenObservation, UiElement) -> Boolean)? = null): ActionResult {
        val obs = observer.observe() ?: return ActionResult.Failed(FailureReason.NO_SCREEN, ExecPhase.RESOLVE)
        detect(obs)?.let { return ActionResult.Blocked(it) }
        val target = TargetResolver.resolve(obs, spec) ?: return ActionResult.Failed(FailureReason.TARGET_NOT_FOUND, ExecPhase.RESOLVE)
        if (!observer.isLatest(obs)) return ActionResult.Failed(FailureReason.STALE_OBSERVATION, ExecPhase.VALIDATE)
        var method = ActionMethod.ACCESSIBILITY_CLICK
        var r = driver.clickElement(obs, target)
        if (r == DriverResult.STALE) return ActionResult.Failed(FailureReason.STALE_OBSERVATION, ExecPhase.EXECUTE)
        if (r != DriverResult.OK) {
            method = ActionMethod.GESTURE_ON_ELEMENT_BOUNDS
            r = driver.gestureTap(target.bounds.cx, target.bounds.cy)
            if (r != DriverResult.OK) return ActionResult.Failed(if (r == DriverResult.UNSUPPORTED) FailureReason.UNSUPPORTED else FailureReason.ACTION_FAILED, ExecPhase.EXECUTE)
        }
        settle()
        val after = observer.observe() ?: return ActionResult.Failed(FailureReason.NO_SCREEN, ExecPhase.VERIFY)
        detect(after)?.let { return ActionResult.Blocked(it) }
        val ok = expect?.invoke(after, target) ?: (after.windowClass != obs.windowClass || after.pkg != obs.pkg || TargetResolver.resolve(after, spec) == null || after.elements.size != obs.elements.size)
        return if (ok) ActionResult.Success(method) else ActionResult.Failed(FailureReason.VERIFY_FAILED, ExecPhase.VERIFY)
    }
}

/** Types into a text field (a given one, or the focused one) and verifies the text is really there. */
class TextInputExecutor(
    private val driver: ScreenDriver, private val observer: ScreenObserver, private val settle: suspend () -> Unit = { kotlinx.coroutines.delay(250) }
) {
    suspend fun type(text: String, field: TargetSpec? = null): ActionResult {
        val obs = observer.observe() ?: return ActionResult.Failed(FailureReason.NO_SCREEN, ExecPhase.RESOLVE)
        if (field != null) {
            val f = TargetResolver.resolve(obs, field.copy(editable = true)) ?: return ActionResult.Failed(FailureReason.NO_FOCUSED_FIELD, ExecPhase.RESOLVE)
            driver.clickElement(obs, f)
        }
        val r = driver.setText(text)
        if (r != DriverResult.OK) return ActionResult.Failed(if (r == DriverResult.NOT_FOUND) FailureReason.NO_FOCUSED_FIELD else FailureReason.ACTION_FAILED, ExecPhase.EXECUTE)
        settle()
        val after = observer.observe() ?: return ActionResult.Failed(FailureReason.NO_SCREEN, ExecPhase.VERIFY)
        return if (after.elements.any { it.editable && it.text.contains(text.take(20)) }) ActionResult.Success(ActionMethod.SET_TEXT)
        else ActionResult.Failed(FailureReason.VERIFY_FAILED, ExecPhase.VERIFY)
    }
}
