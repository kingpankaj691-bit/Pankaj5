package com.nova.ai.agent

import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.agent.core.*
import com.nova.ai.screen.UiElement as SysEl

/** Production ScreenDriver on top of the AccessibilityService. */
class AccessibilityScreenDriver : ScreenDriver {
    private val originals = HashMap<Int, SysEl>()
    private val svc get() = NovaAccessibilityService.instance

    override fun capture(): CapturedScreen? {
        val s = svc?.snapshot() ?: return null
        originals.clear()
        val els = s.elements.map { e ->
            originals[e.index] = e
            UiElement(e.index, e.text, e.desc, e.clickable, e.editable, Bounds(e.bounds.left, e.bounds.top, e.bounds.right, e.bounds.bottom), e.hint)
        }
        return CapturedScreen(s.pkg, s.pkg, els, s.width, s.height)
    }
    override fun clickElement(obs: ScreenObservation, e: UiElement): DriverResult {
        val o = originals[e.id] ?: return DriverResult.NOT_FOUND
        return if (svc?.clickElement(o) == true) DriverResult.OK else DriverResult.FAILED
    }
    override fun gestureTap(x: Int, y: Int): DriverResult { val s = svc ?: return DriverResult.UNSUPPORTED; return if (s.gestureNow(s.tapPath(x.toFloat(), y.toFloat()), 0, 60)) DriverResult.OK else DriverResult.FAILED }
    override fun setText(text: String): DriverResult { val s = svc ?: return DriverResult.UNSUPPORTED; return if (s.typeText(text)) DriverResult.OK else DriverResult.NOT_FOUND }
    override fun scroll(forward: Boolean): DriverResult = if (svc?.scroll(forward) == true) DriverResult.OK else DriverResult.FAILED
    override fun back(): DriverResult = if (svc?.back() == true) DriverResult.OK else DriverResult.FAILED
    override fun home(): DriverResult = if (svc?.home() == true) DriverResult.OK else DriverResult.FAILED
}
