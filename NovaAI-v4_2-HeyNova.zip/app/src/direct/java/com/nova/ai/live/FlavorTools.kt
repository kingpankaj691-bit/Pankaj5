package com.nova.ai.live

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nova.ai.accessibility.NovaAccessibilityService
import com.nova.ai.agent.AccessibilityScreenDriver
import com.nova.ai.agent.core.*
import com.nova.ai.agent.social.*
import com.nova.ai.agent.whatsapp.*
import com.nova.ai.license.AccessKeyManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Direct (sideload) build: screen control, social agent, WhatsApp agent, access-key gate. */
object FlavorTools {
    const val instruction = " Screen tools: read_screen, tap_text(text), type_text(text), scroll_screen(direction), go_back, go_home. " +
        "Social: execute_social_media_task then social_media_task_control. WhatsApp: execute_whatsapp_task then whatsapp_task_control. " +
        "In this build a message is sent automatically after it is prepared. ALWAYS ask the user first before anything irreversible (posting, sending). " +
        "Only call confirm after the user explicitly said yes."

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val runners = java.util.concurrent.ConcurrentHashMap<String, SocialTaskRunner>()
    @Volatile private var lastTask: String? = null
    @Volatile private var wa: WhatsAppAgent? = null

    fun declarations(): JSONArray = JSONArray()
        .put(LiveTools.decl("read_screen", "Read the visible text of the current screen.", emptyList(), emptyList()))
        .put(LiveTools.decl("tap_text", "Tap the on-screen element with this text.", listOf("text" to "Visible label"), listOf("text")))
        .put(LiveTools.decl("type_text", "Type text into the focused field.", listOf("text" to "Text to type"), listOf("text")))
        .put(LiveTools.decl("scroll_screen", "Scroll the screen.", listOf("direction" to "up or down"), emptyList()))
        .put(LiveTools.decl("go_back", "Press Back.", emptyList(), emptyList()))
        .put(LiveTools.decl("go_home", "Go to the home screen.", emptyList(), emptyList()))
        .put(LiveTools.decl("execute_social_media_task", "Post to Instagram or Facebook using media the user shared to Nova.",
            listOf("platform" to "instagram or facebook", "action" to "create_post, create_reel, create_story or text_post", "media_uri" to "content:// URI shared to Nova",
                "caption" to "Caption text", "mode" to "publish or draft", "target_account" to "Optional account"), listOf("platform", "action")))
        .put(LiveTools.decl("social_media_task_control", "Control a running social task. Only call confirm after the user explicitly said yes.",
            listOf("command" to "confirm, reject, resume, cancel or status", "task_id" to "Task id"), listOf("command")))
        .put(LiveTools.decl("execute_whatsapp_task", "Do a WhatsApp action. Sending needs the user's yes via whatsapp_task_control.",
            listOf("action" to "read_unread, send_message, read_chat, search_chat, mute_chat, unmute_chat or mark_read", "contact" to "Contact name or number", "text" to "Message text"), listOf("action")))
        .put(LiveTools.decl("whatsapp_task_control", "Confirm or reject a pending WhatsApp send. Only call confirm after the user explicitly said yes.",
            listOf("command" to "confirm, reject or cancel"), listOf("command")))

    fun gate(ctx: Context): String? = if (AccessKeyManager.isActive(ctx)) null else AccessKeyManager.blockMessage(ctx)

    /**
     * Messages are NEVER sent from here. This only waits for the composer (and, for WhatsApp, the "Continue to chat"
     * page, which is plain navigation) and leaves the prefilled message for the user to read and send themselves.
     */
    fun prepareComposer(ctx: Context, whatsapp: Boolean): String {
        val svc = NovaAccessibilityService.instance ?: return "composer_opened_not_sent_user_must_press_send"
        if (whatsapp) repeat(8) {
            Thread.sleep(400)
            if (svc.clickText("Continue to chat")) return "composer_opened_not_sent_user_must_press_send"
        }
        return "composer_opened_not_sent_user_must_press_send"
    }

    private fun r(s: String) = JSONObject().put("result", s)

    fun execute(ctx: Context, name: String, args: JSONObject): JSONObject? {
        val needsAcc = name in setOf("read_screen", "tap_text", "type_text", "scroll_screen", "go_back", "go_home", "execute_social_media_task", "execute_whatsapp_task")
        val svc = NovaAccessibilityService.instance
        if (needsAcc && svc == null) return r("accessibility_not_enabled")
        return when (name) {
            "read_screen" -> r(svc!!.readScreen().take(4000))
            "tap_text" -> r(if (svc!!.clickText(args.optString("text"))) "tapped" else "element_not_found")
            "type_text" -> r(svc!!.typeTextChecked(args.optString("text")).let { err -> if (err == null) "typed_and_verified" else "not_typed: $err" })
            "scroll_screen" -> r(if (svc!!.scroll(!args.optString("direction").equals("up", true))) "scrolled" else "nothing_scrollable")
            "go_back" -> r(if (svc!!.back()) "done" else "failed")
            "go_home" -> r(if (svc!!.home()) "done" else "failed")
            "execute_social_media_task" -> startSocial(ctx, args)
            "social_media_task_control" -> {
                val cmd = ControlCommand.parse(args.optString("command")) ?: return r("unknown_command")
                val id = args.optString("task_id").ifBlank { lastTask.orEmpty() }
                val run = runners[id] ?: return r("task_not_found")
                JSONObject().put("result", run.control(cmd)).put("status", run.status.name.lowercase())
            }
            "execute_whatsapp_task" -> whatsapp(ctx, args)
            "whatsapp_task_control" -> r(wa?.control(ControlCommand.parse(args.optString("command")) ?: return r("unknown_command")) ?: "no_task")
            else -> null
        }
    }

    private fun startSocial(ctx: Context, a: JSONObject): JSONObject {
        val map = HashMap<String, String>()
        a.keys().forEach { map[it] = a.optString(it) }
        val req = when (val p = SocialTaskRequest.parse(map, MediaResolver::isKnown)) { is SocialTaskRequest.Parsed.Invalid -> return r("invalid: " + p.message); is SocialTaskRequest.Parsed.Ok -> p.request }
        val driver = AccessibilityScreenDriver()
        val observer = ScreenObserver(driver)
        val id = UUID.randomUUID().toString().take(8)
        val runner = SocialTaskRunner(id, req, SocialSelectors.plan(req), UiActionExecutor(driver, observer), TextInputExecutor(driver, observer), observer, {
            openSocial(ctx, req)
        })
        runners[id] = runner; lastTask = id
        scope.launch { try { runner.run() } catch (e: Exception) { runner.control(ControlCommand.CANCEL) } }
        return JSONObject().put("result", "task_started").put("task_id", id).put("note", "Ask the user before the post is published.")
    }

    private suspend fun openSocial(ctx: Context, req: SocialTaskRequest): Boolean {
        val pm = ctx.packageManager
        val pkg = req.platform.packages.firstOrNull { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } } ?: return false
        val i = if (req.mediaUri != null) {
            val uri = Uri.parse(req.mediaUri)
            Intent(Intent.ACTION_SEND).setType(ctx.contentResolver.getType(uri) ?: "image/*").putExtra(Intent.EXTRA_STREAM, uri)
                .setPackage(pkg).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else pm.getLaunchIntentForPackage(pkg) ?: return false
        return try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); kotlinx.coroutines.delay(2500); true } catch (e: Exception) { false }
    }

    private fun whatsapp(ctx: Context, a: JSONObject): JSONObject {
        val action = WhatsAppAction.parse(a.optString("action")) ?: return r("unknown_action")
        val driver = AccessibilityScreenDriver(); val observer = ScreenObserver(driver)
        val env = object : WhatsAppEnv {
            override fun unread(limit: Int) = com.nova.ai.notifications.NovaNotificationListener.messages(limit).filter { it.pkg.contains("whatsapp") }.map { UnreadMessage(it.sender, it.text) }
            override fun contactsMatching(name: String): List<Pair<String, String>> =
                if (LiveTools.looksLikeNumber(name)) listOf(name to name.filter { it.isDigit() || it == '+' }) else LiveTools.contactRows(ctx, name)
            override suspend fun openChat(phone: String, text: String?): Boolean {
                val u = "https://wa.me/" + phone.filter { it.isDigit() } + (if (text != null) "?text=" + Uri.encode(text) else "")
                return try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); kotlinx.coroutines.delay(1800); true } catch (e: Exception) { false }
            }
            override suspend fun openApp(): Boolean = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { try { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); kotlinx.coroutines.delay(1500); true } catch (e: Exception) { false } } ?: false
        }
        val agent = WhatsAppAgent(env, UiActionExecutor(driver, observer), observer, driver)
        wa = agent
        if (action == WhatsAppAction.SEND_MESSAGE) {
            scope.launch { agent.run(action, a.optString("contact"), a.optString("text")) }
            return r("awaiting_confirmation: read this to the user and ask yes or no. To: " + a.optString("contact") + ". Message: \"" + a.optString("text") + "\". Nothing is sent until they say yes.")
        }
        return r(runBlocking { agent.run(action, a.optString("contact"), a.optString("text")) })
    }
}
