package com.nova.ai.license

import android.content.Context
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.ui.GText
import com.nova.ai.ui.GlassButton
import com.nova.ai.ui.GlassCard
import com.nova.ai.ui.GlassSettingSection
import com.nova.ai.ui.GlassTextField
import com.nova.ai.ui.LocalGlass
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class LicenseInfo(val active: Boolean, val plan: String, val expiresAt: Long, val status: String, val blocked: Boolean, val hasRememberedKey: Boolean)

/** Pure rules: no Android types. */
object AccessKeyRules {
    enum class Status { ACTIVE, EXPIRED, BLOCKED, INVALID }
    const val RECHECK_MS = 3 * 60 * 60 * 1000L
    fun status(plan: String, expiresAt: Long, blocked: Boolean, now: Long): Status = when {
        blocked -> Status.BLOCKED
        plan.isBlank() -> Status.INVALID
        plan.equals("lifetime", true) -> Status.ACTIVE
        expiresAt > 0 && now >= expiresAt -> Status.EXPIRED
        else -> Status.ACTIVE
    }
    fun isActive(plan: String, expiresAt: Long, blocked: Boolean, now: Long) = status(plan, expiresAt, blocked, now) == Status.ACTIVE
    fun needsRecheck(lastCheck: Long, now: Long) = lastCheck <= 0 || now - lastCheck >= RECHECK_MS
    fun text(s: Status) = when (s) { Status.ACTIVE -> "Access key active"; Status.EXPIRED -> "Access key expired"; Status.BLOCKED -> "Access key blocked by the admin"; Status.INVALID -> "No valid access key" }
}

/**
 * Backend config comes from assets/license_config.json ({"url": "https://..."}), a git-ignored file like google-services.json.
 * When it is missing the app builds and runs and reports "licensing not configured" (nothing is blocked).
 */
object AccessKeyManager {
    private const val PREFS = "lia_access_key"
    val info = MutableStateFlow(LicenseInfo(true, "", 0, "Licensing not configured", false, false))
    private val http by lazy { OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build() }

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun url(c: Context): String? = try {
        JSONObject(c.assets.open("license_config.json").bufferedReader().use { it.readText() }).optString("url").takeIf { it.startsWith("https://") }
    } catch (e: Exception) { null }

    fun configured(c: Context) = url(c) != null

    private fun deviceId(c: Context): String {
        val raw = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        return MessageDigest.getInstance("SHA-256").digest(("nova:$raw").toByteArray()).joinToString("") { "%02x".format(it) }.take(32)
    }

    fun refreshInfo(c: Context) {
        if (!configured(c)) { info.value = LicenseInfo(true, "", 0, "Licensing not configured", false, false); return }
        val s = sp(c)
        val plan = s.getString("plan", "").orEmpty(); val exp = s.getLong("expires_at", 0); val blocked = s.getBoolean("blocked", false)
        val st = AccessKeyRules.status(plan, exp, blocked, System.currentTimeMillis())
        info.value = LicenseInfo(st == AccessKeyRules.Status.ACTIVE && s.getBoolean("active", false), plan, exp, AccessKeyRules.text(st), blocked, !s.getString("key", "").isNullOrEmpty())
    }

    fun isActive(c: Context): Boolean { if (!configured(c)) return true; refreshInfo(c); return info.value.active }
    fun blockMessage(c: Context): String = "Nova's access key is not active (" + info.value.status + "). Ask the user to open Settings and enter a valid access key."

    private fun call(c: Context, key: String): JSONObject? {
        val u = url(c) ?: return null
        val body = JSONObject().put("key", key).put("deviceId", deviceId(c)).toString().toRequestBody("application/json".toMediaType())
        http.newCall(Request.Builder().url(u).post(body).build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("http ${r.code}")
            return JSONObject(r.body?.string().orEmpty())
        }
    }

    private fun store(c: Context, key: String, j: JSONObject) {
        sp(c).edit().putString("key", key).putString("plan", j.optString("plan")).putLong("expires_at", j.optLong("expiresAt"))
            .putBoolean("active", j.optBoolean("valid") && !j.optBoolean("blocked")).putBoolean("blocked", j.optBoolean("blocked"))
            .putLong("last_remote_check", System.currentTimeMillis()).apply()
        refreshInfo(c)
    }

    /** Validates a key against the backend and binds it to this device. Call off the main thread. */
    fun activate(c: Context, key: String): String {
        if (!configured(c)) return "Licensing not configured."
        return try {
            val j = call(c, key.trim()) ?: return "Licensing not configured."
            store(c, key.trim(), j)
            if (info.value.active) "Access key accepted." else j.optString("message").ifBlank { info.value.status }
        } catch (e: IOException) { "Couldn't reach the license server. Try again." } catch (e: Exception) { "The license server sent an unexpected answer." }
    }

    /** At most once per 3 hours. FAILS OPEN on network errors; an admin block makes the key inactive immediately. */
    fun liveCheck(c: Context) {
        if (!configured(c)) return
        val s = sp(c); val key = s.getString("key", "").orEmpty()
        if (key.isEmpty() || !AccessKeyRules.needsRecheck(s.getLong("last_remote_check", 0), System.currentTimeMillis())) return
        try { call(c, key)?.let { store(c, key, it) } } catch (e: Exception) { /* fail open: keep the old state */ }
    }
}

@Composable
fun AccessKeySection() {
    val ctx = LocalContext.current
    if (!remember { AccessKeyManager.configured(ctx) }) return
    val info by AccessKeyManager.info.collectAsState()
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    remember { AccessKeyManager.refreshInfo(ctx) }
    GlassSettingSection("Access key") {
        GText(info.status + if (info.plan.isNotBlank()) " · ${info.plan}" else "", size = 14.sp)
        GlassTextField(key, { key = it }, Modifier.fillMaxWidth(), placeholder = "Enter access key")
        GlassButton("Activate", { scope.launch { msg = withContext(Dispatchers.IO) { AccessKeyManager.activate(ctx, key) } } }, Modifier.fillMaxWidth(), primary = true, enabled = key.isNotBlank())
        if (msg.isNotBlank()) GText(msg, size = 12.sp, color = LocalGlass.current.subtext)
    }
}

@Composable
fun AccessKeyBanner() {
    val ctx = LocalContext.current
    if (!remember { AccessKeyManager.configured(ctx) }) return
    val info by AccessKeyManager.info.collectAsState()
    remember { AccessKeyManager.refreshInfo(ctx) }
    if (info.active) return
    GlassCard(Modifier.fillMaxWidth(), glow = true) { GText(info.status + ". Enter a key in Voice settings.", Modifier.padding(14.dp), size = 13.sp) }
}
