package com.nova.ai.license

import org.junit.Assert.*
import org.junit.Test

class AccessKeyRulesTest {
    private val now = 1_000_000L
    @Test fun activeExpiredBlockedInvalid() {
        assertEquals(AccessKeyRules.Status.ACTIVE, AccessKeyRules.status("pro", now + 1, false, now))
        assertEquals(AccessKeyRules.Status.EXPIRED, AccessKeyRules.status("pro", now, false, now))
        assertEquals(AccessKeyRules.Status.BLOCKED, AccessKeyRules.status("lifetime", 0, true, now))
        assertEquals(AccessKeyRules.Status.INVALID, AccessKeyRules.status("", 0, false, now))
        assertEquals(AccessKeyRules.Status.ACTIVE, AccessKeyRules.status("lifetime", 1, false, now))
        assertTrue(AccessKeyRules.isActive("pro", 0, false, now))
    }
    @Test fun recheckEveryThreeHours() {
        assertTrue(AccessKeyRules.needsRecheck(0, now))
        assertFalse(AccessKeyRules.needsRecheck(now, now + AccessKeyRules.RECHECK_MS - 1))
        assertTrue(AccessKeyRules.needsRecheck(now, now + AccessKeyRules.RECHECK_MS))
    }
}
