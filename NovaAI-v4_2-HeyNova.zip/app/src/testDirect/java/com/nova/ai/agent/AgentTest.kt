package com.nova.ai.agent

import com.nova.ai.agent.core.*
import com.nova.ai.agent.social.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

/** A scripted screen: each click moves to the next screen of the script. Fakes instead of mocks. */
class FakeScreenDriver(private val screens: List<List<String>>, private val pkg: String = "com.instagram.android") : ScreenDriver {
    var index = 0
    val clicks = ArrayList<String>()
    var staleOnClick = false
    var typed = ""
    private fun els(i: Int) = screens[minOf(i, screens.size - 1)].mapIndexed { n, t ->
        val edit = t.startsWith("[edit]")
        UiElement(n, t.removePrefix("[edit]").let { if (edit) typed.ifEmpty { it } else it }, "", !edit, edit, Bounds(0, 100 * n, 100, 100 * n + 90), if (edit) t.removePrefix("[edit]") else "")
    }
    override fun capture() = CapturedScreen(pkg, "w$index", els(index), 1080, 2400)
    override fun clickElement(obs: ScreenObservation, e: UiElement): DriverResult {
        if (staleOnClick) return DriverResult.STALE
        clicks.add(e.label); index++; return DriverResult.OK
    }
    override fun gestureTap(x: Int, y: Int) = DriverResult.OK
    override fun setText(text: String): DriverResult { typed = text; return DriverResult.OK }
    override fun scroll(forward: Boolean) = DriverResult.OK
    override fun back() = DriverResult.OK
    override fun home() = DriverResult.OK
}

@OptIn(ExperimentalCoroutinesApi::class)
class AgentTest {
    private fun request(mode: TaskMode = TaskMode.PUBLISH) = SocialTaskRequest(Platform.INSTAGRAM, SocialAction.CREATE_REEL, "content://m/1", "hi", mode, null)
    private fun runner(d: FakeScreenDriver, req: SocialTaskRequest, steps: List<PlanStep>, check: (ScreenObservation) -> Boolean = { true }): SocialTaskRunner {
        val o = ScreenObserver(d)
        return SocialTaskRunner("t1", req, steps, UiActionExecutor(d, o, { }), TextInputExecutor(d, o, { }), o, { true }, check, { })
    }
    private val tap = { n: String -> PlanStep(n, StepKind.TAP, TargetSpec(listOf(n))) }
    private val publish = PlanStep("Share", StepKind.PUBLISH, TargetSpec(listOf("Share")), irreversible = true)

    @Test fun legalAndIllegalTransitions() {
        val m = TaskStateMachine()
        m.moveTo(TaskState.OPENING_APP); m.moveTo(TaskState.OBSERVING); m.moveTo(TaskState.RESOLVING_TARGET)
        assertThrows(IllegalStateException::class.java) { m.moveTo(TaskState.COMPLETED) }
        assertThrows(IllegalStateException::class.java) { TaskStateMachine().moveTo(TaskState.VERIFYING) }
        for (s in TaskState.values().filter { !it.terminal }) {
            assertTrue(TaskStateMachine.isLegal(s, TaskState.FAILED)); assertTrue(TaskStateMachine.isLegal(s, TaskState.CANCELLED))
        }
        for (t in listOf(TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED)) for (s in TaskState.values()) assertFalse(TaskStateMachine.isLegal(t, s))
        assertEquals(listOf(TaskState.IDLE, TaskState.OPENING_APP, TaskState.OBSERVING, TaskState.RESOLVING_TARGET), m.history)
    }

    @Test fun publishWaitsForConfirmationAndConfirmWithoutAskIsRefused() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Reel", "Share"), listOf("Share"), listOf("Posted")))
        val r = runner(d, request(), listOf(tap("Reel"), publish))
        assertEquals("nothing_to_confirm", r.control(ControlCommand.CONFIRM))        // no prior yes needed: refused
        val job = async { r.run() }
        advanceUntilIdle()
        assertEquals(TaskStatus.WAITING_FOR_CONFIRMATION, r.status)
        assertEquals(listOf("Reel"), d.clicks)                                           // nothing irreversible yet
        assertEquals("confirmed", r.control(ControlCommand.CONFIRM))
        advanceUntilIdle()
        val rep = job.await()
        assertEquals(TaskStatus.COMPLETED, rep.status); assertEquals(listOf("Reel", "Share"), d.clicks)
    }

    @Test fun rejectNeverPublishes() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Share"), listOf("Share")))
        val r = runner(d, request(), listOf(publish))
        val job = async { r.run() }; advanceUntilIdle()
        r.control(ControlCommand.REJECT); advanceUntilIdle()
        assertEquals(TaskStatus.CANCELLED, job.await().status); assertTrue(d.clicks.isEmpty())
    }

    @Test fun draftNeverPublishes() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Save draft", "Share"), listOf("Draft saved")))
        val r = runner(d, request(TaskMode.DRAFT), listOf(publish))
        val rep = r.run()
        assertEquals(TaskStatus.DRAFT_SAVED, rep.status); assertFalse(d.clicks.contains("Share"))
    }

    @Test fun blockerPausesUntilResume() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Log in", "[edit]Password"), listOf("Reel")))
        val r = runner(d, request(), listOf(tap("Reel")))
        val job = async { r.run() }; advanceUntilIdle()
        assertEquals(TaskStatus.WAITING_FOR_USER, r.status)
        d.index = 1                                                                      // user logged in
        assertEquals("resumed", r.control(ControlCommand.RESUME)); advanceUntilIdle()
        assertEquals(TaskStatus.COMPLETED, job.await().status)
    }

    @Test fun unverifiedSubmissionIsReported() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Share"), listOf("Share")))
        val r = runner(d, request(), listOf(publish), check = { false })
        val job = async { r.run() }; advanceUntilIdle(); r.control(ControlCommand.CONFIRM); advanceUntilIdle()
        val rep = job.await()
        assertEquals(TaskStatus.SUBMITTED_UNVERIFIED, rep.status); assertTrue(rep.message.contains("could not confirm"))
    }

    @Test fun staleObservationIsNotClicked() = runTest {
        val d = FakeScreenDriver(listOf(listOf("Reel"))); d.staleOnClick = true
        val o = ScreenObserver(d)
        val res = UiActionExecutor(d, o, { }).click(TargetSpec(listOf("Reel")))
        assertEquals(ActionResult.Failed(FailureReason.STALE_OBSERVATION, ExecPhase.EXECUTE), res)
        val obs = o.observe()!!; o.observe()
        assertFalse(o.isLatest(obs))
    }

    @Test fun requestParsingValidatesFirst() {
        val known = { u: String -> u == "content://m/1" }
        fun p(vararg kv: Pair<String, String>) = SocialTaskRequest.parse(mapOf(*kv), known)
        assertTrue(p("platform" to "instagram", "action" to "create_post", "media_uri" to "content://m/1") is SocialTaskRequest.Parsed.Ok)
        assertTrue(p("platform" to "tiktok", "action" to "create_post") is SocialTaskRequest.Parsed.Invalid)
        assertTrue(p("platform" to "instagram", "action" to "create_post") is SocialTaskRequest.Parsed.Invalid)
        assertTrue(p("platform" to "instagram", "action" to "create_post", "media_uri" to "file:///sdcard/a.jpg") is SocialTaskRequest.Parsed.Invalid)
        assertTrue(p("platform" to "instagram", "action" to "create_post", "media_uri" to "content://other/9") is SocialTaskRequest.Parsed.Invalid)
        assertTrue(p("platform" to "instagram", "action" to "text_post", "caption" to "x") is SocialTaskRequest.Parsed.Invalid)
        assertTrue(p("platform" to "facebook", "action" to "text_post", "caption" to "hello") is SocialTaskRequest.Parsed.Ok)
        assertTrue(p("platform" to "facebook", "action" to "text_post", "caption" to "x", "mode" to "later") is SocialTaskRequest.Parsed.Invalid)
    }

    @Test fun targetResolverPrefersExactAndClickable() {
        val o = ScreenObservation(1, "p", "w", listOf(
            UiElement(0, "Share your story", "", true, false, Bounds(0, 0, 10, 10)),
            UiElement(1, "Share", "", true, false, Bounds(0, 20, 10, 30))), 1, 1, 0)
        assertEquals(1, TargetResolver.resolve(o, TargetSpec(listOf("Share")))!!.id)
        assertNull(TargetResolver.resolve(o, TargetSpec(listOf("Nope"))))
    }

    @Test fun blockerDetection() {
        fun obs(vararg t: String) = ScreenObservation(1, "p", "w", t.mapIndexed { i, s -> UiElement(i, s, "", true, false, Bounds(0, 0, 1, 1), if (s == "Password") "password" else "") }, 1, 1, 0)
        assertEquals(Blocker.CAPTCHA, BlockerDetector.detect(obs("Please solve the CAPTCHA")))
        assertEquals(Blocker.LOGIN, BlockerDetector.detect(obs("Log in", "Password")))
        assertNull(BlockerDetector.detect(obs("Reel", "Share")))
    }
}
