package com.nova.ai.forge

import org.junit.Assert.*
import org.junit.Test

class ForgeCoreTest {

    @Test fun sseParsing() {
        assertEquals("""{"a":1}""", SseParser.dataOf("""data: {"a":1}"""))
        assertNull(SseParser.dataOf("data: [DONE]")); assertNull(SseParser.dataOf("event: x")); assertNull(SseParser.dataOf("data:"))
        val multi = """{"candidates":[{"content":{"parts":[{"text":"Hel"},{"text":"lo"}]},"finishReason":"STOP"}]}"""
        assertEquals("Hello", SseParser.extractText(multi)); assertEquals("STOP", SseParser.extractFinishReason(multi))
        assertNull(SseParser.extractFinishReason("""{"candidates":[{"content":{"parts":[{"text":"x"}]}}]}"""))
        assertEquals("", SseParser.extractText("not json"))
        assertEquals("UNAVAILABLE: busy", SseParser.extractError("""{"error":{"status":"UNAVAILABLE","message":"busy"}}"""))
        assertNull(SseParser.extractError(multi))
    }

    @Test fun fencesAndHtmlChecks() {
        assertEquals("<html></html>", ForgeHtml.stripFences("```html\n<html></html>\n```"))
        assertEquals("<html></html>", ForgeHtml.stripFences("<html></html>"))
        assertTrue(ForgeHtml.looksLikeHtml("<!DOCTYPE html><html>")); assertFalse(ForgeHtml.looksLikeHtml("Sorry, I can't"))
    }

    @Test fun truncationRepair() {
        val r = ForgeHtml.repairTruncated("<html><body><style>a{}<script>var a=1;")
        assertTrue(r.endsWith("</html>")); assertTrue(r.contains("</script>")); assertTrue(r.contains("</body>"))
        val whole = "<html><body></body></html>"
        assertEquals(whole, ForgeHtml.repairTruncated(whole))
    }

    @Test fun safetyNetIsIdempotent() {
        val once = ForgeHtml.withSafetyNet("<html><body><p>hi</p></body></html>")
        assertTrue(once.contains(ForgeHtml.SAFETY_MARK))
        assertTrue(once.indexOf(ForgeHtml.SAFETY_MARK) < once.indexOf("</body>"))
        assertEquals(once, ForgeHtml.withSafetyNet(once))
    }

    @Test fun stageDetection() {
        val head = "<html><head><style>" + "a{}".repeat(5000) + "</style><script src=\"tailwind\"></script></head>"
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect(head))
        assertEquals(ForgeStage.STRUCTURE, ForgeStageDetector.detect("$head<body><nav>x</nav>"))
        assertEquals(ForgeStage.STYLING, ForgeStageDetector.detect("<body>" + "<div class=\"a\"></div>".repeat(16)))
        assertEquals(ForgeStage.CONTENT, ForgeStageDetector.detect("<body><section><h2>A</h2></section><section><h2>B</h2></section>"))
        assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect("<body><section></section><section></section><script>gsap.to()"))
        assertTrue(ForgeStageDetector.detect("<body><canvas></canvas>").ordinal >= ForgeStage.STYLING.ordinal)
        assertEquals(ForgeStage.FINISHING, ForgeStageDetector.detect("<body></body></html>"))
    }

    @Test fun progressStaysBelowOneUntilDone() {
        assertEquals(0f, ForgeStageDetector.progress(ForgeStage.PLANNING, 0), 0f)
        assertTrue(ForgeStageDetector.progress(ForgeStage.FINISHING, 1_000_000) < 1f)
        assertEquals(1f, ForgeStageDetector.progress(ForgeStage.FINISHING, 10, done = true), 0f)
    }

    @Test fun sectionNaming() {
        val h = "<section id=\"about-us\"><h2>x</h2></section><section><h2>Our <b>Menu</b></h2></section><section><p>no heading</p></section>"
        assertEquals(listOf("About us", "Our Menu", "Section 3"), ForgeStageDetector.sections(h))
    }

    @Test fun intentMatchesAndIgnores() {
        assertNotNull(ForgeIntent.extract("ek cafe ki website banao"))
        assertNotNull(ForgeIntent.extract("Build a landing page for my gym"))
        assertNotNull(ForgeIntent.extract("make me a website"))
        assertNull(ForgeIntent.extract("how do I build a website?"))
        assertNull(ForgeIntent.extract("what is a website"))
        assertNull(ForgeIntent.extract("website kya hai"))
        assertNull(ForgeIntent.extract("open youtube"))
    }

    @Test fun errorMapping() {
        assertTrue(ForgeErrors.friendly(503, "").contains("overloaded"))
        assertTrue(ForgeErrors.friendly(0, "UNAVAILABLE: x").contains("overloaded"))
        assertTrue(ForgeErrors.isOverloaded(503, "")); assertFalse(ForgeErrors.isOverloaded(400, ""))
        assertTrue(ForgeErrors.friendly(429, "").contains("quota"))
    }

    @Test fun modelPicking() {
        assertEquals("gemini-2.5-flash", WebsiteForgeClient.pickModel(listOf("gemini-2.0-pro", "gemini-2.5-flash-live", "gemini-2.5-flash-image", "gemini-2.5-flash-tts", "gemini-2.5-flash")))
        assertEquals("gemini-pro", WebsiteForgeClient.pickModel(listOf("gemini-pro")))
        assertNull(WebsiteForgeClient.pickModel(emptyList()))
    }

    @Test fun promptsCarryTheirInputs() {
        assertTrue(ForgeSystemPrompt.forNewSite("cafe").contains("cafe"))
        val e = ForgeSystemPrompt.forEdit("<html>OLD</html>", "darker")
        assertTrue(e.contains("OLD") && e.contains("darker"))
        assertTrue(ForgeSystemPrompt.SYSTEM.contains("Three.js") && ForgeSystemPrompt.SYSTEM.contains("never", true) || ForgeSystemPrompt.SYSTEM.contains("NEVER"))
    }
}
