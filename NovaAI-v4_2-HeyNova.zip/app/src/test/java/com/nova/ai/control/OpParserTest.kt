package com.nova.ai.control

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OpParserTest {
    @Test fun hinglishBrightnessDown() {
        val op = OpParser.parse("Nova, mere phone ki brightness kam kar do") as ControlOp.Brightness
        assertEquals(-20, op.delta); assertNull(op.pct)
    }
    @Test fun brightnessUpAndAbsolute() {
        assertEquals(20, (OpParser.parse("brightness badha do") as ControlOp.Brightness).delta)
        assertEquals(50, (OpParser.parse("set brightness to 50%") as ControlOp.Brightness).pct)
        assertEquals(100, (OpParser.parse("brightness full") as ControlOp.Brightness).pct)
    }
    @Test fun wifiAndBluetooth() {
        assertEquals(ControlOp.Wifi(false), OpParser.parse("wifi band kar do"))
        assertEquals(ControlOp.Wifi(true), OpParser.parse("turn wifi on"))
        assertEquals(ControlOp.Bluetooth(true), OpParser.parse("bluetooth chalu karo"))
        assertNull(OpParser.parse("bluetooth settings kholo"))
        assertNull(OpParser.parse("wifi status"))
    }
    @Test fun timeoutAndRotation() {
        assertEquals(ControlOp.ScreenTimeout(60), OpParser.parse("screen timeout 1 minute"))
        assertEquals(ControlOp.AutoRotate(false), OpParser.parse("auto rotate off"))
    }
    @Test fun forceStop() {
        assertEquals(ControlOp.ForceStop("youtube"), OpParser.parse("force stop youtube"))
        assertEquals(ControlOp.ForceStop("instagram", loose = true), OpParser.parse("close instagram"))
        assertEquals(ControlOp.ForceStop("instagram", loose = true), OpParser.parse("instagram band kar do"))
        assertNull(OpParser.parse("music band kar do"))
        assertNull(OpParser.parse("close wifi"))
    }
    @Test fun statusQuestions() {
        assertEquals(ControlOp.ShizukuStatusOp, OpParser.parse("shizuku status check karo"))
        assertEquals(ControlOp.Battery, OpParser.parse("battery kitni hai"))
        assertNull(OpParser.parse("tell me a joke"))
    }

    // ───────── uninstall / install (Part 5) ─────────
    @Test fun uninstallForms() {
        assertEquals(ControlOp.Uninstall("whatsapp"), OpParser.parse("uninstall whatsapp"))
        assertEquals(ControlOp.Uninstall("candy crush"), OpParser.parse("uninstall the app Candy Crush"))
        assertEquals(ControlOp.Uninstall("telegram"), OpParser.parse("Nova, uninstall telegram app"))
        assertEquals(ControlOp.Uninstall("telegram"), OpParser.parse("telegram ko uninstall karo"))
        assertEquals(ControlOp.Uninstall("whatsapp"), OpParser.parse("whatsapp uninstall kar do"))
    }

    @Test fun uninstallQuestionsAreNotCommands() {
        assertNull(OpParser.parse("how do i uninstall apps"))
        assertNull(OpParser.parse("how to uninstall"))
        assertNull(OpParser.parse("uninstall"))
    }

    @Test fun installApkForms() {
        assertEquals(ControlOp.InstallApk(""), OpParser.parse("install apk"))
        assertEquals(ControlOp.InstallApk("whatsapp"), OpParser.parse("install apk whatsapp"))
        assertEquals(ControlOp.InstallApk("my app"), OpParser.parse("install the apk file named my app"))
        assertEquals(ControlOp.InstallApk(""), OpParser.parse("apk install karo"))
        assertEquals(ControlOp.InstallApk("whatsapp"), OpParser.parse("whatsapp apk install kar do"))
    }

    @Test fun plainInstallIsLeftToOtherHandlers() = assertNull(OpParser.parse("install whatsapp"))
}
