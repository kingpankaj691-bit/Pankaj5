package com.nova.ai.permissions

import com.nova.ai.accessibility.A11yStatus
import com.nova.ai.control.ShizukuSnapshot
import com.nova.ai.files.FileAccessState
import org.junit.Assert.*
import org.junit.Test

class PermissionDashboardTest {
    private val goodA11y = A11yStatus(true, true, true, true, "com.google.android.youtube", false)
    private val goodShizuku = ShizukuSnapshot(installed = true, running = true, granted = true, serverVersion = 13, serverUid = 2000, serviceBound = true)
    private val noFiles = FileAccessState(33, true, false, false, false, false, false, false, 0, false, false)
    private val allFiles = noFiles.copy(allFilesGranted = true)

    private fun inputs(
        a11y: A11yStatus = goodA11y, shizuku: ShizukuSnapshot = goodShizuku, files: FileAccessState = allFiles, safTotal: Int = 2, safValid: Int = 2,
        mic: Boolean = true, micBlocked: Boolean = false, notif: Boolean = true, notifCanAsk: Boolean = false, capture: Boolean = true, online: Boolean? = true
    ) = DashInputs(a11y, shizuku, files, safTotal, safValid, mic, micBlocked, notif, notifCanAsk, capture, online)

    private fun item(i: DashInputs, id: String) = PermissionDashboard.build(i).first { it.id == id }

    @Test fun everythingFineMeansNoButtonsAndAnHonestSummary() {
        val items = PermissionDashboard.build(inputs())
        assertEquals(11, items.size)
        assertTrue(PermissionDashboard.allClear(items))
        assertTrue(items.all { it.state == DashState.OK })
        assertTrue(items.all { it.fix == DashFix.NONE })
        assertTrue(PermissionDashboard.summary(items).startsWith("11 checks passed"))
    }

    @Test fun nothingGrantedIsNeverReportedAsAllGood() {
        val i = inputs(a11y = A11yStatus(false, false, false, true, "", false), shizuku = ShizukuSnapshot(), files = noFiles, safTotal = 0, safValid = 0,
            mic = false, notif = false, notifCanAsk = true, capture = false, online = false)
        val items = PermissionDashboard.build(i)
        assertFalse(PermissionDashboard.allClear(items))
        val s = PermissionDashboard.summary(items)
        assertTrue(s, s.contains("need attention"))
        assertFalse(s.contains("Nothing needs attention"))
        assertEquals(DashFix.REQUEST_MIC, item(i, "mic").fix)
        assertEquals(DashFix.OPEN_ACCESSIBILITY, item(i, "a11y").fix)
        assertEquals(DashFix.OPEN_ALL_FILES, item(i, "allfiles").fix)
        assertEquals(DashFix.OPEN_NETWORK_SETTINGS, item(i, "net").fix)
    }

    @Test fun groupsAreTheFourAreas() =
        assertEquals(setOf(PermissionDashboard.G_VOICE, PermissionDashboard.G_SCREEN, PermissionDashboard.G_FILES, PermissionDashboard.G_SHIZUKU),
            PermissionDashboard.build(inputs()).map { it.group }.toSet())

    // ───────── microphone and notifications ─────────
    @Test fun aBlockedMicrophoneSendsYouToAppSettingsNotToADeadDialog() {
        assertEquals(DashFix.OPEN_APP_SETTINGS, item(inputs(mic = false, micBlocked = true), "mic").fix)
        assertEquals(DashFix.REQUEST_MIC, item(inputs(mic = false, micBlocked = false), "mic").fix)
    }

    @Test fun notificationFixDependsOnWhetherAndroidWillStillAsk() {
        assertEquals(DashFix.REQUEST_NOTIFICATIONS, item(inputs(notif = false, notifCanAsk = true), "notif").fix)
        assertEquals(DashFix.OPEN_NOTIFICATION_SETTINGS, item(inputs(notif = false, notifCanAsk = false), "notif").fix)
    }

    @Test fun internetStates() {
        assertEquals(DashState.OK, item(inputs(online = true), "net").state)
        assertEquals(DashState.ATTENTION, item(inputs(online = false), "net").state)
        assertEquals(DashState.NOT_APPLICABLE, item(inputs(online = null), "net").state)
    }

    // ───────── screen control ─────────
    @Test fun accessibilityEnabledInSettingsButNotConnected() {
        val it = item(inputs(a11y = A11yStatus(true, false, false, true, "", false)), "a11y")
        assertEquals(DashState.ATTENTION, it.state)
        assertTrue(it.detail.contains("isn't connected"))
        assertEquals(DashFix.OPEN_ACCESSIBILITY, it.fix)
    }

    @Test fun connectedButUnreadableHasNoFixButton() {
        val it = item(inputs(a11y = A11yStatus(true, true, false, true, "", false)), "a11y")
        assertEquals(DashState.ATTENTION, it.state)
        assertEquals(DashFix.NONE, it.fix)
    }

    @Test fun theScreenActionsSwitchIsIndependentOfTheService() {
        val i = inputs(a11y = A11yStatus(true, true, true, false, "com.x", false))
        assertEquals(DashState.OK, item(i, "a11y").state)
        assertEquals(DashState.ATTENTION, item(i, "actions").state)
        assertEquals(DashFix.ENABLE_SCREEN_ACTIONS, item(i, "actions").fix)
    }

    @Test fun screenCaptureIsOptional() {
        val it = item(inputs(capture = false), "capture")
        assertEquals(DashState.NOT_APPLICABLE, it.state)
        assertEquals(DashFix.START_SCREEN_CAPTURE, it.fix)
    }

    // ───────── Shizuku: three separate layers ─────────
    @Test fun shizukuNotInstalledIsOptionalNotAFailure() {
        val i = inputs(shizuku = ShizukuSnapshot())
        assertEquals(DashState.NOT_APPLICABLE, item(i, "sz_service").state)
        assertEquals(DashFix.SHIZUKU_INSTALL, item(i, "sz_service").fix)
        assertEquals(DashState.NOT_APPLICABLE, item(i, "sz_perm").state)
        assertEquals(DashState.NOT_APPLICABLE, item(i, "sz_bind").state)
        assertTrue(PermissionDashboard.allClear(PermissionDashboard.build(i)))
    }

    @Test fun installedButNotRunning() {
        val i = inputs(shizuku = ShizukuSnapshot(installed = true))
        assertEquals(DashState.ATTENTION, item(i, "sz_service").state)
        assertEquals(DashFix.SHIZUKU_OPEN, item(i, "sz_service").fix)
        assertEquals(DashState.NOT_APPLICABLE, item(i, "sz_perm").state)
    }

    @Test fun runningWithoutPermission() {
        val i = inputs(shizuku = ShizukuSnapshot(installed = true, running = true, serverVersion = 13, serverUid = 2000))
        assertEquals(DashState.OK, item(i, "sz_service").state)
        assertEquals(DashFix.SHIZUKU_REQUEST, item(i, "sz_perm").fix)
        assertEquals(DashFix.SHIZUKU_OPEN, item(inputs(shizuku = ShizukuSnapshot(installed = true, running = true, serverVersion = 13, permanentlyDenied = true)), "sz_perm").fix)
    }

    @Test fun permissionGrantedButShellNotConnected() {
        val i = inputs(shizuku = goodShizuku.copy(serviceBound = false))
        assertEquals(DashState.OK, item(i, "sz_perm").state)
        assertEquals(DashState.ATTENTION, item(i, "sz_bind").state)
        assertEquals(DashFix.SHIZUKU_RECONNECT, item(i, "sz_bind").fix)
    }

    @Test fun anOldShizukuIsAProblemWithAnUpdateFix() {
        val it = item(inputs(shizuku = goodShizuku.copy(serverVersion = 10)), "sz_service")
        assertEquals(DashState.ATTENTION, it.state)
        assertEquals(DashFix.SHIZUKU_UPDATE, it.fix)
    }

    @Test fun shizukuNeverStandsInForAllFilesAccess() {
        val i = inputs(files = noFiles)            // Shizuku fully working, All files access off
        assertEquals(DashState.OK, item(i, "sz_bind").state)
        assertEquals(DashState.ATTENTION, item(i, "allfiles").state)
    }

    // ───────── files ─────────
    @Test fun allFilesNotOfferedIsNotAFailure() =
        assertEquals(DashState.NOT_APPLICABLE, item(inputs(files = noFiles.copy(allFilesAvailable = false)), "allfiles").state)

    @Test fun chosenFolders() {
        assertEquals(DashState.NOT_APPLICABLE, item(inputs(safTotal = 0, safValid = 0), "saf").state)
        assertEquals(DashState.OK, item(inputs(safTotal = 3, safValid = 3), "saf").state)
        val lost = item(inputs(safTotal = 3, safValid = 1), "saf")
        assertEquals(DashState.ATTENTION, lost.state)
        assertTrue(lost.detail.contains("1 of 3"))
        assertEquals(DashFix.PICK_FOLDER, lost.fix)
    }

    // ───────── Android's "ask again?" rule ─────────
    @Test fun permanentlyDeniedTruthTable() {
        assertTrue(PermissionRules.permanentlyDenied(askedBefore = true, granted = false, showRationale = false))
        assertFalse(PermissionRules.permanentlyDenied(askedBefore = false, granted = false, showRationale = false))
        assertFalse(PermissionRules.permanentlyDenied(askedBefore = true, granted = false, showRationale = true))
        assertFalse(PermissionRules.permanentlyDenied(askedBefore = true, granted = true, showRationale = false))
    }
}
