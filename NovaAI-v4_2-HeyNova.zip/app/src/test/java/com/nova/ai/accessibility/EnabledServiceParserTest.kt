package com.nova.ai.accessibility

import org.junit.Assert.*
import org.junit.Test

class EnabledServiceParserTest {
    private val pkg = "com.nova.ai"
    private val cls = "com.nova.ai.accessibility.NovaAccessibilityService"

    @Test fun longForm() = assertTrue(EnabledServiceParser.contains("$pkg/$cls", pkg, cls))
    @Test fun shortForm() = assertTrue(EnabledServiceParser.contains("$pkg/.accessibility.NovaAccessibilityService", pkg, cls))
    @Test fun amongOtherServices() =
        assertTrue(EnabledServiceParser.contains("com.other/.Svc:$pkg/.accessibility.NovaAccessibilityService:com.third/com.third.X", pkg, cls))
    @Test fun otherServicesOnly() = assertFalse(EnabledServiceParser.contains("com.other/.Svc:com.third/com.third.X", pkg, cls))
    @Test fun differentClassOfSamePackage() = assertFalse(EnabledServiceParser.contains("$pkg/$pkg.other.Service", pkg, cls))
    @Test fun nullAndBlank() {
        assertFalse(EnabledServiceParser.contains(null, pkg, cls))
        assertFalse(EnabledServiceParser.contains("   ", pkg, cls))
    }
    @Test fun malformedEntriesDoNotCrash() {
        assertFalse(EnabledServiceParser.contains("garbage::/:$pkg/", pkg, cls))
    }
}
