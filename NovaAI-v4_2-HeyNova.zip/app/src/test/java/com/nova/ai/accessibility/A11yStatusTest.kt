package com.nova.ai.accessibility

import org.junit.Assert.*
import org.junit.Test

class A11yStatusTest {
    private fun st(
        enabled: Boolean? = true, connected: Boolean = true, readable: Boolean = true,
        actions: Boolean = true, fg: String = "com.google.android.youtube", blocked: Boolean = false
    ) = A11yStatus(enabled, connected, readable, actions, fg, blocked)

    @Test fun readyWhenEverythingIsOk() {
        val s = st()
        assertEquals(A11yProblem.NONE, s.problem)
        assertTrue(s.ready)
        assertTrue(s.explain().contains("com.google.android.youtube"))
    }

    @Test fun notEnabledInSettings() = assertEquals(A11yProblem.NOT_ENABLED_IN_SETTINGS, st(enabled = false, connected = false).problem)

    @Test fun enabledButNotConnectedIsItsOwnProblem() {
        assertEquals(A11yProblem.NOT_CONNECTED, st(enabled = true, connected = false).problem)
        assertEquals(A11yProblem.NOT_CONNECTED, st(enabled = null, connected = false).problem)
    }

    @Test fun connectedServiceWinsOverStaleSettingsValue() = assertEquals(A11yProblem.NONE, st(enabled = false, connected = true).problem)

    @Test fun masterSwitchOff() = assertEquals(A11yProblem.ACTIONS_SWITCH_OFF, st(actions = false).problem)

    @Test fun unreadableScreen() {
        val s = st(readable = false)
        assertEquals(A11yProblem.SCREEN_UNREADABLE, s.problem)
        assertFalse(s.ready)
    }

    @Test fun blockedForegroundApp() = assertEquals(A11yProblem.BLOCKED_APP, st(blocked = true).problem)

    @Test fun priorityOrderIsConnectionThenSwitchThenReadabilityThenApp() {
        assertEquals(A11yProblem.NOT_CONNECTED, st(connected = false, actions = false, readable = false, blocked = true).problem)
        assertEquals(A11yProblem.ACTIONS_SWITCH_OFF, st(actions = false, readable = false, blocked = true).problem)
        assertEquals(A11yProblem.SCREEN_UNREADABLE, st(readable = false, blocked = true).problem)
    }

    @Test fun explanationsExistInBothLanguagesForEveryProblem() {
        val all = listOf(
            st(), st(enabled = false, connected = false), st(connected = false), st(actions = false), st(readable = false), st(blocked = true)
        )
        for (s in all) {
            assertTrue(s.explain(false).isNotBlank())
            assertTrue(s.explain(true).isNotBlank())
            assertNotEquals(s.explain(false), s.explain(true))
        }
    }
}
