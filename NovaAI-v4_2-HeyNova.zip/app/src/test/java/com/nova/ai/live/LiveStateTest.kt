package com.nova.ai.live

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Voice state transitions, session lifecycle rules, reconnect policy and the Gemini Live message details. Pure JVM tests. */
class LiveStateTest {

    private fun map(running: Boolean = true, paused: Boolean = false, active: Boolean = true, state: LiveOrbState = LiveOrbState.LISTENING,
                    reconnecting: Boolean = false, micOpen: Boolean = true, legacy: String = "") =
        LiveStatusMapper.map(running, paused, active, state, reconnecting, micOpen, legacy)

    // ───────── status mapping ─────────

    @Test fun readyWhenServiceIsOffOrPaused() {
        assertEquals(LiveStatus.READY, map(running = false, active = false, state = LiveOrbState.IDLE, micOpen = false))
        assertEquals(LiveStatus.READY, map(paused = true))
    }

    @Test fun twoWayEngineStatesMapOneToOne() {
        assertEquals(LiveStatus.CONNECTING, map(state = LiveOrbState.CONNECTING))
        assertEquals(LiveStatus.LISTENING, map(state = LiveOrbState.LISTENING))
        assertEquals(LiveStatus.THINKING, map(state = LiveOrbState.THINKING))
        assertEquals(LiveStatus.SPEAKING, map(state = LiveOrbState.SPEAKING))
        assertEquals(LiveStatus.ERROR, map(state = LiveOrbState.ERROR))
    }

    @Test fun reconnectingWinsOverConnecting() {
        assertEquals(LiveStatus.RECONNECTING, map(state = LiveOrbState.CONNECTING, reconnecting = true))
    }

    @Test fun errorIsShownEvenIfTheServiceFlagsLag() {
        assertEquals(LiveStatus.ERROR, map(running = false, state = LiveOrbState.ERROR))
    }

    @Test fun otherSpeechModesUseTheOlderStatus() {
        assertEquals(LiveStatus.CONNECTING, map(active = false, micOpen = false))
        assertEquals(LiveStatus.LISTENING, map(active = false, micOpen = true))
        assertEquals(LiveStatus.THINKING, map(active = false, legacy = "Thinking"))
        assertEquals(LiveStatus.SPEAKING, map(active = false, legacy = "Speaking"))
    }

    @Test fun fullConversationLifecycle() {
        // tap mic -> connecting -> listening -> user stops talking -> thinking -> model audio -> speaking -> listening
        val seen = ArrayList<LiveStatus>()
        fun step(s: LiveOrbState, reconnecting: Boolean = false) { seen.add(map(state = s, reconnecting = reconnecting)) }
        step(LiveOrbState.CONNECTING); step(LiveOrbState.LISTENING); step(LiveOrbState.THINKING); step(LiveOrbState.SPEAKING)
        step(LiveOrbState.LISTENING)
        // connection drops -> reconnecting -> back to listening
        step(LiveOrbState.CONNECTING, reconnecting = true); step(LiveOrbState.LISTENING)
        assertEquals(
            listOf(LiveStatus.CONNECTING, LiveStatus.LISTENING, LiveStatus.THINKING, LiveStatus.SPEAKING, LiveStatus.LISTENING, LiveStatus.RECONNECTING, LiveStatus.LISTENING),
            seen
        )
        // tap again -> session closed -> ready
        assertEquals(LiveStatus.READY, map(running = false, active = false, state = LiveOrbState.IDLE, micOpen = false))
    }

    // ───────── reconnect policy ─────────

    @Test fun reconnectBacksOffAndStopsAtTheLimit() {
        val p = ReconnectPolicy(maxAttempts = 3, baseDelayMs = 1000, maxDelayMs = 2500)
        assertEquals(1000L, p.next()); assertEquals(2000L, p.next()); assertEquals(2500L, p.next())
        assertNull(p.next())                                // limit reached: no endless loop
        assertEquals(3, p.attempts)
        p.reset()
        assertEquals(1000L, p.next())                       // a successful session resets the counter
    }

    // ───────── errors ─────────

    @Test fun errorsThatRetryingCannotFixAreFatal() {
        assertTrue(LiveErrors.classify(403, null, "").fatal)
        assertTrue(LiveErrors.classify(null, 1008, "API key not valid. Please pass a valid API key.").fatal)
        assertTrue(LiveErrors.classify(null, 1007, "models/x is not found for API version v1beta, or is not supported for bidiGenerateContent").fatal)
        assertTrue(LiveErrors.classify(429, null, "").fatal)
        assertTrue(LiveErrors.classify(null, 1011, "Resource has been exhausted (e.g. check quota).").fatal)
        val transient = LiveErrors.classify(null, 1006, "")
        assertFalse(transient.fatal)
        assertTrue(transient.message.contains("1006"))
    }

    private class Rec : GeminiLiveClient.Listener {
        val ev = ArrayList<String>()
        override fun onSetupComplete() { ev.add("setup") }
        override fun onAudioChunk(pcm24k: ByteArray) { ev.add("audio") }
        override fun onInputTranscript(text: String) { ev.add("in") }
        override fun onOutputTranscript(text: String) { ev.add("out") }
        override fun onToolCall(id: String, name: String, args: JSONObject) { ev.add("tool") }
        override fun onTurnComplete() { ev.add("done") }
        override fun onInterrupted() { ev.add("int") }
        override fun onError(message: String) { ev.add("err:$message") }
        override fun onClosed() { ev.add("closed") }
        override fun onFatalError(message: String) { ev.add("fatal:$message") }
    }

    @Test fun serverErrorMessageBecomesFatalOrTransient() {
        val r = Rec(); val d = ToolCallDeduplicator()
        LiveMessageParser.parse("""{"error":{"code":403,"message":"API key not valid"}}""", r, d)
        LiveMessageParser.parse("""{"error":{"code":500,"message":"internal hiccup"}}""", r, d)
        assertTrue(r.ev[0].startsWith("fatal:"))
        assertEquals("err:internal hiccup", r.ev[1])
    }

    @Test fun oneServerEventCanCarryAudioTranscriptAndInterruption() {
        val r = Rec(); val d = ToolCallDeduplicator()
        val audio = java.util.Base64.getEncoder().encodeToString(ByteArray(960))
        LiveMessageParser.parse(
            """{"serverContent":{"modelTurn":{"parts":[{"inlineData":{"mimeType":"audio/pcm;rate=24000","data":"$audio"}},{"inlineData":{"mimeType":"audio/pcm;rate=24000","data":"$audio"}}]},"outputTranscription":{"text":"Namaste"},"interrupted":true}}""",
            r, d
        )
        assertEquals(listOf("audio", "audio", "out", "int"), r.ev)        // both audio parts are kept, then transcript, then interruption
    }

    // ───────── model + setup ─────────

    @Test fun modelPathAddsThePrefixOnce() {
        assertEquals("models/gemini-3.8-live", GeminiLiveClient.modelPath("gemini-3.8-live"))
        assertEquals("models/gemini-3.8-live", GeminiLiveClient.modelPath("models/gemini-3.8-live"))
        assertEquals("models/gemini-3.8-live", GeminiLiveClient.MODEL)
    }

    @Test fun function3_8DeclaredBlockingOldModelsUntouched() {
        val tools = JSONArray().put(JSONObject().put("name", "open_app"))
        val new = setupMessage("models/gemini-3.8-live", "sys", "Aoede", tools).getJSONObject("setup")
        assertEquals("BLOCKING", new.getJSONArray("tools").getJSONObject(0).getJSONArray("functionDeclarations").getJSONObject(0).getString("behavior"))
        assertFalse(tools.getJSONObject(0).has("behavior"))                // the caller's declarations are not modified
        val old = setupMessage("models/gemini-3.1-flash-live-preview", "sys", "Aoede", tools).getJSONObject("setup")
        assertFalse(old.getJSONArray("tools").getJSONObject(0).getJSONArray("functionDeclarations").getJSONObject(0).has("behavior"))
        assertTrue(new.has("inputAudioTranscription") && new.has("outputAudioTranscription"))
    }

    // ───────── speaker ─────────

    @Test fun pcmIsSplitInto20msSlicesWithoutLosingData() {
        val pcm = ByteArray(24000 * 2 / 10) { (it % 100).toByte() }          // 100 ms
        val s = LiveSpeaker.slices(pcm)
        assertEquals(5, s.size)
        assertTrue(s.all { it.size == 960 })
        assertEquals(pcm.size, s.sumOf { it.size })
        assertArrayEquals(pcm, s.fold(ByteArray(0)) { a, b -> a + b })
        assertTrue(LiveSpeaker.slices(ByteArray(0)).isEmpty())
        val odd = LiveSpeaker.slices(ByteArray(1001))                      // never a half sample
        assertTrue(odd.all { it.size % 2 == 0 })
    }
}
