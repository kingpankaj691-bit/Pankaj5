package com.nova.ai.control

import org.junit.Assert.*
import org.junit.Test

class ShizukuReportTest {
    private fun snap(installed: Boolean = true, running: Boolean = true, granted: Boolean = false, denied: Boolean = false, ver: Int = 13, uid: Int = 2000, bound: Boolean = false) =
        ShizukuSnapshot(installed = installed, running = running, granted = granted, permanentlyDenied = denied, serverVersion = ver, serverUid = uid, serviceBound = bound)

    private fun line(s: ShizukuSnapshot, label: String) = ShizukuReport.lines(s).first { it.label.startsWith(label) }

    @Test fun notInstalled() {
        val s = snap(installed = false, running = false)
        assertFalse(line(s, "Shizuku app").ok)
        assertEquals(ShizukuFix.INSTALL_SHIZUKU, line(s, "Shizuku app").fix)
        assertFalse(ShizukuReport.usable(s))
    }

    @Test fun installedButNotRunning() {
        val s = snap(running = false)
        assertTrue(line(s, "Shizuku app").ok)
        assertEquals(ShizukuFix.OPEN_SHIZUKU_APP, line(s, "Shizuku service").fix)
    }

    @Test fun runningButOld() {
        val s = snap(ver = 10)
        assertFalse(line(s, "Shizuku version").ok)
        assertEquals(ShizukuFix.UPDATE_SHIZUKU, line(s, "Shizuku version").fix)
    }

    @Test fun permissionNotGrantedVersusDeniedForever() {
        assertEquals(ShizukuFix.REQUEST_PERMISSION, line(snap(), "Nova has").fix)
        assertEquals(ShizukuFix.OPEN_SHIZUKU_APP, line(snap(denied = true), "Nova has").fix)
    }

    @Test fun permissionGrantedButShellServiceNotConnected() {
        val s = snap(granted = true, bound = false)
        assertTrue(line(s, "Nova has").ok)
        assertFalse(line(s, "Shell service").ok)
        assertEquals(ShizukuFix.RECONNECT, line(s, "Shell service").fix)
        assertFalse(ShizukuReport.usable(s))
    }

    @Test fun everythingConnected() {
        val s = snap(granted = true, bound = true)
        assertTrue(ShizukuReport.usable(s))
        assertTrue(line(s, "Shizuku service").detail.contains("adb"))
    }

    @Test fun theNoteSeparatesShizukuFromOtherPermissions() {
        assertTrue(ShizukuReport.NOTE.contains("Accessibility"))
        assertTrue(ShizukuReport.NOTE.contains("All files"))
    }

    // ───────── self test checks the ANSWER ─────────
    @Test fun selfTestPassesOnlyWithTheRightAnswer() {
        assertTrue(ShizukuSelfTest.evaluate(ShellResult(true, 0, "33\n", ""), 33).ok)
        assertFalse(ShizukuSelfTest.evaluate(ShellResult(true, 0, "34\n", ""), 33).ok)
        assertFalse(ShizukuSelfTest.evaluate(ShellResult(true, 0, "", ""), 33).ok)
    }

    @Test fun selfTestExplainsFailures() {
        assertTrue(ShizukuSelfTest.evaluate(ShellResult(false, 125, "", "Shizuku is not ready (needs permission)."), 33).message.contains("failed"))
        assertTrue(ShizukuSelfTest.evaluate(ShellResult(false, 126, "", "blocked", blocked = true), 33).message.contains("policy"))
    }
}
