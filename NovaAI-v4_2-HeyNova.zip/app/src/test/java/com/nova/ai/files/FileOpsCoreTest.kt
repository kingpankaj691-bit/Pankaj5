package com.nova.ai.files

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class FileOpsCoreTest {
    private lateinit var root: File

    @Before fun setUp() { root = Files.createTempDirectory("novafm").toFile() }
    @After fun tearDown() { root.deleteRecursively() }

    private fun file(rel: String, text: String = "hello"): File = File(root, rel).also { it.parentFile.mkdirs(); it.writeText(text) }
    private fun dir(rel: String): File = File(root, rel).also { it.mkdirs() }

    // ── names ──
    @Test fun nameValidation() {
        assertNull(NameRules.validate("report final.pdf"))
        assertNotNull(NameRules.validate("  "))
        assertNotNull(NameRules.validate("a/b"))
        assertNotNull(NameRules.validate(".."))
        assertNotNull(NameRules.validate("what?"))
        assertNotNull(NameRules.validate("x".repeat(201)))
    }

    @Test fun uniqueNameNeverOverwrites() {
        val taken = setOf("a.pdf", "a (1).pdf", "b")
        assertEquals("a (2).pdf", NameRules.uniqueName("a.pdf") { it in taken })
        assertEquals("c.pdf", NameRules.uniqueName("c.pdf") { it in taken })
        assertEquals("b (1)", NameRules.uniqueName("b") { it in taken })
        assertEquals(".hidden (1)", NameRules.uniqueName(".hidden") { it == ".hidden" })
    }

    @Test fun zipEntryNames() {
        assertEquals("a/b.txt", ZipRules.safeEntryName("a/b.txt"))
        assertEquals("a/b.txt", ZipRules.safeEntryName("a\\b.txt"))
        assertNull(ZipRules.safeEntryName("../evil.txt"))
        assertNull(ZipRules.safeEntryName("a/../../evil.txt"))
        assertNull(ZipRules.safeEntryName("/etc/passwd"))
        assertNull(ZipRules.safeEntryName("C:/x"))
        assertNull(ZipRules.safeEntryName(""))
    }

    @Test fun deleteGuard() {
        val roots = listOf("/storage/emulated/0")
        assertNotNull(DeleteGuard.refusal("/storage/emulated/0", roots))
        assertNotNull(DeleteGuard.refusal("/storage/emulated/0/Download", roots))
        assertNotNull(DeleteGuard.refusal("/storage/emulated/0/DCIM", roots))
        assertNotNull(DeleteGuard.refusal("/storage/emulated/0/Android/data/com.x", roots))
        assertNotNull(DeleteGuard.refusal("/data/data/com.x", roots))
        assertNull(DeleteGuard.refusal("/storage/emulated/0/Download/old.zip", roots))
        assertNull(DeleteGuard.refusal("/storage/emulated/0/MyFolder", roots))
    }

    @Test fun organizePlan() {
        fun mk(n: String, dir: Boolean = false) = FileItem("/x/$n", n, dir, 1, 1, if (dir) FileKind.FOLDER else FileTypes.kindOf(n), null, "", "/x")
        val plan = OrganizePlanner.plan(listOf(mk("a.pdf"), mk("b.jpg"), mk("c.mp4"), mk("d.docx"), mk("e.zip"), mk("f.apk"), mk("g.kt"), mk("h.xyz"), mk("sub", true), mk(".hid.txt")))
        assertEquals(8, plan.size)
        assertEquals("Documents", plan.first { it.name == "d.docx" }.toFolder)
        assertEquals("Other", plan.first { it.name == "h.xyz" }.toFolder)
        assertEquals("Documents" to 2, OrganizePlanner.summary(plan).first())
    }

    @Test fun duplicateRules() {
        fun mk(n: String, size: Long, mod: Long) = FileItem("/x/$n", n, false, size, mod, FileKind.OTHER)
        val a = mk("a", 10, 300); val b = mk("b", 10, 100); val c = mk("c", 10, 200); val d = mk("d", 99, 1)
        assertEquals(1, DuplicateRules.sizeCandidates(listOf(a, b, c, d)).size)
        val groups = listOf(listOf(a, b, c))
        assertEquals(setOf("/x/a", "/x/c"), DuplicateRules.extras(groups))          // oldest (b) is kept
        assertTrue(DuplicateRules.safeSelection(groups, setOf("/x/a", "/x/c")))
        assertFalse(DuplicateRules.safeSelection(groups, setOf("/x/a", "/x/b", "/x/c")))
        assertEquals(20L, DuplicateRules.wasted(groups))
    }

    // ── real file operations ──
    @Test fun copyFileKeepsOriginalAndNeverOverwrites() {
        val src = file("in/a.txt", "data"); val dest = dir("out")
        val r1 = LocalFs.copy(src, dest); assertTrue(r1.message, r1.ok)
        assertEquals("data", File(dest, "a.txt").readText()); assertTrue(src.exists())
        val r2 = LocalFs.copy(src, dest); assertTrue(r2.ok)
        assertTrue(File(dest, "a (1).txt").exists())
        assertEquals("data", File(dest, "a.txt").readText())
    }

    @Test fun copyFolderRecursivelyAndRefuseIntoItself() {
        val src = dir("proj"); file("proj/x.txt", "1"); file("proj/sub/y.txt", "22")
        val dest = dir("out")
        assertTrue(LocalFs.copy(src, dest).ok)
        assertEquals("22", File(dest, "proj/sub/y.txt").readText())
        val bad = LocalFs.copy(src, File(src, "sub")); assertFalse(bad.ok)
        assertFalse(File(src, "sub/proj").exists())
    }

    @Test fun moveFileAndAlreadyThere() {
        val src = file("a/m.txt", "mv"); val dest = dir("b")
        val r = LocalFs.move(src, dest); assertTrue(r.message, r.ok)
        assertFalse(src.exists()); assertEquals("mv", File(dest, "m.txt").readText())
        assertTrue(LocalFs.move(File(dest, "m.txt"), dest).message.contains("already"))
        assertFalse(LocalFs.move(File(root, "ghost"), dest).ok)
    }

    @Test fun moveFolderIntoItselfRefused() {
        val d = dir("p"); dir("p/q")
        assertFalse(LocalFs.move(d, File(d, "q")).ok); assertTrue(d.exists())
    }

    @Test fun renameRules() {
        val f = file("r.txt"); file("taken.txt")
        assertFalse(LocalFs.rename(f, "a/b").ok)
        assertFalse(LocalFs.rename(f, "taken.txt").ok); assertTrue(f.exists())
        assertTrue(LocalFs.rename(f, "new.txt").ok)
        assertTrue(File(root, "new.txt").exists()); assertFalse(f.exists())
    }

    @Test fun mkdirRules() {
        assertTrue(LocalFs.mkdir(root, "Docs").ok)
        assertFalse(LocalFs.mkdir(root, "Docs").ok)
        assertFalse(LocalFs.mkdir(root, "bad/name").ok)
    }

    @Test fun deleteFileAndFolder() {
        val f = file("d/x.txt"); file("d/y/z.txt")
        assertTrue(LocalFs.delete(f).ok); assertFalse(f.exists())
        assertTrue(LocalFs.delete(File(root, "d")).ok); assertFalse(File(root, "d").exists())
        assertTrue(LocalFs.delete(File(root, "d")).ok)       // already gone is fine
    }

    @Test fun zipThenUnzipRoundTrip() {
        val a = file("src/a.txt", "AAA"); val d = dir("src/folder"); file("src/folder/b.txt", "BB")
        val zip = File(root, "out.zip")
        val z = LocalFs.zip(listOf(a, d), zip); assertTrue(z.message, z.ok); assertEquals(2, z.done)
        val dest = dir("ex")
        val u = LocalFs.unzip(zip, dest); assertTrue(u.message, u.ok)
        assertEquals("AAA", File(dest, "out/a.txt").readText())
        assertEquals("BB", File(dest, "out/folder/b.txt").readText())
        assertTrue(a.exists())
    }

    @Test fun unzipBlocksZipSlip() {
        val zip = File(root, "evil.zip")
        ZipOutputStream(zip.outputStream()).use { z -> z.putNextEntry(ZipEntry("../evil.txt")); z.write("x".toByteArray()); z.closeEntry() }
        val dest = dir("ex")
        val r = LocalFs.unzip(zip, dest)
        assertFalse(r.ok)
        assertFalse(File(root, "evil.txt").exists())
        assertFalse(File(dest, "evil").exists())              // partial output removed
        assertTrue(dest.listFiles()!!.isEmpty())
    }

    @Test fun zipOfNothingFails() = assertFalse(LocalFs.zip(emptyList(), File(root, "n.zip")).ok)

    @Test fun sha256KnownValue() =
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", LocalFs.sha256(file("abc.txt", "abc")))

    @Test fun duplicatesByContent() {
        val a = file("a.txt", "same!"); val b = file("sub/b.txt", "same!"); val c = file("c.txt", "diff!"); file("empty1.txt", ""); file("empty2.txt", "")
        val groups = LocalFs.findDuplicates(LocalFs.listFiles(listOf(root)))
        assertEquals(1, groups.size)
        assertEquals(setOf(a.canonicalPath, b.canonicalPath), groups[0].map { it.canonicalPath }.toSet())
        assertFalse(groups[0].any { it.name == c.name })
    }

    @Test fun cancelledScanReturnsNothingInsteadOfGuessing() {
        file("a.txt", "same!"); file("b.txt", "same!")
        assertTrue(LocalFs.findDuplicates(LocalFs.listFiles(listOf(root)), alive = { false }).isEmpty())
    }
}
