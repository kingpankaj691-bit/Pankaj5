package com.nova.ai.accessibility

import org.junit.Assert.*
import org.junit.Test

class TextVerifyTest {
    @Test fun sameText() = assertTrue(TextVerify.matches("lofi songs", "lofi songs"))
    @Test fun caseAndWhitespaceAreIgnored() = assertTrue(TextVerify.matches("Lofi  Songs ", " lofi songs"))
    @Test fun nullMeansNotTyped() = assertFalse(TextVerify.matches("lofi", null))
    @Test fun emptyFieldIsNotTyped() = assertFalse(TextVerify.matches("lofi", ""))
    @Test fun differentTextFails() = assertFalse(TextVerify.matches("lofi songs", "lofi son"))
    @Test fun unicodeNormalisation() = assertTrue(TextVerify.matches("caf\u00e9", "cafe\u0301"))
    @Test fun hindiText() = assertTrue(TextVerify.matches("अरिजीत सिंह", "अरिजीत  सिंह"))
}
