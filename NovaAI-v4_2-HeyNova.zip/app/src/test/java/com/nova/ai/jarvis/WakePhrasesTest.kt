package com.nova.ai.jarvis

import org.junit.Assert.*
import org.junit.Test

/** Wake phrases, the recognition plan built from model vocabularies, and the conversation window. Pure JVM tests. */
class WakePhrasesTest {
    private val en = setOf("hey", "hello", "hi", "nova", "jaan", "how", "are", "you", "listen", "there", "meri", "baat", "suno", "kaisi", "ho", "kya", "kar", "rahi")
    private val enNoJaan = en - "jaan"
    private val hiVocab = setOf("जान", "कैसी", "हो", "क्या", "कर", "रही", "हेलो", "सुनो", "नोवा", "मेरी", "बात", "हाय", "हे", "लिसन")
    private val all = WakePhrases.builtins("nova")
    private fun on(ids: List<String> = WakePhrases.DEFAULT_IDS) = WakePhrases.enabled(all, ids)

    @Test fun allTwelveRequestedPhrasesExistAndAreOnByDefault() {
        val labels = on().map { it.label }
        assertEquals(listOf("Hey Nova", "Hello Nova", "Hi Nova", "Hi Jaan", "Hey Jaan", "Hello Jaan", "Jaan, how are you?",
            "Jaan, kaisi ho?", "Jaan, kya kar rahi ho?", "Hello Jaan, suno", "Nova, meri baat suno", "Jaan, listen"), labels)
    }

    @Test fun oldIdsAreMappedAndBlankFallsBackToDefaults() {
        assertEquals(listOf("hey_nova", "nova_listen"), WakePhrases.parseIds("hey,listen,bogus"))
        assertEquals(WakePhrases.DEFAULT_IDS, WakePhrases.parseIds(""))
        assertEquals(emptyList<String>(), WakePhrases.parseIds(WakePhrases.NONE))
    }

    @Test fun fullVocabularyEveryPhraseIsReadyAndGrammarHasTheExactPhrases() {
        val plan = WakePhrases.plan(on(), mapOf(WakePhrases.EN to en, WakePhrases.HI to hiVocab))
        assertTrue(plan.unavailable.isEmpty())
        assertEquals(WakePhrases.EN, plan.modelFor("hey_jaan"))
        assertEquals(WakePhrases.HI, plan.modelFor("jaan_kaisi"))        // Hindi phrases prefer the Hindi model
        assertEquals(WakePhrases.EN, plan.modelFor("nova_suno"))         // "nova meri baat suno" is in the English vocabulary here
        val g = plan.models.first { it.model == WakePhrases.HI }.grammar
        assertTrue(g.contains("\"जान कैसी हो\""))
        assertTrue(g.endsWith(",\"[unk]\"]"))
    }

    @Test fun aWordTheModelDoesNotKnowIsNeverSilentlyDropped() {
        // "jaan" missing from the English model: the English forms of the Jaan phrases must not be used (it would fire on a bare "hi")
        val plan = WakePhrases.plan(on(listOf("hi_jaan", "hi_nova")), mapOf(WakePhrases.EN to enNoJaan))
        assertEquals(WakePhrases.EN, plan.modelFor("hi_nova"))
        assertNull(plan.modelFor("hi_jaan"))
        assertTrue(plan.unavailable["hi_jaan"]!!.contains("jaan"))
        assertFalse(plan.models.single().grammar.contains("hi jaan"))
    }

    @Test fun missingModelIsReportedAndOnlyNeededModelsAreLoaded() {
        val plan = WakePhrases.plan(on(listOf("hey_nova", "jaan_kaisi")), mapOf(WakePhrases.EN to en))
        // jaan_kaisi has an English form whose words are all known, so it still works on the English model alone
        assertEquals(listOf(WakePhrases.EN), plan.models.map { it.model })
        val onlyHindi = WakePhrases.plan(on(listOf("jaan_kaisi")), mapOf())
        assertTrue(onlyHindi.isEmpty)
        assertTrue(onlyHindi.unavailable["jaan_kaisi"]!!.contains("model"))
    }

    @Test fun unverifiedVocabularyIsAssumedValid() {
        val plan = WakePhrases.plan(on(listOf("hey_jaan")), mapOf(WakePhrases.EN to null))
        assertEquals(WakePhrases.EN, plan.modelFor("hey_jaan"))
    }

    @Test fun identifyFindsTheRightPhraseAndIgnoresOrdinaryTalk() {
        val plan = WakePhrases.plan(on(), mapOf(WakePhrases.EN to en, WakePhrases.HI to hiVocab))
        val enPlan = plan.models.first { it.model == WakePhrases.EN }
        val hiPlan = plan.models.first { it.model == WakePhrases.HI }
        assertEquals("hey_nova", enPlan.identify("hey nova"))
        assertEquals("hello_nova", enPlan.identify("[unk] hello nova open youtube"))
        assertEquals("hi_jaan", enPlan.identify("hi jaan"))
        assertEquals("jaan_kaisi", hiPlan.identify("जान कैसी हो"))
        assertEquals("jaan_kya", hiPlan.identify("जान क्या कर रही हो"))
        assertNull(enPlan.identify("hi"))                      // half a phrase
        assertNull(enPlan.identify("jaan"))
        assertNull(enPlan.identify("[unk]"))
        assertNull(hiPlan.identify("जान"))
    }

    @Test fun customPhrasesNeedTwoWordsAndPickTheModelByScript() {
        assertNotNull(WakePhrases.validateCustom("buddy"))
        assertNull(WakePhrases.validateCustom("hey buddy"))
        assertNotNull(WakePhrases.validateCustom("a b c d e f g"))
        val raw = WakePhrases.addCustom(WakePhrases.addCustom("", "Hey Buddy!"), "सुनो नोवा")
        val cat = WakePhrases.catalog("nova", raw)
        val customs = cat.filter { it.custom }
        assertEquals(listOf("c:hey buddy", "c:सुनो नोवा"), customs.map { it.id })
        assertEquals(WakePhrases.EN, customs[0].forms[0].model)
        assertEquals(WakePhrases.HI, customs[1].forms[0].model)
        assertEquals(listOf("c:सुनो नोवा"), WakePhrases.parseCustom(WakePhrases.removeCustom(raw, "c:hey buddy")).map { "c:$it" })
        // custom phrases are always on
        assertEquals(2, WakePhrases.enabled(cat, emptyList()).count { it.custom })
    }

    // ───────── custom wake word manager ─────────

    private fun cat(raw: String) = WakePhrases.catalog("nova", raw) { t -> if (t == "meri jaan") listOf("मेरी जान") else emptyList() }

    @Test fun yourExamplesAreAccepted() {
        val c = cat("")
        for (p in listOf("Meri Jaan", "Jaan Suno", "Nova Listen")) assertNull(p, WakePhrases.validateCustom(p))
        // "Nova Listen" already exists as an (off by default) built-in, "Jaan Suno" and "Meri Jaan" are new
        assertNotNull(WakePhrases.checkCustom(c, "nova listen"))
        assertNull(WakePhrases.checkCustom(c, "Jaan Suno"))
        assertNull(WakePhrases.checkCustom(c, "Meri Jaan"))
    }

    @Test fun duplicatesAreDetectedAcrossBuiltinsCustomsAndSpellings() {
        val raw = WakePhrases.addCustom("", "jaan suno")
        val c = cat(raw)
        assertTrue(WakePhrases.checkCustom(c, "Hey, Nova!")!!.contains("Hey Nova"))
        assertTrue(WakePhrases.checkCustom(c, "JAAN SUNO")!!.contains("Already"))
        assertTrue(WakePhrases.checkCustom(c, "जान कैसी हो")!!.contains("Already"))   // a Devanagari spelling a built-in already uses
        assertNull(WakePhrases.checkCustom(c, "jaan suno", exceptId = "c:jaan suno"))    // editing a phrase may keep its own text
    }

    @Test fun falseActivationProtection() {
        assertNotNull(WakePhrases.validateCustom("hey you"))          // only everyday words
        assertNotNull(WakePhrases.validateCustom("kya hai"))
        assertNotNull(WakePhrases.validateCustom("hi no"))            // too short
        assertNotNull(WakePhrases.validateCustom("nova"))             // one word
        assertNull(WakePhrases.validateCustom("hey buddy"))
    }

    @Test fun enableDisableEditDeleteAndPersistenceFormat() {
        var raw = WakePhrases.addCustom(WakePhrases.addCustom("", "jaan suno"), "meri jaan")
        assertEquals("1|jaan suno\n1|meri jaan", raw)
        raw = WakePhrases.setCustomEnabled(raw, "c:meri jaan", false)
        assertEquals("1|jaan suno\n0|meri jaan", raw)
        assertEquals(listOf(true, false), WakePhrases.parseEntries(raw).map { it.on })
        raw = WakePhrases.editCustom(raw, "c:meri jaan", "meri pyari jaan")
        assertEquals("1|jaan suno\n0|meri pyari jaan", raw)            // keeps position and off state
        raw = WakePhrases.removeCustom(raw, "c:jaan suno")
        assertEquals("0|meri pyari jaan", raw)
        // older versions stored plain lines: they stay on
        assertEquals(listOf(true, true), WakePhrases.parseEntries("hey buddy\n  ok buddy ").map { it.on })
    }

    @Test fun disabledPhrasesAreNotListenedForButTheDefaultAlwaysIs() {
        val c = cat("1|jaan suno\n0|meri jaan")
        val ids = listOf("hey_nova", "hi_jaan")
        assertEquals(listOf("hey_nova", "hi_jaan", "c:jaan suno"), WakePhrases.enabled(c, ids).map { it.id })
        // default is a phrase that is switched off: it is still on
        assertEquals(listOf("hey_nova", "hi_jaan", "c:jaan suno", "c:meri jaan"), WakePhrases.enabled(c, ids, "c:meri jaan").map { it.id })
        // nothing ticked at all: Hey Nova (default) remains
        assertEquals(listOf("hey_nova"), WakePhrases.enabled(cat(""), emptyList()).map { it.id })
        // a default that no longer exists falls back to Hey Nova
        assertEquals(listOf("hey_nova"), WakePhrases.enabled(cat(""), emptyList(), "c:gone").map { it.id })
    }

    @Test fun savedPhrasesReachTheRecognitionPlan() {
        // The English model does not know "jaan"; the Hindi model does: "Meri Jaan" runs on the Hindi model through its Devanagari spelling.
        val c = cat("1|meri jaan\n1|jaan suno")
        val plan = WakePhrases.plan(WakePhrases.enabled(c, emptyList()).filter { it.custom },
            mapOf(WakePhrases.EN to (en - "jaan"), WakePhrases.HI to (hiVocab + setOf("मेरी"))))
        assertEquals(WakePhrases.HI, plan.modelFor("c:meri jaan"))
        assertTrue(plan.models.single { it.model == WakePhrases.HI }.grammar.contains("\"मेरी जान\""))
        assertEquals("c:meri jaan", plan.models.single { it.model == WakePhrases.HI }.identify("मेरी जान"))
        // "jaan suno" has no Devanagari guess in this fake translit and the English model lacks "jaan": reported, not weakened
        assertNull(plan.modelFor("c:jaan suno"))
        assertTrue(plan.unavailable["c:jaan suno"]!!.contains("jaan"))
        // editing the phrase changes the grammar
        val edited = cat(WakePhrases.editCustom("1|meri jaan", "c:meri jaan", "nova listen please")).filter { it.custom }
        val p2 = WakePhrases.plan(edited, mapOf(WakePhrases.EN to en + "please"))
        assertEquals("c:nova listen please", p2.models.single().identify("nova listen please"))
        assertNull(p2.models.single().identify("meri jaan"))
    }

    @Test fun renamedAssistantChangesTheNovaPhrasesButNotTheJaanOnes() {
        val p = WakePhrases.builtins("Max")
        assertEquals("hey max", p.first { it.id == "hey_nova" }.forms.first().text)
        assertEquals(1, p.first { it.id == "hey_nova" }.forms.size)           // no Devanagari form for a custom name
        assertEquals("hey jaan", p.first { it.id == "hey_jaan" }.forms.first().text)
    }

    @Test fun questionPhrasesAreAnsweredAndGreetingsAreNot() {
        val by = all.associateBy { it.id }
        assertEquals("kaisi ho?", by["jaan_kaisi"]!!.reply)
        assertEquals("how are you?", by["jaan_how"]!!.reply)
        assertEquals("", by["hello_jaan_suno"]!!.reply)
        assertNull(by["hey_nova"]!!.reply)
        assertTrue(by["nova_suno"]!!.hindi)
    }

    @Test fun matchAndStripStillWork() {
        val p = listOf("hey nova")
        assertEquals("hey nova", WakePhrases.match("Hey, Nova!", p))
        assertNull(WakePhrases.match("nova", p))
        assertNull(WakePhrases.match("hey novak", p))
        val all = listOf("hey nova", "hello nova", "nova are you there")
        assertEquals("open youtube", WakePhrases.strip("Hey Nova open youtube", all))
        assertEquals("", WakePhrases.strip("nova are you there", all))
        assertEquals("what is the time", WakePhrases.strip("what is the time", all))
    }

    @Test fun lowConfidenceFinalResultsAreRejected() {
        val good = """{"result":[{"conf":0.98,"word":"hey"},{"conf":0.9,"word":"nova"}],"text":"hey nova"}"""
        val bad = """{"result":[{"conf":0.31,"word":"hey"},{"conf":0.4,"word":"nova"},{"conf":0.1,"word":"[unk]"}],"text":"hey nova"}"""
        assertTrue(WakePhrases.confident(good, 0.55f))
        assertFalse(WakePhrases.confident(bad, 0.55f))
        assertTrue(WakePhrases.confident("""{"text":"hey nova"}""", 0.55f))
    }

    @Test fun grammarJsonEscapes() {
        assertEquals("[\"hey nova\",\"[unk]\"]", WakePhrases.grammarJson(listOf("hey nova")))
    }

    // ───────── conversation window ─────────

    @Test fun windowStaysOpenWhileNovaIsBusyAndClosesAfterFollowUpTime() {
        val w = ConversationWindow(initialMs = 10_000, followUpMs = 8_000)
        assertFalse(w.isOpen(0))
        w.open(1_000)
        assertTrue(w.isOpen(10_999))
        assertFalse(w.isOpen(11_000))
        w.touch(9_000, active = true)
        assertTrue(w.isOpen(16_999))
        w.touch(12_000, active = false)
        assertFalse(w.isOpen(17_000))
    }

    @Test fun reopeningNeverShortensTheWindow() {
        val w = ConversationWindow(initialMs = 10_000, followUpMs = 8_000)
        w.open(0); w.touch(9_000, true)
        w.open(9_500)
        assertTrue(w.isOpen(19_000))
        w.close()
        assertFalse(w.isOpen(100))
    }
}
