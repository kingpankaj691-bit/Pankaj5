package com.nova.ai.brain

/** Plain-Kotlin copy of the store so the memory logic can be tested on the JVM. SQLite itself is covered by BrainInstrumentedTest. */
class InMemoryBrainStore : BrainStore {
    private var nextId = 1L
    private val itemsMap = LinkedHashMap<Long, BrainItem>()
    private val versionsMap = HashMap<Long, MutableList<Pair<Int, String>>>()
    private val turnList = ArrayList<Turn>()
    private val topicMap = LinkedHashMap<Long, TopicRec>()
    private val state = HashMap<String, String>()
    private val projectMap = LinkedHashMap<Long, ProjectRec>()
    private val fileList = ArrayList<FileRec>()
    private val reminderMap = LinkedHashMap<Long, ReminderRec>()
    private val vaultMap = LinkedHashMap<Long, VaultRec>()

    override fun saveItem(item: BrainItem): Long {
        if (item.id == 0L) { val id = nextId++; itemsMap[id] = item.copy(id = id, version = 1); return id }
        val old = itemsMap[item.id]
        var ver = old?.version ?: item.version
        if (old != null && old.content != item.content) { versionsMap.getOrPut(item.id) { ArrayList() }.add(old.version to old.content); ver++ }
        itemsMap[item.id] = item.copy(version = ver)
        return item.id
    }
    override fun item(id: Long) = itemsMap[id]
    override fun items() = itemsMap.values.sortedWith(compareByDescending<BrainItem> { it.pinned }.thenByDescending { it.updatedAt })
    override fun deleteItem(id: Long): Boolean { versionsMap.remove(id); reminderMap.values.removeAll { it.itemId == id }; return itemsMap.remove(id) != null }
    override fun deleteCategory(cat: BrainCategory): Int { val ids = itemsMap.values.filter { it.category == cat }.map { it.id }; ids.forEach { deleteItem(it) }; return ids.size }
    override fun deleteAllItems(): Int { val n = itemsMap.size; itemsMap.clear(); versionsMap.clear(); reminderMap.clear(); return n }
    override fun versions(itemId: Long) = versionsMap[itemId]?.reversed() ?: emptyList()
    override fun touch(ids: Collection<Long>, now: Long) { ids.forEach { id -> itemsMap[id]?.let { itemsMap[id] = it.copy(lastUsedAt = now) } } }

    override fun addTurn(t: Turn): Long { val id = nextId++; turnList.add(t.copy(id = id)); return id }
    override fun turns(limit: Int, topicId: Long) = turnList.filter { topicId == 0L || it.topicId == topicId }.takeLast(limit)
    override fun clearTurns() = turnList.clear()

    override fun saveTopic(t: TopicRec): Long { if (t.id == 0L) { val id = nextId++; topicMap[id] = t.copy(id = id); return id }; topicMap[t.id] = t; return t.id }
    override fun topic(id: Long) = topicMap[id]
    override fun topics() = topicMap.values.sortedByDescending { it.updatedAt }
    override fun deleteTopic(id: Long) { topicMap.remove(id) }

    override fun getState(key: String) = state[key]
    override fun putState(key: String, value: String) { state[key] = value }
    override fun statePrefix(prefix: String) = state.filterKeys { it.startsWith(prefix) }

    override fun saveProject(p: ProjectRec): Long { if (p.id == 0L) { val id = nextId++; projectMap[id] = p.copy(id = id); return id }; projectMap[p.id] = p; return p.id }
    override fun projects() = projectMap.values.toList()
    override fun deleteProject(id: Long) { projectMap.remove(id); fileList.removeAll { it.projectId == id } }
    override fun replaceFiles(projectId: Long, files: List<FileRec>) { fileList.removeAll { it.projectId == projectId }; files.forEach { fileList.add(it.copy(id = nextId++)) } }
    override fun files(projectId: Long) = fileList.filter { projectId == 0L || it.projectId == projectId }

    override fun saveReminder(r: ReminderRec): Long { if (r.id == 0L) { val id = nextId++; reminderMap[id] = r.copy(id = id); return id }; reminderMap[r.id] = r; return r.id }
    override fun reminders() = reminderMap.values.sortedBy { it.fireAt }
    override fun deleteReminder(id: Long) { reminderMap.remove(id) }

    override fun saveVault(v: VaultRec): Long { if (v.id == 0L) { val id = nextId++; vaultMap[id] = VaultRec(id, v.label, v.kind, v.cipher, v.createdAt, v.updatedAt); return id }; vaultMap[v.id] = v; return v.id }
    override fun vault() = vaultMap.values.toList()
    override fun deleteVault(id: Long) { vaultMap.remove(id) }

    override fun integrityOk() = true
    override fun sizeBytes() = 0L
    override fun wipeAll() { itemsMap.clear(); versionsMap.clear(); turnList.clear(); topicMap.clear(); state.clear(); projectMap.clear(); fileList.clear(); reminderMap.clear() }
    override fun <T> tx(block: () -> T): T = block()
}
