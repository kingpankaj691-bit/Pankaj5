package com.nova.ai.screen

import org.junit.Assert.*
import org.junit.Test

class ActionValidatorTest {
    @Test fun notConnectedIsDeniedWithAReason() {
        val v = ActionValidator.baseFor(false, true, "")
        assertTrue(v is Verdict.Denied)
        assertTrue((v as Verdict.Denied).reason.contains("isn't connected"))
    }

    @Test fun masterSwitchOffIsDenied() {
        val v = ActionValidator.baseFor(true, false, "com.google.android.youtube")
        assertTrue(v is Verdict.Denied)
        assertTrue((v as Verdict.Denied).reason.contains("switched off"))
    }

    @Test fun paymentAppIsDenied() = assertTrue(ActionValidator.baseFor(true, true, "com.phonepe.app") is Verdict.Denied)

    @Test fun normalAppsAreAllowed() {
        assertEquals(Verdict.Allowed, ActionValidator.baseFor(true, true, "com.google.android.youtube"))
        assertEquals(Verdict.Allowed, ActionValidator.baseFor(true, true, "com.whatsapp"))
        assertEquals(Verdict.Allowed, ActionValidator.baseFor(true, true, ""))
    }

    @Test fun packageBlockRules() {
        assertTrue(ActionValidator.packageBlocked("com.sbi.bankapp"))
        assertTrue(ActionValidator.packageBlocked("com.mobile.hdfcbanking"))
        assertTrue(ActionValidator.packageBlocked("in.org.npci.upiapp"))
        assertTrue(ActionValidator.packageBlocked("com.example.upi.pay"))
        assertTrue(ActionValidator.packageBlocked("com.android.packageinstaller"))
        assertFalse(ActionValidator.packageBlocked("com.example.groupie"))
        assertFalse(ActionValidator.packageBlocked("com.google.android.youtube"))
        assertFalse(ActionValidator.packageBlocked("com.samsung.android.honeyboard"))
        assertFalse(ActionValidator.packageBlocked("com.whatsapp"))
        assertFalse(ActionValidator.packageBlocked(""))
    }

    @Test fun credentialFieldsAreRecognised() {
        listOf("Password", "Enter OTP", "Enter PIN", "Card number", "Verification code", "mPIN", "One-time password", "CVV")
            .forEach { assertTrue("should be secret: $it", ActionValidator.isSecretField(it)) }
    }

    @Test fun ordinaryFieldsAreNotSecret() {
        listOf("Search YouTube", "Search", "Message", "PIN code", "PIN-code", "Pincode", "Name", "Spinning wheel")
            .forEach { assertFalse("should not be secret: $it", ActionValidator.isSecretField(it)) }
    }

    @Test fun riskyWordsAskForConfirmation() {
        listOf("Delete", "Send money", "Subscribe now", "Uninstall", "Place order").forEach { assertTrue(it, ActionValidator.isRisky(it)) }
        listOf("Search", "Play", "Subscribe", "Home").forEach { assertFalse(it, ActionValidator.isRisky(it)) }
    }
}
