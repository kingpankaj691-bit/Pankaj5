package com.nova.ai.brain

import org.junit.Assert.*
import org.junit.Test

class IndexSafetyTest {
    private fun rec(path: String) = FileRec(projectId = 1, uri = "content://x/$path", name = path.substringAfterLast('/'), relPath = path)
    private val old = listOf(rec("src/A.kt"), rec("docs/B.md"), rec("README.md"), rec("srcx/F.kt"))

    @Test fun filesUnderAnUnreadableFolderAreKept() =
        assertEquals(listOf("src/A.kt"), IndexSafety.keepUnreadable(old, listOf("src")).map { it.relPath })

    @Test fun aSiblingWithTheSamePrefixIsNotKept() =
        assertFalse(IndexSafety.keepUnreadable(old, listOf("src")).any { it.relPath.startsWith("srcx") })

    @Test fun anUnreadableRootKeepsEverything() = assertEquals(4, IndexSafety.keepUnreadable(old, listOf("")).size)

    @Test fun nothingSkippedMeansNothingKept() = assertTrue(IndexSafety.keepUnreadable(old, emptyList()).isEmpty())

    @Test fun severalUnreadableFolders() =
        assertEquals(setOf("src/A.kt", "docs/B.md"), IndexSafety.keepUnreadable(old, listOf("src", "docs")).map { it.relPath }.toSet())
}
