package com.nova.ai.files

import org.junit.Assert.*
import org.junit.Test

class FileAccessPolicyTest {
    private fun st(
        sdk: Int = 33, avail: Boolean = true, all: Boolean = false, img: Boolean = false, vid: Boolean = false, aud: Boolean = false,
        sel: Boolean = false, legacy: Boolean = false, saf: Int = 0, shizuku: Boolean = false, write: Boolean = false
    ) = FileAccessState(sdk, avail, all, img, vid, aud, sel, legacy, saf, shizuku, write)

    private fun denied(a: Access) = a as Access.Denied
    private fun d(s: FileAccessState, n: FileNeed) = FileAccessPolicy.decide(s, n)

    @Test fun nothingGrantedOnAndroid13NamesEachMissingPermission() {
        val s = st()
        assertEquals(FixAction.REQUEST_MEDIA_PERMISSION, denied(d(s, FileNeed.IMAGES)).fix)
        assertEquals(FixAction.REQUEST_MEDIA_PERMISSION, denied(d(s, FileNeed.AUDIO)).fix)
        assertEquals(FixAction.OPEN_ALL_FILES_SETTINGS, denied(d(s, FileNeed.DOCUMENTS)).fix)
        assertEquals(FixAction.OPEN_ALL_FILES_SETTINGS, denied(d(s, FileNeed.ANY_PATH)).fix)
        assertEquals(FixAction.OPEN_ALL_FILES_SETTINGS, denied(d(s, FileNeed.WRITE)).fix)
    }

    @Test fun mediaPermissionOnlyCoversMediaNotDocuments() {
        val s = st(img = true)
        assertEquals("photos permission", (d(s, FileNeed.IMAGES) as Access.Granted).via)
        assertTrue(d(s, FileNeed.VIDEOS) is Access.Denied)
        assertTrue(d(s, FileNeed.DOCUMENTS) is Access.Denied)
        assertNull(FileAccessPolicy.searchProblem(s, listOf("image/%")))
        val pdf = FileAccessPolicy.searchProblem(s, listOf("application/pdf"))
        assertNotNull(pdf)
        assertTrue(pdf!!.contains("All files access"))
    }

    @Test fun anAllKindsSearchStillRunsWhenOnlySomeKindsAreAllowed() = assertNull(FileAccessPolicy.searchProblem(st(img = true), emptyList()))

    @Test fun allFilesAccessCoversEverythingWithoutMediaPermissions() {
        val s = st(all = true)
        FileNeed.values().forEach { assertEquals(it.name, "All files access", (d(s, it) as Access.Granted).via) }
        assertNull(FileAccessPolicy.searchProblem(s, listOf("application/pdf")))
    }

    @Test fun selectedPhotosOnlyIsPartialAndDoesNotCoverAudio() {
        val s = st(sdk = 34, sel = true)
        val g = d(s, FileNeed.IMAGES) as Access.Granted
        assertTrue(g.partial)
        assertTrue(d(s, FileNeed.AUDIO) is Access.Denied)
    }

    @Test fun android9LegacyPermissionCoversDocumentsButWritingNeedsItsOwn() {
        val s = st(sdk = 28, avail = false, legacy = true)
        assertTrue(d(s, FileNeed.DOCUMENTS) is Access.Granted)
        assertEquals(FixAction.REQUEST_WRITE_PERMISSION, denied(d(s, FileNeed.WRITE)).fix)
        assertTrue(d(st(sdk = 28, avail = false, legacy = true, write = true), FileNeed.WRITE) is Access.Granted)
    }

    @Test fun android10AndPlayBuildsFallBackToPickingAFolder() {
        assertEquals(FixAction.PICK_FOLDER, denied(d(st(sdk = 29, avail = false), FileNeed.DOCUMENTS)).fix)
        assertEquals(FixAction.PICK_FOLDER, denied(d(st(sdk = 29, avail = false), FileNeed.WRITE)).fix)
        assertEquals(FixAction.PICK_FOLDER, denied(d(st(sdk = 33, avail = false), FileNeed.DOCUMENTS)).fix)
    }

    @Test fun shizukuAllowsLimitedWritesAndSaysSo() {
        val g = d(st(shizuku = true), FileNeed.WRITE) as Access.Granted
        assertTrue(g.partial)
        assertTrue(g.via.contains("Shizuku"))
        assertTrue(g.via.contains("rename"))
    }

    @Test fun mimeNeeds() {
        assertEquals(setOf(FileNeed.IMAGES, FileNeed.VIDEOS, FileNeed.AUDIO, FileNeed.DOCUMENTS), FileAccessPolicy.needsFor(emptyList()))
        assertEquals(setOf(FileNeed.IMAGES, FileNeed.VIDEOS), FileAccessPolicy.needsFor(listOf("image/%", "video/%")))
        assertEquals(setOf(FileNeed.DOCUMENTS), FileAccessPolicy.needsFor(listOf("application/pdf", "text/plain")))
    }

    @Test fun hinglishReasonsDifferFromEnglish() {
        val s = st()
        FileNeed.values().forEach {
            val en = denied(FileAccessPolicy.decide(s, it, false)).reason
            val hi = denied(FileAccessPolicy.decide(s, it, true)).reason
            assertTrue(it.name, en.isNotBlank() && hi.isNotBlank())
            assertNotEquals(it.name, en, hi)
        }
    }

    @Test fun reportNeverShowsAnythingGrantedWhenAndroidGrantedNothing() {
        val lines = FileAccessPolicy.report(st())
        assertEquals(8, lines.size)
        assertTrue(lines.none { it.ok == true })
        val all = lines.first { it.label == "All files access" }
        assertEquals(false, all.ok)
        assertEquals(FixAction.OPEN_ALL_FILES_SETTINGS, all.fix)
    }

    @Test fun reportReflectsRealGrants() {
        val lines = FileAccessPolicy.report(st(all = true, img = true, saf = 2, shizuku = true))
        assertEquals(true, lines.first { it.label == "All files access" }.ok)
        assertEquals(true, lines.first { it.label == "Photos" }.ok)
        assertEquals(false, lines.first { it.label == "Videos" }.ok)
        assertEquals("2 folder(s)", lines.first { it.label == "Chosen folders (SAF)" }.detail)
        assertEquals(true, lines.first { it.label == "Shizuku file helper" }.ok)
    }

    @Test fun allFilesLineIsNotApplicableWhenNotOffered() = assertNull(FileAccessPolicy.report(st(avail = false)).first { it.label == "All files access" }.ok)
}
