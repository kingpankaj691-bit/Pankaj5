package com.nova.ai.planner

import org.junit.Assert.*
import org.junit.Test

class TaskPlannerYoutubeBrowserTest {
    private val ytOpen = Step.OpenApp("youtube")

    private fun steps(s: String) = TaskPlanner.plan(s)?.steps

    @Test fun openYoutubeAndSearch() =
        assertEquals(listOf(ytOpen, Step.SearchInApp("lofi songs")), steps("Open YouTube and search for lofi songs"))

    @Test fun openYoutubeAndPlayOpensTheResultAndChecksPlayback() =
        assertEquals(
            listOf(ytOpen, Step.SearchInApp("arijit singh songs"), Step.OpenResult(0), Step.VerifyPlayback),
            steps("open youtube and play arijit singh songs")
        )

    @Test fun hinglishYoutubeParPlayKaro() =
        assertEquals(
            listOf(ytOpen, Step.SearchInApp("lofi songs"), Step.OpenResult(0), Step.VerifyPlayback),
            steps("YouTube par lofi songs play karo")
        )

    @Test fun hinglishYoutubeSearchKaroDoesNotPlay() =
        assertEquals(listOf(ytOpen, Step.SearchInApp("lofi songs")), steps("youtube me lofi songs search karo"))

    @Test fun playXOnYoutube() =
        assertEquals(listOf(ytOpen, Step.SearchInApp("believer"), Step.OpenResult(0), Step.VerifyPlayback), steps("play believer on youtube"))

    @Test fun youtubeKholoAurChalao() =
        assertEquals(
            listOf(ytOpen, Step.SearchInApp("arijit singh ke gaane"), Step.OpenResult(0), Step.VerifyPlayback),
            steps("YouTube kholo aur arijit singh ke gaane chalao")
        )

    @Test fun commaSeparatedClausesAlsoPlay() =
        assertEquals(
            listOf(ytOpen, Step.SearchInApp("lofi"), Step.OpenResult(0), Step.VerifyPlayback),
            steps("open youtube, play lofi")
        )

    @Test fun queryKeepsItsCapitalisation() =
        assertEquals(Step.SearchInApp("Arijit Singh"), steps("Open YouTube and search Arijit Singh")?.get(1))

    // ───────── browser ─────────
    @Test fun chromeSearchOpensTheNamedBrowserAndReadsResults() =
        assertEquals(listOf(Step.OpenBrowser("chrome"), Step.SearchInApp("best laptops"), Step.ReadResults), steps("chrome me best laptops search karo"))

    @Test fun genericBrowserMeansTheUsersBrowser() =
        assertEquals(listOf(Step.OpenBrowser(null), Step.SearchInApp("kotlin coroutines"), Step.ReadResults), steps("open browser and search for kotlin coroutines"))

    @Test fun searchOnNamedBrowser() =
        assertEquals(listOf(Step.OpenBrowser("firefox"), Step.SearchInApp("kotlin"), Step.ReadResults), steps("search kotlin on firefox"))

    @Test fun openFirstResultIsPartOfThePlan() =
        assertEquals(listOf(Step.OpenBrowser("chrome"), Step.SearchInApp("weather"), Step.OpenResult(1)), steps("open chrome and search weather and open the first result"))

    @Test fun openChromeThenScrollUsesTheBrowserStep() =
        assertEquals(listOf(Step.OpenBrowser("chrome"), Step.Scroll(true)), steps("open chrome and scroll down"))

    // ───────── things that must stay unchanged ─────────
    @Test fun loneOpenAppIsLeftToTheLauncher() {
        assertNull(TaskPlanner.plan("open youtube"))
        assertNull(TaskPlanner.plan("open chrome"))
    }

    @Test fun nonScreenRequestsAreNotPlans() {
        assertNull(TaskPlanner.plan("what is the weather today"))
        assertNull(TaskPlanner.plan("play music"))
    }

    @Test fun planFlags() {
        val p = TaskPlanner.plan("open youtube and play lofi")!!
        assertTrue(p.needsInternet)
        assertTrue(p.touchesScreen)
        assertTrue(p.summary().contains("check that it is playing"))
    }
}
