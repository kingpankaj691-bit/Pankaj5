package com.nova.ai.screen

import org.junit.Assert.*
import org.junit.Test

class AppNameMatcherTest {
    private val yt = "com.google.android.youtube"
    private val ytMusic = "com.google.android.apps.youtube.music"
    private val ytKids = "com.google.android.apps.youtube.mango"

    @Test fun exactPackageForSpokenNames() {
        assertEquals(yt, AppNameMatcher.exactPackageFor("YouTube"))
        assertEquals(yt, AppNameMatcher.exactPackageFor("You Tube!"))
        assertEquals("com.whatsapp", AppNameMatcher.exactPackageFor("WhatsApp"))
        assertNull(AppNameMatcher.exactPackageFor("Camera"))
    }

    @Test fun youtubeNeverOpensMusicOrKids() {
        val apps = listOf("YouTube Music" to ytMusic, "YouTube Kids" to ytKids, "YouTube" to yt)
        assertEquals(yt, AppNameMatcher.pickBest(apps, "youtube"))
        assertEquals(ytMusic, AppNameMatcher.pickBest(apps, "youtube music"))
    }

    @Test fun doesNotGuessALookalikeWhenTheKnownAppIsMissing() {
        val apps = listOf("YouTube Music" to ytMusic, "YouTube Kids" to ytKids)
        assertNull(AppNameMatcher.pickBest(apps, "youtube"))
    }

    @Test fun whatsappBeatsWhatsappBusiness() {
        val apps = listOf("WhatsApp Business" to "com.whatsapp.w4b", "WhatsApp" to "com.whatsapp")
        assertEquals("com.whatsapp", AppNameMatcher.pickBest(apps, "whatsapp"))
        assertEquals("com.whatsapp.w4b", AppNameMatcher.pickBest(apps, "whatsapp business"))
    }

    @Test fun genericNamesRankExactThenWholeWordThenPrefix() {
        val apps = listOf("Camera Tools" to "x.tools", "Camera" to "x.camera", "Calculator" to "x.calc")
        assertEquals("x.camera", AppNameMatcher.pickBest(apps, "camera"))
        assertEquals("x.calc", AppNameMatcher.pickBest(apps, "calc"))
    }

    @Test fun plainWhatsappFallsBackToBusinessWhenThatIsAllThereIs() {
        assertEquals("com.whatsapp.w4b", AppNameMatcher.pickBest(listOf("WhatsApp Business" to "com.whatsapp.w4b"), "whatsapp"))
        assertNull(AppNameMatcher.pickBest(listOf("Camera" to "x.camera"), "whatsapp"))
    }

    @Test fun noMatchReturnsNull() = assertNull(AppNameMatcher.pickBest(listOf("Camera" to "x.camera"), "xyz"))

    @Test fun shorterLabelWinsATie() {
        val apps = listOf("Giant Pro" to "a", "Big Pro" to "b")
        assertEquals("b", AppNameMatcher.pickBest(apps, "pro"))
    }
}
