package com.nova.ai.planner

import org.junit.Assert.*
import org.junit.Test

class TaskPlannerWhatsAppTest {
    private val open = Step.OpenApp("whatsapp")
    private fun steps(s: String) = TaskPlanner.plan(s)?.steps

    @Test fun hinglishSendWithWhatsappFirst() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "hello")), steps("WhatsApp par Rahul ko hello bhejo"))

    @Test fun hinglishSendWithContactFirst() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "hello")), steps("Rahul ko WhatsApp par hello bhejo"))

    @Test fun hinglishMessageBhejoKi() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "main late hun")), steps("Rahul ko whatsapp par message bhejo ki main late hun"))

    @Test fun englishSendSaying() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "I will be late")), steps("send a whatsapp message to Rahul saying I will be late"))

    @Test fun englishSendOnWhatsapp() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "hello")), steps("send message to Rahul on whatsapp saying hello"))

    @Test fun quotesAroundTheMessageAreRemoved() =
        assertEquals(listOf(open, Step.WhatsAppSend("Rahul", "hello there")), steps("whatsapp par Rahul ko \"hello there\" bhejo"))

    @Test fun aVagueMessageIsNeverSentLiterally() = assertNull(steps("Rahul ko whatsapp par message bhejo"))

    @Test fun openChatForms() {
        assertEquals(listOf(open, Step.WhatsAppOpenChat("Rahul")), steps("open Rahul's chat on whatsapp"))
        assertEquals(listOf(open, Step.WhatsAppOpenChat("Rahul")), steps("WhatsApp par Rahul ki chat kholo"))
        assertEquals(listOf(open, Step.WhatsAppOpenChat("Priya")), steps("open whatsapp chat with Priya"))
    }

    @Test fun readForms() {
        assertEquals(listOf(open, Step.ReadWhatsApp), steps("read my whatsapp messages"))
        assertEquals(listOf(open, Step.ReadWhatsApp), steps("WhatsApp par chats dikhao"))
    }

    @Test fun loneOpenWhatsappIsLeftToTheLauncher() = assertNull(steps("open whatsapp"))

    @Test fun theSummaryShownBeforeRunningMentionsTheConfirmation() {
        val p = TaskPlanner.plan("WhatsApp par Rahul ko hello bhejo")!!
        assertTrue(p.touchesScreen)
        assertTrue(p.summary().contains("I will ask before sending"))
        assertTrue(p.summary().contains("Rahul"))
    }

    @Test fun nonWhatsappRequestsAreUnaffected() {
        assertNull(steps("Rahul ko hello bhejo"))
        assertEquals(listOf(Step.OpenApp("youtube"), Step.SearchInApp("lofi")), steps("open youtube and search lofi"))
    }
}
