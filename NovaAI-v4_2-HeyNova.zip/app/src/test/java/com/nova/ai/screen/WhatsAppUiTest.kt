package com.nova.ai.screen

import org.junit.Assert.*
import org.junit.Test

class WhatsAppUiTest {
    private fun named(id: Int, text: String, top: Int, v: String = "conversations_row_contact_name") =
        Cand(id, text = text, viewId = "com.whatsapp:id/$v", top = top, bottom = top + 80, right = 900)

    // ───────── redaction ─────────
    @Test fun verificationCodesAreHidden() {
        val r = SensitiveText.redact("Your WhatsApp code: 123-456. Don't share")
        assertFalse(r, r.contains("123"))
        assertTrue(r.contains("[hidden]"))
    }

    @Test fun otpAndPinAreHidden() {
        assertFalse(SensitiveText.redact("my otp is 482913").contains("482913"))
        assertFalse(SensitiveText.redact("pin 1234").contains("1234"))
    }

    @Test fun cardNumbersAreHidden() = assertFalse(SensitiveText.redact("card 4111 1111 1111 1111").contains("4111"))

    @Test fun ordinaryTextIsUntouched() {
        assertEquals("see you at 5 pm", SensitiveText.redact("see you at 5 pm"))
        assertEquals("meeting code of conduct", SensitiveText.redact("meeting code of conduct"))
    }

    @Test fun outgoingSensitiveMessagesAreFlagged() {
        assertTrue(SensitiveText.looksSensitive("my password is abc"))
        assertTrue(SensitiveText.looksSensitive("4111 1111 1111 1111"))
        assertFalse(SensitiveText.looksSensitive("hello how are you"))
    }

    // ───────── screens ─────────
    @Test fun onboardingScreensAreRecognised() {
        assertTrue(WhatsAppUi.isOnboarding(listOf("Verify your phone number", "Next")))
        assertTrue(WhatsAppUi.isOnboarding(listOf("Enter the 6-digit code")))
        assertFalse(WhatsAppUi.isOnboarding(listOf("Chats", "Rahul")))
    }

    @Test fun phoneNumbersAreRecognised() {
        assertTrue(WhatsAppUi.looksLikeNumber("+91 98765 43210"))
        assertTrue(WhatsAppUi.looksLikeNumber("9876543210"))
        assertFalse(WhatsAppUi.looksLikeNumber("Rahul"))
        assertFalse(WhatsAppUi.looksLikeNumber("12345"))
    }

    // ───────── search / contacts ─────────
    @Test fun searchFieldAndEntry() {
        assertEquals(1, WhatsAppUi.searchField(listOf(Cand(1, editable = true, viewId = "com.whatsapp:id/search_input")))?.id)
        assertEquals(2, WhatsAppUi.searchEntry(listOf(Cand(2, desc = "Search", clickable = true), Cand(3, desc = "Camera", clickable = true)))?.id)
        assertNull(WhatsAppUi.searchEntry(listOf(Cand(4, desc = "Search with voice", clickable = true))))
    }

    @Test fun twoDifferentPeopleAreAmbiguous() {
        val cs = listOf(named(1, "Rahul Sharma", 500), named(2, "Rahul Verma", 600), named(3, "Priya", 700))
        val rows = WhatsAppUi.contactRows(cs, "rahul")
        assertEquals(2, rows.size)
        assertEquals(2, WhatsAppUi.closeMatches(rows).size)
    }

    @Test fun anExactNameIsNeverAmbiguous() {
        val cs = listOf(named(1, "Rahul Sharma", 500), named(2, "Rahul Verma", 600))
        val close = WhatsAppUi.closeMatches(WhatsAppUi.contactRows(cs, "Rahul Sharma"))
        assertEquals(1, close.size)
        assertEquals("Rahul Sharma", close[0].name)
    }

    @Test fun exactBeatsLongerNames() {
        val cs = listOf(named(1, "Rahul Sharma", 500), named(2, "Rahul", 600))
        val close = WhatsAppUi.closeMatches(WhatsAppUi.contactRows(cs, "rahul"))
        assertEquals(listOf("Rahul"), close.map { it.name })
    }

    @Test fun unrelatedContactsAreNotMatched() = assertTrue(WhatsAppUi.contactRows(listOf(named(1, "Priya", 500)), "rahul").isEmpty())

    @Test fun theOpenChatTitleIsNotASearchResultRow() {
        val cs = listOf(named(1, "Rahul Sharma", 100, "conversation_contact_name"))
        assertTrue(WhatsAppUi.contactRows(cs, "rahul").isEmpty())
        assertEquals("Rahul Sharma", WhatsAppUi.openChatTitle(cs))
    }

    @Test fun sameContactRules() {
        assertTrue(WhatsAppUi.sameContact("Rahul Sharma", "rahul"))
        assertTrue(WhatsAppUi.sameContact("Rahul Sharma", "Rahul Sharma"))
        assertFalse(WhatsAppUi.sameContact("Rahul Sharma", "Rahul Verma"))
        assertFalse(WhatsAppUi.sameContact("Priya", "Rahul"))
        assertFalse(WhatsAppUi.sameContact("", "Rahul"))
    }

    // ───────── composer ─────────
    @Test fun messageFieldAndSendButton() {
        assertEquals(1, WhatsAppUi.messageField(listOf(Cand(1, editable = true, viewId = "com.whatsapp:id/entry")))?.id)
        assertEquals(2, WhatsAppUi.messageField(listOf(Cand(2, editable = true, hint = "Type a message")))?.id)
        assertEquals(3, WhatsAppUi.sendButton(listOf(Cand(3, desc = "Send", clickable = true)))?.id)
        assertNull(WhatsAppUi.sendButton(listOf(Cand(4, desc = "Voice message", clickable = true))))
        assertNull(WhatsAppUi.sendButton(listOf(Cand(5, desc = "Send", clickable = false))))
    }

    @Test fun messageTextsAreTopToBottom() {
        val cs = listOf(named(1, "second", 700, "message_text"), named(2, "first", 300, "message_text"), named(3, "not a message", 500))
        assertEquals(listOf("first", "second"), WhatsAppUi.messageTexts(cs))
    }

    @Test fun sentOnlyWhenBoxIsEmptyAndANewBubbleAppeared() {
        assertEquals(SendOutcome.CONFIRMED, WhatsAppUi.sendOutcome(fieldEmpty = true, bubbleSeen = true))
        assertEquals(SendOutcome.UNCONFIRMED, WhatsAppUi.sendOutcome(fieldEmpty = true, bubbleSeen = false))
        assertEquals(SendOutcome.NOT_SENT, WhatsAppUi.sendOutcome(fieldEmpty = false, bubbleSeen = true))
        assertEquals(SendOutcome.NOT_SENT, WhatsAppUi.sendOutcome(fieldEmpty = false, bubbleSeen = false))
    }

    // ───────── chat list ─────────
    @Test fun chatListEntriesPairNamesWithPreviewAndUnreadCount() {
        val cs = listOf(
            named(1, "Rahul", 500), named(2, "hello", 560, "single_msg_tv"), named(3, "2", 520, "conversations_row_message_count"),
            named(4, "Priya", 800), named(5, "see you", 860, "single_msg_tv")
        )
        val e = WhatsAppUi.chatListEntries(cs)
        assertEquals(listOf(ChatEntry("Rahul", "hello", "2"), ChatEntry("Priya", "see you", "")), e)
    }
}
