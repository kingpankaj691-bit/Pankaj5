package com.nova.ai.control

import org.junit.Assert.assertEquals
import org.junit.Test

class TaskLogTest {
    private fun rec(id: Long, st: TaskStatus) = TaskRecord(id, id, "t$id", "m", st, "msg")
    @Test fun capsAndOrdersNewestFirst() {
        val l = TaskLog(3); (1L..5L).forEach { l.add(rec(it, TaskStatus.VERIFIED)) }
        assertEquals(listOf(5L, 4L, 3L), l.all().map { it.id })
    }
    @Test fun updateReplacesRunningRecord() {
        val l = TaskLog(); l.add(rec(1, TaskStatus.RUNNING)); assertEquals(1, l.running().size)
        l.update(rec(1, TaskStatus.FAILED)); assertEquals(0, l.running().size); assertEquals(1, l.failed().size); assertEquals(1, l.all().size)
    }
    @Test fun unverifiedIsNotCountedAsFailureOrSuccess() {
        val l = TaskLog(); l.add(rec(1, TaskStatus.UNVERIFIED)); assertEquals(0, l.failed().size)
    }
}
