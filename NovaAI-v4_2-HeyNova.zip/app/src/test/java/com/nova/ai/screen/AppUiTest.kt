package com.nova.ai.screen

import org.junit.Assert.*
import org.junit.Test

class AppUiTest {
    private val yt = "com.google.android.youtube"
    private val chrome = "com.android.chrome"
    private val W = 1080
    private val H = 2400

    private fun row(id: Int, label: String, top: Int, clickable: Boolean = true, w: Int = 1080) =
        Cand(id, desc = label, clickable = clickable, left = 0, right = w, top = top, bottom = top + 300)

    // ───────── search field / entry ─────────
    @Test fun youtubeSearchFieldIsFoundById() {
        val f = Cand(1, viewId = "com.google.android.youtube:id/search_edit_text", editable = true, focused = true, hint = "Search YouTube")
        assertEquals(1, AppUi.searchField(listOf(Cand(9, text = "Home"), f), yt)?.id)
    }

    @Test fun noEditableMeansNoFieldYet() = assertNull(AppUi.searchField(listOf(Cand(1, desc = "Search", clickable = true)), yt))

    @Test fun youtubeSearchIconIsTheEntryAndVoiceSearchIsNot() {
        val cs = listOf(Cand(2, desc = "Search with your voice", clickable = true), Cand(3, desc = "Search", clickable = true), Cand(4, desc = "Cast", clickable = true))
        assertEquals(3, AppUi.searchEntry(cs, yt)?.id)
    }

    @Test fun browserAddressBarIsFound() {
        val f = Cand(5, viewId = "com.android.chrome:id/url_bar", editable = true, text = "")
        assertEquals(5, AppUi.searchField(listOf(f), chrome)?.id)
    }

    @Test fun browserStartPageFakeSearchBoxIsAnEntry() {
        val b = Cand(6, hint = "Search or type web address", clickable = true)
        assertEquals(6, AppUi.searchEntry(listOf(b, Cand(7, desc = "Search with Google Lens", clickable = true)), chrome)?.id)
    }

    @Test fun unknownAppFallsBackToFirstEditableButHasNoEntry() {
        val f = Cand(1, editable = true)
        assertEquals(1, AppUi.searchField(listOf(f), "com.whatsapp")?.id)
        assertNull(AppUi.searchEntry(listOf(Cand(2, desc = "Search", clickable = true)), "com.whatsapp"))
    }

    @Test fun disabledFieldIsIgnored() = assertNull(AppUi.searchField(listOf(Cand(1, editable = true, enabled = false)), yt))

    // ───────── YouTube results ─────────
    @Test fun resultsAreVideoRowsInReadingOrder() {
        val a = row(10, "Lofi hip hop radio - 2 hours, 3 minutes - Lofi Girl - 1.2M views", 900)
        val b = row(11, "Arijit Singh Best Songs - 10 minutes - T-Series - 5M views", 500)
        assertEquals(listOf(11, 10), AppUi.youtubeResults(listOf(a, b), W, H).map { it.id })
    }

    @Test fun suggestionsAdsShortsChipsAndToolbarAreNotResults() {
        val cs = listOf(
            row(1, "lofi songs 2024 playlist", 400),                                   // suggestion row (no duration / views)
            row(2, "Sponsored - Buy shoes - 1 minute - Shop - 3K views", 600),         // ad
            row(3, "Funny cats - 30 seconds - play Short", 800),                       // short
            row(4, "Lofi mix - 1 hour - Chill - 100 views", 100),                      // above the results area
            row(5, "Lofi mix - 1 hour - Chill - 100 views", 700, w = 300),              // a narrow chip
            Cand(6, desc = "Lofi mix - 1 hour - Chill - 100 views", clickable = false, right = 1080, top = 900, bottom = 1200) // not clickable
        )
        assertTrue(AppUi.youtubeResults(cs, W, H).isEmpty())
    }

    @Test fun bestResultMatchesTheQueryElseTheFirst() {
        val a = row(10, "Lofi hip hop radio - 2 hours - Lofi Girl - 1M views", 500)
        val b = row(11, "Arijit Singh Best Songs - 10 minutes - T-Series - 5M views", 900)
        assertEquals(11, AppUi.bestForQuery(listOf(a, b), "arijit singh songs")?.id)
        assertEquals(10, AppUi.bestForQuery(listOf(a, b), "zzzz")?.id)
        assertNull(AppUi.bestForQuery(emptyList(), "x"))
    }

    // ───────── video page / playback ─────────
    @Test fun watchPageIsRecognisedByPlayerId() =
        assertTrue(AppUi.onYoutubeVideoPage(listOf(Cand(1, viewId = "com.google.android.youtube:id/watch_player")), yt))

    @Test fun watchPageIsRecognisedByTwoControls() =
        assertTrue(AppUi.onYoutubeVideoPage(listOf(Cand(1, desc = "Pause video"), Cand(2, desc = "Enter fullscreen")), yt))

    @Test fun resultsPageMiniPlayerAndOtherAppsAreNotWatchPages() {
        assertFalse(AppUi.onYoutubeVideoPage(listOf(row(1, "Lofi - 1 hour - X - 1 views", 500)), yt))
        assertFalse(AppUi.onYoutubeVideoPage(listOf(Cand(1, viewId = "com.google.android.youtube:id/miniplayer_container")), yt))
        assertFalse(AppUi.onYoutubeVideoPage(listOf(Cand(1, viewId = "x:id/watch_player")), "com.whatsapp"))
    }

    @Test fun playbackUiReadsTheControls() {
        assertEquals(UiPlayback.PLAYING, AppUi.playbackUi(listOf(Cand(1, desc = "Pause video"))))
        assertEquals(UiPlayback.PAUSED, AppUi.playbackUi(listOf(Cand(1, desc = "Play video"))))
        assertEquals(UiPlayback.PAUSED, AppUi.playbackUi(listOf(Cand(1, desc = "Replay"))))
        assertEquals(UiPlayback.UNKNOWN, AppUi.playbackUi(listOf(Cand(1, desc = "Like"))))
        assertEquals(UiPlayback.PLAYING, AppUi.playbackUi(listOf(Cand(1, desc = "Play video"), Cand(2, desc = "Pause video"))))
    }

    @Test fun playControlIsTheClickablePlayButton() {
        assertEquals(2, AppUi.playControl(listOf(Cand(1, desc = "Like", clickable = true), Cand(2, desc = "Play video", clickable = true)))?.id)
        assertNull(AppUi.playControl(listOf(Cand(1, desc = "Play video", clickable = false))))
    }

    @Test fun playbackVerdictNeverTrustsAudioThatWasAlreadyPlaying() {
        assertEquals(PlaybackOutcome.CONFIRMED, PlaybackVerdict.decide(true, false, UiPlayback.UNKNOWN))
        assertEquals(PlaybackOutcome.UNCONFIRMED, PlaybackVerdict.decide(true, true, UiPlayback.UNKNOWN))
        assertEquals(PlaybackOutcome.UNCONFIRMED, PlaybackVerdict.decide(false, false, UiPlayback.UNKNOWN))
        assertEquals(PlaybackOutcome.CONFIRMED, PlaybackVerdict.decide(false, false, UiPlayback.PLAYING))
        assertEquals(PlaybackOutcome.PAUSED, PlaybackVerdict.decide(true, false, UiPlayback.PAUSED))
    }

    // ───────── browser ─────────
    @Test fun browserResultsAreLongLinksBelowTheToolbar() {
        val cs = listOf(
            Cand(1, text = "Kotlin coroutines guide | Kotlin Documentation", clickable = true, top = 900, bottom = 1100, right = 1000),
            Cand(2, text = "Images", clickable = true, top = 500, bottom = 600),
            Cand(3, text = "A very long address bar text here", editable = true, clickable = true, top = 200, bottom = 300),
            Cand(4, text = "Top banner text that is long enough", clickable = true, top = 100, bottom = 200),
            Cand(5, text = "Sponsored", clickable = true, top = 700, bottom = 800)
        )
        assertEquals(listOf(1), AppUi.browserResults(cs, H).map { it.id })
    }

    @Test fun urlTextReadsTheAddressBar() =
        assertEquals("kotlinlang.org", AppUi.urlText(listOf(Cand(1, viewId = "com.android.chrome:id/url_bar", text = "kotlinlang.org"))))

    @Test fun urlTextIsEmptyWhenUnreadable() = assertEquals("", AppUi.urlText(listOf(Cand(1, text = "kotlinlang.org"))))

    // ───────── page problems ─────────
    @Test fun pageProblems() {
        assertEquals(PageProblem.OFFLINE, AppUi.pageProblem(listOf("No internet connection", "Retry")))
        assertEquals(PageProblem.OFFLINE, AppUi.pageProblem(listOf("You're offline")))
        assertEquals(PageProblem.SITE_UNREACHABLE, AppUi.pageProblem(listOf("This site can't be reached")))
        assertEquals(PageProblem.LOAD_FAILED, AppUi.pageProblem(listOf("Something went wrong. Tap to retry")))
        assertEquals(PageProblem.CONSENT, AppUi.pageProblem(listOf("Before you continue to Google")))
        assertNull(AppUi.pageProblem(listOf("Kotlin coroutines guide", "Images")))
    }

    // ───────── failure messages ─────────
    @Test fun everyFailureHasAMessageInBothLanguages() {
        for (k in FailureKind.values()) {
            val en = Failures.message(k, "detail", false)
            val hi = Failures.message(k, "detail", true)
            assertTrue(k.name, en.isNotBlank() && hi.isNotBlank())
            assertNotEquals(k.name, en, hi)
        }
    }

    @Test fun failureMessagesNameTheCause() {
        assertTrue(Failures.message(FailureKind.NO_INTERNET).contains("internet", true))
        assertTrue(Failures.message(FailureKind.APP_NOT_INSTALLED, "YouTube").contains("YouTube"))
        assertTrue(Failures.message(FailureKind.APP_NOT_IN_FRONT, "YouTube").contains("Display over other apps"))
        assertTrue(Failures.message(FailureKind.PLAYBACK_UNCONFIRMED).contains("can't confirm"))
    }
}
