package com.nova.ai.live

import com.nova.ai.ai.Personality
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LiveCoreTest {

    @Test fun dedupSkipsRepeatsAndIsBounded() {
        val d = ToolCallDeduplicator(3)
        assertTrue(d.firstTime("a")); assertFalse(d.firstTime("a"))
        d.firstTime("b"); d.firstTime("c"); d.firstTime("d")      // "a" falls out
        assertTrue(d.firstTime("a"))
        assertTrue(d.firstTime("")); assertTrue(d.firstTime(""))
    }

    @Test fun memoryKeepsLast12AndCapsRecap() {
        val m = ConversationMemory()
        assertNull(m.recap())
        repeat(20) { m.add(ConversationMemory.Role.USER, "msg$it") }
        assertEquals(12, m.size())
        assertTrue(m.recap()!!.startsWith("User: msg8"))
        val big = ConversationMemory()
        repeat(12) { big.add(ConversationMemory.Role.ASSISTANT, "x".repeat(500)) }
        assertEquals(1600, big.recap()!!.length)
        big.clear(); assertNull(big.recap())
    }

    @Test fun promptRecapOnlyWhenResuming() {
        for (p in Personality.values()) for (l in listOf("auto", "english", "hindi", "hinglish", "manual")) {
            val a = PersonalityPromptBuilder.build(p, "custom", l, "Tamil", null, null, "Nova")
            val b = PersonalityPromptBuilder.build(p, "custom", l, "Tamil", "Hinglish", "User: hi", "Nova")
            assertFalse(a.contains("continuing conversation"))
            assertTrue(b.contains("do not greet again"))
            assertTrue(a.contains("You are Nova"))
        }
    }

    @Test fun echoGuardCountsAndTail() {
        val ts = TestScope()
        val g = EchoGuardCore(ts, tailMs = 450, watchdogMs = 60_000)
        g.notifyPlaybackStarted(); g.notifyPlaybackStarted()
        assertTrue(g.isMicMuted())
        g.notifyPlaybackStopped()
        ts.advanceTimeBy(1000); ts.runCurrent()
        assertTrue(g.isMicMuted())                      // one playback still active
        g.notifyPlaybackStopped()
        ts.advanceTimeBy(400); ts.runCurrent()
        assertTrue(g.isMicMuted())                      // inside the 450 ms tail
        ts.advanceTimeBy(100); ts.runCurrent()
        assertFalse(g.isMicMuted())
    }

    @Test fun echoGuardWatchdogUnmutes() {
        val ts = TestScope()
        val g = EchoGuardCore(ts)
        g.notifyPlaybackStarted()
        ts.advanceTimeBy(60_001); ts.runCurrent()
        assertFalse(g.isMicMuted()); assertEquals(0, g.activePlaybacks())
    }

    @Test fun latencyTrackerOrdering() {
        val t = VoiceLatencyTracker { 0L }
        t.mark(VoiceLatencyTracker.Mark.USER_SPEECH_END, 100)
        t.mark(VoiceLatencyTracker.Mark.FIRST_MODEL_AUDIO, 450)
        t.mark(VoiceLatencyTracker.Mark.TURN_COMPLETE, 2450)
        assertEquals(350L, t.firstAudioLatencyMs()); assertEquals(2000L, t.turnDurationMs())
        t.startTurn()
        t.mark(VoiceLatencyTracker.Mark.TURN_COMPLETE, 900)
        t.mark(VoiceLatencyTracker.Mark.FIRST_MODEL_AUDIO, 500)   // out of order: ignored
        assertNull(t.turnDurationMs())
    }

    @Test fun appMatchingAndContactRanking() {
        val labels = mapOf("youtube" to "p.yt", "youtube music" to "p.ytm", "whatsapp" to "p.wa", "ma" to "p.ma")
        assertEquals("p.yt", LiveTools.findApp(labels, "YouTube"))
        assertEquals("p.ytm", LiveTools.findApp(labels, "youtube mus"))
        assertNull(LiveTools.findApp(labels, "tsap"))             // no loose substring matching
        assertTrue(LiveTools.looksLikeNumber("+91 98765-43210")); assertFalse(LiveTools.looksLikeNumber("Mummy"))
        val rows = listOf("Rahul Sharma" to "1", "Rahul" to "2", "Sa Rahul" to "3")
        assertEquals("2", LiveTools.rankContacts("rahul", rows)!!.second)
        assertNull(LiveTools.rankContacts("zzz", rows))
    }

    private class Rec : GeminiLiveClient.Listener {
        val ev = ArrayList<String>()
        override fun onSetupComplete() { ev.add("setup") }
        override fun onAudioChunk(pcm24k: ByteArray) { ev.add("audio${pcm24k.size}") }
        override fun onInputTranscript(text: String) { ev.add("in:$text") }
        override fun onOutputTranscript(text: String) { ev.add("out:$text") }
        override fun onToolCall(id: String, name: String, args: JSONObject) { ev.add("tool:$id:$name") }
        override fun onTurnComplete() { ev.add("done") }
        override fun onInterrupted() { ev.add("int") }
        override fun onError(message: String) { ev.add("err") }
        override fun onClosed() { ev.add("closed") }
    }

    @Test fun parserHandlesServerMessages() {
        val r = Rec(); val d = ToolCallDeduplicator()
        assertTrue(LiveMessageParser.parse("""{"setupComplete":{}}""", r, d))
        val audio = java.util.Base64.getEncoder().encodeToString(ByteArray(8))
        LiveMessageParser.parse("""{"serverContent":{"modelTurn":{"parts":[{"inlineData":{"mimeType":"audio/pcm;rate=24000","data":"$audio"}}]},"outputTranscription":{"text":"hello"},"turnComplete":true}}""", r, d)
        val call = """{"toolCall":{"functionCalls":[{"id":"c1","name":"open_app","args":{"app_name":"YouTube"}}]}}"""
        LiveMessageParser.parse(call, r, d); LiveMessageParser.parse(call, r, d)
        LiveMessageParser.parse("""{"serverContent":{"interrupted":true,"inputTranscription":{"text":"hi"}}}""", r, d)
        LiveMessageParser.parse("""{"sessionResumptionUpdate":{}}""", r, d); LiveMessageParser.parse("not json", r, d)
        assertEquals(listOf("setup", "audio8", "out:hello", "done", "tool:c1:open_app", "in:hi", "int"), r.ev)
    }

    @Test fun setupMessageShape() {
        val s = setupMessage(GeminiLiveClient.MODEL, "sys", "Aoede", LiveTools.declarations()).getJSONObject("setup")
        assertEquals("AUDIO", s.getJSONObject("generationConfig").getJSONArray("responseModalities").getString(0))
        assertFalse(s.has("realtimeInputConfig"))
        assertTrue(s.getJSONArray("tools").getJSONObject(0).getJSONArray("functionDeclarations").length() >= 4)
    }

    @Test fun rmsOfPcm() {
        assertEquals(0f, LiveSpeaker.rms(ByteArray(8)), 0f)
        val loud = ByteArray(4) { if (it % 2 == 1) 0x7F else 0 }
        assertTrue(LiveSpeaker.rms(loud) > 0.9f)
    }
}
