package com.nova.ai.control

import org.junit.Assert.*
import org.junit.Test

class AppGuardTest {
    private val own = "com.nova.ai"
    private fun refused(v: AppVerdict) = (v as AppVerdict.Refused).reason

    // ───────── uninstall guard ─────────
    @Test fun novaNeverUninstallsItself() = assertTrue(refused(AppGuard.forUninstall(own, "Nova AI", own, false)).contains("myself"))

    @Test fun systemAppsAreRefused() = assertTrue(refused(AppGuard.forUninstall("com.android.chrome", "Chrome", own, isSystem = true)).contains("system app"))

    @Test fun toolsNovaDependsOnAndSecurityAppsAreRefused() {
        assertTrue(AppGuard.forUninstall("moe.shizuku.privileged.api", "Shizuku", own, false) is AppVerdict.Refused)
        assertTrue(AppGuard.forUninstall("com.termux", "Termux", own, false) is AppVerdict.Refused)
        assertTrue(AppGuard.forUninstall("com.google.android.gms", "Play services", own, false) is AppVerdict.Refused)
    }

    @Test fun bankingAndPasswordAppsAreRefused() {
        assertTrue(refused(AppGuard.forUninstall("com.sbi.bankapp", "SBI", own, false)).contains("banking"))
        assertTrue(AppGuard.forUninstall("com.bitwarden.mobile", "Bitwarden", own, false) is AppVerdict.Refused)
    }

    @Test fun anOrdinaryAppMayBeUninstalledThroughAndroidsScreen() =
        assertEquals(AppVerdict.Allowed, AppGuard.forUninstall("com.king.candycrushsaga", "Candy Crush", own, false))

    // ───────── install guard ─────────
    @Test fun novaDoesNotReplaceItself() = assertTrue(AppGuard.forInstall(own, "Nova AI", own) is AppVerdict.Refused)
    @Test fun protectedPackagesAreNotInstalled() = assertTrue(AppGuard.forInstall("com.android.systemui", "SystemUI", own) is AppVerdict.Refused)
    @Test fun ordinaryAppsMayBeInstalled() {
        assertEquals(AppVerdict.Allowed, AppGuard.forInstall("com.king.candycrushsaga", "Candy Crush", own))
        assertEquals(AppVerdict.Allowed, AppGuard.forInstall("com.sbi.bankapp", "SBI", own))
    }

    // ───────── picking the app ─────────
    private val apps = listOf(
        "WhatsApp" to "com.whatsapp", "WhatsApp Business" to "com.whatsapp.w4b", "Candy Crush" to "com.king.candy",
        "Candy Crush Soda" to "com.king.soda", "Chrome" to "com.android.chrome"
    )

    @Test fun anExactNameWinsOverLongerNames() {
        assertEquals(AppPick.Pick.Found("WhatsApp", "com.whatsapp"), AppPick.pick(apps, "whatsapp"))
        assertEquals(AppPick.Pick.Found("Candy Crush", "com.king.candy"), AppPick.pick(apps, "Candy Crush"))
    }

    @Test fun aPartialNameThatFitsSeveralAppsIsAmbiguous() {
        val p = AppPick.pick(apps, "candy") as AppPick.Pick.Ambiguous
        assertEquals(listOf("Candy Crush", "Candy Crush Soda"), p.names)
    }

    @Test fun aUniquePartialNameIsFound() = assertEquals(AppPick.Pick.Found("Chrome", "com.android.chrome"), AppPick.pick(apps, "chro"))

    @Test fun aPackageNameWorks() = assertEquals(AppPick.Pick.Found("Chrome", "com.android.chrome"), AppPick.pick(apps, "com.android.chrome"))

    @Test fun unknownOrBlankIsNotFound() {
        assertEquals(AppPick.Pick.NotFound, AppPick.pick(apps, "xyz"))
        assertEquals(AppPick.Pick.NotFound, AppPick.pick(apps, ""))
    }

    @Test fun aKnownAppThatIsNotInstalledIsNotGuessed() =
        assertEquals(AppPick.Pick.NotFound, AppPick.pick(listOf("YouTube Music" to "com.google.android.apps.youtube.music"), "youtube"))

    @Test fun twoAppsWithTheSameNameAreAmbiguous() {
        val p = AppPick.pick(listOf("Notes" to "a.notes", "Notes" to "b.notes"), "notes") as AppPick.Pick.Ambiguous
        assertEquals(2, p.names.size)
    }

    // ───────── picking the APK ─────────
    @Test fun apkMatching() {
        val names = listOf("app-release.apk", "Whatsapp.apk", "readme.txt")
        assertEquals(listOf("Whatsapp.apk"), ApkPick.match(names, "whats"))
        assertEquals(listOf("app-release.apk", "Whatsapp.apk"), ApkPick.match(names, ""))
        assertTrue(ApkPick.match(names, "zzz").isEmpty())
    }
}
