package com.nova.ai.control

import com.nova.ai.media.MediaAccess
import com.nova.ai.media.MediaAccessLevel
import com.nova.ai.media.MediaActions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaAccessTest {
    @Test fun android14PartialAccessIsReportedAsSelectedOnly() =
        assertEquals(MediaAccessLevel.SELECTED_ONLY, MediaAccess.levelFor(34, images = false, videos = false, selected = true, legacy = false))
    @Test fun fullAndNoneOnAndroid13() {
        assertEquals(MediaAccessLevel.FULL, MediaAccess.levelFor(33, true, true, false, false))
        assertEquals(MediaAccessLevel.NONE, MediaAccess.levelFor(33, false, false, false, false))
        assertEquals(MediaAccessLevel.IMAGES_ONLY, MediaAccess.levelFor(33, true, false, false, false))
    }
    @Test fun selectedFlagIgnoredBelowAndroid14() =
        assertEquals(MediaAccessLevel.NONE, MediaAccess.levelFor(33, false, false, true, false))
    @Test fun legacyStoragePermissionOnAndroid12AndBelow() {
        assertEquals(MediaAccessLevel.FULL, MediaAccess.levelFor(31, false, false, false, true))
        assertEquals(MediaAccessLevel.NONE, MediaAccess.levelFor(31, true, true, false, false))
    }
    @Test fun requestListsPerVersion() {
        assertEquals(3, MediaAccess.permissionsToRequest(34).size)
        assertEquals(2, MediaAccess.permissionsToRequest(33).size)
        assertEquals(1, MediaAccess.permissionsToRequest(30).size)
    }
    @Test fun albumNames() {
        assertTrue(MediaActions.validAlbumName("Nova Trip 2025"))
        assertFalse(MediaActions.validAlbumName("../DCIM"))
        assertFalse(MediaActions.validAlbumName("a/b"))
        assertFalse(MediaActions.validAlbumName(""))
    }
}
