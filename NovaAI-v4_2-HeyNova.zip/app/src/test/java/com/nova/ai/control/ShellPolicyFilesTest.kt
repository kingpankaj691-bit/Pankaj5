package com.nova.ai.control

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ShellPolicyFilesTest {
    private fun allowed(c: String) = ShellPolicy.validate(c) is ShellPolicy.Decision.Allow
    private fun risk(c: String) = (ShellPolicy.validate(c) as ShellPolicy.Decision.Allow).risk

    @Test fun listingIsReadOnlyAndSharedStorageOnly() {
        assertTrue(allowed("ls -1p /storage/emulated/0/Android/data"))
        assertEquals(ShellPolicy.Risk.READ, risk("ls -1p /sdcard/Download"))
        assertTrue(!allowed("ls -1p /data/data"))
        assertTrue(!allowed("ls -1p /storage/emulated/0/Download/../../../data"))
        assertTrue(!allowed("ls -1p /storage/emulated/0/My Folder"))
        assertTrue(!allowed("ls -la /sdcard"))
        assertTrue(!allowed("ls -1p /sdcard/*"))
    }

    @Test fun copyMoveNeedConfirmationAndStayOutOfAndroidDir() {
        assertEquals(ShellPolicy.Risk.CONFIRM, risk("cp /storage/emulated/0/Download/a.txt /storage/emulated/0/Documents"))
        assertTrue(allowed("cp /sdcard/a/b.txt /sdcard/Documents"))
        assertTrue(allowed("cp /storage/emulated/0/Android/data/x/f.db /storage/emulated/0/Download"))      // copying OUT is fine
        assertTrue(!allowed("cp /storage/emulated/0/Download/a.txt /storage/emulated/0/Android/data/x"))   // writing IN is not
        assertTrue(allowed("mv /storage/emulated/0/Download/a.txt /storage/emulated/0/Documents"))
        assertTrue(!allowed("mv /storage/emulated/0/Download /storage/emulated/0/Documents"))             // whole top-level folder
        assertTrue(!allowed("mv /storage/emulated/0/Android/data/x/a /storage/emulated/0/Documents"))
    }

    @Test fun deleteIsSingleFileOnly() {
        assertEquals(ShellPolicy.Risk.CONFIRM, risk("rm /storage/emulated/0/Download/a.txt"))
        assertTrue(!allowed("rm /storage/emulated/0/Download"))
        assertTrue(!allowed("rm -rf /storage/emulated/0/Download/a"))
        assertTrue(!allowed("rm -r /sdcard/Download/a"))
        assertTrue(!allowed("rm /data/data/com.x/files/a"))
        assertTrue(!allowed("rm /storage/emulated/0/Android/data/x/a"))
        assertTrue(!allowed("rm /sdcard/Download/a.txt; reboot"))
    }

    @Test fun mkdirRules() {
        assertTrue(allowed("mkdir /storage/emulated/0/Download/New"))
        assertTrue(!allowed("mkdir /storage/emulated/0/Android/data/New"))
        assertTrue(!allowed("mkdir /system/new"))
    }
}
