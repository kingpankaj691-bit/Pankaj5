package com.nova.ai.files

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DocReaderTest {
    private lateinit var dir: File
    @Before fun up() { dir = Files.createTempDirectory("novadoc").toFile() }
    @After fun down() { dir.deleteRecursively() }

    private fun zip(name: String, entries: Map<String, String>): File {
        val f = File(dir, name)
        ZipOutputStream(f.outputStream()).use { z -> entries.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return f
    }

    @Test fun docx() {
        val xml = "<w:document><w:body><w:p><w:r><w:t>Hello</w:t></w:r><w:r><w:t xml:space=\"preserve\"> World &amp; co</w:t></w:r></w:p>" +
            "<w:p><w:r><w:t>Second</w:t></w:r><w:tab/><w:r><w:t>line</w:t></w:r></w:p></w:body></w:document>"
        val r = DocReader.read(zip("a.docx", mapOf("word/document.xml" to xml)))
        assertTrue(r.note, r.ok); assertEquals("Hello World & co\nSecond\tline", r.text)
    }

    @Test fun xlsxKeepsColumnsAndSharedStrings() {
        val shared = "<sst><si><t>Name</t></si><si><t>Age</t></si><si><t>Asha</t></si></sst>"
        val sheet = "<worksheet><sheetData><row r=\"1\"><c r=\"A1\" t=\"s\"><v>0</v></c><c r=\"B1\" t=\"s\"><v>1</v></c></row>" +
            "<row r=\"2\"><c r=\"A2\" t=\"s\"><v>2</v></c><c r=\"B2\"><v>31</v></c></row><row r=\"3\"><c r=\"B3\"><v>7</v></c></row></sheetData></worksheet>"
        val r = DocReader.read(zip("s.xlsx", mapOf("xl/sharedStrings.xml" to shared, "xl/worksheets/sheet1.xml" to sheet)))
        assertTrue(r.note, r.ok)
        assertEquals(listOf("Name | Age", "Asha | 31", "| 7"), r.text.lines().map { it.trim() })
    }

    @Test fun pptxSlidesInNumericOrder() {
        fun slide(t: String) = "<p:sld><a:p><a:r><a:t>$t</a:t></a:r></a:p></p:sld>"
        val r = DocReader.read(zip("p.pptx", mapOf("ppt/slides/slide10.xml" to slide("Ten"), "ppt/slides/slide2.xml" to slide("Two &lt;2&gt;"), "ppt/slides/slide1.xml" to slide("One"))))
        assertTrue(r.ok)
        assertTrue(r.text.indexOf("One") < r.text.indexOf("Two <2>") && r.text.indexOf("Two <2>") < r.text.indexOf("Ten"))
    }

    @Test fun odt() {
        val r = DocReader.read(zip("o.odt", mapOf("content.xml" to "<office:text><text:h>Title</text:h><text:p>Body &amp; more</text:p></office:text>")))
        assertTrue(r.ok); assertEquals("Title\nBody & more", r.text)
    }

    @Test fun htmlIsStripped() {
        val f = File(dir, "p.html"); f.writeText("<html><head><title>x</title><style>p{color:red}</style></head><body><h1>Hello</h1><p>A &amp; B</p><script>evil()</script></body></html>")
        val r = DocReader.read(f)
        assertTrue(r.ok); assertTrue(r.text.contains("Hello")); assertTrue(r.text.contains("A & B"))
        assertFalse(r.text.contains("evil")); assertFalse(r.text.contains("color"))
    }

    @Test fun csvAndCodeArePlainText() {
        val c = File(dir, "d.csv"); c.writeText("a,b\n1,2\n")
        assertEquals("a,b\n1,2", DocReader.read(c).text)
        val k = File(dir, "Main.kt"); k.writeText("fun main() {}\n")
        assertTrue(DocReader.read(k).ok)
    }

    @Test fun binaryIsRefusedNotShownAsGarbage() {
        val f = File(dir, "x.txt"); f.writeBytes(ByteArray(2000) { (it % 8).toByte() })
        val r = DocReader.read(f); assertFalse(r.ok); assertTrue(r.note.contains("binary"))
    }

    @Test fun longTextIsTruncatedAndSaysSo() {
        val f = File(dir, "l.txt"); f.writeText("x".repeat(100))
        val r = DocReader.read(f, 10); assertTrue(r.ok); assertTrue(r.truncated); assertEquals(10, r.text.length)
    }

    @Test fun oldBinaryOfficeFormatsAreHonestlyUnsupported() {
        val f = File(dir, "old.doc"); f.writeBytes(byteArrayOf(1, 2, 3))
        val r = DocReader.read(f); assertFalse(r.ok); assertTrue(r.note.contains(".docx"))
        assertFalse(DocReader.read(File(dir, "missing.txt")).ok)
    }

    @Test fun zipListing() {
        val f = File(dir, "z.zip")
        ZipOutputStream(f.outputStream()).use { z -> z.putNextEntry(ZipEntry("a.txt")); z.write("hi".toByteArray()); z.closeEntry(); z.putNextEntry(ZipEntry("d/")); z.closeEntry(); z.putNextEntry(ZipEntry("d/b.txt")); z.write("yo".toByteArray()); z.closeEntry() }
        val r = DocReader.read(f)
        assertTrue(r.ok); assertTrue(r.text.contains("2 files, 1 folders")); assertTrue(r.text.contains("d/b.txt"))
    }

    @Test fun readableAndHelpers() {
        assertTrue(DocReader.readable("a.docx")); assertTrue(DocReader.readable("Main.kt")); assertTrue(DocReader.readable("n.json"))
        assertFalse(DocReader.readable("a.pdf")); assertFalse(DocReader.readable("a.mp3"))
        assertEquals(0, DocReader.colIndex("A")); assertEquals(25, DocReader.colIndex("Z")); assertEquals(26, DocReader.colIndex("AA"))
        assertEquals("AB", DocReader.unescape("&#65;&#x42;"))
    }
}
