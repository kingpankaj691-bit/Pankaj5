package com.nova.ai.voice

import org.junit.Assert.*
import org.junit.Test

/** The four orb states and when each one shows. Pure JVM tests. */
class OrbPhaseTest {
    private fun d(override: OrbPhase? = null, mic: Boolean = true, paused: Boolean = false, gated: Boolean = true, awake: Boolean = false,
                  speaking: Boolean = false, thinking: Boolean = false, working: Boolean = false) =
        OrbPhases.derive(override, mic, paused, gated, awake, speaking, thinking, working)

    @Test fun idleUntilTheWakePhraseIsHeard() {
        assertEquals(OrbPhase.IDLE, d())
        assertEquals(OrbPhase.LISTENING, d(awake = true))
    }

    @Test fun thinkingAndSpeakingFollowTheConversation() {
        assertEquals(OrbPhase.THINKING, d(awake = true, thinking = true))
        assertEquals(OrbPhase.SPEAKING, d(awake = true, speaking = true))
        assertEquals(OrbPhase.SPEAKING, d(awake = true, speaking = true, thinking = true))     // speaking wins
    }

    @Test fun conversationEndReturnsToIdle() {
        assertEquals(OrbPhase.IDLE, d(awake = false))
    }

    @Test fun pausedMicrophoneOrStoppedServiceIsIdle() {
        assertEquals(OrbPhase.IDLE, d(paused = true, awake = true))
        assertEquals(OrbPhase.IDLE, d(mic = false, awake = true))
    }

    @Test fun withoutTheGateTheOrbIsSmallUntilNovaSpeaksOrThinks() {
        assertEquals(OrbPhase.IDLE, d(gated = false))
        assertEquals(OrbPhase.SPEAKING, d(gated = false, speaking = true))
        assertEquals(OrbPhase.THINKING, d(gated = false, thinking = true))
    }

    @Test fun screenTasksShowThinkingAndTestsOverrideEverything() {
        assertEquals(OrbPhase.THINKING, d(working = true, paused = true))
        assertEquals(OrbPhase.SPEAKING, d(override = OrbPhase.SPEAKING, mic = false))
    }

    @Test fun labelsMatchTheSpec() {
        assertEquals("Listening…", OrbPhases.label(OrbPhase.LISTENING))
        assertEquals("Nova is thinking", OrbPhases.label(OrbPhase.THINKING))
        assertEquals("Nova is speaking", OrbPhases.label(OrbPhase.SPEAKING))
        assertEquals("", OrbPhases.label(OrbPhase.IDLE))
    }
}
