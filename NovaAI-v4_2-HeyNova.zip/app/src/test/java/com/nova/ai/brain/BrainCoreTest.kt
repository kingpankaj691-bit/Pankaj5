package com.nova.ai.brain

import java.security.GeneralSecurityException
import java.time.LocalDateTime
import java.time.ZoneId
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BrainCoreTest {
    private val utc = ZoneId.of("UTC")
    private val now = LocalDateTime.of(2026, 11, 4, 10, 0).atZone(utc).toInstant().toEpochMilli()

    private fun key(): SecretKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
    private fun item(cat: BrainCategory, text: String, project: String = "", status: String = "", due: Long = 0) =
        BrainItem(0, cat, Txt.clip(text, 60), text, project, 0, status, due, 0.6f, now, now, now, "test", false, Txt.hash(text), 1)

    // ───── 1, 2, 20: topic continuity, recovery and the topic lock ─────
    private fun androidConversation(topics: TopicEngine) {
        assertTrue(topics.onUserTurn("Nova, mujhe ek Android application banani hai.", 1000) is TopicDecision.Started)
        topics.onAssistantTurn("Kaisi application?", 2000)
        assertTrue(topics.onUserTurn("AI assistant.", 3000) is TopicDecision.Continued)
        topics.onAssistantTurn("Usmein kya features chahiye?", 4000)
        assertTrue(topics.onUserTurn("Voice aur memory.", 5000) is TopicDecision.Continued)
    }

    @Test fun topicContinuityKeepsTheWholeDiscussion() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val t = topics.active()!!
        assertTrue(t.title.contains("Android"))
        val recap = topics.recap(t, false)
        assertTrue(recap, recap.contains("Android application"))
        assertTrue(recap, recap.contains("AI assistant"))
        assertTrue(recap, recap.contains("Voice aur memory"))
    }

    @Test fun unansweredQuestionIsRemembered() {
        val topics = TopicEngine(InMemoryBrainStore())
        topics.onUserTurn("Nova, mujhe ek Android application banani hai.", 1000)
        topics.onAssistantTurn("Kaisi application?", 2000)
        assertTrue(topics.active()!!.unanswered.contains("A:Kaisi application?"))
        assertTrue(topics.recap(topics.active()!!, false).contains("Kaisi application?"))
    }

    @Test fun incompleteSentenceAndReferencesNeverChangeTopic() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val id = topics.activeId()
        assertTrue(topics.onUserTurn("aur usmein", 6000) is TopicDecision.Continued)
        assertTrue(topics.onUserTurn("ye wala bhi", 7000) is TopicDecision.Continued)
        assertTrue(topics.onUserTurn("usmein login screen bhi chahiye", 8000) is TopicDecision.Continued)
        assertEquals(id, topics.activeId())
    }

    @Test fun unrelatedQuestionSwitchesButOldTopicStaysAndCanBeResumed() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val first = topics.activeId()
        val d = topics.onUserTurn("Delhi mein aaj mausam kaisa hai?", 6000)
        assertTrue(d is TopicDecision.Switched)
        assertTrue(topics.activeId() != first)
        assertEquals("PAUSED", topics.history().first { it.id == first }.status)
        val found = topics.find("android application")
        assertEquals(first, found.first().id)
        topics.resume(first, 7000)
        assertEquals(first, topics.activeId())
    }

    @Test fun returningToAnOlderTopicIsRecognised() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val first = topics.activeId()
        topics.onUserTurn("Delhi mein aaj mausam kaisa hai?", 6000)
        val d = topics.onUserTurn("Android application mein voice feature kaise add karun?", 7000)
        assertTrue(d is TopicDecision.Resumed)
        assertEquals(first, topics.activeId())
    }

    @Test fun explicitTopicChangeSwitchesAndUncertainKeepsContext() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val first = topics.activeId()
        assertTrue(topics.onUserTurn("kal subah gym jaana hai dost ke saath", 6000) is TopicDecision.Uncertain)
        assertEquals(first, topics.activeId())
        assertTrue(topics.onUserTurn("naya topic cooking recipes ke baare mein", 7000) is TopicDecision.Switched)
        assertTrue(topics.activeId() != first)
    }

    @Test fun askingAboutTheConversationNeverChangesIt() {
        val topics = TopicEngine(InMemoryBrainStore())
        androidConversation(topics)
        val id = topics.activeId()
        assertEquals(TopicQuery.RECAP, TopicEngine.queryKind("Nova, hum kya bana rahe the?"))
        assertEquals(TopicQuery.RESUME, TopicEngine.queryKind("Nova, hum purani wali baat continue karte hain."))
        assertTrue(topics.onUserTurn("hum kya bana rahe the", 9000) is TopicDecision.Continued)
        assertEquals(id, topics.activeId())
    }

    // ───── 3, 4, 5, 6: language stability ─────
    private val hinglish = listOf("mujhe ek android app banana hai jisme voice aur memory ho", "usme login screen bhi chahiye aur dark theme bhi", "kal tak ye kaam khatam karna hai mujhe")
    private val english = listOf("Please open the settings for me now", "Can you tell me what this means", "I think that is the right answer", "Show me how it works in detail")

    @Test fun hinglishStaysHinglishEvenAfterEnglishSentencesAndOneForeignWord() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        hinglish.forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        assertEquals(LanguageStabilizer.HINGLISH, lang.state()!!.lang)
        lang.observe("bonjour", 2000)
        assertEquals(LanguageStabilizer.HINGLISH, lang.state()!!.lang)
        english.take(3).forEachIndexed { i, s -> lang.observe(s, 3000L + i) }
        assertEquals(LanguageStabilizer.HINGLISH, lang.state()!!.lang)
        lang.observe(hinglish[0], 4000)                       // a Hinglish turn resets the evidence
        english.take(3).forEachIndexed { i, s -> lang.observe(s, 5000L + i) }
        assertEquals(LanguageStabilizer.HINGLISH, lang.state()!!.lang)
    }

    @Test fun englishConversationStaysEnglish() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        english.forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        assertEquals(LanguageStabilizer.ENGLISH, lang.state()!!.lang)
        lang.observe("mujhe ek android app banana hai", 5000)
        assertEquals(LanguageStabilizer.ENGLISH, lang.state()!!.lang)
    }

    @Test fun hindiDevanagariConversationStaysHindi() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        listOf("मुझे आज एक नया प्रोजेक्ट शुरू करना है", "इसमें आवाज़ और मेमोरी चाहिए", "कल मैं इसका डिज़ाइन देखूँगा").forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        assertEquals(LanguageStabilizer.HINDI, lang.state()!!.lang)
    }

    @Test fun repeatedClearEnglishEventuallySwitchesFromHinglish() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        hinglish.forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        english.forEachIndexed { i, s -> lang.observe(s, 3000L + i) }
        assertEquals(LanguageStabilizer.ENGLISH, lang.state()!!.lang)
    }

    @Test fun explicitRequestSwitchesImmediatelyButAskingForEnglishTextDoesNot() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        hinglish.forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        lang.observe("mujhe English mein email likhna hai", 2000)
        assertEquals(LanguageStabilizer.HINGLISH, lang.state()!!.lang)
        lang.observe("ab English mein baat karo", 3000)
        assertEquals(LanguageStabilizer.ENGLISH, lang.state()!!.lang)
        assertTrue(lang.state()!!.explicit)
        assertEquals(LanguageStabilizer.HINDI, LanguageStabilizer.explicitChange("Hindi mein bolo"))
        assertEquals(LanguageStabilizer.HINGLISH, LanguageStabilizer.explicitChange("please speak hinglish"))
    }

    @Test fun languagePolicyForbidsSelfSwitchingAndSurvivesRestart() {
        val store = InMemoryBrainStore()
        LanguageStabilizer(store).also { l -> hinglish.forEachIndexed { i, s -> l.observe(s, 1000L + i) } }
        val after = LanguageStabilizer(store)                     // new instance = app restart / reconnect
        assertEquals(LanguageStabilizer.HINGLISH, after.state()!!.lang)
        val p = after.policy()
        assertTrue(p.contains("Hinglish") && p.contains("Do not switch language") && p.contains("NOT a request to switch"))
    }

    @Test fun fixedLanguageSettingWinsOverDetection() {
        val lang = LanguageStabilizer(InMemoryBrainStore())
        lang.observe(english[0], 1000, "hindi")
        assertEquals(LanguageStabilizer.HINDI, lang.state()!!.lang)
    }

    // ───── extraction (the examples from the specification) ─────
    @Test fun extractsPreferenceProjectAndTaskExamples() {
        val pref = MemoryExtractor.extract("Nova, mujhe dark liquid glass UI pasand hai.", now, utc).single()
        assertEquals(BrainCategory.PREFERENCE, pref.category); assertTrue(pref.title.contains("liquid"))
        val proj = MemoryExtractor.extract("Nova, main Nova AI project par kaam kar raha hoon.", now, utc).single()
        assertEquals(BrainCategory.PROJECT, proj.category); assertEquals("Nova AI", proj.title); assertEquals(Status.ONGOING, proj.status)
        val task = MemoryExtractor.extract("Nova, kal mujhe is project ka voice engine complete karna hai.", now, utc).single()
        assertEquals(BrainCategory.TASK, task.category)
        assertEquals(LocalDateTime.of(2026, 11, 5, 9, 0).atZone(utc).toInstant().toEpochMilli(), task.dueAt)
    }

    @Test fun postponedFeatureBecomesPendingTask() {
        val c = MemoryExtractor.extract("Nova, is feature ko baad mein implement karenge", now, utc).single()
        assertEquals(BrainCategory.TASK, c.category); assertEquals(Status.POSTPONED, c.status)
    }

    @Test fun secretsAreBlockedAndQuestionsAreNotSaved() {
        assertEquals(Sensitivity.BLOCK, MemoryExtractor.extract("mera password hunter2 hai", now, utc).single().sensitivity)
        assertEquals(Sensitivity.BLOCK, MemoryExtractor.extract("my otp is 123456", now, utc).single().sensitivity)
        assertEquals(Sensitivity.BLOCK, MemoryExtractor.extract("api key AIzaSyA1234567890abcdefghijklmn", now, utc).single().sensitivity)
        assertTrue(MemoryExtractor.extract("mera phone kaun sa hai?", now, utc).isEmpty())
        assertFalse(MemoryExtractor.redact("password hunter2").contains("password"))
    }

    @Test fun personalContactDetailsNeedAYes() {
        val c = MemoryExtractor.extract("mera phone number 9876543210 hai", now, utc).single()
        assertEquals(Sensitivity.ASK, c.sensitivity)
    }

    @Test fun rememberAndDontSaveDirectives() {
        assertEquals(Directive.REMEMBER, MemoryExtractor.directive("Nova, ise yaad rakhna"))
        assertEquals(Directive.DONT_SAVE, MemoryExtractor.directive("Nova, ye baat save mat karna"))
        assertEquals("main Delhi mein rehta hoon", MemoryExtractor.stripWrapper("Nova, ise yaad rakhna ki main Delhi mein rehta hoon"))
        assertEquals("", MemoryExtractor.stripWrapper("Nova, ise yaad rakhna"))
    }

    @Test fun dateResolverUsesLocalDateAndTime() {
        val tomorrow5 = DateResolver.resolve("kal shaam 5 baje meeting", now, utc)!!
        assertEquals(LocalDateTime.of(2026, 11, 5, 17, 0).atZone(utc).toInstant().toEpochMilli(), tomorrow5.at); assertTrue(tomorrow5.hasTime)
        assertEquals(now + 2 * 3_600_000L, DateResolver.resolve("2 ghante mein yaad dilana", now, utc)!!.at)
        assertEquals(LocalDateTime.of(2026, 11, 6, 9, 0).atZone(utc).toInstant().toEpochMilli(), DateResolver.resolve("parso", now, utc)!!.at)
        assertNull(DateResolver.resolve("mujhe dark UI pasand hai", now, utc))
        val y = DateResolver.pastRange("kal wali baat yaad dilao", now, utc)!!
        assertEquals(LocalDateTime.of(2026, 11, 3, 0, 0).atZone(utc).toInstant().toEpochMilli(), y.first)
    }

    // ───── 7, 8, 14, 16, 18: long-term memory, restart, duplicates, deletion, pending tasks ─────
    @Test fun memorySurvivesRestartAndDuplicatesAreNotStored() {
        val store = InMemoryBrainStore()
        val m1 = MemoryService(store) { now }
        val c = MemoryExtractor.extract("Nova, mujhe dark liquid glass UI pasand hai.", now, utc).single()
        assertTrue(m1.save(c, "chat") is SaveResult.Saved)
        val again = MemoryExtractor.extract("dark liquid glass UI mujhe pasand hai", now, utc).single()
        assertTrue(MemoryService(store) { now }.save(again, "chat") is SaveResult.Duplicate)   // new service = restart
        assertEquals(1, MemoryService(store) { now }.all().size)
    }

    @Test fun projectUpdateMergesInsteadOfDuplicating() {
        val m = MemoryService(InMemoryBrainStore()) { now }
        m.save(Candidate(BrainCategory.PROJECT, "Nova AI", "main Nova AI project par kaam kar raha hoon", status = Status.ONGOING), "chat")
        val r = m.save(Candidate(BrainCategory.PROJECT, "Nova AI", "Nova AI project ka voice engine bana rahe hain", status = Status.ONGOING), "chat")
        assertTrue(r is SaveResult.Updated || r is SaveResult.Duplicate)
        assertEquals(1, m.byCategory(BrainCategory.PROJECT).size)
    }

    @Test fun pendingTasksAreRetrievedAndOnlyDoneByTheUser() {
        val m = MemoryService(InMemoryBrainStore()) { now }
        val c = MemoryExtractor.extract("Nova, is feature ko baad mein implement karenge", now, utc).single()
        val saved = (m.save(c, "chat", 0, "Nova AI") as SaveResult.Saved).item
        assertEquals(listOf(saved.id), m.pendingTasks("Nova AI").map { it.id })
        assertTrue(m.pendingTasks("Other project").isEmpty())
        m.setStatus(saved.id, Status.DONE)
        assertTrue(m.pendingTasks().isEmpty())
    }

    @Test fun userRequestedDeletionRemovesEverything() {
        val store = InMemoryBrainStore(); val m = MemoryService(store) { now }
        val a = (m.save(Candidate(BrainCategory.PREFERENCE, "a", "dark UI pasand hai"), "chat") as SaveResult.Saved).item
        m.save(Candidate(BrainCategory.TASK, "b", "voice engine complete karna hai", status = Status.PENDING), "chat")
        m.save(Candidate(BrainCategory.TASK, "c", "memory dashboard test karna hai", status = Status.PENDING), "chat")
        assertTrue(m.delete(a.id)); assertNull(m.item(a.id))
        assertEquals(2, m.clearCategory(BrainCategory.TASK)); assertTrue(m.all().isEmpty())
        m.save(Candidate(BrainCategory.NOTE, "n", "ek note"), "chat"); store.wipeAll(); assertTrue(m.all().isEmpty())
    }

    @Test fun editingKeepsEarlierVersionsAndRefusesSecrets() {
        val store = InMemoryBrainStore(); val m = MemoryService(store) { now }
        val saved = (m.save(Candidate(BrainCategory.PERSONAL, "phone", "mera phone Pixel 7 hai"), "chat") as SaveResult.Saved).item
        assertNotNull(m.update(saved.id, "mera phone Pixel 9 hai"))
        assertEquals(2, store.item(saved.id)!!.version)
        assertEquals("mera phone Pixel 7 hai", store.versions(saved.id).first().second)
        assertNull(m.update(saved.id, "password hunter2"))
    }

    // ───── 11, 19: retrieval accuracy and context isolation ─────
    private fun library(): List<BrainItem> = listOf(
        item(BrainCategory.PERSONAL, "Mera phone Samsung Galaxy S23 hai, 8GB RAM"),
        item(BrainCategory.PROJECT, "Main Nova AI project par kaam kar raha hoon", "Nova AI"),
        item(BrainCategory.PROJECT, "Video editing project Reel Studio", "Reel Studio"),
        item(BrainCategory.PREFERENCE, "dark liquid glass UI pasand hai"),
        item(BrainCategory.TASK, "voice engine complete karna hai", "Nova AI", Status.PENDING)
    ).mapIndexed { i, x -> x.copy(id = i + 1L) }

    @Test fun retrievalFindsTheRightMemory() {
        val lib = library()
        assertEquals(1L, Retrieval.search(lib, RetrievalQuery("phone"), now).first().item.id)
        assertEquals("Reel Studio", Retrieval.search(lib, RetrievalQuery("mere editing project ka naam"), now).first().item.project)
        assertEquals(4L, Retrieval.search(lib, RetrievalQuery("UI design kaisa pasand hai"), now).first().item.id)
        assertEquals("Nova AI", Retrieval.search(lib, RetrievalQuery("pending features"), now).first().item.project)
    }

    @Test fun unrelatedQuestionsRetrieveNothing() {
        assertTrue(Retrieval.search(library(), RetrievalQuery("weather forecast tomorrow"), now).isEmpty())
    }

    @Test fun twoEquallyGoodMatchesAreReportedAsAmbiguous() {
        val lib = listOf(item(BrainCategory.PROJECT, "Video editing project Alpha", "Alpha"), item(BrainCategory.PROJECT, "Photo editing project Beta", "Beta")).mapIndexed { i, x -> x.copy(id = i + 1L) }
        val hits = Retrieval.search(lib, RetrievalQuery("editing project ka naam"), now)
        val amb = Retrieval.ambiguous(hits)
        assertNotNull(amb); assertEquals(2, amb!!.size)
        assertNull(Retrieval.ambiguous(Retrieval.search(library(), RetrievalQuery("phone"), now)))
    }

    @Test fun timeFilterLimitsRecall() {
        val old = item(BrainCategory.NOTE, "UI discussion notes").copy(id = 1, createdAt = now - 10 * 86_400_000L, updatedAt = now - 10 * 86_400_000L)
        val fresh = item(BrainCategory.NOTE, "UI colour notes").copy(id = 2)
        val yesterday = DateResolver.pastRange("pichhle hafte ki baat", now, utc)!!
        val hits = Retrieval.search(listOf(old, fresh), RetrievalQuery("UI notes", from = yesterday.first, to = yesterday.second), now)
        assertEquals(listOf(2L), hits.map { it.item.id })
    }

    // ───── 9, 10, 12, 19: context builder, voice reconnect, model switching, project context ─────
    private fun seeded(): InMemoryBrainStore {
        val store = InMemoryBrainStore()
        val m = MemoryService(store) { now }
        library().forEach { m.save(Candidate(it.category, it.title, it.content, it.project, it.status), "test") }
        m.ensureProject("Nova AI", Status.ONGOING)
        val lang = LanguageStabilizer(store); hinglish.forEachIndexed { i, s -> lang.observe(s, 1000L + i) }
        val topics = TopicEngine(store); androidConversation(topics)
        store.addTurn(Turn(topicId = topics.activeId(), fromUser = true, text = "Voice aur memory.", ts = 5000))
        store.addTurn(Turn(topicId = topics.activeId(), fromUser = false, text = "Theek hai, voice aur memory features rakhte hain.", ts = 5100))
        return store
    }
    private fun builder(store: BrainStore) = ContextBuilder(store, TopicEngine(store), LanguageStabilizer(store), ProfileService(store)) { now }

    @Test fun contextHasLanguageLockTopicAndOnlyRelevantMemories() {
        val ctx = builder(seeded()).build("mera phone kaunsa hai", 6000).text
        assertTrue(ctx.contains("LANGUAGE LOCK")); assertTrue(ctx.contains("CURRENT TOPIC: Android application"))
        assertTrue(ctx.contains("Samsung Galaxy S23"))
        assertFalse(ctx.contains("Reel Studio"))                    // unrelated memory is not mixed in
    }

    @Test fun contextIsRebuiltAfterReconnectFromTheDatabaseAlone() {
        val store = seeded()
        val ctx = builder(store).build("", 5000, recentTurns = 6).text      // brand-new objects, nothing kept in RAM
        assertTrue(ctx.contains("RECENT MESSAGES")); assertTrue(ctx.contains("voice aur memory features rakhte hain"))
        assertTrue(ctx.contains("Hinglish"))
    }

    @Test fun everyModelGetsTheSameMemoryOnlyTheBudgetDiffers() {
        val b = builder(seeded())
        val pro = b.build("mera phone", ContextBuilder.budgetFor("gemini-2.5-pro")).text
        val lite = b.build("mera phone", ContextBuilder.budgetFor("gemini-2.5-flash-lite")).text
        assertTrue(pro.contains("Samsung Galaxy S23") && lite.contains("Samsung Galaxy S23"))
        assertEquals(6000, ContextBuilder.budgetFor("gemini-2.5-pro")); assertEquals(3500, ContextBuilder.budgetFor("gemini-2.5-flash-lite"))
        assertEquals(1200, ContextBuilder.budgetFor("gemini-2.5-pro", inputTokenLimit = 2000))
        assertTrue(ContextBuilder.budgetFor("gemini-live", live = true) <= 5000)
    }

    @Test fun projectContextCarriesPendingWorkOnlyWhenAsked() {
        val b = builder(seeded())
        val asked = b.build("Nova AI mein kaunse features pending hain", 6000).text
        assertTrue(asked.contains("PROJECT: Nova AI")); assertTrue(asked.contains("voice engine complete"))
        val notAsked = b.build("Nova AI ka naam kaisa hai", 6000).text
        assertTrue(notAsked.contains("pending item(s)")); assertFalse(notAsked.contains("Pending items:"))
    }

    @Test fun uncertainTopicTellsTheModelToAskInsteadOfSwitching() {
        val ctx = builder(seeded()).build("kal subah gym jaana hai", 6000, topicUncertain = true).text
        assertTrue(ctx.contains("do not assume it changed the topic"))
    }

    @Test fun profileUsesOnlyWhatTheUserSaid() {
        val store = InMemoryBrainStore(); val p = ProfileService(store)
        assertEquals("", p.summary())
        p.observe(MemoryExtractor.extract("mujhe chhote jawab pasand hain, short answer do", now, utc).first())
        p.observe(MemoryExtractor.extract("mujhe dark liquid glass UI pasand hai", now, utc).first())
        assertEquals("short", p.get("answer_length")); assertTrue(p.get("fav_ui").contains("liquid"))
        assertTrue(p.get("skill").isEmpty())
    }

    // ───── 12, 13: project memory and file search ─────
    @Test fun fileSearchFindsOnlyRealIndexedFiles() {
        val syms = ProjectFiles.symbols("VoiceEngine.kt", "class VoiceEngine { fun startListening() {} }")
        val files = listOf(
            FileRec(1, 1, "u1", "VoiceEngine.kt", "voice/VoiceEngine.kt", tokens = syms),
            FileRec(2, 1, "u2", "Utils.kt", "core/Utils.kt", tokens = ""),
            FileRec(3, 1, "u3", "VoiceOld.kt", "old/VoiceOld.kt", tokens = "voice engine old", stale = true)
        )
        assertEquals("VoiceEngine.kt", ProjectFiles.search(files, "voice engine code").first().first.name)
        assertTrue(ProjectFiles.search(files, "voice engine code").none { it.first.stale })
        assertTrue(ProjectFiles.search(files, "camera zoom").isEmpty())
        assertEquals("3.8", ProjectFiles.latestVersion(listOf("NovaAI-v3_8-complete.zip", "NovaAI-v3_3.zip", "notes.txt")))
        assertEquals("", ProjectFiles.latestVersion(listOf("readme.md")))
        assertTrue(ProjectFiles.structure(files).contains("voice"))
    }

    // ───── 15: vault encryption ─────
    @Test fun vaultEncryptsTamperProofsAndRefusesSecretLabels() {
        val store = InMemoryBrainStore(); val k = key()
        val vault = SecureVault(store, { k }) { now }
        val id = vault.add("GitHub token", VaultKind.CREDENTIAL_REF, "ghp_supersecret123")
        assertEquals("ghp_supersecret123", vault.reveal(id))
        val cipher = store.vault().single().cipher
        assertFalse(String(cipher, Charsets.ISO_8859_1).contains("supersecret"))
        cipher[cipher.size - 3] = (cipher[cipher.size - 3].toInt() xor 1).toByte()
        try { vault.reveal(id); fail("tampered data must not decrypt") } catch (e: GeneralSecurityException) { }
        try { SecureVault(store, { key() }).reveal(id); fail("another key must not decrypt") } catch (e: GeneralSecurityException) { }
        try { vault.add("abcdefghijklmnopqrstuvwxyz1234", VaultKind.NOTE, "x"); fail("secret-like label") } catch (e: IllegalArgumentException) { }
        vault.delete(id); assertEquals(0, vault.count())
    }

    @Test fun vaultNeverAppearsInContextOrExports() {
        val store = seeded(); val vault = SecureVault(store, { key() }) { now }
        vault.add("Bank note", VaultKind.NOTE, "TOPSECRETVALUE")
        assertFalse(builder(store).build("bank note secret", 6000).text.contains("TOPSECRETVALUE"))
        assertFalse(BackupManager.export(store, now, "t").contains("TOPSECRETVALUE"))
    }

    // ───── 17: backup, verification, restore ─────
    @Test fun encryptedBackupRoundTripWrongPassphraseAndTamper() {
        val src = seeded()
        val json = BackupManager.export(src, now, "test")
        assertTrue(BackupManager.verify(json).ok)
        val sealed = BackupManager.seal(json, "correct horse battery".toCharArray())
        assertFalse(String(sealed, Charsets.ISO_8859_1).contains("Samsung"))
        assertEquals(json, BackupManager.open(sealed, "correct horse battery".toCharArray()))
        try { BackupManager.open(sealed, "wrong passphrase".toCharArray()); fail("wrong passphrase") } catch (e: GeneralSecurityException) { }
        val bad = sealed.copyOf(); bad[bad.size - 5] = (bad[bad.size - 5].toInt() xor 1).toByte()
        try { BackupManager.open(bad, "correct horse battery".toCharArray()); fail("tampered backup") } catch (e: GeneralSecurityException) { }
        assertFalse(BackupManager.verify(json.replace("Samsung", "Samsunk")).ok)
        assertFalse(BackupManager.verify("not json").ok)
    }

    @Test fun restoreRebuildsMemoryTopicsLanguageAndSkipsDuplicates() {
        val src = seeded()
        val json = BackupManager.export(src, now, "test")
        val dst = InMemoryBrainStore()
        val r = BackupManager.restore(dst, json, replace = false)
        assertTrue(r.added > 0)
        assertEquals(src.items().size, dst.items().size)
        assertEquals(src.topics().size, dst.topics().size)
        assertEquals(LanguageStabilizer.HINGLISH, LanguageStabilizer(dst).state()!!.lang)
        val again = BackupManager.restore(dst, json, replace = false)
        assertEquals(0, again.added); assertEquals(src.items().size, again.merged); assertEquals(src.items().size, dst.items().size)
    }

    @Test fun backupCarriesVaultOnlyInsideTheEncryptedFileWhenAsked() {
        val store = InMemoryBrainStore()
        val vault = SecureVault(store, { key() }) { now }; vault.add("Note", VaultKind.NOTE, "hidden text")
        val json = BackupManager.export(store, now, "t", vault.exportPlain())
        val dst = InMemoryBrainStore(); val k2 = key()
        val r = BackupManager.restore(dst, json, true) { SecureVault(dst, { k2 }) { now }.importPlain(it) }
        assertEquals(1, r.vault); assertEquals("hidden text", SecureVault(dst, { k2 }) { now }.let { it.reveal(it.list().single().id) })
    }

    // ───── memory commands ─────
    @Test fun spokenCommandsAreUnderstood() {
        fun p(s: String) = BrainIntents.parse(s)
        assertEquals(BrainIntent.Remember(""), p("Nova, ise yaad rakhna"))
        assertEquals(BrainIntent.DontSave, p("Nova, ye baat save mat karna"))
        assertEquals(BrainIntent.WhatDoYouRemember, p("Nova, meri memory mein kya save hai?"))
        assertEquals(BrainIntent.Recap, p("Nova, hum kya bana rahe the?"))
        assertTrue(p("Nova, hum purani wali baat continue karte hain.") is BrainIntent.ResumeTopic)
        assertTrue(p("Nova, jo kaam adhura chhoda tha use continue karo") is BrainIntent.ResumeTopic)
        assertTrue(p("Nova, mujhe kal wali baat yaad dilao") is BrainIntent.ResumeTopic)
        assertTrue(p("Nova, meri ye information update karo") is BrainIntent.Update)
        assertEquals(BrainIntent.Delete(""), p("Nova, is information ko delete karo"))
        assertEquals(BrainIntent.ProjectMemory, p("Nova, mera pichhla project yaad hai?"))
        assertTrue(p("Nova, mere voice engine ka code kahan hai?") is BrainIntent.FindFile)
        assertTrue((p("Nova, maine tumhe apne phone ke baare mein kya bataya tha?") as BrainIntent.Recall).explicitTold)
        assertTrue(p("Nova, mere editing project ka naam kya tha?") is BrainIntent.Recall)
        assertEquals(BrainIntent.PendingList, p("Nova, mere project mein kaun se features abhi pending hain?"))
        assertEquals(BrainIntent.WipeAll, p("Nova, meri saari memory delete karo"))
        assertEquals(BrainIntent.PauseSaving, p("Nova, memory save karna band karo"))
        assertEquals(BrainIntent.MarkDone("voice engine"), p("voice engine ho gaya"))
    }

    @Test fun ordinaryRequestsAreLeftAlone() {
        listOf("open youtube", "what is the weather today", "call mom", "mujhe ek joke sunao", "Nova, is feature ko baad mein implement karenge").forEach { assertNull(it, BrainIntents.parse(it)) }
        assertTrue(BrainIntents.isYes("haan kar do")); assertTrue(BrainIntents.isNo("nahi rehne do"))
        assertEquals(1, BrainIntents.choiceIndex("doosra", listOf("a", "b")))
        assertEquals(0, BrainIntents.choiceIndex("alpha", listOf("Video editing alpha", "Photo editing beta")))
    }

    @Test fun textToolsBehave() {
        assertTrue(Txt.similar("mujhe dark UI pasand hai", "dark UI mujhe pasand hai"))
        assertFalse(Txt.similar("mujhe dark UI pasand hai", "kal gym jaana hai"))
        assertTrue(Txt.expand(listOf("phone")).contains("mobile"))
        assertTrue(Txt.recency(now, now) > Txt.recency(now - 90 * 86_400_000L, now))
    }
}
