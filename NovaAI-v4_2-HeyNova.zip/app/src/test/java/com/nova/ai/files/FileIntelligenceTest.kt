package com.nova.ai.files

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class FileIntelligenceTest {
    private lateinit var root: File
    @Before fun up() { root = Files.createTempDirectory("novaproj").toFile() }
    @After fun down() { root.deleteRecursively() }
    private fun w(rel: String, text: String) = File(root, rel).also { it.parentFile.mkdirs(); it.writeText(text) }

    // ── project analyzer ──
    @Test fun androidProjectReport() {
        w("build.gradle", "x\n"); w("app/src/main/AndroidManifest.xml", "<manifest/>"); w("app/src/main/java/Main.kt", "val secret=1\nb\nc\n")
        w("README.md", "# Demo\nA demo app.\n"); w("node_modules/x/index.js", "skip\n"); w("build/gen/Gen.kt", "skip\n")
        val rep = ProjectAnalyzer.analyze(root)
        assertEquals(4, rep.files); assertEquals(4, rep.dirs)
        assertTrue(rep.types.contains("Android app (Gradle)"))
        val kt = rep.langs.first { it.name == "Kotlin" }; assertEquals(1, kt.files); assertEquals(3L, kt.lines)
        assertTrue(rep.keyFiles.containsAll(listOf("README.md", "build.gradle", "app/src/main/AndroidManifest.xml")))
        assertFalse(rep.langs.any { it.name == "JavaScript" })                // node_modules skipped
        assertTrue(rep.toText().contains("Kotlin"))
    }

    @Test fun aiExcerptHasOutlineAndKeyFilesButNotSourceCode() {
        w("build.gradle", "x\n"); w("app/src/main/java/Main.kt", "val secret=1\n"); w("README.md", "# Demo\nA demo app.\n")
        val ex = ProjectAnalyzer.excerptForAi(root, ProjectAnalyzer.analyze(root))
        assertTrue(ex.contains("# Demo")); assertTrue(ex.contains("Top-level layout"))
        assertFalse(ex.contains("secret"))
        assertTrue(ex.length <= DocReader.MAX_CHARS)
    }

    @Test fun findsProjectsButNotTheContainer() {
        w("Projects/A/build.gradle", "x"); w("Projects/B/package.json", "{}"); w("Projects/C/notes.txt", "n"); w("Projects/build.gradle", "container")
        val found = ProjectAnalyzer.findProjects(listOf(File(root, "Projects"))).map { it.name }.toSet()
        assertEquals(setOf("A", "B"), found)
    }

    // ── local summary ──
    @Test fun localSummary() {
        val text = "Solar panels convert sunlight into electricity for homes. Solar energy is clean and renewable energy for everyone. Cats are nice. The weather is fine today for a walk outside."
        assertEquals(setOf("solar", "energy"), LocalSummary.keywords(text).take(2).toSet())
        val s = LocalSummary.of(text)
        assertTrue(s.contains("words")); assertTrue(s.contains("Solar"))
        assertFalse(s.contains("Cats are nice"))                       // too short to be a key sentence
        assertEquals("There's no text to summarize.", LocalSummary.of("  "))
    }

    // ── sensitive data ──
    @Test fun luhn() { assertTrue(SensitiveScan.luhn("4111111111111111")); assertFalse(SensitiveScan.luhn("1234567890123456")) }

    @Test fun scanFindsAndDoesNotDoubleCount() {
        assertEquals(listOf(SensitiveFinding("card number", 1)), SensitiveScan.scan("Pay 4111 1111 1111 1111 now"))
        val all = SensitiveScan.scan("Aadhaar 1234 5678 9012, PAN ABCDE1234F, password: hunter2, key AIza" + "A".repeat(35)).map { it.label }
        assertTrue(all.containsAll(listOf("Aadhaar-like number", "PAN-like number", "password, PIN or OTP", "API key or secret")))
        assertTrue(SensitiveScan.scan("order 1234 5678 9012 3456 shipped").isEmpty())      // fails the card checksum and isn't 3 groups
    }

    @Test fun redactHidesValues() {
        val r = SensitiveScan.redact("card 4111 1111 1111 1111 and password: hunter2 ok")
        assertTrue(r.contains("[hidden card number]")); assertTrue(r.contains("[hidden password, PIN or OTP]"))
        assertFalse(r.contains("4111")); assertFalse(r.contains("hunter2"))
    }

    // ── voice / chat commands ──
    private val now = 100L * 86_400_000L
    private fun p(s: String) = FileIntents.parse(s, now)

    @Test fun specPhrases() {
        val read = p("Nova, meri PDF file padho.") as FileIntent.Read
        assertEquals(setOf(FileKind.PDF), read.kinds)

        val search = p("Downloads folder mein APK search karo.") as FileIntent.Search
        assertEquals("Download", search.query.folder); assertEquals(setOf(FileKind.APK), search.query.kinds); assertEquals("", search.query.text)

        assertEquals(FileIntent.LatestDownload, p("Meri latest downloaded file kholo."))
        assertEquals(FileIntent.SummarizeCurrent, p("Is document ka summary banao."))
        assertEquals(FileIntent.AnalyzeProject, p("Mere coding project ko analyze karo."))
        assertEquals(FileIntent.FindDuplicates, p("Duplicate files search karo."))
        assertEquals(FileIntent.Organize("Documents"), p("Mere documents organize karo."))
    }

    @Test fun englishPhrases() {
        val s = p("search for pdf files from yesterday") as FileIntent.Search
        assertEquals(setOf(FileKind.PDF), s.query.kinds); assertEquals(now - 2 * 86_400_000L, s.query.sinceMs)
        val i = p("find invoice pdf in downloads") as FileIntent.Search
        assertEquals("invoice", i.query.text); assertEquals("Download", i.query.folder)
        assertEquals(FileIntent.OpenManager, p("open file manager"))
        assertEquals(FileIntent.Organize("Download"), p("organize my downloads"))
    }

    @Test fun otherRequestsAreNotClaimed() {
        listOf("read my messages", "summarize my notifications", "what's the weather", "open downloads", "play some music", "organize my day", "hello").forEach {
            assertNull("should not claim: $it", p(it))
        }
    }

    @Test fun fileContextRemembersTheLastFile() {
        val f = FileItem("/x/a.pdf", "a.pdf", false, 1, 1, FileKind.PDF)
        FileContext.last = f; assertNotNull(FileContext.last); assertEquals("a.pdf", FileContext.last?.name)
        FileContext.last = null
    }
}
