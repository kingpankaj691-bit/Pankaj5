package com.nova.ai.ai

import com.nova.ai.ai.model.*
import com.nova.ai.ai.net.*
import com.nova.ai.live.LiveErrors
import com.nova.ai.live.setupMessage
import com.nova.ai.live.transcriptionSetupMessage
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class ModelSystemTest {

    private fun m(id: String, vararg methods: String) = GeminiModel(id, methods = methods.toSet())

    // ───────── capability detection ─────────

    @Test fun textModelIsChatCapableAndNotLive() {
        val c = m("gemini-2.5-flash", "generateContent", "countTokens").caps
        assertEquals(ModelKind.TEXT, c.kind)
        assertTrue(c.chatCapable); assertTrue(c.streaming); assertFalse(c.nativeLive); assertNull(c.liveModality)
    }

    @Test fun liveOnlyModelUsesAudioAndCannotChat() {
        val c = m("gemini-3.8-live", "bidiGenerateContent").caps
        assertEquals(ModelKind.LIVE_CONVERSATION, c.kind)
        assertTrue(c.nativeLive); assertFalse(c.chatCapable); assertEquals(LiveModality.AUDIO, c.liveModality); assertTrue(c.nativeAudio)
    }

    @Test fun transcribeModelRequiresTextModality() {
        val c = m("gemini-3.5-transcribe-live", "bidiGenerateContent").caps
        assertEquals(ModelKind.LIVE_TRANSCRIBE, c.kind)
        assertEquals(LiveModality.TEXT, c.liveModality); assertFalse(c.selectable)
    }

    @Test fun ttsImageAndEmbeddingAreNotSelectable() {
        assertEquals(ModelKind.TTS, m("gemini-2.5-flash-preview-tts", "generateContent").caps.kind)
        assertEquals(ModelKind.IMAGE, m("gemini-2.5-flash-image", "generateContent").caps.kind)
        assertEquals(ModelKind.EMBEDDING, m("text-embedding-004", "embedContent").caps.kind)
        assertFalse(m("gemini-2.5-flash-preview-tts", "generateContent").caps.selectable)
    }

    @Test fun hybridModelSupportsBothChatAndLive() {
        val c = m("gemini-x-flash", "generateContent", "bidiGenerateContent").caps
        assertTrue(c.chatCapable); assertTrue(c.nativeLive)
    }

    @Test fun unknownIdFallsBackToNameHeuristics() {
        assertTrue(ModelClassifier.classify("gemini-9.9-flash", emptySet(), known = false).chatCapable)
        assertTrue(ModelClassifier.classify("gemini-9-live", emptySet(), known = false).nativeLive)
        assertFalse(ModelClassifier.classify("gemini-9-flash", emptySet(), known = false).nativeLive)
    }

    // ───────── list parsing ─────────

    @Test fun parsesModelListPageAndToken() {
        val raw = """{"models":[{"name":"models/gemini-2.5-pro","displayName":"Gemini 2.5 Pro","inputTokenLimit":1048576,
            "outputTokenLimit":65536,"supportedGenerationMethods":["generateContent"],"thinking":true}],"nextPageToken":"abc"}"""
        val p = ModelListParser.parsePage(raw)
        assertEquals("abc", p.nextPageToken)
        val x = p.models.single()
        assertEquals("gemini-2.5-pro", x.id); assertEquals(65536, x.outputTokenLimit); assertTrue(x.thinking)
        assertTrue(x.limitsText().contains("1M"))
        assertNull(ModelListParser.parsePage("""{"models":[]}""").nextPageToken)
    }

    @Test fun cacheRoundTripKeepsCapabilities() {
        val src = listOf(m("a-live", "bidiGenerateContent"), m("b-flash", "generateContent"))
        val back = ModelListParser.parsePage(ModelListParser.toJson(src)).models
        assertEquals(src.map { it.id }, back.map { it.id })
        assertEquals(src.map { it.caps.kind }, back.map { it.caps.kind })
    }

    @Test fun sortingPutsLatestAliasesThenNewestFirst() {
        val l = listOf(m("gemini-2.5-flash"), m("gemini-3.1-pro"), m("gemini-flash-latest")).sortedWith(ModelSort.comparator)
        assertEquals(listOf("gemini-flash-latest", "gemini-3.1-pro", "gemini-2.5-flash"), l.map { it.id })
    }

    // ───────── routing ─────────

    @Test fun routesLiveModelToNativeAndFlashToFallback() {
        assertTrue(ModelRouter.route("gemini-3.8-live", m("gemini-3.8-live", "bidiGenerateContent")) is VoiceRoute.NativeLive)
        val f = ModelRouter.route("gemini-2.5-flash", m("gemini-2.5-flash", "generateContent"))
        assertTrue(f is VoiceRoute.Fallback); assertEquals("gemini-2.5-flash", f.modelId)   // same model, never substituted
    }

    @Test fun learnedRefusalOrToggleForcesFallbackForHybrid() {
        val hybrid = m("h", "generateContent", "bidiGenerateContent")
        assertTrue(ModelRouter.route("h", hybrid, learnedNoNative = true) is VoiceRoute.Fallback)
        assertTrue(ModelRouter.route("h", hybrid, preferNative = false) is VoiceRoute.Fallback)
    }

    @Test fun nonAnsweringModelsAreUnavailableNotSwitched() {
        assertTrue(ModelRouter.route("t-tts", m("t-tts", "generateContent")) is VoiceRoute.Unavailable)
        assertTrue(ModelRouter.route("x-live", m("x-live", "bidiGenerateContent"), learnedNoNative = true) is VoiceRoute.Unavailable)
    }

    @Test fun chatIsBlockedForLiveOnlyModelWithReason() {
        val e = ModelRouter.chatProblem("gemini-3.8-live", m("gemini-3.8-live", "bidiGenerateContent"))
        assertNotNull(e); assertEquals(GeminiErrorKind.MODEL_UNSUPPORTED, e!!.kind)
        assertNull(ModelRouter.chatProblem("gemini-2.5-flash", m("gemini-2.5-flash", "generateContent")))
        assertNull(ModelRouter.chatProblem("custom-id", null))
    }

    @Test fun transcriptionPickNeverUsesConversationalModel() {
        val list = listOf(m("gemini-3.8-live", "bidiGenerateContent"), m("gemini-3.5-transcribe-live", "bidiGenerateContent"))
        assertEquals("gemini-3.5-transcribe-live", ModelRouter.pickTranscription("gemini-3.8-live", list, "dflt"))
        assertEquals("dflt", ModelRouter.pickTranscription("gemini-3.8-live", emptyList(), "dflt"))
        assertNull(ModelRouter.pickTranscription("gemini-3.8-live", listOf(m("gemini-2.5-flash", "generateContent")), "dflt"))
    }

    // ───────── Live request configuration (the 1007 bug) ─────────

    @Test fun conversationalSetupSendsOnlyAudio() {
        val s = setupMessage("models/gemini-3.8-live", "sys", "Aoede", JSONArray(), LiveModality.AUDIO).getJSONObject("setup")
        val g = s.getJSONObject("generationConfig")
        assertEquals(1, g.getJSONArray("responseModalities").length())
        assertEquals("AUDIO", g.getJSONArray("responseModalities").getString(0)); assertTrue(g.has("speechConfig"))
    }

    @Test fun transcriptionSetupSendsOnlyTextAndNoVoice() {
        val s = transcriptionSetupMessage("gemini-3.5-transcribe-live").getJSONObject("setup")
        assertEquals("models/gemini-3.5-transcribe-live", s.getString("model"))
        val g = s.getJSONObject("generationConfig")
        assertEquals("TEXT", g.getJSONArray("responseModalities").getString(0)); assertFalse(g.has("speechConfig"))
        assertFalse(s.has("tools")); assertFalse(s.has("outputAudioTranscription"))
    }

    @Test fun textSessionOmitsVoiceToolsAndOutputTranscription() {
        val s = setupMessage("models/x", "sys", "Aoede", JSONArray(), LiveModality.TEXT).getJSONObject("setup")
        assertFalse(s.getJSONObject("generationConfig").has("speechConfig")); assertFalse(s.has("tools"))
    }

    private val serverMsg = "The requested combination of response modalities (TEXT) is not supported by the selected model."

    @Test fun detectsModalityRejectionFrom1007() {
        assertTrue(LiveModalityPolicy.isModalityRejection(1007, serverMsg))
        assertEquals(LiveModality.TEXT, LiveModalityPolicy.triedModality(serverMsg))
        assertFalse(LiveModalityPolicy.isModalityRejection(1007, "models/x is not found for API version v1beta"))
        assertFalse(LiveModalityPolicy.isModalityRejection(1006, ""))
        val c = LiveErrors.classify(null, 1007, serverMsg)
        assertTrue(c.fatal); assertFalse(c.message.contains("not available"))
    }

    @Test fun modalityPolicyPrefersLearnedThenCapability() {
        assertEquals(LiveModality.TEXT, LiveModalityPolicy.modalityFor("t", m("x-transcribe-live", "bidiGenerateContent"), null))
        assertEquals(LiveModality.AUDIO, LiveModalityPolicy.modalityFor("t", m("x-transcribe-live", "bidiGenerateContent"), LiveModality.AUDIO))
        assertEquals(LiveModality.AUDIO, LiveModalityPolicy.modalityFor("gemini-3.8-live", null, null))
    }

    // ───────── generateContent configuration ─────────

    @Test fun generationConfigClampsToModelLimitsAndNeverSendsModalities() {
        val model = GeminiModel("x", outputTokenLimit = 2048, methods = setOf("generateContent"), maxTemperature = 1.0)
        val c = GenerationConfigBuilder.build(1.7, 8000, model)
        assertEquals(2048, c.getInt("maxOutputTokens")); assertEquals(1.0, c.getDouble("temperature"), 0.0)
        assertFalse(c.has("responseModalities"))
        assertEquals(4096, GenerationConfigBuilder.build(0.5, 4096, null).getInt("maxOutputTokens"))
    }

    @Test fun chatRequestShape() {
        val b = ChatRequestBuilder.build(listOf(true to "hi", false to "hello"), "sys", JSONObject())
        assertEquals("model", b.getJSONArray("contents").getJSONObject(1).getString("role"))
        assertTrue(b.has("systemInstruction")); assertFalse(ChatRequestBuilder.build(emptyList(), " ", JSONObject()).has("systemInstruction"))
    }

    @Test fun responseParserSkipsThoughtsAndExplainsEmptyAnswers() {
        val ok = JSONObject("""{"candidates":[{"content":{"parts":[{"text":"hidden","thought":true},{"text":"Hello"}]},"finishReason":"STOP"}]}""")
        assertEquals("Hello", ResponseParser.parse(ok).text)
        val maxed = JSONObject("""{"candidates":[{"content":{"parts":[]},"finishReason":"MAX_TOKENS"}]}""")
        assertEquals(GeminiErrorKind.EMPTY, ResponseParser.parse(maxed).error!!.kind)
        val blocked = JSONObject("""{"promptFeedback":{"blockReason":"SAFETY"}}""")
        assertEquals(GeminiErrorKind.BLOCKED, ResponseParser.parse(blocked).error!!.kind)
    }

    // ───────── error handling ─────────

    private fun http(code: Int, body: String = "", ra: String? = null) = GeminiErrors.fromHttp(code, body, ra, "m", 0L)

    @Test fun classifiesHttpStatuses() {
        assertEquals(GeminiErrorKind.INVALID_KEY, http(401).kind)
        assertEquals(GeminiErrorKind.INVALID_KEY, http(400, """{"error":{"message":"API key not valid. Please pass a valid API key."}}""").kind)
        assertEquals(GeminiErrorKind.PERMISSION, http(403).kind)
        assertEquals(GeminiErrorKind.MODEL_NOT_FOUND, http(404).kind)
        assertEquals(GeminiErrorKind.RATE_LIMIT, http(429).kind)
        assertEquals(GeminiErrorKind.QUOTA_EXHAUSTED, http(429, """{"error":{"message":"Quota exceeded for metric ... PerDay"}}""").kind)
        assertEquals(GeminiErrorKind.SERVER, http(500).kind); assertEquals(GeminiErrorKind.SERVER, http(503).kind)
        assertEquals(GeminiErrorKind.MODEL_UNSUPPORTED, http(400, """{"error":{"message":"response modalities not supported"}}""").kind)
    }

    @Test fun permanentErrorsAreNeverRetried() {
        val p = RetryPolicy.chat()
        listOf(401, 403, 404, 400).forEach { assertNull(p.nextDelayMs(0, http(it))) }
        assertNull(p.nextDelayMs(0, http(429, """{"error":{"message":"PerDay"}}""")))
    }

    @Test fun backoffGrowsWithJitterAndStops() {
        val p = RetryPolicy(maxRetries = 3, baseMs = 1000, capMs = 20_000, random = Random(1))
        val e = http(503)
        val d0 = p.nextDelayMs(0, e)!!; val d1 = p.nextDelayMs(1, e)!!
        assertTrue(d0 in 500..1000); assertTrue(d1 in 1000..2000)
        assertNull(p.nextDelayMs(3, e))                                  // retry limit
        assertNull(p.nextDelayMs(0, e, elapsedMs = 119_900))             // wall-clock budget
    }

    @Test fun retryAfterIsRespectedOrSurfaced() {
        val p = RetryPolicy(random = Random(2))
        assertTrue(p.nextDelayMs(0, http(429, "", "7"))!! >= 7000)
        assertNull(p.nextDelayMs(0, http(429, "", "600")))               // too long to wait: show the error instead
        assertEquals(7000L, GeminiErrors.parseRetryAfter("7"))
        assertNull(GeminiErrors.parseRetryAfter("garbage"))
        assertEquals(27_000L, GeminiErrors.retryDelayFromBody("""{"error":{"details":[{"@type":"type.googleapis.com/google.rpc.RetryInfo","retryDelay":"27s"}]}}"""))
    }

    @Test fun separatesConnectFromResponseTimeout() {
        val c = GeminiErrors.fromException(java.net.SocketTimeoutException("failed to connect to host after 15000ms"), "m")
        val r = GeminiErrors.fromException(java.net.SocketTimeoutException("timeout"), "m")
        assertEquals(GeminiErrorKind.CONNECT_TIMEOUT, c.kind); assertEquals(GeminiErrorKind.RESPONSE_TIMEOUT, r.kind)
        assertEquals(GeminiErrorKind.NO_NETWORK, GeminiErrors.fromException(java.net.UnknownHostException("x"), "m").kind)
        assertFalse(RetryPolicy.chat().nextDelayMs(0, r) != null)        // a slow model is not asked twice
        assertNotNull(RetryPolicy.chat().nextDelayMs(0, c))
    }

    @Test fun messagesNameTheCauseAndNeverLeakKeys() {
        val msg = http(404).userMessage("gemini-x")
        assertTrue(msg.contains("gemini-x") && msg.contains("choose another model"))
        assertFalse(GeminiError(GeminiErrorKind.RESPONSE_TIMEOUT).userMessage().contains("timed out. Check your connection"))
        val leaked = http(400, """{"error":{"message":"bad AIzaSyA1234567890123456789012345678901 key"}}""")
        assertFalse(leaked.detail.contains("AIza"))
    }

    @Test fun responseTimeoutDependsOnModel() {
        assertTrue(GeminiTimeouts.responseMs("gemini-2.5-pro", 1024) > GeminiTimeouts.responseMs("gemini-2.5-flash", 1024))
        assertTrue(GeminiTimeouts.responseMs("gemini-2.5-flash", 8000) > GeminiTimeouts.responseMs("gemini-2.5-flash", 1024))
    }

    @Test fun modelCatalogDoesNotSilentlySwapRetiredModels() {
        assertEquals("gemini-2.0-flash", ModelCatalog.clean("models/Gemini-2.0-Flash", "other"))
        assertEquals("fallback", ModelCatalog.clean("!!", "fallback"))
    }
}
