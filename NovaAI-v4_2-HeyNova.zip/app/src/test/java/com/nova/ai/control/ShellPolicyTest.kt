package com.nova.ai.control

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ShellPolicyTest {
    private fun allowed(c: String) = ShellPolicy.validate(c) is ShellPolicy.Decision.Allow
    private fun risk(c: String) = (ShellPolicy.validate(c) as ShellPolicy.Decision.Allow).risk

    @Test fun allowsDisplaySettings() {
        assertTrue(allowed("settings put system screen_brightness 120"))
        assertTrue(allowed("settings put system screen_off_timeout 60000"))
        assertTrue(allowed("settings put system accelerometer_rotation 0"))
        assertEquals(ShellPolicy.Risk.READ, risk("settings get system screen_brightness"))
    }
    @Test fun rejectsOutOfRangeValues() {
        assertTrue(!allowed("settings put system screen_brightness 0"))
        assertTrue(!allowed("settings put system screen_brightness 300"))
        assertTrue(!allowed("settings put system screen_off_timeout 10"))
    }
    @Test fun rejectsSecureAndGlobalWrites() {
        assertTrue(!allowed("settings put secure lockscreen.disabled 1"))
        assertTrue(!allowed("settings put global airplane_mode_on 1"))
    }
    @Test fun rejectsShellOperators() {
        assertTrue(!allowed("settings get system screen_brightness; rm -rf /sdcard"))
        assertTrue(!allowed("svc wifi enable && reboot"))
        assertTrue(!allowed("input text hello|sh"))
        assertTrue(!allowed("getprop ro.build.version.sdk `id`"))
    }
    @Test fun rejectsDestructiveCommands() {
        listOf("reboot", "rm -rf /sdcard", "pm uninstall com.whatsapp", "pm clear com.whatsapp", "su -c id", "setprop x y",
            "cmd package install-existing x", "am broadcast -a x", "wipe data", "settings put global device_provisioned 0").forEach { assertTrue(it, !allowed(it)) }
    }
    @Test fun forceStopNeedsConfirmAndProtectsSystem() {
        assertEquals(ShellPolicy.Risk.CONFIRM, risk("am force-stop com.example.game"))
        assertTrue(!allowed("am force-stop com.android.systemui"))
        assertTrue(!allowed("am force-stop com.nova.ai"))
        assertTrue(!allowed("am force-stop moe.shizuku.privileged.api"))
        assertTrue(!allowed("am force-stop android"))
    }
    @Test fun togglesAndKeys() {
        assertTrue(allowed("svc wifi enable")); assertTrue(allowed("svc bluetooth disable")); assertTrue(!allowed("svc data enable"))
        assertTrue(allowed("input keyevent KEYCODE_BACK")); assertTrue(!allowed("input keyevent KEYCODE_POWER"))
        assertTrue(allowed("cmd notification set_dnd priority"))
        assertTrue(allowed("cmd media_session volume --stream 3 --set 7"))
    }
    @Test fun inputTextEscaping() {
        assertEquals("hello%sworld", ShellPolicy.inputTextArg("hello world"))
        assertEquals(null, ShellPolicy.inputTextArg("a'b"))
        assertEquals(null, ShellPolicy.inputTextArg(""))
    }
}
