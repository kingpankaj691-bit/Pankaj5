package com.nova.ai.files

import android.Manifest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FileManagerCoreTest {
    private fun item(name: String, size: Long = 100, mod: Long = 1_000, dir: Boolean = false, folder: String = "/storage/emulated/0/Download") =
        FileItem("$folder/$name", name, dir, size, mod, if (dir) FileKind.FOLDER else FileTypes.kindOf(name), null, "", folder)

    @Test fun kindsFromExtension() {
        assertEquals(FileKind.PDF, FileTypes.kindOf("a.PDF"))
        assertEquals(FileKind.WORD, FileTypes.kindOf("x.docx"))
        assertEquals(FileKind.SHEET, FileTypes.kindOf("x.xlsx"))
        assertEquals(FileKind.DATA, FileTypes.kindOf("x.csv"))
        assertEquals(FileKind.CODE, FileTypes.kindOf("Main.kt"))
        assertEquals(FileKind.CODE, FileTypes.kindOf("App.java"))
        assertEquals(FileKind.APK, FileTypes.kindOf("nova.apk"))
        assertEquals(FileKind.ARCHIVE, FileTypes.kindOf("a.zip"))
        assertEquals(FileKind.WEB, FileTypes.kindOf("i.html"))
        assertEquals(FileKind.OTHER, FileTypes.kindOf("noext"))
        assertEquals(FileKind.OTHER, FileTypes.kindOf(".hidden"))
    }

    @Test fun extAndMime() {
        assertEquals("gz", FileTypes.extOf("a.tar.gz"))
        assertEquals("", FileTypes.extOf("a."))
        assertEquals("application/pdf", FileTypes.mimeOf("a.pdf"))
        assertEquals("application/octet-stream", FileTypes.mimeOf("a.unknown"))
        assertEquals(FileKind.IMAGE, FileTypes.kindOfMime("image/webp"))
        assertEquals(FileKind.APK, FileTypes.kindOfMime("application/vnd.android.package-archive"))
    }

    @Test fun wordsInHinglish() {
        assertTrue(FileKind.AUDIO in FileTypes.kindsForWord("gaane"))
        assertTrue(FileKind.IMAGE in FileTypes.kindsForWord("tasveer"))
        assertTrue(FileKind.PDF in FileTypes.kindsForWord("documents"))
        assertTrue(FileTypes.kindsForWord("banana").isEmpty())
    }

    @Test fun sizeFormatAndParse() {
        assertEquals("512 B", FileFormat.size(512))
        assertEquals("1.5 KB", FileFormat.size(1536))
        assertEquals("5.0 MB", FileFormat.size(5L * 1048576))
        assertEquals(5L * 1048576, FileFormat.parseSize("5mb"))
        assertEquals(200L * 1024, FileFormat.parseSize("200 KB"))
        assertNull(FileFormat.parseSize("big"))
        assertEquals(0.5f, FileFormat.percent(50, 100), 0.0001f)
        assertEquals(0f, FileFormat.percent(5, 0), 0.0001f)
    }

    @Test fun sortKeepsFoldersFirst() {
        val l = listOf(item("b.txt", 5, 10), item("Zed", dir = true), item("a.txt", 50, 20), item("Alpha", dir = true))
        assertEquals(listOf("Alpha", "Zed", "a.txt", "b.txt"), FileSort.sort(l, SortMode.NAME).map { it.name })
        assertEquals(listOf("a.txt", "b.txt"), FileSort.sort(l, SortMode.DATE).filter { !it.isDir }.map { it.name })
        assertEquals("a.txt", FileSort.sort(l, SortMode.SIZE).first { !it.isDir }.name)
    }

    @Test fun pathWithinIsNotFooledByPrefixes() {
        assertTrue(PathRules.isWithin("/storage/emulated/0", "/storage/emulated/0/Download/a.pdf"))
        assertTrue(PathRules.isWithin("/storage/emulated/0", "/storage/emulated/0"))
        assertFalse(PathRules.isWithin("/storage/emulated/0", "/storage/emulated/01/x"))
        assertFalse(PathRules.isWithin("/storage/emulated/0", "/data/data/com.nova.ai"))
    }

    @Test fun parentAndBreadcrumb() {
        val root = "/storage/emulated/0"
        assertEquals("/storage/emulated/0/Download", PathRules.parent("/storage/emulated/0/Download/x", root))
        assertNull(PathRules.parent(root, root))
        val b = PathRules.breadcrumb("/storage/emulated/0/Download/x", root)
        assertEquals(listOf("Storage", "Download", "x"), b.map { it.first })
        assertEquals("/storage/emulated/0/Download", b[1].second)
        assertTrue(PathRules.breadcrumb("/other", root).isEmpty())
    }

    @Test fun otherAppsFoldersAreBlocked() {
        assertNotNull(PathRules.blockedReason("/storage/emulated/0/Android/data"))
        assertNotNull(PathRules.blockedReason("/storage/emulated/0/Android/data/com.whatsapp/files"))
        assertNotNull(PathRules.blockedReason("/storage/emulated/0/Android/obb"))
        assertNotNull(PathRules.blockedReason("/storage/1A2B-3C4D/Android/data/x"))
        assertNotNull(PathRules.blockedReason("/data/data/com.other.app/databases"))
        assertNotNull(PathRules.blockedReason("/data/user/0/com.other.app"))
        assertNull(PathRules.blockedReason("/storage/emulated/0/Android"))
        assertNull(PathRules.blockedReason("/storage/emulated/0/Download"))
        assertNull(PathRules.blockedReason("/storage/emulated/0/Android-backup"))
    }

    @Test fun searchMatching() {
        val f = item("Invoice March.pdf", 2000, 5_000)
        assertTrue(SearchQuery(text = "invoice march").matches(f))
        assertFalse(SearchQuery(text = "invoice april").matches(f))
        assertTrue(SearchQuery(exts = setOf("pdf")).matches(f))
        assertTrue(SearchQuery(kinds = setOf(FileKind.PDF)).matches(f))
        assertFalse(SearchQuery(kinds = setOf(FileKind.IMAGE)).matches(f))
        assertTrue(SearchQuery(folder = "download").matches(f))
        assertFalse(SearchQuery(folder = "dcim").matches(f))
        assertTrue(SearchQuery(sinceMs = 4_000).matches(f))
        assertFalse(SearchQuery(sinceMs = 6_000).matches(f))
        assertFalse(SearchQuery(untilMs = 5_000).matches(f))
        assertFalse(SearchQuery(minSize = 5000).matches(f))
        assertFalse(SearchQuery(text = "x").matches(item("Download", dir = true)))
    }

    @Test fun queryBoxFilters() {
        val now = 100L * 86_400_000L
        val q = QueryBox.parse("invoice ext:pdf,.docx in:Download days:7 min:2mb type:images", now)
        assertEquals("invoice", q.text)
        assertEquals(setOf("pdf", "docx"), q.exts)
        assertTrue(FileKind.IMAGE in q.kinds)
        assertEquals("Download", q.folder)
        assertEquals(now - 7 * 86_400_000L, q.sinceMs)
        assertEquals(2L * 1048576, q.minSize)
        assertTrue(QueryBox.parse("   ").isEmpty)
        assertEquals("days:abc", QueryBox.parse("days:abc").text)
    }

    @Test fun chipFiltersMergeWithoutOverridingTypedOnes() {
        val now = 50L * 86_400_000L
        val q = QueryBox.parse("report days:3 in:DCIM", now).withFilters(setOf(FileKind.PDF), 30, "Download", now)
        assertEquals(now - 3 * 86_400_000L, q.sinceMs)      // typed filter wins
        assertEquals("DCIM", q.folder)
        assertTrue(FileKind.PDF in q.kinds)
    }

    @Test fun permissionsPerAndroidVersion() {
        assertEquals(4, FileAccessRules.permissionsToRequest(34).size)
        assertTrue(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED in FileAccessRules.permissionsToRequest(34))
        assertEquals(3, FileAccessRules.permissionsToRequest(33).size)
        assertEquals(listOf(Manifest.permission.READ_EXTERNAL_STORAGE), FileAccessRules.permissionsToRequest(30))
        assertEquals(listOf(Manifest.permission.READ_EXTERNAL_STORAGE), FileAccessRules.permissionsToRequest(26))
    }

    @Test fun pathAccessRules() {
        assertTrue(FileAccessRules.pathAccess(34, allFilesGranted = true, readStorageGranted = false))
        assertFalse(FileAccessRules.pathAccess(34, allFilesGranted = false, readStorageGranted = true))
        assertTrue(FileAccessRules.pathAccess(28, allFilesGranted = false, readStorageGranted = true))
        assertFalse(FileAccessRules.pathAccess(28, allFilesGranted = false, readStorageGranted = false))
        assertFalse(FileAccessRules.pathAccess(29, allFilesGranted = true, readStorageGranted = true))   // Android 10: scoped storage, no path access
    }

    @Test fun accessStateNeverClaimsMore() {
        val none = FileAccessState(34, true, false, false, false, false, false, false, 0, false)
        assertFalse(none.canSeeAnything); assertFalse(none.pathAccess)
        assertTrue(none.lines().first().contains("not available"))
        val partial = none.copy(selectedOnly = true)
        assertTrue(partial.canSeeAnything); assertFalse(partial.pathAccess)
        assertTrue(none.copy(safFolders = 1).canSeeAnything)
    }

    @Test fun historyRingBufferAndCodec() {
        val log = FileOpLog(cap = 3)
        for (i in 1..5) log.add(FileOpRecord(i.toLong(), i * 10L, FileOp.OPEN, "f$i", "", FileStatus.OK, ""))
        assertEquals(listOf("f5", "f4", "f3"), log.all().map { it.name })
        val round = FileOpCodec.decode(FileOpCodec.encode(log.all()))
        assertEquals(log.all(), round)
        assertTrue(FileOpCodec.decode("not json").isEmpty())
        log.clear(); assertTrue(log.all().isEmpty())
    }
}
