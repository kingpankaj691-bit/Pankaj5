#!/usr/bin/env python3
"""NOVA PC companion (optional). Runs on YOUR computer; NOVA sends it JSON over your own network.
Only the whitelisted commands below can run (lock, sleep, volume, media keys, shutdown/restart with a 60 s delay, open a URL or a listed app). Set NOVA_TOKEN and use the same token in NOVA → Tools → Connections.
Usage:  NOVA_TOKEN=secret python3 pc_companion.py   (listens on port 8765; expose only on your home network)
Endpoint to enter in NOVA:  http://<pc-ip>:8765/
"""
import json, os, platform, subprocess, webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

TOKEN = os.environ.get("NOVA_TOKEN", "")
OS = platform.system()

def lock():
    cmds = {"Windows": ["rundll32.exe", "user32.dll,LockWorkStation"], "Darwin": ["pmset", "displaysleepnow"], "Linux": ["loginctl", "lock-session"]}
    subprocess.Popen(cmds[OS])
def sleep():
    cmds = {"Windows": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"], "Darwin": ["pmset", "sleepnow"], "Linux": ["systemctl", "suspend"]}
    subprocess.Popen(cmds[OS])

def _ps(script):
    subprocess.Popen(["powershell", "-NoProfile", "-Command", script])

def volume(direction):
    """direction: up | down | mute"""
    if OS == "Windows":
        key = {"up": 175, "down": 174, "mute": 173}[direction]
        _ps(f"(New-Object -ComObject WScript.Shell).SendKeys([char]{key})")
    elif OS == "Darwin":
        expr = {"up": "set volume output volume ((output volume of (get volume settings)) + 10)",
                "down": "set volume output volume ((output volume of (get volume settings)) - 10)",
                "mute": "set volume output muted true"}[direction]
        subprocess.Popen(["osascript", "-e", expr])
    else:
        arg = {"up": "+10%", "down": "-10%", "mute": "toggle"}[direction]
        subprocess.Popen(["pactl", "set-sink-mute" if direction == "mute" else "set-sink-volume", "@DEFAULT_SINK@", arg])

def media(action):
    """action: playpause | next | prev"""
    if OS == "Windows":
        key = {"playpause": 179, "next": 176, "prev": 177}[action]
        _ps(f"(New-Object -ComObject WScript.Shell).SendKeys([char]{key})")
    elif OS == "Linux":
        subprocess.Popen(["playerctl", {"playpause": "play-pause", "next": "next", "prev": "previous"}[action]])
    else:
        return False
    return True

def power(kind):
    """Shutdown / restart wait 60 seconds so you can cancel with: shutdown /a (Windows) or shutdown -c (Linux)."""
    if OS == "Windows":
        subprocess.Popen(["shutdown", "/s" if kind == "shutdown" else "/r", "/t", "60"])
    elif OS == "Linux":
        subprocess.Popen(["shutdown", "-h" if kind == "shutdown" else "-r", "+1"])
    else:
        return False
    return True

APPS = {  # only these names can be opened by voice
    "Windows": {"notepad": "notepad", "calculator": "calc", "chrome": "chrome", "explorer": "explorer", "terminal": "wt", "vscode": "code"},
    "Darwin": {"calculator": "Calculator", "chrome": "Google Chrome", "terminal": "Terminal", "vscode": "Visual Studio Code", "safari": "Safari"},
    "Linux": {"calculator": "gnome-calculator", "chrome": "google-chrome", "terminal": "gnome-terminal", "vscode": "code", "files": "nautilus"},
}

def run(command: str) -> str:
    c = command.strip().lower()
    if c in ("lock", "lock pc", "lock screen"): lock(); return "locked"
    if c in ("sleep", "sleep pc"): sleep(); return "sleeping"
    if c in ("volume up", "louder"): volume("up"); return "volume up"
    if c in ("volume down", "quieter"): volume("down"); return "volume down"
    if c in ("mute", "volume mute"): volume("mute"); return "muted"
    if c in ("play", "pause", "play pause", "resume"): return "ok" if media("playpause") else "not supported on this OS"
    if c in ("next", "next song", "next track"): return "ok" if media("next") else "not supported on this OS"
    if c in ("previous", "previous song", "prev"): return "ok" if media("prev") else "not supported on this OS"
    if c in ("shutdown", "shut down", "shutdown pc"): return "shutting down in 60 seconds" if power("shutdown") else "not supported on this OS"
    if c in ("restart", "restart pc", "reboot"): return "restarting in 60 seconds" if power("restart") else "not supported on this OS"
    if c.startswith("open "):
        target = command[5:].strip()
        if target.startswith(("http://", "https://")): webbrowser.open(target); return "opened"
        if "." in target and " " not in target: webbrowser.open("https://" + target); return "opened"
        app = APPS.get(OS, {}).get(target.lower())
        if app:
            subprocess.Popen(["open", "-a", app] if OS == "Darwin" else [app]); return "opened " + target
    return "unsupported command (allowed: lock, sleep, volume up/down, mute, play/pause, next, previous, shutdown, restart, open <url or " + ", ".join(APPS.get(OS, {})) + ">)"

class H(BaseHTTPRequestHandler):
    def do_POST(self):
        if TOKEN and self.headers.get("Authorization") != f"Bearer {TOKEN}":
            self.send_response(401); self.end_headers(); return
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            out = run(body.get("command", ""))
            code = 200
        except Exception as e:
            out, code = f"error: {e}", 400
        self.send_response(code); self.end_headers(); self.wfile.write(out.encode())
    def log_message(self, *a): pass

if __name__ == "__main__":
    if not TOKEN: print("WARNING: NOVA_TOKEN is not set; anyone on your network could send commands.")
    HTTPServer(("0.0.0.0", 8765), H).serve_forever()
