# NOVA AI — "Your Voice. My World."
Package `com.nova.ai` · Kotlin + Jetpack Compose · Gemini via REST (no extra SDK) · minSdk 26, target/compile 34

## Build (AndroidIDE, on the phone)
1. Open the `NovaAI` folder in AndroidIDE and wait for Gradle sync (it downloads dependencies, so be online).
2. Build > Build APK (debug). The APK is `app/build/outputs/apk/debug/app-debug.apk`.
3. Install it and allow "unknown sources" for AndroidIDE when asked.
No Termux, root or shell scripts are used anywhere in the build.

## Gemini setup
Get a key at aistudio.google.com → app → Settings → paste key → Test connection.
Key is stored with EncryptedSharedPreferences, never in source. Model name is editable (default `gemini-2.0-flash`).

## Enabling restricted features
- Background Voice: Settings → Background (or Control tab) → switch on. Allow Microphone and Notifications. A notification with Pause / Stop shows the whole time the mic is on.
- Accessibility: Access tab → Open Accessibility → NOVA AI → On. If "Restricted setting": App info → ⋮ → Allow restricted settings.
- Notification access: Access tab → Open Notification access → NOVA AI.

## Android limits (honest list)
- Apps can't silently toggle Wi-Fi/Bluetooth/mobile data on Android 10+; Nova opens the right settings page.
- Background Voice records with AudioRecord (no SpeechRecognizer loop, no beep) and sends 5-second clips to Gemini for speech-to-text, so it needs internet, a Gemini key and uses Gemini quota continuously. There is no offline recognizer for the continuous mode.
- Launching apps from the background (screen off / other app) is restricted by Android 10+.
- Nova opens the dialer for calls; you tap Call (that is the confirmation).
- Samsung/One UI may kill background services: disable battery optimisation for NOVA AI.

## Testing checklist
text chat · invalid key message · airplane mode message · flashlight on/off · open YouTube/settings · call a number/contact · mic switch + notification Stop · accessibility read screen · remember/delete memory · permissions screen status after grant/deny.

## Not yet built (next phase)
Wi-Fi password connect, Bluetooth device list, per-app notification allow-list, file/SAF tools, code editor with highlighting, confirmation-level setting, Compose multi-screen split (Voice/Memory/About are folded into Chat/Settings).

## Liquid Glass UI (v1.1)
Design system: `ui/Glass.kt` (GlassCard, GlassButton, GlassIconButton, GlassTextField, GlassSwitch, GlassSlider, GlassChip, GlassListItem, GlassSettingSection, GlassPermissionCard, GlassDialog, GlassSheet, GlassBottomBar, GlassNavigationBar). Tokens come from one `GlassTheme` (dark/light, accent, blur, transparency, reduced motion) set in Settings → Appearance.
Blur: real RenderEffect blur on the ambient background (Android 12+), soft gradients on older Android. Cards are translucent gradient + border highlight + sheen, not live backdrop blur.
Icons are emoji glyphs (no icon dependency), so they are not accent-tinted.
Tabs: Home, Chat, Control, Developer, Settings (Voice/Gemini/Memory/Privacy/Permissions/Personality live inside Settings).

## v1.2 — mood, emotion, avatar, voice, routing
- Mood engine (local keywords, tone only) + 11 emotion states; Gemini also tags its reply `[emo:x]` (stripped before display/speech). Emotion drives wording hint, TTS rate/pitch, avatar face, ambient lighting.
- 21 personalities, mood override (Auto/Calm/Happy/Funny/Serious/Professional/Playful), "talk normally" command.
- Voice: auto language, volume, voice picker, sentence-by-sentence TTS with pauses, Stop / Continue / Repeat, mic-level reactive orb/avatar.
- Router categories (AI_CHAT, DEVICE_CONTROL, APP_CONTROL, PHONE, SCREEN_CONTROL, VOICE, DEVELOPER, MEMORY, SETTINGS, GENERAL_INFORMATION) run locally; confirmation level in Settings → Privacy & Security.
- Screen text and notification text are sent to Gemini only after you ask ("what is on my screen", "summarize notifications").
- Developer tab: Assistant + Editor (highlighting, Copy, Save via system picker, Share, Explain, Fix).
- Settings search, Liquid Glass materials, Notifications app allow-list, Device Scan page.
Honest limits: avatar is stylized vector art (not photoreal); TTS can't resume mid-word (Continue restarts the interrupted sentence); speaking-amplitude sync isn't available from Android TTS (mouth is animated by a timer); mic level uses SpeechRecognizer RMS; no barge-in while Nova speaks in background mode.

## v1.3 — NOVA Device Intelligence
Say "Nova, scan my phone" (or tap Scan Phone / Control → Device Intelligence). Nova runs 18 scan steps (Device, Android, Hardware, Display, Battery, Storage, Memory, Network, Wi-Fi, Bluetooth, Sensors, Cameras, Audio, Applications, Permissions, Notifications, Accessibility, System features) with an animated progress view, then shows SCAN COMPLETE, a tappable health dashboard, an app inventory (10 categories, version, install/update dates, launch), an app capability map, Storage Overview, Battery Center, Network Center and Permission Intelligence. Then ask "What did you find?" — answered locally from the stored report.
- Profile is saved only in app-private storage (device_profile.json); Settings → Device Intelligence or "delete scan data" removes it. Only a one-line summary (never the full profile) is added as AI context, and only when your question is about the device; app names only if you ask about apps.
- Hardware items show Available / Not available / Restricted (present but Nova lacks the permission).
- Wi-Fi: status, "connect with password" uses Android's own add-network dialog (Android 11+; password never stored). SSID is hidden by Android without Location permission, which Nova does not request.
- Bluetooth: paired/connected lists need the Nearby devices permission; "turn Bluetooth on" asks Android to enable it.
- Modules: `core/Modules.kt` defines AIProvider, VoiceProvider, TTSManager, CommandExecutor, DeviceScanner, AppManager, ScreenAssistant, MemoryManager, NotificationManager, PermissionManager, PersonalityEngine; Gemini, voice, scanner, apps, memory, notifications, permissions, accessibility and personality implement them. Router categories now: DEVICE_SCAN, LOCAL_DEVICE_COMMAND, APP_COMMAND, VOICE_COMMAND, SCREEN_COMMAND, AI_QUERY, DEVELOPER_COMMAND, SETTINGS_COMMAND, GENERAL_QUERY.
Honest limits: CPU model/clock and battery capacity aren't reliably exposed; app list is limited by package visibility; per-app permission info is only which sensitive permissions other visible apps hold; USB, NFC, etc. are feature flags only.

## v1.4 — persistence, memory engine, offline, security
- **Boot:** `BootReceiver` (BOOT_COMPLETED / app update) restores local state, purges expired memory, reschedules routines, checks for device changes and posts "NOVA initialized". It never starts the microphone by itself (Android blocks that); the notification has a "Resume listening" button if you had the background assistant on. A phone that is powered off cannot run NOVA.
- **Background Reliability** (Settings): service, battery optimization, auto-start (OEM page when known; Android doesn't report status), notifications, mic permission, last boot init.
- **Foreground service:** "NOVA Assistant Active" with Pause / Resume / Talk / Stop. Pause turns the mic off.
- **Memory engine:** SQLite (`nova.db`), 9 categories, importance, confidence LOW/MEDIUM/HIGH, expiry, source, userConfirmed, pin, forget (blocks re-saving), "Why did NOVA remember this?", ignored list (sensitive text is never stored, only a redacted note). Local rules decide; nothing is sent for classification. Temporary context expires by itself; confirmed permanent memories are never auto-deleted.
- **Context:** current conversation + short-term context (temporary memories) + long-term memory; long chats are compressed (Gemini online, local rules offline; passwords redacted first). Chat history is restored after closing (can be turned off/deleted).
- **Offline:** `OfflineProvider` + `LocalCommandRouter` (flashlight, apps, settings, battery, device/storage/Wi-Fi/Bluetooth status, time/date, calculator, timers/alarms via the clock app, notes, reminders, memory, scan). AI-only questions answer "Internet is required for this answer." Speech recognition asks Android to prefer offline. A future on-device model implements `AIProvider`.
- **Security:** Owner Mode with Confirm / Voice-or-biometric / Biometric (Android BiometricPrompt). Voice Lock is an experimental spectral voiceprint check, easy to fool, never claimed as biometric; enrolment/verification record only while you tap the button.
- **Lock screen:** per-type allow list; private data (notifications, screen text, memories, notes) is never revealed while locked, and memory isn't sent to the AI while locked.
- **Automation:** daily-time, one-time, battery-low and Bluetooth-connect routines via WorkManager. They only notify or offer to open an app (tap to proceed); nothing runs silently. Times can be minutes late under Doze.
- **Change detection:** cheap snapshot diff (packages, Android build, Bluetooth, network, storage 5% steps) at app start, boot and every 12 h; only affected profile sections are refreshed.
- **Plugins:** Settings → Plugins; Reminders, Notes, Study mode, Gaming mode work; others are listed as not built.
Limits: no separate Voice screen (voice lives on Home/Chat/Voice settings); wake word isn't low-power; Bluetooth-connect routines depend on Android delivering the broadcast; BiometricPrompt needs a screen lock to be set.

## v1.5 — People, relationships & person-aware conversation
- **Room database** (`nova_people.db`, KSP): persons, aliases, person_memories, blocked_patterns. `@SkipQueryVerification` is on the database so the build doesn't need Room's SQLite JDBC check (it fails on some Termux/ARM setups). If your build ever complains about KSP, remove the `ksp` plugin/deps and ask me for a framework-SQLite version.
- **Say it naturally (Hinglish/English):** "Ye meri mummy hain, naam Sunita hai", "Rahul mera dost hai", "Rahul ko main Rahu bulata hoon", "Meri mummy ka naam kya hai?", "Rahul ke baare mein jo yaad hai batao", "Rahul ko bhool jao", "Rahul ke saath main gaming karta hoon", "Rahul ko message karna hai", "Isko yaad rakhna", "Is baat ko mat yaad rakhna", "Saare people memories delete karo".
- **Never guesses:** multiple Rahuls → "Kaunse Rahul?" with buttons (or answer "dost", "2"). Same name + same relationship → no duplicate; same name + different relationship → asks merge/keep separate. Possible duplicates (similar names) are only suggested in People & Memory, never merged silently.
- **Privacy:** only people you introduce; no audio, camera, tracking or speaker identification (the speaker module is an empty, optional slot). Gemini gets at most one short line for each person named in the request (e.g. "Rahul is the user's friend."), never the people list, and only if "Use in AI answers" is on globally and for that person. Notes refuse passwords/PINs/cards. Data lives in app-private storage (not separately encrypted by the app); Owner Mode can lock the People screen; export is user-initiated.
- **Mood:** the tone shown for a person is the tone of YOUR messages about them. NOVA answers mood questions with "Mere paas ... reliable information nahi hai" or a hedged "lagta hai ... lekin main sure nahi hoon". Explicit style requests ("short mein bolo", "formal tone") override automatic mood, and each person can have a conversation style (formal, casual, funny, short, detailed...).
- **Separate from owner security:** People recognition only personalizes chat. Owner Mode / BiometricPrompt / Voice Lock are untouched. Message/call actions are Sensitive: they ask for confirmation, open the SMS composer or dialer, and never send anything by themselves.
- Not used: DataStore (existing prefs already cover settings). Custom relationships ("Neighbour") are added through the UI; voice only recognizes the built-in relationship words.

## v1.6 — Screen engine, vision, web search, planner, languages
**New modules** (all wired into one pipeline: text/voice → language detection → `TaskPlanner` → `LocalCommandRouter` → web search → Gemini/Offline):
- `screen/` — `ScreenActionExecutor` (tap, double tap, long press, swipe, drag, scroll, type, submit, Back/Home/Recents/Notifications), `ScreenSearch` (find buttons/fields/text; asks "Kaunsa select karun?" on multiple matches), `ActionValidator` (refuses payment/banking/password apps and password fields; asks before pay/delete/install/send-type actions).
- `vision/` — `ScreenCaptureManager` (MediaProjection, user-approved, visible notification with Stop, newest frame in RAM only) → `ScreenFrame` → `VisionAnalyzer` (Gemini) → `UIElementResolver` (accessibility first, screenshot only for visual queries like "blue button"). Start with "start screen vision" or Settings → Screen Assistant.
- `planner/` — `IntentClassifier`, `TaskPlanner` (Hindi/Hinglish/English, multi-step: "YouTube kholo aur search mein latest AI news dekho"), `PlanRunner` (waits for app, finds search, types, presses Search, opens result; stops and explains on failure), `ContextPolicy` (what may be sent to Gemini).
- `web/` — `WebSearchProvider` (Gemini + Google Search grounding), source verification (https only, de-duplicated, trusted sources first ✓), honest "no internet / local-only" messages. "YouTube par search karo X" opens YouTube results by intent.
- `language/` — 50-language catalog, on-device language detector (scripts + Hinglish/Latin heuristics), Auto/Manual mode, TTS fallback note, recognition language detection on Android 13+.
- `future/` — interfaces only (image, camera, PDF, translation, weather, calendar, music, smart home, PC, multi-device, study, gaming, travel, productivity) + `ModuleRegistry`. No fake implementations.
- Also: max output tokens, Clear API key, Local-only mode, Web/vision sharing toggles, Bluetooth nearby scan ("scan bluetooth"), "open contact Rahul", headphone-connect routines + routine log, Export my data, More hub with Voice / Screen Assistant / Notifications / Permissions / Privacy / About screens, Orb states Processing and Screen Control.

**Honest limits**
- This code was written without a compiler or device in this environment. Run `gradle assembleDebug` and send me any errors; expect a few small fixes.
- Accessibility service config changed (gestures enabled): disable and re-enable NOVA AI in Accessibility after updating.
- Android 14+ asks for screen-capture approval every time Screen Vision starts. Apps that hide their UI or block gestures can't be controlled; NOVA says so.
- Starting apps from the background is restricted by Android 10+; screen plans work best when NOVA is in front or started from the notification.
- Headphone routines notify; they cannot open apps silently. Hindi words typed with unusual spellings may not parse; Gemini handles open conversation.

## v1.7 — future modules are now real
- **Weather** (Open-Meteo, no key), **Calendar** (read-only, needs Calendar permission), **Translation** (Gemini), **Music** (play-from-search intent + media keys; works with any player that listens to media keys), **Study quiz, Gaming tips, Travel plan, Day plan** (Gemini), **Image / Camera / PDF / Document** questions (Tools screen: you pick the file or photo; sent once to Gemini), **Smart home / PC / other devices** (JSON POST to an endpoint you run; sample PC script in `companion/pc_companion.py`; every send asks first), **Reminders + Notes** modules registered, **notification dismiss/open** ("dismiss notifications from whatsapp", "open latest notification"), **Companion style** chooser (Settings → Personality, GF Mode/Companion).
- Voice phrases are listed in More → Tools. Modules need: internet (weather, Gemini ones), Calendar permission, Notification access, or your own endpoint.
- Still not done / honest limits: no low-power wake-word engine (still SpeechRecognizer loop); memory stays SQLite (only People uses Room) and navigation is custom tab navigation, not Navigation Compose; Bluetooth has status, nearby scan and settings but no direct connect (Android doesn't allow it for arbitrary devices); smart home/PC need your own endpoint, NOVA has no built-in device drivers; ContextPolicy is defined but the older context rules are what actually gate Gemini context; weather without a city needs Location permission; code has not been compiled here.

## v1.8 — Device Intelligence completed
`scanner/HardwareCapabilityManager.kt` (new) plus 3 new scan steps (21 total): **Processor & graphics** (ABIs, 64-bit, cores, min/max clock when Android exposes it, board, OpenGL ES, Vulkan, memory class, low-RAM, thermal status, SoC), **Speech & language** (recognition, on-device recognition on Android 13+, TTS engines/voices/offline voices/languages, device languages, wake-word hardware note) and **NOVA readiness** (19 abilities: flashlight, voice, TTS, screen control, Screen Vision, biometrics, notifications, calls/contacts, Bluetooth, Wi-Fi dialog, background service, boot recovery, calendar, weather location, camera, Gemini, offline brain, on-device model, wake word — each Ready / Needs permission / Not available with the reason).
Existing sections now carry more facts: Display (size, wide colour, HDR, dark mode), Battery (capacity/charge counter, current, voltage, cycles on Android 14), Network (transports, uplink, roaming, data saver, SIM state, carrier, airplane mode), Wi-Fi (5/6 GHz, Wi-Fi 5/6, Direct), Bluetooth (LE 2M/Coded/extended, scan permission), Storage (volumes, SD card), Memory (low-memory state), Sensors (total, vendors), Cameras (megapixels, max video, focal lengths, aperture, OIS, RAW, zoom).
Honest limits: battery mAh capacity, CPU model name and some clocks are hidden by many phones and show as Restricted; GPU model needs an OpenGL context and isn't read; nothing private (files, messages, Wi-Fi passwords, other apps' data) is read. Not compiled here.

## v1.9 — Continuous Background Voice (AudioRecord)
Pipeline: `NovaVoiceForegroundService` → `AudioCapture` (AudioRecord PCM) → `SpeechProcessingEngine` (`GeminiSpeechEngine`) → recognized text → `VoiceCommandDispatcher` → command router (`LocalCommandRouter` via the app, or `HeadlessAssistant` when the UI is closed) → `GeminiProvider` / `OfflineProvider` → TTS.
- **Removed:** `ListenService`, `RecognizerWakeWord`, `WakeWordProvider`. No VAD, no wake-word engine, no SpeechSegmenter, no battery/CPU optimizers.
- **Files** (`app/src/main/java/com/nova/ai/voice/`): `NovaVoiceForegroundService`, `AudioCapture`, `NovaWakeLockManager`, `SpeechProcessingEngine`, `GeminiSpeechEngine`, `VoiceNotificationManager`, `VoicePermissionManager`, `VoiceState` (+ `VoiceBus`), `VoiceCommandDispatcher`, `HeadlessAssistant`.
- **Privacy:** starts only after you switch Background Voice on and grant Microphone + Notifications; persistent notification "Nova AI: Background Voice is active. Microphone is ON." with Pause/Resume/Stop; Android's own mic indicator is untouched; no app-generated beep; no audio saved to disk; audio held in RAM is bounded (one 5 s window plus at most two waiting).
- **Service:** `START_NOT_STICKY`, never restarts itself, never restarts after you turn it off; partial WakeLock only while the mic is open; everything released in `onDestroy`.
- **Name trigger:** Settings → Background → "Only answer when I say Nova". It is a text check on the transcript, not an audio wake-word engine. Off = every recognized sentence is a command.
- **Calls / other apps:** the mic is released during phone/VoIP calls (audio mode check) and capture is paused when Android 10+ silences it for another app; it resumes by itself.
- **Reboot / kill:** Android does not allow mic services to start from boot. After a reboot the "NOVA initialized" notification offers "Resume listening"; after a kill, Settings shows that Background Voice was interrupted.
Limits: speech-to-text goes through Gemini audio input in fixed 5 s clips (no VAD by design), so words can be cut at clip edges and answers arrive a few seconds after you stop talking; free-tier Gemini quota (about 15 requests/min, daily cap) can run out, then speech recognition pauses with a visible message. Headless mode (UI closed) cannot show chat, confirmations, screen vision or scans.

## v2.0 — Jarvis Pack (Settings → Jarvis Pack)
New Gradle dependencies (internet needed for the first build): OkHttp, Vosk (offline speech), JNA. The APK grows by roughly 40 MB.
1. **Gemini Live streaming** (`LiveSpeechEngine`): real-time speech-to-text over WebSocket with `gemini-3.5-transcribe-live`, renewed every 9 minutes (10-minute session limit). Model name is editable.
2. **Offline recognizer** (`OfflineSpeechEngine`, `VoskModelManager`): download the English-India or Hindi model in Jarvis settings. In Auto mode it takes over when Live is down.
3. **Natural voice** (`NeuralTts`): Gemini text-to-speech played with AudioTrack, falls back to Android TTS. Model and voice are editable.
4. **Floating orb** (`FloatingOrb`) and **default assistant** (`NovaVoiceInteractionService`): choose Nova under Settings → Default apps → Digital assistant.
5. **Morning briefing** (`Briefing`) by voice ("good morning") or at a set time while Background Voice runs.
6. **Message replies** (`NovaNotificationListener`): "messages padho", "Rahul ko reply karo ki ...". Sending always asks for confirmation. Only apps allowed in Notifications are used.
7. **Calls** (`CallAnnouncer`): announces the caller; "uthao" / "kaat do" while ringing (Answer calls permission).
8. **Reminders**: location reminders (`LocationReminders`, saved places) and "add event" opens the calendar prefilled.
9. **Media**: volume up/down/mute/max and the existing music commands.
10. **PC control**: `companion/pc_companion.py` now has volume, media keys, shutdown/restart (60 s delay) and a list of apps.
11. **Camera Q&A**: "camera se dekho ..." opens the camera at full resolution, then answers aloud. 12. **Files/PDF**: "pdf padho" opens the picker.
13. **Interpreter** (`Interpreter`): "interpreter mode on Hindi English" translates everything you say; "interpreter band karo" stops it.
14. **Agent mode** (`GeminiAgent`): Gemini function calling with safe tools; never runs anything that needs confirmation.
15. **Proactive** (`ProactiveEngine`): event soon, low battery. 16. **Car mode** (`CarMode`): short answers, messages read aloud, follows your car's Bluetooth name.
Also fixed: a compile error in `NovaNotificationListener.kt` that was in v1.8.

## v2.1 — More Jarvis (Settings → Jarvis Pack)
1. **Custom wake name** (`WakeGateEngine`, `VoiceCommandDispatcher`): set any name (jarvis, max...). Normally Nova answers sentences that contain the name. "Offline wake word" uses the Vosk offline model limited to your name, so nothing goes to Gemini until the name is heard. This is not Porcupine: Porcupine needs a per-name model trained on Picovoice's website and an AccessKey, so it is not bundled.
2. **Smart home** (`SmartHome`): Tasmota, Shelly (gen1/gen2), WLED, TP-Link Kasa on your Wi-Fi; Home Assistant REST (also reaches Tuya/Hue/Zigbee); Tuya Cloud OpenAPI (Access ID + Secret from a free Tuya IoT project); plus the existing webhook. Say "kamre ki light off karo", "sab lights band karo", "bedroom light 40 percent". Native Tuya LAN protocol is not included (local keys, protocol 3.4/3.5 handshake).
3. **Emergency SOS** (`SosEngine`): "help me Nova" -> 10 s countdown -> SMS with a Google Maps link to your contacts, optional call to the first one, location updates every 5 min (6 times) until "cancel". Needs Send SMS, Call and Location permissions. Never dials emergency services.
4. **Tasker** (`TaskerBridge`): Tasker -> Nova with Send Intent `com.nova.ai.action.COMMAND` (extras `command`, `token`, optional `reply_package`); Nova -> Tasker with `com.nova.ai.action.RESULT` and `com.nova.ai.action.EVENT`; "tasker chalao <task>" runs a Tasker task.
5. **Clipboard assistant** (`ClipboardWatcher`, `ClipboardActivity`): Android blocks background clipboard reads, so Nova opens a see-through card (needs Display over other apps) that reads the text while it is on screen and offers Summarize / Translate for long text.
6. **Phone files and offline music** (`FileSearch`, `LocalPlayer`): "mere phone se kal wali PDF dhundho" then "pehli wali kholo"; "offline gaane play karo" plays from the phone with a media session. PDFs/documents need "All files access".
Manifest now allows plain http (usesCleartextTraffic) so local smart-home devices work.

## v2.3 (Part 2) - device alerts, weekly routines, modes
- **Alerts** (Command Center > Device alerts, or say "battery alerts on" / "temperature alerts on"): low, critically low and fully charged; temperature uses battery temperature plus Android's thermal status only. Each alert fires once per crossing. A 15-minute WorkManager check runs only while an alert is on; the Nova screen and Background Voice react immediately.
- **Network**: "network status" / "latency". Latency is three small HTTPS requests, only when asked.
- **Weekly routines**: Command Center > New routine > Weekly on days, or say "editing days tuesday saturday 18:00". They notify you; nothing launches an app by itself.
- **Night mode** (now or scheduled): Nova's own voice volume and theme only. **Editing mode**: pauses Nova's proactive notifications, opens your editing app or Android sound settings. Android doesn't allow apps to switch night light, Do Not Disturb or Wi-Fi directly, so Nova never claims to.
- **Memory**: weekday routines ("I edit videos every Tuesday") are saved as routines; ask "what do I normally do on Tuesday". `MemoryRepository` and `ContextManager` sit on the existing memory engine.

## v2.4 (Part 3) - security, camera vision, gesture, screen
- **Security Mode** (Settings > Security & Voice Lock, or say "security mode on"): accelerometer + optional gyroscope, arming delay, confirmation window, cooldown, alarm sound + spoken warning. Runs as a visible foreground notification only while on, never re-arms after a restart, no camera/mic/GPS. Turning it off can require fingerprint or screen lock. It uses a `specialUse` foreground service (declared in the manifest) so it can keep listening with the screen off.
- **Failed unlock events**: only Nova's own fingerprint/screen-lock prompt is logged; Android does not expose other apps' or the phone's failed unlocks.
- **Camera Vision** (More > Camera Vision, or "camera mein kya hai", "is text ko read karo"): CameraX + ML Kit on the phone. The camera is on only while that screen is open and started, and is released on Stop, leaving the screen, or backgrounding. Nothing is saved or uploaded.
- **Gesture mode**: swipe right = next, swipe left = previous, wave = play/pause, via the media keys. It detects hand *movement*; a still open palm needs a hand-landmark model, which is not bundled.
- **Screen assistant**: "what can I tap" lists tappable controls (Accessibility must be on).

## v2.5 (Part 4) - search, news, developer tools, updates
- **Search/News without Gemini**: with OpenAI selected (or no Gemini key) Nova uses public DuckDuckGo instant answers + Wikipedia, and public RSS for headlines, then summarizes with the active AI. Gemini grounded search is still used when Gemini is active with a key. Weather: Open-Meteo (existing).
- **More > Developer Tools**: crash diagnostics (secrets removed, stored on the phone), AI analysis -> Patch review (text only; you apply fixes yourself), and a safe update flow (HTTPS metadata, SHA-256, same signing key, Android installer).
- **Structured actions (beta)** in Settings > Developer: the AI may answer with a JSON action; Nova validates it and runs it through the normal confirm/lock path.
- See `docs/` for the AndroidIDE build guide, the testing checklist and the manifest review.

---

## Universal Gemini model system (this update)

**One selected model, everywhere.** `ai/model/ModelManager` owns the active model (stored under the existing `model` preference, so upgrades keep your choice). Typed chat, the voice fallback, follow-ups, web search, vision and summaries all read it. Nothing switches models silently: if the selected model is retired (404), Live-only, or cannot answer, Nova says why and asks you to pick another in **Settings → Gemini → Model**.

**Discovery.** `ModelRegistry` reads Google's `models.list` (all pages), turns each model's `supportedGenerationMethods` into capabilities (`ModelClassifier`), caches the list for offline use and refreshes it every 12 h or on demand. Only models Nova can really use are selectable; TTS, image, embedding and transcription models are listed with a reason but cannot be the answering model.

**Voice routing** (`ModelRouter`, `RoutedVoiceEngine`), re-evaluated whenever the microphone starts or the model changes:
| Selected model | Voice path |
|---|---|
| supports Live API (`bidiGenerateContent`) | Native Gemini Live, AUDIO only |
| anything else that answers text | Mic → speech-to-text → **same model** → text-to-speech, keeps listening |
| cannot answer | clear message, no substitution |

**Root cause of "error 1007 … (TEXT)".** Live speech recognition sent `responseModalities: ["TEXT"]` to whatever Live model was configured (default `gemini-3.8-live`). TEXT is only valid for `*-transcribe-live` models; conversational Live models accept AUDIO only. Modality is now derived from the model's capability, one modality per session, and a refusal is detected, explained, remembered and never retried blindly.

**Errors.** `GeminiError` classifies 401/403/404/400/429/5xx, connect vs response timeouts, no network, blocks and empty answers. `RetryPolicy` = exponential back-off with jitter, honours `Retry-After`, hard retry and time limits, never retries permanent errors. Coroutine cancellation is no longer swallowed (it caused stuck "Thinking" and duplicate answers). API keys are sent in a header and redacted from messages.

**Notification:** NOVA AI · Background Voice Active · Microphone: ON · Active Gemini Model · voice path, with Pause/Resume and Stop.


## v3.3-complete
See docs/FINAL_REPORT.md (status by category), docs/VERIFICATION_CHECKLIST.md (device tests), docs/PERFORMANCE_AUDIT.md. Build: `./gradlew assembleDirectDebug`; tests: `./gradlew testDirectDebugUnitTest` and `./gradlew connectedDirectDebugAndroidTest`. Not compiled in the authoring environment: expect a few compile fixes on the first build.


## v3.9-memory
Permanent memory engine (topic lock, language lock, projects and files, Secure Vault, reminders, dashboard, backups). See `docs/MEMORY_ENGINE.md`.
