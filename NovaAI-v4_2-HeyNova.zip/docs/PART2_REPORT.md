# Nova AI v4.2 — Part 2 report: YouTube + browser task engine

Builds on Part 1 (verified taps/typing, real foreground detection). Scope: planner, PlanRunner, YouTube flow,
browser flow, failure classification, tests.

## Build status (honest)
NOT built, NOT run (no Gradle / Kotlin compiler / Android SDK in my sandbox). Checked by source reading only.
Please run `./gradlew :app:testDirectDebugUnitTest` and `./gradlew :app:assembleDirectDebug` and send me any error text.
The element-matching rules (YouTube result rows, watch-page detection, browser result links, address bars) are
heuristics on accessibility labels: they are unit-tested against sample data only and MUST be checked on a real phone.

## Root causes found
1. "Play" commands only ever searched: `"X play karo"` was turned into a search step; nothing opened a result or checked playback.
2. Single-sentence forms ("YouTube par X chalao", "play X on youtube") were not understood by the planner and fell through
   to a URL launch, so nothing was typed or tapped.
3. There was no browser plan at all (no selected browser, no address bar logic, no result reading).
4. The old runner treated "tap accepted" as success, never checked that YouTube/the browser was really in front, and could
   not tell offline / not installed / blocked / field missing apart.
5. The first-step safety check used the app in front at the START (a banking app in front blocked "open YouTube").
6. `device.openApp` could open YouTube Music/Kids (fixed in Part 1) and silently fell back to a URL when YouTube was missing.

## What the new flow does (YouTube)
open YouTube → wait until it is really in front and readable → find search field or icon → tap → wait for a text field →
confirm focus → type (skipped if already typed) → read the field back → press Search → wait for a real screen change →
wait for video rows (not suggestion rows) → open the best matching row → wait for the watch page → check playback
(player controls say Pause, or audio became active and nothing else was playing before) → only then "Playing".
Browser: open the spoken / chosen / default browser → address bar (or start-page search box) → type → verify → submit →
results → read titles or open the first result → verify the address or page changed.

## Failure classification (one cause per message, English + Hinglish)
No internet · app/browser not installed · app didn't come to front (explains the Android background-launch limit and
"Display over other apps") · screen unreadable · search box not found (lists what was visible) · text field didn't open ·
search not submitted · no results · result not found · page not loaded · site unreachable · cookie/consent page
(NOVA does not click it) · playback unconfirmed · video paused.

## Safety kept
No taps on consent/cookie dialogs, no typing in credential fields, content taps still blocked in payment/banking apps,
confirmation flow unchanged, task cancellation stops before the next action.

## Files
New: screen/AppUi.kt, test/screen/AppUiTest.kt, test/planner/TaskPlannerYoutubeBrowserTest.kt
Modified: planner/Plan.kt, planner/TaskPlanner.kt, planner/PlanRunner.kt (rewritten, same public API),
device/DeviceController.kt, security/Prefs.kt (browserPackage), screen/ScreenModels.kt, screen/ScreenActionExecutor.kt,
accessibility config + service (click events removed from the "screen changed" signal).

## Limits / next
- Choosing the browser in the UI comes with the Part 6 dashboard; for now: spoken name, else `Prefs.browserPackage`, else system default.
- Playback of apps other than YouTube is not verified. Browser result titles depend on how the site exposes text.
- If the app's UI language is not English/Hindi, label matching ("Search", "Pause video") may miss: tell me the language.
- Text fields that refuse ACTION_SET_TEXT still need the paste / Shizuku fallback (Part 5).

## Real-device checks (Android 13)
1. "Open YouTube and search for lofi songs": field tapped, text visible, results shown, reply only after results exist.
2. "YouTube par arijit singh songs play karo": a video opens and the reply says Playing only if audio/player confirms.
3. Turn on airplane mode and repeat: reply must say there is no internet (nothing typed).
4. Pause other music first, then run (2): reply must still be honest (audio alone is not accepted as proof).
5. Disable "Display over other apps" for Nova, lock-screen Nova in background: message must explain the launch block.
6. "chrome me best laptops search karo", then "open chrome and search weather and open the first result".
7. Open a Google cookie page: Nova must stop and ask you to accept/decline yourself.
8. While running, say stop/cancel: no further taps happen.
