# Nova AI v4.2 — Part 4 report: file access and permissions

## Build status (honest)
NOT built, NOT run (no Gradle / Kotlin compiler / Android SDK in my sandbox). Source-reviewed only; new tests are pure JVM
and unverified until you run `./gradlew :app:testDirectDebugUnitTest` and `./gradlew :app:assembleDirectDebug`. Send me any error text.
The File Manager core (verified copy/move/rename/zip, DeleteGuard, path rules) was already solid and is unchanged.

## Root causes of "Nova says files are inaccessible although I granted permissions"
1. Voice file search (`FileSearch.hasAccess`) only accepted **All files access**. With photos/videos/music allowed but All files off it
   still refused, with a message that blamed the wrong permission. Documents and media need different permissions.
2. When a search failed (Android refused, provider error) the exception was swallowed and the answer was "no files found",
   indistinguishable from "nothing matches".
3. Offline music (`playSongs`) checked only `READ_MEDIA_AUDIO`, ignoring All files access.
4. `FileIndexer`: a null cursor (permission lost / folder moved) was treated as an empty folder, so re-indexing REPLACED the
   saved index with nothing and reported success. Any unreadable sub-folder silently dropped its files.
5. SAF folders were stored as URI strings and shown as "Tap to browse" with no check that Android still holds the grant;
   a lost grant showed "Empty folder." instead of the truth. The grant request also failed completely when write could not be granted.
6. SAF had no rename/move, so with only a chosen folder (no All files access) those operations were impossible.
7. The delete dialog listed only 5 names ("…and N more"), not the exact selection.

## Fixes
- `FileAccessPolicy` (pure, tested): for each need (photos, videos, audio, documents, browse by path, change files) it reads the REAL state and
  returns Granted, partial, or Denied with the exact missing permission and the fix (open All files settings / request media /
  pick a folder / write permission). English and Hinglish. Also `report()`: one honest row per file permission for the Part 6 dashboard.
- Voice search uses it: media searches work with media permission only, documents say they need All files access (or a chosen folder),
  real errors are reported as errors, "nothing found" only when nothing was found.
- `FileIndexer`: unreadable root = clear error ("permission lost" vs "Android refused") and the OLD INDEX IS KEPT; unreadable
  sub-folders keep their old records and are counted (`IndexReport.skipped`).
- `Saf`: `grantLevel` / `hasGrant` from Android's persisted grants, `persist` falls back to read-only, `listChecked` (null = refused,
  not empty), `rename` (verifies the new name), `move` (Android move, else copy → verify → remove original; a bad copy is deleted and the original
  is never touched), `copyInto` removes a mismatching or partial copy.
- Files screen: each chosen folder shows Permission lost / Read only / Granted, an unreadable folder says so, new Rename… and Move to… buttons.
- Delete dialog lists up to 12 exact names with their folder, then an honest count of the rest.

## Not changed on purpose
Deleting still happens only after a confirmation dialog; DeleteGuard still refuses volumes, standard folders, Android/data and Android/obb;
Nova still never claims access to other apps' private data.

## Limits
- Android 10 has no path access for this app type: documents there need a chosen folder.
- With Shizuku only (no All files access) rename and zip are not available.
- Providers may refuse move/rename (cloud, read-only volumes); the message then says so.
- The Part 6 dashboard will show `FileAccessPolicy.report()` with buttons; the data layer is ready now.

## Real-device checks (Android 13)
1. Allow photos only (deny All files): "find my photos from yesterday" works; "find my PDF files" says All files access is off (not "nothing found").
2. Turn All files access on: PDF search works without photo permission.
3. Add a folder, then revoke it from Android's settings or delete the folder: the Files screen shows "Permission lost", not "Empty folder".
4. Index a project folder, revoke the grant, re-index: error message, old index still searchable.
5. Rename and Move a file inside a chosen folder, and between two chosen folders: results say (verified); check the files.
6. Select 20 files and delete: the dialog shows 12 names and "…and 8 more that are also selected".
7. Try to open Android/data: Nova explains that Android keeps it private.
