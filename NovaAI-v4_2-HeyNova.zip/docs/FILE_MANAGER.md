# File Manager & File Intelligence (v4.2, delivered in 3 parts)

## BUILD STATUS — READ FIRST
Written in an environment with **no Gradle, no Android SDK and no Kotlin compiler**. **Nothing has been compiled or run.**
Brace/paren balance of every new file was checked by script, and the unit-test expectations were traced by hand, but the first
build in AndroidIDE / GitHub Actions may need small fixes. Send the build log and it will be fixed, like the earlier installments.

## The 3 parts
| Part | Zip | What it adds | Status |
|---|---|---|---|
| 1 | `NovaAI-v4_2-files-part1.zip` | Foundation + dashboard: browse, search, recent, categories, storage usage, permissions, history, open | delivered |
| 2 | `NovaAI-v4_2-files-part2.zip` | Operations: copy, move, rename, new folder, organize, ZIP / extract, Sharesheet, delete with confirmation, duplicates, Shizuku-assisted shared-storage ops | delivered |
| 3 | `NovaAI-v4_2-files-part3.zip` | AI File Intelligence: read & preview documents, summaries, project analyzer, Gemini with consent, voice/chat commands (Hinglish), final tests and report | **this zip (final)** |

## Part 1 — what is in it
New package `com.nova.ai.files`:
- `FileModels.kt` — pure Kotlin: `FileKind`, `FileItem`, type detection (PDF, DOC, DOCX, TXT, CSV, XLSX, ZIP, JSON, XML, HTML, JS, KT, JAVA, APK and more), sorting, `PathRules` (volume confinement, Android/data and system blocks, breadcrumbs), `SearchQuery` + `QueryBox` (search box filters `ext:pdf  in:download  days:7  min:5mb  type:images`).
- `StorageVolumes.kt` — Internal Storage and any mounted SD card / USB drive with used / free / total, standard folders (Download, Documents, DCIM, Pictures, Movies, Music…).
- `FileAccess.kt` — Android-version-specific permission rules and a status that never claims more than Android granted (all-files / media / "selected photos only" / chosen folders / Shizuku).
- `FileCatalog.kt` — MediaStore-based lists (Recent, Documents, Images, Videos, Audio, Downloads, APKs, Archives), search by name / extension / folder / date / size, bounded folder-walk fallback, storage usage by category.
- `FileBrowser.kt` — folder browsing by path, only inside the storage volumes; blocked folders give an honest reason, not an empty list.
- `FileOpener.kt` — open in the app Android picks (MediaStore address, or FileProvider for folder-browsed files).
- `FileHistory.kt` — file operation history (private, names/folders only, clearable). Part 1 logs opens and permission results; Part 2 logs every operation.

UI: **Settings → File Manager** (also two new Home shortcuts: 📁 File Manager, 🔎 Find Files). Dashboard with Internal Storage, SD Card, Recent Files, Documents, Images, Videos, Audio, Downloads, APKs, Archives, Search, Storage Usage, History, Browse folders. Tap a file for its details (type, size, modified, location) and an Open button.

Changed existing files (nothing removed): `SettingsScreen.kt` (one page entry), `HomeScreen.kt` (two shortcuts), `res/xml/file_paths.xml` (one `root-path` so folder-browsed files can be opened), `app/build.gradle.kts` (version 4.2-files-part1). **No new manifest permission** is needed in Part 1.

## What Android allows (so the app never over-promises)
- **Android 11+**: browsing arbitrary folders by path needs "All files access" (direct build only; the Play flavor never offers it). Without it, Images / Videos / Audio still work with media permission, and any folder you choose with the folder picker works.
- **Android 14**: "Select photos and videos" gives Nova only those items; the dashboard says so.
- **Android 10**: scoped storage means no path browsing; use media permission or the folder picker.
- **Android 8–9**: the old storage permission is enough to browse.
- **Never accessible**: other apps' private data (`/data/data`, `/data/user`) and, for normal apps, `Android/data` and `Android/obb`. Nova shows that reason and does not pretend.
- Documents / Downloads / APKs / Archives in the category lists depend on the above; the dashboard explains an empty list instead of showing a fake one.

## Spec coverage (updated each part)
| Spec item | Part |
|---|---|
| Browse internal storage, SD card, standard folders | 1 |
| Formats PDF/DOC/DOCX/TXT/CSV/XLSX/ZIP/JSON/XML/HTML/JS/KT/JAVA/APK | 1 (listing & open), 3 (reading; old binary .doc is the one format that can only be explained, not read) |
| Search by name, extension, folder, date | 1 |
| View size, location, type, modified date | 1 |
| Preview documents and media | 1 details + open in viewer; 3 in-app text preview (done) |
| Open files | 1 |
| Copy, move, rename, create folder, organize, ZIP/extract, Sharesheet, delete-with-confirmation, duplicates | 2 (done) |
| Analyze selected documents (Gemini, with consent) | 3 (done) |
| Media permissions, Photo Picker, SAF, MANAGE_EXTERNAL_STORAGE | 1 (uses the existing media/SAF/all-files code and the existing Photo Picker page) |
| Shizuku shared-storage operations | 2 (done) |
| Permission-revocation handling | 1 (status re-read on every resume; lists go empty, never stale) |
| Operation history | 1 (framework + opens), 2 (every operation, done) |
| Dashboard UI | 1 |
| Voice/chat commands, project analyzer | 3 (done) |

## Test checklist for Part 1
1. Install, open Settings → File Manager. Storage cards show real used/free numbers; an SD card appears only if one is mounted.
2. Tap **Allow photos, videos & audio**. On Android 14 choose "Select photos" once: the Access box must say "only the photos and videos you selected".
3. Turn off the permission in Android settings and come back: lists empty out and the Access box updates.
4. Direct build, Android 11+: **Allow all files access…** → Android settings → allow → return. **Browse folders** now opens `Download`, `Documents`, `DCIM`.
5. Open `Android/data`: you must see Android's "keeps other apps' folders private" message, not an empty folder.
6. Search `ext:pdf days:30` and `invoice` with the PDF chip. Open a result; confirm its details dialog (type, size, date, path).
7. Documents → open a PDF; APKs → open an APK (Android's installer must ask for confirmation).
8. Storage Usage shows per-category bars and the "not counted" line.
9. History shows your opens; **Clear history…** empties it and touches no files.
10. Existing features (voice, Gallery, Files & Storage page, Control Center) behave as before.

---

## Part 2 — what is in it
New in `com.nova.ai.files`:
- `FileRules.kt` (pure): `NameRules` (valid names, never-overwrite `name (1).ext`), `ZipRules` (zip-slip guard, entry and size limits), `DeleteGuard` (refuses whole volumes, Download/DCIM/Documents… top-level folders, Android/ and protected places), `OrganizePlanner`, `DuplicateRules` (a selection must keep at least one copy of every group).
- `LocalFs.kt` (pure JVM, tested on temp folders): copy (files and folders, verified by file count and bytes), move (rename, or copy → verify → delete), rename, new folder, delete (verified gone), ZIP (read back and counted), extract (zip-slip and zip-bomb protected, partial output removed on failure), SHA-256, duplicate finder (size first, then fingerprint), bounded and cancellable folder walk.
- `FileOps.kt`: the single entry for every operation: access check → storage-volume check → safety rules → operation → verified message → history. Sharesheet via FileProvider (the user picks the target; Nova uploads nothing). MediaStore delete requests (Android 11+) for media Nova can see but not write by path: Android shows its own approval dialog.
- `ShizukuFiles.kt`: list / copy / move / mkdir / delete one file through Shizuku, only for shared-storage paths. `ShellPolicy.kt` got matching allow-list rules: no spaces, no wildcards, single files, nothing written inside `Android/`, only reading there. Private app data (`/data/data`) is still unreachable and Nova says so.

UI (Settings → File Manager): **Select** mode on every list (Copy, Move, Share, Zip, Delete…), file details dialog with Copy, Move, Share, Rename…, Zip, Extract (for .zip), Delete…; in Browse: **New folder…**, **Paste here** bar (copy/move waits until you open the destination), **Organize this folder**; new tiles **Duplicates** and **Organize** (preview the full plan, then confirm).

Changed existing files: `ShellPolicy.kt` (file rules), `AndroidManifest.xml` (`WRITE_EXTERNAL_STORAGE`, `maxSdkVersion=28`, only for Android 8–9), `FileAccess.kt`, `FileManagerScreen.kt`, `build.gradle.kts` (4.2-files-part2).

### Safety rules in force
- Delete only after a confirmation dialog that lists the items; folders say "with everything inside". No silent or batch delete anywhere. Duplicate deletion refuses a selection that removes every copy.
- Nothing is overwritten: a clash becomes `name (1).ext`.
- Every result is re-checked on disk before it is reported ("verified"), and failures are logged as failures.
- Changing files by path needs All files access (Android 11+), the write permission (Android 8–9) or Shizuku; otherwise Nova says what's missing instead of failing quietly. On Android 10 only media deletes (Android's own dialog) and the folder-picker page work.
- History records every operation (names and folders only).

### Test checklist for Part 2 (direct build)
1. Turn on All files access. In a test folder: **New folder…** → "Test". Open a file → **Copy** → open Test → **Paste here**: the copy appears; the original stays. Repeat with **Move**: the original is gone.
2. Paste the same file into Test again: you get `name (1).ext`, not an overwrite.
3. **Rename…** with `a/b` (must be refused) and with an existing name (refused).
4. **Select** → pick 3 files → **Zip** → a `.zip` appears; open its details → **Extract** → a folder with the same files appears.
5. **Share** a file → Android's sharesheet opens; cancel it.
6. **Delete…** a test file: the dialog lists it; Cancel leaves it; Delete removes it ("verified"). Try deleting `Download` itself: refused.
7. **Duplicates** → Downloads → Scan; **Keep oldest, select the rest** → **Delete selected…**; selecting every copy of a group must be refused.
8. **Organize** → pick a test folder with mixed files → Preview plan → confirm: files land in Documents / Images / …
9. Without All files access: Copy/Move/Zip say what's missing; deleting a photo from Images uses Android's own approval dialog (Android 11+).
10. With Shizuku running: browse `Android/data` (list only), and confirm copying a file out works while writing into `Android/` is refused.
11. History lists every step above; **Clear history…** works.

---

## Part 3 — AI File Intelligence (final part)

### Reading files on the phone (no network)
- `DocReader.kt` (pure JVM, tested on generated fixtures): TXT/MD/LOG, code (KT, JAVA, JS…), CSV/JSON/XML, HTML (scripts/styles removed), **DOCX, ODT, XLSX (first sheet, columns kept), PPTX (slide order), ZIP (listing)**. Binary files are refused instead of shown as garbage. Reads at most 30,000 characters and says when it truncated.
- `FileReader.kt` (Android): **PDF** is rendered page by page with Android's PdfRenderer and read with on-device text recognition (ML Kit, Latin + Devanagari): first 5 pages, may contain OCR mistakes, nothing uploaded. **APK**: package name, version, target SDK, permissions asked, installed or not (read from the file, never installed or uploaded). Password-protected PDFs and scans with no readable text get an honest message.
- Old binary `.doc / .xls / .ppt` cannot be read on the phone; the app says "save as .docx / PDF" instead of guessing.
- `LocalSummary.kt`: offline extractive summary (counts, main words, key sentences). Never invents anything.
- `ProjectAnalyzer.kt`: counts files, folders, languages and lines, detects Android/Gradle, Flutter, Node, Python, Maven, Rust, Go, CMake, websites, lists key files and the biggest files, skips `.git`, `build`, `node_modules` and similar. `findProjects` locates project folders (a few levels deep).

### Gemini, only with consent
Flow: **Read & analyze…** (file details, selection bar, or Browse → Analyze this folder) → everything up to this point is local (preview, read aloud, local summary) → **Ask Gemini about this…** → consent section.
1. Master switch **File Manager → AI file analysis → Allow Gemini document analysis**: OFF by default (`Prefs.fileAnalysisToGemini`).
2. Even when ON, every send shows **the exact text** (scrollable, up to 30,000 characters), says what is *not* sent (file name, location, anything else), has a question box and a **Send once** button. The permission covers that one request.
3. `SensitiveScan` warns when the text looks like it holds a card number (Luhn checked), Aadhaar-like or PAN-like number, a password/PIN/OTP, or an API key/private key, and offers to replace them with `[hidden …]` (on by default). Pattern based, so it can miss things; that is why the full text is shown.
4. Blocked completely in Local-only mode, when offline, without a Gemini key, or with AI disabled. `NovaViewModel.analyzeFileText` re-checks all of this, so no other code path can send document text.
5. **Receipt**: `AnalysisLedger` stores only time, size and "file/project" (never names or contents); shown on the dashboard with a Clear button. `FileHistory` also logs each read and each send.
6. For a project, Gemini gets an outline: the report, top-level names, and the first lines of README, build file and manifest. Never the rest of the source code.

### Voice and chat commands (Hinglish and English)
`FileIntents.kt` (pure, tested) understands:
| Say | Result |
|---|---|
| "Nova, meri PDF file padho" | finds your newest PDF, reads it on the phone (OCR), opens the sheet with Read aloud |
| "Downloads folder mein APK search karo" | search view: folder Download, type APK |
| "Meri latest downloaded file kholo" | opens your newest download in the app Android picks |
| "Is document ka summary banao" | local summary of the last file you opened/read (Gemini only if you approve) |
| "Mere coding project ko analyze karo" | scans for projects, tap one to analyze |
| "Duplicate files search karo" | opens Duplicates and starts the (read-only) scan |
| "Mere documents organize karo" | opens Organize with the plan preview (nothing moves until you confirm) |
Commands only open the right screen with the request filled in. They never delete, move, or send anything by themselves, and they are marked private, so they don't work from the lock screen. Phrases about messages, notifications, weather etc. are not claimed.

Changed existing files in Part 3: `LocalCommandRouter.kt` (one line to register `FileCommands`), `Prefs.kt` (one switch), `NovaModules.kt` (one method that sends text), `NovaViewModel.kt` (one guarded method), `FileManagerScreen.kt`, `build.gradle.kts` (4.2-files-part3). New: `DocReader`, `FileReader`, `ProjectAnalyzer`, `LocalSummary`, `SensitiveScan`, `FileIntents`, `FileCommands`, `AnalysisLedger`, `FileAnalysisUi`, and their tests.

### Test checklist for Part 3
1. Settings → File Manager → **AI file analysis**: switch is OFF. Open a `.txt` → **Read & analyze…**: preview appears, **Read aloud** and **Local summary** work with Gemini off.
2. Tap **Ask Gemini about this…** with the switch off: it says it is off and sends nothing. Turn it on from the sheet, ask again: the exact text is shown, then **Send once**. The answer appears; the dashboard receipt says "Sent to Gemini 1 time".
3. Put `password: hunter2` and a test card `4111 1111 1111 1111` in a text file: the warning lists both; with "Hide them" on, the shown text has `[hidden …]`.
4. Turn on Local-only mode: **Send once** is blocked. Turn off Wi-Fi/data: blocked with a clear message.
5. Open a DOCX, an XLSX and a PPTX; a PDF with text (OCR, check the "first N of M pages" note); an APK (info only; confirm nothing installs). An old `.doc` must explain itself.
6. Browse → open a project folder → **Analyze this folder**; **Code projects** tile → Find projects. Confirm Gemini only sees the outline (consent text).
7. Voice: say each phrase in the table above. Check each one only opens the right screen. Lock the phone and repeat: "Unlock your phone first".
8. History lists reads/sends; **Clear history…** and **Clear this receipt** work.
9. Re-run Parts 1 and 2 checklists, plus Gallery, Files & Storage, Control Center and voice chat: unchanged.

---

## Final status and honesty notes
- **Never compiled or run.** All three parts were written without Gradle, an Android SDK or a Kotlin compiler. Syntax balance was checked by script and every unit-test expectation was traced by hand. Expect a few compile fixes on the first AndroidIDE / CI build; send the log.
- **Unit tests** (JVM): `FileManagerCoreTest`, `FileOpsCoreTest`, `DocReaderTest`, `FileIntelligenceTest`, `ShellPolicyFilesTest` (plus the existing suites). Anything touching Android (PdfRenderer, ML Kit, MediaStore, Shizuku, Sharesheet) is covered only by the manual checklists above.
- **Permissions in the manifest for this feature**: the existing media/storage permissions, `MANAGE_EXTERNAL_STORAGE` (direct build only), and `WRITE_EXTERNAL_STORAGE` with `maxSdkVersion=28`. No new network or install permission.
- **Play Store**: the Play flavor must not offer "All files access" for a general file manager unless Google approves it. The code only reads the flag, so keep the permission out of the Play flavor's manifest.
- **What Android blocks, and Nova says so**: other apps' private data, `Android/data` and `Android/obb` for normal apps (listing only through Shizuku), protected system paths, path browsing on Android 10, anything outside what the user granted.
