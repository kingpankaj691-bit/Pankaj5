# Build notes
- Flavor: `direct` only (full power). Commands: `./gradlew assembleDirectDebug assembleDirectRelease`
- Tests: `./gradlew testDirectDebugUnitTest`
- Licensing (direct only): put `app/src/direct/assets/license_config.json` = `{"url": "https://your-backend/validate"}` (git-ignored). Without it the app reports "licensing not configured" and blocks nothing. The backend receives `{key, deviceId}` and answers `{valid, plan, expiresAt, blocked, message}`.
- Two-way voice: Jarvis page -> Speech recognition -> "Two-way voice". Live model name lives in one constant: `GeminiLiveClient.MODEL`.

## Two-way voice (v2.9)
- The microphone button on Home now starts the two-way Gemini Live session by default (Settings -> Jarvis -> Speech recognition = "Two-way voice"). An old untouched "Auto" setting is moved to it once; "Offline", "5-sec clips" etc. stay as chosen.
- Model: the Live model chosen in Jarvis settings (default `gemini-3.8-live`). `gemini-3.1-flash-live-preview` and `gemini-2.5-flash-native-audio-preview-12-2025` are shut down by Google on 17 Nov 2026.
- Audio: microphone 16 kHz PCM16 (the real AudioRecord rate is sent if the phone cannot open 16 kHz) -> Gemini; Gemini -> 24 kHz PCM16 -> AudioTrack via a queue + writer thread.
- Barge-in is on by default (echo-cancelling VOICE_COMMUNICATION microphone + a level gate). Turn it off in Jarvis settings if a phone echoes.
- Galaxy Orb reduced effects: Settings -> Two-way voice -> "Galaxy Orb: reduced effects" (on by default for low-RAM phones).
- Tests: `./gradlew testDirectDebugUnitTest` (voice state transitions, reconnect policy, error classification, setup message, speaker slicing).

## Nova branding (v2.9)
- Launcher icon: adaptive icon (`mipmap-anydpi-v26`) = Nova emblem on dark navy, plus a themed (monochrome) layer for Android 13+. Source art: `res/drawable-nodpi/nova_logo_*.webp`, `nova_emblem.webp`.
- Splash: Android 12+ system splash (emblem on black, `values-v31/themes.xml`) followed by the in-app `NovaLogoSplash` (orbit logo, once per launch, tap to skip).
- About Nova shows the ring logo; Home shows the emblem + wordmark + tagline.
- Bottom bar: Home | Tools | History (chat) | More. Control, Developer and Settings moved into More; Settings is also the gear at the top-right of Home.
