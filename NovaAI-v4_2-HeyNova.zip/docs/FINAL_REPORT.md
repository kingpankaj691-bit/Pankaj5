# Nova AI v4.2 — FINAL REPORT (Parts 1 to 6)

## 1. Build and test status — read this first
**Nothing was compiled and no test was run.** The sandbox I worked in has Java but no Gradle, no Kotlin compiler, no Android SDK and no network.
What I did instead: read every changed file against the code it touches, cross-checked every changed function signature against all its callers,
ran a bracket-balance check on all 61 changed or new Kotlin files (0 unbalanced), ran the planner / parser regexes
against the test phrases in Python, and wrote 173 new unit tests (pure JVM, no Android classes) that are **unrun**.
There is **no APK**: I cannot build one here. Run on your machine, then send me the first compiler or test error text and I will fix it:

    ./gradlew :app:testDirectDebugUnitTest
    ./gradlew :app:assembleDirectDebug

Heuristics on other apps' screens (YouTube rows, WhatsApp ids, browser result links, address bars) are unit-tested on sample data only and
**must be checked on a real phone**. Nothing in this report is a claim that a feature "works on your phone".

## 2. Root causes found and fixed

### Screen control (Part 1)
1. The "app in front" was set from every window event, so the keyboard or Nova's own overlays became "the app in front". Now read from the live active window.
2. "Accessibility enabled" meant only `instance != null`. Now Settings-enabled, connected, screen readable, master switch and blocked-app are separate facts with their own messages.
3. Taps were reported OK when Android merely accepted them; stale elements were still tapped. Now refreshed first, gestures awaited, and the result says whether the screen really reacted.
4. Typing was reported "typed" without reading the field. Now read back; the older router / Live / reply paths also read back and refuse password / PIN / OTP / card fields.
5. Search submit never checked the result. Now needs a real screen change.
6. Accessibility events were only window-state; nothing could wait for the UI. Config now also reports content, text and focus changes (change signal only, nothing stored).
7. `onServiceConnected` skipped `super`; state not cleared on unbind; null root during transitions made the screen "unreadable".
8. "YouTube" could open YouTube Music/Kids (first label that contains the text). Now exact package first; a missing app is never replaced by a look-alike.
9. Video titles like "How to buy bitcoin" triggered the "sensitive action" prompt; "upi" matched inside unrelated package names.

### YouTube and browser (Part 2)
10. "Play X" only ever searched; no result was opened and playback was never checked. Single-sentence forms ("YouTube par X chalao") were not understood.
11. There was no browser plan at all. Now: spoken / chosen / default browser, address bar, type, submit, results, read titles or open first result, verify the page changed.
12. The old runner could not tell offline / not installed / blocked / field missing apart, and the first safety check used the app in front at the start.
Now each failure names ONE cause (English + Hinglish). Playback is "playing" only if the player UI says so or audio started and nothing else was playing before.

### WhatsApp (Part 3)
13. **The Live tool `message_contact` pressed Send itself (WhatsApp and SMS) with no confirmation** although it said "the user taps Send". Removed: it only prepares the composer.
14. The Live WhatsApp agent's confirmation had no timeout, accepted an instant "yes", never checked the message left the box, and read chats unredacted. Fixed.
15. No WhatsApp plan existed. Now verified flow: contact picked (never guessed between people), chat title proven, draft read back, recipient + exact text shown with an explicit yes, WhatsApp brought back and re-checked after you answer, Send pressed once (never retried), "sent" only when the box is empty AND a new bubble appears. Codes / OTPs hidden; registration screens refused.

### Files (Part 4)
16. Voice file search accepted only "All files access", blamed the wrong permission, and turned errors into "no files found". Now exact missing permission and fix per file kind (photos, videos, audio, documents, path, write); errors reported as errors.
17. `FileIndexer` treated a null cursor as an empty folder and **wiped the saved index** while reporting success. Now unreadable roots abort with the reason and keep the old index; unreadable sub-folders keep their old records.
18. SAF grants were never checked (showed "Empty folder" for a lost grant), failed completely when write could not be granted, and had no rename / move. Now grant level read from Android, read-only fallback, verified rename and move (copy -> verify -> remove, bad copy deleted).
19. Delete dialog showed 5 names; now 12 exact names with folders and an honest count of the rest.

### Shizuku, install, uninstall (Part 5)
20. Two commands at once could orphan each other's bind (8 s stall); "shell connected" did not ping the binder; old shell processes could keep old policy. Fixed; added a real-answer self test and a per-component report.
21. **`REQUEST_DELETE_PACKAGES` was missing** (Android 9+ uninstall screen), there was no uninstall/install route at all, the Uninstall button swallowed errors and could offer Nova itself, and APK opens never checked "install unknown apps". Now: guarded flows through Android's own screens, result verified from the package list, protected apps refused.

### Permissions (Part 6)
22. No single accurate view existed. New **Permission Dashboard** (Settings, first entry): Accessibility, Screen actions switch, Screen capture, Shizuku service / permission / binder-shell connection, All files access, chosen folders, Microphone, Notifications, Internet. Read live; a button only for what is missing; never says "all granted" unless every applicable row is OK.
23. Location counted as missing when only approximate was granted; "Grant" was a silent no-op for permissions Android no longer asks for; already-granted permissions were re-requested; Accessibility looked "Enabled" whenever the object existed. Fixed.

## 3. Files
Modified (35):
- direct/java/com/nova/ai/agent/whatsapp/WhatsAppAgent.kt
- direct/java/com/nova/ai/live/FlavorTools.kt
- main/AndroidManifest.xml
- main/java/com/nova/ai/accessibility/NovaAccessibilityService.kt
- main/java/com/nova/ai/brain/FileIndexer.kt
- main/java/com/nova/ai/commands/LocalCommandRouter.kt
- main/java/com/nova/ai/control/Capabilities.kt
- main/java/com/nova/ai/control/ControlCommands.kt
- main/java/com/nova/ai/control/ControlEngine.kt
- main/java/com/nova/ai/control/ControlOps.kt
- main/java/com/nova/ai/control/ShizukuManager.kt
- main/java/com/nova/ai/device/DeviceController.kt
- main/java/com/nova/ai/files/FileOpener.kt
- main/java/com/nova/ai/jarvis/FileSearch.kt
- main/java/com/nova/ai/jarvis/JarvisCommands.kt
- main/java/com/nova/ai/live/LiveTools.kt
- main/java/com/nova/ai/media/StorageAccess.kt
- main/java/com/nova/ai/permissions/Permissions.kt
- main/java/com/nova/ai/planner/Plan.kt
- main/java/com/nova/ai/planner/PlanRunner.kt
- main/java/com/nova/ai/planner/TaskPlanner.kt
- main/java/com/nova/ai/screen/ActionValidator.kt
- main/java/com/nova/ai/screen/ScreenActionExecutor.kt
- main/java/com/nova/ai/screen/ScreenModels.kt
- main/java/com/nova/ai/security/Prefs.kt
- main/java/com/nova/ai/suite/DeviceMgmt.kt
- main/java/com/nova/ai/suite/ScreenAgent.kt
- main/java/com/nova/ai/suite/ScreenTools.kt
- main/java/com/nova/ai/ui/ControlCenterScreens.kt
- main/java/com/nova/ai/ui/FileManagerScreen.kt
- main/java/com/nova/ai/ui/GalleryPages.kt
- main/java/com/nova/ai/ui/SettingsScreen.kt
- main/java/com/nova/ai/vision/ScreenCaptureManager.kt
- main/res/xml/accessibility_config.xml
- test/java/com/nova/ai/control/OpParserTest.kt

New (33):
- main/java/com/nova/ai/accessibility/A11yStatus.kt
- main/java/com/nova/ai/accessibility/AccessibilitySettings.kt
- main/java/com/nova/ai/control/AppGuard.kt
- main/java/com/nova/ai/control/AppInstaller.kt
- main/java/com/nova/ai/control/ShizukuReport.kt
- main/java/com/nova/ai/files/FileAccessPolicy.kt
- main/java/com/nova/ai/permissions/DashboardProbe.kt
- main/java/com/nova/ai/permissions/PermissionDashboard.kt
- main/java/com/nova/ai/permissions/PermissionMemory.kt
- main/java/com/nova/ai/planner/WhatsAppFlow.kt
- main/java/com/nova/ai/screen/AppNameMatcher.kt
- main/java/com/nova/ai/screen/AppUi.kt
- main/java/com/nova/ai/screen/WhatsAppUi.kt
- main/java/com/nova/ai/ui/PermissionDashboardPage.kt
- test/java/com/nova/ai/accessibility/A11yStatusTest.kt
- test/java/com/nova/ai/accessibility/EnabledServiceParserTest.kt
- test/java/com/nova/ai/accessibility/TextVerifyTest.kt
- test/java/com/nova/ai/brain/IndexSafetyTest.kt
- test/java/com/nova/ai/control/AppGuardTest.kt
- test/java/com/nova/ai/control/ShizukuReportTest.kt
- test/java/com/nova/ai/files/FileAccessPolicyTest.kt
- test/java/com/nova/ai/permissions/PermissionDashboardTest.kt
- test/java/com/nova/ai/planner/TaskPlannerWhatsAppTest.kt
- test/java/com/nova/ai/planner/TaskPlannerYoutubeBrowserTest.kt
- test/java/com/nova/ai/screen/ActionValidatorTest.kt
- test/java/com/nova/ai/screen/AppNameMatcherTest.kt
- test/java/com/nova/ai/screen/AppUiTest.kt
- test/java/com/nova/ai/screen/WhatsAppUiTest.kt
- docs/PART1_REPORT.md
- docs/PART2_REPORT.md
- docs/PART3_REPORT.md
- docs/PART4_REPORT.md
- docs/PART5_REPORT.md

Gradle files were not changed (no new dependencies). Package name, database, voice system and existing features are untouched.

## 4. Automated tests added (unrun)
Accessibility state and enabled-service parsing, text read-back matching, safety rules (blocked apps, credential fields, risky words), app-name matching,
YouTube / browser / WhatsApp screen matching, send / playback verdicts, failure messages, planner parsing (YouTube, browser, WhatsApp), file permission policy,
index safety, app / APK guards and picking, uninstall / install parsing, Shizuku report and self-test, permission dashboard.
Not covered by unit tests (need a phone): real taps / gestures / typing, window events, MediaStore, Android's installer / uninstall screens, Shizuku binding, SAF providers.

## 5. Android limitations that remain (by design, not bugs)
- Android always shows its own confirmation for install / uninstall, system dialogs, runtime permissions. Nova never automates them.
- Banking, payment, password and authentication screens are refused; passwords, PINs and OTPs are never typed or read.
- Apps that hide their UI from accessibility (some games, Flutter / WebView / secure screens) can't be read; Nova then says so.
- Android/data and Android/obb of other apps stay private. Android 10 gives no path access (use a chosen folder). Play-store builds have no All files access.
- Android 14+ asks screen-capture approval every time; background activity launches can be blocked (Nova explains and points to "Display over other apps").
- Without All files access Nova can't list non-media files by voice or find APKs. With Shizuku only, rename and zip are unavailable.
- WhatsApp view ids change between versions; contact names that look identical need your choice.
- Labels such as "Search" and "Pause video" are matched in English and Hindi; other UI languages may miss.
- The confirmation is shown in Nova; answering there moves WhatsApp to the background (Nova brings it back and re-checks before sending).

## 6. Real-device checklist (Android 13) — run top to bottom, tick each
Setup: install the debug build; grant Accessibility, mic, notifications; for files test once with All files ON and once OFF; have YouTube, Chrome and WhatsApp.
A. Dashboard: open Settings > Permission Dashboard. Turn Accessibility off: row turns red with the fix button. Force-stop Nova with the toggle ON: it says "enabled but not connected". Revoke the mic permanently (deny twice): button says Open app settings.
B. Foreground: open YouTube, show the keyboard, show Nova's orb: the dashboard / replies still name YouTube.
C. YouTube: "Open YouTube and search for lofi songs" (text visible before submit, results before reply). "YouTube par arijit singh songs play karo": reply says Playing only with real playback. Airplane mode: reply says no internet and types nothing. Other music playing first: reply still honest.
D. Browser: "chrome me best laptops search karo"; "open chrome and search weather and open the first result"; a cookie page: Nova stops and tells you to decide.
E. WhatsApp: "WhatsApp par <contact> ko hello bhejo": stops at recipient + text; "no" sends nothing and clears the draft; "yes" sends once and replies Sent only after the bubble appears. Same first name twice: it asks. Live voice "message <contact> hello": composer opens, nothing sent. Chat with a "WhatsApp code": shows [hidden].
F. Files: photos-only permission: photo search works, PDF search says All files is off. All files ON: PDF search works. Add a folder, revoke it in Android: "Permission lost", not "Empty". Rename / Move in a chosen folder: results say verified. Delete 20 files: 12 names + "and 8 more". Index a folder, revoke, re-index: error, old index kept.
G. Install / uninstall: "uninstall <user app>": confirmation, Android screen, "uninstalled (checked)"; cancel in Android: "still installed". "uninstall nova ai / chrome / shizuku / your banking app": refused. "install apk": allow-source page when off; with it on: confirmation, Android installer, "installed (checked)".
H. Shizuku: stop it: rows show the fix; start, grant, run the self test: right SDK number. Two commands at once: both finish.
I. Cancel a running screen task: no further taps happen.

## 7. What to do next
1. Run the two Gradle commands above and send me the first error.
2. Do checklist sections A to I on the phone and tell me which items fail; each failure points at one named heuristic, so fixes will be small.
