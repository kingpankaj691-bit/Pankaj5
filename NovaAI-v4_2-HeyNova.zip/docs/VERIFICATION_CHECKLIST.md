# Feature-by-feature verification (Samsung Galaxy A12, Android 13) — tick each after testing

1. Screen capture permission: Screen Assistant → start Screen Vision → system dialog → notification shows capture; stop works.
2. OCR: open an image with text → "extract text" → sheet shows the text; Copy works.
3. Image text extraction: same with a photo; unselectable text in a video frame (Screen Vision on).
4. Translation: "is page ko Hindi mein translate karo" → translated text; try Hinglish source.
5. Active app identification: Control Center §1 shows the package in front; open WhatsApp/Chrome and re-check.
6. Accessibility clicking: "khud karo Settings kholo" → opens Settings (approval screen first).
7. Scrolling/gestures: agent scrolls a long list; "select all" in a text box; "copy this text" copies selection.
8. Cross-app workflows: YouTube prep (preview → Open & fill only), then Fill & upload with Private; Instagram Reel caption; share latest video to WhatsApp to a test contact.
9. Floating orb: show orb; tap, long-press menu, double-tap action, drag snaps; colours change; green dot goes grey in airplane mode.
10. Bottom sheet: appears over another app; ✕ closes; Copy/Share work.
11. Wake-word detection: set wake name; say it with screen off (Control Center §5).
12. Background voice: leave running 30 min; if killed, Security Activity logs "service-killed" and a notification appears.
13. Gemini Live: two-way voice works and can be interrupted.
14. Universal voice fallback: turn Wi-Fi off briefly → falls back/reports error and reconnects.
15. Audio ducking: play music; speak to Nova and let her answer → music lowers then recovers; switches in §6 turn each part off.
16. Termux: grant permission + allow-external-apps; run `git status` (approve); destructive command refused.
17. GitHub workflow: save token; Pick repository/workflow; Run workflow (confirm); notification when finished; Download latest APK → SHA-256 shown → Install prompt.
18. Log analysis: paste a Gradle error → finding; Nova's own logcat; Explain with AI.
19. Boot receiver: restart phone → Security Activity shows "Phone restarted"; background voice resume notification if enabled.
20. Privacy controls: Dashboard rows match Android settings; revoke microphone → Security Activity + notification.
21. Service recovery: swipe Nova away / force-stop → next start logs "service-killed".
22. Low-memory performance: open 10+ apps, run Live OCR for 5 min → no crash; under memory pressure Live OCR stops itself (trim-memory) and sheet closes.
23. Asset manager: import image/script/XML; preview; copy; share; export; drag in split-screen; recent list.
24. Device Management: inventory search; restrict an app (agent refuses it); pin screen; (optional) Device Owner → kiosk → Exit kiosk → Release Device Owner.
25. Retention: set 7 days; confirm old history items disappear after the next maintenance run.
