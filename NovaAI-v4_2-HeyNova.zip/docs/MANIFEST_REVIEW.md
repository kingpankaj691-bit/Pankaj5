# Manifest review (nothing was removed without asking)

Your master spec says: add only permissions that features really need. These existed before Part 1; here is what the code actually does with them.

| Permission | Used by | Suggestion |
|---|---|---|
| READ_SMS | declared in Permissions.kt only; no code reads SMS | **Remove** (safe) |
| MANAGE_EXTERNAL_STORAGE | FileSearch (find files anywhere) | Remove if you don't need "find my file"; or keep (Play restricts it) |
| SYSTEM_ALERT_WINDOW | FloatingOrb (floating button) | Remove with the orb, otherwise keep |
| SEND_SMS, CALL_PHONE | SOS feature | Keep only if you want SOS |
| ANSWER_PHONE_CALLS, READ_PHONE_STATE, READ_CALL_LOG | call announcer / SOS | Keep only if you use the call announcer |
| READ_CONTACTS, READ_CALENDAR | people, reminders, device scan | Keep |
| FOREGROUND_SERVICE_LOCATION, ACCESS_*_LOCATION | weather by location, SOS | Keep or drop with those |
| READ_MEDIA_*, READ_EXTERNAL_STORAGE | file/photo tools | Keep |
| `usesCleartextTraffic="true"` | smart-home devices on your Wi-Fi (Tasmota, Shelly, WLED, Home Assistant) use plain http | Keep if you use them; otherwise set to false |

Added by Parts 3 and 4: FOREGROUND_SERVICE_SPECIAL_USE (Security Mode), REQUEST_INSTALL_PACKAGES (update installer), camera/accelerometer `uses-feature` marked not required.
Tell me which ones to remove and I'll do it.
