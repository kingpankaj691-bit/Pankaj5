# NOVA Memory Engine (v3.9-memory)

A permanent, local, model-independent memory for Nova. It lives in the new package `com.nova.ai.brain` and its own database
`nova_brain.db`. The older `nova.db` memory and every existing feature are untouched; old memories are imported once.

## Status legend
- **Written, not yet compiled or run.** v3.9 was written without a Kotlin compiler or network, so nothing below has been built or executed
  yet. Build in AndroidIDE first (`./gradlew :app:assembleDebug`), then run `./gradlew :app:testDebugUnitTest`.
- **Needs a phone**: behaviour that only exists on a device (Keystore, biometrics, alarms, folder picker, Live voice).

## Modules (specification module -> code)
| # | Module | Code |
|---|--------|------|
| 1 | Long-term memory, 17 categories | `BrainModels.kt`, `MemoryService.kt`, `MemoryExtractor.kt`, `SqlBrainStore.kt` |
| 2, 3 | Conversation continuity, topic lock and recovery | `TopicEngine.kt` (+ `BrainIntents.kt` for the spoken commands) |
| 4 | Language stability | `LanguageStabilizer.kt` (uses the existing `LanguageDetector`) |
| 5 | Personal Intelligence Profile | `ProfileService` in `MemoryService.kt` |
| 6 | Project and file memory | `FileIndexer.kt` (SAF), `ProjectFiles`, projects in `MemoryService` |
| 7 | Secure Personal Vault | `VaultCrypto.kt`, `KeystoreKeys.kt`, `SecureVault` |
| 8 | Retrieval and smart recall | `Retrieval.kt`, `Txt.kt` |
| 9 | Reminders and unfinished topics | `Reminders.kt`, pending tasks in `MemoryService`/`Brain` |
| 10 | Dashboard | `ui/BrainScreen.kt` (More > Memory Dashboard, and a button in Settings > Memory) |
| 11 | Model integration | `ContextBuilder.kt`, `Brain.contextFor/liveContext/languageInstruction` |
| 12 | Voice continuity | `Brain.liveContext/recapIfRecent/observeVoiceUser`, edits in `GeminiLiveDuplexEngine`, `PersonalityPromptBuilder`, `LiveTools` |
| 13 | Reliability | `SqlBrainStore` migrations, WAL, transactions, integrity check; `BackupManager.kt`; snapshots in `Brain` |
| 14 | Tests | `src/test/.../brain/BrainCoreTest.kt`, `src/androidTest/.../brain/BrainInstrumentedTest.kt` |

## How a message flows
1. `Brain.process(text)` is called first (chat and background voice). A pending yes/no or choice is resolved; memory commands
   ("ise yaad rakhna", "meri memory mein kya save hai", "hum kya bana rahe the" ...) answer locally; otherwise language, topic and
   memory are updated and the message goes on to the AI as before.
2. The system prompt gets `Brain.languageInstruction` (the locked language) and `Brain.contextFor` (topic, profile, relevant memories,
   project and pending items, within a character budget for the selected model). The old `memory.promptContext()` is used only when the
   new engine is switched off.
3. Every reply is passed to `Brain.onAssistantTurn` so open questions and the checkpoint stay current.
4. Live voice: transcripts are joined per turn and sent to the same engine; each (re)connection rebuilds the context from the database.
   Live also has three tools: `save_memory`, `recall_memory`, `get_pending_tasks`.

## Rules the code enforces
- Passwords, PINs, OTPs, card numbers, keys and IDs are never written to normal memory (`MemoryExtractor.isBlocked`).
- Personal contact, health, money and similar details are saved only after a yes (switchable); voice conversations park them in the dashboard.
- The vault is never read by the context builder, the tools, exports without a passphrase, logs or notifications.
- Topic changes only on an explicit request or a clearly unrelated question; short or incomplete sentences and references like "ye/usmein"
  stay in the topic; uncertain cases tell the model to ask.
- Language changes only on an explicit request or after several clear turns in another language (Hinglish -> English needs 4); one word never counts.
- A task is "done" only when the user says so or taps Done. Reminders are never invented.
- Nothing is deleted automatically except the conversation log, which keeps the newest 3000 messages.

## Honest limits
- Semantic search is a local hashed n-gram vector plus synonym lists, not a neural embedding model.
- Language detection is the existing on-device heuristic; "multiple signals" means detector confidence, word count and consecutive turns
  (and Live transcripts), not several speech engines.
- Live voice cannot receive a new system prompt mid-session, so per-request retrieval there is done by the `recall_memory` tool and by
  rebuilding the context at each reconnect.
- Alarms are inexact (Android may deliver a few minutes late). Folder access works only for folders the user picked.
- Vault keys are Keystore-backed but not tied to biometrics; the screen asks for fingerprint / screen lock before it opens the vault. If the
  phone's lock screen is removed or the app is cleared, vault records can become unreadable; keep an encrypted backup including the vault.
- Automatic snapshots live inside the app and do not survive uninstall; exported backups do.
- Hindi replies from local commands are written in Roman letters (Hinglish).
