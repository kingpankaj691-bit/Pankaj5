# Nova AI v4.2 — Part 1 report: screen-control foundation

Scope of Part 1: Accessibility service, state detection, ScreenActionExecutor, ActionValidator, app launching (right app),
and the tests for those. Parts 2-6 (YouTube/browser plan engine, WhatsApp, files, Shizuku + install/uninstall,
dashboard UI + final checklist) build on this.

## Build status (honest)
NOT built and NOT run. This sandbox has Java 21 but no Gradle, no Kotlin compiler and no Android SDK, and no network.
Everything below is verified only by source reading and a bracket-balance check. Run on your machine:

    ./gradlew :app:testDirectDebugUnitTest
    ./gradlew :app:assembleDirectDebug

and send me any compiler error text; I will fix it in the next part.

## Bugs found and fixed
1. Foreground app was wrong. `foregroundPackage` was set from every window-state event, so the keyboard or one of
   NOVA's own overlays (orb, sheets) became "the app in front". Every "is YouTube in front" check and the
   payment-app block then used the wrong package. Now `activePackage()` reads the live active window, ignores the
   keyboard / systemui, and window events from non-application windows are discarded.
2. "Enabled" meant only `instance != null`. Added `A11yStatus` (enabled in Settings, connected, screen readable,
   master switch, foreground, blocked app) with separate explanations, and `AccessibilitySettings.status()`.
3. Taps were reported OK when Android merely accepted them, and the gesture fallback never waited for completion.
   `tapElementDetailed` refreshes the node first (STALE = nothing tapped), clicks the node or runs a gesture it waits on.
   `ActionResult.changed` now says whether the screen really reacted.
4. Typing was reported "typed" without reading the field. `typeText` now re-reads the field (fresh node, then focused
   field) and only succeeds when the text is really there; otherwise it says what the field shows.
5. Search submit never checked the result. `submit()` waits for a real screen change; the Search-button fallback also
   checks that the screen changed.
6. Accessibility events were only `typeWindowStateChanged`, so nothing could wait for the UI. Config now also reports
   content/text/focus/click events (used only as a change counter, nothing is stored); notificationTimeout 100 ms.
7. `onServiceConnected` did not call `super`; state was not cleared on unbind. Fixed.
8. Null `rootInActiveWindow` during transitions made the screen "unreadable". Falls back to the top application window.
9. Wrong app opened: "YouTube" could launch YouTube Music/Kids (first label that contains the text). New
   `AppNameMatcher`: well-known names map to exact packages, then exact > whole-word > prefix. If YouTube is missing
   it does not guess a lookalike.
10. Video/result titles like "How to buy bitcoin" triggered the "sensitive action" confirmation. Content taps use
    `forContent` / `tapContent`; real controls still use the risky-word check.
11. Typing guard: refuses fields whose label/id means password, PIN, OTP, CVV, card number (postal "PIN code" is allowed).
12. "upi" matched inside unrelated package names; it now matches only as a whole dot-separated word.
13. `scrollSmart` decided by comparing message text; now uses `ActionResult.blocked`.

## Files changed
Modified: accessibility/NovaAccessibilityService.kt, screen/ActionValidator.kt, screen/ScreenActionExecutor.kt,
screen/ScreenModels.kt, device/DeviceController.kt (openApp), planner/PlanRunner.kt (content tap, activePackage),
res/xml/accessibility_config.xml, and `foregroundPackage` -> `activePackage()` reads in ScreenAgent, ScreenTools,
LocalCommandRouter, ScreenCaptureManager.
New: accessibility/A11yStatus.kt, accessibility/AccessibilitySettings.kt, screen/AppNameMatcher.kt.
New tests: A11yStatusTest, EnabledServiceParserTest, TextVerifyTest, ActionValidatorTest, AppNameMatcherTest.

## Known limits after Part 1 (handled in later parts)
- PlanRunner still uses the old step logic: no YouTube/browser verification yet, no "playing" check (Part 2).
- Executor calls that touch Android (node refresh, gestures, typing read-back) have no JVM tests; they need the
  real-device checklist.
- `ACTION_SET_TEXT` is not accepted by every field; a paste fallback and Shizuku key events come in Parts 2 and 5.
- Apps that expose no accessibility nodes (games, some Flutter/WebView screens) still need the screenshot fallback.

## Real-device checks for Part 1 (Android 13)
1. Settings > Accessibility: turn NOVA off, ask "tap search" -> must say the service is off. Turn on -> ready.
2. Force-stop Nova while the toggle stays ON -> message must say "enabled but not connected".
3. Open YouTube, open the keyboard, check the in-front app is still YouTube (not the keyboard).
4. Show Nova's orb over YouTube; in-front app must stay YouTube.
5. "Open YouTube" with YouTube Music installed -> YouTube opens, not Music.
6. Type "test" into YouTube search: result says typed only after the text is visible; try a password field -> refused.
7. Open a banking/UPI app -> every action refused.
