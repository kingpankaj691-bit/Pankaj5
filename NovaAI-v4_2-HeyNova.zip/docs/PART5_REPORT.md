# Nova AI v4.2 — Part 5 report: Shizuku, install and uninstall

## Build status (honest)
NOT built, NOT run (no Gradle / Kotlin compiler / Android SDK in my sandbox). Source-reviewed only; the new parser regexes were
also run in Python against the test phrases. Run `./gradlew :app:testDirectDebugUnitTest` and `./gradlew :app:assembleDirectDebug`
and send me any error text. The manifest fix for uninstall follows Android's documented rule for apps targeting API 28+;
I have not been able to reproduce the old failure on a phone.

## Shizuku audit
The existing Shizuku layer is sound: ShizukuProvider and API_V23 permission are declared, AIDL is on, status is read from the system
(installed / running / version / permission / bound), every command goes through ShellPolicy in the app AND again inside the shell
process, and results are never invented. Found and fixed:
1. Two commands at once could both rebind the shell service; the second replaced the first's pending result, so one waited 8 s and failed. Now serialized with a lock.
2. "Shell service connected" was `service != null`; now it pings the binder, so a dead service is not shown as connected.
3. User-service version bumped (1 -> 2) so a Shizuku shell process still running old ShellPolicy / service code is replaced.
4. No way to prove the whole chain works: `ShizukuManager.selfTest()` now runs a real command and checks the ANSWER (SDK number), not just "no crash".
5. New `ShizukuReport`: one honest row per component (app installed, service running/binder, version, Nova permission, shell service) with the
   right fix for each (install, open Shizuku, request permission, update, reconnect) and a note that Shizuku permission is NOT Accessibility or All files access.
ShellPolicy is unchanged (still: no pm install/uninstall, no free-form shell, protected packages never force-stopped).

## Why "Nova can't uninstall apps"
1. `REQUEST_DELETE_PACKAGES` was missing. Apps targeting Android 9+ need it for Android's uninstall screen (target here is 34). Added.
2. There was no voice/command route for uninstall or install at all, so the request fell to the AI model, which said it can't.
3. The Uninstall button swallowed every error, did no checks, and could offer Nova itself and security apps.
4. Opening an APK from the file manager never checked "install unknown apps", said Android would ask, and could not tell the user why nothing happened.

## What exists now
- Voice: "uninstall WhatsApp", "uninstall the app Candy Crush", "telegram ko uninstall karo", "install apk", "install apk whatsapp", "apk install karo".
  Questions like "how do I uninstall apps" are not treated as commands. Plain "install whatsapp" is left to other handlers.
- Uninstall: find the one matching app (never guess between several) -> refuse Nova itself, system apps, Shizuku/Termux/Play services/other protected packages
  and banking/payment/password apps -> ask you (name, package, "data will be deleted") -> open ANDROID'S OWN uninstall screen -> wait up to 45 s and check the package
  is really gone. If it is still there: "confirm it there (or it was cancelled)". Nothing is ever uninstalled silently.
- Install: finds APKs through MediaStore (needs All files access; otherwise says exactly that) -> reads the APK (package, label, version) -> refuses Nova itself and
  protected packages -> checks "Allow from this source" (opens that Android page if off) -> asks you -> opens ANDROID'S OWN installer -> waits up to 2 minutes and
  checks the package now has the new version. Already-installed same/newer version is reported without opening anything.
- File manager APK open and the Control Center Uninstall button use the same checks and give real reasons.
- Capabilities page now shows real install / uninstall state instead of a hard-coded "never".

## Limits
- Android always shows its own confirmation. Nova never taps it and never could; it only watches the result.
- Without All files access Nova cannot list APKs by voice; open the APK from the File Manager or pick a folder.
- A cancelled install/uninstall looks like "still not done" after the wait; Nova says so, it cannot tell cancel from slow.
- Uninstalling apps with Shizuku (silently) is deliberately not offered.

## Real-device checks (Android 13)
1. "uninstall <some user app>": confirmation in Nova, then Android's uninstall screen; confirm -> Nova replies "uninstalled (checked)". Cancel in Android -> Nova says still installed.
2. "uninstall nova ai", "uninstall chrome", "uninstall shizuku", your banking app: all refused with the reason, no Android screen opens.
3. "uninstall candy" with two Candy apps installed: Nova lists them and asks for the full name.
4. Turn off "Allow from this source" for Nova, say "install apk": Nova opens that page. Turn it on, repeat: confirmation, Android installer, "installed (checked)".
5. Put an APK of an already-installed newer version in Downloads: Nova says already installed.
6. Stop Shizuku, open Nova's Shizuku page: rows show "service not running" with the open-Shizuku fix; start it, grant, run the self-test: it must report the right SDK number.
7. Fire two Shizuku commands at once (e.g. "brightness 40 percent" and "wifi off" quickly): both complete, no 8-second stall.
