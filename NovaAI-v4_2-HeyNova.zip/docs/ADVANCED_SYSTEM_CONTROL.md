# Advanced System Control (v4.0-control)

## BUILD STATUS — READ FIRST
This upgrade was written in an environment with **no Gradle, no Android SDK, no Kotlin compiler and no network**.
**Nothing has been compiled. No unit test, instrumented test or APK build has been run.** Brace/paren balance of the new files was
checked mechanically, and the new test files were desk-checked by hand against the code, nothing more.
Before shipping: run `./gradlew :app:testDirectDebugUnitTest :app:assembleDirectDebug` and fix whatever the compiler reports.
The Shizuku dependency coordinates (`dev.rikka.shizuku:api|provider:13.1.5`) and the `rikka.shizuku.*` API usage were written from
memory of the official docs and could not be resolved here.

## What was added (all new code lives in `com.nova.ai.control`, plus small hooks)
| Piece | File |
|---|---|
| Shizuku status/permission/binder/user-service/reconnect | `ShizukuManager.kt`, `ShellUserService.kt`, `aidl/.../IShellService.aidl` |
| Secure command manager (allow-list, range checks, no shell operators; re-checked inside the Shizuku process) | `ShellPolicy.kt` |
| Unified control engine: check state → pick method (Android API → Shizuku → official Settings screen) → run → read back → retry → honest status | `ControlEngine.kt` |
| Hindi / Hinglish / English command understanding | `ControlOps.kt` (`OpParser`) |
| Task history + execution log (persisted, no screen content) | `TaskHistory.kt` |
| Live capability matrix (supported / unsupported on this phone now) | `Capabilities.kt` |
| Router hook + chat/TTS reporting + confirmations | `ControlCommands.kt`, `ControlBus`, 6 lines in `NovaViewModel`, 2 in `LocalCommandRouter` |
| Settings → Advanced System Control, Settings → Shizuku | `ui/AdvancedControlPages.kt`, 2 pages registered in `SettingsScreen.kt` |
| Planned-module interfaces (labelled Planned/Partly available, never faked) | `PlannedModules.kt` |
| Tests | `test/.../control/ShellPolicyTest, OpParserTest, TaskLogTest` |

Manifest/Gradle: Shizuku `api` + `provider`, `ShizukuProvider`, `<queries>` for the Shizuku package, `WRITE_SETTINGS` (optional, user-granted),
Shizuku API permission, `aidl = true`. Package, app name, DB schemas and prefs are unchanged. versionName 3.9-memory → 4.0-control.

## Already existed and was reused, not rewritten
Task planner / PlanRunner (open app, search, tap, long-press, scroll, swipe, type, back/home/recents), ScreenActionExecutor, accessibility service,
UI element resolver + vision, MediaProjection Screen Vision, Termux bridge, notification listener, Gemini agent/live tools, memory, personality, TTS.
Because the Gemini agent already calls the router for phone commands, the new operations are reachable from Gemini function calls as well.

## Behaviour you can rely on
* Verified = state was read back and matches. Otherwise the status is UNVERIFIED / FAILED / NEEDS_USER / UNSUPPORTED / DENIED and the reply says so.
* Without Shizuku: brightness / timeout / rotation need "Modify system settings"; Wi-Fi and Bluetooth-off open the official panel; force-stop opens App info.
* Existing Wi-Fi/Bluetooth commands are only taken over when Shizuku is READY; otherwise the old handlers run unchanged.
* Force-stop always asks first and refuses system/security/Nova/Shizuku/Termux packages; its result is reported UNVERIFIED because Android hides other apps' run state.
* Never done silently: install/uninstall, clear data, factory reset, security settings, payments, sending messages.

## Not done / honest gaps
* Not compiled, not tested (see top).
* The multi-step planner was **not** rewritten into the requested Task Planner/Executor/Observer/Verifier/Retry/Recovery class set; the existing `planner` package covers planning and stop-on-failure, and the new engine adds verify/retry/history for system operations. Screen-plan steps (e.g. YouTube search + play) still do not have independent playback verification.
* Per-permission "explain before asking" flows for every permission were not rebuilt; the existing Permissions page and the new Shizuku page explain theirs.
* Browser automation is Planned only. Other future modules are interface-only.
* No instrumented/device tests; Shizuku behaviour on specific OEM ROMs is unverified.

---
# Photo, Video & Storage Access module (added after the report above)

**Same build status: written but NOT compiled or run** (no Gradle/SDK/network here). `MediaAccessTest` was desk-checked only.

| Requirement | Where |
|---|---|
| READ_MEDIA_IMAGES / VIDEO (13+), READ_MEDIA_VISUAL_USER_SELECTED (14+) in ONE request so Android can offer "Select photos" | `media/MediaAccess.kt`, manifest |
| Honest access level (Full / Photos only / Videos only / Selected only / None) and real counts of what is visible | `MediaAccess.level`, Settings → Photos & Videos |
| Photo Picker (no permission needed), results usable for open / analyze / copy | `GalleryPages.kt` (`PickMultipleVisualMedia`) |
| MediaStore browsing with paging, albums, photo/video filter; empty (never invented) when no access | `media/MediaRepository.kt` |
| Thumbnails (system `loadThumbnail`, LRU-cached) in a grid | `MediaRepository.thumbnail`, `GalleryScreen` |
| Gemini analysis only after select → Analyze → per-use confirmation; master switch OFF by default; blocked in Local-only / offline / no key | `GalleryScreen` dialog, `NovaViewModel.analyzePhotos` |
| What is sent: resized JPEG (EXIF/GPS dropped; video = 1 middle frame), max 4, plus the question. Upload log (counts/times only) | `media/PhotoPrivacy.kt` |
| Open / copy to album / save copy via SAF | `media/MediaActions.kt` |
| Organize (move) and delete / trash with Android's own approval dialog, then verified against MediaStore | `MediaActions` (`createWriteRequest/TrashRequest/DeleteRequest`) |
| SAF folders (persisted, removable), browse / open / new folder / copy / delete; single-file picker | `media/StorageAccess.kt` (`Saf`), `FilesPage` |
| Optional MANAGE_EXTERNAL_STORAGE: only direct (non-Play) build, Android 11+, via Android's settings page; list + single-file delete | `AllFiles`, `FilesPage` |
| Chat/voice entry ("nova gallery", "photos dikhao", "photo analyze karo", "photo picker") | `media/MediaCommands.kt` (existing "open gallery" still opens the phone's Gallery app) |

Limits stated honestly in the UI: moving/trash need Android 11+; on Android 10 delete works only with Android's per-item approval; Android 9 and older cannot delete or move
other apps' media without the legacy write permission, so Nova says so. MediaStore column support on Android 8-9 (width/height/duration/bucket) is untested and the list may come back empty there.
Photos shown from the Photo Picker are temporary grants and cannot be deleted by Nova. All-files browsing cannot open files (no FileProvider paths) - it lists and deletes only.
