# Nova AI testing checklist

Tick each line on a real phone. "Expect" is what should happen.

**Launch & AI**
- [ ] App launch: opens, no crash, chat visible.
- [ ] Gemini: select Gemini, add key, Test connection -> "Connected". Chat answers.
- [ ] OpenAI: select OpenAI, add key + model, Test connection -> "Connected". Chat answers; Gemini key not needed for chat.
- [ ] API configuration: key hidden by default; Clear key removes it; wrong key -> clear error text, no crash.
- [ ] Conversation: follow-up questions use context; Hindi/Hinglish reply style follows you.
- [ ] Structured actions (Settings > Developer, beta): say "turn on security mode" -> Nova asks to confirm; nothing runs without it.

**Memory**
- [ ] "remember that I edit videos every Tuesday" -> saved as a routine; restart app; "what do I normally do on Tuesday" -> answers from memory.
- [ ] Settings > Memory: view, edit, delete, forget, turn off, clear all.

**Voice**
- [ ] Background Voice on: persistent notification; speak a phrase -> answer comes right after you stop talking (no fixed 5 s wait).
- [ ] Silence and room noise send nothing; Nova's own voice isn't transcribed.
- [ ] Screen off: voice still works; mic indicator visible while listening.
- [ ] Foreground service: notification stays; Stop removes it.
- [ ] Service shutdown: stop from notification -> mic released, no restart loop.

**Device**
- [ ] Battery alerts: set low = 99%, unplug -> one alert; plug in at 100% -> "fully charged" once.
- [ ] Temperature: "phone temperature" -> battery temp / thermal status, never a CPU number; heat alert fires once.
- [ ] Network: "network status" twice -> type + latency; airplane mode -> "offline".
- [ ] WorkManager: with alerts on and app closed, an alert arrives within ~15 min.

**Automation**
- [ ] Tuesday/Saturday routine: "editing days tuesday saturday 18:00" -> routine listed; notification on the day (or set a near time to test).
- [ ] Night Mode: on -> Nova voice quieter + dark theme; off -> restored; schedule times fire.
- [ ] Editing Mode: on -> proactive notifications paused, editing app or sound settings opens; off -> restored; template copy works.

**Security**
- [ ] Security Mode: on, put phone down; after the arming delay lift it -> alarm + spoken warning; shake only the table -> no alarm.
- [ ] Motion detection: Low/Medium/High differ; cooldown prevents repeat alarms.
- [ ] Alarm: stops after its length; "Stop alarm" works; Test alarm works.
- [ ] BiometricPrompt: turning Security Mode off asks for fingerprint/screen lock; 3 wrong tries log "Failed unlock".
- [ ] Reboot: Security Mode is OFF afterwards and a notification says so.
- [ ] Force Stop: Security Mode stops; nothing restarts by itself.

**Vision**
- [ ] Camera: permission asked only on the Camera screen; camera off after Stop, leaving the screen, or pressing Home.
- [ ] ML Kit: "What's in view?" names the object.
- [ ] Text recognition: English and Hindi text read correctly in good light.
- [ ] Object detection: several objects -> count mentioned.
- [ ] Gesture mode: swipe right = next, left = previous, wave = play/pause while music plays; stops with the screen.

**Screen**
- [ ] Accessibility: off -> Nova says so; on -> "what can I tap" lists controls; password fields never read.

**Web & developer**
- [ ] OpenAI selected, no Gemini key: "latest news batao" -> headlines; "web search for Kotlin coroutines" -> summary + sources.
- [ ] Weather: "weather in Delhi".
- [ ] Code: "python script bana do jo Downloads organize kare" -> code shown in Developer tab, nothing executed.
- [ ] Diagnostics: after a crash, More > Developer Tools lists it; Analyze with AI saves a suggestion; "I applied it" only marks status.
- [ ] Updates: wrong hash / unsigned APK is refused; correct update opens Android's installer.

**Robustness**
- [ ] Permission denial: deny mic, camera, notifications -> clear message, no crash.
- [ ] Network loss mid-answer: friendly error; local commands still work.
