# Hey Nova + Galaxy Orb (Nova Floating Voice Assistant)

Settings: **Jarvis → Nova Floating Voice Assistant** (top of that page).

## How it is wired (no duplicate services)
| Piece | File | Role |
|---|---|---|
| Microphone | `voice/NovaVoiceForegroundService` + `AudioCapture` | Still the only mic. New `ACTION_APPLY` re-applies settings. |
| Wake engine | `jarvis/WakeGateEngine` (Vosk) | Now listens for a *grammar of whole phrases* (`WakePhrases`). In Hey Nova mode it does **not start Gemini Live / STT until the phrase is heard**, forwards audio while the conversation is open, then stops it again. |
| Phrases | `jarvis/WakePhrases`, `jarvis/WakeVocab` | 12 built-in phrases (Hey/Hello/Hi Nova, Hi/Hey/Hello Jaan, "Jaan, how are you?", "Jaan, kaisi ho?", "Jaan, kya kar rahi ho?", "Hello Jaan, suno", "Nova, meri baat suno", "Jaan, listen") plus your own. Each phrase has forms for the English and/or Hindi Vosk model. Only phrases whose every word is in the model's real vocabulary (`graph/words.txt`) are used; only the needed models are loaded. |
| Conversation | `voice/NovaSession`, `jarvis/ConversationWindow` | Wake → open (10 s) → stays open while Nova thinks/speaks or you talk (+8 s follow-up) → closes. |
| Orb | `jarvis/FloatingOrb` (window) + `jarvis/GalaxyOrbView` (drawing) | The one overlay. IDLE / LISTENING / THINKING / SPEAKING from `voice/OrbPhase`. |
| Settings | `ui/FloatingVoiceSettings`, `jarvis/JarvisPrefs` | `heyNova`, `wakePhraseIds`, `orbIdleMinimized`, `orbReduced`, `batterySaver`, `orbHaptics`. |

## Behaviour changes to existing code
- The offline wake gate now also wraps native Gemini Live (before, it only gated the speech-to-text fallback). Older "Offline wake word" users therefore get what that switch always said.
- `SpeechEngines.fallback` no longer wraps its own gate (the outer gate covers the whole route).
- Dispatcher strips the full wake phrase; "Nova, are you there?" is answered with a spoken "Yes?".
- Added `VIBRATE` permission (haptic tick). No other permission changes.

## Android limits (by design)
- Microphone foreground services cannot be started from the background or from BOOT_COMPLETED (Android 12–14). After a reboot tap **Resume listening** in Nova's notification or open Nova once.
- Some phones stop background mic apps: set Nova AI to *Unrestricted* battery.
- Wake detection uses the English (India) Vosk model (~36 MB, download in settings). Latin-script phrases only.
- Vosk is a general recognizer limited by grammar, not a trained keyword spotter: test your name; expect some misses / false hearings.
- Nova does not hear or record audio while the mic is paused; the notification and Android's mic indicator are shown whenever it is on.

## Test checklist (on a device)
1. Settings → enable Hey Nova → allow mic / notifications / overlay → download the model.
2. **Test floating orb**: orb plays listening → thinking → speaking.
3. **Test voice activation**, say "Hey Nova" in another app: orb appears, Gemini connects only then.
4. Ask something, then a follow-up without the wake phrase; stay silent ~8 s → orb hides.
5. Tap orb while she speaks → interrupts. Drag it; it snaps to an edge and stays out of bars/cutout.
6. Pause microphone → Hey Nova no longer hears anything.

## Hindi / Hinglish phrases
- English phrases run on the English (India) model, Hindi ones on the Hindi model (Devanagari output). Download both in settings; with only English installed, phrases whose English form is in its vocabulary still work and the rest are listed as "not available" with the reason.
- False-activation guards: phrases are 2+ words, the offline recognizer is limited to exactly the phrases (everything else is "unknown"), a result needs average word confidence ≥ 0.55, a partial result must repeat in two consecutive updates, 1.5 s cooldown after a conversation ends.
- Question phrases ("Jaan, kaisi ho?", "Jaan, how are you?") are answered directly; "Hello Jaan, suno" / "Nova, meri baat suno" get "Haan, boliye?"; the live session starts after Nova has spoken.
- Custom phrases: add/remove in settings (2-6 words, English or Devanagari); the list shows whether the installed model can recognize them.
- Not verified without a device: whether the small Vosk models contain words like "jaan"/"kaisi" in the form I assumed. The vocabulary check protects against silent failure, but some phrases may show "not available". Fix by adding a spelling variant as a custom phrase (e.g. Devanagari).

## Add My Own Wake Words (Settings → Nova Floating Voice Assistant)
- Every phrase (12 built-in, 2 extra, yours) has an on/off switch; tap a phrase to **set it as default**, **edit / customize** it, or **delete** yours. The default is always on and listed first.
- Saved in SharedPreferences (`j_wake_custom` as `1|text` / `0|text`, `j_wake_ids`, `j_wake_default`), so it survives restarts.
- Any change is applied to the running wake engine ~1.2 s later (`NovaVoiceForegroundService.applySettings` → `WakeGateEngine` rebuilds its Vosk grammars from `WakeVocab.planFor`). Nothing is "just text".
- Hinglish typed in Roman letters: tried on the English model first; if it lacks a word, `Deva.variants` produces Devanagari spellings (ICU Latin-Devanagari, e.g. "meri jaan" → "मेरी जान") for the Hindi model. A phrase is only used if the model's word list contains every word; otherwise settings shows "not available: …" with the reason (add a Devanagari spelling by hand).
- Protection: 2–6 words, ≥6 letters, refused if made only of everyday words ("hey you", "kya hai"), duplicate detection across built-ins, yours and spellings; plus the confidence / two-update / cooldown guards.
- Recognized phrase → orb + listening → existing Nova AI (Gemini Live or the headless assistant). Microphone privacy: the Pause microphone switch and mic indicator in the same screen.
