# Building Nova AI in AndroidIDE (phone only, no Termux)

1. Extract `NovaAI-v2.5-part4.zip` and open the `NovaAI` folder in AndroidIDE (Open project).
2. Wait for **Gradle sync**. Stay online: it downloads CameraX, ML Kit, Room, WorkManager and the rest.
   If sync says a version was not found, open `app/build.gradle.kts` and move that library to the nearest version Gradle lists.
3. **Build > Build APK** (debug). Output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Install it (allow "Install unknown apps" for AndroidIDE or your file manager).
5. Open Nova and grant permissions only when a feature asks:
   microphone (voice), notifications (alerts/Security Mode), camera (Camera Vision only), Accessibility (Settings > Screen Assistant).
6. Settings > Gemini / AI provider: pick Gemini or OpenAI, paste the key, tap **Test connection**.
   Speech-to-text, Gemini web search and screen vision use the Gemini key.
7. Test: voice (Settings > Voice, say "Nova" commands), memory ("remember that I edit videos every Tuesday"),
   security (Settings > Security & Voice Lock), camera (More > Camera Vision), accessibility ("what can I tap"),
   routines (Command Center).

Release builds to share with others should be signed with one fixed key; Updates only accept an APK signed with the key of the installed app.

## Update metadata (for More > Developer Tools > Updates)
Host a JSON file over HTTPS:
```
{"versionCode":26,"versionName":"2.6","apkUrl":"https://example.com/nova-2.6.apk","sha256":"<64 hex chars of the apk>","notes":"What changed"}
```
Get the hash with `sha256sum nova-2.6.apk`, or any file-hash app.
