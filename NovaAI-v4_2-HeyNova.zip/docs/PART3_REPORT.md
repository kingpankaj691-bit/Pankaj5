# Nova AI v4.2 — Part 3 report: WhatsApp

## Build status (honest)
NOT built, NOT run (no Gradle / Kotlin compiler / Android SDK in my sandbox). The planner regexes were additionally
checked by running the same patterns in Python against the test sentences; everything else is source-reviewed only.
Run `./gradlew :app:testDirectDebugUnitTest` and `./gradlew :app:assembleDirectDebug` and send me any error text.
WhatsApp view ids / labels (entry, send, search_input, conversations_row_contact_name ...) are heuristics and change
between WhatsApp versions: they MUST be checked on a real phone.

## CRITICAL bug fixed (violated "never send without confirmation")
The Live voice tool `message_contact` said "the user taps Send" but `FlavorTools.autoSend()` pressed
"Continue to chat" and **Send** itself, for WhatsApp and SMS, with no confirmation. It is gone: the tool now only opens the
composer with the text filled in (`prepareComposer`) and tells the model the user must press Send.

## Other bugs fixed
1. `WhatsAppAgent` (Live path): the confirmation wait had no timeout (could hang forever) — now 60 s, no answer = not sent.
2. A "yes" arriving in the same instant the question was raised is refused (a person could not have read it).
3. The "awaiting confirmation" reply now carries recipient and exact text, so the model must read them to the user.
4. After Send, the agent checks that the message left the box; no longer says "sent" blindly.
5. Chat text and unread notifications read by the agent now have codes / card numbers hidden.
6. Planner path: there was no WhatsApp plan at all, so "WhatsApp par Rahul ko hello bhejo" could not run on screen.
7. "WhatsApp" resolved to nothing when only WhatsApp Business is installed (now falls back to it).

## New: verified WhatsApp flow (planner) — `WhatsAppFlow`
open WhatsApp (proven in front) → refuse registration/verification screens → find the contact through WhatsApp search
(typed text read back) → if several different people match, ask which (never guess) → open the chat and prove the title
matches → type the draft and read it back → **show recipient + exact message and ask for an explicit yes**
(extra warning if it looks like a password / OTP / PIN / card number) → after the yes, bring WhatsApp back to the front
and re-check chat and draft (the screen may have changed while you answered) → press Send ONCE (never retried, a retry
could send twice) → report "sent" only if the box is empty AND a new bubble with the text appeared; otherwise say exactly
what was seen. A "no" clears the draft. Phone numbers use the official wa.me deep link with the text prefilled.
Reading ("read my whatsapp messages", "WhatsApp par chats dikhao") only happens on request, hides codes and numbers,
and never touches registration screens. NOVA never enters or reads passwords, OTPs or verification codes.

## Voice forms understood
"WhatsApp par Rahul ko hello bhejo" · "Rahul ko WhatsApp par hello bhejo" · "Rahul ko whatsapp par message bhejo ki ..." ·
"send a whatsapp message to Rahul saying ..." · "send message to Rahul on whatsapp saying ..." ·
"open Rahul's chat on whatsapp" · "WhatsApp par Rahul ki chat kholo" · "open whatsapp chat with Priya" ·
"read my whatsapp messages" · "WhatsApp par chats dikhao". A vague message ("message bhejo") is never sent literally.

## Files
New: screen/WhatsAppUi.kt (WhatsApp rules + SensitiveText), planner/WhatsAppFlow.kt,
test/screen/WhatsAppUiTest.kt, test/planner/TaskPlannerWhatsAppTest.kt
Modified: planner/Plan.kt, planner/TaskPlanner.kt, planner/PlanRunner.kt, screen/AppNameMatcher.kt (+test),
device/DeviceController.kt (openWhatsAppChat), direct/live/FlavorTools.kt, main/live/LiveTools.kt,
direct/agent/whatsapp/WhatsAppAgent.kt

## Limits
- The confirmation is shown in NOVA's chat/prompt. If you answer inside NOVA, WhatsApp leaves the front; the flow brings it back
  and re-checks before sending. A floating confirmation over WhatsApp comes with the Part 6 dashboard work if you want it.
- "Delivered/read" ticks are not checked. Group chats work only if the group name is matched in search.
- The old Live `WhatsAppAgent` still relies on the model relaying your yes; the timeout / delay / readback guards reduce the
  risk but cannot prove a human answered. The planner path asks you directly.
- Video-share workflow (`openShare`) is unchanged: it already asks before "Open & send".

## Real-device checks (Android 13)
1. "WhatsApp par <contact> ko hello bhejo": NOVA must stop and show recipient + "hello" and wait. Say no: nothing sent, draft cleared.
2. Say yes: message sent once; reply says Sent only after the bubble appears. Repeat with a very short message ("hi") that already exists in the chat.
3. Two contacts with the same first name: NOVA must ask which.
4. Answer the confirmation from inside NOVA: WhatsApp returns to the front and the message still goes to the right chat.
5. Live voice: "message Rahul hello": the composer opens, NOTHING is sent until you press Send.
6. Log out of WhatsApp test account (or use a fresh install): NOVA refuses to touch the verification screen.
7. Chat containing "Your WhatsApp code: 123-456": reading the chat shows [hidden].
8. Only WhatsApp Business installed: "open whatsapp" and the flow still work.
