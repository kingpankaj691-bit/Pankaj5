# Performance audit for Galaxy A12 (4 GB RAM) — code review, not profiler measurements

Method: read the existing code for loops/handlers/threads/bitmaps (grep over the whole project) and designed the new code around it. **No profiler or on-device measurement was possible.**

Existing code (kept): long-running loops are only the microphone read loop, the Gemini Live reader/writer loops, the optional Proactive engine and one-shot downloads; no fixed-rate timers; 8 services in the manifest (all pre-existing). One screen-capture bitmap path (ARGB_8888 at screen size, recycled by callers).

New code:
- **No new service or foreground service.** Everything runs in the existing voice service, Application, WorkManager or on demand.
- **Single microphone session:** the voice level is computed from the audio already being read (every 4th sample, 12 updates/second).
- **Orb:** redraw only while listening/speaking/working; 12–20 fps tick (not 60); shader cached; one default-network callback only while the orb exists.
- **Live OCR:** 3.5 s base interval on low-RAM phones, slows to 8 s while the screen is static, stops when the screen is off, accessibility text is used before any OCR, frames downscaled to ≤1280 px, bitmaps recycled, own sheet text filtered to avoid feedback.
- **Overlay sheet:** one ComposeView, created on demand, destroyed on close (lifecycle owner stopped, ViewModelStore cleared).
- **Trim memory:** at `TRIM_MEMORY_RUNNING_CRITICAL` Nova stops Live OCR and closes the sheet.
- **GitHub build watcher:** one-time WorkManager job every 60 s, max 25 checks, only after you start a run.
- **Agent:** 1.5 s step delay on low-RAM phones, ≤30 steps, no screenshots (accessibility text only).
- **Network:** model calls only on explicit actions (translate, summarize, draft, agent step); plain OCR/extract uploads nothing.
- **Lazy:** asset previews are sampled bitmaps (≤512 px, RGB_565); inventory loaded only when its screen opens (may take ~0.2 s on the A12; it runs on the main thread — move to a background thread if you see jank).

To measure: Android Studio Profiler (memory, energy) over a 30-minute session with Live OCR + orb + background voice on.
