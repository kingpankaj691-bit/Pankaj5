# v3.2 (suite, installment 1) — spec audit and status

Built from NovaAI-v3_1-universal-models.zip. **Nothing in this installment was compiled or run** (no Gradle/Android SDK and no network in the build environment). Expect a few small compile fixes; send the build log and they get fixed.

## Feature-preservation checklist (nothing removed or replaced)
Existing files edited only by small additions: `LocalCommandRouter.kt` (suite commands + app hint on screen context), `MainActivity.kt` (tabs 19, 20), `MoreScreens.kt` (2 list items), `UiBridge.kt` (2 constants), `NovaVoiceForegroundService.kt` (ducking collector), `AndroidManifest.xml` (Termux permission/query/receiver), `build.gradle.kts` (version only; no new dependencies). Gemini model system, Live/fallback routing, voice pipeline, memory, glass UI, Forge, social agent, licensing: untouched.

## Already in v3.1 (kept as is)
Screen reading + gestures (AccessibilityService), MediaProjection capture, ML Kit OCR (Latin + Devanagari), camera vision, floating orb, Vosk offline recognizer + custom wake name, Gemini Live + STT→model→TTS routing, boot receiver, notification listener, planner/multi-step plans, device scan, brightness/volume (DeviceController), Gemini model discovery.

## Added in this installment
| Spec item | Implementation |
|---|---|
| 1.2 app-aware help | `suite/AppContext.kt` (WhatsApp, Chrome, AndroidIDE/Acode/Termux, Instagram, Alight Motion/CapCut) added to screen-context prompt |
| 4.3 audio ducking | `suite/AudioDucker.kt` (AudioFocus MAY_DUCK), driven by `VoiceState.speaking`, toggle in Privacy Dashboard |
| 2.3 system controls | `suite/SystemControls.kt`: DND (with access grant), settings pages for Bluetooth/Wi-Fi/Airplane/Display/Private DNS, network + battery info |
| 5.2 Termux | `suite/TermuxBridge.kt`: RUN_COMMAND, preview + Approve, destructive patterns refused, result receiver |
| 5.3 logs | `suite/LogAnalyzer.kt`: Kotlin/Gradle/crash detection, own-process logcat, secret removal, 50-item history, AI explanation via the selected model |
| 5.4 GitHub Actions | `suite/GitHubActions.kt`: token in encrypted prefs, trigger (confirmed), run status, failed steps, log tail, artifact names |
| 6.3 privacy dashboard | `ui/SuiteScreens.kt` PrivacyDashboardScreen (mic, service, accessibility, notification access, capture, overlay, DND) |
| 7 commands | `suite/SuiteCommands.kt` (DND, settings pages, ducking, privacy, build/GitHub/Termux → opens review screen) |
| Tests | `test/.../suite/SuiteCoreTest.kt` |

## Installment 2 (v3.2-suite-part2)
- `suite/OverlaySheet.kt` (NovaSheet): Compose bottom sheet in a TYPE_APPLICATION_OVERLAY window with its own lifecycle owner; Copy/Share/✕ and custom actions; quick menu.
- `suite/ScreenTools.kt`: translate (auto source language, target from command, default Hindi), extract text (no AI), summarize. Text from the accessibility tree, else one OCR frame if Screen Vision is on. Floating translation panel = this sheet.
- `jarvis/FloatingOrb.kt` upgraded: long-press quick menu, optional double-tap action (Privacy Dashboard > Floating orb), snap-to-edge, pulse animation only while listening/speaking/working, purple "working" state. Tap and drag behave as before; pause/resume moved into the quick menu.
- Commands: "is page ko Hindi mein translate karo", "extract text", "quick menu".
Device test: grant Display over other apps; long-press orb -> sheet; Translate screen over WhatsApp/Chrome; Extract text copies; double-tap setting; orb stops pulsing when idle.
Limits: OCR fallback needs Screen Vision started; password fields are never read; video-frame OCR works only while Screen Vision is capturing.

## Installment 3 (v3.2-suite-part3): Live OCR
`suite/LiveOcr.kt`. Say "live OCR on" or "live translate Hindi" -> starts and keeps running automatically until "live OCR band karo", the Stop button, or closing the sheet. Never auto-starts, never after reboot, sleeps while the screen is off, reads only when content changed, backs off when static, translate calls max one per 3 s. Purple orb pulse + visible sheet show it is on.
Device test: "live ocr on" over a scrolling Chrome page; text updates; screen off/on pauses/resumes; "live translate hindi"; stop by voice, button and ✕.

## Live OCR (v3.2-suite-part3)
`suite/LiveOcr.kt`: say "live OCR on" (or "live OCR Hindi mein") and it keeps running until "live OCR band karo". Updates the sheet only when text changes, polls 2.5 s then slows to 5 s while static, pauses with the screen off, translates at most every 4 s, resumes with the voice service if left on. Also in the orb quick menu and Privacy Dashboard. Limit: with OCR frames (not accessibility text) the sheet can be re-read; Nova filters its own lines, but unusual fonts may leak through. Needs Display over other apps; OCR of unselectable text needs Screen Vision started.

## Cross-app workflows (v3.2-suite-part4)
`suite/Workflows.kt`. (1) "latest exported video YouTube upload ke liye title description prepare karo": finds newest videos in MediaStore (steps to older ones on request) -> drafts title/description/tags with the selected model (file-name fallback if AI is off) -> preview with Regenerate/Copy -> opens YouTube via share intent -> fills Title/Description through accessibility (best effort) -> stops: you tap Upload. (2) "latest video WhatsApp pe share karo": same file choice, opens that app's share screen; you tap Send. Task history (30 entries) under Developer Integrations. Limits: YouTube's form layout/labels change, so field filling can fail (text is then on the clipboard); needs Photos and videos permission and Display over other apps (which also lets Nova start the app from the sheet). See "Auto upload / send" below.

## Auto upload / send (v3.2-suite-part5)
`suite/AutoPress.kt`. You asked for Nova to upload/send by itself, so the preview now has two choices: "Open & fill only" (stops before Upload/Send) and "Fill & upload" / "Open & send to <name>". Choosing the second is your approval; Nova then presses the buttons by label through accessibility: YouTube (audience -> Next x3 -> visibility -> Upload/Publish) and share targets such as WhatsApp (pick the chat by name, press Send; asks nothing more). Guardrails: you choose visibility and the "made for kids" answer yourself (legal declaration); needs Accessibility on; acts only while the target app is in front; stops if the recipient name matches several chats or any button isn't found; skips password fields; orb menu > "Stop workflow" cancels; the result and history say exactly what was pressed. Limits: apps rename/move buttons, so a step can fail (Nova stops and tells you which); Nova can't confirm the upload finished, only that the button was pressed.

## Instagram + universal agent (v3.2-suite-part6)
- **Live OCR phrases**: "live OCR on", "live OCR chalu karo", "start live OCR", "live OCR Hindi mein" (translate). Stop: "live OCR band karo". (Speech may write "live o c r"; both work.)
- **Instagram**: "latest video Instagram par reel upload karo" -> choose file -> Reel/Post -> caption preview -> "Fill & share" (presses Next/Share) or "Open & fill only". Instagram may restrict accounts that behave like bots; Nova does one approved run only.
- **Universal agent** `suite/ScreenAgent.kt`: say "khud karo <goal>" / "agent mode <goal>" / "jarvis mode <goal>". Observe screen -> selected Gemini picks one action -> Nova checks and performs it (click/type/scroll/back/home/open app/wait/ask you), up to 30 steps. Code-enforced rules: never in payment/banking/password apps, never password fields or secrets, always asks before pay/buy/delete/install/permissions/sign-out, asks before send/post unless you chose automatic for that run; orb menu > Stop workflow. Limits: Accessibility needed, secure/blocked screens unreadable, ~1 model call per step (free-tier quota), the model can misjudge a screen (it stops when stuck).

## Completion installment (v3.3-complete) — everything that was missing
Asset manager (`suite/AssetManager.kt`, screen "Asset Manager"), Device Owner/kiosk, screen pinning, app inventory + restrictions (`suite/DeviceMgmt.kt`, "Device Management"), text select/copy by accessibility, WhatsApp-style reply drafts, document-picker transfer (`suite/PickerActivity.kt`), 3D liquid-glass orb with voice-level reaction, voice meter in the sheet and a connection dot, ducking while YOU speak, permission-change and service-killed alerts with history (`suite/SecurityWatch.kt`), data retention timers, usage access view, repo/workflow pickers + build-ready notification + verified APK download (SHA-256) for GitHub, central command history, the 12-section Control Center with real switches (`ui/ControlCenterScreens.kt`), low-RAM profile (`suite/Features.kt` PerfProfile) and instrumented tests. See FINAL_REPORT.md, VERIFICATION_CHECKLIST.md and PERFORMANCE_AUDIT.md.

## Platform limits (documented, not worked around)
- Termux: needs allow-external-apps=true and the Run-commands permission granted by you.
- Android gives apps only their own logcat; other apps' logs must be pasted/shared.
- GitHub artifact download needs your GitHub login; Nova links the run page.
- Android doesn't let apps toggle Wi-Fi/Bluetooth/airplane/Private DNS; Nova opens the page. DND needs the special access you grant.
- Uninterrupted background mic can't be guaranteed on Samsung One UI; foreground service + battery-optimization exemption is the supported route.
- The Termux feature relaxes the old "Nova never launches Termux" note in CodeAssistant.POLICY only through the separate, approval-gated bridge; generated code is still never run automatically.

## Device checklist for this installment (Galaxy A12, Android 13)
DND toggle (grant access first) · Bluetooth/Wi-Fi/Display pages open · music ducks while Nova speaks and recovers · ducking switch off stops it · Privacy Dashboard rows match Android settings · Termux: grant permission, set allow-external-apps, run `git status`, see output · destructive command refused · GitHub token save, Check status, Run workflow asks first · paste Gradle error → finding shown · "Nova's own logcat" fills box.
