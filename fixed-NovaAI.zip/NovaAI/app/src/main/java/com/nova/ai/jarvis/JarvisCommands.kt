package com.nova.ai.jarvis

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import com.nova.ai.notifications.NovaNotificationListener
import com.nova.ai.security.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class JarvisCall {
    object Briefing : JarvisCall()
    object ReadMessages : JarvisCall()
    data class ReplyMsg(val who: String, val text: String) : JarvisCall()
    object CallAnswer : JarvisCall()
    object CallReject : JarvisCall()
    data class SavePlace(val name: String) : JarvisCall()
    data class LocationRemind(val place: String, val what: String) : JarvisCall()
    data class CalendarAdd(val title: String) : JarvisCall()
    data class MediaKey(val action: String) : JarvisCall()
    data class InterpreterOn(val from: String, val to: String) : JarvisCall()
    object InterpreterOff : JarvisCall()
    data class Car(val on: Boolean) : JarvisCall()
    data class Agent(val on: Boolean) : JarvisCall()
    data class Home(val ids: List<String>, val on: Boolean?, val level: Int?) : JarvisCall()
    object Sos : JarvisCall()
    object SosCancel : JarvisCall()
    data class TaskerRun(val task: String) : JarvisCall()
    data class FindFiles(val query: String) : JarvisCall()
    data class OpenResult(val index: Int) : JarvisCall()
    data class PlayLocal(val query: String) : JarvisCall()
    /** Needs the app screen: takes a photo and asks about it. */
    data class Camera(val question: String) : JarvisCall()
    /** Needs the app screen: picks a file or PDF and asks about it. */
    data class PickFile(val question: String) : JarvisCall()

    /** Anything that sends something out or changes data on its own needs a yes first. */
    val sensitive: Boolean get() = this is ReplyMsg || this is CalendarAdd || (this is Home && SmartHome.needsConfirm(ids))
    val prompt: String get() = when (this) {
        is ReplyMsg -> "Send \"$text\" to ${who.ifBlank { "the latest message" }}?"
        is CalendarAdd -> "Open the calendar to add \"$title\"?"
        is Home -> "Control ${SmartHome.cache.filter { it.id in ids }.joinToString { it.name }}?"
        else -> ""
    }
    val needsScreen: Boolean get() = this is Camera || this is PickFile
}

/** Hindi / Hinglish / English phrases for the Jarvis features. Returns null when the text isn't one of them. */
object JarvisCommands {
    private val langs = "hindi|english|urdu|bengali|tamil|telugu|marathi|gujarati|punjabi|spanish|french|german|japanese|korean|chinese|arabic|russian"

    fun parse(raw: String): JarvisCall? {
        val t = raw.trim().trim('.', '!', '?').replace(Regex("(?i)^(hey )?nova[ ,]*"), "").trim()
        val l = t.lowercase()
        if (l.isEmpty()) return null

        // calls (only while the phone is ringing, so normal speech is never mistaken for a call command)
        if (CallAnnouncer.ringing) {
            if (Regex("^(?:call |phone )?(?:uthao|utha lo|utha do|pick up|answer(?: the call| it)?|haan uthao)$").matches(l)) return JarvisCall.CallAnswer
            if (Regex("^(?:call |phone )?(?:kaat do|kaato|kaat de|cut|reject|decline|disconnect|mat uthao)$").matches(l)) return JarvisCall.CallReject
        }

        // emergency (always checked first; the countdown can be cancelled)
        if (Regex("^(?:help me|help me nova|nova help me|emergency|nova emergency|sos|sos nova|bachao|nova bachao|mujhe bachao|madad karo|help help)$").matches(l)) return JarvisCall.Sos
        if ((SosEngine.pending || SosEngine.active) && Regex("^(?:cancel(?: sos)?|sos cancel|sos band karo|galti se|galti ho gayi|main theek hoon|i am safe|i'm safe|ruk jao|stop)$").matches(l)) return JarvisCall.SosCancel

        if (Regex("^(?:good morning|morning briefing|daily briefing|briefing|subah ki (?:jankari|khabar|briefing)|aaj ka briefing|mera din kaisa hai|brief me)$").matches(l)) return JarvisCall.Briefing

        if (Regex("^(?:read (?:my )?messages?|messages? (?:padho|sunao|batao)|naye messages? (?:padho|sunao)|koi message aaya(?: hai)?|last message padho)$").matches(l)) return JarvisCall.ReadMessages
        Regex("^(?:(.+?)\\s+ko\\s+)?reply\\s+(?:karo|kar do|do|bhejo|send)?\\s*(?:ki|that|:|-)?\\s*(.+)$").find(l)?.let {
            val body = original(t, it.groupValues[2])
            if (body.isNotBlank()) return JarvisCall.ReplyMsg(it.groupValues[1].trim(), body)
        }
        Regex("^reply\\s+to\\s+(.+?)\\s*(?:that|:|saying)\\s*(.+)$").find(l)?.let { return JarvisCall.ReplyMsg(it.groupValues[1].trim(), original(t, it.groupValues[2])) }

        // places and location reminders
        Regex("^(?:ye|yeh|yahi|yaha)\\s+(?:mera|meri)\\s+(.+?)\\s+hai$").find(l)?.let { return JarvisCall.SavePlace(it.groupValues[1].trim()) }
        Regex("^save (?:this|current) (?:place|location)(?: as)? (.+)$").find(l)?.let { return JarvisCall.SavePlace(it.groupValues[1].trim()) }
        Regex("^(?:is jagah|isko|yahan)\\s+ko\\s+(.+?)\\s+(?:naam do|save karo|yaad rakho)$").find(l)?.let { return JarvisCall.SavePlace(it.groupValues[1].trim()) }
        Regex("^remind me to (.+?) when i (?:reach|get to|arrive at|arrive|get) (.+)$").find(l)?.let { return JarvisCall.LocationRemind(it.groupValues[2].trim(), original(t, it.groupValues[1])) }
        Regex("^remind me when i (?:reach|get to|arrive at|arrive|get) (.+?)(?: to|:|,)\\s*(.+)$").find(l)?.let { return JarvisCall.LocationRemind(it.groupValues[1].trim(), original(t, it.groupValues[2])) }
        Regex("^yaad dilana (?:jab )?(.+?) pahunch\\w*\\s*[:,]?\\s*(.+)$").find(l)?.let { return JarvisCall.LocationRemind(it.groupValues[1].trim(), original(t, it.groupValues[2])) }
        Regex("^(.+?)\\s+pahunch\\w*\\s+(?:to|toh|par|pe|per|tab)?\\s*(.+?)\\s+yaad dila\\w*$").find(l)?.let { return JarvisCall.LocationRemind(it.groupValues[1].trim(), original(t, it.groupValues[2])) }

        // calendar
        Regex("^(?:add|create|schedule)\\s+(?:an?\\s+)?(?:event|meeting|appointment)\\s*(?:called|for|:)?\\s*(.+)$").find(l)?.let { return JarvisCall.CalendarAdd(original(t, it.groupValues[1])) }
        Regex("^(.+?)\\s+(?:ka|ki)\\s+(?:event|meeting)\\s+(?:add karo|banao|bana do)$").find(l)?.let { return JarvisCall.CalendarAdd(original(t, it.groupValues[1])) }

        // smart home (only when devices are registered, and only when a device or "sab lights" is named)
        if (SmartHome.cache.isNotEmpty()) {
            val on = Regex("\\b(on|chalu|jala|jalao|jalado|jala do|start)\\b").containsMatchIn(l)
            val off = Regex("\\b(off|band|bandh|bujha|bujhao|bujhado|bujha do)\\b").containsMatchIn(l)
            val lvl = Regex("(\\d{1,3})\\s*(?:%|percent|pratishat)").find(l)?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(1, 100)
                ?: if (Regex("\\b(dim|dheemi|dheema)\\b").containsMatchIn(l)) 30 else if (Regex("\\b(full bright|full brightness|bright|tez)\\b").containsMatchIn(l)) 100 else null
            if ((on || off || lvl != null) && !(on && off)) {
                val devs = SmartHome.match(l)
                if (devs.isNotEmpty()) return JarvisCall.Home(devs.map { it.id }, if (lvl != null) true else on, lvl)
            }
        }

        // phone files and offline songs
        if (FileSearch.last.isNotEmpty()) Regex("^(?:(pehli|pehla|first|1st|dusri|doosri|dusra|second|2nd|teesri|third|3rd)\\s*(?:wali|wala|file|one)?\\s*(?:kholo|open|dikhao)|(?:kholo|open)\\s+(pehli|pehla|first|dusri|doosri|second|teesri|third|isko|ise|it|wo|woh)\\s*(?:wali|wala|file|one)?)$").find(l)?.let {
            val w = it.groupValues[1].ifEmpty { it.groupValues[2] }
            return JarvisCall.OpenResult(when (w) { "dusri", "doosri", "dusra", "second", "2nd" -> 1; "teesri", "third", "3rd" -> 2; else -> 0 })
        }
        if (Regex("\\b(offline|mere phone|phone (?:ke|ka|mein|se)|local|storage)\\b").containsMatchIn(l) && Regex("\\b(gaane|gaana|songs?|music)\\b").containsMatchIn(l) && Regex("\\b(play|bajao|chalao|sunao|laga|lagao)\\b").containsMatchIn(l))
            return JarvisCall.PlayLocal(FileSearch.keywordOf(l))
        if (Regex("\\b(dhundho|dhoondo|dhundh|dhoond|khojo|find|search|locate)\\b").containsMatchIn(l) &&
            Regex("\\b(pdf|documents?|docx?|word|excel|sheet|ppt|presentation|photos?|images?|videos?|files?)\\b").containsMatchIn(l) &&
            Regex("phone|offline|storage|download|\\bkal\\b|\\baaj\\b|parso|yesterday|today|hafte|week|mahine|month|\\bmer[ae]\\b|\\bmeri\\b|\\bmy\\b").containsMatchIn(l)) return JarvisCall.FindFiles(l)

        // Tasker
        Regex("^(?:tasker|task)\\s+(?:chalao|run|start|launch)\\s+(.+)$|^(?:run|start) tasker task (.+)$").find(l)?.let {
            return JarvisCall.TaskerRun(original(t, it.groupValues[1].ifEmpty { it.groupValues[2] }))
        }

        // media and volume (music play/pause/next already live in ModuleCommands)
        if (Regex("^(?:volume|awaaz|aawaz)\\s+(?:up|badhao|zyada karo|increase|tez karo)$").matches(l)) return JarvisCall.MediaKey("volume_up")
        if (Regex("^(?:volume|awaaz|aawaz)\\s+(?:down|kam karo|ghatao|decrease|dheere karo)$").matches(l)) return JarvisCall.MediaKey("volume_down")
        if (Regex("^(?:volume|awaaz|aawaz)\\s+(?:full|max|maximum)$").matches(l)) return JarvisCall.MediaKey("max")
        if (Regex("^(?:mute|awaaz band karo|volume mute)$").matches(l)) return JarvisCall.MediaKey("mute")

        // interpreter
        if (Regex("^(?:interpreter|translator|anuvaadak)(?: mode)?\\s+(?:off|band|stop|band karo|khatam)$|^(?:stop|band karo)\\s+(?:the\\s+)?(?:interpreter|translator)(?: mode)?$").matches(l)) return JarvisCall.InterpreterOff
        Regex("^(?:interpreter|translator)(?: mode)?\\s+(?:on|chalu|start)(?:\\s+karo)?(?:\\s+($langs)\\s+(?:to|and|se|aur|-)\\s+($langs))?$").find(l)?.let {
            val a = it.groupValues[1].ifBlank { "hindi" }; val b = it.groupValues[2].ifBlank { "english" }
            return JarvisCall.InterpreterOn(a.replaceFirstChar { c -> c.uppercase() }, b.replaceFirstChar { c -> c.uppercase() })
        }
        Regex("^($langs)\\s+(?:to|se|aur)\\s+($langs)\\s+interpreter(?: mode)?(?:\\s+(?:on|chalu)(?:\\s+karo)?)?$").find(l)?.let {
            return JarvisCall.InterpreterOn(it.groupValues[1].replaceFirstChar { c -> c.uppercase() }, it.groupValues[2].replaceFirstChar { c -> c.uppercase() })
        }

        // modes
        Regex("^(?:car|driving|gaadi) mode\\s+(on|off|chalu|band)(?:\\s+karo)?$").find(l)?.let { return JarvisCall.Car(it.groupValues[1] == "on" || it.groupValues[1] == "chalu") }
        Regex("^(?:agent|jarvis) mode\\s+(on|off|chalu|band)(?:\\s+karo)?$").find(l)?.let { return JarvisCall.Agent(it.groupValues[1] == "on" || it.groupValues[1] == "chalu") }

        // camera and files (open the app screen)
        if (Regex("camera|photo (?:kheench|le) ke|photo kheench").containsMatchIn(l) && Regex("dekho|dekh|batao|padho|kya hai|what|read|translate|identify|scan|samjhao").containsMatchIn(l))
            return JarvisCall.Camera(t)
        if (Regex("^(?:pdf|document|file)\\s+(?:padho|summari[sz]e|samjhao|choose|pick)|^summari[sz]e (?:a |this |my )?(?:pdf|document|file)$").containsMatchIn(l)) return JarvisCall.PickFile(t)
        return null
    }

    /** Text after the first occurrence of [lowered] keeping the user's original capital letters. */
    private fun original(t: String, lowered: String): String {
        val i = t.lowercase().indexOf(lowered.lowercase())
        return if (i >= 0) t.substring(i, i + lowered.length).trim() else lowered.trim()
    }

    /** Runs every call that doesn't need the app screen. */
    suspend fun run(ctx: Context, prefs: Prefs, call: JarvisCall): String {
        val jp = JarvisPrefs(ctx)
        return when (call) {
            JarvisCall.Briefing -> Briefing.build(ctx, prefs)
            JarvisCall.ReadMessages -> {
                if (NovaNotificationListener.instance == null) "Notification access is off. Enable it in Notifications."
                else NovaNotificationListener.messages(4).let { m ->
                    if (m.isEmpty()) "Koi naya message nahi hai, ya us app ko Notifications mein allow nahi kiya."
                    else m.joinToString(". ") { "${it.sender} ne kaha: ${it.text}" }
                }
            }
            is JarvisCall.ReplyMsg -> NovaNotificationListener.reply(ctx, call.who, call.text)
            JarvisCall.CallAnswer -> CallAnnouncer.answer(ctx)
            JarvisCall.CallReject -> CallAnnouncer.reject(ctx)
            is JarvisCall.SavePlace -> LocationReminders(ctx).savePlaceHere(call.name)
            is JarvisCall.LocationRemind -> LocationReminders(ctx).add(call.place, call.what)
            is JarvisCall.CalendarAdd -> {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, call.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Calendar khol diya. Time set karke Save dabaiye."
                } catch (e: Exception) { "No calendar app could open." }
            }
            is JarvisCall.MediaKey -> Media.control(ctx, call.action)
            is JarvisCall.InterpreterOn -> { Interpreter.start(call.from, call.to); "Interpreter on. Main ${call.from} aur ${call.to} ke beech translate karungi. Band karne ke liye bolo: interpreter band karo." }
            JarvisCall.InterpreterOff -> { Interpreter.stop(); "Interpreter band." }
            is JarvisCall.Car -> { if (call.on) CarMode.enable(ctx) else CarMode.disable(ctx); if (call.on) "Car mode on. Main chhote jawab dungi aur messages padh kar sunaungi." else "Car mode off." }
            is JarvisCall.Agent -> { jp.agent = call.on; if (call.on) "Agent mode on. Ab main khud decide karungi ki kaunsa tool chalana hai." else "Agent mode off." }
            JarvisCall.Sos -> SosEngine.trigger(ctx)
            JarvisCall.SosCancel -> SosEngine.cancel(ctx)
            is JarvisCall.Home -> SmartHome.control(ctx, prefs, call.ids, call.on, call.level)
            is JarvisCall.TaskerRun -> TaskerBridge.runTask(ctx, call.task)
            is JarvisCall.FindFiles -> {
                val s = FileSearch.spec(call.query)
                FileSearch.accessProblem(ctx, s) ?: run {
                    val hits = withContext(Dispatchers.IO) { FileSearch.search(ctx, s) }
                    if (hits.isEmpty() && FileSearch.lastError.isNotBlank()) "Search fail ho gayi (${FileSearch.lastError}). Android ne files padhne nahi di." else FileSearch.describe(hits, s.label)
                }
            }
            is JarvisCall.OpenResult -> FileSearch.open(ctx, call.index)
            is JarvisCall.PlayLocal -> withContext(Dispatchers.IO) { FileSearch.playSongs(ctx, call.query) }
            is JarvisCall.Camera, is JarvisCall.PickFile -> "Open Nova to do that."
        }
    }
}
