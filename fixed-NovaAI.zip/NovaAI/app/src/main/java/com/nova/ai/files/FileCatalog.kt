package com.nova.ai.files

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import java.io.File

data class UsageSlice(val label: String, val glyph: String, val bytes: Long, val count: Int)
data class StorageUsage(val slices: List<UsageSlice>, val indexedBytes: Long, val capped: Boolean)

/**
 * Everything the File Manager lists by category comes from Android's MediaStore index, so it shows exactly what Android lets Nova see:
 * with only media permission that is photos, videos and audio; documents, APKs and archives appear once "All files access" is on
 * or for folders the user picked. With no access the lists are empty (never invented).
 */
@Suppress("DEPRECATION")
object FileCatalog {
    private val filesUri: Uri get() = MediaStore.Files.getContentUri("external")
    private const val F = MediaStore.Files.FileColumns.DISPLAY_NAME
    private const val SIZE = MediaStore.Files.FileColumns.SIZE
    private const val MOD = MediaStore.Files.FileColumns.DATE_MODIFIED
    private const val MIME = MediaStore.Files.FileColumns.MIME_TYPE
    private const val MTYPE = MediaStore.Files.FileColumns.MEDIA_TYPE
    private const val DATA = MediaStore.Files.FileColumns.DATA

    private val projection = arrayOf(MediaStore.Files.FileColumns._ID, F, MIME, SIZE, MOD, MTYPE, DATA)
    private const val ESC = " ESCAPE '\\'"

    private fun like(s: String) = "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

    private fun extClause(exts: Collection<String>): Pair<String, List<String>> =
        exts.joinToString(" OR ", "(", ")") { "$F LIKE ?" } to exts.map { "%.$it" }

    private fun toItem(c: Cursor): FileItem {
        val id = c.getLong(0); val name = c.getString(1) ?: "file"; val mime = c.getString(2) ?: ""
        val size = if (c.isNull(3)) 0L else c.getLong(3); val mod = c.getLong(4) * 1000L; val mt = c.getInt(5); val path = c.getString(6) ?: ""
        val base = when (mt) {
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> filesUri
        }
        var kind = FileTypes.kindOf(name)
        if (kind == FileKind.OTHER) kind = FileTypes.kindOfMime(mime)
        return FileItem(path, name, false, size, mod, kind, ContentUris.withAppendedId(base, id).toString(), mime, if (path.isNotBlank()) File(path).parent.orEmpty() else "")
    }

    private fun run(ctx: Context, selection: String, args: List<String>, sort: SortMode, limit: Int, offset: Int): List<FileItem> {
        val col = when (sort) { SortMode.NAME, SortMode.TYPE -> F; SortMode.SIZE -> SIZE; SortMode.DATE -> MOD }
        val dir = if (sort == SortMode.NAME || sort == SortMode.TYPE) ContentResolver.QUERY_SORT_DIRECTION_ASCENDING else ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toTypedArray())
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(col, MediaStore.Files.FileColumns._ID))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, dir)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit); putInt(ContentResolver.QUERY_ARG_OFFSET, offset)
        }
        val out = ArrayList<FileItem>()
        try { ctx.contentResolver.query(filesUri, projection, b, null)?.use { c -> while (c.moveToNext()) out.add(toItem(c)) } }
        catch (e: Exception) { /* provider unavailable or permission changed mid-query: return what we have, never fake items */ }
        return out
    }

    private const val REAL_FILE = "$SIZE > 0 AND $MIME IS NOT NULL AND $F NOT LIKE '.%'"

    private fun sectionClause(sec: FileSection): Pair<String, List<String>> = when (sec) {
        FileSection.RECENT -> REAL_FILE to emptyList()
        FileSection.IMAGES -> "$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}" to emptyList()
        FileSection.VIDEOS -> "$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}" to emptyList()
        FileSection.AUDIO -> "$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}" to emptyList()
        FileSection.DOCUMENTS -> extClause(FileTypes.extsOf(FileTypes.documentKinds))
        FileSection.APKS -> extClause(FileTypes.extsOf(setOf(FileKind.APK)))
        FileSection.ARCHIVES -> extClause(FileTypes.extsOf(setOf(FileKind.ARCHIVE)))
        FileSection.DOWNLOADS ->
            if (Build.VERSION.SDK_INT >= 29) "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?" to listOf("Download/%")
            else "$DATA LIKE ?" to listOf("%/Download/%")
    }

    fun section(ctx: Context, sec: FileSection, sort: SortMode = SortMode.DATE, limit: Int = 100, offset: Int = 0): List<FileItem> {
        val (sel, args) = sectionClause(sec)
        return run(ctx, sel, args, sort, limit, offset)
    }

    fun recent(ctx: Context, limit: Int = 30): List<FileItem> = section(ctx, FileSection.RECENT, SortMode.DATE, limit)

    fun count(ctx: Context, sec: FileSection): Int = try {
        val (sel, args) = sectionClause(sec)
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel); putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toTypedArray())
        }
        ctx.contentResolver.query(filesUri, arrayOf(MediaStore.Files.FileColumns._ID), b, null)?.use { it.count } ?: 0
    } catch (e: Exception) { 0 }

    /** The newest download (any type) — used by "meri latest downloaded file kholo" in Part 3. */
    fun latestDownload(ctx: Context): FileItem? = section(ctx, FileSection.DOWNLOADS, SortMode.DATE, 1).firstOrNull()

    /** Name / type / folder / date / size search through MediaStore. */
    fun search(ctx: Context, q: SearchQuery, sort: SortMode = SortMode.DATE, limit: Int = 200): List<FileItem> {
        val sel = ArrayList<String>(); val args = ArrayList<String>()
        sel.add(REAL_FILE)
        q.text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.forEach { sel.add("$F LIKE ?$ESC"); args.add(like(it)) }
        if (q.hasTypeFilter) {
            val exts = LinkedHashSet<String>(q.exts); exts.addAll(FileTypes.extsOf(q.kinds))
            val parts = ArrayList<String>()
            if (exts.isNotEmpty()) { val (c, a) = extClause(exts); parts.add(c); args.addAll(a) }
            // media kinds are also matched by Android's own media type, which catches files with unusual extensions
            if (FileKind.IMAGE in q.kinds) parts.add("$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}")
            if (FileKind.VIDEO in q.kinds) parts.add("$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}")
            if (FileKind.AUDIO in q.kinds) parts.add("$MTYPE=${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}")
            sel.add(parts.joinToString(" OR ", "(", ")"))
        }
        if (q.folder.isNotBlank()) { sel.add("$DATA LIKE ?$ESC"); args.add(like(q.folder.trim('/'))) }
        q.sinceMs?.let { sel.add("$MOD >= ?"); args.add((it / 1000).toString()) }
        q.untilMs?.let { sel.add("$MOD < ?"); args.add((it / 1000).toString()) }
        if (q.minSize > 0) { sel.add("$SIZE >= ?"); args.add(q.minSize.toString()) }
        return run(ctx, sel.joinToString(" AND "), args, sort, limit, 0)
    }

    /** Fallback when the index has nothing: walks real folders (only with path access), bounded in depth and count, and cancellable. */
    fun walk(roots: List<String>, q: SearchQuery, limit: Int = 200, maxVisited: Int = 60_000, alive: () -> Boolean = { true }): List<FileItem> {
        val out = ArrayList<FileItem>(); var visited = 0
        val queue = ArrayDeque<Pair<File, Int>>()
        roots.forEach { queue.add(File(it) to 0) }
        while (queue.isNotEmpty() && alive() && out.size < limit && visited < maxVisited) {
            val (dir, depth) = queue.removeFirst()
            if (PathRules.blockedReason(dir.path) != null) continue
            val kids = try { dir.listFiles() } catch (e: Exception) { null } ?: continue
            for (k in kids) {
                visited++
                if (k.isDirectory) { if (depth < 8) queue.add(k to depth + 1) }
                else { val fi = FileBrowser.fromFile(k); if (q.matches(fi)) out.add(fi) }
                if (out.size >= limit || visited >= maxVisited) break
            }
        }
        return FileSort.sort(out, SortMode.DATE)
    }

    /** Space used per category, counted from files Android lets Nova see. Honest about being a floor, not the whole truth. */
    fun usage(ctx: Context): StorageUsage {
        val tally = LinkedHashMap<String, LongArray>()      // label -> [bytes, count]
        val glyph = mapOf("Images" to "🖼", "Videos" to "🎬", "Audio" to "🎵", "Documents" to "📄", "APKs" to "📦", "Archives" to "🗜", "Other files" to "📎")
        fun add(label: String, size: Long) { val a: LongArray = tally.getOrPut(label) { LongArray(2) }; a[0] = a[0] + size; a[1] = a[1] + 1L }
        var rows = 0; val cap = 300_000
        val b = Bundle().apply { putString(ContentResolver.QUERY_ARG_SQL_SELECTION, REAL_FILE); putInt(ContentResolver.QUERY_ARG_LIMIT, cap) }
        try {
            ctx.contentResolver.query(filesUri, arrayOf(SIZE, F, MTYPE, MIME), b, null)?.use { c ->
                while (c.moveToNext()) {
                    rows++
                    val size = c.getLong(0); val name = c.getString(1) ?: ""; val mt = c.getInt(2)
                    val label = when {
                        mt == MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> "Images"
                        mt == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> "Videos"
                        mt == MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO -> "Audio"
                        else -> when (val k = FileTypes.kindOf(name)) {
                            FileKind.APK -> "APKs"; FileKind.ARCHIVE -> "Archives"
                            else -> if (k in FileTypes.documentKinds) "Documents" else "Other files"
                        }
                    }
                    add(label, size)
                }
            }
        } catch (e: Exception) { }
        val slices = tally.map { UsageSlice(it.key, glyph[it.key] ?: "📎", it.value[0], it.value[1].toInt()) }.sortedByDescending { it.bytes }
        return StorageUsage(slices, slices.sumOf { it.bytes }, rows >= cap)
    }
}
